package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomDimensions {

	public synchronized String pomDimensions(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("thumbnailDimensions", "xpath#//*[@class='col-sm-6 col-md-4'][1]/a/div/div/p");
			hs.put("Header_PageHeader", "xpath#//*[@class='page-header']");

			// Add Dimensions page
			hs.put("txtDimensionID", "name#_id");	
			hs.put("lblRelatedQuestion", "xpath#//*[@class='col-md-8']/p");
			hs.put("txtTitle", "id#title");

			hs.put("txtNameFr", "id#name_fr");
			hs.put("txtNameEs", "id#name_es");
			hs.put("txtNameId", "id#name_id");
			hs.put("txtNamePt", "id#name_pt");
			hs.put("txtNameTr", "id#name_tr");
			hs.put("txtNameLo", "id#name_lo");
			hs.put("txtNameVi", "id#name_vi");
			hs.put("txtNameTh", "id#name_th");
			
			// edit Dimensions page
			hs.put("btnEditDimensions", "css#div[row-index='0'] div[col-id='editFlag'] a");
			hs.put("headerEditDimensions", "xpath#//*[@class='page-header']");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");

			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
