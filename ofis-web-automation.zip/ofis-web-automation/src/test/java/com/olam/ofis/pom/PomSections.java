package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomSections {

	public synchronized String pomSections(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("thumbnailAllSections", "xpath#//h3[contains(text(),'All Sections')]");
			hs.put("Header_PageHeader", "xpath#//*[@class='page-header']");
			hs.put("btn_AddSections", "xpath#//*[@class='btn btn-primary']");

			hs.put("drp_FarmerGroup", "name#farmerGroup");
			hs.put("txt_code", "name#code");
			hs.put("txt_name", "name#name");
			hs.put("chk_active", "xpath#//input[@type='checkbox']");

			// Edit all sections page
			hs.put("btn_edit_allSections", "css#div[row-index='0'] div[col-id='0']");
			hs.put("Header_edit_allSections", "xpath#//*[@class='page-header']");
			hs.put("txt_sectionid", "name#id");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");

			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
