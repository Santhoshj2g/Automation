package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomRegions {

	public synchronized String pomRegions(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("iFrame_GeoData", "id#RefFrame");
			hs.put("thumbnail_region", "xpath#//*[@class='col-sm-6 col-md-4'][2]/a/div/div");
			hs.put("Header_PageHeader", "xpath#//*[@class='page-header ofisHeader']");
			hs.put("btn_AddRegion", "xpath#//*[@class='btn btn-primary']");

			hs.put("drp_country", "id#countryId");
			hs.put("txt_name", "id#name");
			hs.put("drp_main_product", "xpath#//*[@formcontrolname='product']");
			hs.put("drp_sub_product", "xpath#//*[@class='ng-option'][1]/span");
			hs.put("txt_centre_lat", "id#centre_lat");
			hs.put("txt_centre_lng", "id#centre_lng");
			hs.put("chk_active", "xpath#//input[@type='checkbox']");
			hs.put("btn_add_region", "xpath#//*[@class='btn btn-primary']");

			// Edit all regions page
			hs.put("btn_edit_allregions", "css#div[row-index='0'] div[col-id='0']");
			hs.put("Header_edit_allcountries", "xpath#//*[@class='page-header ofisHeader']");
			hs.put("txt_regionid", "name#regionId");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");

			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
