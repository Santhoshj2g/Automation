package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomSubModules;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class SubModules extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomSubModules pomSubModules = new PomSubModules();

	public SubModules(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderAllSubModules;
	private String expectedPageHeaderEditAllSubModules;
	private int expectedSubModuleId;
	private String expectedModule;
	private int expectedPageNumber;
	private String expectedName;
	private String expectedNameFrench;
	private String expectedNameSpanish;
	private String expectedNameIndonesian;
	private String expectedNamePortuguese;
	private String expectedNameTurkish;
	private String expectedNameLao;
	private String expectedNameVietnamese;
	private String expectedNameThai;

	public synchronized void allSubModulesLoadExcelData()
			throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/AllSubModules.xlsx");
	
		expectedPageHeaderAllSubModules = read.getCellData("AllSubModulesTC", "pageHeaderAllSubModules", 1);
		expectedPageHeaderEditAllSubModules = read.getCellData("AllSubModulesTC", "pageHeaderEditAllSubModules", 1);
		expectedSubModuleId = read.getNumericCellData("AllSubModulesTC", "text_submoduleid", 1);
		expectedModule = read.getCellData("AllSubModulesTC", "dropdown_module", 1);
		expectedPageNumber = read.getNumericCellData("AllSubModulesTC", "text_pagenumber", 1);
		expectedName = read.getCellData("AllSubModulesTC", "text_name", 1);
		expectedNameFrench = read.getCellData("AllSubModulesTC", "text_name_fr", 1);
		expectedNameSpanish = read.getCellData("AllSubModulesTC", "text_name_es", 1);
		expectedNameIndonesian = read.getCellData("AllSubModulesTC", "text_name_id", 1);
		expectedNamePortuguese = read.getCellData("AllSubModulesTC", "text_name_pt", 1);
		expectedNameTurkish = read.getCellData("AllSubModulesTC", "text_name_tr", 1);
		expectedNameLao = read.getCellData("AllSubModulesTC", "text_name_lo", 1);
		expectedNameVietnamese = read.getCellData("AllSubModulesTC", "text_name_vi", 1);
		expectedNameThai = read.getCellData("AllSubModulesTC", "text_name_th", 1);

	}
	public synchronized void settingsQuestionnaireDataClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_questionnaires"), "Settings->Questionaire data");
	}

	public synchronized void allSubMolulesClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomSubModules.pomSubModules("thumbnailAllSubModules"),
				"thumbnail all sub modules");
	}

	public synchronized void allSubModulesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomSubModules.pomSubModules("Header_PageHeader"),
				expectedPageHeaderAllSubModules, "PageHeader all sub modules");
	}

	public synchronized void editSubAllModulesButtonClick() throws InterruptedException {
		Thread.sleep(3000);
		webElementMouseHoverAndClick(pomSubModules.pomSubModules("btnEditSubModules"),
				"Edit all sub modules button");
	}

	public synchronized void editAllSubModulesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomSubModules.pomSubModules("headerEditSubModules"),
				expectedPageHeaderEditAllSubModules, "Edit all sub modules Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomSubModules.pomSubModules("btn_Cancel"), "cancel");
	}

	public synchronized void validateAllSubModulesValues() throws InterruptedException {
		Thread.sleep(7000);
		webGetAttributeValueAndAssertEqualsNumeric(pomSubModules.pomSubModules("txtSubModuleId"),
				expectedSubModuleId, "sub module id");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(pomSubModules.pomSubModules("drpModule"),
				expectedModule, "module - dropdown");
		webGetAttributeValueAndAssertEqualsNumeric(pomSubModules.pomSubModules("txtPageNumber"),
				expectedPageNumber, "page number");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomSubModules.pomSubModules("txtName"),
				expectedName, "name");
		verifyWebCheckBoxIsSelected(pomSubModules.pomSubModules("chkActiveSubModule"),
				"active sub Module - checkbox");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomSubModules.pomSubModules("txtNameFr"),
				expectedNameFrench, "name French");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomSubModules.pomSubModules("txtNameEs"),
				expectedNameSpanish, "name spanish");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomSubModules.pomSubModules("txtNameId"),
				expectedNameIndonesian, "Bahasa Indonesian Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomSubModules.pomSubModules("txtNamePt"),
				expectedNamePortuguese, "Portuguese Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomSubModules.pomSubModules("txtNameTr"),
				expectedNameTurkish, "Turkish Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomSubModules.pomSubModules("txtNameLo"),
				expectedNameLao, "Lao Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomSubModules.pomSubModules("txtNameVi"),
				expectedNameVietnamese, "Vietnamese Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomSubModules.pomSubModules("txtNameTh"),
				expectedNameThai, "Thai Name");

	}
}
