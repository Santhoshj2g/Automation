package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomEnumerators {

	public synchronized String pomEnumerators(String locator)
	{
		try
		{
			Hashtable<String,String> hs = new Hashtable<String,String>();
			hs.put("iFrame_OFISUser", "id#RefFrame");
			hs.put("thumbnail_Enumerator", "xpath#//*[@class='col-sm-6 col-md-4'][2]/a/div/div");
			hs.put("Header_PageHeader", "xpath#//*[@class='page-header ofisHeader']");
			hs.put("btn_AddEnumerator", "xpath#//*[@class='btn btn-primary']");
			
			hs.put("txt_enum_name", "id#name");
			hs.put("txt_olam_enum_id", "id#olam_enumerator_id");
			hs.put("btn_AddEnumerator", "xpath#//*[@class='btn btn-primary']");
			hs.put("txt_name", "id#name");
			hs.put("txt_olam_enumerator_id", "id#olam_enumerator_id");
			hs.put("drp_main_product_assignment", "xpath#//*[@formcontrolname='product']");
			hs.put("drp_sub_product_assignment", "xpath#//*[@class='ng-option'][1]/span");
			hs.put("drp_enum_assignment_type", "xpath#//select[@id='assignment_type']");
			
			hs.put("drp_main_enum_assignment", "xpath#//ng-select[@formcontrolname='assignments']");
			hs.put("drp_sub_enum_assignment", "xpath#//*[@class='ng-option'][1]/span");
			hs.put("drp_sub_enum_assignment_all", "xpaths#//*[@class='ng-option' or @class='ng-option ng-option-marked']");
			
			hs.put("drp_main_buying_agents", "xpath#//ng-select[@formcontrolname='buying_agent']");
			hs.put("drp_sub_buying_agents", "xpath#//*[@class='ng-option'][1]");
			
			
			hs.put("chk_active_enum", "id#active");
			hs.put("btn_add_enum", "xpath#//*[@class='btn btn-primary']");
		
			//Edit Enumerator page
			hs.put("btn_editEnumerator", "css#div[row-id='0'] div[col-id='0']");
			hs.put("Header_EditEnumerator", "xpath#//*[@class='page-header']");
			hs.put("txt_enumeratorid", "id#id");
			hs.put("txt_name", "id#name");
			hs.put("txt_olam_enumeratorid", "id#olam_enumerator_id");
			hs.put("txt_install_id", "id#install_id");
			hs.put("txt_app_version", "id#app_version");
			hs.put("chk_active", "id#active");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");
			
			return hs.get(locator);
		}catch(Exception e)
		{
			System.out.println("Error occurred in POM classes :"+e);
			return null;
		}
		
	}
}
