package com.olam.ofis.pom;

import java.util.Hashtable;

public class JsonPomFarmerOverview {

	public synchronized String jsonKeys(String getKey)
	{

		try
		{
			Hashtable<String, String> hs = new Hashtable<String, String>();
			
			//Farmer Overview Tab
			//farmers key used for Farmer, Enumerators and Sections
			hs.put("farmers", "outputdata.fgOverviewStats[0].val");
			hs.put("rightSectionsName", "outputdata.sections[0].section_name");
			hs.put("rightSectionsCount", "outputdata.sections[0].farmer_count");
			hs.put("surveyUnderReview", "outputdata.reviewstatistics.under_review");
			hs.put("surveyUnderReviewPercent", "outputdata.reviewstatistics.under_review_percentage");
			hs.put("avgFarmerAge", "outputdata.statisticOverviews[0].valueStr");
			hs.put("femaleFarmers", "outputdata.statisticOverviews[1].valueStr");
			hs.put("maleFarmers", "outputdata.statisticOverviews[2].valueStr");
			hs.put("farmsMappedSinglePoint", "outputdata.statisticOverviews[3].valueStr");
			hs.put("farmsMappedBoundaryPlotted", "outputdata.statisticOverviews[4].valueStr");
			hs.put("avgFarmSizeSurveyed", "outputdata.statisticOverviews[5].valueStr");
			hs.put("avgFarmSizeGps", "outputdata.statisticOverviews[6].valueStr");
			hs.put("totalSurveyedHectares", "outputdata.statisticOverviews[7].valueStr");
			hs.put("totalGpsMappedHectares", "outputdata.statisticOverviews[8].valueStr");
			hs.put("aveEstimatedYieldSurveyedHA", "outputdata.statisticOverviews[9].valueStr");
			hs.put("aveEstimatedYieldGpsHA", "outputdata.statisticOverviews[10].valueStr");
			hs.put("aveGpsScore", "outputdata.statisticOverviews[11].valueStr");
			hs.put("numFarmersWithMobilePhone", "outputdata.statisticOverviews[12].valueStr");

			//farmers Popup
			hs.put("farmersid", "outputdata.farmers[0].id");
			hs.put("farmersOlamFarmerId", "outputdata.farmers[0].olam_farmer_id");
			hs.put("farmersName", "outputdata.farmers[0].name");
			hs.put("farmersEnumeratorName", "outputdata.farmers[0].enumerator_name");
			hs.put("farmersPlaceName", "outputdata.farmers[0].place_name");
			
			//Left sections popup
			hs.put("sectionName", "outputdata.sections[0].name");
			hs.put("sectionFarmers", "outputdata.sections[0].farmers");
			hs.put("sectionSurveyCount", "outputdata.sections[0].survey_count");
			
			//Survey Completed block
			hs.put("lblBaselineSurvey", "outputdata.surveyCompletedList[0].name");
			hs.put("surveyCompleted", "outputdata.surveyCompletedList[0].completed");
			hs.put("surveyTotal", "outputdata.surveyCompletedList[0].total");
		
			//Activity block
			hs.put("activity", "outputdata.compressedData");
			
			//Training Tab
			//statement block
			//trainingTabLeftPanel key used for COURSES AVAILABLE, MODULES AVAILABLE, TOTAL TRAINED FARMERS, TRAINED THIS MONTH
			hs.put("trainingTabLeftPanel", "outputdata.fgOverviewStats[0].val");
			hs.put("courseName", "outputTrainingStatementDto.trainingStatements[0].course");
			hs.put("moduleName", "outputTrainingStatementDto.trainingStatements[0].module_name");
			hs.put("status", "outputTrainingStatementDto.trainingStatements[0].courseStatus");
			hs.put("enumerator", "outputTrainingStatementDto.trainingStatements[0].enumerator_name");
			hs.put("date", "outputTrainingStatementDto.trainingStatements[0].submission_date");
			hs.put("time", "outputTrainingStatementDto.trainingStatements[0].submission_time");
			hs.put("totalAttendees", "outputTrainingStatementDto.trainingStatements[0].training_attendees");
			
			//Course List block
			hs.put("courseListCourseName", "outputData.courseListDtos[0].course_name");
			
			//Enumerators block
			hs.put("enumeratorName", "outputEnumeratorListDto.trainingEnumerators[0].enumerator_name");
			hs.put("enumFarmerCount", "outputEnumeratorListDto.trainingEnumerators[0].farmer_count");
			
			//Management Tab
			//managementTab Left panel
			hs.put("managementTabLeftPanel", "outputdata.fgOverviewStats[0].val");
			//FDP input progress
			hs.put("fertilizerRequiredCurrYr", "outputFMPInputProgressDto.fmpInputProgressDto.fertilizerRequiredCurrYr");
			hs.put("fertilizerGivenCurrYr", "outputFMPInputProgressDto.fmpInputProgressDto.fertilizerGivenCurrYr");
			hs.put("fertilizerRequiredNxtYr", "outputFMPInputProgressDto.fmpInputProgressDto.fertilizerRequiredNxtYr");
			hs.put("seedlingRequiredCurrYr", "outputFMPInputProgressDto.fmpInputProgressDto.seedlingRequiredCurrYr");
			hs.put("seedlingGivenCurrYr", "outputFMPInputProgressDto.fmpInputProgressDto.seedlingGivenCurrYr");
			hs.put("seedlingRequiredNxtYr", "outputFMPInputProgressDto.fmpInputProgressDto.seedlingRequiredNxtYr");
			
			//management tab - generated plans block
			hs.put("fmpCompletedCount", "outputdata.completed_count");
			hs.put("fmpAvailableCount", "outputdata.available_count");
			
			//management tab - sections
			hs.put("managementSectionName", "outputdata.sections[0].section_name");
			hs.put("managementSectionFarmer", "outputdata.sections[0].farmer_count");
			
			//management tab - Farmer Management Plans
			hs.put("fmpPlansList", "outputdata.farmers_count_with_plans#outputdata.farmers_count_without_plans#outputdata.farmers_count_without_enough_data");
			
			return hs.get(getKey);

		}catch(Exception e){
			System.out.println("Error occurred in POM classes :"+e);
			return null;
		}
	}



}
