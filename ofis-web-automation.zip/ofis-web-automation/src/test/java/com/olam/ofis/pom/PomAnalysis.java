package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomAnalysis {

	public synchronized String pomAnalysis(String locator)
	{
		
		try
		{
		Hashtable<String, String> hs = new Hashtable<String, String>();
		
		hs.put("Header_PageHeader", "xpath#//*[@class='page-header']");
		
		//Analysis page
		hs.put("blckOne", "xpath#//*[@id='favourite-chart-1']/div[1]/h2/a");
		hs.put("blckTwo", "xpath#//*[@id='favourite-chart-2']/div[1]/h2/a");
		hs.put("blckThree", "xpath#//*[@id='favourite-chart-3']/div[1]/h2/a");
		hs.put("blckFour", "xpath#//*[@id='favourite-chart-4']/div[1]/h2/a");				
		
		return hs.get(locator);
		}catch(Exception e){
			System.out.println("Error occurred in POM classes :"+e);
			return null;
		}
}

	

}
