package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomLookupValues;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class LookupValues extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomLookupValues pomLookupValues = new PomLookupValues();

	public LookupValues(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderAllLookupValues;
	private String expectedPageHeaderEditAllLookupValues;
	private int expectedLookupValueId;
	private String expectedQuestion;
	private int expectedPosition;
	private String expectedValue;
	private String expectedValueFrench;
	private String expectedValueSpanish;
	private String expectedValueIndonesian;
	private String expectedValuePortuguese;
	private String expectedValueTurkish;
	private String expectedValueLao;
	private String expectedValueVietnamese;
	private String expectedValueThai;
	
	

	public synchronized void allLookupValuesLoadExcelData()
			throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/AllLookupValues.xlsx");
	
		expectedPageHeaderAllLookupValues = read.getCellData("AllLookupValuesTC", "pageHeaderAllLookupValues", 1);
		expectedPageHeaderEditAllLookupValues = read.getCellData("AllLookupValuesTC", "pageHeaderEditAllLookupValues", 1);
		expectedLookupValueId = read.getNumericCellData("AllLookupValuesTC", "textLookupValueID", 1);
		expectedQuestion = read.getCellData("AllLookupValuesTC", "dropdownQuestion", 1);
		
		
		expectedPosition = read.getNumericCellData("AllLookupValuesTC", "textPosition", 1);
		expectedValue = read.getCellData("AllLookupValuesTC", "textValue", 1);
		expectedValueFrench = read.getCellData("AllLookupValuesTC", "textValueFr", 1);
		expectedValueSpanish = read.getCellData("AllLookupValuesTC", "textValueEs", 1);
		expectedValueIndonesian = read.getCellData("AllLookupValuesTC", "textValueId", 1);
		expectedValuePortuguese = read.getCellData("AllLookupValuesTC", "textValuePt", 1);
		expectedValueTurkish = read.getCellData("AllLookupValuesTC", "textValueTr", 1);
		expectedValueLao = read.getCellData("AllLookupValuesTC", "textValueLo", 1);
		expectedValueVietnamese = read.getCellData("AllLookupValuesTC", "textValueVi", 1);
		expectedValueThai = read.getCellData("AllLookupValuesTC", "textValueTh", 1);
			
	}

	
	public synchronized void settingsQuestionnaireDataClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_questionnaires"), "Settings->Questionaire data");
	}

	public synchronized void allLookupValuesClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomLookupValues.pomLookupValues("thumbnailAllLookupValues"),
				"thumbnail all lookup values");
	}

	public synchronized void allLookupValuesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(15000);
		webAssertEqualsAlphaNumeric(pomLookupValues.pomLookupValues("Header_PageHeader"),
				expectedPageHeaderAllLookupValues, "PageHeader all lookup values");
	}

	public synchronized void editAllLookupValuesButtonClick() throws InterruptedException {
		Thread.sleep(12000);
		webElementMouseHoverAndClick(pomLookupValues.pomLookupValues("btnEditLookupValues"),
				"Edit all lookup values button");
	}

	public synchronized void editAllLookupValuesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(9000);
		webAssertEqualsAlphaNumeric(pomLookupValues.pomLookupValues("headerEditLookupValues"),
				expectedPageHeaderEditAllLookupValues, "Edit all lookup values Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomLookupValues.pomLookupValues("btn_Cancel"), "cancel");
	}

	public synchronized void validateAllLookupValues() throws InterruptedException {
		Thread.sleep(7000);
		webGetAttributeValueAndAssertEqualsNumeric(pomLookupValues.pomLookupValues("txtLookupValueID"),
				expectedLookupValueId, "Lookup value id");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(pomLookupValues.pomLookupValues("drpQuestionId"),
				expectedQuestion, "Question id dropdown");
		webGetAttributeValueAndAssertEqualsNumeric(pomLookupValues.pomLookupValues("txtPosition"),
				expectedPosition, "Position");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomLookupValues.pomLookupValues("txtValue"),
				expectedValue, "Value");
		verifyWebTextBoxIsEmpty(pomLookupValues.pomLookupValues("txtRelatedImageOnApp"), "Related Image Displayed On App");
		verifyWebCheckBoxIsSelected(pomLookupValues.pomLookupValues("chkActiveLookupValue"),
				"Active Lookup Value - checkbox");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomLookupValues.pomLookupValues("txtValueFr"),
				expectedValueFrench, "French Value");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomLookupValues.pomLookupValues("txtValueEs"),
				expectedValueSpanish, "Spanish Value");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomLookupValues.pomLookupValues("txtValueId"),
				expectedValueIndonesian, "Bahasa Indonesian Value");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomLookupValues.pomLookupValues("txtValuePt"),
				expectedValuePortuguese, "Portuguese Value");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomLookupValues.pomLookupValues("txtValueTr"),
				expectedValueTurkish, "Turkish Value");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomLookupValues.pomLookupValues("txtValueLo"),
				expectedValueLao, "Lao Value");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomLookupValues.pomLookupValues("txtValueVi"),
				expectedValueVietnamese, "Vietnamese Value");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomLookupValues.pomLookupValues("txtValueTh"),
				expectedValueThai, "Thai Value");
		
	}
}
