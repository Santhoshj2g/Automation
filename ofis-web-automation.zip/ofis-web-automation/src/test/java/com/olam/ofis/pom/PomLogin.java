package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomLogin {

	public synchronized String pomLogin(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			// login
			hs.put("txt_email", "id#email");
			hs.put("txt_password", "id#password");
			hs.put("check_Policy", "id#ofis-guest-policy-agreement");
			hs.put("btn_Submit", "id#ofis-guest-login-submit");
			// logout
			hs.put("drp_main_logout", "xpath#//*[@class='nav navbar-nav navbar-right']/li[2]/a");
			hs.put("drp_sub_logout", "xpath#//*[@class='nav navbar-nav navbar-right']/li[2]/ul/li[3]/a");
			hs.put("lbl_alert_logout", "xpath#//*[@role='alert']/p");
			


			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
