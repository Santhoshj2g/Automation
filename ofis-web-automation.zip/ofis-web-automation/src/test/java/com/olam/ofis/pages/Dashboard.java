package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.wrappers.Functions;

public class Dashboard extends Functions {

	public Dashboard(RemoteWebDriver driver) {
		this.driver = driver;
	}

	PomMenus pomMenus = new PomMenus();
	
	public synchronized void dashboardMenuClick() throws InterruptedException {
		waitTill(7000);
		webElementClick(pomMenus.pomMenus("Menu_dashboard"),"Menu Dashboard");

	}

}
