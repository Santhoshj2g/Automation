package com.olam.ofis.pages;

import java.util.concurrent.TimeoutException;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomModules;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Modules extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomModules pomModules = new PomModules();

	public Modules(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderAllModules;
	private String expectedPageHeaderEditAllModules;
	private int expectedModuleId;
	private String expectedName;
	private String expectedNameFrench;
	private String expectedNameSpanish;
	private String expectedNameIndonesian;
	private String expectedNamePortuguese;
	private String expectedNameTurkish;
	private String expectedNameLoa;
	private String expectedNameVietnamese;
	private String expectedNameThai;

	public synchronized void allModulesLoadExcelData()
			throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/AllModules.xlsx");

		expectedPageHeaderAllModules = read.getCellData("AllModulesTC", "pageHeader_allModules", 1);
		expectedPageHeaderEditAllModules = read.getCellData("AllModulesTC", "pageHeader_edit_allModules", 1);
		expectedModuleId = read.getNumericCellData("AllModulesTC", "text_moduleid", 1);
		expectedName = read.getCellData("AllModulesTC", "text_name", 1);
		expectedNameFrench = read.getCellData("AllModulesTC", "text_name_fr", 1);
		expectedNameSpanish = read.getCellData("AllModulesTC", "text_name_es", 1);
		expectedNameIndonesian = read.getCellData("AllModulesTC", "text_name_id", 1);
		expectedNamePortuguese = read.getCellData("AllModulesTC", "text_name_pt", 1);
		expectedNameTurkish = read.getCellData("AllModulesTC", "text_name_tr", 1);
		expectedNameLoa = read.getCellData("AllModulesTC", "text_name_lo", 1);
		expectedNameVietnamese = read.getCellData("AllModulesTC", "text_name_vi", 1);
		expectedNameThai = read.getCellData("AllModulesTC", "text_name_th", 1);

	}

	public synchronized void settingsQuestionnaireDataClick() throws InterruptedException, TimeoutException {
		Thread.sleep(7000);
		//waitUntilSpinnerDisappear();
		//waitForElementNotVisible();
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_questionnaires"), "Settings->Questionaire data");
	}


	public synchronized void allMolulesClick() throws InterruptedException, TimeoutException {
		Thread.sleep(5000);
		webElementClick(pomModules.pomModules("thumbnailAllModules"), "thumbnail all modules");
	}

	public synchronized void allModulesPageHeaderValidation() throws InterruptedException, TimeoutException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomModules.pomModules("Header_PageHeader"),
				expectedPageHeaderAllModules, "PageHeader all modules");
	}

	public synchronized void editAllModulesButtonClick() throws InterruptedException {
		Thread.sleep(3000);
		webElementMouseHoverAndClick(pomModules.pomModules("btnEditModules"),
				"Edit all modules button");
	}

	public synchronized void editAllModulesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomModules.pomModules("headerEditModules"),
				expectedPageHeaderEditAllModules, "Edit all modules Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomModules.pomModules("btn_Cancel"), "cancel");
	}

	public synchronized void validateAllModulesValues() throws InterruptedException, TimeoutException {
		Thread.sleep(7000);
		webGetAttributeValueAndAssertEqualsNumeric(pomModules.pomModules("txtModuleId"),
				expectedModuleId, "module id");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomModules.pomModules("txtName"),
				expectedName, "name");
		verifyWebTextBoxIsEmpty(pomModules.pomModules("txtExpires"), "expires");
		verifyWebCheckBoxIsNotSelected(pomModules.pomModules("chkAffectFMP"),
				"Affected Farmer management plan ? - checkbox");
		verifyWebCheckBoxIsSelected(pomModules.pomModules("chkActiveModule"), "active Module - checkbox");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomModules.pomModules("txtNameFr"),
				expectedNameFrench, "name French");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomModules.pomModules("txtNameEs"),
				expectedNameSpanish, "name spanish");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomModules.pomModules("txtNameId"),
				expectedNameIndonesian, "Bahasa Indonesian Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomModules.pomModules("txtNamePt"),
				expectedNamePortuguese, "Portuguese Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomModules.pomModules("txtNameTr"),
				expectedNameTurkish, "Turkish Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomModules.pomModules("txtNameLo"),
				expectedNameLoa, "Lao Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomModules.pomModules("txtNameVi"),
				expectedNameVietnamese, "Vietnamese Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomModules.pomModules("txtNameTh"),
				expectedNameThai, "Thai Name");

	}
}
