package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomUsers {

	public synchronized String pomUsers(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("txt_email", "id#email");
			hs.put("txt_password", "id#password");
			hs.put("check_Policy", "id#ofis-guest-policy-agreement");
			hs.put("btn_Submit", "id#ofis-guest-login-submit");
			hs.put("Menu_Settings", "xpath#//*[@routerlink='/settings']");
			hs.put("Menu_User", "xpath#//*[@routerlink='/ofis-users']");
			hs.put("iFrame_OFISUser", "id#RefFrame");
			hs.put("Menu_WebUser", "xpath#//*[@class='col-sm-6 col-md-4'][1]/a/div/div");
			hs.put("btn_Edit", "css#div[row-id='0'] div[col-id='1']");
			hs.put("btn_AddUser", "xpath#//*[@class='btn btn-primary']");

			hs.put("Header_UserPageHeader", "xpath#//*[@class='page-header ofisHeader']");

			hs.put("txt_first_name", "id#first_name");
			hs.put("txt_last_name", "id#last_name");
			hs.put("txt_useremail", "id#email");
			hs.put("txt_userpassword", "id#password");
			hs.put("txt_confirm_password", "id#confirm_password");
			hs.put("drp_role", "id#role");
			hs.put("lst_Capabilities", "xpath#//*[@autocomplete='a8391efebfda']");
			hs.put("chk_active_user", "id#active_user");
			
			hs.put("drp_view_by", "id#view_by");
			
			hs.put("lst_country", "id#country");
			hs.put("lst_partner", "id#partner");
			hs.put("lst_product", "id#product");
			hs.put("lst_module", "id#module");
			
			hs.put("chk_download_farmer_data", "id#download_farmer_data");			
			hs.put("chk_view", "id#view");
			hs.put("chk_manage", "id#manage");
			hs.put("chk_can_send_messages", "id#can_send_messages");
			hs.put("chk_can_send_unapproved_messages", "id#can_send_unapproved_messages");
			hs.put("chk_can_approve_messages", "id#can_approve_messages");

			hs.put("txt_mblox_service_name", "id#mblox_service_name");
			hs.put("txt_mblox_service_key", "id#mblox_service_key");

			hs.put("btn_AddUser", "xpath#//*[@class='btn btn-primary']");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");
			hs.put("lbl_AddUserSuccessMsg", "xpath#//*[@class='alert alert-warning alert-dismissible display']/p");

			// Edit Page
			hs.put("Header_EditUserPage", "xpath#//*[@class='page-header']");
			hs.put("txt_userid", "id#user_id");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");

			hs.put("btn_All", "xpath#//div[@class='btn-group btn-group-sm']//button[text()='All']");
			hs.put("btn_EditUser", "xpath#//div[@title='indirani@mail.com']//following-sibling::div//span//span");
			hs.put("btn_UpdateUser", "xpath#//input[@type='submit']");
			
			//User page - module options
			hs.put("moduleoptn", "xpath#//div[@class='col-md-8']//select[@id='module']//option");
			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
