package com.olam.ofis.testcases;

import org.testng.annotations.Test;

import com.olam.ofis.pages.BaseTest;
import com.olam.ofis.pages.Dashboard;
import com.olam.ofis.pages.FDP_Setting;
import com.olam.ofis.pages.FarmerOverview;
import com.olam.ofis.pages.Users;
import com.olam.ofis.pom.PomMenus;

public class BugSprint extends BaseTest {
	PomMenus Menus = new PomMenus();
	Dashboard dashboardpage = new Dashboard(driver);
	FarmerOverview FMOverview = new FarmerOverview(driver);
	Users userpage = new Users(driver);

	// Jira 1164
	@Test
	public synchronized void FGOSurvey() throws Exception {
		userpage.settingsUsersClick();
		userpage.navigateToIframe();
		userpage.websiteUserClick();
		userpage.clickButton("btn_All", "All Button Clicked");
		userpage.clickButton("btn_EditUser", "Edit Button Clicked");
		userpage.selectListBy("Product", "COCOA");
		userpage.selectViewBy("Country", "COTE D'IVOIRE");
		userpage.selectListBy("Module", "Cocoa Baseline Survey");
		userpage.clickButton("btn_UpdateUser", "Update User Clicked");
		userpage.switchoutFromIframe();
		dashboardpage.dashboardMenuClick();

		webElementClick(Menus.pomMenus("Menu_farmerOverview"), "Menu FarmerOverview");

		FMOverview.foCountryClick();
		FMOverview.foSectionFilterCheckbox("ASSIDJAN ");
		FMOverview.foClickSubmit();
		FMOverview.surveyCompletedValidation("Survey completed box");

		webElementClick(Menus.pomMenus("Menu_farmerOverview"), "Menu FarmerOverview");

		FMOverview.foSectionFilterCheckbox("ASSIDJAN ");
		FMOverview.foClickSubmit();
		FMOverview.surveyCompletedValidation("Survey completed box");
	}

	@Test
	public synchronized void FGOMultipleSurveySelection() throws Exception {
		userpage.settingsUsersClick();
		userpage.navigateToIframe();
		userpage.websiteUserClick();
		userpage.clickButton("btn_All", "All Button Clicked");
		userpage.clickButton("btn_EditUser", "Edit User Clicked");
		userpage.selectListBy("Product", "COCOA");
		userpage.selectViewBy("Country", "COTE D'IVOIRE");
		userpage.selectMultipleValues("lst_module", "Cocoa Baseline Survey", "Coffee Baseline Survey");
		userpage.clickButton("btn_UpdateUser", "Update Button Clicked");
		userpage.switchoutFromIframe();
		dashboardpage.dashboardMenuClick();
		webElementClick(Menus.pomMenus("Menu_farmerOverview"), "Menu FarmerOverview");
		FMOverview.foCountryClick();
		FMOverview.foSectionFilterCheckbox("ASSIDJAN ");
		FMOverview.foClickSubmit();
		FMOverview.surveyCompletedValidation("Survey completed box");
	}

	@Test
	public synchronized void FGOAllSurvey() throws Exception {
		userpage.settingsUsersClick();
		userpage.navigateToIframe();
		userpage.websiteUserClick();
		userpage.clickButton("btn_All", "All Button Clicked");
		userpage.clickButton("btn_EditUser", "Edit Button Clicked");
		userpage.selectListBy("Product", "COFFEE");
		userpage.selectViewBy("Country", "COLOMBIA");
		userpage.selectListBy("Module", "All");
		userpage.clickButton("btn_UpdateUser", "Update Button Clicked");
		userpage.switchoutFromIframe();
		dashboardpage.dashboardMenuClick();
		webElementClick(Menus.pomMenus("Menu_farmerOverview"), "Menu FarmerOverview");

		FMOverview.foCountryClick();
		FMOverview.foClickSubmit();
		FMOverview.surveyCompletedValidation("Survey completed box");
	}

	@Test
	public synchronized void FGOSurvey_Country() throws Exception {
		Dashboard dashboardpage = new Dashboard(driver);
		FarmerOverview FMOverview = new FarmerOverview(driver);
		Users userpage = new Users(driver);
		userpage.settingsUsersClick();
		userpage.navigateToIframe();
		userpage.websiteUserClick();
		userpage.clickButton("btn_All", "All Button Clicked");
		userpage.clickButton("btn_EditUser", "Edit Button Clicked");
		userpage.selectListBy("Product", "COFFEE");
		userpage.selectViewBy("Country", "COLOMBIA");
		userpage.selectMultipleValues("lst_module", "Coffee Baseline Survey", "Coffee Annual Survey");
		userpage.clickButton("btn_UpdateUser", "Update Button Clicked");
		userpage.switchoutFromIframe();
		dashboardpage.dashboardMenuClick();
		webElementClick(Menus.pomMenus("Menu_farmerOverview"), "Menu FarmerOverview");
		FMOverview.foCountryClick();
		FMOverview.foClickSubmit();
		FMOverview.surveyCompletedValidation("Survey completed box");
	}

	@Test
	public synchronized void FGOMultipleProducts_Surveys() throws Exception {
		userpage.settingsUsersClick();
		userpage.navigateToIframe();
		userpage.websiteUserClick();
		userpage.clickButton("btn_All", "All Button Clicked");
		userpage.clickButton("btn_EditUser", "Edit Button Clicked");
		userpage.selectMultipleValues("lst_product", "COFFEE", "RUBBER");
		userpage.selectViewBy("Country", "COLOMBIA");
		userpage.selectMultipleValues("lst_module", "Coffee Baseline Survey", "Coffee Annual Survey");
		userpage.clickButton("btn_UpdateUser", "update Button Clicked");
		userpage.switchoutFromIframe();
		dashboardpage.dashboardMenuClick();
		webElementClick(Menus.pomMenus("Menu_farmerOverview"), "Menu FarmerOverview");

		FMOverview.foCountryClick();
		FMOverview.foClickSubmit();
		FMOverview.surveyCompletedValidation("Survey completed box");
	}

	@Test
	public synchronized void FGOMultipleCountries_Surveys() throws Exception {
		userpage.settingsUsersClick();
		userpage.navigateToIframe();
		userpage.websiteUserClick();
		userpage.clickButton("btn_All", "All Button Clicked");
		userpage.clickButton("btn_EditUser", "Edit Button Clicked");
		userpage.selectListBy("Product", "COFFEE");
		userpage.selectViewBy("Country", "Country");
		userpage.selectMultipleValues("lst_country", "COLOMBIA", "PERU");
		userpage.selectListBy("Module", "All");
		userpage.clickButton("btn_UpdateUser", "Clicked");
		userpage.switchoutFromIframe();
		dashboardpage.dashboardMenuClick();
		webElementClick(Menus.pomMenus("Menu_farmerOverview"), "Menu FarmerOverview");

		FMOverview.foCountryClick();
		FMOverview.foClickSubmit();
		FMOverview.surveyCompletedValidation("Survey completed box");
	}

	// Jira :1297
	@Test
	public synchronized void farmerGroupVsSectionValidation() throws InterruptedException {
		userpage.settingsUsersClick();
		userpage.navigateToIframe();
		userpage.websiteUserClick();
		userpage.clickButton("btn_All", "All Button Clicked");
		userpage.clickButton("btn_EditUser", "Edit Button Clicked");

		userpage.selectListBy("Product", "COCOA");
		userpage.selectViewBy("Country", "Country");
		userpage.selectListBy("Country", "COTE D'IVOIRE");

		userpage.selectMultipleValues("lst_module", "Cocoa Baseline Survey", "Cocoa Annual Survey");
		userpage.clickButton("btn_UpdateUser", "Update clicked");
		userpage.switchoutFromIframe();
		dashboardpage.dashboardMenuClick();
		webElementClick(Menus.pomMenus("Menu_farmerOverview"), "Menu FarmerOverview");
		FMOverview.foCountryClick();
		// FMOverview.foSectionFilterCheckbox("ETTIENKRO ");
		FMOverview.foSectionFilterCheckbox("KABRANKRO ");
		FMOverview.foClickSubmit();
		FMOverview.assertfarmergpVsSectionCountValidation("Farmer Group Vs Section Count");
		FMOverview.assertFarmerCountInSections("Farmer Count In SectionBox");
		FMOverview.assertFarmerCountInStatistics("Farmer Count In StatisticsBox");
		FMOverview.assertFarmerCountInSurveyCompleted("Farmer Count In Survey completed Box");
		FMOverview.assertActivityVsSection("Section in the Activity box");
		FMOverview.assertManagementFarmerCount("Farmer count in Management tab");
	}

	@Test
	public synchronized void farmerGroupVsSectionValidationnew() throws InterruptedException {
		webElementClick(Menus.pomMenus("Menu_farmerOverview"), "Menu FarmerOverview");
		FMOverview.foCountryClick();
		FMOverview.foSectionFilterCheckbox("ASSOKRO ");
		FMOverview.foClickSubmit();
		FMOverview.assertActivityVsSection("Section in the Activity box");
		FMOverview.assertManagementFarmerCount("Farmer count in Management tab");
	}

	// Jira 1277:

		@Test
		public synchronized void fmpPlanTextAreaValidation() {

			FDP_Setting FarmerPlan = new FDP_Setting(driver);

			FarmerPlan.clickSetting();
			FarmerPlan.clickButton("FarmDevelopmentPlan","ClickFDPMenu");
			FarmerPlan.clickButton("templates","clicktemplate");
			FarmerPlan.verifyLabel("templatesLabel", "Template");
			FarmerPlan.clickButton("TemplatesEdit","EditTemplates");
			FarmerPlan.verifyLabel("editTemplatesLabel", "Edit Template");
			FarmerPlan.waitAndClick("Next","clickNext");
			waitTill(2000);
			FarmerPlan.selectTemplateType("GapAdvice");
			waitTill(2000);
			FarmerPlan.getTextAreaFromAdvice("gapadviceslabel", "Trees well pruned");
			waitTill(2000);
			FarmerPlan.selectTemplateType("pests");
			waitTill(2000);
			FarmerPlan.getTextAreaFromAdvice("pestsadviceslabel","Canker");
			waitTill(2000);
			FarmerPlan.selectTemplateType("Pesticide");
			waitTill(2000);
			FarmerPlan.getTextAreaFromAdvice("pesticideadviceslabel","Pesticide Type Advice");
			waitTill(2000);
			FarmerPlan.clickButton("save", "Click Save button");
			waitTill(1000);
			FarmerPlan.clickButton("Yes","clickYesBtn");
		}

		@Test
		public void fmpPlanTextAreaValidationForPestsAdivce() {
			FDP_Setting FarmerPlan = new FDP_Setting(driver);
			FarmerPlan.clickSetting();
			FarmerPlan.webElementClickButton("FarmDevelopmentPlan","ClickFDPMenu");
			FarmerPlan.clickButton("templates","clicktemplate");
			FarmerPlan.verifyLabel("templatesLabel", "Template");
			FarmerPlan.clickButton("TemplatesEdit","EditTemplates");
			FarmerPlan.verifyLabel("editTemplatesLabel","Edit Template");
			FarmerPlan.waitAndClick("Next","clickNext");
			waitTill(2000);
			FarmerPlan.selectTemplateType("pests");
			waitTill(2000);
			FarmerPlan.getTextAreaFromAdvice("pestsadviceslabel","Canker");
			waitTill(2000);
			FarmerPlan.clickButton("save", "Click Save button");
			waitTill(1000);
			FarmerPlan.clickButton("Yes","clickYesBtn");

		}

		@Test
		public void fmpPlanTextAreaValidationForPesticideRecommendation() {
			FDP_Setting FarmerPlan = new FDP_Setting(driver);
			FarmerPlan.clickSetting();
			FarmerPlan.webElementClickButton("FarmDevelopmentPlan","ClickFDPMenu");
			FarmerPlan.clickButton("templates","clicktemplate");
			FarmerPlan.verifyLabel("templatesLabel","Template");
			FarmerPlan.clickButton("TemplatesEdit","EditTemplates");
			FarmerPlan.verifyLabel("editTemplatesLabel"," Edit Template ");
			FarmerPlan.waitAndClick("Next","clickNext");
			waitTill(2000);
			FarmerPlan.selectTemplateType("Pesticide");
			waitTill(2000);
			FarmerPlan.getTextAreaFromAdvice("pesticideadviceslabel","Pesticide Type Advice");
			waitTill(2000);
			FarmerPlan.clickButton("save", "Click Save button");
			waitTill(1000);
			FarmerPlan.clickButton("Yes","clickYesBtn");
			waitTill(3000);
			FarmerPlan.verifyLabel("templatesLabel","Template");
		}

		@Test
		public void fmpNewTemplateAdd() {
			FDP_Setting FarmerPlan = new FDP_Setting(driver);
			FarmerPlan.clickSetting();
			//Click on the FDP menu
			FarmerPlan.webElementClickButton("FarmDevelopmentPlan","ClickFDPMenu");
			//Click template menu and verify the label and click add
			FarmerPlan.clickButton("templates","clicktemplate");
			FarmerPlan.verifyLabel("templatesLabel","Template");
			waitTill(2000);
			FarmerPlan.waitAndClick("addtemplates", "Click Add template");
			waitTill(2000);
			FarmerPlan.selectAssignmentType("productAssignment","cocoa","Clicked productAssignment");
			FarmerPlan.selectAssignmentType("assignmenttype", "country", "click Country dropdown");
			waitTill(2000);
			FarmerPlan.clickButton("assignmentvalueclick", "Click");
			waitTill(2000);
			FarmerPlan.selectAssignmentType("assignmentTypeValue","INDIA","select assignment type");
			waitTill(2000);
			FarmerPlan.selectSegment("maxpermaxpot", "Pesticide Recommendations");
			waitTill(2000);
			FarmerPlan.selectSegment("maxperminpot", "Pests and Diseases");
			waitTill(2000);
			FarmerPlan.selectSegment("minpermaxpot", "GAP Advice");
			waitTill(2000);
			FarmerPlan.selectSegment("minperminpot", "No Modules");
			waitTill(2000);
			FarmerPlan.waitAndClick("Next","clickNext");
			waitTill(2000);
			FarmerPlan.selectTemplateType("pests");
			waitTill(2000);
			FarmerPlan.getTextAreaFromAdvice("pestsadviceslabel","Canker");
			waitTill(2000);
			FarmerPlan.selectTemplateType("Pesticide");
			waitTill(2000);
			FarmerPlan.getTextAreaFromAdvice("pesticideadviceslabel","Pesticide Type Advice");
			waitTill(2000);
		}
		
		@Test
		public synchronized void farmerManagementPlanSmokeTest() throws Exception {
			FDP_Setting FarmerPlan = new FDP_Setting(driver);

			FarmerPlan.clickSetting();
			FarmerPlan.webElementClickButton("FarmDevelopmentPlan","ClickFDPMenu");

			//clickTemplate
			FarmerPlan.clickButton("templates","clicktemplate");
			FarmerPlan.verifyLabel("templatesLabel","Template");
			FarmerPlan.clickButton("TemplatesEdit","EditTemplates");
			FarmerPlan.verifyLabel("editTemplatesLabel"," Edit Template ");
			
			FarmerPlan.clickButton("canceltemplate","Click Cancel templates");
			waitTill(2000);
			
			FarmerPlan.webElementClickButton("FarmDevelopmentPlan","ClickFDPMenu");
			
			 //calender Activity
			 
			FarmerPlan.clickButton("calendar_activity","click Calendar activity");
			FarmerPlan.verifyLabel("calendar_activity_label", "Calendar Activity");
			FarmerPlan.clickButton("EditCalender","Edit Calendar activity");
			FarmerPlan.verifyLabel("Editcalendar_activity_label", "Edit Calendar Activity");
			FarmerPlan.clickButton("CancelButtonCalender","Clicked Cancel Calendar");
			waitTill(2000);
			
			FarmerPlan.webElementClickButton("FarmDevelopmentPlan","ClickFDPMenu");

				
		    //Crop calender
				 
			FarmerPlan.clickButton("cropcallendar","click CropCalendar activity");
			FarmerPlan.verifyLabel("CropCalendar_label", "Crop Calendar");
			FarmerPlan.clickButton("EditcropCalender","Edit CropCalendar activity");
			FarmerPlan.verifyLabel("EditCropCalendarlabel", "Edit Crop Calendar");
			FarmerPlan.clickButton("CancelButtoncropCalender","Click Cancel CropCalendar");
			waitTill(2000);
			
			FarmerPlan.webElementClickButton("FarmDevelopmentPlan","ClickFDPMenu");

				
				 // Weighting
				 
			FarmerPlan.clickButton("weighting","click Weighting");
			FarmerPlan.verifyLabel("Weighting_label","Weighting");
			FarmerPlan.clickButton("Editweighting","Edit Weighting");
			FarmerPlan.verifyLabel("EditWeightingLabel", " Edit Weighting ");
			FarmerPlan.clickButton("CancelButtonweighting","Click cancel Weighting");
			waitTill(2000);
			
			FarmerPlan.webElementClickButton("FarmDevelopmentPlan","ClickFDPMenu");
				 //Setting
				 
			FarmerPlan.clickButton("settings","click settings");
			FarmerPlan.clickButton("EditSetting","Edit Setting");
			FarmerPlan.clickButton("CancelButtonSetting","Click cancel Setting");
			waitTill(2000);
			
			FarmerPlan.webElementClickButton("FarmDevelopmentPlan","ClickFDPMenu");



		}
}
