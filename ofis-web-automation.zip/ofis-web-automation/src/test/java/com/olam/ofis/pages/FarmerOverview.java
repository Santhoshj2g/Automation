package com.olam.ofis.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import com.codoid.products.fillo.RegEX;
import com.olam.ofis.pom.PomFarmerOverview;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.reports.ExtTestMngr;
import com.olam.ofis.wrappers.Functions;

public class FarmerOverview extends Functions {
	PomMenus pomMenus = new PomMenus();
	PomFarmerOverview pomFarmerOverview = new PomFarmerOverview();

	public FarmerOverview(RemoteWebDriver driver) {
		this.driver = driver;
	}
	
	public synchronized void foSelectCountryCheckBox() {
		webListAndCheckboxSelect(pomFarmerOverview.pomFarmerOverview("drp_main_country"),
				pomFarmerOverview.pomFarmerOverview("drp_sub_country"), "All country");
	}

	public synchronized void foWebListSearchAndCheckboxSelect(String getMainElement, String getSubElement,
			String strEnterText, String getFinalElement) {
		webListSearchAndCheckboxSelect(pomFarmerOverview.pomFarmerOverview(getMainElement),
				pomFarmerOverview.pomFarmerOverview(getSubElement), strEnterText,
				pomFarmerOverview.pomFarmerOverview(getFinalElement));
	}
	public synchronized void foCountryClick() {
		click(pomFarmerOverview.pomFarmerOverview("drp_main_country"), "Country arrow down");
		click(pomFarmerOverview.pomFarmerOverview("chk_all_countries"), "Check All Countries");
		waitTill(5000);
	}

	public synchronized void foSectionFilterCheckbox() {
		click(pomFarmerOverview.pomFarmerOverview("drp_section"), "Section dropdown");
		click(pomFarmerOverview.pomFarmerOverview("UnselectAll_section"), "UnselectAll checkbox for Section");
		click(pomFarmerOverview.pomFarmerOverview("chk_section"), "Checkbox selection for a particular section");
		click(pomFarmerOverview.pomFarmerOverview("clk_UpArrow"), "UpArrow icon");
	}
	public synchronized void foSectionFilterCheckbox(String section) {
		click(pomFarmerOverview.pomFarmerOverview("drp_section"), "Section dropdown");
		click(pomFarmerOverview.pomFarmerOverview("UnselectAll_section"), "UnselectAll checkbox for Section");
		driver.findElementByXPath(
				"//li[@class='multiselect-item-checkbox']//following-sibling::div[text()='" + section + "']").click();
		click(pomFarmerOverview.pomFarmerOverview("clk_UpArrow"), "UpArrow icon");
	}

	public synchronized void foClickSubmit() {
		click(pomFarmerOverview.pomFarmerOverview("btn_submit"), "Submit");
	}

	public synchronized void surveyCompletedValidation(String strFieldName) {
		try {
			waitTill(5000);
			List<WebElement> list = selectLocatorsBylists("", pomFarmerOverview.pomFarmerOverview("surveylist"));
			int count = list.size();
			for (int i = 0; i <= count; i++) {
				String s = list.get(i).getText();
				System.out.println(s);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public synchronized void assertFarmerCountInSurveyCompleted(String strFieldName) {
		try {
			String farmercount = selectByLocatorType(pomFarmerOverview.pomFarmerOverview("farmer_count")).getText();
			System.out.println("Farmer count displayed in the main farmer overview screen: " + farmercount);
			click(pomFarmerOverview.pomFarmerOverview("BaselinesurveyProgressbar"),
					"Progress bar of Baseline Survey");
			String FarmersCompletedsurveycount = selectByLocatorType(
					pomFarmerOverview.pomFarmerOverview("lblFarmersCompletedsurvey")).getText();
			System.out.println("Farmers Completed survey text :" + FarmersCompletedsurveycount);
			String latestfarmercount = RegEX.getFirstMatch(FarmersCompletedsurveycount, "/ \\d+").replace("/ ", "");
			System.out.println("Total farmers count displayed in the Survey baseline screen : " + latestfarmercount);
			Assert.assertEquals(latestfarmercount, farmercount,
					"Count of farmers in the overview page & total count in survey completed didnot match");
			click(pomFarmerOverview.pomFarmerOverview("Viewscreenclose"), "Close button of Survey baseline screen");
			ExtTestMngr.reportStepPass("Field Name : '" + strFieldName + "' is verfied successfully.");
		} catch (Exception e) {
			ExtTestMngr.reportStepFail("Field Name : '" + strFieldName + "' verification failed.", true);
			e.printStackTrace();
		}
	}

	public synchronized void assertfarmergpVsSectionCountValidation(String strFieldName) {
		try {
			waitTill(5000);
			List<WebElement> farmerGroupslist = selectLocatorsBylists("",
					pomFarmerOverview.pomFarmerOverview("farmer_groups_count"));
			int farmerGroupcount = farmerGroupslist.size();
			System.out.println("FarmerGroup count in the Farmer Groupsbox of Overview page: " + farmerGroupcount);
			waitTill(5000);
			List<WebElement> sectionlist = selectLocatorsBylists("", pomFarmerOverview.pomFarmerOverview("section_count"));
			int sectioncount = sectionlist.size();
			System.out.println("Section count in the Sectionbox of Overview page: " + sectioncount);
			Assert.assertEquals(farmerGroupcount, sectioncount, "One section should be mapped only to one farmergroup");
			ExtTestMngr.reportStepPass("Field Name : '" + strFieldName + "' is verfied successfully.");
		} catch (Exception e) {
			ExtTestMngr.reportStepFail("Field Name : '" + strFieldName + "' verification failed.", true);
			e.printStackTrace();
		}

	}

	public synchronized void assertFarmerCountInSections(String strFieldName) {

		try {
			String farmercount = selectByLocatorType(pomFarmerOverview.pomFarmerOverview("farmer_count")).getText();
			System.out.println("Total farmer count in the Overview page: " + farmercount);
			String secfarmercnt = selectByLocatorType(pomFarmerOverview.pomFarmerOverview("section_farmerCount")).getText();
			System.out.println("Farmer Count in the Section box: " + secfarmercnt);
			Assert.assertEquals(farmercount, secfarmercnt,
					"Farmers count in the overview page and farmers count in the sectionbox didnt match");
			ExtTestMngr.reportStepPass("Field Name : '" + strFieldName + "' is verfied successfully.");
		} catch (Exception e) {
			ExtTestMngr.reportStepFail("Field Name : '" + strFieldName + "' verification failed.", true);
			e.printStackTrace();
		}

	}

	public synchronized void assertFarmerCountInStatistics(String strFieldName) {

		try {
			String farmercount = selectByLocatorType(pomFarmerOverview.pomFarmerOverview("farmer_count")).getText();
			int farmercountint = Integer.valueOf(farmercount);
			String malefarmercount = selectByLocatorType(pomFarmerOverview.pomFarmerOverview("male_farmers_count")).getText();
			System.out.println("Total count of male farmers : " + malefarmercount);
			String femalefarmercount = selectByLocatorType(pomFarmerOverview.pomFarmerOverview("female_farmers_count")).getText();
			System.out.println("Total count of female farmers : " + femalefarmercount);
			int totalfarmerscount = Integer.valueOf(malefarmercount) + Integer.valueOf(femalefarmercount);
			System.out.println("Total count of male & female farmers: " + totalfarmerscount);
			Assert.assertEquals(farmercountint, totalfarmerscount,
					"Count of farmers in the overview page & total count in statistics didnot match");
			ExtTestMngr.reportStepPass("Field Name : '" + strFieldName + "' is verfied successfully.");
		} catch (NumberFormatException e) {
			ExtTestMngr.reportStepFail("Field Name : '" + strFieldName + "' verification failed.", true);
			e.printStackTrace();
		}

	}

	public synchronized void assertActivityVsSection(String strFieldName) {

		waitTill(5000);
		String sectiontxt = null;
		List<WebElement> activitypages = selectLocatorsBylists("", pomFarmerOverview.pomFarmerOverview("activity_pagination"));
		int pagescount = activitypages.size();
		System.out.println("Number of Activity pages: " + pagescount);
		for (int i = 0; i <= pagescount; i++) {

			try {
				sectiontxt = selectByLocatorType(pomFarmerOverview.pomFarmerOverview("activity_section_text")).getText();
				System.out.println(sectiontxt);

			} catch (Exception e) {
				System.out.println("Farmed added activity is not present in this page!");
			}

			finally {
				if (selectByLocatorType(pomFarmerOverview.pomFarmerOverview("activity_next_page")) != null)
					click(pomFarmerOverview.pomFarmerOverview("activity_next_page"), "Next page in activity");
				else
					break;
				ExtTestMngr.reportStepPass("Field Name : '" + strFieldName + "' is verfied successfully.");
			}
		}

		List<WebElement> list = selectLocatorsBylists("", pomFarmerOverview.pomFarmerOverview("surveylist"));
		int count = list.size();
		for (int i = 0; i <= count; i++) {
			String s = list.get(i).getText();
			System.out.println(s);
		}
	}

	public synchronized void assertManagementFarmerCount(String strFieldName) {
		try {
			waitTill(5000);
			click(pomFarmerOverview.pomFarmerOverview("tab_management"), "Management tab in the farmer overview");
			waitTill(3000);
			String mgmtfarmercount = selectByLocatorType(pomFarmerOverview.pomFarmerOverview("mgmt_farmer_count"))
					.getText();
			System.out.println("Total farmer count in the management page: " + mgmtfarmercount);
			waitTill(3000);
			click(pomFarmerOverview.pomFarmerOverview("tab_overview"), "Overview tab in the farmer overview");
			String farmercount = selectByLocatorType(pomFarmerOverview.pomFarmerOverview("farmer_count")).getText();
			System.out.println("Total farmer count in the Overview page: " + farmercount);
			Assert.assertEquals(mgmtfarmercount, farmercount,
					"Count of farmers in the overview page & total farmer count in management page didnot match");
			ExtTestMngr.reportStepPass("Field Name : '" + strFieldName + "' is verfied successfully.");
		} catch (Exception e) {
			ExtTestMngr.reportStepFail("Field Name : '" + strFieldName + "' verification failed.", true);
			e.printStackTrace();
		}

	}


}
