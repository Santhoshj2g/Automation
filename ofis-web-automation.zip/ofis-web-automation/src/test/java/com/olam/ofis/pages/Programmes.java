package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.pom.PomProgrammes;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Programmes extends Functions {

	public Programmes(RemoteWebDriver driver) {
		this.driver = driver;
	}

	PomProgrammes pomProgrammes = new PomProgrammes();
	PomMenus pomMenus = new PomMenus();

	private String expectedPageHeaderProgramme;
	private String expectedPageHeaderEditProgramme;
	private int expectedProgrammeId;
	private String expectedName;

	public synchronized void allProgrammesLoadExcelData()
			throws Exception {

		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/AllProgrammes.xlsx");
		
		expectedPageHeaderProgramme = read.getCellData("AllProgrammesTC", "pageheader_programme", 2);
		expectedPageHeaderEditProgramme = read.getCellData("AllProgrammesTC", "pageheader_editprogramme", 2);
		expectedProgrammeId = read.getNumericCellData("AllProgrammesTC", "text_programme_id", 2);
		expectedName = read.getCellData("AllProgrammesTC", "text_name", 2);
	
	}

	public synchronized void settingsAllProgrammesClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_progspartsproducts"), "Settings-ProgrammesPartnersProducts");
	}

	public synchronized void allProgrammesClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomProgrammes.pomProgrammes("thumbnail_programmes"), "thumbnail Programmes");
	}

	public synchronized void allProgrammesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(pomProgrammes.pomProgrammes("pageheader_programme"), expectedPageHeaderProgramme,
				"PageHeader 	programme");
	}

	public synchronized void editAllProgrammesButtonClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementMouseHoverAndClick(pomProgrammes.pomProgrammes("editprogramme"), "Edit button");
	}

	public synchronized void editAllProgrammesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomProgrammes.pomProgrammes("pageheader_editprogramme"),
				expectedPageHeaderEditProgramme, "Edit programme Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomProgrammes.pomProgrammes("btn_Cancel"), "cancel");
	}

	public synchronized void validateAllProgrammesValues() throws InterruptedException {
		Thread.sleep(2000);
		webGetAttributeValueAndAssertEqualsNumeric(pomProgrammes.pomProgrammes("txt_programmeid"), expectedProgrammeId,
				"programme id");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomProgrammes.pomProgrammes("txt_name"), expectedName,
				"Programme Name");
		verifyWebCheckBoxIsSelected(pomProgrammes.pomProgrammes("chk_active"), "programme Active- checkbox");
	}

}
