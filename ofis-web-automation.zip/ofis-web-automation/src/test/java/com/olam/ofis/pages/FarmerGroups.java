package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomFarmerGroups;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class FarmerGroups extends Functions {

	public FarmerGroups(RemoteWebDriver driver) {
		this.driver = driver;
	}

	PomMenus pomMenus = new PomMenus();
	PomFarmerGroups pomFarmerGroups = new PomFarmerGroups();

	private String expectedPageHeaderFarmerGroup;
	private String expectedPageHeaderEditFarmerGroup;
	private int expectedFarmerGroupId;
	private String expectedCountry;
	private String expectedPartnerId;
	private String expectedProgramme;
	private String expectedProduct;
	private String expectedCode;
	private String expectedFarmerGroupName;

	public synchronized void allFarmerGroupsLoadExcelData() throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/AllFarmerGroups.xlsx");

		expectedPageHeaderFarmerGroup = read.getCellData("AllFarmerGroupsTC", "pageHeader_farmergroup", 3);
		expectedPageHeaderEditFarmerGroup = read.getCellData("AllFarmerGroupsTC", "pageHeader_edit_farmergroup", 3);
		expectedFarmerGroupId = read.getNumericCellData("AllFarmerGroupsTC", "text_farmergroupid", 3);
		expectedCountry = read.getCellData("AllFarmerGroupsTC", "dropdown_country", 3);
		expectedPartnerId = read.getCellData("AllFarmerGroupsTC", "dropdown_partner_id", 3);
		expectedProgramme = read.getCellData("AllFarmerGroupsTC", "dropdown_programme", 3);
		expectedProduct = read.getCellData("AllFarmerGroupsTC", "dropdown_product", 3);
		expectedCode = read.getCellData("AllFarmerGroupsTC", "text_code", 3);
		expectedFarmerGroupName = read.getCellData("AllFarmerGroupsTC", "textbox_FGName", 3);
	}

	public synchronized void settingsFarmerGroupsClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_farmargroups"), "Settings->FarmerGroups");
	}

	public synchronized void allFarmerGroupsClick() throws InterruptedException {
		Thread.sleep(8000);
		webElementClick(pomFarmerGroups.pomFarmerGroups("Menu_AllFG"), "thumbnail all farmer group");
	}

	public synchronized void allFarmerGroupsPageHeaderValidation() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomFarmerGroups.pomFarmerGroups("Header_FGPageHeader"), expectedPageHeaderFarmerGroup,
				"PageHeader all farmer group");
	}

	public synchronized void editAllFarmerGroupsButtonClick() throws InterruptedException {
		Thread.sleep(7000);
		webElementMouseHoverAndClick(pomFarmerGroups.pomFarmerGroups("btn_edit_farmerGroup"),
				"Edit all farmer group button");
	}

	public synchronized void editAllFarmerGroupsPageHeaderValidation() throws InterruptedException {
		Thread.sleep(9000);
		webAssertEqualsAlphaNumeric(pomFarmerGroups.pomFarmerGroups("Header_edit_allfarmergroup"),
				expectedPageHeaderEditFarmerGroup, "Edit all farmer group Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomFarmerGroups.pomFarmerGroups("btn_Cancel"), "cancel");
	}

	public synchronized void validateAllFarmerGroupsValues() throws InterruptedException {
		Thread.sleep(7000);
		webGetAttributeValueAndAssertEqualsNumeric(pomFarmerGroups.pomFarmerGroups("txt_farmergroupid"),
				expectedFarmerGroupId, "farmer group id");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(pomFarmerGroups.pomFarmerGroups("drp_Country"),
				expectedCountry, "country dropdown");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(pomFarmerGroups.pomFarmerGroups("drp_partner_id"),
				expectedPartnerId, "partner");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(pomFarmerGroups.pomFarmerGroups("drp_programme"),
				expectedProgramme, "programme");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(pomFarmerGroups.pomFarmerGroups("drp_product"),
				expectedProduct, "product");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomFarmerGroups.pomFarmerGroups("txt_FGCode"), expectedCode,
				"code");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomFarmerGroups.pomFarmerGroups("txt_FGName"), expectedFarmerGroupName,
				"name");
		verifyWebCheckBoxIsSelected(pomFarmerGroups.pomFarmerGroups("chk_FGactive"), "active farmer group- checkbox");
		verifyWebCheckBoxIsNotSelected(pomFarmerGroups.pomFarmerGroups("chk_FGdefaultfg"), "default farmer group- checkbox");
	}
}
