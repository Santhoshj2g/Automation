package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomPermissions {

	public synchronized String pomPermissions(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("thumbnailPermissions", "xpath#//*[@class='col-sm-6 col-md-4'][3]/a/div/div/p");
			hs.put("Header_PageHeader", "xpath#//*[@class='page-header ofisHeader']");
			hs.put("iFrame_OFISUser", "id#RefFrame");

			hs.put("grdIndex", "css#div[row-id='0'] div[col-id='userId']");
			hs.put("grdFirstName", "css#div[row-id='0'] div[col-id='firstName']");
			hs.put("grdLastName", "css#div[row-id='0'] div[col-id='lastName']");
			
			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
