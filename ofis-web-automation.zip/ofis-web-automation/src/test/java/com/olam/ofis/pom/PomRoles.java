package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomRoles {

	public synchronized String pomRoles(String locator)
	{
		try
		{
			Hashtable<String,String> hs = new Hashtable<String,String>();
			hs.put("iFrame_OFISUser", "id#RefFrame");
			hs.put("thumbnail_roles", "xpath#//*[@class='col-sm-6 col-md-4'][4]/a/div/div");
			hs.put("Header_roles_PageHeader", "xpath#//*[@class='page-header ofisHeader']");
			hs.put("txt_roles_name", "id#name");
			
			//Edit roles page
			hs.put("btn_editroles", "css#div[row-id='0'] div[col-id='0']");
			hs.put("Header_Editroles", "xpath#//*[@class='page-header']");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");
			
			return hs.get(locator);
		}catch(Exception e)
		{
			System.out.println("Error occurred in POM classes :"+e);
			return null;
		}
		
	}
}
