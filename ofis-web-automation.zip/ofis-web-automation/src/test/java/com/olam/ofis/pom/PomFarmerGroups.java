package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomFarmerGroups {

	public synchronized String pomFarmerGroups(String locator)
	{
		
		try
		{
		Hashtable<String, String> hs = new Hashtable<String, String>();
		
		hs.put("Menu_AllFG", "xpath#//h3[contains(text(),'All Farmer Groups')]");
		hs.put("Menu_AddFG", "xpath#//*[@class='col-md-6 text-right']/a");
		hs.put("Header_FGPageHeader", "xpath#//*[@class='page-header']");
		
		//Add farmer group creation page
		hs.put("drp_Country", "id#country");
		hs.put("drp_partner_id", "id#partner");
		hs.put("drp_programme", "id#programme");
		hs.put("drp_product", "id#product");
		hs.put("txt_FGCode", "id#code");
		hs.put("txt_FGName", "id#name");
		hs.put("chk_FGactive", "xpath#//div[@class='form-group'][2]/div/input[2]");
		hs.put("chk_FGdefaultfg", "xpath#//div[@class='form-group'][3]/div/input[2]");
		hs.put("btn_FGAddFG", "xpath#//*[@value='Add Farmer Group']");
		hs.put("lbl_FGAddSuccessMsg", "xpath#//*[@class='alert alert-warning alert-dismissible display']/p");
		
		//edit farmer group creation page
		hs.put("btn_edit_farmerGroup", "css#div[row-index='0'] div[col-id='editFlag']");
		hs.put("Header_edit_allfarmergroup", "xpath#//*[@class='page-header']");
		hs.put("txt_farmergroupid", "name#id");
		hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");
		
		
		return hs.get(locator);
		}catch(Exception e){
			System.out.println("Error occurred in POM classes :"+e);
			return null;
		}
}

	

}
