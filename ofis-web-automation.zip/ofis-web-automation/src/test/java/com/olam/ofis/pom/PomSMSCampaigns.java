package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomSMSCampaigns {

	public synchronized String pomSMSCampaigns(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("thumbnailSMSCampaigns", "css#a[routerlink='/tasks/sms-campaign'] h3");
			hs.put("Header_PageHeader", "xpath#//*[@class='page-header']");

			// SMS Compaigns page - grd - grid
			hs.put("grdCreator", "xpath#//*[@class='ofis-fg-statement-table']/tbody/tr[1]/td[1]");
			hs.put("grdRecipients", "xpath#//*[@class='ofis-fg-statement-table']/tbody/tr[1]/td[3]");
			hs.put("grdMessage", "xpath#//*[@class='ofis-fg-statement-table']/tbody/tr[1]/td[4]");
			hs.put("grdStatus", "xpath#//*[@class='ofis-fg-statement-table']/tbody/tr[1]/td[5]");
			hs.put("grdDate", "xpath#//*[@class='ofis-fg-statement-table']/tbody/tr[1]/td[7]");
			
			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
