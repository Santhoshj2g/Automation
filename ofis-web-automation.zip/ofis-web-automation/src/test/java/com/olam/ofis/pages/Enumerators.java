package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomEnumerators;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Enumerators extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomEnumerators pomEnumerators = new PomEnumerators();

	public Enumerators(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderEnumerator;
	private String expectedName;
	private String expectedPageHeaderEditEnumerator;
	private int expectedEnumeratorId;
	private int expectedOlamEnumeratorId;
	private String expectedProductAssignment;
	private String expectedEnumeratorAssignmentType;
	private String expectedInstallId;
	private String expectedAppVersion;

	public synchronized void enumeratorLoadExcelData() throws Exception {
		// Expected data is retrieved from Excel sheet and it will be compared with
		// actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/Enumerator.xlsx");

		expectedName = read.getCellData("EnumeratorCreationTC", "text_name", 3);
		expectedPageHeaderEnumerator = read.getCellData("EnumeratorCreationTC", "PageHeader_Enumerator", 3);
		expectedPageHeaderEditEnumerator = read.getCellData("EnumeratorCreationTC", "PageHeader_EditEnumerator", 3);
		expectedEnumeratorId = read.getNumericCellData("EnumeratorCreationTC", "text_enumeratorid", 3);
		expectedOlamEnumeratorId = read.getNumericCellData("EnumeratorCreationTC", "text_olam_enumeratorid", 3);
		expectedProductAssignment = read.getCellData("EnumeratorCreationTC", "dropdown_prod_assignment", 3);
		expectedEnumeratorAssignmentType = read.getCellData("EnumeratorCreationTC", "dropdown_enum_assignment_type", 3);
		expectedInstallId = read.getCellData("EnumeratorCreationTC", "text_install_id", 3);
		expectedAppVersion = read.getCellData("EnumeratorCreationTC", "text_app_version", 3);
	}

	public synchronized void settingsUsersClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"), pomMenus.pomMenus("Settings_ofis-users"),
				"Settings-Users");
	}

	public synchronized void navigateToIframe() throws InterruptedException {

		Thread.sleep(1000);
		iFrameSwitchTo(pomEnumerators.pomEnumerators("iFrame_OFISUser"), "iFrame-OFISUser");

	}

	public synchronized void switchoutFromIframe() throws InterruptedException {

		Thread.sleep(1000);
		iFrameSwitchOut("iFrame-OFISUser");
	}

	public synchronized void enumeratorClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomEnumerators.pomEnumerators("thumbnail_Enumerator"), "thumbnail Enumerator");
	}

	public synchronized void enumeratorPageHeaderValidation() throws InterruptedException {
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(pomEnumerators.pomEnumerators("Header_PageHeader"), expectedPageHeaderEnumerator,
				"PageHeader Enumerator");
	}

	public synchronized void editEnumeratorButtonClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementMouseHoverAndClick(pomEnumerators.pomEnumerators("btn_editEnumerator"), "Edit button");
	}

	public synchronized void editEnumeratorPageHeaderValidation() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomEnumerators.pomEnumerators("Header_EditEnumerator"),
				expectedPageHeaderEditEnumerator, "Edit enumerator Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomEnumerators.pomEnumerators("btn_Cancel"), "cancel");
	}

	public synchronized void validateEnumeratorValues() throws InterruptedException {
		Thread.sleep(2000);
		webGetAttributeValueAndAssertEqualsNumeric(pomEnumerators.pomEnumerators("txt_enumeratorid"),
				expectedEnumeratorId, "enumerator id");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomEnumerators.pomEnumerators("txt_name"), expectedName,
				"enumerator Name");
		webGetAttributeValueAndAssertEqualsNumeric(pomEnumerators.pomEnumerators("txt_olam_enumeratorid"),
				expectedOlamEnumeratorId, "olam enumerator id");
		// WebGetSelectedValueFromDropdownAndAssertAlphaNumeric(POM_EnumCreation.POM_EnumeratorCreations("drp_main_product_assignment"),data_dropdown_prod_assignment3,"product
		// assignment - dropdown");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(
				pomEnumerators.pomEnumerators("drp_enum_assignment_type"), expectedEnumeratorAssignmentType,
				"product assignment type  - dropdown");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomEnumerators.pomEnumerators("txt_install_id"),
				expectedInstallId, "install id");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomEnumerators.pomEnumerators("txt_app_version"),
				expectedAppVersion, "app version");

		verifyWebCheckBoxIsSelected(pomEnumerators.pomEnumerators("chk_active"), "enumerator Active- checkbox");

	}

}
