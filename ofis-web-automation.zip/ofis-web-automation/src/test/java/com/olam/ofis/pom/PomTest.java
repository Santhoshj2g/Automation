package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomTest {

	public synchronized String pomTest(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();
			hs.put("Content-type", "application/json");
			hs.put("Authorization",
					"Bearer eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIzNTAiLCJuYmYiOjE1NDg3MzY1OTQsInVzZXJfbmFtZSI6IjY4NCIsInNjb3BlIjpbIioiXSwiaXNzIjoib2xhbUF1dGgiLCJsYW5ndWFnZV9pc29fY29kZSI6ImVuIiwiZXhwIjoxNTQ5MzQxMzk0LCJpYXQiOjE1NDg3MzY1OTQsImNsaWVudF9pZCI6IjMiLCJqdGkiOiJMX1VrMTRhVDFCSXVNdkRHTTdUM01KLUZVb1ZfSlYwaTFCREpsSlpZQy1xU1pMRzV5Vm4yd2NxLXdDLVAwWV92TWFHaFJKdHBQYTk2ZktTbE96cVhvVU5GOHFCVUpHUVE3NklJbjdyV0dxOEcxa21TdmtIZVpjX0NyY3dWZXNpa1FvNVZJZyJ9.q2opcbqsje7sr9PG_lbMCuoZcwFIkFHIzv46EySYAbpZUq5vs-58w8Rlwpg6grQ082PP8Y3GPusTllvm7JYHhz1Ys26Cib3874MUVa1c58o59NlPIOj5GNzmwh_U7_fpfe3ubaD5xFo5ZPKeOHed_BoklMwDm1L088vubERw_5KWpmcl6zKQ375xZJsWB8qzPSlxWa6fjSRvUA_L9hD-d5ft8x5AO1xpnpjsmXgqAij4fRgNKZEqbIpVL5YgIMZkrwSM1KphV059BWIazi_TgAkB5l0HNUrccwdvgFH7uk6w2RS9PAULIRYseU8NgbmdZpbaUdAnWozuNEr4VhTDN34RC-TF-t2GHEEYHAOiDFJ9L7FcGZ6hwQ2iRCkeUVDKNLJcnhhUDrZGHcodtwt1QtyXHZSVY2n5pRHxk43ggUSHL50x83k_mijj05d55WNQdeBi7kdGTfMJUCROw6Lx4p_7kzFwqDtcj3f-H0arRWS9XJFtsWBr6R0hKIJmWADyno6HxPzZnP2J3WcX0HwykVzfBiOKbFgDVkoXNcQxKFa7GnJP_-LihMqrQUY0oVAaylooAom8a0wkl7ULKB_XTr96Gsk8FYhn6SmaYFoep6ub1c1nWIGHsGEiHxhSz9OITuAVqEiqxcxfNjic4-ay4ZNTn0j0Dox4CJed2YMzihY");
			// hs.put("check_Policy", "id#ofis-guest-policy-agreement");

			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
