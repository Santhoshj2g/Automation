package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.pom.PomTasks;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class ManageGPX extends Functions {

	ReadExcel fromexcel;
	PomMenus pomMenus = new PomMenus();
	PomTasks pomTasks = new PomTasks();

	public ManageGPX(RemoteWebDriver driver) {
		this.driver = driver;
	}

	public ManageGPX() {

		pomTasks = new PomTasks();

	}

	/* Verify the user able to view the upload Gpx file */

	public synchronized void manageGpxSearchFarmer() throws Exception {

		// Expected data is retrieved from Excel sheet and it will be compared with
		// actual web UI data
		ReadExcel fromexcel = new ReadExcel("./src/test/resources/testdata/Task.xlsx");
		String expectedSearchFarmerId = fromexcel.getCellData("ManageGPX", "Farmer ID", 1);
		String expectedSearchFarmerName = fromexcel.getCellData("ManageGPX", "Farmer Name", 1);
		System.out.println(expectedSearchFarmerId);
		try {
			waitTill(5000);
			// Click Task
			webElementClick(pomTasks.pomTasks("taskmenu"), "taskmenu");
			waitTill(8000);
			// click manage gpx
			webElementClick(pomTasks.pomTasks("ClickmanageGPX"), "manageGPX");
			waitTill(8000);
			// Type farmer name or id
			WebEditEnterText(pomTasks.pomTasks("Text_farmerID_GPX"), expectedSearchFarmerId, "Type farmer name or id");
			waitTill(5000);
			// Check farmer button is enabled findfarmer
			verifyWebElementIsEnabled(pomTasks.pomTasks("Button_findfarmer_GPX"), "Find farmer button is enabled");
			// Click farmer button
			webElementClick(pomTasks.pomTasks("Button_findfarmer_GPX"), "Find farmer button click");
			waitTill(30000);
			/*
			 * In this method, search based on the farmer id,based on the farmer id it will
			 * verify the whether the View button is enabled if view button is displayed in
			 * the it will click upload update if is not it will click view button
			 */
			searchOlamFarmerIdAndClick(expectedSearchFarmerName, "ManageGpxlist");
			// switching to view Gpx windows
			switchToWindows(1, "windows");
			// verify textfile value
			String YourFarmIDGPX = webElementGetAttribute(pomTasks.pomTasks("YourFarmIDGPX"), "value");
			System.out.println(YourFarmIDGPX);
			verifyText("284667", YourFarmIDGPX);
			webDriverClose();

		} catch (Exception e) {

			System.out.println("Manage_GPX_TC002 " + e.getMessage());
		}

	}

	/* verify user able to Upload Gpx file suceesfully. */
	public synchronized void manageGpxUploadGpxFile() throws Exception {
		ReadExcel fromexcel = new ReadExcel("./src/test/resources/testdata/Task.xlsx");
		String searchfarmerID = fromexcel.getCellData("ManageGPX", "Farmer ID", 3);
		String Searchfarmername = fromexcel.getCellData("ManageGPX", "Farmer Name", 3);
		System.out.println(searchfarmerID);
		String uploadGPX = ".src/test/resources/gpx/run.gpx";
		try {
			waitTill(5000);
			// Click Task
			webElementClick(pomTasks.pomTasks("taskmenu"), "taskmenu");
			waitTill(8000);
			// click manage gpx
			webElementClick(pomTasks.pomTasks("ClickmanageGPX"), "manageGPX");
			waitTill(8000);
			// Type farmer name or id
			WebEditEnterText(pomTasks.pomTasks("Text_farmerID_GPX"), searchfarmerID, "Type farmer name or id");
			waitTill(5000);
			// Check farmer button is enabled findfarmer
			verifyWebElementIsEnabled(pomTasks.pomTasks("Button_findfarmer_GPX"), "Find farmer button is enabled");
			waitTill(5000);
			// Click farmer button
			webElementClick(pomTasks.pomTasks("Button_findfarmer_GPX"), "Find farmer button click");
			waitTill(15000);
			// Click upload based on the Condition
			searchOlamFarmerIdAndClick(Searchfarmername, "ManageGpxlist");
			waitTill(5000);
			// click choosefile in uploadbutton
			clickUsinglocator(pomTasks.pomTasks("FileUpload_ManageGPX"), "Click browser");
			waitTill(4000);
			uploadGPXFile(uploadGPX);
			waitTill(4000);

			// Clicking upload button
			webElementClick(pomTasks.pomTasks("UploadFILEBUTTON"), "UploadFILEBUTTON");
			waitTill(7000);
			// getting farm id
			String farmid = webElementGetAttribute(pomTasks.pomTasks("YourFarmIDGPX"), "value");
			System.out.println(farmid);
			clickUsinglocator(pomTasks.pomTasks("AprroverGPX"), "ApproverGPX");

			String AlertTest = webElementgetText(pomTasks.pomTasks("Alertmessage"), "SuccessAlertGPX");
			System.out.println(AlertTest);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	/* Verify the "find farmer" button is disabled */

	public synchronized void manageGpxFindFarmerButtonDisabledValidation() throws Exception {

		try {
			waitTill(8000);
			webElementClick(pomMenus.pomMenus("Menu_tasks"), "Menu Tasks");
			waitTill(8000);

			// click manage gpx
			webElementClick(pomTasks.pomTasks("ClickmanageGPX"), "manageGPX");
			waitTill(8000);

			// Verify textfield empty
			String Textfield = webElementGetAttribute(pomTasks.pomTasks("Text_farmerID_GPX"), "value");

			if (Textfield.isEmpty()) {
				System.out.println("textfield is empty");
			} else {
				System.out.println("textfield is not empty");
			}

			// Check farmer button is enabled findfarmer
			verifyWebElementIsEnabled(pomTasks.pomTasks("Button_findfarmer_GPX"), "Find farmer button is enabled ");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}

	}

	/*
	 * Verify farmer are listed in the Manage Gpx when click on the Find farmer
	 * button
	 */

	public synchronized void manageGpxFindFarmerButtonEnabledValidation() throws Exception {
		ReadExcel fromexcel = new ReadExcel("./src/test/resources/testdata/Task.xlsx");
		String searchfarmerID = fromexcel.getCellData("ManageGPX", "Farmer ID", 3);
		System.out.println(searchfarmerID);
		try {
			// Type farmer name or id
			WebEditEnterText(pomTasks.pomTasks("Text_farmerID_GPX"), searchfarmerID, "Type farmer name or id");
			waitTill(5000);
			// Verify textfield empty
			String Textfield = webElementGetAttribute(pomTasks.pomTasks("Text_farmerID_GPX"), "value");

			if (Textfield.isEmpty()) {
				System.out.println("textfield is empty");
			} else {
				System.out.println("textfield is not empty");
			}
			// Check farmer button is enabled findfarmer
			verifyWebElementIsEnabled(pomTasks.pomTasks("Button_findfarmer_GPX"), "Find farmer button is enabled");
			waitTill(4000);
			// Click farmer button
			webElementClick(pomTasks.pomTasks("Button_findfarmer_GPX"), "Find farmer button click");

		} catch (Exception e) {
			e.getMessage();
		}
	}
}
