
package com.olam.ofis.testcases;

import org.testng.annotations.Test;

import com.olam.ofis.pages.Analysis;
import com.olam.ofis.pages.BaseTest;
import com.olam.ofis.pages.CompletionCriteria;
import com.olam.ofis.pages.Countries;
import com.olam.ofis.pages.Courses;
import com.olam.ofis.pages.Dimensions;
import com.olam.ofis.pages.DimensionsGroups;
import com.olam.ofis.pages.Districts;
import com.olam.ofis.pages.Enumerators;
import com.olam.ofis.pages.FDP_Setting;
import com.olam.ofis.pages.FarmerGroups;
import com.olam.ofis.pages.FarmerOverview;
import com.olam.ofis.pages.LookupValues;
import com.olam.ofis.pages.Modules;
import com.olam.ofis.pages.ModulesAssignments;
import com.olam.ofis.pages.Partners;
import com.olam.ofis.pages.Permissions;
import com.olam.ofis.pages.Places;
import com.olam.ofis.pages.Products;
import com.olam.ofis.pages.Programmes;
import com.olam.ofis.pages.Questions;
import com.olam.ofis.pages.Regions;
import com.olam.ofis.pages.Roles;
import com.olam.ofis.pages.SMSCampaigns;
import com.olam.ofis.pages.Sections;
import com.olam.ofis.pages.SocialInfrastructurePoint;
import com.olam.ofis.pages.SubModules;
import com.olam.ofis.pages.TasksList;
import com.olam.ofis.pages.TrainingModules;
import com.olam.ofis.pages.Users;
import com.olam.ofis.pom.PomDashboard;
import com.olam.ofis.pom.PomFarmerOverview;
import com.olam.ofis.pom.PomMenus;

import io.restassured.response.Response;

public class SmokeTestCases extends BaseTest {
	PomFarmerOverview PomFarmerOverviewPage = new PomFarmerOverview();
	PomDashboard PomDashboardPage = new PomDashboard();

	@Test
	public synchronized void dashboardSmokeTest() throws Exception {
		
		String apiUrl = getApiUrl("dashboardEndPoint");
		Response response = getWithHeaders(apiUrl);
		assertApiUiNumeric(response,"farmerCount", PomDashboardPage.pomDashboard("lbl_DB_FarmersReg"),"Farmers Registered");
		assertApiUiNumeric(response,"enumeratorCount", PomDashboardPage.pomDashboard("lblActiveEnumerators"),"Active Enumerators");
		assertApiUiNumeric(response,"socialInfraCount", PomDashboardPage.pomDashboard("lblSocialInfraGpsMapped"),"Social Infrastructure GPS Mapped");
		assertApiUiNumeric(response,"plotsMappedCount", PomDashboardPage.pomDashboard("lblFarmsGpsMapped"),"Farms GPS Mapped");
	}

	@Test
	public synchronized void usersSmokeTest() throws Exception {
		Users UsersSmoke = new Users(driver);
		UsersSmoke.userCreationLoadExcelData();
		UsersSmoke.settingsUsersClick();
		UsersSmoke.navigateToIframe();
		UsersSmoke.websiteUserClick();
		UsersSmoke.userPageHeaderValidation();

		UsersSmoke.clickButton("btn_Edit", "Edit button");
		UsersSmoke.editUserPageHeaderValidation();
		UsersSmoke.validateUsersValues();
		UsersSmoke.clickButton("btn_Cancel", "Cancel button");
		UsersSmoke.userPageHeaderValidation();
		UsersSmoke.switchoutFromIframe();
	}

	@Test
	public synchronized void enumeratorSmokeTest() throws Exception {
		Enumerators EnumeratorCreationSmoke = new Enumerators(driver);
		EnumeratorCreationSmoke.enumeratorLoadExcelData();
		EnumeratorCreationSmoke.settingsUsersClick();
		EnumeratorCreationSmoke.navigateToIframe();
		EnumeratorCreationSmoke.enumeratorClick();
		EnumeratorCreationSmoke.enumeratorPageHeaderValidation();
		EnumeratorCreationSmoke.editEnumeratorButtonClick();
		EnumeratorCreationSmoke.editEnumeratorPageHeaderValidation();
		EnumeratorCreationSmoke.validateEnumeratorValues();
		EnumeratorCreationSmoke.editPageCancelClick();
		EnumeratorCreationSmoke.enumeratorPageHeaderValidation();
		EnumeratorCreationSmoke.switchoutFromIframe();
	}

	@Test
	public synchronized void rolesSmokeTest() throws Exception {
		Roles rolesSmoke = new Roles(driver);
		rolesSmoke.rolesLoadExcelData();
		rolesSmoke.settingsUsersClick();
		rolesSmoke.navigateToIframe();
		rolesSmoke.rolesClick();
		rolesSmoke.rolesPageHeaderValidation();
		rolesSmoke.editRolesButtonClick();
		rolesSmoke.editRolesPageHeaderValidation();
		rolesSmoke.validateRolesValues();
		rolesSmoke.editPageCancelClick();
		rolesSmoke.rolesPageHeaderValidation();
		rolesSmoke.switchoutFromIframe();
	}

	@Test
	public synchronized void programmesSmokeTest() throws Exception {
		Programmes ProgrammesSmoke = new Programmes(driver);

		ProgrammesSmoke.allProgrammesLoadExcelData();
		ProgrammesSmoke.settingsAllProgrammesClick();
		ProgrammesSmoke.allProgrammesClick();
		ProgrammesSmoke.allProgrammesPageHeaderValidation();
		ProgrammesSmoke.editAllProgrammesButtonClick();
		ProgrammesSmoke.editAllProgrammesPageHeaderValidation();
		ProgrammesSmoke.validateAllProgrammesValues();
		ProgrammesSmoke.editPageCancelClick();
		ProgrammesSmoke.allProgrammesPageHeaderValidation();

	}

	@Test
	public synchronized void partnersSmokeTest() throws Exception {
		Partners PartnersSmoke = new Partners(driver);

		PartnersSmoke.allPartnersLoadExcelData();
		PartnersSmoke.settingsAllPartnersClick();
		PartnersSmoke.allPartnersClick();
		PartnersSmoke.allPartnersPageHeaderValidation();
		PartnersSmoke.editAllPartnerButtonClick();
		PartnersSmoke.editAllPartnersPageHeaderValidation();
		PartnersSmoke.validateAllPartnersValues();
		PartnersSmoke.editPageCancelClick();
		PartnersSmoke.allPartnersPageHeaderValidation();

	}

	@Test
	public synchronized void productsSmokeTest() throws Exception {
		Products ProductsSmoke = new Products(driver);

		ProductsSmoke.allPartnersLoadExcelData();
		ProductsSmoke.settingsAllProductsClick();
		ProductsSmoke.allProductsClick();
		ProductsSmoke.allProductPageHeaderValidation();
		ProductsSmoke.editAllProductsButtonClick();
		ProductsSmoke.editAllProductsPageHeaderValidation();
		ProductsSmoke.validateAllProductsValues();
		ProductsSmoke.editPageCancelClick();
		ProductsSmoke.allProductPageHeaderValidation();

	}

	@Test
	public synchronized void countriesSmokeTest() throws Exception {
		Countries CountriesSmoke = new Countries(driver);
		CountriesSmoke.allCountryLoadExcelData();
		CountriesSmoke.settingsGeographicDataclick();
		CountriesSmoke.navigateToIframe();
		CountriesSmoke.allCountriesClick();
		CountriesSmoke.allCountriesPageHeaderValidation();
		CountriesSmoke.editAllCountriesButtonClick();
		CountriesSmoke.editAllCountriesPageHeaderValidation();
		CountriesSmoke.validateAllCountryValues();
		CountriesSmoke.editPageCancelClick();
		CountriesSmoke.allCountriesPageHeaderValidation();
		CountriesSmoke.switchoutFromIframe();

	}

	@Test
	public synchronized void regionsSmokeTest() throws Exception {
		Regions RegionsSmoke = new Regions(driver);
		RegionsSmoke.allRegionLoadExcelData();
		RegionsSmoke.settingsGeographicDataClick();
		RegionsSmoke.navigateToIframe();
		RegionsSmoke.allRegionClick();
		RegionsSmoke.allRegionsPageHeaderValidation();
		RegionsSmoke.editAllRegionButtonClick();
		RegionsSmoke.editAllRegionPageHeaderValidation();
		RegionsSmoke.validateAllRegionValues();
		RegionsSmoke.editPageCancelClick();
		RegionsSmoke.allRegionsPageHeaderValidation();
		RegionsSmoke.switchoutFromIframe();

	}

	@Test
	public synchronized void districtsSmokeTest() throws Exception {
		Districts DistictsSmoke = new Districts(driver);

		DistictsSmoke.allDistrictsLoadExcelData();
		DistictsSmoke.settingsGeographicDataclick();
		DistictsSmoke.switchIntoIframe();
		DistictsSmoke.allDistrictsClick();
		DistictsSmoke.allDistrictsPageHeaderValidation();
		DistictsSmoke.editAllDistrictsButtonClick();
		DistictsSmoke.editAllDistrictsPageHeaderValidation();
		DistictsSmoke.validateAllDistrictsValues();
		DistictsSmoke.editPageCancelClick();
		DistictsSmoke.allDistrictsPageHeaderValidation();
		DistictsSmoke.switchoutFromIframe();
	}

	@Test
	public synchronized void placesSmokeTest() throws Exception {
		Places PlacesSmoke = new Places(driver);
		PlacesSmoke.allPlacesLoadExcelData();
		PlacesSmoke.settingsGeographicDataClick();
		PlacesSmoke.switchIntoIframe();
		PlacesSmoke.allPlacesClick();
		PlacesSmoke.allPlacesPageHeaderValidation();
		PlacesSmoke.editAllPlacesButtonClick();
		PlacesSmoke.editAllPlacesPageHeaderValidation();
		PlacesSmoke.validateAllPlacesValues();
		PlacesSmoke.editPageCancelClick();
		PlacesSmoke.allPlacesPageHeaderValidation();
		PlacesSmoke.switchoutFromIframe();

	}

	@Test
	public synchronized void farmerGroupsSmokeTest() throws Exception {
		FarmerGroups FarmerGroupsSmoke = new FarmerGroups(driver);
		FarmerGroupsSmoke.allFarmerGroupsLoadExcelData();
		FarmerGroupsSmoke.settingsFarmerGroupsClick();
		FarmerGroupsSmoke.allFarmerGroupsClick();
		FarmerGroupsSmoke.allFarmerGroupsPageHeaderValidation();
		FarmerGroupsSmoke.editAllFarmerGroupsButtonClick();
		FarmerGroupsSmoke.editAllFarmerGroupsPageHeaderValidation();
		FarmerGroupsSmoke.validateAllFarmerGroupsValues();
		FarmerGroupsSmoke.editPageCancelClick();
		FarmerGroupsSmoke.allFarmerGroupsPageHeaderValidation();
	}

	@Test
	public synchronized void sectionsSmokeTest() throws Exception {
		Sections SectionsSmoke = new Sections(driver);
		SectionsSmoke.allSectionsLoadExcelData();
		SectionsSmoke.settingsFarmarGroupsClick();
		SectionsSmoke.allSectionsClick();
		SectionsSmoke.allSectionsPageHeaderValidation();
		SectionsSmoke.editAllPlacesButtonClick();
		SectionsSmoke.editAllPlacesPageHeaderValidation();
		SectionsSmoke.validateAllSectionsValues();
		SectionsSmoke.editPageCancelClick();
		SectionsSmoke.allSectionsPageHeaderValidation();
	}

	@Test
	public synchronized void molulesSmokeTest() throws Exception {
		Modules ModulesSmoke = new Modules(driver);
		ModulesSmoke.allModulesLoadExcelData();
		ModulesSmoke.settingsQuestionnaireDataClick();
		ModulesSmoke.allMolulesClick();
		ModulesSmoke.allModulesPageHeaderValidation();
		ModulesSmoke.editAllModulesButtonClick();
		ModulesSmoke.editAllModulesPageHeaderValidation();
		ModulesSmoke.validateAllModulesValues();
		ModulesSmoke.editPageCancelClick();
		ModulesSmoke.allModulesPageHeaderValidation();
	}

	@Test
	public synchronized void subMolulesSmokeTest() throws Exception {
		SubModules SubModulesSmoke = new SubModules(driver);
		SubModulesSmoke.allSubModulesLoadExcelData();
		SubModulesSmoke.settingsQuestionnaireDataClick();
		SubModulesSmoke.allSubMolulesClick();
		SubModulesSmoke.allSubModulesPageHeaderValidation();
		SubModulesSmoke.editSubAllModulesButtonClick();
		SubModulesSmoke.editAllSubModulesPageHeaderValidation();
		SubModulesSmoke.validateAllSubModulesValues();
		SubModulesSmoke.editPageCancelClick();
		SubModulesSmoke.allSubModulesPageHeaderValidation();
	}

	@Test
	public synchronized void moluleAssignmentsSmokeTest() throws Exception {
		ModulesAssignments ModulesAssignmentsSmoke = new ModulesAssignments(driver);
		ModulesAssignmentsSmoke.allMolulesAssignmentLoadExcelData();
		ModulesAssignmentsSmoke.settingsQuestionnaireDataClick();
		ModulesAssignmentsSmoke.allMolulesAssignmentsClick();
		ModulesAssignmentsSmoke.allModulesAssignmentsPageHeaderValidation();
		ModulesAssignmentsSmoke.editAllModulesAssignmentsButtonClick();
		ModulesAssignmentsSmoke.editAllModulesAssignmentsPageHeaderValidation();
		ModulesAssignmentsSmoke.validateAllModulesAssignmentsValues();
		ModulesAssignmentsSmoke.editPageCancelClick();
		ModulesAssignmentsSmoke.allModulesAssignmentsPageHeaderValidation();
	}

	@Test
	public synchronized void lookupValuesSmokeTest() throws Exception {
		LookupValues LookupValuesSmoke = new LookupValues(driver);
		LookupValuesSmoke.allLookupValuesLoadExcelData();
		LookupValuesSmoke.settingsQuestionnaireDataClick();
		LookupValuesSmoke.allLookupValuesClick();
		LookupValuesSmoke.allLookupValuesPageHeaderValidation();
		LookupValuesSmoke.editAllLookupValuesButtonClick();
		LookupValuesSmoke.editAllLookupValuesPageHeaderValidation();
		LookupValuesSmoke.validateAllLookupValues();
		LookupValuesSmoke.editPageCancelClick();
		LookupValuesSmoke.allLookupValuesPageHeaderValidation();

	}

	@Test
	public synchronized void completionCriteriaSmokeTest() throws Exception {
		CompletionCriteria CompletionCriteriaSmoke = new CompletionCriteria(driver);
		CompletionCriteriaSmoke.completionCriteriaLoadExcelData();
		CompletionCriteriaSmoke.settingsTrainingDataClick();
		CompletionCriteriaSmoke.completionCriteriaClick();
		CompletionCriteriaSmoke.completionCriteriaPageHeaderValidation();
		CompletionCriteriaSmoke.editCompletionCriteriaButtonClick();
		CompletionCriteriaSmoke.editCompletionCriteriaPageHeaderValidation();
		CompletionCriteriaSmoke.validateCompletionCriteriaValues();
		CompletionCriteriaSmoke.editPageCancelClick();
		CompletionCriteriaSmoke.completionCriteriaPageHeaderValidation();
	}

	@Test
	public synchronized void coursesSmokeTest() throws Exception {
		Courses CoursesSmoke = new Courses(driver);
		CoursesSmoke.coursesLoadExcelData();
		CoursesSmoke.settingsTrainingDataClick();
		CoursesSmoke.coursesClick();
		CoursesSmoke.coursesPageHeaderValidation();
		CoursesSmoke.editCoursesButtonClick();
		CoursesSmoke.editCoursesPageHeaderValidation();
		CoursesSmoke.validateCoursesValues();
		CoursesSmoke.editPageCancelClick();
		CoursesSmoke.coursesPageHeaderValidation();
	}

	@Test
	public synchronized void trainingModulesSmokeTest() throws Exception {
		TrainingModules TrainingModulesSmoke = new TrainingModules(driver);
		TrainingModulesSmoke.trainingModulesLoadExcelData();
		TrainingModulesSmoke.settingsTrainingDataClick();
		TrainingModulesSmoke.trainingModulesClick();
		TrainingModulesSmoke.trainingModulesPageHeaderValidation();
		TrainingModulesSmoke.editTrainingModulesButtonClick();
		TrainingModulesSmoke.editTrainingModulesPageHeaderValidation();
		TrainingModulesSmoke.validateTrainingModulesValues();
		TrainingModulesSmoke.editPageCancelClick();
		TrainingModulesSmoke.trainingModulesPageHeaderValidation();
	}

	@Test
	public synchronized void dimensionsSmokeTest() throws Exception {
		Dimensions DimensionsSmoke = new Dimensions(driver);
		DimensionsSmoke.allDimensionsLoadExcelData();
		DimensionsSmoke.settingsDimensionsDataClick();
		DimensionsSmoke.dimensionsClick();
		DimensionsSmoke.dimensionsPageHeaderValidation();
		DimensionsSmoke.editDimensionsButtonClick();
		DimensionsSmoke.editDimensionsPageHeaderValidation();
		DimensionsSmoke.validateDimensionsValues();
		DimensionsSmoke.editPageCancelClick();
		DimensionsSmoke.dimensionsPageHeaderValidation();
	}

	@Test
	public synchronized void dimensionsGroupsSmokeTest() throws Exception {
		DimensionsGroups DimensionsGroupsSmoke = new DimensionsGroups(driver);
		DimensionsGroupsSmoke.allDimensionsGroupsLoadExcelData();
		DimensionsGroupsSmoke.settingsDimensionsDataClick();
		DimensionsGroupsSmoke.dimensionsGroupsClick();
		DimensionsGroupsSmoke.dimensionsGroupsPageHeaderValidation();
		DimensionsGroupsSmoke.editDimensionsGroupsButtonClick();
		DimensionsGroupsSmoke.editDimensionsGroupsPageHeaderValidation();
		DimensionsGroupsSmoke.validateDimensionsGroupsValues();
		DimensionsGroupsSmoke.editPageCancelClick();
		DimensionsGroupsSmoke.dimensionsGroupsPageHeaderValidation();
	}

	// smoke FMP
	@Test
	public synchronized void farmerManagementPlanSmokeTest() throws Exception {
		FDP_Setting FarmerPlan = new FDP_Setting(driver);

		FarmerPlan.clickSetting();
		FarmerPlan.webElementClickButton("FarmDevelopmentPlan", "ClickFDPMenu");

		// clickTemplate
		FarmerPlan.clickButton("templates", "clicktemplate");
		FarmerPlan.verifyLabel("templatesLabel", "Template");
		FarmerPlan.clickButton("TemplatesEdit", "EditTemplates");
		FarmerPlan.verifyLabel("editTemplatesLabel", " Edit Template ");

		FarmerPlan.clickButton("canceltemplate", "Click Cancel templates");
		waitTill(2000);

		FarmerPlan.webElementClickButton("FarmDevelopmentPlan", "ClickFDPMenu");

		// calender Activity

		FarmerPlan.clickButton("calendar_activity", "click Calendar activity");
		FarmerPlan.verifyLabel("calendar_activity_label", "Calendar Activity");
		FarmerPlan.clickButton("EditCalender", "Edit Calendar activity");
		FarmerPlan.verifyLabel("Editcalendar_activity_label", "Edit Calendar Activity");
		FarmerPlan.clickButton("CancelButtonCalender", "Clicked Cancel Calendar");
		waitTill(2000);

		FarmerPlan.webElementClickButton("FarmDevelopmentPlan", "ClickFDPMenu");

		// Crop calender

		FarmerPlan.clickButton("cropcallendar", "click CropCalendar activity");
		FarmerPlan.verifyLabel("CropCalendar_label", "Crop Calendar");
		FarmerPlan.clickButton("EditcropCalender", "Edit CropCalendar activity");
		FarmerPlan.verifyLabel("EditCropCalendarlabel", "Edit Crop Calendar");
		FarmerPlan.clickButton("CancelButtoncropCalender", "Click Cancel CropCalendar");
		waitTill(2000);

		FarmerPlan.webElementClickButton("FarmDevelopmentPlan", "ClickFDPMenu");

		// Weighting

		FarmerPlan.clickButton("weighting", "click Weighting");
		FarmerPlan.verifyLabel("Weighting_label", "Weighting");
		FarmerPlan.clickButton("Editweighting", "Edit Weighting");
		FarmerPlan.verifyLabel("EditWeightingLabel", " Edit Weighting ");
		FarmerPlan.clickButton("CancelButtonweighting", "Click cancel Weighting");
		waitTill(2000);

		FarmerPlan.webElementClickButton("FarmDevelopmentPlan", "ClickFDPMenu");

		// Setting
		FarmerPlan.clickButton("settings", "click settings");
		FarmerPlan.clickButton("EditSetting", "Edit Setting");
		FarmerPlan.clickButton("CancelButtonSetting", "Click cancel Setting");
		waitTill(2000);

		FarmerPlan.webElementClickButton("FarmDevelopmentPlan", "ClickFDPMenu");
	}

	@Test
	public synchronized void socialInfrastructurePointSmokeTest() throws Exception {

		SocialInfrastructurePoint SocialInfrastructurePointSmoke = new SocialInfrastructurePoint(driver);
		SocialInfrastructurePointSmoke.socialInfraPointLoadExcelData();
		SocialInfrastructurePointSmoke.settingsSocialInfraPointClick();
		SocialInfrastructurePointSmoke.socialInfraPointPageHeaderValidation();
		SocialInfrastructurePointSmoke.validateSocialInfraPointValues();
	}

	@Test
	public synchronized void farmerOverviewSmokeTest() throws Exception {
		PomMenus Menus = new PomMenus();
		webElementClick(Menus.pomMenus("Menu_farmerOverview"), "Menu FarmerOverview");
		FarmerOverview FarmerOverviewPage = new FarmerOverview(driver);
		Thread.sleep(12000);
		FarmerOverviewPage.foWebListSearchAndCheckboxSelect("drp_main_FG", "txt_FG_search", "COOPYCA", "chk_FG_select");
		webElementClick(PomFarmerOverviewPage.pomFarmerOverview("btn_submit"), "Submit button");
		webAssertEqualsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("tab_overview"), "Overview", "Overview");
		webAssertEqualsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("tab_training"), "Training", "Training");
		webAssertEqualsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("tab_management"), "Management",
				"Management");
	}

	@Test
	public synchronized void questionsSmokeTest() throws Exception {
		Questions QuestionsSmoke = new Questions(driver);
		QuestionsSmoke.allQuestionsLoadExcelData();
		QuestionsSmoke.settingsAllQuestionsDataClick();
		QuestionsSmoke.allQuestionsClick();
		QuestionsSmoke.allQuestionsPageHeaderValidation();
		QuestionsSmoke.editAllQuestionsButtonClick();
		QuestionsSmoke.editAllQuestionsPageHeaderValidation();
		QuestionsSmoke.validateAllQuestionsValues();
		QuestionsSmoke.editPageCancelClick();
		QuestionsSmoke.allQuestionsPageHeaderValidation();
	}

	@Test
	public synchronized void permissionsSmokeTest() throws Exception {
		Permissions PermissionsSmoke = new Permissions(driver);
		PermissionsSmoke.permissionsLoadExcelData();
		PermissionsSmoke.settingsPermissionsClick();
		PermissionsSmoke.navigateToIframe();
		PermissionsSmoke.permissionsClick();
		PermissionsSmoke.permissionsPageHeaderValidation();
		PermissionsSmoke.validatePermissionsValues();
		PermissionsSmoke.switchoutFromIframe();
	}

	@Test
	public synchronized void tasksListSmokeTest() throws Exception {
		TasksList TasksListSmoke = new TasksList(driver);
		TasksListSmoke.tasksListLoadExcelData();
		TasksListSmoke.menuTasksClick();
		TasksListSmoke.thumbnailTasksListClick();
		TasksListSmoke.tasksListPageHeaderValidation();
		//TasksListSmoke.sortTasksListGridUsingTaskTextColumn();
		TasksListSmoke.validateTasksListValues();
	}

	@Test
	public synchronized void smsCampaignsSmokeTest() throws Exception {
		SMSCampaigns SMSCampaignsSmoke = new SMSCampaigns(driver);
		SMSCampaignsSmoke.smsCampaignsLoadExcelData();
		SMSCampaignsSmoke.menuTasksClick();
		SMSCampaignsSmoke.thumbnailSMSCampaignsClick();
		SMSCampaignsSmoke.smsCampaignsPageHeaderValidation();
		//SMSCampaignsSmoke.validateSMSCampaignsValues();
	}

	@Test
	public synchronized void analysisSmokeTest() throws Exception {
		Analysis AnalysisSmoke = new Analysis(driver);
		AnalysisSmoke.analysisLoadExcelData();
		AnalysisSmoke.analysisClick();
		AnalysisSmoke.analysisPageHeaderValidation();
		AnalysisSmoke.validateAnalysisValues();
	}

}
