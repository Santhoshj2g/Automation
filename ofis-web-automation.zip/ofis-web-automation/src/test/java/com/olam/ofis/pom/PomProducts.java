package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomProducts {

	public synchronized String pomProducts(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("txt_email", "id#email");
			hs.put("txt_password", "id#password");
			hs.put("check_Policy", "id#ofis-guest-policy-agreement");
			hs.put("btn_Submit", "id#ofis-guest-login-submit");
			hs.put("Menu_Settings", "xpath#//*[@routerlink='/settings']");
			hs.put("thumbnail_ppp", "xpath#//*[@routerlink='/progspartsproducts']");
			hs.put("thumbnail_product",
					"xpath#//*[@class='container-fluid ofis-core-body-container']/div/app-progspartsproducts/div/div/div/div[3]/a/div/div/p");
			hs.put("Productslc", "xpath#//*[@class='caption']//*[text()='All Products']");
			hs.put("Addproduct",
					"xpath#//html/body/app-root/app-landing-page/div[2]/div/app-product/div/div[1]/div[2]/a");
			hs.put("programmes", "xpath#//*[@id='programmes']");
			hs.put("addproduct", "xpath#//*[@class='btn btn-primary']");
			hs.put("editproduct", "xpath#//*[@class='btn btn-primary']");
			hs.put("testprod", "xpath#//*[@class='close']");
			hs.put("All", "xpath#//*[@class ='btn btn-default']");
			hs.put("edit", "xpath//*[@id=\"myGridLookup\"]/div/div[1]/div/div[3]/div[2]/div/div/div[1]/div[1]");

			hs.put("pageheader_product", "xpath#//*[@class='page-header']");

			// add product
			hs.put("txt_name", "id#name");
			hs.put("chk_active", "id#active");
			hs.put("txt_name_french", "id#name_fr");
			hs.put("txt_name_spanish", "id#name_es");
			hs.put("txt_name_indonesian", "id#name_id");
			hs.put("txt_name_portuguese", "id#name_pt");
			hs.put("txt_name_turkish", "id#name_tr");
			hs.put("txt_name_lao", "id#name_lo");
			hs.put("txt_name_vietnamese", "id#name_vi");
			hs.put("txt_name_thai", "id#name_th");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");

			// edit product
			hs.put("editproduct", "css#div[row-index='0'] div[col-id='0'] a");
			hs.put("pageheader_editproduct", "xpath#//*[@class='page-header']");
			hs.put("txt_productid", "id#id");

			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}

	}

}
