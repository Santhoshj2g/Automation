package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.pom.PomPermissions;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Permissions extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomPermissions pomPermissions = new PomPermissions();

	public Permissions(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderUserPermissions;
	private int expectedIndex;
	private String expectedFirstName;
	private String expectedLastName;

	public synchronized void permissionsLoadExcelData() throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/Permissions.xlsx");

		expectedPageHeaderUserPermissions = read.getCellData("PermissionsTC", "pageHeaderUserPermissions", 1);
		expectedIndex = read.getNumericCellData("PermissionsTC", "gridIndex", 1);
		expectedFirstName = read.getCellData("PermissionsTC", "gridFirstName", 1);
		expectedLastName = read.getCellData("PermissionsTC", "gridLastName", 1);
	}

	public synchronized void navigateToIframe() throws InterruptedException {

		Thread.sleep(1000);
		iFrameSwitchTo(pomPermissions.pomPermissions("iFrame_OFISUser"), "iFrame-OFISUser");

	}

	public synchronized void switchoutFromIframe() throws InterruptedException {

		Thread.sleep(1000);
		iFrameSwitchOut("iFrame-OFISUser");
	}
	public synchronized void settingsPermissionsClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_ofis-users"), "Settings->Ofis Users");
	}
	
	public synchronized void permissionsClick() throws InterruptedException {
		Thread.sleep(7000);
		webElementClick(pomPermissions.pomPermissions("thumbnailPermissions"), "thumbnail Permissions");
	}

	public synchronized void permissionsPageHeaderValidation() throws InterruptedException {
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(pomPermissions.pomPermissions("Header_PageHeader"),
				expectedPageHeaderUserPermissions, "PageHeader All Questions");
	}

	public synchronized void validatePermissionsValues() throws InterruptedException {
		Thread.sleep(5000);
		webAssertEqualsNumeric(pomPermissions.pomPermissions("grdIndex"), expectedIndex,
				"grid - Index");
		webAssertEqualsAlphaNumeric(pomPermissions.pomPermissions("grdFirstName"),
				expectedFirstName, "grid - First Name");
		webAssertEqualsAlphaNumeric(pomPermissions.pomPermissions("grdLastName"),
				expectedLastName, "grid - Last Name");
	}
}
