package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomQuestions {

	public synchronized String pomQuestions(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("thumbnailAllQuestions", "xpath#//*[@class='col-sm-6 col-md-4'][4]/a/div/div/p");
			hs.put("Header_PageHeader", "xpath#//*[@class='page-header']");

			// Add All Questions page
			hs.put("drpSubmodule", "id#submodule_id");
			hs.put("drpDataType", "id#datatype_id");
			hs.put("txtPosition", "id#position");
			hs.put("drpDisplayType", "id#display_type");
			hs.put("txtQuestion", "id#question");
			hs.put("txtDisplayConfiguration", "id#display_configuration");
			hs.put("txtStorageModel", "id#storage_model");
			hs.put("txtStorageColumn", "id#storage_column");
			hs.put("chkActiveQuestion", "id#active");

			hs.put("txtQuestionFr", "id#question_fr");
			hs.put("txtQuestionEs", "id#question_es");
			hs.put("txtQuestionId", "id#question_id");
			hs.put("txtQuestionPt", "id#question_pt");
			hs.put("txtQuestionTr", "id#question_tr");
			hs.put("txtQuestionLo", "id#question_lo");
			hs.put("txtQuestionVi", "id#question_vi");
			hs.put("txtQuestionTh", "id#question_th");
			
			// edit All Questions page
			hs.put("btnEditAllQuestions", "css#div[row-index='0'] div[col-id='0'] a");
			hs.put("headerEditAllQuestions", "xpath#//*[@class='page-header']");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");

			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
