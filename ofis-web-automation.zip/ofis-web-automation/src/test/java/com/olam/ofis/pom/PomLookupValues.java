package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomLookupValues {

	public synchronized String pomLookupValues(String locator) {
		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("thumbnailAllLookupValues", "xpath#//*[@class='col-sm-6 col-md-4'][5]/a/div/div");
			hs.put("Header_PageHeader", "xpath#//*[@class='page-header']");

			// Add all lookup values page
			hs.put("drpQuestionId", "id#question_id");
			hs.put("txtPosition", "id#position");
			hs.put("txtValue", "id#value");
			hs.put("txtRelatedImageOnApp", "id#photo");
			hs.put("chkActiveLookupValue", "xpath#//*[@class='form-group'][3]/div/input");

			hs.put("txtValueFr", "id#value_fr");
			hs.put("txtValueEs", "id#value_es");
			hs.put("txtValueId", "id#value_id");
			hs.put("txtValuePt", "id#value_pt");
			hs.put("txtValueTr", "id#value_tr");
			hs.put("txtValueLo", "id#value_lo");
			hs.put("txtValueVi", "id#value_vi");
			hs.put("txtValueTh", "id#value_th");

			// edit all lookup values page
			hs.put("btnEditLookupValues", "css#div[row-index='0'] div[col-id='0'] a");
			hs.put("headerEditLookupValues", "xpath#//*[@class='page-header']");
			hs.put("txtLookupValueID", "name#id");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");

			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
