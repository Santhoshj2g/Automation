package com.olam.ofis.wrappers;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Screen;
import org.testng.Assert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.olam.ofis.pom.JsonPomFarmerOverview;
import com.olam.ofis.pom.PomFarmerOverview;
import com.olam.ofis.pom.PomLogin;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.reports.ExtTestMngr;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Functions {
	PomLogin PomLogin = new PomLogin();
	PomMenus PomMenusPage = new PomMenus();
	PomFarmerOverview PomFarmerOverviewPage = new PomFarmerOverview();
	JsonPomFarmerOverview FoJsonKeys = new JsonPomFarmerOverview();
	public static Properties sysProperty = new Properties();
	public static Properties restApiEndPointsProperty = new Properties();
	public ArrayList<String> cellValues = new ArrayList<String>();

	public String elementValue = new String();
	public String parentWindowHandle;
	public int intVal;
	protected RemoteWebDriver driver;
	protected static String browserName = null;

	static {
		try {
			sysProperty.load(new FileInputStream(new File("./config/SystemConfig.properties")));
			restApiEndPointsProperty.load(new FileInputStream(new File("./config/RestApiEndPoints.properties")));
			browserName = sysProperty.getProperty("testBrowser");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public RemoteWebDriver getDriver() {
		return driver;
	}

	public synchronized void launchApplication(String appURL) throws InterruptedException {
		String urlToLaunch = null;
		String userCategory = null;
		try {
			userCategory = sysProperty.getProperty("userCategory");
			urlToLaunch = sysProperty.getProperty(appURL);

			if (browserName.equalsIgnoreCase("firefox")) {
				driver = new FirefoxDriver();
			} else if (browserName.equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver", "BrowserDrivers/chromedriver.exe");
				driver = new ChromeDriver();
			}
			driver.manage().window().maximize();
			driver.get(urlToLaunch);
			ExtTestMngr.reportStepPass("'" + browserName.toUpperCase() + "' Browser lauched with URL '" + urlToLaunch
					+ "' successfully. and logged in with User category : " + userCategory);

		} catch (WebDriverException e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "'Webdriver Exception : " + browserName.toUpperCase()
					+ "' Browser failed to launch with URL '" + urlToLaunch + "'. Exception is : " + e, true);

		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "'Webdriver Exception : " + browserName.toUpperCase()
					+ "' Browser failed to launch with URL '" + urlToLaunch + "'. Exception is : " + e, true);
		}
	}

	public synchronized void login() throws InterruptedException {
		String userCategory = null;
		try {
			userCategory = sysProperty.getProperty("userCategory");
			String username = "";
			String password = "";
			switch (userCategory.toLowerCase()) {
			case "admin": {
				username = sysProperty.getProperty("emailidAdmin");
				password = sysProperty.getProperty("passwordAdmin");
				break;
			}
			case "poweruser": {
				username = sysProperty.getProperty("emailidPowerUser");
				password = sysProperty.getProperty("passwordPowerUser");
				break;
			}
			case "user": {
				username = sysProperty.getProperty("emailidUser");
				password = sysProperty.getProperty("passwordUser");
				break;
			}
			}
			WebEditEnterText(PomLogin.pomLogin("txt_email"), username, "EmailID");
			WebEditEnterText(PomLogin.pomLogin("txt_password"), password, "Password");
			click(PomLogin.pomLogin("check_Policy"), "Policy Agreement");
			click(PomLogin.pomLogin("btn_Submit"), "Login Button");
			ExtTestMngr.reportStepPass("Application logged in successully with User category : " + userCategory);
		} catch (WebDriverException e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "'Webdriver  Exception is : " + e, true);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "Exception is : " + e, true);
			System.setProperty("webdriver.chrome.driver", "BrowserDrivers/chromedriver");
			driver = new ChromeDriver();
		}
	}

	public synchronized void logout() throws InterruptedException {
		try {
			webMainAndSubElementClick(PomLogin.pomLogin("drp_main_logout"), PomLogin.pomLogin("drp_sub_logout"),
					"OFIS-Logout");
			ExtTestMngr.reportStepPass("Application logout successully");
		} catch (WebDriverException e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "'Webdriver  Exception is : " + e, true);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "Exception is : " + e, true);
		}
	}

	public synchronized void WebEditEnterText(String locator, String testData, String fieldName) {
		
		try {
			Thread.sleep(500);
			selectByLocatorType(locator).clear();
			selectByLocatorType(locator).sendKeys(testData);
			ExtTestMngr.reportStepPass(
					"Text '" + testData + "' is entered successfully in the textbox '" + fieldName + "'");
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver,
					"Text '" + testData + "' was not entered in the textbox '" + fieldName + "'", true);
		}
	}

	public synchronized WebElement selectByLocatorType(String locator) {
		WebElement element = null;
		if (locator == null) {
			ExtTestMngr.reportStepFail(driver, "POM '" + locator + "' was not avaiable '", true);
			return null;
		}

		try {
			String locatorType = locator.split("#")[0];
			String locatorValue = locator.split("#")[1];

			String loc = locatorType;
			switch (loc.toLowerCase()) {
			case "id":
				element = driver.findElement(By.id(locatorValue));
				break;
			case "xpath":
				element = driver.findElement(By.xpath(locatorValue));
				break;
			case "css":
				element = driver.findElement(By.cssSelector(locatorValue));
				break;
			case "classname":
				element = driver.findElement(By.className(locatorValue));
				break;
			case "name":
				element = driver.findElement(By.name(locatorValue));
				break;
			case "linktext":
				element = driver.findElement(By.linkText(locatorValue));
				break;
			case "tagname":
				element = driver.findElement(By.tagName(locatorValue));
				break;
			case "partiallinktext":
				element = driver.findElement(By.partialLinkText(locatorValue));
				break;
			default:
				throw new IllegalArgumentException("Check the given locator Type in POM");
			}
		} catch (StaleElementReferenceException e) {
			ExtTestMngr.reportStepFail(driver, "POM '" + locator + "' was not avaiable'", true);
			return selectByLocatorType(locator);
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "POM '" + locator + "' was not avaiable'", true);
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "POM '" + locator + "' was not avaiable'", true);
			return null;
		}
		return element;
	}

	public synchronized List<WebElement> selectByLocatorTypeAllValues(String locator) {
		List<WebElement> elements = null;
		if (locator == null) {
			ExtTestMngr.reportStepFail(driver, "POM '" + locator + "' was not avaiable '", true);
			return null;
		}

		try {
			String locatorType = locator.split("#")[0];
			String locatorValue = locator.split("#")[1];

			String loc = locatorType;
			switch (loc.toLowerCase()) {
			case "id":
				elements = driver.findElements(By.id(locatorValue));
				break;
			case "xpath":
				elements = driver.findElements(By.xpath(locatorValue));
				break;
			case "xpathlist":
				elements = driver.findElements(By.xpath(locatorValue));
				break;
			case "css":
				elements = driver.findElements(By.cssSelector(locatorValue));
				break;
			case "classname":
				elements = driver.findElements(By.className(locatorValue));
				break;
			case "name":
				elements = driver.findElements(By.name(locatorValue));
				break;
			case "linktext":
				elements = driver.findElements(By.linkText(locatorValue));
				break;
			case "tagname":
				elements = driver.findElements(By.tagName(locatorValue));
				break;
			case "partiallinktext":
				elements = driver.findElements(By.partialLinkText(locatorValue));
				break;
			default:
				throw new IllegalArgumentException("Check the given locator Type in POM");
			}
		} catch (StaleElementReferenceException e) {
			ExtTestMngr.reportStepFail(driver, "POM '" + locator + "' was not avaiable 1'", true);
			return selectByLocatorTypeAllValues(locator);
		} catch (NoSuchElementException e) {
			ExtTestMngr.reportStepFail(driver, "POM '" + locator + "' was not avaiable 2'", true);
			return null;
		} catch (Exception e) {
			ExtTestMngr.reportStepFail(driver, "POM '" + locator + "' was not avaiable 3'", true);
			return null;
		}
		return elements;
	}

	public synchronized void webElementClick(String locator, String fieldName) {

		try {
			if (browserName.equalsIgnoreCase("firefox") || browserName.equalsIgnoreCase("ie")
					|| browserName.equalsIgnoreCase("chrome")) {
				WebElement element = selectByLocatorType(locator);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
				ExtTestMngr.reportStepPass("Field Name : '" + fieldName + "' is clicked successfully.");
			} else {
				WebElement element = selectByLocatorType(locator);
				element.click();
				ExtTestMngr.reportStepPass("Field Name : '" + fieldName + "' is clicked successfully.");
			}

		} catch (StaleElementReferenceException e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver,
					"button '" + fieldName + "' was not avaiable - StaleElementReferenceException '", true);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "button '" + fieldName + "' was not avaiable '", true);
		}
	}

	public synchronized void webElementExistValidation(String locator, String fieldName) {

		try {
			WebElement element = selectByLocatorType(locator);
			boolean isElementDisplayed = element.isDisplayed();

			if (isElementDisplayed == true) {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
				ExtTestMngr.reportStepPass("'" + fieldName + "' block is loaded successfully.");
			}
		} catch (StaleElementReferenceException e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver,
					"button '" + fieldName + "' was not avaiable - StaleElementReferenceException '", true);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "button '" + fieldName + "' was not avaiable '" + e.getMessage(),
					true);
		}
	}

	public synchronized void navigateToPopupAndClose(String elementPopupTitle) throws InterruptedException {
		try {
			WebElement element = selectByLocatorType(PomMenusPage.pomMenus(elementPopupTitle));
			String title = element.getText();
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", element);
			// For below code Sikuli was used in order to click close button
			Screen s = new Screen();
			if (s.exists("closeButton.png") != null) {
				s.find("closeButton.png").click();
				ExtTestMngr.reportStepPass("'" + title + "' popup closed successfully.");
			} else if (s.exists("closeButtonWhite.png") != null) {
				s.find("closeButtonWhite.png").click();
				ExtTestMngr.reportStepPass("'" + title + "' popup closed successfully.");
			} else {
				System.out.println("close button not exists");
			}
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "button  was not avaiable '", true);
		}
	}

	// Mouse hover on element and click
	public synchronized void webElementMouseHoverAndClick(String locator, String fieldName) {
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(selectByLocatorType(locator));
			actions.doubleClick().build().perform();
			ExtTestMngr.reportStepPass("Field Name : '" + fieldName + "' is clicked successfully.");
		} catch (StaleElementReferenceException e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver,
					"button '" + fieldName + "' was not avaiable - StaleElementReferenceException '", true);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "button '" + fieldName + "' was not avaiable '", true);
		}
	}

	// Abu Add click element
	public synchronized void click(String locator, String fieldName) {

		try {
			WebElement element = selectByLocatorType(locator);
			element.click();

			ExtTestMngr.reportStepPass("Field Name : '" + fieldName + "' is clicked successfully.");
		} catch (Exception e) {

			System.out.println("click() fail" + e.getMessage());
			ExtTestMngr.reportStepPass("Field Name : '" + fieldName + "' is clicked Failed.");

		}
	}

	public synchronized void webMainAndSubElementClick(String dropdownLocator, String dropdownItemLocator,
			String fieldName) {
		try {
			if (browserName.equalsIgnoreCase("firefox") || browserName.equalsIgnoreCase("ie")
					|| browserName.equalsIgnoreCase("chrome")) {
				WebElement mainelement = selectByLocatorType(dropdownLocator);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", mainelement);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", mainelement);
				Thread.sleep(200);
				WebElement subelement = selectByLocatorType(dropdownItemLocator);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", subelement);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", subelement);
				ExtTestMngr.reportStepPass("Field Name : '" + fieldName + "' is clicked successfully.");

			} else {
				WebElement mainelement = selectByLocatorType(dropdownLocator);
				mainelement.click();
				Thread.sleep(200);
				WebElement subelement = selectByLocatorType(dropdownItemLocator);
				subelement.click();
				ExtTestMngr.reportStepPass("Field Name : '" + fieldName + "' is clicked successfully.");
			}

		} catch (StaleElementReferenceException e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver,
					"button '" + fieldName + "' was not avaiable - StaleElementReferenceException '", true);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "button '" + fieldName + "' was not avaiable '", true);
		}
	}

	public synchronized boolean verifyWebCheckBoxIsSelected(String locator, String fieldName) {
		boolean selectedFlag=false;
		try {

			selectedFlag = selectByLocatorType(locator).isSelected();
			if (selectedFlag == true) {
				ExtTestMngr.reportStepPass("Field Name : '" + fieldName + " ' isSelected validation success");
			} else {
				ExtTestMngr.reportStepFail(driver,
						"Checkbox '" + fieldName + "' was not selected and isselected failed'", true);
			}
		} catch (StaleElementReferenceException e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver,
					"button '" + fieldName + "' was not avaiable - StaleElementReferenceException '", true);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "Button with text '" + fieldName + "' is not displayed.", true);
		}
		return selectedFlag;
	}

	public synchronized boolean verifyWebCheckBoxIsNotSelected(String locator, String fieldName) {
		boolean selectedFlag=false;
		try {

			selectedFlag = selectByLocatorType(locator).isSelected();
			if (selectedFlag == false) {
				ExtTestMngr.reportStepPass("Field Name : '" + fieldName + "' is not Selected validation success");
			} else {
				ExtTestMngr.reportStepFail(driver, "Checkbox '" + fieldName
						+ "' was selected hence checkbox is not selected validation failed'", true);
			}
		} catch (StaleElementReferenceException e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver,
					"button '" + fieldName + "' was not avaiable - StaleElementReferenceException '", true);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "button '" + fieldName + "' was not avaiable '", true);
		}
		return selectedFlag;
	}

	public synchronized boolean verifyWebTextBoxIsEmpty(String locator, String fieldName) {
		boolean selectedFlag=false;
		try {
			String elementvalue = webElementGetAttribute(locator, "value");

			selectedFlag= elementvalue.isEmpty();
			
			if (selectedFlag == true) {
				ExtTestMngr.reportStepPass("Field Name : '" + fieldName + " ' is Empty validation success");
			} else {

				ExtTestMngr.reportStepFail(driver,
						"Textbox '" + fieldName
								+ "' is not empty hence validation failed and value in the textbox is '" + elementvalue,
						true);
			}
		} catch (StaleElementReferenceException e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver,
					"textbox '" + fieldName + "' was not avaiable - StaleElementReferenceException '", true);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "textbox '" + fieldName + "' was not avaiable '", true);
		}
		return selectedFlag;
	}

	public synchronized void iFrameSwitchTo(String locator, String fieldName) {
		try {

			WebElement element = selectByLocatorType(locator);
			driver.switchTo().frame(element);
			ExtTestMngr.reportStepPass("Switching to iFrame Name : '" + fieldName + "' is  successfull.");

		} catch (StaleElementReferenceException e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver,
					"iFrame '" + fieldName + "' was not avaiable - StaleElementReferenceException '", true);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "iFrame '" + fieldName + "' was not avaiable '", true);
		}
	}

	public synchronized void iFrameSwitchOut(String fieldName) {
		try {
			driver.switchTo().defaultContent();

			ExtTestMngr.reportStepPass("Switching out from iFrame Name : '" + fieldName + "' is  successfull.");

		} catch (StaleElementReferenceException e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver,
					"iFrame '" + fieldName + "' was not avaiable - StaleElementReferenceException '", true);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "iFrame '" + fieldName + "' was not avaiable '", true);
		}
	}

	public synchronized void webListSelectSingleItemByText(String locator, String testData, String fieldName) {
				try {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

			new Select(selectByLocatorType(locator)).deselectAll();
			new Select(selectByLocatorType(locator)).selectByVisibleText(testData);
			ExtTestMngr.reportStepPass("Drop Down list : '" + fieldName + "' is selected");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver, "Element '" + fieldName + "' was not avaiable '", true);
		}
		

	}

	public synchronized void webDropdownSelect(String locator, String testData, String fieldName) {
			try {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			new Select(selectByLocatorType(locator)).selectByVisibleText(testData);
			ExtTestMngr.reportStepPass(
					"Field Name : '" + fieldName + " and value selected dropdown is : '" + testData + "'");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver, "Element '" + fieldName + "' was not avaiable '", true);
		}
		

	}

	// abu method for sleep
	public synchronized void waitTill(int time) {

		try {
			Thread.sleep(time);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public synchronized void webListAndCheckboxSelect(String dropdownLocator, String dropdownItemLocator,
			String fieldName) {

		String testDataUI;
		try {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			// Create object 'action' of an Actions class
			Actions actions = new Actions(driver);
			// To mouseover on main menu
			actions.moveToElement(selectByLocatorType(dropdownLocator)).click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			// To mouseover on sub menu
			actions.moveToElement(selectByLocatorType(dropdownItemLocator));
			actions.click().build().perform();
			testDataUI = selectByLocatorType(dropdownItemLocator).getText().toString();
			actions.moveToElement(selectByLocatorType(dropdownLocator)).click().build().perform();
			ExtTestMngr
					.reportStepPass("Field Name : " + fieldName + " Value selected in dropdown is : " + testDataUI);
			

		} catch (Exception e) {
			System.out.println(e.getMessage());
			ExtTestMngr
					.reportStepFail(driver,
							"Field Name: " + fieldName + "Main Element DropDown->Checkbox : '" + dropdownLocator
									+ "  Sub Element DropDown->Checkbox : '" + dropdownItemLocator + "' was not avaiable '",
							true);
		}
		
	}

	public synchronized void webListSelectAndClick(String dropdownLocator, String dropdownItemLocator,
			String fieldName) {

		String mainElement, subElement;
		mainElement = selectByLocatorType(dropdownLocator).getText().toString();

		try {

			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			Actions actions = new Actions(driver);
			actions.moveToElement(selectByLocatorType(dropdownLocator)).click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			actions.moveToElement(selectByLocatorType(dropdownItemLocator));
			subElement = selectByLocatorType(dropdownItemLocator).getText().toString();
			actions.click().build().perform();
			ExtTestMngr.reportStepPass("Field Name : '" + fieldName + "' Main Element DropDown->Checkbox : '"
					+ mainElement + "' sub Element DropDown and Clicked: '" + subElement);
			

		} catch (Exception e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver, "Field Name: " + fieldName + "Element DropDown is clicked '"
					+ mainElement + "' was not avaiable '", true);
		}
		

	}

	public synchronized void webListSearchAndCheckboxSelect(String locatorDropdown, String searchBoxLocator,
			String textToSearch, String searchResultLocator) {

		String dropdownselected;
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(selectByLocatorType(locatorDropdown)).click();
			dropdownselected = selectByLocatorType(locatorDropdown).getText();
			actions.moveToElement(selectByLocatorType(searchBoxLocator)).click();
			actions.sendKeys(textToSearch).perform();
			actions.moveToElement(selectByLocatorType(searchResultLocator)).click();
			actions.moveToElement(selectByLocatorType(locatorDropdown)).click().build().perform();
			ExtTestMngr.reportStepPass("In '" + dropdownselected + "' dropdown, Value '" + textToSearch + "' is selected");

		} catch (Exception e) {
			System.out.println(e.getMessage());

			ExtTestMngr.reportStepFail(driver, "Main Element DropDown->Checkbox : '" + locatorDropdown
					+ "  Sub Element DropDown->Checkbox : '" + searchBoxLocator + "' was not avaiable '", true);
		}
	}

	public synchronized void webListSearchAndUncheckboxSelect(String locatorDropdown, String searchBoxLocator,
			String textToSearch, String searchResultLocator, String unSelectAllLocator) {

		String dropdownselected;
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(selectByLocatorType(locatorDropdown)).click();
			actions.moveToElement(selectByLocatorType(unSelectAllLocator)).click();
			dropdownselected = selectByLocatorType(locatorDropdown).getText();
			actions.moveToElement(selectByLocatorType(searchBoxLocator)).click();
			actions.sendKeys(textToSearch).perform();
			actions.moveToElement(selectByLocatorType(searchResultLocator)).click();
			actions.moveToElement(selectByLocatorType(locatorDropdown)).click().build().perform();
			ExtTestMngr.reportStepPass("In '" + dropdownselected + "' dropdown, Value '" + textToSearch + "' is selected");

		} catch (Exception e) {
			System.out.println(e.getMessage());

			ExtTestMngr.reportStepFail(driver, "Main Element DropDown->Checkbox : '" + locatorDropdown
					+ "  Sub Element DropDown->Checkbox : '" + searchBoxLocator + "' was not avaiable '", true);
		}
	}

	public synchronized void webDropdownClickAndCheckNonEmpty(String locatorDropdown, String searchBoxLocator,
			String value, String fieldName) {

		WebElement rawDropdownSubElement;
		String dropdownSubElement;
		Actions actions = new Actions(driver);
		try {

			actions.moveToElement(selectByLocatorType(locatorDropdown)).click().build().perform();
			Thread.sleep(3000);
			rawDropdownSubElement = selectByLocatorType(searchBoxLocator);
			System.out.println("Sub element dropdownSubElement " + rawDropdownSubElement);

			if (rawDropdownSubElement != null) {
				dropdownSubElement = selectByLocatorType(searchBoxLocator).getText();
				String dropdownSubElement2 = dropdownSubElement.trim();
				System.out.println("Sub element dropdownselected " + rawDropdownSubElement);
				if (dropdownSubElement2.equals(value)) {
					ExtTestMngr.reportStepFail(driver,
							"'" + fieldName + "' dropdown valid values are not loaded and loaded value is '"
									+ dropdownSubElement2 + "'",
							true);
				} else {
					ExtTestMngr.reportStepPass("'" + fieldName
							+ "' dropdown valid values are loaded and loaded value is '" + dropdownSubElement2 + "'");
				}
			} else {
				ExtTestMngr.reportStepFail(driver, "DropDown Sub Element is not loaded due to null pointer Exception.",
						true);
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver, "Main Element DropDown->Checkbox : '" + locatorDropdown
					+ "  Sub Element DropDown->Checkbox : '" + searchBoxLocator + "' was not avaiable '", true);
		}
		actions.moveToElement(selectByLocatorType(locatorDropdown)).click().build().perform();
	}

	public synchronized void checkBoxSelect(String getElement) {
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(selectByLocatorType(getElement)).click();
			actions.build().perform();
			ExtTestMngr.reportStepPass("Check box is selected");

		} catch (Exception e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver, "Checkbox selection faileds", true);
		}
	}

	public synchronized void webDynamicDropdownClickAndSelectItemByText(String locatorDropdown, String searchBoxLocator,
			String fieldName) {
		String testDataUI;
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(selectByLocatorType(locatorDropdown));
			actions.click().build().perform();
			actions.moveToElement(selectByLocatorType(searchBoxLocator));
			testDataUI = selectByLocatorType(searchBoxLocator).getText();
			actions.click().build().perform();
			ExtTestMngr.reportStepPass(
					"Field Name : '" + fieldName + "' and Value selected in dropdown is : '" + testDataUI + "'");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ExtTestMngr
					.reportStepFail(driver,
							"Field Name: " + fieldName + "Main Element DropDown->Checkbox : '" + locatorDropdown
									+ "  Sub Element DropDown->Checkbox : '" + searchBoxLocator + "' was not avaiable '",
							true);
		}
		
	}

	public synchronized void webDynamicDropdownClickAndSelectAllItems(String locatorDropdown, String searchBoxLocator,
			String fieldName) {
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(selectByLocatorType(locatorDropdown));
			actions.click().build().perform();
			List<WebElement> myListToCheck = selectByLocatorTypeAllValues(searchBoxLocator);
			int dropdownsize = myListToCheck.size();
			System.out.println("dropdown size" + dropdownsize);

			for (int i = 0; i < dropdownsize; i++) {
				System.out.println("dropdown size " + dropdownsize + "print i value " + i);

				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				actions.moveToElement(selectByLocatorType(locatorDropdown));
				actions.click().build().perform();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				actions.moveToElement(myListToCheck.get(dropdownsize)).click().build().perform();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				dropdownsize--;
			}
			

		} catch (Exception e) {
			System.out.println(e.getMessage());
			ExtTestMngr
					.reportStepFail(driver,
							"Field Name: " + fieldName + "Main Element DropDown->Checkbox : '" + locatorDropdown
									+ "  Sub Element DropDown->Checkbox : '" + searchBoxLocator + "' was not avaiable '",
							true);
		}
		

	}

	public synchronized void webAssertEqualsNumeric(String locator, int expectedValue, String fiendName) {
		String testDataUI = null;
		String numericPartUI = null;
		String testDataExcel;
		WebElement element;

		try {
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			testDataUI = selectByLocatorType(locator).getText();
			Pattern pattern = Pattern.compile("([-]?\\d+(?:\\.\\d+)?)");
			Matcher matcher = pattern.matcher(testDataUI);
			while (matcher.find()) {
				numericPartUI = matcher.group(1);
			}

			Double testDataExcel2 = Double.valueOf(expectedValue);
			DecimalFormat df = new DecimalFormat("#.####");
			testDataExcel = df.format(testDataExcel2);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			element = selectByLocatorType(locator);
			js.executeScript("arguments[0].scrollIntoView();", element);

			try {
				Assert.assertEquals(numericPartUI, testDataExcel);
				ExtTestMngr.reportStepPass(
						"Field Name : '" + fiendName + "' and its value validation success. Expected Test Data : '"
								+ testDataExcel + "\n" + "' Vs Actual UI Data : '" + numericPartUI + "'");
			} catch (AssertionError e) {
				System.out.println(e.getMessage());
				ExtTestMngr.reportStepFail(driver,
						"Test is Failed due to data mismatch. Field Name is '" + fiendName + "' " + e.getMessage(),
						true);
			}

		} catch (Exception e) {
		}
		
	}

	public synchronized void webGetAttributeValueAndAssertEqualsNumeric(String locator, int testData,
			String fieldName) {
		String testDataUI = null;
		String numericPartUI = null;
		String testDataExcel;
		WebElement element;
		testDataUI = webElementGetAttribute(locator, "value");

		try {
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			Pattern pattern = Pattern.compile("([-]?\\d+(?:\\.\\d+)?)");
			Matcher matcher = pattern.matcher(testDataUI);
			while (matcher.find()) {
				numericPartUI = matcher.group(1);
			}
			Double testDataExcel2 = Double.valueOf(testData);
			DecimalFormat df = new DecimalFormat("#.####");
			testDataExcel = df.format(testDataExcel2);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			element = selectByLocatorType(locator);
			js.executeScript("arguments[0].scrollIntoView();", element);

			try {
				Assert.assertEquals(numericPartUI, testDataExcel);
				ExtTestMngr.reportStepPass(
						"Field Name : " + fieldName + " and its value validation success. Expected Test Data : "
								+ testDataExcel + "\n" + " Vs Actual UI Data : " + numericPartUI + "'");
			} catch (AssertionError e) {
				System.out.println(e.getMessage());
				ExtTestMngr.reportStepFail(driver,
						"Test is Failed due to data mismatch. Field Name is '" + fieldName + "' " + e.getMessage(),
						true);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

	public synchronized void webGetAttributeValueAndAssertEqualsAlphaNumeric(String locator, String testData,
			String fieldName) {

		WebElement element;
		String testDataUI = webElementGetAttribute(locator, "value");

		try {

			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			element = selectByLocatorType(locator);
			js.executeScript("arguments[0].scrollIntoView();", element);

			try {
				Assert.assertEquals(testDataUI.trim(), testData);
				ExtTestMngr.reportStepPass(
						"Field Name : " + fieldName + " value comparision success. Expected Test Data : '" + testData
								+ "\n" + "' Vs Actual UI Data : '" + testDataUI + "'");
			} catch (AssertionError e) {
				System.out.println(e.getMessage());
				ExtTestMngr.reportStepFail(driver,
						"Test is Failed due to data mismatch. Field Name is '" + fieldName + "' " + e.getMessage(),
						true);
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	}

	public synchronized void webAssertEqualsNumeric(String locator, String testData, String fieldName) {

		String testDataUI = null;
		String numericPartUI = null;
		String testDataExcel;
		WebElement element;

		try {
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			testDataUI = selectByLocatorType(locator).getText();
			System.out.println("test data data" + testDataUI);
			Pattern pattern = Pattern.compile("([-]?\\d+(?:\\.\\d+)?)");
			Matcher matcher = pattern.matcher(testDataUI);

			while (matcher.find()) {
				System.out.println(matcher.group(1));
				numericPartUI = matcher.group(1);
			}

			System.out.println("1st pattern numeric part" + numericPartUI);

			Double testDataExcel2 = Double.valueOf(testData);
			DecimalFormat df = new DecimalFormat("#.####");

			testDataExcel = df.format(testDataExcel2);

			JavascriptExecutor js = (JavascriptExecutor) driver;
			element = selectByLocatorType(locator);
			js.executeScript("arguments[0].scrollIntoView();", element);

			try {
				Assert.assertEquals(numericPartUI, testDataExcel);
				ExtTestMngr.reportStepPassScreenShot(driver,
						"Field Name : " + fieldName + " and its value validation success. Expected Test Data : "
								+ testDataExcel + "\n" + " Vs Actual UI Data : " + numericPartUI,
						true);
			} catch (AssertionError e) {
				System.out.println(e.getMessage());

				ExtTestMngr.reportStepFail(driver,
						"Test is Failed due to data mismatch. Field Name is '" + fieldName + "' " + e.getMessage(),
						true);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

	public synchronized void webAssertEqualsAlphaNumeric(String locator, String expectedValue,
			String fieldName) {
		String testDataExcel;
		WebElement element;

		try {

			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			String testDataUI = selectByLocatorType(locator).getText();
			testDataExcel = expectedValue;
			JavascriptExecutor js = (JavascriptExecutor) driver;
			element = selectByLocatorType(locator);
			js.executeScript("arguments[0].scrollIntoView();", element);

			try {
				Assert.assertEquals(testDataUI.trim(), testDataExcel);
				ExtTestMngr.reportStepPass(
						"Field Name : " + fieldName + " value comparision success. Expected Test Data : '"
								+ testDataExcel + "\n" + "' Vs Actual UI Data : '" + testDataUI + "'");
			} catch (AssertionError e) {
				System.out.println(e.getMessage());
				ExtTestMngr.reportStepFail(driver,
						"Test is Failed due to data mismatch. Field Name is '" + fieldName + "' " + e.getMessage(),
						true);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

	// Below method variable 'returnStrElementValue' value retrieved from
	// getTextFromWebElementBySplitPrefixAndSuffix method
	public synchronized void assertStringContainsAlphaNumeric(String locator, String fieldName) {

		WebElement element;

		try {

			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			String testDataUI = selectByLocatorType(locator).getText().trim();

			JavascriptExecutor js = (JavascriptExecutor) driver;
			element = selectByLocatorType(locator);
			js.executeScript("arguments[0].scrollIntoView();", element);

			try {

				if (testDataUI.contains(elementValue) == true || elementValue.contains(testDataUI) == true) {
					// Assert.assertEquals(testDataUI.trim(), previousIUtestData);
					ExtTestMngr.reportStepPass(
							"Field Name : " + fieldName + " value comparision success. Expected Test Data : '"
									+ elementValue + "' Vs Actual UI Data : '" + testDataUI + "'");
				}else {
					ExtTestMngr.reportStepFail(driver,
							"Test is Failed due to data mismatch. Field Name is '" + fieldName
									+ "'Expected Test Data : '" + elementValue + "' Vs Actual UI Data : '" + testDataUI + "'",
							true);
				}
			} catch (AssertionError e) {
				System.out.println(e.getMessage());
				ExtTestMngr.reportStepFail(driver,
						"Test is Failed due to data mismatch. Field Name is '" + fieldName + "' " + e.getMessage(),
						true);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

	public synchronized void assertStringContainsAlphaNumeric(String locator, String testData,
			String fieldName) {

		WebElement element;

		try {

			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			String testDataUI = selectByLocatorType(locator).getText().trim();

			JavascriptExecutor js = (JavascriptExecutor) driver;
			element = selectByLocatorType(locator);
			js.executeScript("arguments[0].scrollIntoView();", element);

			try {

				if (testDataUI.contains(testData) == true) {
					// Assert.assertEquals(testDataUI.trim(), previousIUtestData);
					ExtTestMngr.reportStepPass(
							"Field Name : " + fieldName + " value comparision success. Expected Test Data : '"
									+ testData + "\n" + "' Vs Actual UI Data : '" + testDataUI + "'");
				} else {
					ExtTestMngr.reportStepFail(driver,
							"Test is Failed due to data mismatch. Field Name is '" + fieldName
									+ "'Expected Test Data : '" + testData + "\n" + "' Vs Actual UI Data : '"
									+ testDataUI + "'",
							true);
				}
			} catch (AssertionError e) {
				System.out.println(e.getMessage());
				ExtTestMngr.reportStepFail(driver,
						"Test is Failed due to data mismatch. Field Name is '" + fieldName + "' " + e.getMessage(),
						true);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

	public synchronized void webGetSelectedValueFromDropdownAndAssertAlphaNumeric(String locator,
			String testData, String fieldName) {

		String selectedvalue = "";
		WebElement element;
		try {

			Select select = new Select(selectByLocatorType(locator));
			WebElement option = select.getFirstSelectedOption();
			selectedvalue = option.getText();

			JavascriptExecutor js = (JavascriptExecutor) driver;
			element = selectByLocatorType(locator);
			js.executeScript("arguments[0].scrollIntoView();", element);

			try {
				Assert.assertEquals(selectedvalue.trim(), testData);
				ExtTestMngr.reportStepPass(
						"Field Name : " + fieldName + " selected value comparision success. Expected Test Data : '"
								+ testData + "\n" + "' Vs Actual UI Data : '" + selectedvalue + "'");
			} catch (AssertionError e) {
				System.out.println(e.getMessage());
				ExtTestMngr.reportStepFail(driver,
						"Test is Failed due to data mismatch. Field Name is '" + fieldName + "' " + e.getMessage(),
						true);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

	private synchronized String getRestAPIAccessToken() {
		String accessToken = "";
		try {
			String restAPIbaseURIPrefix = sysProperty.getProperty("RestAPIbaseURIPrefix");
			String restApiAuthToken = restApiEndPointsProperty.getProperty("restAuthToken");
			String requestAuthTokenURI = restAPIbaseURIPrefix + restApiAuthToken;

			RestAssured.baseURI = requestAuthTokenURI;
			RequestSpecification request = RestAssured.given();
			request.header("Content-Type", "application/json");
			request.header("App-Id", "1");

			String userName = sysProperty.getProperty("emailidAdmin");
			String passwordAdmin = sysProperty.getProperty("passwordAdmin");

			JSONObject requestParams = new JSONObject();
			requestParams.put("username", userName);
			requestParams.put("password", passwordAdmin);
			requestParams.put("userDetailsRequired", "true");
			requestParams.put("language", "en");

			request.body(requestParams.toString());
			Response response = request.post("/authenticate");

			int statusCode = response.getStatusCode();
			int respstatusCode = response.getStatusCode();

			if (statusCode == 200) {
				JsonPath jsonPathEvaluator = response.jsonPath();
				String restApiAccessToken = jsonPathEvaluator.get("access_token").toString();
				String restApiTokenType = jsonPathEvaluator.get("token_type").toString();
				accessToken = restApiTokenType.concat(" ").concat(restApiAccessToken);
			} else {
				ExtTestMngr.reportStepFail(driver, "API request failed and the Response status code is '"
						+ respstatusCode + "' and Response message is " + response.print(), false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "Test is Failed due to Exception " + e.getMessage(), false);
		}

		return accessToken;
	}

	private Headers createApiHeadersList() {
		List<Header> headerslist = new ArrayList<Header>();
		headerslist.add(new Header("Content-Type", "application/json"));
		headerslist.add(new Header("App-ID", "1"));
		String accessToken = getRestAPIAccessToken();
		headerslist.add(new Header("Authorization", accessToken));
		Headers headers = new Headers(headerslist);
		return headers;
	}

	public String getApiUrl(String rawEndPoint) {
		String apiUrl = null;
		try {
			String restAPIbaseURIPrefix = sysProperty.getProperty("RestAPIbaseURIPrefix");
			String endPoint = restApiEndPointsProperty.getProperty(rawEndPoint);
			apiUrl = restAPIbaseURIPrefix + endPoint;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return apiUrl;
	}

	public String getApiUrl(String rawEndPoint, String suffix) {
		String apiUrl = null;
		try {
			String restAPIbaseURIPrefix = sysProperty.getProperty("RestAPIbaseURIPrefix");
			String endPoint = restApiEndPointsProperty.getProperty(rawEndPoint);
			apiUrl = restAPIbaseURIPrefix + endPoint + suffix;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return apiUrl;
	}

	public Response getWithHeaders(String apiUrl) {
		Headers headers = createApiHeadersList();
		Response response = null;
		int responseCode = 0;
		try {
			RequestSpecification request = RestAssured.given();
			request.given().headers(headers);
			response = request.get(apiUrl).then().extract().response();
			responseCode = response.getStatusCode();
			if (responseCode == 200) {
				response = request.get(apiUrl).then().extract().response();
				ExtTestMngr.reportStepPass("Validating API End point is '" + apiUrl
						+ "' and response status code is : '" + responseCode + "'");
			}else {
				ExtTestMngr.reportStepFail(driver, "Validating API End Point is '" + apiUrl
						+ "' and API Response status code is : '" + responseCode + "' ", true);
			}
		} catch (Exception e) {
			ExtTestMngr.reportStepFail(driver, "Validating API End Point is '" + apiUrl
					+ "' and API Response status code is : '" + responseCode + "' " + e.getMessage(), true);
			e.printStackTrace();
		}
		return response;
	}

	public Response postWithHeaders(String rawEndPoint, String jsonFileName) {
		Headers headers = createApiHeadersList();
		String restAPIbaseURIPrefix = sysProperty.getProperty("RestAPIbaseURIPrefix");
		String jsonFilePath = sysProperty.getProperty("RestApiJsonFilePath");
		String endPoint = restApiEndPointsProperty.getProperty(rawEndPoint);
		String apiUrl = restAPIbaseURIPrefix + endPoint;
		String jsonFile = jsonFilePath + jsonFileName;
		Response response = null;
		String jsonBody = null;
		int responseCode = 0;
		try {
			jsonBody = loadJSON(jsonFile);
			RequestSpecification request = RestAssured.given();
			request.given().headers(headers).body(jsonBody);
			response = request.post(apiUrl).then().extract().response();
			responseCode = response.getStatusCode();
			ExtTestMngr.reportStepPass("Validating API End point is '" + apiUrl + "' and response status code is : '"
					+ responseCode + "'");
		} catch (Exception e) {
			ExtTestMngr.reportStepFail(driver, "Validating API End Point is '" + apiUrl
					+ "and API Response status code is : '" + responseCode + "' " + e.getMessage(), true);
			e.printStackTrace();
		}
		return response;
	}

	public Response postWithJsonObject(String rawEndPoint, JSONObject jsonObject) {
		Headers headers = createApiHeadersList();
		String restAPIbaseURIPrefix = sysProperty.getProperty("RestAPIbaseURIPrefix");
		String endPoint = restApiEndPointsProperty.getProperty(rawEndPoint);
		String apiUrl = restAPIbaseURIPrefix + endPoint;
		Response response = null;
		int responseCode = 0;
		try {
			RequestSpecification request = RestAssured.given();
			request.given().headers(headers).body(jsonObject.toString());
			response = request.post(apiUrl).then().extract().response();
			responseCode = response.getStatusCode();
			ExtTestMngr.reportStepPass("Validating API End point is '" + apiUrl + "' and response status code is : '"
					+ responseCode + "'");
		} catch (Exception e) {
			ExtTestMngr.reportStepFail(driver, "Validating API End Point is '" + apiUrl
					+ "and API Response status code is : '" + responseCode + "' " + e.getMessage(), true);
			e.printStackTrace();
		}
		return response;
	}

	public synchronized int getNumericValueFromApiReponse(Response response, String jsonKey) {
		try {
			JsonPath jsonPathEvaluator = response.jsonPath();
			intVal = jsonPathEvaluator.get(jsonKey);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver,
					"Test is Failed while fetching integer value from API response and fetched json value " + intVal
							+ e.getMessage(),
					true);
		}
		return intVal;
	}

	public synchronized Float getFloatValueFromApiReponse(Response response, String jsonKey) {

		Float value = (float) 0;
		try {
			JsonPath jsonPathEvaluator = response.jsonPath();
			value = jsonPathEvaluator.get(jsonKey);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver,
					"Test is Failed while fetching integer value from API response and fetched json value " + intVal
							+ e.getMessage(),
					true);
		}
		return value;
	}

	public synchronized void assertApiUiNumeric(Response response, String jsonKey, String uiValue, String fieldName) {

		String testDataUI = selectByLocatorType(uiValue).getText();
		JsonPath jsonPathEvaluator = response.jsonPath();
		Object getVal, convertedTestDataUI;
		try {

			WebElement element = selectByLocatorType(uiValue);
			Actions actions = new Actions(driver);
			actions.moveToElement(element);
			actions.perform();

			Object vals = jsonPathEvaluator.get(jsonKey);
			String type = ((Object) vals).getClass().getName();

			boolean comparisonStatus = false;

			if (type.contains("Integer")) {
				getVal = (int) jsonPathEvaluator.get(jsonKey);
				convertedTestDataUI = Integer.parseInt(testDataUI);
				comparisonStatus = getVal.equals(convertedTestDataUI);
			} else if (type.contains("Float")) {
				getVal = (float) jsonPathEvaluator.get(jsonKey);
				convertedTestDataUI = Float.parseFloat(testDataUI);
				comparisonStatus = getVal.equals(convertedTestDataUI);

			} else {
				ExtTestMngr.reportStepFail(driver,
						"Test has been failed due to data mismatch in the field '" + fieldName + "' Field type" + type,
						true);
			}
			getVal = jsonPathEvaluator.get(jsonKey);
			if (comparisonStatus == true) {
				ExtTestMngr.reportStepPass(
						"Field Name : '" + fieldName + "' value contains validation success. Expected Data : '" + getVal
								+ "' Vs Actual UI Data : '" + testDataUI + "'");
			} else {
				ExtTestMngr.reportStepFail(driver, "Test is Failed for Field Name is '" + fieldName
						+ "' due to data mismatch. UI Data '" + testDataUI + "' and Api Response '" + getVal + "'",
						true);
			}

		} catch (AssertionError e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver, "Test is Failed for Field Name is '" + fieldName
					+ "' due to test data mismatch and " + e.getMessage(), true);
		}

	}

	public synchronized void assertApiNumericUiString(Response response, String jsonKey, String uiValue,
			String fieldName, int compareNumeric, String EqualantString) {

		String testDataUI = selectByLocatorType(uiValue).getText();
		JsonPath jsonPathEvaluator = response.jsonPath();
		try {
			int getVal = jsonPathEvaluator.get(jsonKey);
			if (getVal == compareNumeric) {

				WebElement element = selectByLocatorType(uiValue);
				Actions actions = new Actions(driver);
				actions.moveToElement(element).perform();

				Assert.assertEquals(EqualantString, testDataUI);
				ExtTestMngr.reportStepPass("Field Name '" + fieldName
						+ "' -> Comparing UI with API validation is success. Expected UI Data : '" + testDataUI
						+ "' Vs Actual API response  : '" + EqualantString + "'");
			} else {
				ExtTestMngr.reportStepFail(driver,
						"Test is Failed for Field Name is '" + fieldName
								+ "' due to data mismatch.Expected UI Data : '" + testDataUI
								+ "' Vs Actual API response  : " + EqualantString + "'",
						true);
			}
		} catch (AssertionError e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver, "Test is Failed for Field Name is '" + fieldName
					+ "' due to test data mismatch and " + e.getMessage(), true);
		}

	}

	public synchronized void assertUiStringApiNumeric(int numericValue, String locator, String fieldName) {
		WebElement element;

		try {

			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			String testDataUI = selectByLocatorType(locator).getText().trim();
			
			String percentage = String.valueOf(numericValue);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			element = selectByLocatorType(locator);
			js.executeScript("arguments[0].scrollIntoView();", element);

			try {

				if (testDataUI.contains(percentage) == true) {
					ExtTestMngr.reportStepPass(
							"Field Name : '" + fieldName + "' value comparision success. Expected Test Data : '"
									+ percentage + "' Vs Actual UI Data : '" + testDataUI + "'");
				} else {
					ExtTestMngr.reportStepFail(driver,
							"Test is Failed due to data mismatch. Field Name is '" + fieldName
									+ "' Expected Test Data : '" + percentage + "' Vs Actual UI Data : '"
									+ testDataUI + "'",
							true);
				}
			} catch (AssertionError e) {
				System.out.println(e.getMessage());
				ExtTestMngr.reportStepFail(driver,
						"Test is Failed due to data mismatch. Field Name is '" + fieldName + "' " + e.getMessage(),
						true);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

	public synchronized void assertApiUiAlphaNumeric(Response response, String jsonKey, String uiValue,
			String fieldName, String assertType) {
		String getVal = null, uiData = null;
		try {
			JsonPath jsonPathEvaluator = response.jsonPath();
			getVal = jsonPathEvaluator.get(jsonKey).toString().trim();
			uiData = selectByLocatorType(uiValue).getText().trim();
			WebElement element = selectByLocatorType(uiValue);
			Actions actions = new Actions(driver);
			actions.moveToElement(element).perform();

			boolean comparisonStatus = false;
			switch (assertType.toLowerCase()) {
			case "equals":
				comparisonStatus = getVal.equals(uiData);
				break;
			case "contains":
				comparisonStatus = getVal.contains(uiData) || uiData.contains(getVal);
				break;
			}
			if (comparisonStatus == true) {
				ExtTestMngr.reportStepPass(
						"Field Name : '" + fieldName + "' value contains validation success. Expected Data : '"
								+ getVal + "' Vs Actual UI Data : '" + uiData + "'");
			} else {
				ExtTestMngr.reportStepFail(driver,
						"Test is Failed for Field Name is '" + fieldName + "' due to data mismatch. UI Data '"
								+ uiData + "' and Api Response '" + getVal + "'",
						true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "Test is Failed for Field Name is '" + fieldName + "' due to Exception",
					true);
		}
	}

	public synchronized void assertApiUiAlphaNumeric(String response, String uiValue, String fieldName,
			String assertType) {
		String getValTrimed = null, uiData = null, uiDataTrimed = null;
		try {
			uiData = selectByLocatorType(uiValue).getText();
			uiDataTrimed = uiData.trim();
			getValTrimed = response.trim();
			WebElement element = selectByLocatorType(uiValue);
			Actions actions = new Actions(driver);
			actions.moveToElement(element).perform();

			boolean comparisonStatus = false;
			switch (assertType.toLowerCase()) {
			case "equals":
				comparisonStatus = getValTrimed.equals(uiDataTrimed);
				break;
			case "contains":
				comparisonStatus = getValTrimed.contains(uiDataTrimed) || uiDataTrimed.contains(getValTrimed);
				break;
			}
			if (comparisonStatus == true) {
				ExtTestMngr.reportStepPass(
						"Field Name : '" + fieldName + "' value contains validation success. Expected Data : '"
								+ getValTrimed + "' Vs Actual UI Data : '" + uiDataTrimed + "'");
			} else {
				ExtTestMngr.reportStepFail(driver, "Test is Failed for Field Name is '" + fieldName
						+ "' due to data mismatch. UI Data " + uiDataTrimed + "and Api Response " + getValTrimed, true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver,
					"Test is Failed for Field Name is '" + fieldName + "' due to Exception", true);
		}
	}

	public synchronized void assertApiUiAlphaNumericWithSuffix(Response response, String jsonKey, String uiValue,
			String fieldName, String suffix) {
		String getVal = null, getValSuffix = null;
		try {
			JsonPath jsonPathEvaluator = response.jsonPath();
			getVal = jsonPathEvaluator.get(jsonKey);
			String getValSpace = getVal.concat(" ");
			getValSuffix = getValSpace.concat(suffix);
			String testDataUI = selectByLocatorType(uiValue).getText();
			WebElement element = selectByLocatorType(uiValue);
			Actions actions = new Actions(driver);
			actions.moveToElement(element).perform();

			try {
				Assert.assertEquals(getValSuffix, testDataUI);
				ExtTestMngr.reportStepPass("Field Name '" + fieldName
						+ "' -> Comparing UI with API validation is success. Expected UI Data : '" + testDataUI
						+ "' Vs Actual API response  : '" + getValSuffix + "'");

			} catch (AssertionError e) {
				System.out.println(e.getMessage());
				ExtTestMngr.reportStepFail(driver, "Test is Failed for Field Name is '" + fieldName
						+ "' due to data mismatch and " + e.getMessage(), true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "Test is Failed for Field Name is '" + fieldName
					+ "' due to data mismatch and " + e.getMessage(), true);
		}
	}

	public String loadJSON(String fileName) throws JsonProcessingException {
		String json = null;
		try {
			InputStream is = this.getClass().getClassLoader().getResourceAsStream(fileName);
			int size = is.available();
			byte[] buffer = new byte[size];
			is.read(buffer);
			is.close();
			json = new String(buffer, "UTF-8");
		} catch (IOException ex) {
			ex.printStackTrace();
			return null;
		}
		System.out.println("json " + json);
		return json;
	}

	public JSONObject jsonFarmDetails(String farmerId) throws JsonProcessingException {

		JSONObject jsonObject = new JSONObject();
		try {
			JSONObject farmer = new JSONObject();
			farmer.put("farmer_id", farmerId);
			jsonObject.put("filters", farmer);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("jsonObject "+jsonObject);
		return jsonObject;
	}

	public String jsonFarmerOverview() throws JsonProcessingException {

		String finalJson = null;
		try {
			JSONObject json = new JSONObject();
			JSONObject farmerOverview = new JSONObject();

			List<String> countries = new ArrayList<>();
			List<String> products = new ArrayList<>();
			List<String> farmergroups = new ArrayList<>();
			farmergroups.add("1");
			List<String> programmes = new ArrayList<>();
			List<String> sections = new ArrayList<>();
			sections.add("2");
			List<String> partners = new ArrayList<>();
			List<String> year = new ArrayList<>();

			farmerOverview.put("countries", products);
			farmerOverview.put("products", countries);
			farmerOverview.put("farmergroups", farmergroups);
			farmerOverview.put("programmes", programmes);
			farmerOverview.put("sections", sections);
			farmerOverview.put("partners", partners);
			farmerOverview.put("year", year);
			farmerOverview.put("user_id", "832");
			farmerOverview.put("approver_id", "832");

			json.put("filters", farmerOverview);

			finalJson = json.toString();

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("finalJson "+finalJson);
		return finalJson;
	}

	public String getFarmerId(String endPoint, String jsonKey) {

		String farmerID = null;
		try {
			Response responseFarmersPopup = postWithHeaders(endPoint, "getFarmerOverview.json");

			int farmerid = getNumericValueFromApiReponse(responseFarmersPopup, FoJsonKeys.jsonKeys(jsonKey));
			farmerID = Integer.toString(farmerid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return farmerID;
	}

	public JSONObject loadJSONasJsonObject(String fileName) throws JsonProcessingException {
		String json = null;
		try {
			InputStream is = this.getClass().getClassLoader().getResourceAsStream(fileName);
			int size = is.available();
			byte[] buffer = new byte[size];
			is.read(buffer);
			is.close();
			json = new String(buffer, "UTF-8");
		} catch (IOException ex) {
			ex.printStackTrace();
			return null;
		}
		return new JSONObject(json);
	}

	public int getPercentage(Float valueOne, Float valueTwo) {

		int percentage = 0;
		try {

			float calculation = ((valueOne / valueTwo) * 100);
			percentage = Math.round(calculation);

		} catch (AssertionError e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver, "Percentage calculation is Failed for value One '" + valueOne
					+ "' and value Two " + valueTwo + e.getMessage(), true);
		}
		return percentage;
	}

	public float getFloatValue(Response response, String jsonKey) {
		JsonPath jsonPathEvaluator = response.jsonPath();
		float floatVal = 0;
		try {
			floatVal = Float.parseFloat(jsonPathEvaluator.get(jsonKey).toString());
		} catch (Exception e) {
			ExtTestMngr.reportStepFail(driver, "String to Float conversion is failed" + e.getMessage(), true);
			e.printStackTrace();
		}
		return floatVal;
	}

	public String convertToTwoDecimalWithComma(Float floatValue) {
		String addCommaAndDecimalInFloat = null;
		try {
			addCommaAndDecimalInFloat = String.format("%,.2f", floatValue);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return addCommaAndDecimalInFloat;
	}

	public synchronized ArrayList<String> angularWebTableFetchAndClickFirstRow(String getTablePath) {
		cellValues.removeAll(cellValues);
		WebElement clickRowValue = null;
		WebElement rawCell = null;
		try {

			WebElement mytable = null;
			mytable = selectByLocatorType(getTablePath);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", mytable);
			List<WebElement> rows = mytable.findElements(By.tagName("div"));
			for (int row = 0; row < 1; row++) {
				List<WebElement> columns = rows.get(row).findElements(By.tagName("div"));
				int columnsCount = columns.size();
				for (int column = 0; column < columnsCount; column++) {
					clickRowValue = columns.get(0);
					rawCell = columns.get(column);
					String cell = rawCell.getText();
					cellValues.add(cell);
				}
			}
			String clickElement = clickRowValue.getText();
			ExtTestMngr.reportStepPassScreenShot(driver, "Element going to click is : " + clickElement, true);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", clickRowValue);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", clickRowValue);
			ExtTestMngr.reportStepPass(
					"Element is clicked successfully from Grid and clicked element is : " + clickElement);
		} catch (Exception e) {
			ExtTestMngr.reportStepFail(driver, "Fetch and click a first row is failed", true);
			System.out.println(e.getMessage());
		}
		System.out.println("Angular Array List Values are : " + cellValues);
		return cellValues;

	}

	public synchronized String getTextFromElement(String locator) {
		WebElement element = selectByLocatorType(locator);
		
		elementValue=null;
		try {
			elementValue = element.getText().trim();
			System.out.println("returnStrElementValue " + elementValue);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "Unable to retrieve text from the element with locator "+locator, true);
		}

		return elementValue;
	}

	// Author:JAYAN - Below method return string after removing given prefix and
	// suffix from web element.
	public synchronized String getTextFromElementByRemovingPrefix(String locator, String splitPrefix) {
		WebElement rawElement = selectByLocatorType(locator);
		String rawElementValue = rawElement.getText();
		elementValue=null;
		try {
			elementValue = rawElementValue.split(splitPrefix)[1].trim();
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "String : '" + rawElementValue + "' and removing prefix '" + splitPrefix
					+ "' from String is failed", true);
		}

		return elementValue;
	}

	// Author:JAYAN - Below method return string after removing given prefix and
	// suffix from web element.
	public synchronized String getTextFromElementByRemovingPrefixAndSuffix(String locator, String splitPrefix,
			String splitSuffix) {
		WebElement element = selectByLocatorType(locator);
		String rawElementValue = element.getText();

		try {
			elementValue = rawElementValue.split(splitPrefix)[1];
			elementValue = elementValue.split(splitSuffix)[0].trim();
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "String : '" + rawElementValue + "' and removing prefix '" + splitPrefix
					+ "' and Surffix '" + splitSuffix + "' from String is failed", true);
		}

		return elementValue;

	}

	public synchronized ArrayList<String> webTableFetchAndClickFirstRow(String getTablePath) {
		cellValues.removeAll(cellValues);
		List<WebElement> rowIndex = null;
		try {
			WebElement myTable = null;
			myTable = selectByLocatorType(getTablePath);
			List<WebElement> rowsTable = myTable.findElements(By.tagName("tr"));
			for (int row = 0; row < 1; row++) {
				List<WebElement> ColumnsRow = rowsTable.get(row).findElements(By.tagName("td"));
				int columnsCount = ColumnsRow.size();
				for (int column = 0; column < columnsCount; column++) {
					rowIndex = ColumnsRow;
					WebElement rawCell = ColumnsRow.get(column);
					String cell = rawCell.getText();
					cellValues.add(cell);
				}
			}

			WebElement clickColumnValue = rowIndex.get(0);
			String elementToBeClicked = clickColumnValue.getText();
			clickColumnValue.click();
			ExtTestMngr.reportStepPass(
					"Element is clicked successfully from Grid and clicked element is : " + elementToBeClicked);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "Fetching first row and clicking on it is failed", true);
			System.out.println(e.getMessage());
		}
		System.out.println("web Array List Values are : " + cellValues);
		return cellValues;
	}

	public synchronized ArrayList<String> webTableFetchGivenRow(WebElement tableElement, int fetchRow) {
		// Cleanup ArrayList
		cellValues.removeAll(cellValues);

		try {
			List<WebElement> rows = tableElement.findElements(By.tagName("tr"));
			for (int row = 0; row <= fetchRow; row++) {
				if (row == fetchRow) {
					List<WebElement> columns = rows.get(row).findElements(By.tagName("td"));
					int columnsCount = columns.size();
					for (int column = 0; column < columnsCount; column++) {

						WebElement rawCell = columns.get(column);
						String cell = rawCell.getText();
						cellValues.add(cell);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "Fetching given row value is failed", true);
			System.out.println(e.getMessage());
		}
		// Remove all Empty Values
		System.out.println(
				"web Array List Values before Removing null : " + cellValues + "cellValues size " + cellValues.size());
		while (cellValues.remove(""))
			;
		System.out.println(
				"web Array List Values after removing null : " + cellValues + "cellValues size " + cellValues.size());

		return cellValues;
	}

	public synchronized void foFarmerManagementPlanRegressionTest() throws Exception {
		try {
			webElementClick(PomFarmerOverviewPage.pomFarmerOverview("tab_management"), "Management Tab");
			Thread.sleep(7000);
			List<WebElement> fmp = selectByLocatorTypeAllValues(
					PomFarmerOverviewPage.pomFarmerOverview("btnShowHideFarmersWithPlan"));
			int fmpSize = fmp.size();
			for (int i = 0; i < fmpSize; i++) {
				WebElement fmpElement = fmp.get(i);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", fmpElement);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", fmpElement);
				Thread.sleep(5000);
				List<WebElement> fmptables = selectByLocatorTypeAllValues(
						PomFarmerOverviewPage.pomFarmerOverview("webtableFarmersWithPlan"));
				WebElement fmpTableElement = fmptables.get(0);
				webTableFetchGivenRow(fmpTableElement, 1);
				String strArrayValue = cellValues.get(0);
				String strArrayValueFinal = strArrayValue.substring(strArrayValue.length() - 9);
				int j = i + 1;
				String txtSearchBox = "FMP Block " + j + " SearchBox";
				WebEditEnterText(PomFarmerOverviewPage.pomFarmerOverview("txtFmpSearch"), strArrayValueFinal,
						txtSearchBox);
				webElementClick(PomFarmerOverviewPage.pomFarmerOverview("btnFmpSearch"), "button Search");
				Thread.sleep(9000);
				String txtViewProfile = "Block " + j + " View Profile";
				webElementClick(PomFarmerOverviewPage.pomFarmerOverview("btnViewProfile"), txtViewProfile);
				getParentWindowAndSwitchToSpecificTab(1, "Farmer Profile");
				Thread.sleep(12000);
				assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileOlamFarmerId"),
						1, "Farmer Id");
				assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileFarmerName"), 1,
						"Farmer Name");
				webDriverClose();
				driver.switchTo().window(parentWindowHandle);
				Thread.sleep(5000);
				String txtHide = "Block " + j + " Hide";
				clickUsingWebElement(fmpElement, txtHide);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public synchronized void foApiFarmerManagementPlan(Response response, String fieldName) throws Exception {
		ArrayList<String> fmpList = new ArrayList<String>();
		int getVal = 0, j = 0, blocknumber = 0;
		String getValue = null, rawFmp = null, fmpJsonVal = null;
		WebElement fmpElement;
		try {
			webElementClick(PomFarmerOverviewPage.pomFarmerOverview("tab_management"), "Management Tab");
			Thread.sleep(7000);
			List<WebElement> fmp = selectByLocatorTypeAllValues(PomFarmerOverviewPage.pomFarmerOverview("fmpHeader"));
			int fmpSize = fmp.size();

			String getValueFromPOM = FoJsonKeys.jsonKeys("fmpPlansList");
			String[] fmpJson = getValueFromPOM.split("#");
			JsonPath jsonPathEvaluator;
			for (int i = 0; i < fmpSize; i++) {
				fmpElement = fmp.get(i);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", fmpElement);
				rawFmp = fmpElement.getText();

				Actions actions = new Actions(driver);
				actions.moveToElement(fmpElement).perform();

				fmpList.add(rawFmp);
				j = i;
				fmpJsonVal = fmpJson[j];
				try {
					jsonPathEvaluator = response.jsonPath();
					getVal = jsonPathEvaluator.get(fmpJsonVal);
					getValue = Integer.toString(getVal);

					if (getVal > 0) {
						boolean comparisonStatus = false;
						comparisonStatus = rawFmp.contains(getValue) || getValue.contains(rawFmp);

						blocknumber = i + 1;
						if (comparisonStatus == true) {
							ExtTestMngr.reportStepPass("Field Name : '" + fieldName + " " + blocknumber
									+ "' value contains validation success. Expected Data : '" + getValue
									+ "' Vs Actual UI Data : '" + rawFmp + "'");
						} else if (comparisonStatus == false) {

							ExtTestMngr.reportStepFail(driver,
									"Test is Failed for Field Name is '" + fieldName + " " + blocknumber
											+ "' due to data mismatch. UI Data " + rawFmp + "and Api Response "
											+ getValue,
									true);
						}
					} else {
						j = i + 1;
						fmpElement = fmp.get(i);
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", fmpElement);
						rawFmp = fmpElement.getText();
						fmpJsonVal = fmpJson[j];

						jsonPathEvaluator = response.jsonPath();
						getVal = jsonPathEvaluator.get(fmpJsonVal);
						getValue = Integer.toString(getVal);

						boolean comparisonStatus = false;
						comparisonStatus = rawFmp.contains(getValue) || getValue.contains(rawFmp);

						if (comparisonStatus == true) {
							ExtTestMngr.reportStepPass("Field Name : '" + fieldName + " " + j
									+ "' value contains validation success. Expected Data : '" + getValue
									+ "' Vs Actual UI Data : '" + rawFmp + "'");
						} else if (comparisonStatus == false) {

							ExtTestMngr.reportStepFail(driver, "Test is Failed for Field Name is '" + fieldName + " "
									+ j + "' due to data mismatch. UI Data " + rawFmp + "and Api Response " + getValue,
									true);
						}
					}

				} catch (Exception e) {
					e.printStackTrace();
					ExtTestMngr.reportStepFail(driver,
							"Test is Failed for Field Name is '" + fieldName + "' due to Exception", true);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Array values comparison by adding prefix array value.
	public synchronized void assertStringContainsAlphaNumericByAddingPrefix(String locator,
			String addPrefix, int arrayValue, String fieldName) {

		String arrayListData = cellValues.get(arrayValue - 1);
		String arrayListDataWithPrefix = addPrefix.concat(arrayListData);

		try {

			String testDataUI = selectByLocatorType(locator).getText();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement strElement = selectByLocatorType(locator);
			js.executeScript("arguments[0].scrollIntoView();", strElement);

			if (arrayListDataWithPrefix.contains(testDataUI) == true) {
				ExtTestMngr.reportStepPass(
						"Field Name : " + fieldName + " value contains validation success. Expected Test Data : '"
								+ arrayListDataWithPrefix + "\n" + "' Vs Actual UI Data : '" + testDataUI + "'");
			}
		} catch (AssertionError e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver,
					"Test is Failed due to data mismatch. Field Name is '" + fieldName + "' " + e.getMessage(), true);
		}

		
	}

	// parameter String webTableOrAngularTable should be consists of webtable or
	// angulartable in order to handle two different dynamic tables
	public synchronized ArrayList<String> webTableFetchAndClickSpecificRow(String getTablePath, int columnIndex,
			String webTableOrAngularTable) {

		cellValues.removeAll(cellValues);
		List<WebElement> rowIndex = null;
		WebElement myTable = null;
		List<WebElement> columns = null;
		String element = null;
		try {

			if (webTableOrAngularTable == "angulartable") {
				myTable = selectByLocatorType(getTablePath);
				List<WebElement> rows = myTable.findElements(By.tagName("div"));
				int rowsCount = rows.size();

				outerLoop: for (int row = 0; row < rowsCount; row++) {
					columns = rows.get(row).findElements(By.tagName("div"));
					int columnsCount = columns.size();
					for (int column = 0; column < columnsCount; column++) {
						int columnIndex2 = columnIndex - 1;
						WebElement cellColumnIndex = columns.get(columnIndex2);
						String rawCellColumnIndex = cellColumnIndex.getText();
						long convertedCellColumnIndex = Long.parseLong(rawCellColumnIndex);
						if (convertedCellColumnIndex != 0) {
							rowIndex = columns;
							for (int column2 = 0; column2 < columnsCount; column2++) {
								WebElement rawCell2 = rowIndex.get(column2);
								String cell2 = rawCell2.getText();
								cellValues.add(cell2);
							}
							break outerLoop;
						}
					}
				}
			} else {
				myTable = selectByLocatorType(getTablePath);
				List<WebElement> rowsTable = myTable.findElements(By.tagName("tr"));
				int rowsCount = rowsTable.size();
				outerLoop: for (int row = 0; row < rowsCount; row++) {
					columns = rowsTable.get(row).findElements(By.tagName("td"));
					int columnsCount = columns.size();
					for (int column = 0; column < columnsCount; column++) {
						int columnIndex2 = columnIndex - 1;
						WebElement cellColumndntex = columns.get(columnIndex2);
						String cellColumnIndex = cellColumndntex.getText();
						long convertedCellColumnIndex = Long.parseLong(cellColumnIndex);
						if (convertedCellColumnIndex != 0) {
							rowIndex = columns;
							for (int column2 = 0; column2 < columnsCount; column2++) {
								WebElement rawCell2 = rowIndex.get(column2);
								String cell2 = rawCell2.getText();
								cellValues.add(cell2);
							}
							break outerLoop;
						}
					}
				}

			}
			System.out.println("Angular Array List Values are :" + cellValues);
			WebElement elementToBeClicked = rowIndex.get(0);
			element = elementToBeClicked.getText();
			elementToBeClicked.click();
			ExtTestMngr.reportStepPass("Element is clicked successfully from Grid and clicked element is : " + element);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "Fetching specific value is failed and trying to click element is '" + element + "'",
					true);
			System.out.println(e.getMessage());
		}

		return cellValues;
	}

	public synchronized ArrayList<String> webTableFetchAndClickSpecificValue(String getTablePath, int columnIndex,
			String compareValue, int clickCellIndex) {

		cellValues.removeAll(cellValues);
		List<WebElement> rowIndex = null;
		WebElement myTable = null;
		List<WebElement> columns = null;
		String cellText = null;
		try {
			myTable = selectByLocatorType(getTablePath);
			List<WebElement> rows = myTable.findElements(By.tagName("div"));
			int rowsCount = rows.size();

			outerLoop: for (int row = 0; row < rowsCount; row++) {
				columns = rows.get(row).findElements(By.tagName("div"));
				int columnsCount = columns.size();
				for (int column = 0; column < columnsCount; column++) {
					int columnIndex2 = columnIndex - 1;
					WebElement cellColumnIndex = columns.get(columnIndex2);
					cellText = cellColumnIndex.getText().trim();
					if (cellText.equals(compareValue)) {
						rowIndex = columns;
						for (int column2 = 0; column2 < columnsCount; column2++) {
							WebElement rawCell2 = rowIndex.get(column2);
							String cell2 = rawCell2.getText();
							cellValues.add(cell2);
						}
						break outerLoop;
					}
				}
			}
			System.out.println("Angular Array List Values are :" + cellValues);
			WebElement columnToBeClick = rowIndex.get(clickCellIndex);
			columnToBeClick.click();
			ExtTestMngr
					.reportStepPass("First matching Element is clicked successfully from Grid and clicked element is : "
							+ compareValue);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver,
					"First matching Element is failed from Grid and compared value is : " + compareValue, true);
			System.out.println(e.getMessage());
		}
		return cellValues;
	}

	public synchronized ArrayList<String> webSpecificColumnValuesFetchAndValidate(String locator,
			String valueToSearch, String fieldName) {

		cellValues.removeAll(cellValues);
		List<WebElement> myColumnElements = null;
		try {

			myColumnElements = selectByLocatorTypeAllValues(locator);
			int columnsCount = myColumnElements.size();

			for (int row = 0; row < columnsCount; row++) {
				WebElement rawCell = myColumnElements.get(row);
				String cell = rawCell.getText();
				cellValues.add(cell);

				String toUpperArrayListData = cell.toUpperCase();
				String toUpperTestDataUI = valueToSearch.toUpperCase();

				if (toUpperArrayListData.contains(toUpperTestDataUI) == true
						|| toUpperTestDataUI.contains(toUpperArrayListData) == true) {
					ExtTestMngr.reportStepPass("Field Name : " + fieldName
							+ " value contains validation success. Expected Test Data : '" + valueToSearch
							+ "' Vs Actual UI Data : '" + cell + "'");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "Specific column value and validate value is failed.", true);
			System.out.println(e.getMessage());
		}
		return cellValues;
	}

	public synchronized ArrayList<String> webListFetchAndClickNonZeroValue(String getWebList, int cellText) {

		cellValues.removeAll(cellValues);
		List<WebElement> rowText = null;
		List<WebElement> columns = null;
		try {

			WebElement webList = selectByLocatorType(getWebList);

			List<WebElement> rows = webList.findElements(By.tagName("li"));
			int rowsCount = rows.size();

			outerLoop: for (int row = 0; row < rowsCount; row++) {
				columns = rows.get(row).findElements(By.tagName("div"));
				int columnsCount = columns.size();
				for (int column = 0; column < columnsCount; column++) {
					int cellText2 = cellText - 1;
					WebElement rawCellColumnIndex = columns.get(cellText2);
					String cellColumnIndex = rawCellColumnIndex.getText();
					long convertedCellColumnIndex = Long.parseLong(cellColumnIndex);
					if (convertedCellColumnIndex != 0) {
						rowText = columns;
						for (int column2 = 0; column2 < columnsCount; column2++) {
							WebElement rawCell2 = rowText.get(column2);
							String cell2 = rawCell2.getText();
							cellValues.add(cell2);
						}
						break outerLoop;
					}
				}
			}
			WebElement clickColumnValue = rowText.get(0);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", clickColumnValue);
			String clickingElement = clickColumnValue.getText();
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", clickColumnValue);
			// clickColumnValue.click();
			ExtTestMngr.reportStepPass(
					"Element is clicked successfully from Grid and clicked element is : " + clickingElement);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "Fetch a list of values and click non zero value is failed.", true);
			System.out.println(e.getMessage());
		}
		System.out.println("Angular Array List Values are :" + cellValues);
		return cellValues;
	}

	public synchronized void assertStringContainsAlphaNumeric(String locator, int arrayValue,
			String fieldName) {

		String arrayListData = cellValues.get(arrayValue - 1);

		try {
			String testDataUI = selectByLocatorType(locator).getText();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement element = selectByLocatorType(locator);
			js.executeScript("arguments[0].scrollIntoView();", element);
			String toUpperArrayListData = arrayListData.toUpperCase();
			String toUpperTestDataUI = testDataUI.toUpperCase();

			if (toUpperArrayListData.contains(toUpperTestDataUI) == true
					|| toUpperTestDataUI.contains(toUpperArrayListData) == true) {
				ExtTestMngr.reportStepPass(
						"Field Name : " + fieldName + " value contains validation success. Expected Test Data : '"
								+ arrayListData + "\n" + "' Vs Actual UI Data : '" + testDataUI + "'");
			} else {
				ExtTestMngr.reportStepFail(driver,
						"Test is Failed due to data mismatch. Field Name is '" + fieldName
								+ "' And Expected Test Data : '" + arrayListData + "\n" + "' Vs Actual UI Data : '"
								+ testDataUI + "'",
						true);
			}
		} catch (AssertionError e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver,
					"Test is Failed due to data mismatch. Field Name is '" + fieldName + "' " + e.getMessage(), true);
		}

		
	}

	public synchronized void formatDateAndAssertContainsUIData(String locator, int arrayValue,
			String fieldName) throws Exception {

		String arrayListData = cellValues.get(arrayValue - 1);

		try {
			String testDataUI = selectByLocatorType(locator).getText();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement element = selectByLocatorType(locator);
			js.executeScript("arguments[0].scrollIntoView();", element);
			SimpleDateFormat formatter = new SimpleDateFormat("dd MMMM yyyy");

			Date date = formatter.parse(arrayListData);
			SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
			String convertedDate = dateFormatter.format(date);
			System.out.println("Converted Date: " + convertedDate);

			if (testDataUI.contains(convertedDate) == true || convertedDate.contains(testDataUI) == true) {
				ExtTestMngr.reportStepPass("Field Name : " + fieldName
						+ " converted Date contains validation success. Expected Test Data : '" + arrayListData + "\n"
						+ "' Vs Actual UI Data : '" + testDataUI + "'");
			}
		} catch (AssertionError e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver,
					"Test is Failed due to data mismatch. Field Name is '" + fieldName + "' " + e.getMessage(),
					true);
		}

		
	}

	public synchronized void webDriverClose() {
		try {
			driver.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver, "button  was not avaiable '", true);
		}
	
	}

	/*
	 * Abu Pass using Webelement
	 */
	public synchronized void clickUsingWebElement(WebElement ele, String fieldName) {
		try {
			ele.click();
			ExtTestMngr.reportStepPass("Field Name : '" + fieldName + "' is clicked successfully.");
		} catch (Exception e) {
			System.out.println("click" + e.getMessage());
			ExtTestMngr.reportStepFail(driver, fieldName + " is not clicked", true);
		}
	}

	/*
	 * Abu in this method used click any click element by passing two parameter as
	 * String example :for the locator pass as xpath#//input[], other for result.
	 */
	public synchronized void clickUsinglocator(String locator, String fieldName) {
		WebElement ele = null;
		try {
			// ((JavascriptExecutor) driver).executeScript("arguments[0].click();", ele);
			ele = selectByLocatorType(locator);
			ele.click();
			ExtTestMngr.reportStepPass("Field Name : '" + fieldName + "' is clicked successfully.");
		} catch (Exception e) {
			System.out.println("click" + e.getMessage());
			ExtTestMngr.reportStepFail(driver, fieldName + " is not clicked", true);
		}
	}

	// button validation -abu
	public synchronized boolean verifyWebElementIsEnabled(String locator, String fieldName) {
		boolean button = false;
		WebElement btnelement;
		try {
			btnelement = selectByLocatorType(locator);

			button = btnelement.isEnabled();
			System.out.println(button);

			ExtTestMngr.reportStepPass("Field Name : '" + fieldName + "'isEnabled validation success " + button);
			return button;

		} catch (Exception e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver, "Verify web element is enabled Failed." + e.getMessage(), true);
		}
		return button;
	}

	/*
	 * Abu webtable for manageGPX In this method, search based on the farmer
	 * id,based on the farmer id it will verify the whether the View button is
	 * enabled if view button is displayed in the it will click upload update if is
	 * not it will click view button
	 */

	public synchronized void searchOlamFarmerIdAndClick(String olamFarmerId, String reports) {
		WebElement viewButton, uploadButton;

		List<WebElement> column = driver.findElements(By.xpath("//table[@class='table']/thead/tr/th"));
		int numberOfColumns = column.size();
		System.out.println("COLS : " + numberOfColumns);
		waitTill(3000);
		List<WebElement> rows = driver.findElements(By.xpath("//table[@class='table']/tbody/tr/td"));
		int numberOfRows = rows.size();
		System.out.println("ROWS : " + numberOfRows);

		for (int x = 1; x <= numberOfRows; x++) {

			String farmerColoumid = driver.findElement(By.xpath("//table[@class='table']/tbody/tr[" + x + "]/td[2]"))
					.getText();

			try {
				if (farmerColoumid.equals(olamFarmerId)) {
					viewButton = driver.findElement(By.xpath("// table[@class='table']/tbody/tr[" + x + "]/td[5]/a"));
					System.out.println(farmerColoumid);
					String isViewButton = viewButton.getAttribute("class");
					System.out.println(isViewButton);

					if (!(isViewButton.equals("btn btn-primary disabled"))) {
						clickUsingWebElement(viewButton, "view button");
						ExtTestMngr.reportStepPass(
								"Field Name : '" + reports + "'isEnabled validation success" + isViewButton);
					} else {
						uploadButton = driver
								.findElement(By.xpath("// table[@class='table']/tbody/tr[" + x + "]/td[5]/button"));
						clickUsingWebElement(uploadButton, "Uploadbutton ");

						ExtTestMngr.reportStepPass(
								"Field Name : '" + reports + "'isEnabled validation success" + isViewButton);
					}
					break;
				}

			} catch (Exception e) {
				System.out.println(e.getMessage());
				ExtTestMngr.reportStepFail(driver, "WebElementdymanicTableTask" + e.getMessage(), true);
			}
		}

	}

	// Abu- Fileupload code
	public synchronized void uploadGPXFile(String filePath) {

		Robot robot = null;

		try {
			StringSelection selection = new StringSelection(filePath);
			Clipboard Clip = Toolkit.getDefaultToolkit().getSystemClipboard();
			Clip.setContents(selection, null);
			robot = new Robot();
			robot.delay(250);

			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.delay(250);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {

			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, " uploadGPXFile" + e.getMessage(), true);
		}

	}

	public synchronized void getParentWindowAndSwitchToSpecificTab(int i, String result) {
		try {
			parentWindowHandle = driver.getWindowHandle();
			driver.switchTo().window(driver.getWindowHandles().toArray()[i].toString());
			Thread.sleep(8000);
			ExtTestMngr.reportStepPassScreenShot(driver, "Switch to window '" + result + "' is successful.", true);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver, "switchToWindows" + e.getMessage(), true);
		}

	}

	public synchronized void switchToWindows(int i, String result) {
		try {
			driver.switchTo().window(driver.getWindowHandles().toArray()[i].toString());
			Thread.sleep(8000);
			ExtTestMngr.reportStepPassScreenShot(driver, "Switch to window '" + result + "' is successful.", true);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver, "switchToWindows" + e.getMessage(), true);
		}

	}

	public synchronized void switchToDefaultWindow() {

		try {

			driver.switchTo().defaultContent();
			ExtTestMngr.reportStepPassScreenShot(driver, "switchToDefaultWindow is sucessful", true);

		} catch (Exception e) {

			System.out.println("switchToDefaultWindow" + e.getMessage());
			ExtTestMngr.reportStepFail(driver, "switchToDefaultWindow" + e.getMessage(), true);

		}
	}

	public synchronized void closeCurrentWindow() throws InterruptedException {
		webDriverClose();
		// switchToParentWindow();
	}

	public synchronized void getParentWindow() {

		try {

			parentWindowHandle = driver.getWindowHandle();
			// ExtTestMngr.reportStepPassScreenShot(driver, "get parent window is
			// sucessful", true);

		} catch (Exception e) {

			System.out.println("switchToDefaultWindow" + e.getMessage());
			ExtTestMngr.reportStepFail(driver, "switchToDefaultWindow" + e.getMessage(), true);

		}
	}

	public synchronized void switchToParentWindow() {

		try {

			// Switch to the parent window
			driver.switchTo().window(parentWindowHandle);
			ExtTestMngr.reportStepPassScreenShot(driver, "switch To Parent Window is sucessful", true);

		} catch (Exception e) {

			System.out.println("switchToDefaultWindow" + e.getMessage());
			ExtTestMngr.reportStepFail(driver, "switchToDefaultWindow" + e.getMessage(), true);

		}
	}

	public synchronized String webElementgetText(String locator, String result) {
		String textvalue = null;
		String locatorkey = locator.split("#")[0];
		String locatorvalue = locator.split("#")[1];

		try {
			switch (locatorkey) {
			case "id":
				textvalue = driver.findElement(By.id(locatorvalue)).getText();
				break;
			case "name":
				textvalue = driver.findElement(By.name(locatorvalue)).getText();
				break;
			case "xpath":
				textvalue = driver.findElement(By.xpath(locatorvalue)).getText();
				break;
			case "css":
				textvalue = driver.findElement(By.cssSelector(locatorvalue)).getText();
				break;
			case "linkText":
				textvalue = driver.findElement(By.linkText(locatorvalue)).getText();
				break;

			}

			ExtTestMngr.reportStepPassScreenShot(driver, " Text is " + result, true);

		} catch (Exception e) {

			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver, " webElementgetText " + e.getMessage(), true);
		}
		return textvalue;

	}

	// abu verify text

	public synchronized void verifyText(String exceptedResult, String actualResult) {

		try {
			if (exceptedResult.equals(actualResult)) {
				System.out.println(exceptedResult + " is result Equal to Actual result " + actualResult);
			} else {

				System.out.println(exceptedResult + " is result NotEqual to Actual result " + actualResult);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block

			ExtTestMngr.reportStepFail(driver, " webElementgetText " + e.getMessage(), true);
		}
	}

	public synchronized String webElementGetAttribute(String locator, String attribute) {

		String attributevalue = "";
		WebElement ele;
		try {
			ele = selectByLocatorType(locator);
			switch (attribute) {
			case "id":
				attributevalue = ele.getAttribute("id");
				break;
			case "class":
				attributevalue = ele.getAttribute("class");
				break;
			case "value":
				attributevalue = ele.getAttribute("value");
				break;
			case "option":
				attributevalue = ele.getText();
				break;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver, " webElementgetText " + e.getMessage(), true);
		}
		return attributevalue;
	}

	public synchronized WebElement selectByLocatorcssSelector(String cssLocator) {
		WebElement ele = null;
		try {
			ele = driver.findElement(By.cssSelector(cssLocator));
		} catch (Exception e) {
			System.out.println("selectByLocatorcssSelector" + e.getMessage());
		}
		return ele;
	}

	public synchronized boolean WebdriverQuit() {
		try {
			driver.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver, "button  was not avaiable '", true);
			return false;
		}
		return true;
	}

	// verify url
	public synchronized void getUrlWebPage(String expectedUrl) {
		String Actualurl = driver.getCurrentUrl();
		try {
			if (Actualurl.equals(expectedUrl)) {
				System.out.println(Actualurl + "is equal to " + expectedUrl);
			} else {
				System.out.println(Actualurl + "is not equal to " + expectedUrl);
			}
		} catch (Exception e) {
			System.out.println(" getUrlWebPage: " + e.getMessage());
		}
	}

	public String webElementGetText(String locator) {

		WebElement ele = selectByLocatorType(locator);
		String gettextvalue = "";
		try {
			gettextvalue = ele.getText();
			return gettextvalue;
		} catch (Exception e) {
			System.out.println(" WebgetText: " + e.getMessage());
			return null;
		}
	}

	public String webDropdown(String locator, String visibleText, String reports) {

		String listText = "";
		try {

			Select sel = new Select(selectByLocatorType(locator));
			List<WebElement> lst = sel.getOptions();
			for (int i = 0; i < lst.size(); i++) {

				listText = lst.get(i).getText();

				System.out.println(listText);

				if (listText.trim().equalsIgnoreCase(visibleText)) {
					sel.selectByVisibleText(listText);
					break;
				}
			}
			ExtTestMngr.reportStepPassScreenShot(driver, reports + "Successful", true);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("webDropdown fail" + e.getMessage());

			ExtTestMngr.reportStepFail(e.getMessage(), true);
		}

		return listText;
	}

	public void waitUntilElementToBeClicked(String locator, String result) {
		WebElement element;
		WebDriverWait wait;
		try {
			element = selectByLocatorType(locator);

			wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.elementToBeClickable(element)).click();
			ExtTestMngr.reportStepPassScreenShot(driver, result + "Sucessful", true);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail(driver, result + "Failed", true);
		}
	}

	/*
	 * This method used to store value as the list. passing the locator using two
	 * ways, 1.Pass one value has empty string and other with locator based on the
	 * selectByLocatorType() method it split the # with before and after value.
	 * 
	 * 2.Pass first parameter as locator type ,locator value this will work as
	 * normal selenium method
	 * 
	 *
	 */
	public List<WebElement> selectLocatorsBylists(String locatorName, String locator) {

		String locatorType = "";
		String locatorValue = "";
		if (locatorName.trim().length() == 0 && locator.contains("#")) {
			locatorType = locator.split("#")[0];
			locatorValue = locator.split("#")[1];
		} else {
			locatorValue = locator;
		}
		List<WebElement> labellst = null;
		try {
			if ((locatorType.equalsIgnoreCase("xpath"))
					|| (locatorName != null && locatorName.equalsIgnoreCase("xpath"))) {
				labellst = driver.findElements(By.xpath(locatorValue));
			} else if ((locatorType.equalsIgnoreCase("id"))
					|| (locatorName != null && locatorName.equalsIgnoreCase("id"))) {
				labellst = driver.findElements(By.id(locatorValue));
			} else if ((locatorType.equalsIgnoreCase("css"))
					|| (locatorName != null && locatorName.equalsIgnoreCase("css"))) {
				labellst = driver.findElements(By.cssSelector(locatorValue));
			}
			return labellst;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ExtTestMngr.reportStepFail("selectLocatorsBylists" + e.getMessage(), false);
			return null;
		}
	}
	
	public boolean checkWebElementExist(String locatorTypeAndValue){
		WebElement element = null;
		boolean elementExists=false; 
		try {
			
			String locatorType = locatorTypeAndValue.split("#")[0];
			String locatorValue = locatorTypeAndValue.split("#")[1];

			String loc = locatorType;
			switch (loc.toLowerCase()) {
			case "id":
				element = driver.findElement(By.id(locatorValue));
				break;
			case "xpath":
				element = driver.findElement(By.xpath(locatorValue));
				break;
			case "css":
				element = driver.findElement(By.cssSelector(locatorValue));
				break;
			case "classname":
				element = driver.findElement(By.className(locatorValue));
				break;
			case "name":
				element = driver.findElement(By.name(locatorValue));
				break;
			case "linktext":
				element = driver.findElement(By.linkText(locatorValue));
				break;
			case "tagname":
				element = driver.findElement(By.tagName(locatorValue));
				break;
			case "partiallinktext":
				element = driver.findElement(By.partialLinkText(locatorValue));
				break;
			default:
				throw new IllegalArgumentException("Check the given locator Type in POM");
			}
		elementExists = element.isDisplayed();
		
		}catch(Exception e) {
			System.out.println("Exception message " + e.getMessage());
		}
		return elementExists;
	}
}
