package com.olam.ofis.pom;

import java.util.HashMap;
import java.util.Map;

public class PomFarmDevelopmentPlan {

	public synchronized String pomFarmDevelopmentPlan(String locator) {

		try {
			Map<String, String> hmap = new HashMap<>();
			// ClickFDP
			hmap.put("FarmDevelopmentPlan", "xpath#(//a[@routerlink='/fdp'])[1]/span");
			hmap.put("templates", "xpath#//span[@class='templates']");
			hmap.put("addtemplates", "xpath#//a[@role='button']");
			// dropdown
			hmap.put("productAssignment", "xpath#//select[@formcontrolname='productName']");
			hmap.put("assignmenttype", "xpath#//select[@formcontrolname='assignment2Type']");
			hmap.put("assignmentvalueclick", "css#ng-select[formcontrolname='assignment2']");
			hmap.put("assignmentvaluelst", "css#ng-dropdown-panel[class='ng-dropdown-panel ng-select-multiple ng-select-top']>div>div>div span.ng-option-label");
			//hmap.put("assignmentvaluelst", "//div[@class='ng-dropdown-panel-items scroll-host']//following-sibling::div//div");
			hmap.put("assignmenttype3", "xpath#//select[@formcontrolname='assignment3Type']");
			//TemplateSegment and alert
			hmap.put("dangeralert", "css#div[class='alert alert-danger alert-dismissible'] strong");
			hmap.put("maxpermaxpot", "css#ng-select[formcontrolname='maxPerfMaxPot']");
			hmap.put("dropdownforsegment", "css#div[class='ng-dropdown-panel-items scroll-host']>div>div.ng-option");
			hmap.put("maxperminpot", "css#ng-select[formcontrolname='maxperfMinPot']");
			hmap.put("minpermaxpot", "css#ng-select[formcontrolname='minPerfMaxPot']");
			hmap.put("minperminpot", "css#ng-select[formcontrolname='minPerfMinPot']");
			
			// Templates Labels
			hmap.put("templatesLabel", "xpath#//h1[contains(text(),'Template')]");
			hmap.put("editTemplatesLabel", "xpath#//h1[contains( text(),'Edit Template')]");
			
			// templates Add
			hmap.put("assignmenttype", "xpath#//select[@formcontrolname='assignment3Type']");
			hmap.put("addTemplates", "xpath#//a[@role='button']");
			hmap.put("assignmentvaluelst", "#a0e89a9df09b>div >div>div span.ng-option-label");
			hmap.put("assignmenttype3", "xpath#//select[@formcontrolname='assignment3Type']");
			// templates Edit
			hmap.put("TemplatesEdit", "xpath#(//span[@class='glyphicon glyphicon-edit editDeleteGlyph'])[1]");
			
			// templates Next and cancel
			hmap.put("Next", "xpath#//input[@value='Next']");
			hmap.put("cancelbutton", "xpath#//button[contains(text(),'Cancel')]");
			hmap.put("save", "xpath#//button[text()='Save']");
			hmap.put("canceltemplate", "xpath#//button[text()='Cancel']");
			// templates Alert
			hmap.put("Yes", "xpath#//button[text()='Yes']");
			hmap.put("Alertcancel", "xpath#//button[text()='Cancel']");

			//templates

			hmap.put("GapAdvice", "xpath#//a[text()='GAP Advice']");
			hmap.put("pests", "xpath#//a[text()='Pests and Diseases']");
			hmap.put("Pesticide", "xpath#//a[text()='Pesticide Recommendations']");
			// templates gapadivceLabel and textarea
			hmap.put("gapadviceslabel", "xpath#//div[@class='row module-table']/div[1]/div[2][@class='col col-md-3' or @class='col lableQn col-md-3']");
			hmap.put("gaptextarea", "xpath#//div[@class='col col-md-8 col-width-70']/textarea");

			// templates pests&disease label and textarea.
			hmap.put("pestsadviceslabel",
					"xpath#//div[@class='row module-table']/div[1]/div[2][@class='col col-md-3' or @class='col lableQn col-md-3']");
			hmap.put("peststextarea", "xpath#//div[@class='col col-md-8 col-width-70']/textarea");
			// templates pesticide
			hmap.put("pesticideadviceslabel",
					"xpath#//div[@class='row module-table']/div[1]/div[2][@class='col col-md-3' or @class='col lableQn col-md-3']");
			hmap.put("pesticidetextarea", "xpath#//div[@class='col col-md-8 col-width-70']/textarea");

			// calender activity
			hmap.put("calendar_activity", "xpath#//span[@class='calendar_activity']");
			hmap.put("calendar_activity_label", "xpath#//h1[contains(text(),'Calendar Activity')]");
			hmap.put("EditCalender", "xpath#(//span[@class='glyphicon glyphicon-edit editDeleteGlyph'])[1]");
			hmap.put("Editcalendar_activity_label", "xpath#//h1[contains(text(),'Edit Calendar Activity')]");
			hmap.put("CancelButtonCalender", "xpath#//div[contains(text(),'Cancel')]");

			// cropcalender
			hmap.put("cropcallendar", "xpath#//span[@class='cropcallendar']");
			hmap.put("CropCalendar_label", "xpath#//h1[contains(text(),'Crop Calendar')]");
			hmap.put("EditcropCalender", "xpath#(//span[@class='glyphicon glyphicon-edit editDeleteGlyph'])[1]");
			hmap.put("EditCropCalendarlabel", "xpath#//h1[contains(text(),'Edit Crop Calendar')]");
			hmap.put("CancelButtoncropCalender", "xpath#//button[contains(text(),'Cancel')]");

			// weighting
			hmap.put("weighting", "xpath#//span[@class='weighting']");
			hmap.put("Weighting_label", "xpath#//h1[contains(text(),'Weighting')]");
			hmap.put("Editweighting", "xpath#(//span[@class='glyphicon glyphicon-edit editDeleteGlyph'])[1]");
			hmap.put("EditWeightingLabel", "xpath#//h1[contains(text(),'Edit Weighting')]");
			hmap.put("CancelButtonweighting", "xpath#//button[contains(text(),'Cancel')]");

			// Setting
			hmap.put("settings", "xpath#//span[@class='settings']");
			hmap.put("EditSetting", "xpath#(//span[@class='glyphicon glyphicon-edit editDeleteGlyph'])[1]");
			hmap.put("Overide", "xpath#(//span[@class='glyphicon glyphicon-random overrideGlyph'])[1]");
			hmap.put("CancelButtonSetting", "xpath#//a[contains(text(),'Cancel')]");

			return hmap.get(locator);

		} catch (Exception e) {
			System.out.println("fmp_Menu : " + e.getMessage());
			return null;
		}
	}
}
