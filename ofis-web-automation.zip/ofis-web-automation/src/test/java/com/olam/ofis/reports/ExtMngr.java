package com.olam.ofis.reports;

import com.relevantcodes.extentreports.ExtentReports;

public class ExtMngr {
	private static ExtentReports extent;

	public synchronized static ExtentReports getReporter(String filePath) {
		extent = null;
		extent = new ExtentReports(filePath, true);
		return  extent;
	}

	public synchronized static ExtentReports getReporter() {
		return extent;
	}

}
