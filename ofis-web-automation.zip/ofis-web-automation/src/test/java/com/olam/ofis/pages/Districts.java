package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomDistricts;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Districts extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomDistricts pomDistricts = new PomDistricts();

	public Districts(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderAllDistricts;
	private String expectedPageHeaderEditAllDistricts;
	private int expectedDistrictId;
	private String expectedRegion;
	private String expectedName;

	public synchronized void allDistrictsLoadExcelData()
			throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/AllDistricts.xlsx");

		expectedPageHeaderAllDistricts = read.getCellData("AllDistrictsTC", "pageHeader_alldistricts", 1);
		expectedPageHeaderEditAllDistricts = read.getCellData("AllDistrictsTC", "pageHeader_edit_alldistricts", 1);
		expectedDistrictId = read.getNumericCellData("AllDistrictsTC", "text_districtid", 1);
		expectedRegion = read.getCellData("AllDistrictsTC", "drp_region", 1);
		expectedName = read.getCellData("AllDistrictsTC", "text_name", 1);

	}

	public synchronized void settingsGeographicDataclick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_geographical"), "Settings->GeographicalData");
	}

	public synchronized void switchIntoIframe() throws InterruptedException {
		Thread.sleep(1000);
		iFrameSwitchTo(pomMenus.pomMenus("iFrame_OFISUser"), "iFrame-OFISGeographicalData");

	}

	public synchronized void switchoutFromIframe() throws InterruptedException {

		Thread.sleep(1000);
		iFrameSwitchOut("iFrame-OFIS Geographical data");
	}

	public synchronized void allDistrictsClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomDistricts.pomDistricts("thumbnail_districts"), "thumbnail all districts");
	}

	public synchronized void allDistrictsPageHeaderValidation() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomDistricts.pomDistricts("Header_PageHeader"),
				expectedPageHeaderAllDistricts, "PageHeader all districts");
	}

	public synchronized void editAllDistrictsButtonClick() throws InterruptedException {
		Thread.sleep(3000);
		webElementMouseHoverAndClick(pomDistricts.pomDistricts("btn_edit_alldistricts"),
				"Edit all districts button");
	}

	public synchronized void editAllDistrictsPageHeaderValidation() throws InterruptedException {
		Thread.sleep(3000);
		webAssertEqualsAlphaNumeric(pomDistricts.pomDistricts("Header_edit_alldistricts"),
				expectedPageHeaderEditAllDistricts, "Edit all districts Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomDistricts.pomDistricts("btn_Cancel"), "cancel");
	}

	public synchronized void validateAllDistrictsValues() throws InterruptedException {
		Thread.sleep(7000);
		webGetAttributeValueAndAssertEqualsNumeric(pomDistricts.pomDistricts("txt_districtid"),
				expectedDistrictId, "district id");
		/*webAssertEqualsAlphaNumeric(pom_alldistricts_page.pomDistricts("drp_region_CENTRE"), data_drp_region1,
				"region dropdown");*/
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomDistricts.pomDistricts("txt_name"),
				expectedName, "name");
		verifyWebCheckBoxIsSelected(pomDistricts.pomDistricts("chk_active"), "district- checkbox");
	}
}
