package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.pom.PomProducts;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Products extends Functions {
	public Products(RemoteWebDriver driver) {
		this.driver = driver;
	}

	PomProducts pomProduct = new PomProducts();
	PomMenus pomMenus = new PomMenus();

	private String expectedPageHeaderProduct;
	private String expectedPageHeaderEditProduct;
	private int expectedProductId;
	private String expectedName;
	private String expectedNameFrench;
	private String expectedNameSpanish;
	private String expectedNameIndonesian;
	private String expectedNamePortuguese;
	private String expectedNameTurkish;
	private String expectedNameLao;
	private String expectedNameVietnamese;
	private String expectedNameThai;

	public synchronized void allPartnersLoadExcelData() throws Exception {
		
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/AllProducts.xlsx");

		expectedPageHeaderProduct = read.getCellData("AllProductsTC", "pageheader_product", 2);
		expectedPageHeaderEditProduct = read.getCellData("AllProductsTC", "pageheader_editproduct", 2);
		expectedProductId = read.getNumericCellData("AllProductsTC", "text_productid", 2);
		expectedName = read.getCellData("AllProductsTC", "text_name", 2);
		expectedNameFrench = read.getCellData("AllProductsTC", "text_name_french", 2);
		expectedNameSpanish = read.getCellData("AllProductsTC", "text_name_spanish", 2);
		expectedNameIndonesian = read.getCellData("AllProductsTC", "text_name_indonesian", 2);
		expectedNamePortuguese = read.getCellData("AllProductsTC", "text_name_portuguese", 2);
		expectedNameTurkish = read.getCellData("AllProductsTC", "text_name_turkish", 2);
		expectedNameLao = read.getCellData("AllProductsTC", "text_name_lao", 2);
		expectedNameVietnamese = read.getCellData("AllProductsTC", "text_name_vietnamese", 2);
		expectedNameThai = read.getCellData("AllProductsTC", "text_name_thai", 2);

	}

	public synchronized void settingsAllProductsClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_progspartsproducts"), "Settings-ProgrammesPartnersProducts");
	}

	public synchronized void allProductsClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomProduct.pomProducts("thumbnail_product"), "thumbnail products");
	}

	public synchronized void allProductPageHeaderValidation() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomProduct.pomProducts("pageheader_product"), expectedPageHeaderProduct,
				"PageHeader product");
	}

	public synchronized void editAllProductsButtonClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementMouseHoverAndClick(pomProduct.pomProducts("editproduct"), "Edit button");
	}

	public synchronized void editAllProductsPageHeaderValidation() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomProduct.pomProducts("pageheader_editproduct"), expectedPageHeaderEditProduct,
				"Edit product Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomProduct.pomProducts("btn_Cancel"), "cancel");
	}

	public synchronized void validateAllProductsValues() throws InterruptedException {
		Thread.sleep(2000);
		webGetAttributeValueAndAssertEqualsNumeric(pomProduct.pomProducts("txt_productid"), expectedProductId,
				"product id");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomProduct.pomProducts("txt_name"), expectedName,
				"product Name");
		verifyWebCheckBoxIsSelected(pomProduct.pomProducts("chk_active"), "programme Active- checkbox");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomProduct.pomProducts("txt_name_french"),
				expectedNameFrench, "product Name-french");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomProduct.pomProducts("txt_name_spanish"),
				expectedNameSpanish, "product Name-spanish");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomProduct.pomProducts("txt_name_indonesian"),
				expectedNameIndonesian, "product Name-indonesian");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomProduct.pomProducts("txt_name_portuguese"),
				expectedNamePortuguese, "product Name-portuguese");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomProduct.pomProducts("txt_name_turkish"),
				expectedNameTurkish, "product Name-turkish");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomProduct.pomProducts("txt_name_lao"), expectedNameLao,
				"product Name-lao");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomProduct.pomProducts("txt_name_vietnamese"),
				expectedNameVietnamese, "product Name-vietnamese");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomProduct.pomProducts("txt_name_thai"), expectedNameThai,
				"product Name-thai");

	}

}
