package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomModules {

	public synchronized String pomModules(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("thumbnailAllModules", "xpath#//*[@class='col-sm-6 col-md-4'][1]/a/div/div");
			hs.put("Header_PageHeader", "xpath#//*[@class='page-header']");

			// Add all modules page
			hs.put("txtName", "id#name");
			hs.put("txtExpires", "id#expires");
			hs.put("chkAffectFMP", "id#annual_survey");
			hs.put("chkActiveModule", "id#active");
			hs.put("txtNameFr", "id#name_fr");
			hs.put("txtNameEs", "id#name_es");
			hs.put("txtNameId", "id#name_id");
			hs.put("txtNamePt", "id#name_pt");
			hs.put("txtNameTr", "id#name_tr");
			hs.put("txtNameLo", "id#name_lo");
			hs.put("txtNameVi", "id#name_vi");
			hs.put("txtNameTh", "id#name_th");

			// edit all modules page
			hs.put("btnEditModules", "css#div[row-index='0'] div[col-id='0'] a");
			hs.put("headerEditModules", "xpath#//*[@class='page-header']");
			hs.put("txtModuleId", "name#id");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");

			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
