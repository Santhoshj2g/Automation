package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomModuleAssignments {

	public synchronized String pomModulesAssignments(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("thumbnailAllModulesAssignments", "xpath#//*[@class='col-sm-6 col-md-4'][3]/a/div/div");
			hs.put("Header_PageHeader", "xpath#//*[@class='page-header']");

			// Add all Sub modules page
			hs.put("drpModule", "id#module_id");
			hs.put("txtModuleAssignmentId", "id#moduleassignment_id");
			hs.put("drpModuleAssignmentType", "id#moduleassignment_type");
			hs.put("chkRecurring", "xpath#//*[@class='form-group'][2]/div/input");
			hs.put("txtRecurrenceFrequency", "id#recurrence_frequency");
			hs.put("drpRecurrenceType", "id#recurrence_type");
			hs.put("txtDisabledMonths", "xpath#//*[@placeholder='Select Some Options']/div/input");
			hs.put("chkActiveModuleAssignment", "id#active");

			// edit all sub modules page
			hs.put("btnEditModulesAssignments", "css#div[row-index='1'] div[col-id='0'] a");
			hs.put("headerEditModulesAssignments", "xpath#//*[@class='page-header']");
			hs.put("txtModuleAssignmentId", "name#id");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");

			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
