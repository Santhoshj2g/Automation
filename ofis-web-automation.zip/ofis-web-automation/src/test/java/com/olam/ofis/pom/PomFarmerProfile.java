package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomFarmerProfile {

	public synchronized String pomFarmerProfile(String locator)
	{

		try
		{
			Hashtable<String, String> hs = new Hashtable<String, String>();

			//Farmer information block
					
			hs.put("titleFarmerName","css#span.farmer_name");
			hs.put("partner","css#div.mtop10:nth-child(3) div:nth-child(1) div:nth-child(1) div:nth-child(2)");
			hs.put("programme","css#div.mtop10:nth-child(3) div:nth-child(1) div:nth-child(2) div:nth-child(2)");
			hs.put("farmerGroup","css#div.mtop10:nth-child(3) div:nth-child(1) div:nth-child(3) div:nth-child(2)");
			hs.put("section","css#div.mtop10:nth-child(3) div:nth-child(1) div:nth-child(4) div:nth-child(2)");
			hs.put("country","css#div.mtop10:nth-child(3) div:nth-child(1) div:nth-child(5) div:nth-child(2)");
			hs.put("region","css#div.mtop10:nth-child(3) div:nth-child(1) div:nth-child(6) div:nth-child(2)");
			hs.put("district","css#div.mtop10:nth-child(3) div:nth-child(1) div:nth-child(7) div:nth-child(2)");
			hs.put("town","css#div.mtop10:nth-child(3) div:nth-child(1) div:nth-child(8) div:nth-child(2)");
			hs.put("yearJoined","css#div.mtop10:nth-child(3) div:nth-child(1) div:nth-child(9) div:nth-child(2)");
			hs.put("gender","css#div.mtop10:nth-child(3) div:nth-child(2) div:nth-child(1) div:nth-child(2)");
			hs.put("dateOfBirth","css#div.mtop10:nth-child(3) div:nth-child(2) div:nth-child(2) div:nth-child(2)");
			hs.put("placeOfBirth","css#div.mtop10:nth-child(3) div:nth-child(2) div:nth-child(3) div:nth-child(2)");
			hs.put("educationLevel","css#div.mtop10:nth-child(3) div:nth-child(2) div:nth-child(4) div:nth-child(2)");
			hs.put("maritalStatus","css#div.mtop10:nth-child(3) div:nth-child(2) div:nth-child(5) div:nth-child(2)");
			hs.put("children","css#div.mtop10:nth-child(3) div:nth-child(2) div:nth-child(6) div:nth-child(2)");
			hs.put("ownsFarm","css#div.mtop10:nth-child(3) div:nth-child(2) div:nth-child(7) div:nth-child(2)");
			hs.put("numberOfPlots","css#div.mtop10:nth-child(3) div:nth-child(2) div:nth-child(8) div:nth-child(2)");
			hs.put("farmSize","css#div.mtop10:nth-child(3) div:nth-child(2) div:nth-child(9) div:nth-child(2)");
			hs.put("totalTrees","css#div.mtop10:nth-child(3) div:nth-child(2) div:nth-child(11) div:nth-child(2)");
			hs.put("tressPerHa","css#div.mtop10:nth-child(3) div:nth-child(2) div:nth-child(12) div:nth-child(2)");
			hs.put("shadeTrees","css#div.mtop10:nth-child(3) div:nth-child(3) div:nth-child(1) div:nth-child(2)");
			
			//phone number block
			hs.put("phoneNumber","css#div.phone_container div.col-xs-4:nth-child(1)");
			
			//Farm Management Plan
			hs.put("fmpStatus", "css#div.pad10:nth-child(1) div.col-xs-2 span:nth-child(2)");
			hs.put("fmpGeneratedDate", "css#div.pad10:nth-child(1) div.col-xs-4 span:nth-child(2)");
			hs.put("fmpUpdatedDate", "css#div.pad10:nth-child(1) div.col-xs-3 span:nth-child(2)");
			
			
			//submitted Modules block
			hs.put("baselineSurvey", "css#div.pad10:nth-child(1) div.survey_name");
			hs.put("baselineSubmittedDate", "css#div.submitted_module_container div.pad10:nth-child(1)>div:nth-child(2) span:nth-child(2)");
			
			hs.put("annualSurvey", "css#div.pad10:nth-child(2) div.survey_name");
			hs.put("annualSubmittedDate", "css#div.submitted_module_container div.pad10:nth-child(2)>div:nth-child(2) span:nth-child(2)");
			
			return hs.get(locator);

		}catch(Exception e){
			System.out.println("Error occurred in POM classes :"+e);
			return null;
		}
	}



}
