package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomDashboard {

	public synchronized String pomDashboard(String locator)
	{
		
		try
		{
		Hashtable<String, String> hs = new Hashtable<String, String>();

		hs.put("lbl_pg_title", "xpath#//*[@class='page-header']/span");
		hs.put("lbl_login_alert", "xpath#//*[@role='alert']/p");
		hs.put("lbl_DB_FarmersReg", "xpath#//div[@class='row ofis-core-nomargin firstrow']/div[1]/div/h3");
		
		hs.put("lblActiveEnumerators", "xpath#//div[@class='row ofis-core-nomargin firstrow']/div[2]/div/h3");
		hs.put("lblSocialInfraGpsMapped", "xpath#//div[@class='row ofis-core-nomargin secondrow']/div[2]/div/h3");
		hs.put("lblFarmsGpsMapped", "xpath#//div[@class='row ofis-core-nomargin secondrow']/div[1]/div/h3");
				
		
		return hs.get(locator);
		}catch(Exception e){
			System.out.println("Error occurred in POM classes :"+e);
			return null;
		}
}

	

}
