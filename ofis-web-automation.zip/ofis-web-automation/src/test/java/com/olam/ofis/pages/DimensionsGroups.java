package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomDimensionsGroups;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class DimensionsGroups extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomDimensionsGroups pomDimensionsGroups = new PomDimensionsGroups();

	public DimensionsGroups(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderAllDimensionGroups;
	private String expectedPageHeaderEditAllDimensionGroups;
	private int expectedDimenionGroupId;
	private String expectedName;
	private int expectedPosition;
	private String expectedParent;
	private String expectedProduct;

	public synchronized void allDimensionsGroupsLoadExcelData() throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/AllDimensionsGroups.xlsx");

		expectedPageHeaderAllDimensionGroups = read.getCellData("AllDimensionsGroupsTC", "pageHeaderAllDimensionGroups", 1);
		expectedPageHeaderEditAllDimensionGroups = read.getCellData("AllDimensionsGroupsTC", "pageHeaderEditAllDimensionGroups", 1);
		expectedDimenionGroupId = read.getNumericCellData("AllDimensionsGroupsTC", "textDimenionGroupId", 1);
		expectedName = read.getCellData("AllDimensionsGroupsTC", "textName", 1);
		expectedPosition = read.getNumericCellData("AllDimensionsGroupsTC", "textPosition", 1);
		expectedParent = read.getCellData("AllDimensionsGroupsTC", "dropdownParent", 1);
		expectedProduct = read.getCellData("AllDimensionsGroupsTC", "dropdownProduct", 1);
	}

	public synchronized void settingsDimensionsDataClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_dimensiondata"), "Settings->Dimensions data");
	}

	public synchronized void dimensionsGroupsClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomDimensionsGroups.pomDimensionGroups("thumbnailDimensionsGroups"),
				"thumbnail Dimensions Groups");
	}

	public synchronized void dimensionsGroupsPageHeaderValidation() throws InterruptedException {
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(pomDimensionsGroups.pomDimensionGroups("Header_PageHeader"),
				expectedPageHeaderAllDimensionGroups, "PageHeader Dimenions Groups");
	}

	public synchronized void editDimensionsGroupsButtonClick() throws InterruptedException {
		Thread.sleep(7000);
		webElementMouseHoverAndClick(pomDimensionsGroups.pomDimensionGroups("btnEditDimensionsGroups"),
				"Edit dimensions groups button");
	}

	public synchronized void editDimensionsGroupsPageHeaderValidation() throws InterruptedException {
		Thread.sleep(10000);
		webAssertEqualsAlphaNumeric(pomDimensionsGroups.pomDimensionGroups("headerEditDimensionsGroups"),
				expectedPageHeaderEditAllDimensionGroups, "Edit Dimensions Groups Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomDimensionsGroups.pomDimensionGroups("btn_Cancel"), "cancel");
	}

	public synchronized void validateDimensionsGroupsValues() throws InterruptedException {
		Thread.sleep(7000);
		webGetAttributeValueAndAssertEqualsNumeric(
				pomDimensionsGroups.pomDimensionGroups("txtDimensionGroupId"), expectedDimenionGroupId,
				"Dimension Groups ID");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomDimensionsGroups.pomDimensionGroups("txtName"),
				expectedName, "Name");
		webGetAttributeValueAndAssertEqualsNumeric(
				pomDimensionsGroups.pomDimensionGroups("txtPosition"), expectedPosition, "Position");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(
				pomDimensionsGroups.pomDimensionGroups("drpParent"), expectedParent, "Parent dropdown");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(
				pomDimensionsGroups.pomDimensionGroups("drpProduct"), expectedProduct,
				"Product dropdown");
	}
}
