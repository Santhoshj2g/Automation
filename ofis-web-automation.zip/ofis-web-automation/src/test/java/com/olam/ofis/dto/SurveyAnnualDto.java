package com.olam.ofis.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SurveyAnnualDto {

	@JsonProperty("surveycompletedannual")
	List<SurveyModuleDto> surveyCompletedAnnual;

	public List<SurveyModuleDto> getSurveyCompletedAnnual() {
		return surveyCompletedAnnual;
	}

	public void setSurveyCompletedAnnual(List<SurveyModuleDto> surveyCompletedAnnual) {
		this.surveyCompletedAnnual = surveyCompletedAnnual;
	}
}
