package com.olam.ofis.pom;

import java.util.Hashtable;

import com.olam.ofis.wrappers.Functions;

public class PomTasks extends Functions {

	public String pomTasks(String locator) {
		try {
			Hashtable<String, String> htable = new Hashtable<>();
			htable.put("taskmenu", "xpath#//a[@routerlink='/tasks']");
			// tasklist //a[@routerlink='tasks/task-list']/span[@class='glyphicon
			// glyphicon-list']//
			htable.put("EmuneratorTask", "xpath#//*[@routerlink='tasks/task-list']");
			htable.put("reviewSubmittedData", "css#a[routerlink='tasks/review-submitted']");
			// text descrpition
			htable.put("textarea", "id#tasktext");
			// ChooseRecipient
			htable.put("ChooseRecipientsbutton",
					"xpath#//div[@class='chooseRecipientDiv']/button[contains(text(),'Choose Recipients')]");

			// choose recipient dropdown
			htable.put("countrydropdown", "xpath#(//*[@class='ng-select-container'])[1]");
			htable.put("FarmerGroup", "xpath#(//*[@class='ng-select-container'])[2]");
			htable.put("Region", "xpath#(//*[@class='ng-select-container'])[3]");
			htable.put("Section", "xpath#(//*[@class='ng-select-container'])[4]");
			htable.put("Enumerator Group", "xpath#(//*[@class='ng-select-container'])[5]");
			htable.put("Search by enumerator name or ID", "xpath#(//*[@class='ng-select-container'])[6]");
			// create
			htable.put("Createbutton", "xpath#//div[@class='chooseRecipientDiv']/button[contains(text(),'Create')]");

			// Click on the Manage GPX
			htable.put("ClickmanageGPX", "xpath#//*[@routerlink='tasks/manage-gpx']");
			// Search Type farmer name or id
			htable.put("Text_farmerID_GPX", "id#farmer_name_id");
			// Button_findfarmer_Manage_Gpx
			htable.put("Button_findfarmer_GPX", "xpath#//*[@value='Find Farmer']");

			// FileUpload_manageGPX
			htable.put("FileUpload_ManageGPX", "xpath#//input[@id='file']");
			htable.put("UploadFILEBUTTON", "xpath#//input[@value='Upload File']");

			// View GPX new windows your_farm_entry text field
			htable.put("YourFarmIDGPX", "id#your_farm_entry");
			htable.put("YourFarmSIZEGPX", "id#your_farm_size");
			htable.put("AprroverGPX", "xpath#//input[@value='Approve Gpx Import']");
			htable.put("Alertmessage", "xpath#//div[@role='alert']/p");
			
			//Tasks List page
			htable.put("popupAngularWebTable", "xpath#//div[@ref='eCenterContainer']");
			//htable.put("txtText", "css#textarea.taskDescription");
			htable.put("txtText", "css#div.cell-task");
			htable.put("lblLastUpdatedOn", "css#div>span.no-padding:nth-child(3)");
			htable.put("lblCreatedBy", "css#div>span.no-padding:nth-child(2)");
			htable.put("btnEditTaskDetails", "id#ofis-activities-tasks-edit-task");
			htable.put("btnAddAssignees", "id#ofis-enumeratorassignment-add");
			htable.put("btnEditCancel", "id#ofis-activities-tasks-cancel-edit-task");
			htable.put("btnChooseRecipients", "css#div button.ofis-activities-tasks-assign-enumerators-btn");
			htable.put("txtSearch", "css#div.modal[style='display: block;'] input.form-control");
			htable.put("btnSearch", "css#button.ofis-activities-tasks-search-btn");
			htable.put("chechbox1stRecord", "css#div.modal[style='display: block;'] td.text-left>input");
			htable.put("tooltipEnumeratorCount", "css#div.modal[style='display: block;'] div.tooltip-inner");
			htable.put("btnView", "css#div.modal[style='display: block;'] span.ofis-activities-tasks-enumerators-viewselected");
			htable.put("btnSaveEnumerator", "css#button.saveEnumeratorButton");
			htable.put("lblRecipients", "css#span.ofis-activities-tasks-assignments-text");
			htable.put("btnEnumeratorGroupAdd", "css#button.ofis-enumeratorgroup-add");
			htable.put("btnSelectEnumerator", "xpath#//button[@data-title='Select Enumerators']");
			htable.put("lblEnumerators", "css#span.ofis-activities-tasks-assignments-text");
			htable.put("gridName", "css#table.table-bordered>tbody>tr>td:nth-child(1)");
			htable.put("gridEnumeratorName", "css#div.modal[style='display: block;'] td");
			htable.put("gridAllNames", "css#div.modal[style='display: block;'] table.table-hover tr td:nth-child(2)");
			htable.put("btnEnumeratorCancel", "css#div.modal[style='display: block;'] button.ofis-activities-tasks-assignments-cancel");
			htable.put("drpCountryMainElement", "css#div.modal[style='display: block;'] ng-select.ng-select[formcontrolname=selectedCountry] span");
			htable.put("drpFarmerGroupMainElement", "css#div.modal[style='display: block;'] ng-select.ng-select[formcontrolname=selectedFarmergroup] span");
			htable.put("drpRegionMainElement", "css#div.modal[style='display: block;'] ng-select.ng-select[formcontrolname=selectedRegion] span");
			htable.put("drpSectionMainElement", "css#div.modal[style='display: block;'] ng-select.ng-select[formcontrolname=selectedSection] span");
			htable.put("drpEnumeratorGroupMainElement", "css#div.modal[style='display: block;'] ng-select.ng-select[formcontrolname=selectedEnumeratorGroup] span");
			htable.put("drpCountryAndFGSubElement", "css#div.ng-dropdown-panel-items div div");
			htable.put("drpRegionSectionSubElement", "css#div.ng-dropdown-panel-items span");
			
			//SMSCampaings
			htable.put("drpSMSCampCountryMainElement", "css#modal-container[style='display: block;'] ng-select[name=country] span");
			htable.put("drpSMSCampFarmerGroupMainElement", "css#modal-container[style='display: block;'] ng-select[name=farmerGroup] span");
			htable.put("drpSMSCampRegionMainElement", "css#modal-container[style='display: block;'] ng-select[name=region] span");
			htable.put("drpSMSCampSectionMainElement", "css#modal-container[style='display: block;'] ng-select[name=section] span");
			htable.put("drpSMSCampDistrictMainElement", "css#modal-container[style='display: block;'] ng-select[name=district] span");
			
			htable.put("txtFarmerSearch", "id#search");
			htable.put("btnFarmerSearch", "css#input.ofis-sms-farmer-search-btn");
			htable.put("chechboxFarmer1stRecord", "css#div.ofis-sms-section-checkbox-contain>input");
			htable.put("tooltipFarmerCount", "css#div.tooltip-inner");
			htable.put("btnFarmerView", "css#span.ofis-fg-sms-viewselected");
			htable.put("btnSaveFarmer", "css#input.ofis-sms-recipients-save");
			htable.put("lblFarmerRecipients", "css#span.ofis-activities-tasks-assignments-text");
			htable.put("gridAllFarmerNames", "css#table.ofis-sms-farmers-table tr td:nth-child(2)");
			
			//View Recipients
			htable.put("gridFarmerName", "css#div[ref=eBodyContainer] div[col-id=farmerName]");
			htable.put("gridOlamFarmerId", "css#div[ref=eBodyContainer] div[col-id=olamFarmerId]");
			
			//Review Submitted Data
			htable.put("titleReviewSubmittedData", "id#ofis-sm-title");
			
			return htable.get(locator);
		} catch (Exception e) {
			System.out.println("task locator:" + e.getMessage());
			return locator;
		}
	}

}
