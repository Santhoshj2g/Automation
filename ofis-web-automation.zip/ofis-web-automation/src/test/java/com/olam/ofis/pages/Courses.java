package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomCourses;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Courses extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomCourses pomCourses = new PomCourses();

	public Courses(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderCourses;
	private String expectedPageHeaderEditCourses;
	private String expectedTextName;
	private int expectedTargetPercentage;
	private int expectedTargetNumber;
	private String expectedProductAssign;
	private String expectedCourseAssignType;
	private String expectedNameFrench;
	private String expectedNameSpanish;
	private String expectedNameIndonesian;
	private String expectedNamePortuguese;
	private String expectedNameTurkish;
	private String expectedNameLao;
	private String expectedNameVietnamese;
	private String expectedNameThai;

	public synchronized void coursesLoadExcelData()
			throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/Courses.xlsx");

		expectedPageHeaderCourses = read.getCellData("CoursesTC", "pageHeaderCourses", 1);
		expectedPageHeaderEditCourses = read.getCellData("CoursesTC", "pageHeaderEditCourses", 1);
		expectedTextName = read.getCellData("CoursesTC", "textName", 1);
		expectedTargetPercentage = read.getNumericCellData("CoursesTC", "textTargetPercentage", 1);
		expectedTargetNumber = read.getNumericCellData("CoursesTC", "textTargetNumber", 1);
		expectedProductAssign = read.getCellData("CoursesTC", "dropdownProductAssign", 1);
		expectedCourseAssignType = read.getCellData("CoursesTC", "dropdownCourseAssignType", 1);

		expectedNameFrench = read.getCellData("CoursesTC", "textNameFr", 1);
		expectedNameSpanish = read.getCellData("CoursesTC", "textNameEs", 1);
		expectedNameIndonesian = read.getCellData("CoursesTC", "textNameId", 1);
		expectedNamePortuguese = read.getCellData("CoursesTC", "textNamePt", 1);
		expectedNameTurkish = read.getCellData("CoursesTC", "textNameTr", 1);
		expectedNameLao = read.getCellData("CoursesTC", "textNameLo", 1);
		expectedNameVietnamese = read.getCellData("CoursesTC", "textNameVi", 1);
		expectedNameThai = read.getCellData("CoursesTC", "textNameTh", 1);

	}

	public synchronized void settingsTrainingDataClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_trainingdata"), "Settings->Training data");
	}

	public synchronized void coursesClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomCourses.pomCourses("thumbnailCourses"), "thumbnail courses");
	}

	public synchronized void coursesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(pomCourses.pomCourses("Header_PageHeader"), expectedPageHeaderCourses,
				"PageHeader courses");
	}

	public synchronized void editCoursesButtonClick() throws InterruptedException {
		Thread.sleep(8000);
		webElementMouseHoverAndClick(pomCourses.pomCourses("btnEditCourses"), "Edit courses button");
	}

	public synchronized void editCoursesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(pomCourses.pomCourses("headerEditCourses"), expectedPageHeaderEditCourses,
				"Edit courses Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomCourses.pomCourses("btn_Cancel"), "cancel");
	}

	public synchronized void validateCoursesValues() throws InterruptedException {
		Thread.sleep(7000);
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomCourses.pomCourses("txtName"), expectedTextName,
				"Name");
		webGetAttributeValueAndAssertEqualsNumeric(pomCourses.pomCourses("txtTargetPercent"),
				expectedTargetPercentage, "Target Percentage");
		webGetAttributeValueAndAssertEqualsNumeric(pomCourses.pomCourses("txtTargetNum"),
				expectedTargetNumber, "Target Number");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(pomCourses.pomCourses("drpProductType"),
				expectedProductAssign, "Product Type dropdown");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(pomCourses.pomCourses("drpAssignmentType"),
				expectedCourseAssignType, "Assignment Type dropdown");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomCourses.pomCourses("txtNameFr"), expectedNameFrench,
				"French Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomCourses.pomCourses("txtNameEs"), expectedNameSpanish,
				"Spanish Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomCourses.pomCourses("txtNameId"), expectedNameIndonesian,
				"Bahasa Indonesian Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomCourses.pomCourses("txtNamePt"), expectedNamePortuguese,
				"Portuguese Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomCourses.pomCourses("txtNameTr"), expectedNameTurkish,
				"Turkish Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomCourses.pomCourses("txtNameLo"), expectedNameLao,
				"Lao Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomCourses.pomCourses("txtNameVi"), expectedNameVietnamese,
				"Vietnamese Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomCourses.pomCourses("txtNameTh"), expectedNameThai,
				"Thai Name");
		verifyWebCheckBoxIsSelected(pomCourses.pomCourses("chkActiveCourse"), "Active Course - checkbox");

	}
}
