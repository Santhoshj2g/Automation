package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomMenus {

	public synchronized String pomMenus(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("Menu_dashboard", "xpath#//*[@routerlink='/dashboard']");
			hs.put("Menu_analysis", "xpath#//*[@routerlink='/analysis']");
			hs.put("Menu_maps", "xpath#//*[@routerlink='/maps']");
			hs.put("Menu_farmerOverview", "xpath#//*[@routerlink='/farmer-group']");
			hs.put("Menu_transactions", "xpath#//*[@class='glyphicon glyphicon-transfer']");
			hs.put("Menu_tasks", "xpath#//*[@routerlink='/tasks']");
			hs.put("Menu_Settings", "xpath#//*[@routerlink='/settings']");
			hs.put("Settings","xpath#//span[@class='glyphicon glyphicon-cog']");
			hs.put("FarmDevelopmentPlan", "xpath#//h3[.='Farm Development Plan']");

			// Settings Sub Menus - switch to iframe
			hs.put("iFrame_OFISUser", "id#RefFrame");

			// Settings Sub Menus
			hs.put("Settings_ofis-users", "xpath#//*[@routerlink='/ofis-users']");
			hs.put("OFIS_users","xpath#//span[@class='glyphicon glyphicon-user']");
			hs.put("Settings_geographical", "xpath#//*[@routerlink='/geographical']");
			hs.put("Settings_farmargroups", "xpath#//*[@routerlink='/farmargroups']");
			hs.put("Settings_progspartsproducts", "xpath#//*[@routerlink='/progspartsproducts']");
			hs.put("Settings_questionnaires", "xpath#//*[@routerlink='/questionnaires']");
			hs.put("Settings_dimensiondata", "xpath#//*[@routerlink='/dimensiondata']");
			hs.put("Settings_fdp", "xpath#//*[@routerlink='/fdp']");
			hs.put("Settings_socialinfra", "xpath#//*[@routerlink='/socialinfra']");
			hs.put("Settings_transactionsData", "xpath#//*[@class='child_anchor_settings']");
			hs.put("Settings_trainingdata", "xpath#//*[@routerlink='/trainingdata']");
			hs.put("Settings_appVersions", "xpath#//*[@routerlink='/appdata']");
			
			//Popup Close Element
			hs.put("popupTitle", "css#div.ofis-modal-head");
			hs.put("titleReviewSubmittedData", "id#ofis-sm-title");
			hs.put("titleViewRecipients", "css#span.ofis-fg-modal-header");

			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
