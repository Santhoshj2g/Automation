package com.olam.ofis.pages;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.olam.ofis.reports.ExtTestMngr;
import com.olam.ofis.wrappers.Functions;

public class BaseTest extends Functions {

	public static int fileCount;
	public static String reportFileName;
	static Set<Integer> set;
	static CountDownLatch latch;
	static CountDownLatch afterLatch;
	private static boolean calledMyMethod;

	@BeforeSuite(alwaysRun = true)
	@Parameters({ "suiteType" })
	public void beforeSuite(String suiteType) throws Exception {

		System.out.println("Before Suite started to execute for Suite Type :" + suiteType);
		initializeFiles();
		createReport(suiteType);
	}

	@BeforeTest(alwaysRun = true)
	@Parameters({ "testCaseNameLogin", "testCaseDescLogin" })
	public void beforeTest(String testCaseNameLogin, String testCaseDescLogin) {
		try {

			killBrowserInTaskManager();
			ExtTestMngr.startTestCase(testCaseNameLogin, "<b>" + testCaseDescLogin + "</b>");
			launchApplication("URL");
			login();
			ExtTestMngr.endTestCase();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	@BeforeMethod(alwaysRun = true)
	@Parameters({ "testCaseName", "testCaseDesc", })
	public void beforeMethod(String testCaseName, String testCaseDesc) {
		try {

			ExtTestMngr.startTestCase(testCaseName, "<b>" + testCaseDesc + "</b>");

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	@AfterMethod(alwaysRun = true)
	public void aferMethod() {
		try {
			ExtTestMngr.endTestCase();

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	@AfterTest(alwaysRun = true)
	@Parameters({ "suiteType", "testCaseNameLogout", "testCaseDescLogout" })
	public void afterTest(String suiteType, String testCaseNameLogout, String testCaseDescLogout) throws Exception {

		try {
			ExtTestMngr.startTestCase(testCaseNameLogout, "<b>" + testCaseDescLogout + "</b>");
			logout();
			ExtTestMngr.endTestCase();

			File file = new File("./" + sysProperty.getProperty("extentReportFilePath") + "/" + reportFileName);
			double reportFileSizeInBytes = file.length();
			double reportFileSizeInKB = (reportFileSizeInBytes / 1024);
			int fileSize = (int) reportFileSizeInKB;

			if (fileSize > Integer.parseInt(sysProperty.getProperty("MaxReportFileSize"))) {

				if (suiteType.trim().equalsIgnoreCase(sysProperty.getProperty("ParallelSuiteType"))) {
					Thread t = new Thread() {
						public void run() {
							latch.countDown();
						}
					};
					t.start();
					try {
						latch.await(5, TimeUnit.MINUTES);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

				createReportSynchronized(suiteType);

				if (suiteType.trim().equalsIgnoreCase(sysProperty.getProperty("ParallelSuiteType"))) {
					Thread th = new Thread() {
						public void run() {
							afterLatch.countDown();
						}
					};
					th.start();
					try {
						afterLatch.await(20, TimeUnit.SECONDS);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				calledMyMethod = false;

			} else {
			}

		} catch (Exception e) {

			e.printStackTrace();

		} finally {

			try {
				ExtTestMngr.endTestCase();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

	}

	@AfterSuite(alwaysRun = true)
	public void afterSuite() {
		reduceHTMLReportSize(reportFileName);
		killBrowserInTaskManager();
		killBrowserDriverInTaskManager();
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				ExtTestMngr.endTestCase();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void initializeFiles() {
		try {
			sysProperty = new Properties();
			sysProperty.load(new FileInputStream(new File("./config/SystemConfig.properties")));

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void killBrowserInTaskManager() {
		try {

			if (sysProperty.getProperty("killBrowser").equalsIgnoreCase("true")) {
				if (sysProperty.getProperty("testBrowser").equalsIgnoreCase("firefox")) {
					Runtime.getRuntime().exec("taskkill /F /IM firefox.exe");
				} else if (sysProperty.getProperty("testBrowser").equalsIgnoreCase("chrome")) {
					Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");
				} else if (sysProperty.getProperty("testBrowser").equalsIgnoreCase("ie")) {
					Runtime.getRuntime().exec("taskkill /F /IM iexplore.exe");
				}
				Thread.sleep(2000);

			}
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void createReport(String suiteType) throws Exception {
		if (suiteType.trim().equalsIgnoreCase(sysProperty.getProperty("ParallelSuiteType"))) {
			latch = new CountDownLatch(Integer.parseInt(sysProperty.getProperty("No_of_Instances")));
			afterLatch = new CountDownLatch(Integer.parseInt(sysProperty.getProperty("No_of_Instances")));
		}

		fileCount++;
		String datetime = new SimpleDateFormat("_dd_MM_yyyy_HHmmss").format(new Date());
		reportFileName = sysProperty.getProperty("extentReportFileName") + "_"
				+ (sysProperty.getProperty("testBrowser").toUpperCase()) + "_" + datetime + "_" + fileCount + ".html";
		ExtTestMngr.startReportWithFileName(fileCount, reportFileName);
		ExtTestMngr.addReportInfo("Selenium Version", "2.53.0");
	}

	public synchronized void createReportSynchronized(String suiteType) throws Exception {

		if (calledMyMethod) {
			return;
		} else {
			calledMyMethod = true;
			reduceHTMLReportSize(reportFileName);
			createReport(suiteType);
			killBrowserInTaskManager();
		}
	}

	public void reduceHTMLReportSize(String reportFilePath) {
		try {
			String contents = FileUtils.readFileToString(
					new File("./" + sysProperty.getProperty("extentReportFilePath") + "/" + reportFilePath), "UTF-8");
			contents = contents.replaceAll("\r\n", "").replaceAll("\n", "").replaceAll("\t", "");
			FileWriter output = new FileWriter(
					"./" + sysProperty.getProperty("extentReportFilePath") + "/" + reportFilePath);
			BufferedWriter bw = new BufferedWriter(output);
			bw.write(contents);
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void killBrowserDriverInTaskManager() {
		try {
			if (sysProperty.getProperty("testBrowser").equalsIgnoreCase("firefox")) {
				Runtime.getRuntime().exec("taskkill /F /IM geckodriver.exe");
			} else if (sysProperty.getProperty("testBrowser").equalsIgnoreCase("chrome")) {
				Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
			} else if (sysProperty.getProperty("testBrowser").equalsIgnoreCase("ie")) {
				Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
			}
			Thread.sleep(2000);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
