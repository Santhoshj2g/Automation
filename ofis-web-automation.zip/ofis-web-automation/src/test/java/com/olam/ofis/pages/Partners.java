package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.pom.PomPartners;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Partners extends Functions {

	public Partners(RemoteWebDriver driver) {
		this.driver = driver;
	}

	PomPartners pomPartners = new PomPartners();
	PomMenus pomMenus = new PomMenus();

	private String expectedPageHeaderPartner;
	private String expectedPageHeaderEditPartner;
	private int expectedPartnerId;
	private String expectedName;

	public synchronized void allPartnersLoadExcelData()
			throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/AllPartners.xlsx");
		
		expectedPageHeaderPartner = read.getCellData("AllPartnersTC", "pageheader_partner", 2);
		expectedPageHeaderEditPartner = read.getCellData("AllPartnersTC", "pageheader_editpartner", 2);
		expectedPartnerId = read.getNumericCellData("AllPartnersTC", "text_partnerid", 2);
		expectedName = read.getCellData("AllPartnersTC", "text_name", 2);

		}
	public synchronized void settingsAllPartnersClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_progspartsproducts"), "Settings->ProgrammesPartnersProducts");
	}

	public synchronized void allPartnersClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomPartners.pomPartners("thumbnail_partner"), "thumbnail partners");
	}

	public synchronized void allPartnersPageHeaderValidation() throws InterruptedException {
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(pomPartners.pomPartners("pageheader_partner"), expectedPageHeaderPartner,
				"PageHeader partner");
	}

	public synchronized void editAllPartnerButtonClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementMouseHoverAndClick(pomPartners.pomPartners("btn_editpartner"), "Edit button");
	}

	public synchronized void editAllPartnersPageHeaderValidation() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomPartners.pomPartners("pageheader_editpartner"),
				expectedPageHeaderEditPartner, "Edit partner Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomPartners.pomPartners("btn_Cancel"), "cancel");
	}

	public synchronized void validateAllPartnersValues() throws InterruptedException {
		Thread.sleep(2000);
		webGetAttributeValueAndAssertEqualsNumeric(pomPartners.pomPartners("txt_partnerid"),
				expectedPartnerId, "partner id");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomPartners.pomPartners("txt_name"), expectedName,
				"partner Name");
		verifyWebCheckBoxIsSelected(pomPartners.pomPartners("chk_active"), "partner Active- checkbox");
	}

	
}
