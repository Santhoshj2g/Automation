package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomCompletionCriteria;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class CompletionCriteria extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomCompletionCriteria pomCompletionCriteria = new PomCompletionCriteria();

	public CompletionCriteria(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderCompletionCriteria;
	private String expectedPageHeaderEditCompletionCriteria;
	private String expectedTextName;

	public synchronized void completionCriteriaLoadExcelData()
			throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/CompletionCriteria.xlsx");

		expectedPageHeaderCompletionCriteria = read.getCellData("CompletionCriteriaTC", "pageHeaderCompletionCriteria", 1);
		expectedPageHeaderEditCompletionCriteria = read.getCellData("CompletionCriteriaTC", "pageHeaderEditCompletionCriteria", 1);
		expectedTextName = read.getCellData("CompletionCriteriaTC", "textName", 1);

	}

	public synchronized void settingsTrainingDataClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_trainingdata"), "Settings->Training data");
	}

	public synchronized void completionCriteriaClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomCompletionCriteria.pomCompletionCriteria("thumbnailCompletionCriteria"),
				"thumbnail Completion Criteria");
	}

	public synchronized void completionCriteriaPageHeaderValidation() throws InterruptedException {
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(pomCompletionCriteria.pomCompletionCriteria("Header_PageHeader"),
				expectedPageHeaderCompletionCriteria, "PageHeader Completion Criteria");
	}

	public synchronized void editCompletionCriteriaButtonClick() throws InterruptedException {
		Thread.sleep(12000);
		webElementMouseHoverAndClick(
				pomCompletionCriteria.pomCompletionCriteria("btnEditCompletionCriteria"),
				"Edit Completion Criteria button");
	}

	public synchronized void editCompletionCriteriaPageHeaderValidation() throws InterruptedException {
		Thread.sleep(5000);
		webAssertEqualsAlphaNumeric(
				pomCompletionCriteria.pomCompletionCriteria("headerEditCompletionCriteria"),
				expectedPageHeaderEditCompletionCriteria, "Edit Completion Criteria Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomCompletionCriteria.pomCompletionCriteria("btn_Cancel"), "cancel");
	}

	public synchronized void validateCompletionCriteriaValues() throws InterruptedException {
		Thread.sleep(7000);
		webGetAttributeValueAndAssertEqualsAlphaNumeric(
				pomCompletionCriteria.pomCompletionCriteria("txtName"), expectedTextName, "Name");

	}
}
