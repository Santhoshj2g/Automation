package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.pom.PomTrainingModules;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class TrainingModules extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomTrainingModules pomTrainingModules = new PomTrainingModules();

	public TrainingModules(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderTrainingModules;
	private String expectedPageHeaderEditTrainingModules;
	private String expectedName;
	private String expectedCourses;
	private String expectedCompletionCriterion;
	private String expectedNameFrench;
	private String expectedNameSpanish;
	private String expectedNameIndonesian;
	private String expectedNamePortuguese;
	private String expectedNameTurkish;
	private String expectedNameLao;
	private String expectedNameVietnamese;
	private String expectedNameThai;

	public synchronized void trainingModulesLoadExcelData()
			throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/TrainingModules.xlsx");

		expectedPageHeaderTrainingModules = read.getCellData("TrainingModulesTC", "pageHeaderTrainingModules", 1);
		expectedPageHeaderEditTrainingModules = read.getCellData("TrainingModulesTC", "pageHeaderEditTrainingModules", 1);
		expectedName = read.getCellData("TrainingModulesTC", "textName", 1);
		expectedCourses = read.getCellData("TrainingModulesTC", "dropdownCourses", 1);
		expectedCompletionCriterion = read.getCellData("TrainingModulesTC", "dropdownCompletionCriterion", 1);

		expectedNameFrench = read.getCellData("TrainingModulesTC", "textNameFr", 1);
		expectedNameSpanish = read.getCellData("TrainingModulesTC", "textNameEs", 1);
		expectedNameIndonesian = read.getCellData("TrainingModulesTC", "textNameId", 1);
		expectedNamePortuguese = read.getCellData("TrainingModulesTC", "textNamePt", 1);
		expectedNameTurkish = read.getCellData("TrainingModulesTC", "textNameTr", 1);
		expectedNameLao = read.getCellData("TrainingModulesTC", "textNameLo", 1);
		expectedNameVietnamese = read.getCellData("TrainingModulesTC", "textNameVi", 1);
		expectedNameThai = read.getCellData("TrainingModulesTC", "textNameTh", 1);

	}

	public synchronized void settingsTrainingDataClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_trainingdata"), "Settings->Training data");
	}

	public synchronized void trainingModulesClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomTrainingModules.pomTrainingModules("thumbnailTrainingModules"),
				"thumbnail Training Modules");
	}

	public synchronized void trainingModulesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(pomTrainingModules.pomTrainingModules("Header_PageHeader"),
				expectedPageHeaderTrainingModules, "PageHeader Training Modules");
	}

	public synchronized void editTrainingModulesButtonClick() throws InterruptedException {
		Thread.sleep(12000);
		webElementMouseHoverAndClick(pomTrainingModules.pomTrainingModules("btnEditTrainingModules"),
				"Edit training modules button");
	}

	public synchronized void editTrainingModulesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(5000);
		webAssertEqualsAlphaNumeric(pomTrainingModules.pomTrainingModules("headerEditTrainingModules"),
				expectedPageHeaderEditTrainingModules, "Edit Training Modules Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomTrainingModules.pomTrainingModules("btn_Cancel"), "cancel");
	}

	public synchronized void validateTrainingModulesValues() throws InterruptedException {
		Thread.sleep(7000);
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomTrainingModules.pomTrainingModules("txtName"),
				expectedName, "Name");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(
				pomTrainingModules.pomTrainingModules("drpCourseId"), expectedCourses,
				"course dropdown");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(
				pomTrainingModules.pomTrainingModules("drpCompletionCriterionId"),
				expectedCompletionCriterion, "drpCompletion Criterion dropdown");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomTrainingModules.pomTrainingModules("txtNameFr"),
				expectedNameFrench, "French Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomTrainingModules.pomTrainingModules("txtNameEs"),
				expectedNameSpanish, "Spanish Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomTrainingModules.pomTrainingModules("txtNameId"),
				expectedNameIndonesian, "Bahasa Indonesian Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomTrainingModules.pomTrainingModules("txtNamePt"),
				expectedNamePortuguese, "Portuguese Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomTrainingModules.pomTrainingModules("txtNameTr"),
				expectedNameTurkish, "Turkish Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomTrainingModules.pomTrainingModules("txtNameLo"),
				expectedNameLao, "Lao Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomTrainingModules.pomTrainingModules("txtNameVi"),
				expectedNameVietnamese, "Vietnamese Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomTrainingModules.pomTrainingModules("txtNameTh"),
				expectedNameThai, "Thai Name");
		verifyWebCheckBoxIsSelected(pomTrainingModules.pomTrainingModules("chkActiveTrainingModule"),
				"Active Training Module - checkbox");

	}
}
