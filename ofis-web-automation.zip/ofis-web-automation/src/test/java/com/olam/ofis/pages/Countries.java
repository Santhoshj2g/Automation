package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomCountries;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Countries extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomCountries pomCountries = new PomCountries();

	public Countries(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderAllCountries;
	private String expectedPageHeaderEditAllCountries;
	private int expectedCountryId;
	private String expectedCode;
	private String expectedName;
	private String expectedDiallingCode;
	private String expectedCenterLatitude;
	private String expectedCenterLongitude;
	private String expectedSmsOriginatorId;

	public synchronized void allCountryLoadExcelData()
			throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/AllCountries.xlsx");

		expectedPageHeaderAllCountries = read.getCellData("AllCountriesTC", "pageHeader_allcountries", 1);
		expectedPageHeaderEditAllCountries = read.getCellData("AllCountriesTC", "pageHeader_edit_allcountries", 1);
		expectedCountryId = read.getNumericCellData("AllCountriesTC", "text_countryid", 1);
		expectedCode = read.getCellData("AllCountriesTC", "text_code", 1);
		expectedName = read.getCellData("AllCountriesTC", "text_name", 1);
		expectedDiallingCode = read.getCellData("AllCountriesTC", "text_dialling_code", 1);
		expectedCenterLatitude = read.getCellData("AllCountriesTC", "text_center_latitude", 1);
		expectedCenterLongitude = read.getCellData("AllCountriesTC", "text_center_longitude", 1);
		expectedSmsOriginatorId = read.getCellData("AllCountriesTC", "text_sms_originator_id", 1);

	}

	public synchronized void settingsGeographicDataclick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_geographical"), "Settings->GeographicalData");
	}

	public synchronized void navigateToIframe() throws InterruptedException {

		Thread.sleep(1000);
		iFrameSwitchTo(pomMenus.pomMenus("iFrame_OFISUser"), "iFrame-OFISGeographicalData");
	}

	public synchronized void switchoutFromIframe() throws InterruptedException {

		Thread.sleep(1000);
		iFrameSwitchOut("iFrame-OFIS Geographical data");
	}

	public synchronized void allCountriesClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomCountries.pomCountries("thumbnail_allcountries"), "thumbnail all countries");
	}

	public synchronized void allCountriesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomCountries.pomCountries("Header_allcountries_PageHeader"),
				expectedPageHeaderAllCountries, "PageHeader all countries");
	}

	public synchronized void editAllCountriesButtonClick() throws InterruptedException {
		Thread.sleep(3000);
		webElementMouseHoverAndClick(pomCountries.pomCountries("btn_edit_allcountries"),
				"Edit all countries button");
	}

	public synchronized void editAllCountriesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(3000);
		webAssertEqualsAlphaNumeric(pomCountries.pomCountries("Header_edit_allcountries"),
				expectedPageHeaderEditAllCountries, "Edit all countries Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomCountries.pomCountries("btn_Cancel"), "cancel");
	}

	public synchronized void validateAllCountryValues() throws InterruptedException {
		Thread.sleep(2000);
		webGetAttributeValueAndAssertEqualsNumeric(pomCountries.pomCountries("txt_countryId"),
				expectedCountryId, "country id");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomCountries.pomCountries("txt_code"),
				expectedCode, "code");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomCountries.pomCountries("txt_countryName"),
				expectedName, "name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomCountries.pomCountries("txt_diallingCode"),
				expectedDiallingCode, "dialling code");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomCountries.pomCountries("txt_centreLat"),
				expectedCenterLatitude, "center latitude");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomCountries.pomCountries("txt_centreLng"),
				expectedCenterLongitude, "longitude");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomCountries.pomCountries("txt_smsOriginatorId"),
				expectedSmsOriginatorId, "sms originator id");
		verifyWebCheckBoxIsSelected(pomCountries.pomCountries("chk_olam_country"), "olam country- checkbox");
		verifyWebCheckBoxIsSelected(pomCountries.pomCountries("chk_activecountry"), "active country- checkbox");
	}
}
