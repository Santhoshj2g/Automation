package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomTaskList {

	public synchronized String pomTaskList(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("thumbnailTaskList", "xpath#//*[@class='col-sm-6 col-md-4 tasks-individual-grid'][1]/a/div/div/p");
			hs.put("Header_PageHeader", "xpath#//*[@class='page-header']");

			// Task List page
			hs.put("grdHeaderTaskText", "xpath#//*[@class='ag-header-cell ag-header-cell-sortable'][1]/div[2]/div");
			hs.put("grdTaskText", "css#div[row-index='0'] div[col-id='tasksDescription']");
			hs.put("grdCreatedBy", "css#div[row-index='0'] div[col-id='userName']");
			hs.put("grdLastUpdatedOn", "css#div[row-index='0'] div[col-id='updatedAt']");
			
			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
