package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.pom.PomRegions;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Regions extends Functions {

	public Regions(RemoteWebDriver driver) {
		this.driver = driver;
	}

	PomMenus pomMenus = new PomMenus();
	PomRegions pomRegions = new PomRegions();

	private String expectedPageHeaderAllRegions;
	private String expectedPageHeaderEditAllRegions;
	private int expectedRegionId;
	private String expectedCountry;
	private String expectedName;
	private String expectedCentreLatitude;
	private String expectedCentreLongitude;

	public synchronized void allRegionLoadExcelData() throws Exception {
		// Expected data is retrieved from Excel sheet and it will be compared with
		// actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/AllRegion.xlsx");

		expectedPageHeaderAllRegions = read.getCellData("AllRegionTC", "PageHeader_region", 1);
		expectedPageHeaderEditAllRegions = read.getCellData("AllRegionTC", "PageHeader_edit_region", 2);
		expectedRegionId = read.getNumericCellData("AllRegionTC", "text_region_id", 2);
		expectedCountry = read.getCellData("AllRegionTC", "dropdown_country", 2);
		expectedName = read.getCellData("AllRegionTC", "text_name", 2);
		expectedCentreLatitude = read.getCellData("AllRegionTC", "text_centre_lat", 2);
		expectedCentreLongitude = read.getCellData("AllRegionTC", "text_centre_lng", 2);
	}

	public synchronized void settingsGeographicDataClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"), pomMenus.pomMenus("Settings_geographical"),
				"Settings->GeographicalData");
	}

	public synchronized void navigateToIframe() throws InterruptedException {

		Thread.sleep(1000);
		iFrameSwitchTo(pomMenus.pomMenus("iFrame_OFISUser"), "iFrame-OFISGeographicalData");
	}

	public synchronized void switchoutFromIframe() throws InterruptedException {

		Thread.sleep(1000);
		iFrameSwitchOut("iFrame-OFIS Geographical data");
	}

	public synchronized void allRegionClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomRegions.pomRegions("thumbnail_region"), "thumbnail all regions");
	}

	public synchronized void allRegionsPageHeaderValidation() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomRegions.pomRegions("Header_PageHeader"), expectedPageHeaderAllRegions,
				"PageHeader all regions");
	}

	public synchronized void editAllRegionButtonClick() throws InterruptedException {
		Thread.sleep(3000);
		webElementMouseHoverAndClick(pomRegions.pomRegions("btn_edit_allregions"), "Edit all regions button");
	}

	public synchronized void editAllRegionPageHeaderValidation() throws InterruptedException {
		Thread.sleep(3000);
		webAssertEqualsAlphaNumeric(pomRegions.pomRegions("Header_edit_allcountries"), expectedPageHeaderEditAllRegions,
				"Edit all regions Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomRegions.pomRegions("btn_Cancel"), "cancel");
	}

	public synchronized void validateAllRegionValues() throws InterruptedException {
		Thread.sleep(2000);
		webGetAttributeValueAndAssertEqualsNumeric(pomRegions.pomRegions("txt_regionid"), expectedRegionId,
				"region id");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(pomRegions.pomRegions("drp_country"), expectedCountry,
				"Country dropdown");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomRegions.pomRegions("txt_name"), expectedName, "name");
		/*
		 * webGetAttributeValueAndAssertEqualsAlphaNumeric(POM_Region.pomRegions(
		 * "txt_centre_lat"), data_text_centre_lat2, "Center Latitude");
		 * webGetAttributeValueAndAssertEqualsAlphaNumeric(POM_Region.pomRegions(
		 * "txt_centre_lng"), data_text_centre_lng2, "Center Longitude");
		 */
		verifyWebCheckBoxIsSelected(pomRegions.pomRegions("chk_active"), "active region - checkbox");

	}

}
