package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.pom.PomSocialInfrastructurePoint;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class SocialInfrastructurePoint extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomSocialInfrastructurePoint pomSocialInfrastructurePoint = new PomSocialInfrastructurePoint();

	public SocialInfrastructurePoint(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderSocialInfraPoint;
	
	private String expectedName;
	private String expectedType;
	private String expectedCountry;
	private String expectedRegion;
	private String expectedDistrict;

	public synchronized void socialInfraPointLoadExcelData() throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/SocialInfrastructurePoint.xlsx");

		expectedPageHeaderSocialInfraPoint = read.getCellData("SocialInfrastructurePointTC", "pageHeaderSocialInfrastructurePoint", 1);
		expectedName = read.getCellData("SocialInfrastructurePointTC", "gridName", 1);
		expectedType = read.getCellData("SocialInfrastructurePointTC", "gridType", 1);
		expectedCountry = read.getCellData("SocialInfrastructurePointTC", "gridCountry", 1);
		expectedRegion = read.getCellData("SocialInfrastructurePointTC", "gridRegion", 1);
		expectedDistrict = read.getCellData("SocialInfrastructurePointTC", "gridDistrict", 1);
	}

	public synchronized void settingsSocialInfraPointClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_socialinfra"), "Settings->Social Infrastructure point");
	}

	public synchronized void socialInfraPointPageHeaderValidation() throws InterruptedException {
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(
				pomSocialInfrastructurePoint.pomSocialInfrastructurePoint("Header_PageHeader"),
				expectedPageHeaderSocialInfraPoint, "PageHeader Social Infrastructure point");
	}

	public synchronized void validateSocialInfraPointValues() throws InterruptedException {
		Thread.sleep(5000);		
		webAssertEqualsAlphaNumeric(
				pomSocialInfrastructurePoint.pomSocialInfrastructurePoint("grdName"), expectedName,
				"grid - Name");
		webAssertEqualsAlphaNumeric(pomSocialInfrastructurePoint.pomSocialInfrastructurePoint("grdType"),
				expectedType, "grid - Type");
		webAssertEqualsAlphaNumeric(pomSocialInfrastructurePoint.pomSocialInfrastructurePoint("grdCountry"),
				expectedCountry, "grid - Country");
		webAssertEqualsAlphaNumeric(pomSocialInfrastructurePoint.pomSocialInfrastructurePoint("grdRegion"),
				expectedRegion, "grid - Region");
		webAssertEqualsAlphaNumeric(pomSocialInfrastructurePoint.pomSocialInfrastructurePoint("grdDistrict"),
				expectedDistrict, "grid - District");
	}
}
