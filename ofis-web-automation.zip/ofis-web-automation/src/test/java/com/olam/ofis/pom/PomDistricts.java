package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomDistricts {

	public synchronized String pomDistricts(String locator)
	{
		
		try
		{
		Hashtable<String, String> hs = new Hashtable<String, String>();
		
		hs.put("thumbnail_districts", "xpath#//*[@class='col-sm-6 col-md-4'][3]/a/div/div");
		hs.put("Header_PageHeader", "xpath#//*[@class='page-header ofisHeader']");
		hs.put("btn_AddDistricts", "xpath#//*[@class='btn btn-primary']");
		
		hs.put("drp_region", "xpath#//*[@formcontrolname='regionId']");
		hs.put("drp_region_CENTRE", "xpath#//*[@formcontrolname='regionId']/optgroup[4]/option[42]");
		hs.put("txt_name", "id#name");
		hs.put("chk_active", "xpath#//input[@type='checkbox']");
		hs.put("btn_add_region", "xpath#//*[@class='btn btn-primary']");
		
		//Edit all regions page
		hs.put("btn_edit_alldistricts", "css#div[row-index='0'] div[col-id='0']");
		hs.put("Header_edit_alldistricts", "xpath#//*[@class='page-header ofisHeader']");
		hs.put("txt_districtid", "name#district");
		hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");
		
		
		return hs.get(locator);
		}catch(Exception e){
			System.out.println("Error occurred in POM classes :"+e);
			return null;
		}
}

	

}
