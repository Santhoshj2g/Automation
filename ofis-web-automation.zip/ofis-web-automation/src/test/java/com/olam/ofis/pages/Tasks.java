package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomFarmerOverview;
import com.olam.ofis.pom.PomLogin;
import com.olam.ofis.pom.PomTasks;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Tasks extends Functions {

	PomTasks PomTasksPage = new PomTasks();
	PomLogin login;
	PomTasks ts;
	ReadExcel fromexcel;
	PomFarmerOverview PomFarmerOverviewPage = new PomFarmerOverview();
	
	public Tasks(RemoteWebDriver driver) {
		this.driver = driver;
	}

	
	public Tasks() {
		login = new PomLogin();
		ts = new PomTasks();

	}

	public synchronized void TaskClick(String testcaseName, String testdatasheet, String testCategory)
			throws Exception {
		fromexcel = new ReadExcel(testdatasheet);
		String textdesc = fromexcel.getCellData(testCategory, "Task Description", 1);

		String countrytask = fromexcel.getCellData(testCategory, "Country", 1);
		System.out.println(countrytask);

		try {
			//LaunchApplication("URL");
			WebEditEnterText(login.pomLogin("txt_email"), "jayan.alwar@olamnet.com", "EmailID");
			WebEditEnterText(login.pomLogin("txt_password"), "olam@123", "Password");
			webElementClick(login.pomLogin("check_Policy"), "Policy Agreement");
			webElementClick(login.pomLogin("btn_Submit"), "Login Button");
			waitTill(5000);
			webElementClick(ts.pomTasks("taskmenu"), "taskmenu");
			waitTill(5000);
			System.out.println("task click");
			webElementClick(ts.pomTasks("EmuneratorTask"), "task list");
			waitTill(5000);
			WebEditEnterText(ts.pomTasks("textarea"), textdesc, "text description");
			webElementClick(ts.pomTasks("ChooseRecipientsbutton"), "chooseRecipient");
			waitTill(20000);
			webDropdownSelect(ts.pomTasks("countrydropdown"), countrytask, "countryfield");
			waitTill(5000);

		} catch (Exception e) {

			System.out.println("TaskClick " + e.getMessage());
		}

		}

	public synchronized void searchEnumerator(String getValueFromPOM, String strFieldName) throws Exception {
		try {
		Thread.sleep(7000);
		checkBoxSelect(PomTasksPage.pomTasks("chechbox1stRecord"));
		getTextFromElement(PomTasksPage.pomTasks("tooltipEnumeratorCount"));
		webElementClick(PomTasksPage.pomTasks("btnView"), "View");
		Thread.sleep(3000);
		assertStringContainsAlphaNumeric(PomTasksPage.pomTasks("tooltipEnumeratorCount"),
				"tooltip Enumerator Count");
		webElementClick(PomTasksPage.pomTasks("btnSaveEnumerator"), "Save Enumerator");
		Thread.sleep(7000);
		assertStringContainsAlphaNumeric(PomTasksPage.pomTasks(getValueFromPOM),
				strFieldName);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public synchronized void searchEnumeratorAndValidateValues(String getColumnValues, String searchString, String strFieldName) throws Exception {
		try {
		Thread.sleep(10000);
		WebEditEnterText(PomTasksPage.pomTasks("txtSearch"), searchString, "Search");
		Thread.sleep(3000);
		webElementClick(PomTasksPage.pomTasks("btnSearch"), "Search");
		Thread.sleep(7000);
		webSpecificColumnValuesFetchAndValidate(PomTasksPage.pomTasks(getColumnValues), searchString,strFieldName);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public synchronized void dropdownPopulatingValueValidation() throws Exception{
		
		try {
			Thread.sleep(5000);
			webDropdownClickAndCheckNonEmpty(PomTasksPage.pomTasks("drpCountryMainElement"),PomTasksPage.pomTasks("drpCountryAndFGSubElement"),"No items found","Country");
			webDropdownClickAndCheckNonEmpty(PomTasksPage.pomTasks("drpFarmerGroupMainElement"),PomTasksPage.pomTasks("drpCountryAndFGSubElement"),"No items found","Farmer Group");
			webDropdownClickAndCheckNonEmpty(PomTasksPage.pomTasks("drpRegionMainElement"),PomTasksPage.pomTasks("drpRegionSectionSubElement"),"No items found","Region");
			webDropdownClickAndCheckNonEmpty(PomTasksPage.pomTasks("drpSectionMainElement"),PomTasksPage.pomTasks("drpRegionSectionSubElement"),"No items found","Section");
			//webDropdownClickAndCheckNonEmpty(PomTasksPage.pomTasks("drpEnumeratorGroupMainElement"),PomTasksPage.pomTasks("drpCountryAndFGSubElement"),"No items found","Enumerator Group");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public synchronized void dropdownPopulatingValueValidationSMSCampaigns() throws Exception{
		
		try {
			Thread.sleep(10000);
			webDropdownClickAndCheckNonEmpty(PomTasksPage.pomTasks("drpSMSCampCountryMainElement"),PomTasksPage.pomTasks("drpCountryAndFGSubElement"),"No items found","Country");
			webDropdownClickAndCheckNonEmpty(PomTasksPage.pomTasks("drpSMSCampFarmerGroupMainElement"),PomTasksPage.pomTasks("drpCountryAndFGSubElement"),"No items found","Farmer Group");
			webDropdownClickAndCheckNonEmpty(PomTasksPage.pomTasks("drpSMSCampRegionMainElement"),PomTasksPage.pomTasks("drpRegionSectionSubElement"),"No items found","Region");
			webDropdownClickAndCheckNonEmpty(PomTasksPage.pomTasks("drpSMSCampSectionMainElement"),PomTasksPage.pomTasks("drpRegionSectionSubElement"),"No items found","Section");
			webDropdownClickAndCheckNonEmpty(PomTasksPage.pomTasks("drpSMSCampDistrictMainElement"),PomTasksPage.pomTasks("drpCountryAndFGSubElement"),"No items found","Enumerator Group");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	
	public synchronized void searchFarmerAndValidateValues(String getColumnValues, String searchString, String strFieldName,String getValueFromPOM, String strFieldName2) throws Exception {
		try {
		Thread.sleep(7000);
		WebEditEnterText(PomTasksPage.pomTasks("txtFarmerSearch"), searchString, "Search");
		Thread.sleep(3000);
		webElementClick(PomTasksPage.pomTasks("btnFarmerSearch"), "Search");
		Thread.sleep(14000);
		webSpecificColumnValuesFetchAndValidate(PomTasksPage.pomTasks(getColumnValues), searchString,strFieldName);
		
		checkBoxSelect(PomTasksPage.pomTasks("chechboxFarmer1stRecord"));
		getTextFromElement(PomTasksPage.pomTasks("tooltipFarmerCount"));
		webElementClick(PomTasksPage.pomTasks("btnFarmerView"), "View");
		Thread.sleep(3000);
		assertStringContainsAlphaNumeric(PomTasksPage.pomTasks("tooltipFarmerCount"),
				"tooltip Farmer Count");
		webElementClick(PomTasksPage.pomTasks("btnSaveFarmer"), "Save");
		Thread.sleep(7000);
		assertStringContainsAlphaNumeric(PomTasksPage.pomTasks(getValueFromPOM),
				strFieldName2);
		//popup View Recipients validation
		/*webElementClick(PomTasksPage.pomTasks("lblFarmerRecipients"), "Recipients");
		assertStringContainsAlphaNumeric(PomTasksPage.pomTasks("gridFarmerName"), 1, "Farmer Name");
		assertStringContainsAlphaNumeric(PomTasksPage.pomTasks("gridOlamFarmerId"), 1, "Olam Farmer Id");
		navigateToPopupAndClose("titleViewRecipients");*/
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public synchronized void reviewSubmittedDataAndFarmerProfileValidation(String compareValue) throws Exception{
		try {
		
		webTableFetchAndClickSpecificValue(PomTasksPage.pomTasks("popupAngularWebTable"), 7, compareValue,1);
		Thread.sleep(10000);
		getParentWindowAndSwitchToSpecificTab(1, "Farmer Profile");
		assertStringContainsAlphaNumeric(PomTasksPage.pomTasks("titleReviewSubmittedData"),7, compareValue);
		navigateToPopupAndClose("titleReviewSubmittedData");
		Thread.sleep(10000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileFarmerName"), 6, "Farmer Name");
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileFarmerGroup"), 5, "FARMER Group");
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileCountry"), 4, "Country");
		webDriverClose();
		driver.switchTo().window(parentWindowHandle);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}
