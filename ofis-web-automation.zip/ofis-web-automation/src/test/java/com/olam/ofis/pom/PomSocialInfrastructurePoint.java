package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomSocialInfrastructurePoint {

	public synchronized String pomSocialInfrastructurePoint(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("Header_PageHeader", "xpath#//*[@class='page-header']");
			
			// Permissions page
			hs.put("grdId", "xpath#//*[@ref='eBodyContainer']/div[1]/div[4]");
			hs.put("grdName", "xpath#//*[@ref='eBodyContainer']/div[1]/div[5]");
			hs.put("grdType", "xpath#//*[@ref='eBodyContainer']/div[1]/div[6]");
			hs.put("grdCountry", "xpath#//*[@ref='eBodyContainer']/div[1]/div[7]");
			hs.put("grdRegion", "xpath#//*[@ref='eBodyContainer']/div[1]/div[8]");
			hs.put("grdDistrict", "xpath#//*[@ref='eBodyContainer']/div[1]/div[9]");
			
			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
