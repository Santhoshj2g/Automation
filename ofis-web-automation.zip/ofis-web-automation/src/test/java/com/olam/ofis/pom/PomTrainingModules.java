package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomTrainingModules {

	public synchronized String pomTrainingModules(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("thumbnailTrainingModules", "xpath#//p[contains(text(), 'edit training modules')]");
			hs.put("Header_PageHeader", "xpath#//*[@class='page-header']");

			// Add Training Modules page
			hs.put("txtName", "id#name");
			hs.put("drpCourseId", "id#course_id");
			hs.put("drpCompletionCriterionId", "id#completioncriterion_id");

			hs.put("txtNameFr", "id#name_fr");
			hs.put("txtNameEs", "id#name_es");
			hs.put("txtNameId", "id#name_id");
			hs.put("txtNamePt", "id#name_pt");
			hs.put("txtNameTr", "id#name_tr");
			hs.put("txtNameLo", "id#name_lo");
			hs.put("txtNameVi", "id#name_vi");
			hs.put("txtNameTh", "id#name_th");
			hs.put("chkActiveTrainingModule", "id#active");

			// edit Training Modules page
			hs.put("btnEditTrainingModules", "css#div[row-index='0'] div[col-id='0'] a");
			hs.put("headerEditTrainingModules", "xpath#//*[@class='page-header']");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");

			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
