package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomQuestions;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Questions extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomQuestions pomQuestions = new PomQuestions();

	public Questions(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderAllQuestions;
	private String expectedPageHeaderEditAllQuestions;
	private String expectedSubModule;
	private String expectedDataType;
	private int expectedPosition;
	private String expectedDisplayType;
	private String expectedQuestion;
	private String expectedDisplayConfig;
	private String expectedStorageModel;
	private String expectedStorageColumn;
	private String expectedQuestionFrench;
	private String expectedQuestionSpanish;
	private String expectedQuestionIndonesian;
	private String expectedQuestionPortuguese;
	private String expectedQuestionTurkish;
	private String expectedQuestionLao;
	private String expectedQuestionVietnamese;
	private String expectedQuestionThai;

	public synchronized void allQuestionsLoadExcelData() throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/AllQuestions.xlsx");

		expectedPageHeaderAllQuestions = read.getCellData("AllQuestionsTC", "pageHeaderAllQuestions", 1);
		expectedPageHeaderEditAllQuestions = read.getCellData("AllQuestionsTC", "pageHeaderEditAllQuestions", 1);
		expectedSubModule = read.getCellData("AllQuestionsTC", "dropdownSubModule", 1);
		expectedDataType = read.getCellData("AllQuestionsTC", "dropdownDataType", 1);
		expectedPosition = read.getNumericCellData("AllQuestionsTC", "textPosition", 1);
		expectedDisplayType = read.getCellData("AllQuestionsTC", "dropdownDisplayType", 1);
		expectedQuestion = read.getCellData("AllQuestionsTC", "textQuestion", 1);
		expectedDisplayConfig = read.getCellData("AllQuestionsTC", "textDisplayConfig", 1);
		expectedStorageModel = read.getCellData("AllQuestionsTC", "textStorageModel", 1);
		expectedStorageColumn = read.getCellData("AllQuestionsTC", "textStorageColumn", 1);

		expectedQuestionFrench = read.getCellData("AllQuestionsTC", "textQuestionFr", 1);
		expectedQuestionSpanish = read.getCellData("AllQuestionsTC", "textQuestionEs", 1);
		expectedQuestionIndonesian = read.getCellData("AllQuestionsTC", "textQuestionId", 1);
		expectedQuestionPortuguese = read.getCellData("AllQuestionsTC", "textQuestionPt", 1);
		expectedQuestionTurkish = read.getCellData("AllQuestionsTC", "textQuestionTr", 1);
		expectedQuestionLao = read.getCellData("AllQuestionsTC", "textQuestionLo", 1);
		expectedQuestionVietnamese = read.getCellData("AllQuestionsTC", "textQuestionVi", 1);
		expectedQuestionThai = read.getCellData("AllQuestionsTC", "textQuestionTh", 1);

	}

	public synchronized void settingsAllQuestionsDataClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_questionnaires"), "Settings->Questionnaires data");
	}

	public synchronized void allQuestionsClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomQuestions.pomQuestions("thumbnailAllQuestions"), "thumbnail All Questions");
	}

	public synchronized void allQuestionsPageHeaderValidation() throws InterruptedException {
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(pomQuestions.pomQuestions("Header_PageHeader"),
				expectedPageHeaderAllQuestions, "PageHeader All Questions");
	}

	public synchronized void editAllQuestionsButtonClick() throws InterruptedException {
		Thread.sleep(12000);
		webElementMouseHoverAndClick(pomQuestions.pomQuestions("btnEditAllQuestions"),
				"Edit All Questions button");
	}

	public synchronized void editAllQuestionsPageHeaderValidation() throws InterruptedException {
		Thread.sleep(5000);
		webAssertEqualsAlphaNumeric(pomQuestions.pomQuestions("headerEditAllQuestions"),
				expectedPageHeaderEditAllQuestions, "Edit All Questions Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomQuestions.pomQuestions("btn_Cancel"), "cancel");
	}

	public synchronized void validateAllQuestionsValues() throws InterruptedException {
		Thread.sleep(7000);
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(pomQuestions.pomQuestions("drpSubmodule"),
				expectedSubModule, "Sub module dropdown");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(pomQuestions.pomQuestions("drpDataType"),
				expectedDataType, "drpDataType");
		webGetAttributeValueAndAssertEqualsNumeric(pomQuestions.pomQuestions("txtPosition"),
				expectedPosition, "Position");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(
				pomQuestions.pomQuestions("drpDisplayType"), expectedDisplayType, "Display Type");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomQuestions.pomQuestions("txtQuestion"),
				expectedQuestion, "Question");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(
				pomQuestions.pomQuestions("txtDisplayConfiguration"), expectedDisplayConfig,
				"Display Configuration");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomQuestions.pomQuestions("txtStorageModel"),
				expectedStorageModel, "Storage Model");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomQuestions.pomQuestions("txtStorageColumn"),
				expectedStorageColumn, "Storage Column");
		verifyWebCheckBoxIsSelected(pomQuestions.pomQuestions("chkActiveQuestion"), "Active Question - checkbox");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomQuestions.pomQuestions("txtQuestionFr"),
				expectedQuestionFrench, "French Question");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomQuestions.pomQuestions("txtQuestionEs"),
				expectedQuestionSpanish, "Spanish Question");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomQuestions.pomQuestions("txtQuestionId"),
				expectedQuestionIndonesian, "Bahasa Indonesian Question");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomQuestions.pomQuestions("txtQuestionPt"),
				expectedQuestionPortuguese, "Portuguese Question");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomQuestions.pomQuestions("txtQuestionTr"),
				expectedQuestionTurkish, "Turkish Question");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomQuestions.pomQuestions("txtQuestionLo"),
				expectedQuestionLao, "Lao Question");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomQuestions.pomQuestions("txtQuestionVi"),
				expectedQuestionVietnamese, "Vietnamese Question");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomQuestions.pomQuestions("txtQuestionTh"),
				expectedQuestionThai, "Thai Question");
		
	}

}
