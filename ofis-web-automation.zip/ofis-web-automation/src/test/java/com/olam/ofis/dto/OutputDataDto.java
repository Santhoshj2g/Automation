package com.olam.ofis.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OutputDataDto {

	@JsonProperty("outputdata")
	SurveyAnnualDto outputData;
	Boolean hasError;
	private String errors;

	public String getErrors() {
		return errors;
	}

	public void setErrors(String errors) {
		this.errors = errors;
	}

	public Boolean getError() {
		return hasError;
	}

	public void setError(Boolean hasError) {
		this.hasError = hasError;
	}

	public SurveyAnnualDto getOutputData() {
		return outputData;
	}

	public void setOutputData(SurveyAnnualDto outputData) {
		this.outputData = outputData;
	}

}