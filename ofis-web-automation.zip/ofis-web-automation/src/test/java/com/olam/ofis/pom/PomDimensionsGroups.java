package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomDimensionsGroups {

	public synchronized String pomDimensionGroups(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("thumbnailDimensionsGroups", "xpath#//*[@class='col-sm-6 col-md-4'][2]/a/div/div/p");
			hs.put("Header_PageHeader", "xpath#//*[@class='page-header']");

			// Add Dimensions Groups page
			hs.put("txtName", "id#name");
			hs.put("txtPosition", "id#position");
			hs.put("drpParent", "id#parentId");
			hs.put("drpProduct", "id#productId");
						
			// edit Dimensions Groups page
			hs.put("btnEditDimensionsGroups", "xpath#//*[@class='table table-hover sectionAll']/tbody[1]/tr[1]/td[4]");
			hs.put("headerEditDimensionsGroups", "xpath#//*[@class='page-header']");
			hs.put("txtDimensionGroupId", "id#id");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");

			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
