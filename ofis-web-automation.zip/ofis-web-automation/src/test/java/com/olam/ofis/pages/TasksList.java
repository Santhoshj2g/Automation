package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.pom.PomTaskList;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class TasksList extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomTaskList pomTaskList = new PomTaskList();

	public TasksList(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderTasksList;
	private String expectedTaskText;
	private String expectedCreatedBy;
	private String expectedLastUpdatedOn;

	public synchronized void tasksListLoadExcelData()
			throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/TasksList.xlsx");

		expectedPageHeaderTasksList = read.getCellData("TasksListTC", "pageHeaderTasksList", 1);
		expectedTaskText = read.getCellData("TasksListTC", "gridTaskText", 1);
		expectedCreatedBy = read.getCellData("TasksListTC", "gridCreatedBy", 1);
		expectedLastUpdatedOn = read.getCellData("TasksListTC", "gridLastUpdatedOn", 1);
	}

	public synchronized void menuTasksClick() throws InterruptedException {
		Thread.sleep(10000);
		webElementClick(pomMenus.pomMenus("Menu_tasks"), "Menu Tasks");
	}

	public synchronized void thumbnailTasksListClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomTaskList.pomTaskList("thumbnailTaskList"), "thumbnail Task List");
	}

	public synchronized void tasksListPageHeaderValidation() throws InterruptedException {
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(pomTaskList.pomTaskList("Header_PageHeader"), expectedPageHeaderTasksList,
				"PageHeader Tasks List");
	}

	public synchronized void sortTasksListGridUsingTaskTextColumn() throws InterruptedException {
		Thread.sleep(9000);
		webElementClick(pomTaskList.pomTaskList("grdHeaderTaskText"), "sort Task list grid using Task Text column");
	}

	public synchronized void validateTasksListValues() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomTaskList.pomTaskList("grdTaskText"), expectedTaskText,
				"grid Task Text");
		webAssertEqualsAlphaNumeric(pomTaskList.pomTaskList("grdCreatedBy"), expectedCreatedBy,
				"grid Created By");
		webAssertEqualsAlphaNumeric(pomTaskList.pomTaskList("grdLastUpdatedOn"), expectedLastUpdatedOn,
				"grid Last Updated On");
	}
}
