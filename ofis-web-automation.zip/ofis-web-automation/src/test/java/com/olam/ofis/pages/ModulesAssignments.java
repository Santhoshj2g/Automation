package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomModuleAssignments;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class ModulesAssignments extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomModuleAssignments pomModulesAssignments = new PomModuleAssignments();

	public ModulesAssignments(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderAllModulesAssignment;
	private String expectedPageHeaderEditAllModulesAssignment;
	private int expectedModuleAssignmentId;
	private String expectedModule;
	private int expectedModuleAssignmentId2;
	private String expectedModuleAssignmentType;
	private int expectedRecurringFrequency;
	private String expectedRecurringType;

	public synchronized void allMolulesAssignmentLoadExcelData()
			throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/AllModulesAssignments.xlsx");
		
		expectedPageHeaderAllModulesAssignment = read.getCellData("AllModuleAssignmentsTC", "pageHeaderAllModulesAssign", 1);
		expectedPageHeaderEditAllModulesAssignment = read.getCellData("AllModuleAssignmentsTC", "pageHeaderEditAllModulesAssign", 1);
		expectedModuleAssignmentId = read.getNumericCellData("AllModuleAssignmentsTC", "textModuleAssignID1", 1);
		expectedModule = read.getCellData("AllModuleAssignmentsTC", "dropdownModule", 1);
		expectedModuleAssignmentId2 = read.getNumericCellData("AllModuleAssignmentsTC", "textModuleAssignID2", 1);
		expectedModuleAssignmentType = read.getCellData("AllModuleAssignmentsTC", "dropdownModuleAssignType", 1);
		expectedRecurringFrequency = read.getNumericCellData("AllModuleAssignmentsTC", "textRecurFreq", 1);
		expectedModuleAssignmentType = read.getCellData("AllModuleAssignmentsTC", "dropdownModuleAssignType", 1);
		expectedRecurringType = read.getCellData("AllModuleAssignmentsTC", "textRecurType", 1);
		
	}

	public synchronized void settingsQuestionnaireDataClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_questionnaires"), "Settings->Questionaire data");
	}

	public synchronized void allMolulesAssignmentsClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomModulesAssignments.pomModulesAssignments("thumbnailAllModulesAssignments"),
				"thumbnail all modules assignments");
	}

	public synchronized void allModulesAssignmentsPageHeaderValidation() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomModulesAssignments.pomModulesAssignments("Header_PageHeader"),
				expectedPageHeaderAllModulesAssignment, "PageHeader all modules assignments");
	}

	public synchronized void editAllModulesAssignmentsButtonClick() throws InterruptedException {
		Thread.sleep(3000);
		webElementMouseHoverAndClick(pomModulesAssignments.pomModulesAssignments("btnEditModulesAssignments"),
				"Edit all modules assignments button");
	}

	public synchronized void editAllModulesAssignmentsPageHeaderValidation() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomModulesAssignments.pomModulesAssignments("headerEditModulesAssignments"),
				expectedPageHeaderEditAllModulesAssignment, "Edit all modules assignments Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomModulesAssignments.pomModulesAssignments("btn_Cancel"), "cancel");
	}

	public synchronized void validateAllModulesAssignmentsValues() throws InterruptedException {
		Thread.sleep(7000);
		webGetAttributeValueAndAssertEqualsNumeric(pomModulesAssignments.pomModulesAssignments("txtModuleAssignmentId"),
				expectedModuleAssignmentId, "Module Assignments id");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(pomModulesAssignments.pomModulesAssignments("drpModule"),
				expectedModule, "module - dropdown");
		webGetAttributeValueAndAssertEqualsNumeric(pomModulesAssignments.pomModulesAssignments("txtModuleAssignmentId"),
				expectedModuleAssignmentId2, "Module Assignment id 1");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(pomModulesAssignments.pomModulesAssignments("drpModuleAssignmentType"),
				expectedModuleAssignmentType, "module assignment type - dropdown");
		/*WebCheckboxIsNotSelected(POMAllModulesAssignPage.pomAllModulesAssignmentsLocator("chkRecurring"),
				"Recurring - checkbox");
		WebGetAttributeValueAndAssertEqualsNumeric(POMAllModulesAssignPage.pomAllModulesAssignmentsLocator("txtRecurrenceFrequency"),
				datatextRecurFreq1, "Recurrence Frequency");
		WebGetSelectedValueFromDropdownAndAssertAlphaNumeric(POMAllModulesAssignPage.pomAllModulesAssignmentsLocator("drpRecurrenceType"),
				datatextRecurType1, "Recurrence Type - dropdown");*/
		verifyWebTextBoxIsEmpty(pomModulesAssignments.pomModulesAssignments("txtDisabledMonths"), "Disabled Months");
		verifyWebCheckBoxIsSelected(pomModulesAssignments.pomModulesAssignments("chkActiveModuleAssignment"),
				"Active Module Assignment - checkbox");
	}
}
