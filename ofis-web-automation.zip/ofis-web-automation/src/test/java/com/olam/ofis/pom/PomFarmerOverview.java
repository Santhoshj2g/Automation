package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomFarmerOverview {

	public synchronized String pomFarmerOverview(String locator)
	{

		try
		{
			Hashtable<String, String> hs = new Hashtable<String, String>();

			//country dropdown
			hs.put("drp_main_country", "xpath#//div[@class='form-group col1']/ng-multiselect-dropdown/div");
			hs.put("drp_sub_country", "xpath#//div[@class='form-group col1']/ng-multiselect-dropdown/div/div[2]/ul/li[3]/div");
			//hs.put("drp_country_arrow", "xpath#//span[text()='All Countries']//following-sibling::span//span[@class='glyphicon glyphicon-menu-down']");
			hs.put("chk_all_countries","xpath#//div[text()='All Countries']//parent::li[@class='multiselect-item-checkbox']");
			
			hs.put("UnselectAll_section", "xpath#(//div[text()='UnSelect All'])[6]");
			hs.put("chk_section", "xpath#//li[@class='multiselect-item-checkbox']//following-sibling::div[text()='DALLO ']");
			hs.put("clk_UpArrow", "xpath#//span[@class='glyphicon glyphicon-menu-up']");

			//FarmerGroup dropdown
			hs.put("drp_main_FG", "xpath#//div[@class='form-group col3']/ng-multiselect-dropdown/div");
			hs.put("drp_sub_FG", "xpath#//div[@class='form-group col1']/ng-multiselect-dropdown/div/div[2]/ul/li[3]/div");
			hs.put("txt_FG_search", "xpath#//div[@class='form-group col3']/ng-multiselect-dropdown/div/div[2]/ul/li[2]");
			hs.put("chk_FG_select", "xpath#//div[@class='form-group col3']/ng-multiselect-dropdown/div/div[2]/ul[2]/li[1]");
			
			//Sections dropdown
			//hs.put("drp_section", "css#div[class='form-group col3'] ng-multiselect-dropdown:nth-child(4) li:nth-child(2)>input");
			hs.put("drpSection", "css#div[class='form-group col3'] ng-multiselect-dropdown:nth-child(4) div");
			hs.put("UnselectAllSection", "css#div[class='form-group col3'] ng-multiselect-dropdown:nth-child(4) li:nth-child(1)");
			hs.put("txtSectionSearch", "css#div[class='form-group col3'] ng-multiselect-dropdown:nth-child(4) li:nth-child(2)>input");
			hs.put("chkSectionSelect", "css#div[class='form-group col3'] ng-multiselect-dropdown:nth-child(4) ul:nth-child(2) li div");

			
			hs.put("btn_submit", "xpath#//button[@class='btn btn-success' and text()='Submit']");

			//Overview Tab
			hs.put("tab_overview", "xpath#//*[@routerlink='/farmer-group/overview']");

			hs.put("lbl_DB_FarmersReg", "xpath#//*[@class='ofis-dasboard-placeholder-inner-wrapper']/h3");

			//Survey Box

			hs.put("surveylist","xpath#//div[@class='survey_node' or @class='annual_survey']//p[contains(@class,'progress_label')]");
			hs.put("annualsurveylist", "xpath#//div[@class='annual_survey']//p[@class='progress_label_an']");
			hs.put("BaselinesurveyProgressbar", "xpath#//div[@class='survey_node']//p[contains(text(),'Baseline Survey')]//following-sibling::div//div[@class='progress-bar']");
			hs.put("lblFarmersCompletedsurvey", "xpath#(//ul[@class='ofis-modal-list']//li)[2]");
			hs.put("Viewscreenclose", "xpath#//span[@class='ofis-modal-close glyphicon glyphicon-remove']");

			//Surveys Completed
			hs.put("lblBaselineSurvey", "css#div.baseline_survey div.survey_node p:nth-child(1)");
			hs.put("percentageBaselineSurvey", "css#div.baseline_survey div.survey_node p:nth-child(3)");
			hs.put("lblAnnualSurvey", "css#div.annual_survey p");
			hs.put("annualSurveyStartYear", "css#div.annual_survey div.survey_node p:nth-child(2)");
			hs.put("percentageAnnualSurvey", "css#div.annual_survey div.survey_node p:nth-child(3)");
			
			//Farmer Groups Box

			hs.put("farmer_groups_count", "xpath#//ul[@class='farmerGroupNode']//li");

			//Left Sections Block
			
			hs.put("leftSectionsCount", "xpath#//p[text()='SECTIONS']//preceding-sibling::div[@class='count ofis-modal-new']");
			hs.put("sectionName", "css#div.ag-cell-value:nth-child(1)");
			hs.put("sectionFarmers", "css#div.ag-cell-value:nth-child(2)");
			hs.put("sectionSurveyCompleted", "css#div.ag-cell-value:nth-child(3)");
			// Right Sections Box
			hs.put("section_count", "xpath#//div[@class='ofis-modal-new inactive_section']");
			hs.put("section_farmerCount", "xpath#//div[@title='Number of farmers in this section']//span");

			//Overview farmer count
			hs.put("farmer_count", "xpath#//p[text()='FARMERS']//preceding-sibling::div[@class='count ofis-modal-new']");

			//Activity
			hs.put("activity_pagination", "xpath#//ul[@role='navigation']//li//following-sibling::li");
			hs.put("activity_current_page", "xpath#//li[@class='current']");
			hs.put("activity_next_page", "xpath#//li[@class='pagination-next']");
			hs.put("activity_pagination", "xpath#//*[@id=\"fgTab\"]/div/app-overview/div/div[4]/div[1]/app-conentbox/div/div/div/app-activity/div/div/pagination-controls/pagination-template/ul/li/a/span");
			hs.put("activity_section_text", "xpath#(//span[@class='glyphicon ofis-fg-content-glyphs glyphicon-user']//following-sibling::h1[text()='Farmer Added ']//parent::div//following-sibling::div//p)[2]");

			//Statistics 
			hs.put("male_farmers_count", "xpath#//p[@class='title_wrap' and text()='Male Farmers']//following-sibling::p[@class='count_wrap']");
			hs.put("female_farmers_count", "xpath#//p[@class='title_wrap' and text()='Female Farmers']//following-sibling::p[@class='count_wrap']");

			//left side panel-Farmers
			hs.put("block_farmers", "xpath#//*[@countlabel='FARMERS']/div/div/div/div/p");
			hs.put("block_farmers_val", "xpath#//*[@countlabel='FARMERS']/div/div/div/div/div");

			hs.put("popupWebTable", "xpath#//*[@class='table']/tbody");
			hs.put("popupFarmersWebTableFirstRow", "xpath#//*[@class='table']/tbody/tr[1]");

			hs.put("farmerProfileOlamFarmerId","xpath#//*[@class='col-sm-10 col-md-10 col-lg-10 col-xs-10 nopad']/div[2]");
			hs.put("farmerProfileFarmerName","xpath#//*[@class='col-sm-10 col-md-10 col-lg-10 col-xs-10 nopad']/div[1]");


			hs.put("Pagenat_farmers", "xpath#//ul[@class='pagination']");
			hs.put("Pagenat_farmers_popup_val", "xpathlist#//ul[@class='pagination']/li");
			hs.put("PagelistofVal_farmers_popup", "xpathlist#//*[@class='table']/tbody/tr");

			//Farmer popup
			hs.put("farmersOlamFarmerId", "css#tbody tr:nth-child(1) td:nth-child(2)");
			hs.put("farmersName", "css#tbody tr:nth-child(1) td:nth-child(3)");
			hs.put("farmersEnumeratorName", "css#tbody tr:nth-child(1) td:nth-child(4)");
			hs.put("farmersPlaceName", "css#tbody tr:nth-child(1) td:nth-child(5)");
			
			//left side panel-Enumerators
			hs.put("block_enumerators", "xpath#//*[@countlabel='ENUMERATORS']/div/div/div/div/p");
			hs.put("enumeratorsCount", "xpath#//*[@countlabel='ENUMERATORS']/div/div/div/div/div");

			//hs.put("popupAngularWebTable", "xpath#//div[@ref='eBodyViewport']/div");
			hs.put("popupAngularWebTable", "xpath#//div[@ref='eCenterContainer']");
			hs.put("popupAngularLeftWebTable", "xpath#//div[@class='col-sm-6'][1]/div[2]/div/div[1]/ag-grid-angular/div/div/div/div[3]/div[2]/div/div");
			hs.put("popupAngularRightWebTable", "xpath#//div[@class='col-sm-6'][2]/div[2]/div/div[1]/ag-grid-angular/div/div/div/div[3]/div[2]/div/div");
			hs.put("popupEnumColumnFarmersReg", "xpath#//*[@title='FARMERS REGISTERED']");

			//Enumerators second level popup
			hs.put("lblEnumeratorName","xpath#//*[@class='content-section']/div[1]/div[2]/ul/li[1]");
			hs.put("lblOlamId", "xpath#//*[@class='content-section']/div[1]/div[2]/ul/li[2]");
			hs.put("lblFarmersAdded", "xpath#//*[@class='content-section']/div[1]/div[2]/ul/li[3]");
			hs.put("lblSurveysCompleted", "xpath#//*[@class='content-section']/div[1]/div[3]/ul/li[1]");

			//Enumerators 2nd level popup - RecentSurveys Block
			hs.put("enumRecentSurveysTable", "css#div.content-section div.ag-center-cols-container:nth-child(1)");

			//Enumerators 3rd level popup - RecentSurveys popup
			hs.put("lblModule", "xpath#//*[@class='content-section']/div/div[3]/ul/li[1]");
			hs.put("btnEnum3rdPopupModuleView", "xpath#//*[@class='content-section']/div/div[3]/ul/li[1]/button");
			hs.put("lblEnumerator", "xpath#//*[@class='content-section']/div/div[2]/ul/li[2]");
			hs.put("btnEnum3rdPopupEnumView", "xpath#//*[@class='content-section']/div/div[2]/ul/li[2]/button");

			hs.put("popupEnum3rdlevelTitle", "xpath#//*[@class='ofis-modal-head']/h4");
			//Enumerators 4th level popup-1 - Survey :Cocoa Annual Survey popup
			hs.put("btnTotalQuestView", "xpath#//*[@class='content-section']/div[1]/div[3]/ul/li/span/button");
			hs.put("btnFarmersCompletedView", "xpath#//*[@class='content-section']/div[1]/div[2]/ul/li[2]/span/button");

			//Enumerators 4th level popup-2 - Survey :Cocoa Annual Survey popup
			hs.put("btnEnum4thlevelFarmersCompView", "xpath#//*[@class='content-section']/div[1]/div[3]/ul/li/span/button");

			//Enumerators Sub Module
			hs.put("lblTotalQuestion", "xpath#//*[@class='col-sm-6'][2]/ul/li[1]");
			hs.put("lblQuestionsAnswered", "xpath#//*[@class='col-sm-6'][2]/ul/li[2]");
			//rightpanelSections Block
			hs.put("listRightSections", "xpath#//*[@class='section_node']");
			hs.put("listRightSectionsClick", "xpath#//*[@class='section_node']/li/div");
			hs.put("lblFarmers","xpath#//div[@class='col-sm-5'][1]/ul/li[2]");

			//Cocoa Annual Survey popup
			hs.put("breadCrumbEnum5thPopup1", "classname#col-sm-12 ofis-modal-breadcrumbs");
			hs.put("breadCrumbQuestions", "xpath#//*[@class='col-sm-12 ofis-modal-breadcrumbs']/a");


			//Enumerators second level popup - FarmersAdded Block
			hs.put("enumFarmersAddedTable", "css#div.content-section>div:nth-last-child(1) div.ag-center-cols-container");

			//left side panel-Sections
			hs.put("block_sections", "xpath#//*[@countlabel='SECTIONS']/div/div/div/div/p");
			hs.put("block_sections_val", "xpath#//*[@countlabel='SECTIONS']/div/div/div/div/div");

			//
			hs.put("popupSectionsAngularWebTable", "xpath#//*[@ref='eBodyViewport']/div");
			hs.put("popupSectionsWebTableFirstRow", "xpath#//*[@ref='eBodyViewport']/div/div[1]");

			hs.put("popupSectionsName", "xpath#//*[@class='modal-body courseLevel']/div/span[2]");
			hs.put("lblSectionsFarmers", "xpath#//*[@class='content-section']/div/div[2]/ul/li[2]");
			hs.put("lblSectionsSurveys", "xpath#//*[@class='content-section']/div/div[2]/ul/li[3]");


			hs.put("Pagenat_sections", "xpath#//ul[@class='pagination']");
			hs.put("PagelistofVal_Section_popup", "xpathlist#//*[@ref='eBodyContainer']/div");
			hs.put("title_Sections_popup", "xpath#//*[@class='ofis-modal-head']/h4");
			hs.put("btn_Popup_close", "xpathlist#//*[@class='ofis-modal-close glyphicon glyphicon-remove']");




			//right side panel
			hs.put("block_farmergroups", "xpath#//*[@boxtitle='Farmer Groups']/div/h3");
			hs.put("block_right_sections", "xpath#//*[@class='col-md-10 col-sm-10']/app-farmer-group-section/div[2]/div/h3");
			hs.put("block_reviewstatistics", "xpath#//*[@class='col-md-10 col-sm-10 split_space']/div[1]/app-conentbox/div/h3");
			
			hs.put("rightSectionName", "css#div.inactive_section");
			hs.put("rightSectionCount", "css#div.inactive_section div span:nth-child(1)");
			
			//review Statistics  block
			hs.put("surveysUnderReview","css#ul.rs_node li:nth-child(1) span:nth-child(2)");
			hs.put("surveysUnderReviewPercent","css#ul.rs_node li:nth-child(2) span:nth-child(2)");
			
			hs.put("block_surveycompleted", "xpath#//*[@class='col-md-10 col-sm-10 split_space']/div[2]/app-conentbox/div/h3");
			hs.put("surveyComLbl1stRecord","xpath#//*[@class='baseline_survey']/div/app-progressbar/div/p");
			hs.put("surveyComLbl2ndRecord","xpath#//*[@class='annual_survey']/div/div/app-progressbar/div/p[2]");
			
			//Activity block
			hs.put("block_activity", "xpath#//*[@class='col-md-12 col-sm-12 activity_wrapper']/div[1]/app-conentbox/div/h3");
			hs.put("activityFirstRecord", "css#app-conentbox.activity_box_wrap div.timeline_node h1");
			
			hs.put("block_statistics", "xpath#//*[@class='col-md-12 col-sm-12 activity_wrapper']/div[2]/app-conentbox/div/h3");
			hs.put("block_map", "xpath#//*[@class='col-md-12 col-sm-12 maps_wrapper']/div[1]/app-conentbox/div/h3");
			
			//Statistics block
			hs.put("lblAvgFarmerAge", "css#ul.statistics_node li:nth-child(1) p:nth-child(2)");
			hs.put("lblFemaleFarmers", "css#ul.statistics_node li:nth-child(2) p:nth-child(2)");
			hs.put("lblMaleFarmers", "css#ul.statistics_node li:nth-child(3) p:nth-child(2)");
			hs.put("lblFarmsMappedSinglePoint", "css#ul.statistics_node li:nth-child(4) p:nth-child(2)");
			hs.put("lblFarmsMappedBoundaryPlotted", "css#ul.statistics_node li:nth-child(5) p:nth-child(2)");
			hs.put("lblAvgFarmSizeSurveyed", "css#ul.statistics_node li:nth-child(6) p:nth-child(2)");
			hs.put("lblAvgFarmSizeGps", "css#ul.statistics_node li:nth-child(7) p:nth-child(2)");
			hs.put("lblTotalSurveyedHectares", "css#ul.statistics_node li:nth-child(8) p:nth-child(2)");
			hs.put("lblTotalGpsMappedHectares", "css#ul.statistics_node li:nth-child(9) p:nth-child(2)");
			hs.put("lblAveEstimatedYieldSurveyedHA", "css#ul.statistics_node li:nth-child(10) p:nth-child(2)");
			hs.put("lblAveEstimatedYieldGpsHA", "css#ul.statistics_node li:nth-child(11) p:nth-child(2)");
			hs.put("lblAveGpsScore", "css#ul.statistics_node li:nth-child(12) p:nth-child(2)");
			hs.put("lblNumFarmersWithMobilePhone", "css#ul.statistics_node li:nth-child(13) p:nth-child(2)");
			
			
			//Training Tab
			hs.put("tab_training", "xpath#//*[@routerlink='/farmer-group/training']");
			hs.put("block_coursesavailable", "xpath#//*[@countlabel='Courses Available']/div/div/div/div/p"); 
			hs.put("coursesAvailableVal", "css#div.box1 div");
			hs.put("block_modulesavailable", "xpath#//*[@countlabel='Modules Available']/div/div/div/div/p");
			hs.put("modulesAvailableVal", "css#div.box2 div");
			hs.put("block_totaltrainedfarmers", "xpath#//*[@countlabel='Total Trained Farmers']/div/div/div/div/p");
			hs.put("totalTrainedFarmersVal", "css#div.box3 div");
			hs.put("block_trainedthismonth", "xpath#//*[@countlabel='Trained This Month']/div/div/div/div/p");
			hs.put("trainedThisMonthVal", "css#div.box4 div");
			
			//statement block
			hs.put("block_statement", "xpath#//*[@boxtitle='Statement']/div/h3");
			hs.put("gridCourseName", "css#tbody:nth-child(2) tr:nth-child(1) p:nth-child(1)");
			hs.put("gridModuleName", "css#tbody:nth-child(2) tr:nth-child(1) p:nth-child(2)");
			hs.put("gridStatus", "css#tbody:nth-child(2) tr:nth-child(1) td:nth-child(3)");
			hs.put("gridEnumerator", "css#tbody:nth-child(2) tr:nth-child(1) td:nth-child(4)");
			hs.put("gridDate", "css#tbody:nth-child(2) tr:nth-child(1) td:nth-child(5)");
			hs.put("gridTime", "css#tbody:nth-child(2) tr:nth-child(1) td:nth-child(6)");
			hs.put("gridTotalAttendees", "css#tbody:nth-child(2) tr:nth-child(1) td:nth-child(7)");
			
			//Courselist block
			hs.put("block_courselist", "xpath#//*[@class='col-md-10 col-sm-10 split_space']/div[1]/app-conentbox/div/h3");
			
			//Enumerators block
			hs.put("blockEnumerators", "xpath#//*[@class='col-md-10 col-sm-10 split_space']/div[2]/app-conentbox/div/h3");
			hs.put("linkEnumeratorsName", "css#ul.enumeratorlist_node div span");
			hs.put("linkEnumFarmerCount", "css#ul.enumeratorlist_node div.icon_wrap span");

			//Training Tab - 1st Popup
			hs.put("lblTrainer", "xpath#//*[@class='content-section']/div[1]/div[2]/ul/li[3]");
			hs.put("lblDate", "xpath#//*[@class='content-section']/div[1]/div[2]/ul/li[4]");
			hs.put("lblTime", "xpath#//*[@class='content-section']/div[1]/div[2]/ul/li[5]");
			hs.put("lblFarmersAttended", "xpath#//*[@class='content-section']/div[1]/div[3]/ul/li[1]");

			//Training Tab - Course list
			hs.put("listCourseList", "xpath#//*[@class='courselist_node']");
			hs.put("courseName", "css#ul.courselist_node li:nth-child(1) span.name_label");

			//Training Tab - Course list
			hs.put("listEnumerators", "xpath#//*[@class='enumeratorlist_node']");

			//Training Tab - Farmers attempted
			hs.put("lblFamersAttempted", "xpath#//div[@class='content-section']/div[1]/div[2]/ul/li");
			hs.put("btnFamersAttemptedView", "xpath#//div[@class='content-section']/div[1]/div[2]/ul/li/button");
			hs.put("breadcrumbFarmersAttempted", "xpath#//div[@class='col-sm-12 ofis-modal-breadcrumbs']");
			hs.put("breadcrumbMiddleFarmersAttempted", "xpath#//div[@class='col-sm-12 ofis-modal-breadcrumbs']/a[2]");

			//Training Tab - Last Sessions
			hs.put("lblTrainer", "xpath#//div[@class='content-section']/div[1]/div[2]/ul/li[3]");
			hs.put("lblFarmersAttended", "xpath#//div[@class='content-section']/div[1]/div[3]/ul/li[1]");

			//Training Tab->Enumerators->TrainingModules
			hs.put("lblName", "xpath#//div[@class='col-sm-4'][2]/ul[1]/li[1]");
			//Training Tan->Enumeratos->TrainingModules->RecentTrainingDays
			hs.put("lblFarmersAttended", "xpath#//div[@class='col-md-3']/ul/li");

			//Management Tab
			hs.put("tab_management", "xpath#//*[@routerlink='/farmer-group/management']");
			hs.put("block_mgt_farmers", "xpath#//*[@countlabel='FARMERS']/div/div/div/div/p");
			hs.put("mgmt_farmer_count", "css#div.box1 div");
			hs.put("block_mgt_sections", "xpath#//*[@countlabel='SECTIONS']/div/div/div/div/p");
			hs.put("mgtSectionsCount", "css#div.box2 div");
			hs.put("mgtFmpCount", "css#div.box3 div");
			hs.put("block_mgt_right_sections", "xpath#//*[@class='sections_box_wrap']/div/h3");
			hs.put("block_mgt_farmer_group", "xpath#//*[@class='farmer_box_wrap']/div/h3");

			//Management tab - Sections
			hs.put("managementSectionName", "css#li div.active_selection");
			hs.put("managementSectionFarmer", "css#span.count_tip");
			
			//Management tab - FDP input progress
			hs.put("fertiliserCurrYr", "css#div.fertilizerCr p.progress_value");
			hs.put("fertiliserRequiredNextYr", "css#div.fertilizerBlock:nth-child(1) div:nth-child(2) p:nth-child(3)");
			
			hs.put("seedlingcurrYr", "css#div.seedingCr p.progress_value");
			hs.put("seedlingRequiredNextYr", "css#div.seedlingBlock:nth-child(2) div:nth-child(2) p:nth-child(3)");

			//Management Tab - Generated Plans block (fmp-Farmer Mangement Plan)
			hs.put("fmpCompleted", "css#div.chart_container div:nth-child(3) p span");
			hs.put("fmpAvailable", "css#div.chart_container div:nth-child(4) p span");
			hs.put("fmpChartCenter", "css#p.chart_center_big_text_2");
			
			//Farmer Management Plans-farmers with plan
			hs.put("btnShowHideFarmersWithPlan", "css#div.close_button");
			hs.put("fmpHeader", "css#div.header_text span");
			hs.put("showFarmersWithPlan", "xpath#//*[@class='FMP_Results']/div[1]/div[3]");
			hs.put("hideFarmersWithPlan", "xpath#//*[@class='FMP_Results']/div[1]/div[4]");
			//hs.put("webtableFarmersWithPlan","xpath#//*[@class='table ']/tbody");
			hs.put("webtableFarmersWithPlan","css#table.table>tbody");
			//hs.put("btnViewProfile", "xpath#//*[@class='table ']/tbody/tr[2]/td[4]/a");
			hs.put("btnViewProfile", "css#a.btn-primary");
			hs.put("txtFmpSearch", "css#input.search_box");
			hs.put("btnFmpSearch", "css#i.fa-search");

			//Farmer Management Plans - farmers without plan
			hs.put("showFarmersWithoutPlan", "xpath#//*[@class='FMP_Results']/div[4]/div[3]");
			hs.put("hideFarmersWithoutPlan", "xpath#//*[@class='FMP_Results']/div[4]/div[4]");
			hs.put("btnWithoutPlanViewProfile", "xpath#//*[@class='table']/tbody/tr[2]/td[4]/a");

			//Farmer Management Plans - farmers without enough data
			hs.put("showFarmersWithoutEnoughData", "xpath#//*[@class='FMP_Results']/div[7]/div[3]");
			hs.put("hideFarmersWithoutEnoughData", "xpath#//*[@class='FMP_Results']/div[7]/div[4]");
			hs.put("btnWithoutEnoughDataViewProfile", "xpath#//*[@class='table']/tbody/tr[2]/td[2]/a");
			


			//Popup Close Element
			hs.put("popupTitle", "xpath#//*[@class='ofis-modal-head']/h4");
			return hs.get(locator);

		}catch(Exception e){
			System.out.println("Error occurred in POM classes :"+e);
			return null;
		}
	}



}
