package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomCompletionCriteria {

	public synchronized String pomCompletionCriteria(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("thumbnailCompletionCriteria", "xpath#//p[contains(text(), 'edit completion criteria')]");
			hs.put("Header_PageHeader", "xpath#//*[@class='page-header']");

			// Add CompletionCriteria page
			hs.put("txtName", "id#name");

			// edit CompletionCriteria page
			hs.put("btnEditCompletionCriteria", "css#div[row-index='0'] div[col-id='0'] a");
			hs.put("headerEditCompletionCriteria", "xpath#//*[@class='page-header']");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");

			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
