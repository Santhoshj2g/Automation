package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.pom.PomRoles;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Roles extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomRoles pomRoles = new PomRoles();

	public Roles(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderRoles;
	private String expectedPageHeaderEditRoles;
	private String expectedName;

	public synchronized void rolesLoadExcelData()
			throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/Roles.xlsx");
	
		expectedPageHeaderRoles = read.getCellData("RolesTC", "pageHeader_roles", 1);
		expectedPageHeaderEditRoles = read.getCellData("RolesTC", "pageHeader_edit_roles", 1);
		expectedName = read.getCellData("RolesTC", "text_name", 1);
	}

	public synchronized void settingsUsersClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_ofis-users"), "Settings-Users");
	}

	public synchronized void navigateToIframe() throws InterruptedException {

		Thread.sleep(1000);
		iFrameSwitchTo(pomRoles.pomRoles("iFrame_OFISUser"), "iFrame-OFISUser");
	}

	public synchronized void switchoutFromIframe() throws InterruptedException {

		Thread.sleep(1000);
		iFrameSwitchOut("iFrame-OFISUser");
	}

	public synchronized void rolesClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomRoles.pomRoles("thumbnail_roles"), "thumbnail Enumerator");
	}

	public synchronized void rolesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(pomRoles.pomRoles("Header_roles_PageHeader"),
				expectedPageHeaderRoles, "PageHeader roles");
	}

	public synchronized void editRolesButtonClick() throws InterruptedException {
		Thread.sleep(3000);
		webElementMouseHoverAndClick(pomRoles.pomRoles("btn_editroles"), "Edit roles button");
	}

	public synchronized void editRolesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(3000);
		webAssertEqualsAlphaNumeric(pomRoles.pomRoles("Header_Editroles"), expectedPageHeaderEditRoles,
				"Edit roles Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomRoles.pomRoles("btn_Cancel"), "cancel");
	}

	public synchronized void validateRolesValues() throws InterruptedException {
		Thread.sleep(2000);
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomRoles.pomRoles("txt_roles_name"),
				expectedName, "roles name");

	}
}
