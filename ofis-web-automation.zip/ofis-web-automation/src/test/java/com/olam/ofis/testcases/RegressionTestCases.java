
package com.olam.ofis.testcases;

import java.util.List;

import org.json.JSONObject;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.olam.ofis.dto.OutputDataDto;
import com.olam.ofis.dto.SurveyModuleDto;
import com.olam.ofis.pages.BaseTest;
import com.olam.ofis.pages.FarmerOverview;
import com.olam.ofis.pages.ManageGPX;
import com.olam.ofis.pages.Tasks;
import com.olam.ofis.pom.JsonPomFarmerOverview;
import com.olam.ofis.pom.JsonPomFarmerProfile;
import com.olam.ofis.pom.PomFarmerOverview;
import com.olam.ofis.pom.PomFarmerProfile;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.pom.PomSMSCampaigns;
import com.olam.ofis.pom.PomTasks;
import com.olam.ofis.reports.ExtTestMngr;

import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class RegressionTestCases extends BaseTest {
	PomMenus Menus = new PomMenus();
	PomFarmerOverview PomFarmerOverviewPage = new PomFarmerOverview();
	PomFarmerProfile PomFarmerPage = new PomFarmerProfile();
	JsonPomFarmerOverview FoJsonKeys = new JsonPomFarmerOverview();
	JsonPomFarmerProfile FarmerProfile = new JsonPomFarmerProfile();
	PomTasks PomTasksPage = new PomTasks();
	PomSMSCampaigns PomSMSCampaignsPage = new PomSMSCampaigns();

	@Test
	public synchronized void farmerOverviewStartRegressionTest() throws Exception {
		try {
			Thread.sleep(5000);
			webElementClick(Menus.pomMenus("Menu_farmerOverview"), "Menu FarmerOverview");
			FarmerOverview FarmerOverviewPage = new FarmerOverview(driver);
			Thread.sleep(12000);
			FarmerOverviewPage.foWebListSearchAndCheckboxSelect("drp_main_FG", "txt_FG_search", "COOPYCA",
					"chk_FG_select");
			Thread.sleep(1000);
			webElementClick(PomFarmerOverviewPage.pomFarmerOverview("btn_submit"), "Submit button");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void farmersBlockRegressionTest() throws Exception {
		webElementClick(PomFarmerOverviewPage.pomFarmerOverview("block_farmers"), "Farmers block");
		Thread.sleep(5000);
		webTableFetchAndClickFirstRow(PomFarmerOverviewPage.pomFarmerOverview("popupWebTable"));
		getParentWindowAndSwitchToSpecificTab(1, "Farmer Profile");
		Thread.sleep(8000);
		try {
			assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileOlamFarmerId"), 2,
					"OLAM FARMER ID");
			assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileFarmerName"), 3,
					"Farmer Name");
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "Farmers block fields are not validated due to exception", true);
		}
		webDriverClose();
		driver.switchTo().window(parentWindowHandle);
		navigateToPopupAndClose("popupTitle");
	}

	@Test
	public synchronized void enumeratorBlockRegressionTest() throws Exception {

		Thread.sleep(7000);
		webElementClick(PomFarmerOverviewPage.pomFarmerOverview("block_enumerators"), "Enumerator block");
		Thread.sleep(12000);
		webTableFetchAndClickSpecificRow(PomFarmerOverviewPage.pomFarmerOverview("popupAngularWebTable"), 3,
				"angulartable");
		Thread.sleep(12000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblEnumeratorName"), 1,
				"Enumerator 2nd level popup - Name");
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblOlamId"), 2,
				"Enumerator 2nd level popup - Olam Id");
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblFarmersAdded"), 3,
				"Enumerator 2nd level popup - Farmers added");
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblSurveysCompleted"), 5,
				"Enumerator 2nd level popup - Surveys completed");
	}

	@Test
	public synchronized void farmersAddedBlockRegressionTest() throws Exception {
		Thread.sleep(7000);
		angularWebTableFetchAndClickFirstRow(PomFarmerOverviewPage.pomFarmerOverview("enumFarmersAddedTable"));
		getParentWindowAndSwitchToSpecificTab(1, "Farmer Profile");
		Thread.sleep(8000);
		try {
			assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileOlamFarmerId"), 3,
					"OLAM FARMER ID");
			assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileFarmerName"), 4,
					"Farmer Name");
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "Farmers added block fields are not validated due to exception", true);
		}
		webDriverClose();
		driver.switchTo().window(parentWindowHandle);
	}

	@Test
	public synchronized void recentSurveyBlockRegressionTest() throws Exception {
		Thread.sleep(10000);
		angularWebTableFetchAndClickFirstRow(PomFarmerOverviewPage.pomFarmerOverview("enumRecentSurveysTable"));
		Thread.sleep(15000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblModule"), 1,
				"Enumerator 3nd level popup - Module");
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("popupEnum3rdlevelTitle"), 2,
				"Enumerator 3nd level popup - Title");
	}

	@Test
	public synchronized void enumeratorViewBlockRegressionTest() throws Exception {
		Thread.sleep(7000);
		getTextFromElementByRemovingPrefixAndSuffix(PomFarmerOverviewPage.pomFarmerOverview("lblEnumerator"), ":",
				"VIEW");
		Thread.sleep(7000);
		webElementClick(PomFarmerOverviewPage.pomFarmerOverview("btnEnum3rdPopupEnumView"), "Module - View Button");
		Thread.sleep(7000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("popupTitle"), "Popup - Survey");
	}

	@Test
	public synchronized void surveyBlockRegressionTest() throws Exception {
		recentSurveyBlockRegressionTest();
		Thread.sleep(7000);
		getTextFromElementByRemovingPrefixAndSuffix(PomFarmerOverviewPage.pomFarmerOverview("lblModule"), ":", "VIEW");
		Thread.sleep(7000);
		webElementClick(PomFarmerOverviewPage.pomFarmerOverview("btnEnum3rdPopupModuleView"), "Module - View Button");
		Thread.sleep(7000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("popupTitle"), "Popup - Survey");

	}

	@Test
	public synchronized void questionsBlockRegressionTest() throws Exception {
		getTextFromElementByRemovingPrefix(PomFarmerOverviewPage.pomFarmerOverview("popupTitle"), "Survey :");
		webElementClick(PomFarmerOverviewPage.pomFarmerOverview("btnTotalQuestView"), "Total Questions - View Button");
		Thread.sleep(7000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("popupTitle"), "Popup - Questions");
		webElementClick(PomFarmerOverviewPage.pomFarmerOverview("breadCrumbQuestions"), "BreadCrumb - Questions");
	}

	@Test
	public synchronized void farmersCompletedBlockRegressionTest() throws Exception {
		Thread.sleep(7000);
		getTextFromElementByRemovingPrefix(PomFarmerOverviewPage.pomFarmerOverview("popupTitle"), "Survey :");
		webElementClick(PomFarmerOverviewPage.pomFarmerOverview("btnFarmersCompletedView"),
				"Farmers Completed - View Button");
		Thread.sleep(7000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("popupTitle"),
				"Popup - Farmers Completed");
	}

	@Test
	public synchronized void surveyNotCompletedFarmerProfileRegressionTest() throws Exception {
		Thread.sleep(7000);
		try {
			angularWebTableFetchAndClickFirstRow(PomFarmerOverviewPage.pomFarmerOverview("popupAngularLeftWebTable"));
			getParentWindowAndSwitchToSpecificTab(1, "Farmer Profile");
			Thread.sleep(12000);
			assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileOlamFarmerId"), 2,
					"OLAM FARMER ID");
			assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileFarmerName"), 1,
					"Farmer Name");
			webDriverClose();
			driver.switchTo().window(parentWindowHandle);
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "surveyNotCompletedFarmerProfileRegressionTest failed due to exception",
					true);
		}
	}

	@Test
	public synchronized void  surveyCompletedFarmerProfileRegressionTest() throws Exception {
		Thread.sleep(7000);
		
		try {
			boolean elementExistStatus = checkWebElementExist(PomFarmerOverviewPage.pomFarmerOverview("popupAngularRightWebTable"));
			if(elementExistStatus == true) {
			angularWebTableFetchAndClickFirstRow(PomFarmerOverviewPage.pomFarmerOverview("popupAngularRightWebTable"));
			getParentWindowAndSwitchToSpecificTab(1, "Farmer Profile");
			Thread.sleep(12000);
			assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileOlamFarmerId"), 2,
					"OLAM FARMER ID");
			assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileFarmerName"), 1,
					"Farmer Name");
			webDriverClose();
			driver.switchTo().window(parentWindowHandle);
			Thread.sleep(2000);
			webElementClick(PomFarmerOverviewPage.pomFarmerOverview("breadCrumbQuestions"), "BreadCrumb - survey status");
			}else {
				
				ExtTestMngr.reportStepPass("Field Name : 'Cocoa Annual Survey->Survey status page - Survey Completed block' is not available.");
				webElementClick(PomFarmerOverviewPage.pomFarmerOverview("breadCrumbQuestions"), "BreadCrumb - survey status");
			}
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "surveyCompletedFarmerProfileRegressionTest failed due to exception",
					true);
		}
		
	}

	@Test
	public synchronized void subModule1stRecordRegressionTest() throws Exception {
		Thread.sleep(7000);
		webTableFetchAndClickSpecificRow(PomFarmerOverviewPage.pomFarmerOverview("popupAngularWebTable"), 3,
				"angulartable");
		Thread.sleep(7000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("popupTitle"), 2,
				"Popup - Sub Module->1st Record");
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblTotalQuestion"), 3,
				"Popup - Sub Module->Total Question");
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblQuestionsAnswered"), 4,
				"Popup - Sub Module->Questions Answered");
		Thread.sleep(7000);
		navigateToPopupAndClose("popupTitle");
	}

	@Test
	public synchronized void sectionsBlockRegressionTest() throws Exception {
		Thread.sleep(3000);
		webElementClick(PomFarmerOverviewPage.pomFarmerOverview("block_sections"), "Sections block");
		Thread.sleep(12000);
		angularWebTableFetchAndClickFirstRow(PomFarmerOverviewPage.pomFarmerOverview("popupAngularWebTable"));
		Thread.sleep(12000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblSectionsFarmers"), 2, "Farmers");
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblSectionsSurveys"), 3, "Surveys");
	}

	@Test
	public synchronized void sectionsFarmersBlockRegressionTest() throws Exception {

		Thread.sleep(7000);
		angularWebTableFetchAndClickFirstRow(PomFarmerOverviewPage.pomFarmerOverview("popupAngularWebTable"));
		getParentWindowAndSwitchToSpecificTab(1, "Farmer Profile");
		Thread.sleep(8000);
		try {
			assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileOlamFarmerId"), 3,
					"OLAM FARMER ID");
			assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileFarmerName"), 4,
					"Farmer Name");
		} catch (Exception e) {
			e.printStackTrace();
			ExtTestMngr.reportStepFail(driver, "Sections->Farmers block fields are not validated due to exception", true);
		}
		webDriverClose();
		driver.switchTo().window(parentWindowHandle);
		navigateToPopupAndClose("popupTitle");
	}

	@Test
	public synchronized void rightSectionsBlockRegressionTest() throws Exception {
		Thread.sleep(7000);
		webListFetchAndClickNonZeroValue(PomFarmerOverviewPage.pomFarmerOverview("listRightSections"), 2);
		Thread.sleep(7000);
		assertStringContainsAlphaNumericByAddingPrefix(PomFarmerOverviewPage.pomFarmerOverview("popupTitle"),
				"Sections:", 1, "Popup - Sections");
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblFarmers"), 2, "Farmers");
	}

	@Test
	public synchronized void rightSectionsFarmersBlockRegressionTest() throws Exception {
		sectionsFarmersBlockRegressionTest();
	}

	@Test
	public synchronized void surveysCompQuestionsBlockRegressionTest() throws Exception {
		Thread.sleep(7000);
		getTextFromElement(PomFarmerOverviewPage.pomFarmerOverview("surveyComLbl1stRecord"));
		webElementClick(PomFarmerOverviewPage.pomFarmerOverview("surveyComLbl1stRecord"), "Survey hyperlink click");
		Thread.sleep(7000);
		questionsBlockRegressionTest();
	}

	@Test
	public synchronized void surveysCompFarmersCompletedBlockRegressionTest() throws Exception {
		farmersCompletedBlockRegressionTest();
	}

	@Test
	public synchronized void surveysCompSurveysNotCompletedRegressionTest() throws Exception {
		surveyNotCompletedFarmerProfileRegressionTest();
	}

	@Test
	public synchronized void surveysCompSurveysCompletedRegressionTest() throws Exception {
		surveyCompletedFarmerProfileRegressionTest();
	}

	@Test
	public synchronized void surveysCompSubModule1stRecordRegressionTest() throws Exception {
		subModule1stRecordRegressionTest();
	}

	@Test
	public synchronized void surveysCompAnnualQuestionsBlockRegressionTest() throws Exception {
		Thread.sleep(7000);
		getTextFromElement(PomFarmerOverviewPage.pomFarmerOverview("surveyComLbl2ndRecord"));
		webElementClick(PomFarmerOverviewPage.pomFarmerOverview("surveyComLbl2ndRecord"), "Survey hyperlink click");
		Thread.sleep(7000);
		questionsBlockRegressionTest();
	}

	@Test
	public synchronized void surveysCompAnnualFarmersCompletedBlockRegressionTest() throws Exception {
		farmersCompletedBlockRegressionTest();
	}

	@Test
	public synchronized void surveysCompAnnualSurveysNotCompletedRegressionTest() throws Exception {
		surveyNotCompletedFarmerProfileRegressionTest();
	}

	@Test
	public synchronized void surveysCompAnnualSurveysCompletedRegressionTest() throws Exception {
		surveyCompletedFarmerProfileRegressionTest();
	}

	@Test
	public synchronized void surveysCompAnnualSubModule1stRecordRegressionTest() throws Exception {
		subModule1stRecordRegressionTest();
	}

	@Test
	public synchronized void activityRegressionTest() throws Exception {
		try {
			Thread.sleep(8000);
			webElementExistValidation(PomFarmerOverviewPage.pomFarmerOverview("activityFirstRecord"), "Activity");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void statementBlockRegressionTest() throws Exception {

		webElementClick(PomFarmerOverviewPage.pomFarmerOverview("tab_training"), "Training Tab");
		Thread.sleep(10000);
		webTableFetchAndClickFirstRow(PomFarmerOverviewPage.pomFarmerOverview("popupWebTable"));
		Thread.sleep(10000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblTrainer"), 4, "Trainer");
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblDate"), 5, "Date");
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblTime"), 6, "Time");
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblFarmersAttended"), 7,
				"FARMERS ATTENDED");
	}

	@Test
	public synchronized void attendeesBlockRegressionTest() throws Exception {
		Thread.sleep(7000);
		angularWebTableFetchAndClickFirstRow(PomFarmerOverviewPage.pomFarmerOverview("popupAngularWebTable"));
		getParentWindowAndSwitchToSpecificTab(1, "Farmer Profile");
		Thread.sleep(8000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileFarmerName"), 3,
				"Farmer Name");
		webDriverClose();
		driver.switchTo().window(parentWindowHandle);
		navigateToPopupAndClose("popupTitle");
	}

	@Test
	public synchronized void courseListBlockRegressionTest() throws Exception {
		Thread.sleep(7000);
		webListFetchAndClickNonZeroValue(PomFarmerOverviewPage.pomFarmerOverview("listCourseList"), 2);
		Thread.sleep(7000);
		// assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("popupTitle",
		// 1, "Popup
		// - Course List");
		assertStringContainsAlphaNumericByAddingPrefix(PomFarmerOverviewPage.pomFarmerOverview("popupTitle"),
				"Course List :", 1, "Popup - Course List");
	}

	@Test
	public synchronized void trainingModulesRegressionTest() throws Exception {
		Thread.sleep(7000);
		webTableFetchAndClickSpecificRow(PomFarmerOverviewPage.pomFarmerOverview("popupAngularWebTable"), 3,
				"angulartable");
		Thread.sleep(7000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("popupTitle"), 2,
				"Popup - Training Module");
	}

	@Test
	public synchronized void farmersAttemptedBlockRegressionTest() throws Exception {
		getTextFromElement(PomFarmerOverviewPage.pomFarmerOverview("breadcrumbFarmersAttempted"));
		Thread.sleep(7000);
		webElementClick(PomFarmerOverviewPage.pomFarmerOverview("btnFamersAttemptedView"),
				"Farmers Attempted - View Button");
		Thread.sleep(7000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("breadcrumbFarmersAttempted"),
				"Breadcrumb - Farmers Attempts");
	}

	@Test
	public synchronized void farmersAttemptedBlockFarmerProfileRegressionTest() throws Exception {
		webTableFetchAndClickSpecificRow(PomFarmerOverviewPage.pomFarmerOverview("popupAngularWebTable"), 4,
				"angulartable");
		getParentWindowAndSwitchToSpecificTab(1, "Farmer Profile");
		Thread.sleep(8000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("farmerProfileFarmerName"), 3,
				"Farmer Name");
		webDriverClose();
		driver.switchTo().window(parentWindowHandle);
		webElementClick(PomFarmerOverviewPage.pomFarmerOverview("breadcrumbMiddleFarmersAttempted"),
				"Breadcrumb - Navigate to First Farmers Attempted");
	}

	@Test
	public synchronized void lastSessionsBlockRegressionTest() throws Exception {

		Thread.sleep(7000);
		webTableFetchAndClickSpecificRow(PomFarmerOverviewPage.pomFarmerOverview("popupAngularWebTable"), 5,
				"angulartable");
		Thread.sleep(8000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblTrainer"), 3, "Label - Trainer");
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblFarmersAttended"), 5,
				"Label - Famers Attended");
	}

	@Test
	public synchronized void lastSessionsBlockAttendeesBlockRegressionTest() throws Exception {

		attendeesBlockRegressionTest();
	}

	@Test
	public synchronized void trainingBlockEnumeratorsRegressionTest() throws Exception {
		Thread.sleep(7000);
		webListFetchAndClickNonZeroValue(PomFarmerOverviewPage.pomFarmerOverview("listEnumerators"), 2);
		Thread.sleep(7000);
		// assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("popupTitle",
		// 1, "Popup
		// - Enumerators");
		assertStringContainsAlphaNumericByAddingPrefix(PomFarmerOverviewPage.pomFarmerOverview("popupTitle"),
				"Enumerator: ", 1, "Popup - Enumerators");
	}

	@Test
	public synchronized void trainingBlockTrainingModulesRegressionTest() throws Exception {
		Thread.sleep(7000);
		webTableFetchAndClickSpecificRow(PomFarmerOverviewPage.pomFarmerOverview("popupAngularWebTable"), 3,
				"angulartable");
		Thread.sleep(7000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("popupTitle"), 1,
				"Popup - Enumerators");
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblName"), 1, "Label - Name");
	}

	@Test
	public synchronized void recentTrainingDaysRegressionTest() throws Exception {

		Thread.sleep(7000);
		webTableFetchAndClickSpecificRow(PomFarmerOverviewPage.pomFarmerOverview("popupAngularWebTable"), 4,
				"angulartable");
		Thread.sleep(7000);
		assertStringContainsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblFarmersAttended"), 4,
				"Label-Farmers Attended");
	}

	@Test
	public synchronized void recentTrainingDaysAttendeesBlockRegressionTest() throws Exception {

		attendeesBlockRegressionTest();
	}

	// Management Tab
	@Test
	public synchronized void farmerManagementPlanRegressionTest() throws Exception {
		foFarmerManagementPlanRegressionTest();
	}
	// **************FARMER OVERVIEW PAGE REGRESSIONS ENDS**************

	// **************FARMER OVERVIEW PAGE REGRESSION API Validation
	// STARTS**************
	// Regression API Validaton - Overview Tab started
	@Test
	public synchronized void apiFarmerOverviewStart() throws Exception {
		try {
			Thread.sleep(5000);
			webElementClick(Menus.pomMenus("Menu_farmerOverview"), "Menu FarmerOverview");
			FarmerOverview FarmerOverviewPage = new FarmerOverview(driver);
			Thread.sleep(12000);
			FarmerOverviewPage.foWebListSearchAndCheckboxSelect("drp_main_FG", "txt_FG_search", "COOPYCA",
					"chk_FG_select");
			Thread.sleep(1000);
			webListSearchAndUncheckboxSelect(PomFarmerOverviewPage.pomFarmerOverview("drpSection"),
					PomFarmerOverviewPage.pomFarmerOverview("txtSectionSearch"), "KABRANKRO",
					PomFarmerOverviewPage.pomFarmerOverview("chkSectionSelect"),
					PomFarmerOverviewPage.pomFarmerOverview("UnselectAllSection"));
			Thread.sleep(1000);
			webElementClick(PomFarmerOverviewPage.pomFarmerOverview("btn_submit"), "Submit button");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiOverviewTabLeftPanel() throws Exception {
		try {
			Response responseFarmers = postWithHeaders("farmerCountEndPoint", "getFarmerOverview.json");
			assertApiUiNumeric(responseFarmers, FoJsonKeys.jsonKeys("farmers"),
					PomFarmerOverviewPage.pomFarmerOverview("farmer_count"), "Farmers");

			Response responseEnumerators = postWithHeaders("enumeratorsEndPoint", "getFarmerOverview.json");
			assertApiUiNumeric(responseEnumerators, FoJsonKeys.jsonKeys("farmers"),
					PomFarmerOverviewPage.pomFarmerOverview("enumeratorsCount"), "Enumerators");

			Response responseSections = postWithHeaders("sectionsEndPoint", "getFarmerOverview.json");
			assertApiUiNumeric(responseSections, FoJsonKeys.jsonKeys("farmers"),
					PomFarmerOverviewPage.pomFarmerOverview("leftSectionsCount"), "Left block Sections");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiFarmersPopup() throws Exception {
		try {
			webElementClick(PomFarmerOverviewPage.pomFarmerOverview("block_farmers"), "Farmers block");

			Response responseFarmersPopup = postWithHeaders("farmersPopupEndPoint", "getFarmerOverview.json");

			assertApiUiAlphaNumeric(responseFarmersPopup, FoJsonKeys.jsonKeys("farmersOlamFarmerId"),
					PomFarmerOverviewPage.pomFarmerOverview("farmersOlamFarmerId"), "Olam Farmer Id", "equals");
			assertApiUiAlphaNumeric(responseFarmersPopup, FoJsonKeys.jsonKeys("farmersName"),
					PomFarmerOverviewPage.pomFarmerOverview("farmersName"), "Name", "equals");
			assertApiUiAlphaNumeric(responseFarmersPopup, FoJsonKeys.jsonKeys("farmersEnumeratorName"),
					PomFarmerOverviewPage.pomFarmerOverview("farmersEnumeratorName"), "Enumerator", "equals");
			assertApiUiAlphaNumeric(responseFarmersPopup, FoJsonKeys.jsonKeys("farmersPlaceName"),
					PomFarmerOverviewPage.pomFarmerOverview("farmersPlaceName"), "Place", "equals");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiFarmerProfile() throws Exception {
		try {
			webTableFetchAndClickFirstRow(PomFarmerOverviewPage.pomFarmerOverview("popupWebTable"));
			getParentWindowAndSwitchToSpecificTab(1, "Farmer Profile");

			Response responseFarmersPopup = postWithHeaders("farmersPopupEndPoint", "getFarmerOverview.json");

			int farmerid = getNumericValueFromApiReponse(responseFarmersPopup, FoJsonKeys.jsonKeys("farmersid"));
			String strFarmerID = Integer.toString(farmerid);

			String farmerInformationEndPointUrl = getApiUrl("farmerInformationEndPoint", strFarmerID);
			Response responseFarmerInfo = getWithHeaders(farmerInformationEndPointUrl);

			Thread.sleep(3000);

			try {
				assertApiUiAlphaNumeric(responseFarmerInfo, "farmerName",
						PomFarmerPage.pomFarmerProfile("titleFarmerName"), "Title Farmer", "equals");
				assertApiUiAlphaNumeric(responseFarmerInfo, "farmerName",
						PomFarmerOverviewPage.pomFarmerOverview("farmerProfileFarmerName"), "Farmer Name", "equals");
				assertApiUiAlphaNumeric(responseFarmerInfo, "olamFarmerId",
						PomFarmerOverviewPage.pomFarmerOverview("farmerProfileOlamFarmerId"), "Olam Farmer ID",
						"equals");
				assertApiUiAlphaNumeric(responseFarmerInfo, "partnersName", PomFarmerPage.pomFarmerProfile("partner"),
						"partner", "equals");
				assertApiUiAlphaNumeric(responseFarmerInfo, "programmeName",
						PomFarmerPage.pomFarmerProfile("programme"), "programme", "equals");
				assertApiUiAlphaNumeric(responseFarmerInfo, "farmergroupsName",
						PomFarmerPage.pomFarmerProfile("farmerGroup"), "farmerGroup", "equals");
				assertApiUiAlphaNumeric(responseFarmerInfo, "sectionName", PomFarmerPage.pomFarmerProfile("section"),
						"section", "equals");
				assertApiUiAlphaNumeric(responseFarmerInfo, "countryName", PomFarmerPage.pomFarmerProfile("country"),
						"country", "equals");
				assertApiUiAlphaNumeric(responseFarmerInfo, "regionName", PomFarmerPage.pomFarmerProfile("region"),
						"region", "equals");
				assertApiUiAlphaNumeric(responseFarmerInfo, "districtName", PomFarmerPage.pomFarmerProfile("district"),
						"district", "equals");
				assertApiUiAlphaNumeric(responseFarmerInfo, "placeName", PomFarmerPage.pomFarmerProfile("town"), "town",
						"equals");
				assertApiUiNumeric(responseFarmerInfo, "joinOlam", PomFarmerPage.pomFarmerProfile("yearJoined"),
						"yearJoined");

				assertApiUiAlphaNumeric(responseFarmerInfo, "gender", PomFarmerPage.pomFarmerProfile("gender"),
						"gender", "equals");
				assertApiUiAlphaNumeric(responseFarmerInfo, "dob", PomFarmerPage.pomFarmerProfile("dateOfBirth"),
						"dateOfBirth", "equals");
				assertApiUiAlphaNumeric(responseFarmerInfo, "birthCountryName",
						PomFarmerPage.pomFarmerProfile("placeOfBirth"), "placeOfBirth", "equals");
				assertApiUiAlphaNumeric(responseFarmerInfo, "educationLevel",
						PomFarmerPage.pomFarmerProfile("educationLevel"), "educationLevel", "equals");
				assertApiUiAlphaNumeric(responseFarmerInfo, "maritalStatus",
						PomFarmerPage.pomFarmerProfile("maritalStatus"), "maritalStatus", "equals");
				assertApiUiNumeric(responseFarmerInfo, "numberChildren", PomFarmerPage.pomFarmerProfile("children"),
						"children");
			} catch (Exception e) {
				e.printStackTrace();
				ExtTestMngr.reportStepFail(driver, "Fields inside 'farmer profile' page are not validated due to an exception", true);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiFarmDetails() throws Exception {
		try {

			String farmerId = getFarmerId("farmersPopupEndPoint", "farmersid");
			JSONObject farmDetails = jsonFarmDetails(farmerId);
			Response ResponsefarmDetails = postWithJsonObject("farmDetails", farmDetails);
			jsonFarmerOverview();
			assertApiUiNumeric(ResponsefarmDetails, FarmerProfile.jsonFarmerProfile("numberOfPlots"),
					PomFarmerPage.pomFarmerProfile("numberOfPlots"), "Number of Plots");
			
			Float rawFarmSize = getFloatValueFromApiReponse(ResponsefarmDetails, FarmerProfile.jsonFarmerProfile("farmSize"));
			String farmSize = Float.toString(rawFarmSize).trim();
			assertStringContainsAlphaNumeric(PomFarmerPage.pomFarmerProfile("farmSize"), farmSize, "Farm Size");
			/*
			String treesDetailsUrl = getApiUrl("treesDetails", strFarmerID);
			Response treeDetails = getWithHeaders(treesDetailsUrl);
			
			assertApiUiAlphaNumeric(treeDetails, FoJsonKeys.jsonKeys("shadeTrees"),
					PomFarmerPage.pomFarmerProfile("shadeTrees"), "Shade Trees","equals");
			*/
			try {

			} catch (Exception e) {
				e.printStackTrace();
				ExtTestMngr.reportStepFail(driver, "Farm details fields are not validated due to exception", true);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiPhoneNumber() throws Exception {
		try {

			String strFarmerID = getFarmerId("farmersPopupEndPoint", "farmersid");
			Thread.sleep(3000);

			try {
				// Phone number block
				String farmerPhoneNumberEndPointUrl = getApiUrl("farmerPhoneNumberEndPoint", strFarmerID);
				Response responseFarmerPhoneNumumber = getWithHeaders(farmerPhoneNumberEndPointUrl);

				assertApiUiAlphaNumeric(responseFarmerPhoneNumumber, "[0].phoneNumber",
						PomFarmerPage.pomFarmerProfile("phoneNumber"), "Phone Number", "contains");
				assertApiUiAlphaNumeric(responseFarmerPhoneNumumber, "[0].diallingCode",
						PomFarmerPage.pomFarmerProfile("phoneNumber"), "diallingCode in Phone Number", "contains");

			} catch (Exception e) {
				e.printStackTrace();
				ExtTestMngr.reportStepFail(driver, "phone numbers fields are not validated due to exception", true);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiFarmManagementPlans() throws Exception {
		try {

			String strFarmerID = getFarmerId("farmersPopupEndPoint", "farmersid");
			try {
				// Farm Management Plan
				String farmManagementPlanUrl = getApiUrl("farmManagementPlan", strFarmerID);
				Response farmManagementPlan = getWithHeaders(farmManagementPlanUrl);

				assertApiUiAlphaNumeric(farmManagementPlan, "[0].fmp_created",
						PomFarmerPage.pomFarmerProfile("fmpGeneratedDate"), "Generated Date", "equals");
				assertApiUiAlphaNumeric(farmManagementPlan, "[0].fmp_updated",
						PomFarmerPage.pomFarmerProfile("fmpUpdatedDate"), "Updated Date", "equals");

			} catch (Exception e) {
				e.printStackTrace();
				ExtTestMngr.reportStepFail(driver, "Farm management plans fields are not validated due to exception", true);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiSubmittedModules() throws Exception {
		try {

			String strFarmerID = getFarmerId("farmersPopupEndPoint", "farmersid");
			try {
				// Submitted Modules
				String submittedModuleUrl = getApiUrl("submittedModule", strFarmerID);
				Response submittedModules = getWithHeaders(submittedModuleUrl);

				assertApiUiAlphaNumeric(submittedModules, "[0].moduleName",
						PomFarmerPage.pomFarmerProfile("baselineSurvey"), "Baseline Survey", "equals");
				assertApiUiAlphaNumeric(submittedModules, "[0].submittedDate",
						PomFarmerPage.pomFarmerProfile("baselineSubmittedDate"), "baseline survey Submitted Date",
						"equals");
				assertApiUiAlphaNumeric(submittedModules, "[1].moduleName",
						PomFarmerPage.pomFarmerProfile("annualSurvey"), "Annual Survey", "equals");
				assertApiUiAlphaNumeric(submittedModules, "[1].submittedDate",
						PomFarmerPage.pomFarmerProfile("annualSubmittedDate"), "Annual survey Submitted Date", "equals");

			} catch (Exception e) {
				e.printStackTrace();
				ExtTestMngr.reportStepFail(driver, "Fields inside 'Submitted modules' page are not validated due to an exception", true);
			}
			webDriverClose();
			driver.switchTo().window(parentWindowHandle);
			navigateToPopupAndClose("popupTitle");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiLeftSections() throws Exception {
		try {
			webElementClick(PomFarmerOverviewPage.pomFarmerOverview("block_sections"), "Sections block");

			Response responseRightSection = postWithHeaders("sectionsDetails", "getFarmerOverview.json");
			assertApiUiAlphaNumeric(responseRightSection, FoJsonKeys.jsonKeys("sectionName"),
					PomFarmerOverviewPage.pomFarmerOverview("sectionName"), "Name", "equals");
			assertApiUiNumeric(responseRightSection, FoJsonKeys.jsonKeys("sectionFarmers"),
					PomFarmerOverviewPage.pomFarmerOverview("sectionFarmers"), "Farmers");
			assertApiUiNumeric(responseRightSection, FoJsonKeys.jsonKeys("sectionSurveyCount"),
					PomFarmerOverviewPage.pomFarmerOverview("sectionSurveyCompleted"), "Surveys Completed");

			navigateToPopupAndClose("popupTitle");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiRightSections() throws Exception {
		try {
			Response responseRightSection = postWithHeaders("rightSectionsEndPoint", "getFarmerOverview.json");
			assertApiUiAlphaNumeric(responseRightSection, FoJsonKeys.jsonKeys("rightSectionsName"),
					PomFarmerOverviewPage.pomFarmerOverview("rightSectionName"), "Sections Name", "contains");
			assertApiUiNumeric(responseRightSection, FoJsonKeys.jsonKeys("rightSectionsCount"),
					PomFarmerOverviewPage.pomFarmerOverview("rightSectionCount"), "Sections Count");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiReviewStatistics() throws Exception {
		try {
			Response responseReviewStatistics = postWithHeaders("reviewStatisticsEndPoint", "getFarmerOverview.json");
			assertApiUiNumeric(responseReviewStatistics, FoJsonKeys.jsonKeys("surveyUnderReview"),
					PomFarmerOverviewPage.pomFarmerOverview("surveysUnderReview"), "Surveys under review (#)");
			assertApiUiNumeric(responseReviewStatistics, FoJsonKeys.jsonKeys("surveyUnderReviewPercent"),
					PomFarmerOverviewPage.pomFarmerOverview("surveysUnderReviewPercent"), "Surveys under review (%)");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiSurveyCompleted() throws Exception {
		try {

			// Survey Completed - Baseline survey
			Response responseBaselineSurvey = postWithHeaders("surveyCompletedBaseline", "getFarmerOverview.json");
			assertApiUiAlphaNumeric(responseBaselineSurvey, FoJsonKeys.jsonKeys("lblBaselineSurvey"),
					PomFarmerOverviewPage.pomFarmerOverview("lblBaselineSurvey"), "Cocoa Baseline Survey", "equals");

			Float baselineCompleted = getFloatValue(responseBaselineSurvey, FoJsonKeys.jsonKeys("surveyCompleted"));
			Float baselineTotal = getFloatValue(responseBaselineSurvey, FoJsonKeys.jsonKeys("surveyTotal"));

			int baselinePercentage = getPercentage(baselineCompleted, baselineTotal);

			assertUiStringApiNumeric(baselinePercentage,
					PomFarmerOverviewPage.pomFarmerOverview("percentageBaselineSurvey"), "Baseline Survey Percentage");

			// Survey Completed - Annual survey

			Response responseAnnualSurvey = postWithHeaders("surveyCompletedAnnual", "getFarmerOverview.json");
			ResponseBody rawResponseBody = responseAnnualSurvey.getBody();
			String responseBody = rawResponseBody.asString();

			ObjectMapper objectMapper = new ObjectMapper();
			OutputDataDto outputDataObjMapper = objectMapper.readValue(responseBody, OutputDataDto.class);

			// below code is to fetch starting year json value from year based all the
			// annual survey value
			List<SurveyModuleDto> smList = outputDataObjMapper.getOutputData().getSurveyCompletedAnnual();
			String surveyType = "Cocoa Annual Survey";
			int min = Integer.parseInt(smList.get(0).getYear());
			SurveyModuleDto minSurveyModule = null;
			for (SurveyModuleDto surveyValue : smList) {

				if (surveyType.equals(surveyValue.getName())) {
					int curr = Integer.parseInt(surveyValue.getYear());
					if (curr <= min) {
						min = curr;
						minSurveyModule = surveyValue;
					}
				}
			}

			webAssertEqualsAlphaNumeric(PomFarmerOverviewPage.pomFarmerOverview("lblAnnualSurvey"),
					minSurveyModule.getName(), "Cocoa Annual Survey");
			webAssertEqualsNumeric(PomFarmerOverviewPage.pomFarmerOverview("annualSurveyStartYear"),
					Integer.parseInt(minSurveyModule.getYear()), "Annual Survey Completed Year");

			Float AnnualCompleted = Float.parseFloat(minSurveyModule.getCompleted().toString());
			Float AnnualTotal = Float.parseFloat(minSurveyModule.getTotal().toString());
			int annualPercentage = getPercentage(AnnualCompleted, AnnualTotal);

			assertUiStringApiNumeric(annualPercentage,
					PomFarmerOverviewPage.pomFarmerOverview("percentageAnnualSurvey"), "Annual Survey Percentage");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiStatisticsOverview() throws Exception {
		try {
			Response responseStatisticsOverview = postWithHeaders("statisticsOverviewEndPoint",
					"getFarmerOverview.json");
			assertApiUiAlphaNumeric(responseStatisticsOverview, FoJsonKeys.jsonKeys("avgFarmerAge"),
					PomFarmerOverviewPage.pomFarmerOverview("lblAvgFarmerAge"), "AVERAGE FARMER AGE", "equals");
			assertApiUiAlphaNumeric(responseStatisticsOverview, FoJsonKeys.jsonKeys("femaleFarmers"),
					PomFarmerOverviewPage.pomFarmerOverview("lblFemaleFarmers"), "FEMALE FARMERS", "equals");
			assertApiUiAlphaNumeric(responseStatisticsOverview, FoJsonKeys.jsonKeys("maleFarmers"),
					PomFarmerOverviewPage.pomFarmerOverview("lblMaleFarmers"), "MALE FARMERS", "equals");
			assertApiUiAlphaNumeric(responseStatisticsOverview, FoJsonKeys.jsonKeys("farmsMappedSinglePoint"),
					PomFarmerOverviewPage.pomFarmerOverview("lblFarmsMappedSinglePoint"), "FARMS MAPPED (SINGLE POINT)",
					"equals");
			assertApiUiAlphaNumeric(responseStatisticsOverview, FoJsonKeys.jsonKeys("farmsMappedBoundaryPlotted"),
					PomFarmerOverviewPage.pomFarmerOverview("lblFarmsMappedBoundaryPlotted"),
					"FARMS MAPPED (BOUNDARY PLOTTED)", "equals");

			assertApiUiAlphaNumericWithSuffix(responseStatisticsOverview, FoJsonKeys.jsonKeys("avgFarmSizeSurveyed"),
					PomFarmerOverviewPage.pomFarmerOverview("lblAvgFarmSizeSurveyed"), "AVERAGE FARM SIZE (SURVEYED)",
					"HA");
			assertApiUiAlphaNumericWithSuffix(responseStatisticsOverview, FoJsonKeys.jsonKeys("avgFarmSizeGps"),
					PomFarmerOverviewPage.pomFarmerOverview("lblAvgFarmSizeGps"), "AVERAGE FARM SIZE (GPS)", "HA");
			assertApiUiAlphaNumericWithSuffix(responseStatisticsOverview, FoJsonKeys.jsonKeys("totalSurveyedHectares"),
					PomFarmerOverviewPage.pomFarmerOverview("lblTotalSurveyedHectares"), "TOTAL SURVEYED HECTARES",
					"HA");
			assertApiUiAlphaNumericWithSuffix(responseStatisticsOverview, FoJsonKeys.jsonKeys("totalGpsMappedHectares"),
					PomFarmerOverviewPage.pomFarmerOverview("lblTotalGpsMappedHectares"), "TOTAL GPS MAPPED HECTARES",
					"HA");
			assertApiUiAlphaNumericWithSuffix(responseStatisticsOverview,
					FoJsonKeys.jsonKeys("aveEstimatedYieldSurveyedHA"),
					PomFarmerOverviewPage.pomFarmerOverview("lblAveEstimatedYieldSurveyedHA"),
					"AVERAGE ESTIMATED YIELD (SURVEYED HA)", "KG/HA");
			assertApiUiAlphaNumericWithSuffix(responseStatisticsOverview, FoJsonKeys.jsonKeys("aveEstimatedYieldGpsHA"),
					PomFarmerOverviewPage.pomFarmerOverview("lblAveEstimatedYieldGpsHA"),
					"AVERAGE ESTIMATED YIELD (GPS HA)", "KG/HA");
			assertApiUiAlphaNumeric(responseStatisticsOverview, FoJsonKeys.jsonKeys("aveGpsScore"),
					PomFarmerOverviewPage.pomFarmerOverview("lblAveGpsScore"), "AVERAGE GAP SCORE", "equals");
			assertApiUiAlphaNumeric(responseStatisticsOverview, FoJsonKeys.jsonKeys("numFarmersWithMobilePhone"),
					PomFarmerOverviewPage.pomFarmerOverview("lblNumFarmersWithMobilePhone"),
					"NUMBER OF FARMERS WITH A MOBILE PHONE", "equals");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Regression API Validaton - Overview Tab Ends
	// Regression API Validaton - Training Tab started
	@Test
	public synchronized void apiTrainingTabLeftPanel() throws Exception {
		try {
			webElementClick(PomFarmerOverviewPage.pomFarmerOverview("tab_training"), "Training Tab");
			Response responseCoursesAvl = postWithHeaders("coursesAvailableEndPoint", "getFarmerOverview.json");
			assertApiUiNumeric(responseCoursesAvl, FoJsonKeys.jsonKeys("trainingTabLeftPanel"),
					PomFarmerOverviewPage.pomFarmerOverview("coursesAvailableVal"), "COURSES AVAILABLE");

			Response responseModulesAvl = postWithHeaders("modulesAvailableEndPoint", "getFarmerOverview.json");
			assertApiUiNumeric(responseModulesAvl, FoJsonKeys.jsonKeys("trainingTabLeftPanel"),
					PomFarmerOverviewPage.pomFarmerOverview("modulesAvailableVal"), "MODULES AVAILABLE");

			Response responseTotalTrainedFarmers = postWithHeaders("totalTrainedFarmersEndPoint",
					"getFarmerOverview.json");
			assertApiUiNumeric(responseTotalTrainedFarmers, FoJsonKeys.jsonKeys("trainingTabLeftPanel"),
					PomFarmerOverviewPage.pomFarmerOverview("totalTrainedFarmersVal"), "TOTAL TRAINED FARMERS");

			Response responseTrainedThisMonth = postWithHeaders("trainedThisMonthEndPoint", "getFarmerOverview.json");
			assertApiUiNumeric(responseTrainedThisMonth, FoJsonKeys.jsonKeys("trainingTabLeftPanel"),
					PomFarmerOverviewPage.pomFarmerOverview("trainedThisMonthVal"), "TRAINED THIS MONTH");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiStatement() throws Exception {
		try {
			Response responseStatement = postWithHeaders("statementBlockEndPoint", "getFarmerOverview.json");
			assertApiUiAlphaNumeric(responseStatement, FoJsonKeys.jsonKeys("courseName"),
					PomFarmerOverviewPage.pomFarmerOverview("gridCourseName"), "COURSE", "equals");

			assertApiUiAlphaNumeric(responseStatement, FoJsonKeys.jsonKeys("moduleName"),
					PomFarmerOverviewPage.pomFarmerOverview("gridModuleName"), "Module", "equals");

			assertApiNumericUiString(responseStatement, FoJsonKeys.jsonKeys("status"),
					PomFarmerOverviewPage.pomFarmerOverview("gridStatus"), "Status", 1, "Active");

			assertApiUiAlphaNumeric(responseStatement, FoJsonKeys.jsonKeys("enumerator"),
					PomFarmerOverviewPage.pomFarmerOverview("gridEnumerator"), "Enumerator", "equals");

			assertApiUiAlphaNumeric(responseStatement, FoJsonKeys.jsonKeys("date"),
					PomFarmerOverviewPage.pomFarmerOverview("gridDate"), "Date", "equals");

			assertApiUiAlphaNumeric(responseStatement, FoJsonKeys.jsonKeys("time"),
					PomFarmerOverviewPage.pomFarmerOverview("gridTime"), "Time", "equals");

			assertApiUiNumeric(responseStatement, FoJsonKeys.jsonKeys("totalAttendees"),
					PomFarmerOverviewPage.pomFarmerOverview("gridTotalAttendees"), "Total Attendees");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiCourseList() throws Exception {
		try {
			Response courseList = postWithHeaders("courseList", "managementSeedling.json");
			assertApiUiAlphaNumeric(courseList, FoJsonKeys.jsonKeys("courseListCourseName"),
					PomFarmerOverviewPage.pomFarmerOverview("courseName"), "Course Name", "equals");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiTrainingTabEnumerators() throws Exception {
		try {
			Response responseEnumeratorsList = postWithHeaders("enumeratorsListEndPoint", "getFarmerOverview.json");
			assertApiUiAlphaNumeric(responseEnumeratorsList, FoJsonKeys.jsonKeys("enumeratorName"),
					PomFarmerOverviewPage.pomFarmerOverview("linkEnumeratorsName"), "Enumerator Name", "equals");

			assertApiUiNumeric(responseEnumeratorsList, FoJsonKeys.jsonKeys("enumFarmerCount"),
					PomFarmerOverviewPage.pomFarmerOverview("linkEnumFarmerCount"), "Enumerators->Farmers count");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	// Regression API Validaton - Training Tab Ends

	// Regression API Validaton - Management Tab Starts
	@Test
	public synchronized void apiManagementTabLeftPanel() throws Exception {
		try {
			webElementClick(PomFarmerOverviewPage.pomFarmerOverview("tab_management"), "Management Tab");
			Response responseFarmers = postWithHeaders("managementTabFarmersCount", "getFarmerOverview.json");
			assertApiUiNumeric(responseFarmers, FoJsonKeys.jsonKeys("managementTabLeftPanel"),
					PomFarmerOverviewPage.pomFarmerOverview("mgmt_farmer_count"), "Farmers");

			Response responseSections = postWithHeaders("managementTabSectionsCount", "getFarmerOverview.json");
			assertApiUiNumeric(responseSections, FoJsonKeys.jsonKeys("managementTabLeftPanel"),
					PomFarmerOverviewPage.pomFarmerOverview("mgtSectionsCount"), "Sections");

			Response fmpCount = postWithHeaders("managementTabFmpCount", "managementSeedling.json");
			assertApiUiNumeric(fmpCount, FoJsonKeys.jsonKeys("fmpCompletedCount"),
					PomFarmerOverviewPage.pomFarmerOverview("mgtFmpCount"), "FMP");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiFdpInputProgress() throws Exception {
		try {
			Response responseFertiliserCurrYr = postWithHeaders("fdpFertiliserCurrentYear", "managementSeedling.json");

			Float fertilizerRequiredCurrYr = getFloatValue(responseFertiliserCurrYr,
					FoJsonKeys.jsonKeys("fertilizerRequiredCurrYr"));
			String decimalFertiliserRequiredCurrYr = convertToTwoDecimalWithComma(fertilizerRequiredCurrYr);
			assertApiUiAlphaNumeric(decimalFertiliserRequiredCurrYr,
					PomFarmerOverviewPage.pomFarmerOverview("fertiliserCurrYr"), "Fertiliser Required current year",
					"contains");

			Float fertilizerGivenCurrYr = getFloatValue(responseFertiliserCurrYr,
					FoJsonKeys.jsonKeys("fertilizerGivenCurrYr"));
			String decimalFertiliserGivenCurrYr = convertToTwoDecimalWithComma(fertilizerGivenCurrYr);
			assertApiUiAlphaNumeric(decimalFertiliserGivenCurrYr,
					PomFarmerOverviewPage.pomFarmerOverview("fertiliserCurrYr"), "Fertiliser Given current year",
					"contains");

			Response responseFertiliserNextYear = postWithHeaders("fdpFertiliserNextYear", "managementSeedling.json");

			Float fertilizerRequiredNxtYr = getFloatValue(responseFertiliserNextYear,
					FoJsonKeys.jsonKeys("fertilizerRequiredNxtYr"));
			String decimalFertilizerRequiredNxtYr = convertToTwoDecimalWithComma(fertilizerRequiredNxtYr);
			assertApiUiAlphaNumeric(decimalFertilizerRequiredNxtYr,
					PomFarmerOverviewPage.pomFarmerOverview("fertiliserRequiredNextYr"),
					"Fertiliser Required Next Year", "contains");

			Response responseSeedlingCurrYr = postWithHeaders("fdpSeedlingCurrentYear", "managementSeedling.json");

			Float seedlingRequiredCurrYr = getFloatValue(responseSeedlingCurrYr,
					FoJsonKeys.jsonKeys("seedlingRequiredCurrYr"));
			String decimalSeedlingRequiredCurrYr = convertToTwoDecimalWithComma(seedlingRequiredCurrYr);
			assertApiUiAlphaNumeric(decimalSeedlingRequiredCurrYr,
					PomFarmerOverviewPage.pomFarmerOverview("seedlingcurrYr"), "Seedling Required current year",
					"contains");

			Float seedlingGivenCurrYr = getFloatValue(responseSeedlingCurrYr,
					FoJsonKeys.jsonKeys("seedlingGivenCurrYr"));
			String decimalSeedlingGivenCurrYr = convertToTwoDecimalWithComma(seedlingGivenCurrYr);
			assertApiUiAlphaNumeric(decimalSeedlingGivenCurrYr,
					PomFarmerOverviewPage.pomFarmerOverview("seedlingcurrYr"), "Seedling Given current year",
					"contains");

			Response responseSeedlingNextYear = postWithHeaders("fdpSeedlingNextYear", "managementSeedling.json");

			Float seedlingRequiredNxtYr = getFloatValue(responseSeedlingNextYear,
					FoJsonKeys.jsonKeys("seedlingRequiredNxtYr"));
			String decimalSeedlingRequiredNxtYr = convertToTwoDecimalWithComma(seedlingRequiredNxtYr);
			assertApiUiAlphaNumeric(decimalSeedlingRequiredNxtYr,
					PomFarmerOverviewPage.pomFarmerOverview("seedlingRequiredNextYr"), "Seedling Required Next Year",
					"contains");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiManagementSections() throws Exception {
		try {
			Response managementSections = postWithHeaders("managementSections", "managementSeedling.json");
			assertApiUiNumeric(managementSections, FoJsonKeys.jsonKeys("managementSectionFarmer"),
					PomFarmerOverviewPage.pomFarmerOverview("managementSectionFarmer"), "Sections Farmer Count");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiGeneratedPlan() throws Exception {
		try {
			Response generatedPlan = postWithHeaders("managementTabFmp", "managementSeedling.json");
			assertApiUiNumeric(generatedPlan, FoJsonKeys.jsonKeys("fmpCompletedCount"),
					PomFarmerOverviewPage.pomFarmerOverview("fmpCompleted"), "Completed");
			assertApiUiNumeric(generatedPlan, FoJsonKeys.jsonKeys("fmpAvailableCount"),
					PomFarmerOverviewPage.pomFarmerOverview("fmpAvailable"), "Available");
			assertApiUiNumeric(generatedPlan, FoJsonKeys.jsonKeys("fmpCompletedCount"),
					PomFarmerOverviewPage.pomFarmerOverview("fmpChartCenter"), "Chart Center");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public synchronized void apiFarmerManagementPlan() throws Exception {

		Response fmpCount = postWithHeaders("fmpCount", "managementSeedling.json");
		foApiFarmerManagementPlan(fmpCount, "Farmer Management Plan Block - ");
	}

	// Regression API Validaton - Management Tab Ends
	// **************FARMER OVERVIEW PAGE REGRESSION API Validation
	// ENDS**************

	// **************TASKS PAGE REGRESSIONS STARTS**************
	@Test
	public synchronized void taskListNavigation() throws Exception {
		Thread.sleep(8000);
		webElementClick(Menus.pomMenus("Menu_tasks"), "Menu tasks");
		Thread.sleep(5000);
		webElementClick(PomTasksPage.pomTasks("EmuneratorTask"), "Emunerator Task List");
		Thread.sleep(7000);
		angularWebTableFetchAndClickFirstRow(PomTasksPage.pomTasks("popupAngularWebTable"));
		Thread.sleep(7000);
		assertStringContainsAlphaNumeric(PomTasksPage.pomTasks("txtText"), 8, "Text");
		assertStringContainsAlphaNumeric(PomTasksPage.pomTasks("lblCreatedBy"), 9, "Created By");
		formatDateAndAssertContainsUIData(PomTasksPage.pomTasks("lblLastUpdatedOn"), 1, "Created On");
	}

	@Test
	public synchronized void taskDetailsActionsEditAndAddAssignees() throws Exception {

		webElementClick(PomTasksPage.pomTasks("btnEditTaskDetails"), "edit Task Details");
		Thread.sleep(3000);
		assertStringContainsAlphaNumeric(PomTasksPage.pomTasks("txtText"), 8, "Text");
		webElementClick(PomTasksPage.pomTasks("btnEditCancel"), "edit Cancel");
		Thread.sleep(3000);
		getTextFromElement(PomTasksPage.pomTasks("gridName"));
		webElementClick(PomTasksPage.pomTasks("btnAddAssignees"), "Add Assignees");
		Tasks TasksPage = new Tasks(driver);
		TasksPage.dropdownPopulatingValueValidation();
		webElementClick(PomTasksPage.pomTasks("btnView"), "View");
		Thread.sleep(3000);
		assertStringContainsAlphaNumeric(PomTasksPage.pomTasks("gridEnumeratorName"), "Enumerator Name");
		TasksPage.searchEnumeratorAndValidateValues("gridAllNames", "enumerator", "Name Column");
		Thread.sleep(2000);
		webElementClick(PomTasksPage.pomTasks("btnEnumeratorCancel"), "Enumerator Cancel");
		Thread.sleep(2000);
		navigateToPopupAndClose("popupTitle");
	}

	@Test
	public synchronized void chooseRecipientSearchAndView() throws Exception {
		Thread.sleep(3000);
		webElementClick(PomTasksPage.pomTasks("btnChooseRecipients"), "Choose Recipients");
		Tasks TasksPage = new Tasks(driver);
		TasksPage.dropdownPopulatingValueValidation();
		TasksPage.searchEnumeratorAndValidateValues("gridAllNames", "enumerator", "Name Column");
		TasksPage.searchEnumerator("lblRecipients", "Recipients");
	}

	@Test
	public synchronized void enumeratorGroupSearchAndView() throws Exception {
		Thread.sleep(3000);
		webElementClick(PomTasksPage.pomTasks("btnEnumeratorGroupAdd"), "Enumerator Group Add");
		webElementClick(PomTasksPage.pomTasks("btnSelectEnumerator"), "select Enumertor");
		Tasks TasksPage = new Tasks(driver);
		TasksPage.dropdownPopulatingValueValidation();
		TasksPage.searchEnumeratorAndValidateValues("gridAllNames", "enumerator", "Name Column");
		TasksPage.searchEnumerator("lblEnumerators", "Enumerator Count");
	}

	@Test
	public synchronized void smsCampaignsNavigation() throws Exception {
		Thread.sleep(8000);
		webElementClick(Menus.pomMenus("Menu_tasks"), "Menu tasks");
		Thread.sleep(5000);
		webElementClick(PomSMSCampaignsPage.pomSMSCampaigns("thumbnailSMSCampaigns"), "SMS Campaigns");

	}

	@Test
	public synchronized void smsCampaignsChooseRecipient() throws Exception {
		Thread.sleep(3000);
		webElementClick(PomTasksPage.pomTasks("btnChooseRecipients"), "Choose Recipients");
		Tasks TasksPage = new Tasks(driver);
		TasksPage.dropdownPopulatingValueValidationSMSCampaigns();
		TasksPage.searchFarmerAndValidateValues("gridAllFarmerNames", "sky", "Name Column", "lblFarmerRecipients",
				"Recipients");

	}

	@Test
	public synchronized void reviewSubmittedDataCocoaAnnualSurvey() throws Exception {
		Thread.sleep(8000);
		webElementClick(Menus.pomMenus("Menu_tasks"), "Menu tasks");
		Thread.sleep(5000);
		webElementClick(PomTasksPage.pomTasks("reviewSubmittedData"), "Review Submitted Datas");
		Thread.sleep(15000);
		Tasks TasksPage = new Tasks(driver);
		TasksPage.reviewSubmittedDataAndFarmerProfileValidation("Cocoa Annual Survey");
	}

	@Test
	public synchronized void reviewSubmittedDataCocoaBaselineSurvey() throws Exception {

		Thread.sleep(2000);
		Tasks TasksPage = new Tasks(driver);
		TasksPage.reviewSubmittedDataAndFarmerProfileValidation("Cocoa Baseline Survey");
	}

	// Manage GPX
	@Test
	public synchronized void taskManageGpxFindFarmerButtonDisabledValidation() throws Exception {
		ManageGPX mgps = new ManageGPX(driver);
		mgps.manageGpxFindFarmerButtonDisabledValidation();
	}

	@Test
	public synchronized void taskManageGpxFindFarmerButtonEnabledValidation() throws Exception {
		ManageGPX mgps = new ManageGPX(driver);
		mgps.manageGpxFindFarmerButtonEnabledValidation();
	}

	@Test
	public synchronized void taskManageGpxUploadGpxFile() throws Exception {
		ManageGPX mgps = new ManageGPX(driver);
		mgps.manageGpxUploadGpxFile();
	}

	@Test
	public synchronized void taskManageGpxSearchFarmer() throws Exception {
		ManageGPX mgps = new ManageGPX(driver);
		mgps.manageGpxSearchFarmer();
	}

	// **************TASKS PAGE REGRESSIONS ENDS**************

}
