package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomCountries {

	public synchronized String pomCountries(String locator)
	{
		try
		{
			Hashtable<String,String> hs = new Hashtable<String,String>();
			hs.put("thumbnail_allcountries", "xpath#//*[@class='col-sm-6 col-md-4'][1]/a/div/div");
			hs.put("Header_allcountries_PageHeader", "xpath#//*[@class='page-header ofisHeader']");
			
			hs.put("txt_code", "id#countryCode");
			hs.put("txt_countryName", "id#countryName");
			hs.put("txt_diallingCode", "id#diallingCode");
			hs.put("txt_centreLat", "id#centreLat");
			hs.put("txt_centreLng", "id#centreLng");
			hs.put("txt_smsOriginatorId", "id#smsOriginatorId");
			hs.put("chk_olam_country", "id#olam_country");
			hs.put("chk_activecountry", "xpath#//*[@class='form-group'][9]/div/input[2]");
			
			//Edit all countries page
			hs.put("txt_countryId", "id#countryId");			
			hs.put("btn_edit_allcountries", "css#div.ag-row-first div.farmerEdit span span");
			hs.put("Header_edit_allcountries", "xpath#//*[@class='page-header ofisHeader']");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");
			
			return hs.get(locator);
		}catch(Exception e)
		{
			System.out.println("Error occurred in POM classes :"+e);
			return null;
		}
		
	}
}
