package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomPartners {

	public synchronized String pomPartners(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("txt_email", "id#email");
			hs.put("txt_password", "id#password");
			hs.put("check_Policy", "id#ofis-guest-policy-agreement");
			hs.put("btn_Submit", "id#ofis-guest-login-submit");
			hs.put("Menu_Settings", "xpath#//*[@routerlink='/settings']");
			hs.put("thumbnail_ppp", "xpath#//*[@routerlink='/progspartsproducts']");
			hs.put("thumbnail_Addprogrammes", "xpath#//*[@class='thumbnail']/div/p");
			hs.put("thumbnail_Createprogrammes", "xpath#//*[@class='glyphicon glyphicon-plus']");
			hs.put("thumbnail_Checkbutton", "xpath#//*[@id='active']");

			hs.put("test", "xpath#//*[@class='close']");
			hs.put("icon", "xpath#//*[@class='ag-header-icon ag-sort-ascending-icon ag-hidden']");

			// Partner
			hs.put("Menu_Set", "xpath#//*[@routerlink='/settings']");
			hs.put("thumbnail_ppp", "xpath#//*[@routerlink='/progspartsproducts']");
			hs.put("thumbnail_partner",
					"xpath#//*[@class='container-fluid ofis-core-body-container']/div/app-progspartsproducts/div/div/div/div[2]/a/div/div/p");
			hs.put("pageheader_partner", "xpath#//*[@class='page-header']");

			hs.put("Partslc", "xpath#//*[@class='caption']//*[text()='All Partners']");

			hs.put("Addpart", "xpath#//*[@class='btn btn-primary']");
			hs.put("programme", "xpath#//*[@id='programmes']");
			hs.put("partcreate", "xpath#//*[@class='btn btn-primary']");

			// edit partner
			hs.put("btn_editpartner", "css#div[row-index='0'] div[col-id='0'] a");
			hs.put("pageheader_editpartner", "xpath#//*[@class='page-header']");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");
			hs.put("txt_partnerid", "id#id");
			hs.put("txt_name", "id#name");
			hs.put("chk_active", "id#active");

			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}

	}

}
