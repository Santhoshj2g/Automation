package com.olam.ofis.pom;

import java.util.Hashtable;

public class JsonPomFarmerProfile {

	public synchronized String jsonFarmerProfile(String getKey)
	{

		try
		{
			Hashtable<String, String> hs = new Hashtable<String, String>();
			
			//Farmer Profile
			hs.put("farmers", "outputdata.fgOverviewStats[0].val");
			hs.put("numberOfPlots", "outputdata.farmdetails.number_plots");
			hs.put("farmSize", "outputdata.farmdetails.estimated_planted_area");
			hs.put("shadeTrees", "answer[3].get('answer_int')");
			
			return hs.get(getKey);

		}catch(Exception e){
			System.out.println("Error occurred in POM classes :"+e);
			return null;
		}
	}



}