package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomPlaces {

	public synchronized String pomPlacesr(String locator) {
		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("thumbnail_districts", "xpath#//*[@class='col-sm-6 col-md-4'][4]/a/div/div");
			hs.put("Header_PageHeader", "xpath#//*[@class='page-header ofisHeader']");
			hs.put("btn_AddPlaces", "xpath#//*[@class='btn btn-primary']");

			hs.put("drp_district", "xpath#//*[@formcontrolname='districtId']/optgroup[111]/option[2]");
			hs.put("drp_type", "xpath#//*[@formcontrolname='type']/option[1]");
			hs.put("txt_name", "id#name");
			hs.put("chk_active", "xpath#//input[@type='checkbox']");
			hs.put("btn_add_places", "xpath#//*[@class='btn btn-primary']");

			// Edit all regions page
			hs.put("btn_edit_allPlaces", "css#div[row-index='0'] div[col-id='0']");
			hs.put("Header_edit_alldistricts", "xpath#//*[@class='page-header']");
			hs.put("txt_placeid", "id#placeId");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");

			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
