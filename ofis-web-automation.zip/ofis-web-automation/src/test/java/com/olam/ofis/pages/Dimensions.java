package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomDimensions;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Dimensions extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomDimensions pomDimensions = new PomDimensions();

	public Dimensions(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderAllDimensions;
	private String expectedPageHeaderEditAllDimensions;
	private int expectedDimensionId;
	private String expectedRelatedQuestion;
	private String expectedTitle;
	private String expectedNameFrench;
	private String expectedNameSpanish;
	private String expectedNameIndonesian;
	private String expectedNamePortuguese;
	private String expectedNameTurkish;
	private String expectedNameLao;
	private String expectedNameVietnamese;
	private String expectedNameThai;

	public synchronized void allDimensionsLoadExcelData()
			throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/AllDimensions.xlsx");

		expectedPageHeaderAllDimensions = read.getCellData("AllDimensionsTC", "pageHeaderAllDimensions", 1);
		expectedPageHeaderEditAllDimensions = read.getCellData("AllDimensionsTC", "pageHeaderEditAllDimensions", 1);
		expectedDimensionId = read.getNumericCellData("AllDimensionsTC", "textDimenionId", 1);
		expectedRelatedQuestion = read.getCellData("AllDimensionsTC", "labelRelatedQuestion", 1);
		expectedTitle = read.getCellData("AllDimensionsTC", "textTitle", 1);

		expectedNameFrench = read.getCellData("AllDimensionsTC", "textNameFr", 1);
		expectedNameSpanish = read.getCellData("AllDimensionsTC", "textNameEs", 1);
		expectedNameIndonesian = read.getCellData("AllDimensionsTC", "textNameId", 1);
		expectedNamePortuguese = read.getCellData("AllDimensionsTC", "textNamePt", 1);
		expectedNameTurkish = read.getCellData("AllDimensionsTC", "textNameTr", 1);
		expectedNameLao = read.getCellData("AllDimensionsTC", "textNameLo", 1);
		expectedNameVietnamese = read.getCellData("AllDimensionsTC", "textNameVi", 1);
		expectedNameThai = read.getCellData("AllDimensionsTC", "textNameTh", 1);

	}

	public synchronized void settingsDimensionsDataClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_dimensiondata"), "Settings->Dimensions data");
	}

	public synchronized void dimensionsClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomDimensions.pomDimensions("thumbnailDimensions"), "thumbnail Dimensions");
	}

	public synchronized void dimensionsPageHeaderValidation() throws InterruptedException {
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(pomDimensions.pomDimensions("Header_PageHeader"),
				expectedPageHeaderAllDimensions, "PageHeader Dimenions");
	}

	public synchronized void editDimensionsButtonClick() throws InterruptedException {
		Thread.sleep(12000);
		webElementMouseHoverAndClick(pomDimensions.pomDimensions("btnEditDimensions"),
				"Edit dimensions button");
	}

	public synchronized void editDimensionsPageHeaderValidation() throws InterruptedException {
		Thread.sleep(10000);
		webAssertEqualsAlphaNumeric(pomDimensions.pomDimensions("headerEditDimensions"),
				expectedPageHeaderEditAllDimensions, "Edit Dimensions Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomDimensions.pomDimensions("btn_Cancel"), "cancel");
	}

	public synchronized void validateDimensionsValues() throws InterruptedException {
		Thread.sleep(7000);
		webGetAttributeValueAndAssertEqualsNumeric(pomDimensions.pomDimensions("txtDimensionID"),
				expectedDimensionId, "Dimension ID");
		webAssertEqualsAlphaNumeric(pomDimensions.pomDimensions("lblRelatedQuestion"),
				expectedRelatedQuestion, "label Related Question");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomDimensions.pomDimensions("txtTitle"),
				expectedTitle, "Title");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomDimensions.pomDimensions("txtNameFr"),
				expectedNameFrench, "French Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomDimensions.pomDimensions("txtNameEs"),
				expectedNameSpanish, "Spanish Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomDimensions.pomDimensions("txtNameId"),
				expectedNameIndonesian, "Bahasa Indonesian Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomDimensions.pomDimensions("txtNamePt"),
				expectedNamePortuguese, "Portuguese Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomDimensions.pomDimensions("txtNameTr"),
				expectedNameTurkish, "Turkish Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomDimensions.pomDimensions("txtNameLo"),
				expectedNameLao, "Lao Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomDimensions.pomDimensions("txtNameVi"),
				expectedNameVietnamese, "Vietnamese Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomDimensions.pomDimensions("txtNameTh"),
				expectedNameThai, "Thai Name");
	}
}
