package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.pom.PomSMSCampaigns;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class SMSCampaigns extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomSMSCampaigns pomSMSCampaigns = new PomSMSCampaigns();

	public SMSCampaigns(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderSMSCampaigns;
	private String expectedCreator;
	private int expectedRecipients;
	private String expectedMessage;
	private String expectedStatus;
	private String expectedDate;

	public synchronized void smsCampaignsLoadExcelData() throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/SMSCampaigns.xlsx");

		expectedPageHeaderSMSCampaigns = read.getCellData("SMSCampaignsTC", "pageHeaderSMSCampaigns", 1);
		expectedCreator = read.getCellData("SMSCampaignsTC", "gridCreator", 1);
		expectedRecipients = read.getNumericCellData("SMSCampaignsTC", "gridRecipients", 1);
		expectedMessage = read.getCellData("SMSCampaignsTC", "gridMessage", 1);
		expectedStatus = read.getCellData("SMSCampaignsTC", "gridStatus", 1);
		expectedDate = read.getCellData("SMSCampaignsTC", "gridDate", 1);
	}

	public synchronized void menuTasksClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomMenus.pomMenus("Menu_tasks"), "Menu Tasks");
	}

	public synchronized void thumbnailSMSCampaignsClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomSMSCampaigns.pomSMSCampaigns("thumbnailSMSCampaigns"), "thumbnail SMS Compaigns");
	}

	public synchronized void smsCampaignsPageHeaderValidation() throws InterruptedException {
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(pomSMSCampaigns.pomSMSCampaigns("Header_PageHeader"),
				expectedPageHeaderSMSCampaigns, "PageHeader SMS Compaigns");
	}

	public synchronized void validateSMSCampaignsValues() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomSMSCampaigns.pomSMSCampaigns("grdCreator"), expectedCreator,
				"grid Creator");
		webAssertEqualsNumeric(pomSMSCampaigns.pomSMSCampaigns("grdRecipients"), expectedRecipients,
				"grid Recipients");
		webAssertEqualsAlphaNumeric(pomSMSCampaigns.pomSMSCampaigns("grdMessage"), expectedMessage,
				"grid Message");
		webAssertEqualsAlphaNumeric(pomSMSCampaigns.pomSMSCampaigns("grdStatus"), expectedStatus,
				"grid Status");
		webAssertEqualsAlphaNumeric(pomSMSCampaigns.pomSMSCampaigns("grdDate"), expectedDate, "grid Date");
	}
}
