package com.olam.ofis.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import com.olam.ofis.pom.PomFarmDevelopmentPlan;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.wrappers.Functions;

public class FDP_Setting extends Functions {

	PomFarmDevelopmentPlan pomFarmDevelopmentPlan = new PomFarmDevelopmentPlan();
	PomMenus pomMenus = new PomMenus();

	public FDP_Setting(RemoteWebDriver driver) {
		this.driver = driver;
	}

	public synchronized void clickSetting() {
		waitTill(5000);
		webElementClick(pomMenus.pomMenus("Menu_Settings"), "Setting Click");
	}	

	public synchronized void verifyLabel(String pomName, String expectedLabel) {
		String uiLabel = webElementGetText(pomFarmDevelopmentPlan.pomFarmDevelopmentPlan(pomName));
		verifyText(expectedLabel.trim(), uiLabel.trim());
		waitTill(2000);
	}
	public synchronized void clickButton(String pomName,String txtMsg) {
		waitTill(2000);
		click(pomFarmDevelopmentPlan.pomFarmDevelopmentPlan(pomName), txtMsg);
		waitTill(5000);
	}
	public synchronized void webElementClickButton(String pomName,String txtMsg) {
		waitTill(2000);
		webElementClick(pomMenus.pomMenus(pomName), txtMsg);
		//webElementClick(FMP.pomFarmDevelopmentPlan(pomName), txtMsg);
		waitTill(5000);
	}

	
	public synchronized void selectTemplateType(String templateType) {
		click(pomFarmDevelopmentPlan.pomFarmDevelopmentPlan(templateType), "click on " + templateType);
	}


	// getting text from text area from the all advice
	public synchronized void getTextAreaFromAdvice(String pomName,String gapLabelName) {
		List<WebElement> labelname = selectLocatorsBylists("",pomFarmDevelopmentPlan.pomFarmDevelopmentPlan(pomName));
		int Count = labelname.size();
		System.out.println(Count);
		for (int i = 0; i < Count; i++) {
			String s = labelname.get(i).getText();

			if (s.contains(gapLabelName)) {
				int j = i + 1;
				WebElement ele = driver
						.findElement(By.xpath("(//div[@class='col col-md-8 col-width-70']/textarea)[" + j + "]"));

				String textareavalue = ele.getAttribute("value");
				System.out.println(textareavalue);
				break;
			}
		}
	}


	// verify the label in the gap advice
	public synchronized void verifyGaplabel(String pomName,String expectedGaplblName) {
		//gapadviceslabel
		List<WebElement> labelname = selectLocatorsBylists("",pomFarmDevelopmentPlan.pomFarmDevelopmentPlan(pomName));
		int Count = labelname.size();
		System.out.println(Count);
		for (WebElement listofelement : labelname) {

			String actualresult = listofelement.getText();
			if (actualresult.contains(expectedGaplblName)) {
				System.out.println(
						"Excepted result" + expectedGaplblName + " is equal to my Actualresult" + actualresult);

				break;
			}
		}
	}


	public synchronized void getPesticideAdviceTextArea(String pesticideLabelName) {
		List<WebElement> labelname = selectLocatorsBylists("",pomFarmDevelopmentPlan.pomFarmDevelopmentPlan("pesticideadviceslabel"));
		int Count = labelname.size();
		System.out.println(Count);
		for (WebElement Pesticidelblvalue : labelname) {
			String s = Pesticidelblvalue.getText();
			if (s.contains(pesticideLabelName)) {
				String textareavalue = webElementGetAttribute(pomFarmDevelopmentPlan.pomFarmDevelopmentPlan("pesticidetextarea"), "value");
				System.out.println(textareavalue);
				break;
			}
		}
	}

	public synchronized void assignmentTypeValue(String assignmentValue) {

		List<WebElement>lst=selectLocatorsBylists("xpath",pomFarmDevelopmentPlan.pomFarmDevelopmentPlan("assignmentvaluelst"));
		int assignmentSize=lst.size();
		System.out.println(assignmentSize);

		for (WebElement assignmentweblist : lst) {

			String valuename=assignmentweblist.getText();

			if (valuename.equalsIgnoreCase(assignmentValue)) {

				assignmentweblist.click();
				break;
			}
		}
	}

	/*
	 * This method is used for selecting segment cordent based on the our input 
	 * 
	 */

	public synchronized void selectSegment(String selectCordent,String segmentMap) {

		if(selectCordent.contains("maxpermaxpot")) {
			click(pomFarmDevelopmentPlan.pomFarmDevelopmentPlan("maxpermaxpot"), "clicked segmentMaxPerMaxpot");
			waitTill(2000);
		}
		else if (selectCordent.contains("maxPerminPot")) {
			click(pomFarmDevelopmentPlan.pomFarmDevelopmentPlan("maxperminpot"), "clicked maxmin");
			waitTill(2000);	
		}

		else if(selectCordent.contains("minpermaxpot")) {
			click(pomFarmDevelopmentPlan.pomFarmDevelopmentPlan("minpermaxpot"), "clicked segmentMinperMaxpot");
			waitTill(2000);
		}
		else if(selectCordent.contains("minperminpot"))  {

			click(pomFarmDevelopmentPlan.pomFarmDevelopmentPlan("minperminpot"), "segmentMinperMinpot");
			waitTill(2000);

		}

		List<WebElement>lst=selectLocatorsBylists("",pomFarmDevelopmentPlan.pomFarmDevelopmentPlan("dropdownforsegment"));
		int Size=lst.size();
		System.out.println(Size);
		for (WebElement assignmentweblist : lst) {

			String valuename=assignmentweblist.getText();

			if (valuename.trim().equalsIgnoreCase(segmentMap)) {
				assignmentweblist.click();
				break;
			}

		}
	}

	public synchronized void selectAssignmentType(String PomName,String dropdownValue,String reports) {

		webDropdown(pomFarmDevelopmentPlan.pomFarmDevelopmentPlan(PomName), dropdownValue,reports);

	}

	public synchronized void waitAndClick(String pomName,String report) {
		try {

			waitUntilElementToBeClicked(pomFarmDevelopmentPlan.pomFarmDevelopmentPlan(pomName),report);
		}
		catch(Exception e) {
			System.out.println("Element is not clicked next button is displayed "+e.getMessage());
		}

	}
}	


