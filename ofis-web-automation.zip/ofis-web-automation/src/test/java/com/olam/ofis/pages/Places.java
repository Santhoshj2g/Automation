package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.pom.PomPlaces;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Places extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomPlaces pomPlaces = new PomPlaces();

	public Places(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderAllPlaces;
	private String expectedPageHeaderEditAllPlaces;
	private int expectedPlaceId;
	private String expectedDistrict;
	private String expectedType;
	private String expectedName;

	public synchronized void allPlacesLoadExcelData()
			throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/AllPlaces.xlsx");

		expectedPageHeaderAllPlaces = read.getCellData("AllPlacesTC", "pageHeader_allplaces", 1);
		expectedPageHeaderEditAllPlaces = read.getCellData("AllPlacesTC", "pageHeader_edit_allplaces", 1);
		expectedPlaceId = read.getNumericCellData("AllPlacesTC", "text_placeid", 1);
		expectedDistrict = read.getCellData("AllPlacesTC", "drp_district", 1);
		expectedType = read.getCellData("AllPlacesTC", "drp_type", 1);
		expectedName = read.getCellData("AllPlacesTC", "text_name", 1);

	}

	public synchronized void settingsGeographicDataClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),
				pomMenus.pomMenus("Settings_geographical"), "Settings->GeographicalData");
	}

	public synchronized void switchIntoIframe() throws InterruptedException {

		Thread.sleep(1000);
		iFrameSwitchTo(pomMenus.pomMenus("iFrame_OFISUser"), "iFrame-OFISGeographicalData");
	}

	public synchronized void switchoutFromIframe() throws InterruptedException {

		Thread.sleep(1000);
		iFrameSwitchOut("iFrame-OFIS Geographical data");
	}

	public synchronized void allPlacesClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomPlaces.pomPlacesr("thumbnail_districts"), "thumbnail all places");
	}

	public synchronized void allPlacesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomPlaces.pomPlacesr("Header_PageHeader"), expectedPageHeaderAllPlaces,
				"PageHeader all places");
	}

	public synchronized void editAllPlacesButtonClick() throws InterruptedException {
		Thread.sleep(3000);
		webElementMouseHoverAndClick(pomPlaces.pomPlacesr("btn_edit_allPlaces"), "Edit all places button");
	}

	public synchronized void editAllPlacesPageHeaderValidation() throws InterruptedException {
		Thread.sleep(8000);
		webAssertEqualsAlphaNumeric(pomPlaces.pomPlacesr("Header_edit_alldistricts"),
				expectedPageHeaderEditAllPlaces, "Edit all places Page header");
	}

	public synchronized void editPageCancelClick() throws InterruptedException {

		webElementClick(pomPlaces.pomPlacesr("btn_Cancel"), "cancel");
	}

	public synchronized void validateAllPlacesValues() throws InterruptedException {
		Thread.sleep(7000);
		webGetAttributeValueAndAssertEqualsNumeric(pomPlaces.pomPlacesr("txt_placeid"), expectedPlaceId,
				"place id");
		webAssertEqualsAlphaNumeric(pomPlaces.pomPlacesr("drp_type"), expectedType, "type dropdown");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomPlaces.pomPlacesr("txt_name"), expectedName,
				"name");
		verifyWebCheckBoxIsSelected(pomPlaces.pomPlacesr("chk_active"), "active place - checkbox");
	}
}
