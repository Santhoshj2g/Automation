package com.olam.ofis.pom;

import java.util.Hashtable;

public class PomCourses {

	public synchronized String pomCourses(String locator) {

		try {
			Hashtable<String, String> hs = new Hashtable<String, String>();

			hs.put("thumbnailCourses", "xpath#//p[contains(text(), 'edit courses')]");
			hs.put("Header_PageHeader", "xpath#//*[@class='page-header']");

			// Add Courses page
			hs.put("txtName", "id#name");
			hs.put("txtTargetPercent", "xpath#//*[@formcontrolname='target_percentage']");
			hs.put("txtTargetNum", "xpath#//*[@formcontrolname='target_number']");
			hs.put("drpProductType", "id#product_type");
			hs.put("drpAssignmentType", "id#assignment_type");

			hs.put("txtNameFr", "id#name_fr");
			hs.put("txtNameEs", "id#name_es");
			hs.put("txtNameId", "id#name_id");
			hs.put("txtNamePt", "id#name_pt");
			hs.put("txtNameTr", "id#name_tr");
			hs.put("txtNameLo", "id#name_lo");
			hs.put("txtNameVi", "id#name_vi");
			hs.put("txtNameTh", "id#name_th");
			hs.put("chkActiveCourse", "id#active");

			// edit Courses page
			hs.put("btnEditCourses", "css#div[row-index='0'] div[col-id='0'] a");
			hs.put("headerEditCourses", "xpath#//*[@class='page-header']");
			hs.put("btn_Cancel", "xpath#//*[@class='btn btn-default']");

			return hs.get(locator);
		} catch (Exception e) {
			System.out.println("Error occurred in POM classes :" + e);
			return null;
		}
	}

}
