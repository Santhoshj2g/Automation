package com.olam.ofis.pages;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.pom.PomUsers;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Users extends Functions {

	PomUsers pomUsers = new PomUsers();
	PomMenus pomMenus = new PomMenus();

	public Users(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderUser;
	private String expectedPageHeaderEditUsersPage;
	private int expectedUserId;
	private String expectedFirstName;
	private String expectedLastName;
	private String expectedEmail;
	private String expectedRole;
	private String expectedViewBy;

	public synchronized void userCreationLoadExcelData() throws Exception {

		// Expected data is retrieved from Excel sheet and it will be compared with
		// actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/UserCreation.xlsx");

		expectedPageHeaderUser = read.getCellData("UserCreationTC", "PageHeader_UsersPage", 1);
		expectedUserId = read.getNumericCellData("UserCreationTC", "text_userid", 2);
		expectedFirstName = read.getCellData("UserCreationTC", "text_firstname", 2);
		expectedLastName = read.getCellData("UserCreationTC", "text_lastname", 2);
		expectedEmail = read.getCellData("UserCreationTC", "text_email", 2);
		expectedRole = read.getCellData("UserCreationTC", "dropdown_role", 2);
		expectedViewBy = read.getCellData("UserCreationTC", "dropdown_viewby", 1);
		expectedPageHeaderEditUsersPage = read.getCellData("UserCreationTC", "PageHeader_editUsersPage", 1);
	}

	public synchronized void settingsUsersClick() throws InterruptedException {
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"), pomMenus.pomMenus("Settings_ofis-users"),
				"Settings-Users");
	}

	public synchronized void navigateToIframe() throws InterruptedException {
		iFrameSwitchTo(pomUsers.pomUsers("iFrame_OFISUser"), "iFrame-OFISUser");
	}

	public synchronized void switchoutFromIframe() throws InterruptedException {
		iFrameSwitchOut("iFrame-OFISUser");
	}

	public synchronized void websiteUserClick() throws InterruptedException {
		Thread.sleep(5000);
		webElementClick(pomUsers.pomUsers("Menu_WebUser"), "thumbnail Website User");
	}

	public synchronized void userPageHeaderValidation() throws InterruptedException {
		waitTill(7000);
		webAssertEqualsAlphaNumeric(pomUsers.pomUsers("Header_UserPageHeader"), this.expectedPageHeaderUser,
				"User Page header");
	}

	public synchronized void editUserPageHeaderValidation() throws InterruptedException {
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomUsers.pomUsers("Header_EditUserPage"), this.expectedPageHeaderEditUsersPage,
				"Edit user Page header");
	}

	public synchronized void validateUsersValues() throws InterruptedException {
		Thread.sleep(2000);
		webGetAttributeValueAndAssertEqualsNumeric(pomUsers.pomUsers("txt_userid"), expectedUserId, "user id");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomUsers.pomUsers("txt_first_name"), expectedFirstName,
				"First Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomUsers.pomUsers("txt_last_name"), expectedLastName,
				"last Name");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomUsers.pomUsers("txt_useremail"), expectedEmail,
				"Email id");
		verifyWebTextBoxIsEmpty(pomUsers.pomUsers("txt_userpassword"), "password");
		verifyWebTextBoxIsEmpty(pomUsers.pomUsers("txt_confirm_password"), "confirm password");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(pomUsers.pomUsers("drp_role"), expectedRole,
				"Country - dropdown");
		verifyWebCheckBoxIsSelected(pomUsers.pomUsers("chk_active_user"), "Active User - checkbox");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(pomUsers.pomUsers("drp_view_by"), expectedViewBy,
				"View by - dropdown");
		verifyWebCheckBoxIsSelected(pomUsers.pomUsers("chk_download_farmer_data"), "download farmer data - checkbox");
		verifyWebCheckBoxIsSelected(pomUsers.pomUsers("chk_view"), "view - checkbox");
		verifyWebCheckBoxIsSelected(pomUsers.pomUsers("chk_manage"), "manage - checkbox");
		verifyWebCheckBoxIsNotSelected(pomUsers.pomUsers("chk_can_send_messages"), "can send messages - checkbox");
		verifyWebCheckBoxIsNotSelected(pomUsers.pomUsers("chk_can_send_unapproved_messages"),
				"can send unapproved messages - checkbox");
		verifyWebCheckBoxIsNotSelected(pomUsers.pomUsers("chk_can_approve_messages"),
				"can send approve messages - checkbox");
		verifyWebTextBoxIsEmpty(pomUsers.pomUsers("txt_mblox_service_name"), "Twilio Account Name");
		verifyWebTextBoxIsEmpty(pomUsers.pomUsers("txt_mblox_service_key"), "Twilio SID");

	}

	public synchronized void clickButton(String pomName, String txtMsg) throws InterruptedException {
		waitTill(7000);
		click(pomUsers.pomUsers(pomName), txtMsg);
	}

	public synchronized void selectViewBy(String viewByName, String listby) {

		webDropdown(pomUsers.pomUsers("drp_view_by"), viewByName, listby);
		waitTill(7000);

		switch (viewByName) {
		case "Country":
			webListSelectSingleItemByText(pomUsers.pomUsers("lst_country"), listby, "selected is " + listby);
			break;
		case "Partner":
			webListSelectSingleItemByText(pomUsers.pomUsers("lst_partner"), listby, "selected is " + listby);
			break;
		case "Farmer Group":
			webListSelectSingleItemByText(pomUsers.pomUsers("lst_partner"), listby, "selected is " + listby);
			break;
		}
	}

	public synchronized void selectListBy(String classification, String listByName) {
		waitTill(7000);

		switch (classification) {
		case "Country":
			webListSelectSingleItemByText(pomUsers.pomUsers("lst_country"), listByName, "selected is " + listByName);
			break;
		case "Product":
			webListSelectSingleItemByText(pomUsers.pomUsers("lst_product"), listByName, "selected is " + listByName);
			break;
		case "Module":
			webListSelectSingleItemByText(pomUsers.pomUsers("lst_module"), listByName,
					"Selected the required product from the list " + listByName);
			break;
		}
	}

	public synchronized void selectMultipleValues(String productormodules, String value1, String value2) {
		waitTill(5000);
		final String[] textOptions = { value1, value2 };
		final WebElement element = selectByLocatorType(pomUsers.pomUsers(productormodules));
		final Select dropdown = new Select(element);
		final List<WebElement> options = dropdown.getOptions();
		final Actions builder = new Actions(driver);
		final boolean isMultiple = dropdown.isMultiple();
		if (isMultiple) {
			dropdown.deselectAll();
		}
		builder.keyDown(Keys.CONTROL);
		for (String textOption : textOptions) {
			for (WebElement option : options) {
				final String optionText = option.getText().trim();
				if (optionText.equalsIgnoreCase(textOption)) {
					if (isMultiple) {
						if (!option.isSelected()) {
							builder.click(option);
						}
					} else {
						option.click();
					}
					break;
				}
			}
		}
		builder.keyUp(Keys.CONTROL).build().perform();
	}

}
