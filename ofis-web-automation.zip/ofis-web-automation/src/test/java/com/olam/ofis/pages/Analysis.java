package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomAnalysis;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Analysis extends Functions {

	PomMenus pomMenus = new PomMenus();
	PomAnalysis pomAnalysis = new PomAnalysis();

	public Analysis(RemoteWebDriver driver) {
		this.driver = driver;
	}

	private String expectedPageHeaderAnalysis;
	private String expectedBlockOne;
	private String expectedBlockTwo;
	private String expectedBlockThree;
	private String expectedBlockFour;

	public synchronized void analysisLoadExcelData() throws Exception {
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/Analysis.xlsx");
		expectedPageHeaderAnalysis = read.getCellData("AnalysisTC", "pageHeaderAnalysis", 1);
		expectedBlockOne = read.getCellData("AnalysisTC", "blockOne", 1);
		expectedBlockTwo = read.getCellData("AnalysisTC", "blockTwo", 1);
		expectedBlockThree = read.getCellData("AnalysisTC", "blockThree", 1);
		expectedBlockFour = read.getCellData("AnalysisTC", "blockFour", 1);
	}

	public synchronized void analysisClick() throws InterruptedException {
		Thread.sleep(7000);
		webElementClick(pomMenus.pomMenus("Menu_analysis"), "Menu Analysis");
	}

	public synchronized void analysisPageHeaderValidation() throws InterruptedException {
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(pomAnalysis.pomAnalysis("Header_PageHeader"), expectedPageHeaderAnalysis,
				"PageHeader Analysis");
	}

	public synchronized void validateAnalysisValues() throws InterruptedException {
		Thread.sleep(5000);
		webAssertEqualsAlphaNumeric(pomAnalysis.pomAnalysis("blckOne"), expectedBlockOne, "Analysis block one");
		webAssertEqualsAlphaNumeric(pomAnalysis.pomAnalysis("blckTwo"), expectedBlockTwo,
				"Analysis block Second");
		webAssertEqualsAlphaNumeric(pomAnalysis.pomAnalysis("blckThree"), expectedBlockThree,
				"Analysis block Third");
		webAssertEqualsAlphaNumeric(pomAnalysis.pomAnalysis("blckFour"), expectedBlockFour,
				"Analysis block fourth");
	}
}
