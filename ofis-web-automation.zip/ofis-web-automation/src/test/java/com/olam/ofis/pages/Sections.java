package com.olam.ofis.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.olam.ofis.pom.PomSections;
import com.olam.ofis.pom.PomMenus;
import com.olam.ofis.utils.ReadExcel;
import com.olam.ofis.wrappers.Functions;

public class Sections extends Functions{
	
	PomMenus pomMenus = new PomMenus();
	PomSections pomSections = new PomSections();
		
	public Sections(RemoteWebDriver driver) {
		this.driver=driver;
	}
	private String expectedPageHeaderAllSections;
	private String expectedPageHeaderEditAllSections;
	private int expectedSectionId;
	private String expectedFarmerGroup;
	private String expectedCode;
	private String expectedName;
	
	public synchronized void allSectionsLoadExcelData()throws Exception{
		
		//Expected data is retrieved from Excel sheet and it will be compared with actual web UI data
		ReadExcel read = new ReadExcel("./src/test/resources/testdata/AllSections.xlsx");
				
		expectedPageHeaderAllSections = read.getCellData("AllSectionsTC", "pageHeader_allSections", 1);
		expectedPageHeaderEditAllSections = read.getCellData("AllSectionsTC", "pageHeader_edit_allSections", 1);
		expectedSectionId=read.getNumericCellData("AllSectionsTC", "text_sectionid", 1);
		expectedFarmerGroup=read.getCellData("AllSectionsTC", "drp_farmerGroup", 1);
		expectedCode=read.getCellData("AllSectionsTC", "text_code", 1);
		expectedName = read.getCellData("AllSectionsTC", "text_name", 1);
		
	}
	public synchronized void settingsFarmarGroupsClick()throws InterruptedException{
		Thread.sleep(7000);
		webMainAndSubElementClick(pomMenus.pomMenus("Menu_Settings"),pomMenus.pomMenus("Settings_farmargroups"),"Settings->FarmerGroups");
		}
		
	public synchronized void allSectionsClick() throws InterruptedException{
		Thread.sleep(5000);
		webElementClick(pomSections.pomSections("thumbnailAllSections"), "thumbnail all sections");
		}
	
	public synchronized void allSectionsPageHeaderValidation() throws InterruptedException{
		Thread.sleep(7000);
		webAssertEqualsAlphaNumeric(pomSections.pomSections("Header_PageHeader"),expectedPageHeaderAllSections, "PageHeader all sections");
		}
	
	public synchronized void editAllPlacesButtonClick() throws InterruptedException{
		Thread.sleep(3000);
		webElementMouseHoverAndClick(pomSections.pomSections("btn_edit_allSections"), "Edit all sections button");
		//WebElementClick(POMAllSectionsPage.pomAllSections("btn_edit_allSections"), "Edit all sections button");
		
		}

	public synchronized void editAllPlacesPageHeaderValidation() throws InterruptedException{
		Thread.sleep(12000);
		webAssertEqualsAlphaNumeric(pomSections.pomSections("Header_edit_allSections"),expectedPageHeaderEditAllSections, "Edit all sections Page header");
		}
	public synchronized void editPageCancelClick() throws InterruptedException{
		
		webElementClick(pomSections.pomSections("btn_Cancel"), "cancel");
	}

	public synchronized void validateAllSectionsValues() throws InterruptedException{
		Thread.sleep(12000);
		webGetAttributeValueAndAssertEqualsNumeric(pomSections.pomSections("txt_sectionid"),expectedSectionId, "Section id");
		webGetSelectedValueFromDropdownAndAssertAlphaNumeric(pomSections.pomSections("drp_FarmerGroup"),expectedFarmerGroup, "farmer group");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomSections.pomSections("txt_code"),expectedCode, "code");
		webGetAttributeValueAndAssertEqualsAlphaNumeric(pomSections.pomSections("txt_name"),expectedName, "name");
		verifyWebCheckBoxIsSelected(pomSections.pomSections("chk_active"), "active place - checkbox");
		}	
}
