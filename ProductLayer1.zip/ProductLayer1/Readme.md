# Product Layer #

Serenity - that feeling you get when you know you can trust your tests
======================================================================
Serenity is a library designed to make writing automated acceptance tests easier, and more fun.

What does it do?
	This module lets you write your BDD acceptance tests using JBehave, and generate fabulous living documentation reports based on the outcomes of these tests.
Serenity helps structure your automated acceptance tests in order to make them easier to understand and maintain, 
and provides great reporting capabilities on top of tools like JBehave, Cucumber or JUnit. 
It also provides tight integration with WebDriver, to make automated web testing easier and more efficient.

# Serenity works in two ways: #
* It instruments your test code and reports on the steps that your tests execute to achieve their goals, 
and stores the test results in a standardized format;

* It aggregates these test results into clear and meaningful reports, that reflect not only the outcomes of your tests, 
but also the status of your project. For example, you can get Serenity to report on what requirements, 
features or stories you have implemented, and how well (or not) they were tested.

# Prerequisites #

1. JDK 6+
2. Maven 2+
3. Firefox 10+

# Windows configuration #

Once all the required tools are installed:

create two new system variables:

JAVA_HOME e.g.: JAVA_HOME=C:\Program Files\Java\jdk1.7.0_10

M2_HOME e.g.: M2_HOME=C:\Program Files\apache-maven-3.0.5

Add paths to the firefox, java and maven folders containing corresponding binaries to the Path variable,

e.g.:
Path=WHATEVER_WAS_THERE_BEFORE;C:\Program Files\Java\jdk1.7.0_10\bin\;C:\Program Files\apache-maven-3.0.5\bin\;C:\Program Files (x86)\Mozilla Firefox\

NOTES:

More information on FirefoxDriver
Handy tutorial on setting $PATH and environmental variables in Windows.
FF binary (firefox.exe) can usually be found in %PROGRAMFILES%\Mozilla Firefox

# Project Structure #
	
	src/test/java
		com.dnb.automation.project
			SuiteFileName.java
		com.dnb.automation.project.steps
			Steps.java
		com.dnb.automation.project.tests
			Tests.java
			
	src/main/java
		com.dnb.automation.project.pages
			Pages.java
		com.dnb.automation.util
			Common methods classes
			
	src/test/resources
		stories
			ProjectName
				suite_file_name.story
				
* Create the suite file using story file (make sure to both the file name should be same).
	Ex: Story File Name is "verify_application_flow.story" the Suite File Name would be "VerifyApplicationFlow.java"
* Write the Functional tests (Narrative & Scenarios) in story files
* Implement the Page classes using story files
* Properly integrate the story file with pages classes by steps & tests package classes

Story Files==>steps==>tests==>pages==>tests

1. In Steps, will implement story file's steps by calling test package classes methods
2. In tests, will call the page package classes methods and do the assertions
3. In pages, will implements the methods for functional tests by using real browser actions

# Add a new user story #
Create a new story files (make sure to SuiteFileName.java and story file names should be same) under src/test/resources/stories directory

Story Files For Billing Test Flow:
==================================
1. verify_application_decisioning_for_na3.story
2. verify_application_decisioning.story
3. verify_application_redecisioning_for_na3.story
4. verify_application_redecisioning.story
5. verify_company_docs_from_live_report.story
6. verify_company_docs_from_search_results.story
7. verify_gft_from_live_report.story
8. verify_gft_from_search_results.story
9. verify_order_invest_from_live_report_for_na3.story
10. verify_order_invest_from_live_report.story
11. verify_order_invest_from_search_results_for_na3.story
12. verify_order_invest_from_search_results.story
13. verify_pull_live_report_for_na3.story
14. verify_pull_live_report.story

Story Files For DNBi Account Flow:
==================================
1. verify_account_configurations_flow.story
2. verify_account_creation_flow.story

Story Files For DNBi Application Flow:
======================================
1. To be updated

Story Files For DNBi Common Flow:
=================================
1. verify_dnbi_common_flow.story

Dependencies Install command:
=============================
mvn clean package

Automation Script execution command:
====================================
mvn clean verify -Dwebdriver.driver=chrome -Dsuite.file=project/SuitFileName -DappURL="Application URL" 
-DappUserName="Application Login UserName" -DappPassword="Application Login Password"