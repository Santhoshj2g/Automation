package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;
/**********************************************************************************************
 * PortfolioSortCompanylist - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/
public class PortfolioSortCompanylist extends SerenityStory{

}
