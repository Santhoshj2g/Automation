/**
 * 
 */
package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

/**
 * Cirrus Portfolio - This program calls serenity
 * @author SaitS
 *
 */
public class PortfolioOverviewPage extends SerenityStory {

}
