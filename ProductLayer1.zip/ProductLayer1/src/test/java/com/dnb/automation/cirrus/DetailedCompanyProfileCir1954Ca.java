package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedCompanyProfileCir1954Ca - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/
public class DetailedCompanyProfileCir1954Ca extends SerenityStory{

}
