package com.dnb.automation.bd;
import net.serenitybdd.jbehave.SerenityStory;
/**********************************************************************************************
 * Function : Invokes serenity story file profile_claim_reject_approve.story
 * 
 *
 ***********************************************************************************************/
public class ProfileClaimRejectApprove extends SerenityStory {
	
	
	
}
