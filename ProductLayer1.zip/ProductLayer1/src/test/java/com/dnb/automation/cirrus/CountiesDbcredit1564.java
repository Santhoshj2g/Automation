package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class CountiesDbcredit1564 extends SerenityStory {

}
