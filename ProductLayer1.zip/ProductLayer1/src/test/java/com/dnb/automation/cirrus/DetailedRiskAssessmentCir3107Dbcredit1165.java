package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedRiskAssessmentCir3107Dbcredit1165 - This program calls serenity
 * story file
 *
 * @author Rajesh G
 ***********************************************************************************************/

public class DetailedRiskAssessmentCir3107Dbcredit1165 extends SerenityStory{

}
