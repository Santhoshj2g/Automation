package com.dnb.automation.bd;

import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * Function : Invokes serenity story file super_admin_my_account.story
 * 
 *
 ***********************************************************************************************/

public class SuperAdminResetPassword extends SerenityStory {

}
