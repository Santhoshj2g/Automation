package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedLegalTabFilterCir2300CA - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class DetailedLegalTabFilterCir2300CA extends SerenityStory{

}
