package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;
/**********************************************************************************************
 * DetailedTradePaymentsCA - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class DetailedTradePaymentsCA  extends SerenityStory {

}
