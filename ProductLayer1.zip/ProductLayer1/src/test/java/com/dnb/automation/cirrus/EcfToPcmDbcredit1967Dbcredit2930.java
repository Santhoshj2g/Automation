package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * AllPanelsDbcredit1967 - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class EcfToPcmDbcredit1967Dbcredit2930 extends SerenityStory{

}
