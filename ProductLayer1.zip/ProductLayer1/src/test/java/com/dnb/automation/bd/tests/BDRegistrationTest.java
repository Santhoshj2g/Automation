package com.dnb.automation.bd.tests;

//import junit.framework.Assert;
import org.jbehave.core.annotations.Named;
import org.junit.Assert;

import net.thucydides.core.steps.ScenarioSteps;

import com.dnb.automation.bd.pages.RegistrationPage;

public class BDRegistrationTest extends ScenarioSteps {
	
	RegistrationPage objRegistrationPage;
	
	public void ClickRegisterLink()
	{
		objRegistrationPage.clickRegister();
	}	
	public void verifyRegistrationScreen()
	{
		Assert.assertEquals(true,objRegistrationPage.getRegisterVisibility());		
	}	
	public void FillRegistrationForm(String email,String prefix,String firstname,String lastName,String counryCode,String aredCode,String phoneNum,String extnum,String country,String compWebsite)
	{
		objRegistrationPage.fillRegistrationForm(email,prefix, firstname, lastName, counryCode, aredCode, phoneNum,extnum, country,compWebsite);	
	}	
	public void ClickTermsAndConditon()
	{
		objRegistrationPage.clickTermsAndCondition();
	}	
	public void verifyTermsAndConditonPopupAppeared()
	{
		Assert.assertEquals(objRegistrationPage.getTermsAndConditionPopUpDisplayed(),true);
	}	
	public void ClickAgree()
	{
		objRegistrationPage.acceptTermsAndCondtion();
	}	
	public void verifyTermsAndConditonPopupDissAppeared()
	{
		Assert.assertEquals(false,objRegistrationPage.getTermsAndConditionPopUpDisplayed());
	}
	public void ClickRegister()
	{
		objRegistrationPage.submitRegister();
	}	
	public void verifyRegSucessMsgAppeared()
	{
		Assert.assertEquals(true,objRegistrationPage.getRegSucessMsgDisplayed());
	}
}
