package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;
/**********************************************************************************************
 * PortfolioHomepg - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class PortfolioHomepg extends SerenityStory{

}
