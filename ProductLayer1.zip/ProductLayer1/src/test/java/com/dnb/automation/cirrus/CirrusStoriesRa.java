package com.dnb.automation.cirrus;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ CirrusHomeCir2356.class,CirrusSearch.class,CirrusSearchCir223.class,
	CirrusSearchCir3357.class,	CirrusSearchCir8089Ca.class,CirrusSearchCir8089Us.class,CirrusSearchCir8221.class,
	CirrusSearchCir8378.class,DetailedNavigationCir4450.class,DetailedNavigationCir8084Ca.class,DetailedNavigationCir8084UsPrivate.class,
	})
public class CirrusStoriesRa {
	

}
