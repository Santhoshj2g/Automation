package com.dnb.automation.bd.tests;

import java.sql.SQLException;

import org.junit.Assert;

import net.thucydides.core.steps.ScenarioSteps;

import com.dnb.automation.bd.pages.AdminDashboardPage;
import com.dnb.automation.bd.pages.BDTabsPage;
import com.dnb.automation.bd.pages.DBConnectionPage;

public class AdminDashboardTest extends ScenarioSteps {
	
	AdminDashboardPage objAdminDashboardPage;
	BDTabsPage objBDTabsPage;
	DBConnectionPage objDBConnectionPage;
	
	public void inDashboard() throws Exception
	{
		Assert.assertEquals(true,objBDTabsPage.getMYDASHBOARDTabSelection());
	}
	
	public void userRegistrationTab()
	{
		objAdminDashboardPage.selectUserRegistrationTab();
	}

	public void ProfileClaimTab()
	{
		Assert.assertEquals(true,objAdminDashboardPage.selectProfileClaimTab());
	}
	
	public void searchClaimByCompany(String dunsNo) throws InterruptedException, SQLException
	{
		String dbProfileName = objDBConnectionPage.getProfileName(dunsNo);		
		Assert.assertEquals(true,objAdminDashboardPage.searchClaimByCompany(dbProfileName));
	}

	public void searchUserRegistrationByEmailId(String emaiId)
	{		
		objAdminDashboardPage.searchRegUserByEmail(emaiId);
	}
	
	public void verifyClaimedProfileStatusPending()
	{
		Assert.assertEquals(true,objAdminDashboardPage.getClaimedProfileStatus().equalsIgnoreCase("Pending"));
	}

	public void verifyRegUserStatusPending()
	{
		Assert.assertEquals(true,objAdminDashboardPage.getRegUserStatus().equalsIgnoreCase("Pending"));
	}
	
	public void rejectTheClaimRequest()
	{
		objAdminDashboardPage.clickClaimRejectButton();
	}

	public void approveTheClaimRequest()
	{
		objAdminDashboardPage.clickClaimApproveButton();
	}
	
	public void VerifyApproveConfirmation()
	{
		Assert.assertEquals(true,objAdminDashboardPage.getApproveConfirmation());
	}

	public void VerifyRejectConfirmation()
	{
		Assert.assertEquals(true,objAdminDashboardPage.getRejectConfirmation());
	}
	
	public void acceptApproveConfirmation()
	{
		objAdminDashboardPage.acceptApproveConfirmation();
	}

	public void acceptRejectConfirmation()
	{
		objAdminDashboardPage.acceptRejectConfirmation();
	}
	
	public void VerifyApproveSuccessMessage()
	{
		Assert.assertEquals(true,objAdminDashboardPage.getApproveSuccessMessage());
		objAdminDashboardPage.acceptApproveSuccessMessage();
	}

	public void VerifyRejectSuccessMessage()
	{
		Assert.assertEquals(true,objAdminDashboardPage.getRejectSuccessMessage());
		objAdminDashboardPage.acceptRejectSuccessMessage();
	}

//Test to select the Profile Edits tab	
	public void SelectProfileEditsTab() {
		Assert.assertEquals(true,objAdminDashboardPage.SelectProfileEditsTab());		
	}

//Test to verify that the profile edit list is displayed	
	public void isProfileEditListDisplayed() {
		Assert.assertEquals(true,objAdminDashboardPage.isProfileEditListDisplayed());		
	}


//Test to search the profile edit request
	public void SearchProfileEditReq(String dunsNo) throws SQLException {
		String dbProfileName = objDBConnectionPage.getProfileName(dunsNo);
		objAdminDashboardPage.SearchProfileEditReq(dbProfileName);
		
	}

//Test to verify the edited profile status is pending	
	public void verifyEditedProfileStatusPending() {
		Assert.assertEquals(true,objAdminDashboardPage.getEditedProfileStatus().equalsIgnoreCase("Pending"));
	}

//Test to select the profile from the editlist	
	public void selectTheProfileFromEditList() {
		Assert.assertEquals(true,objAdminDashboardPage.selectTheProfileFromEditList());		
	}

//Test to verify that the profile is opened in edit for approve or reject 	
	public void isProfileEditModeForApproveReject(String dunsNo) throws SQLException {
		String dbProfileName = objDBConnectionPage.getProfileName(dunsNo);		
		String uiProfileName = objAdminDashboardPage.isProfileEditModeForApproveReject();
		String editProfileName = dunsNo+" - "+dbProfileName;
//		Assert.assertEquals(editProfileName,uiProfileName);	
		Assert.assertTrue(editProfileName.equalsIgnoreCase(uiProfileName));
	}

//Test to reject all the changes in CompanyInfoTab	
	public void rejectCompanyInfoChages() {
		 objAdminDashboardPage.rejectCompanyInfoChages();
	}

//Test to approve all the changes in CompanyInfoTab	
	public void approveCompanyInfoChages() {
		 objAdminDashboardPage.approveCompanyInfoChages();
	}
	
//Test to reject the phone number changes in Corporate info tab	
	public void rejectCorporateInfoChanges() {
		 objAdminDashboardPage.rejectCorporateInfoChanges();	
	}

//Test to approve the phone number changes in Corporate info tab	
	public void approveCorporateInfoChanges() {
		 objAdminDashboardPage.approveCorporateInfoChanges();	
	}
	
//Test to reject the Key employee changes	
	public void rejectKeyEmployeeChanges() {
		 objAdminDashboardPage.rejectKeyEmployeeChanges();		
	}

//Test to approve the Key employee changes	
	public void approveKeyEmployeeChanges() {
		 objAdminDashboardPage.approveKeyEmployeeChanges();		
	}
	
//Test to reject the Linkage info changes in Business info tab	
	public void rejectBusinessInfoChanges() {
		 objAdminDashboardPage.rejectBusinessInfoChanges();
		
	}

//Test to Approve the Linkage info changes in Business info tab	
	public void approveBusinessInfoChanges() {
		 objAdminDashboardPage.approveBusinessInfoChanges();			
	}
	
//Test to sumbit the edit apporve or rejections	
	public void clickSubmit() {
		objAdminDashboardPage.clickSubmit();		
	}

//Test to verify the user registration tab is selected
	public void isUserRegistrationTabSelected() {
		Assert.assertEquals(true,objAdminDashboardPage.isUserRegistrationTabSelected());		
	}
}
