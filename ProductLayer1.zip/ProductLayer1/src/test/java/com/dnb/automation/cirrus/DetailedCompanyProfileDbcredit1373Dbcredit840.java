package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedCompanyProfileDbcredit1373UkIre - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/
public class DetailedCompanyProfileDbcredit1373Dbcredit840 extends SerenityStory{

}
