package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * CustomizeKeydataDataValDbcredit495CA - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class CustomizeKeydataDataValDbcredit495CA  extends SerenityStory{

}
