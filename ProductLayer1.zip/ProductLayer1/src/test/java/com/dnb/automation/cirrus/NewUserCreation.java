package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * NewUserCreation - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class NewUserCreation extends SerenityStory{

}
