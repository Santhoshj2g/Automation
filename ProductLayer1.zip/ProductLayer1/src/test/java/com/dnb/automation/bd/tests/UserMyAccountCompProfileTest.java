package com.dnb.automation.bd.tests;

import java.sql.SQLException;

import org.junit.Assert;

import net.thucydides.core.steps.ScenarioSteps;

import com.dnb.automation.bd.pages.DBConnectionPage;
import com.dnb.automation.bd.pages.UserMyAccountCompProfilePage;

public class UserMyAccountCompProfileTest extends ScenarioSteps
{	
	UserMyAccountCompProfilePage objUserMyAccountCompProfilePage;
	DBConnectionPage objDBConnectionPage;

//Test to verify , is profile edit button is enabled in company profile tab.	
	public void isProfileEditButtonEnabled(String dunsNo) throws SQLException
	{		
		String dbProfileName = objDBConnectionPage.getProfileName(dunsNo);		
		Assert.assertEquals(true,objUserMyAccountCompProfilePage.isProfileEditButtonEnabled(dbProfileName));
		
	}

//Test to select the profile and click on edit button.	
	public void selectProfileAndEdit(String dunsNo) throws SQLException {
		String dbProfileName = objDBConnectionPage.getProfileName(dunsNo);		
		Assert.assertEquals(true,objUserMyAccountCompProfilePage.selectProfileAndEdit(dbProfileName));		
	}


}
