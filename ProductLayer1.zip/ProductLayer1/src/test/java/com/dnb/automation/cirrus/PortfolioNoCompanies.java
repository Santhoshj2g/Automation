package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * ReportLegalEvents - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class PortfolioNoCompanies extends SerenityStory{

}
