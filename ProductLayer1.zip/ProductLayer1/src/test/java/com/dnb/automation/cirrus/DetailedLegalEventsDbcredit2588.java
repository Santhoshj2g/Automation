package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class DetailedLegalEventsDbcredit2588 extends SerenityStory{

}
