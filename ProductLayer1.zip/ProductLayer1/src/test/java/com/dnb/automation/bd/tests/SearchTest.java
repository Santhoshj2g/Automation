package com.dnb.automation.bd.tests;

import java.sql.SQLException;

import org.hamcrest.Matchers;

//import junit.framework.Assert;




import com.dnb.automation.bd.pages.DBConnectionPage;
import com.dnb.automation.bd.pages.LoginPage;
import com.dnb.automation.bd.pages.SearchPage;

import net.thucydides.core.steps.ScenarioSteps;

import org.junit.Assert;

public class SearchTest extends ScenarioSteps {

	LoginPage objLoginPage;
	SearchPage objSearchPage;
	DBConnectionPage objDBConnectionPage;

//Test to verify the user in Home page
	public void inHomePage() throws Exception
	{
		Assert.assertEquals(true,objLoginPage.userInHomePage());
	}
//Test to select the search option and do the search
	public void searchDuns(String option,String dunNo) throws Exception{
		objSearchPage.search(option,dunNo);
	}
//Test to select the profile to view from the search result
	public void selectProfileToView()
	{
		objSearchPage.selectProfileToView();
	}
//Test to verify the displayed profile name is matched with data base profile name
	public void verifyProfile_Duns(String dunNo) throws SQLException{
		String uiProfileName = objSearchPage.getDispProfileName();
//		String dbProfileName = objDBConnectionPage.getProfileName(dunNo);
//		Assert.assertEquals(uiProfileName,dbProfileName);
	}
//Test to verify the result table is displayed
	public void VerifyResultTable(){
		Assert.assertEquals(true,objSearchPage.getResultBodyVisibility());
	}
//Test to verify the total number of records displayed in search result
	public void verifyNoOfRowsInSearchResult()
	{
		boolean rowIsLessThanOrEqualTo30=false;
		int noOfRows=objSearchPage.getNoOfRowsInSearchResultForGuest();
		if(noOfRows<=30)
		{
			rowIsLessThanOrEqualTo30=true;
		}
		Assert.assertEquals(true,rowIsLessThanOrEqualTo30);
	}
	public void clickHome() throws Exception
	{
		objSearchPage.clickHome();
	}
	//Clicking the Manage Account Link in Home Page
	public void mngAccLnk() throws Exception
	{
		Assert.assertEquals(objSearchPage.clickOnManageaccLnk(),true);
	}
	//Clicking the ResetPassword Link in Under Manage Accounts
	public void resetPswdLnk() throws Exception
	{
		objSearchPage.resetPswdLnk();
	}
	//Verifying the ResetPassword section
	public void verifyResetPswdPageadmin() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyResetPswdPageadmin(),true);
	}
	//Clicking the Edit Profile Online Link
	public void editprofile() throws Exception
	{
		objSearchPage.editprofile();
	}
	//Verifying the ResetPassword Page
	public void verifyResetPswdPage() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyResetPswdPage(),true);
	}
	//Verifying the Email id field in Reset Password Page
	public void verifyEmailId() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyEmailId(),true);
	}
	//Verifying the First Name field in Reset Password Page
	public void verifyFirstName() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyFirstName(),true);
	}
	//Verifying the Last Name field in Reset Password Page
	public void verifyLastName() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyLastName(),true);
	}
	//Verifying the Edit Profile Online Page
	public void verifyEditprofilePage() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyEditprofilePage(),true);
		//objSearchPage.verifyEditprofilePage();
	}
	//Verifying the editProfile online section
	public void verifyMyAcc() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyMyAcc(),true);
	}
	//Verifying the Email id field in Edit Profile Online Page
	public void verifyEmailid() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyEmailid(),true);
	}
	//Verifying the prefix field in Edit Profile Online Page
	public void verifyPrefix() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyPrefix(),true);
	}
	//Verifying the LastName field in Edit Profile Online Page
	public void verifyLastNameonEditProf() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyLastName(),true);
	}
	//Verifying the Country Code field in Edit Profile Online Page
	public void verifyCountrycode() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyCountrycode(),true);
	}
	//Verifying the AreaCode field in Edit Profile Online Page
	public void verifyAreacode() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyAreacode(),true);
	}
	//Verifying the Phone Number field in Edit Profile Online Page
	public void verifyPhoneNo() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyPhoneNo(),true);
	}
	//Verifying the Extension field in Edit Profile Online Page
	public void verifyPhoneExtn() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyPhoneExtn(),true);
	}
	//Verifying the Country field in Edit Profile Online Page
	public void verifyCountry() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyCountry(),true);
	}
	//Verifying the Company Url field in Edit Profile Online Page
	public void verifyCompanyUrl() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyCompanyUrl(),true);
	}
	//Verifying the Role field in Edit Profile Online Page
	public void verifyRole() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyRole(),true);
	}
	//Clicking the Create New User Link in Home page
	public void createNewUser() throws Exception
	{
		Assert.assertEquals(objSearchPage.createNewUser(),true);
	}
	//Verifying the User Registration Management details
	public void verifyUserRegMgmnt()
	{
		Assert.assertEquals(objSearchPage.verifyUserRegMgmnt(),true);
	}
	//Verifying the Downloads and offers section
	public void downloadsandoffersLnk() throws Exception
	{
		Assert.assertEquals(objSearchPage.downloadsandoffersLnk(),true);
	}
	//Clicking the Manage Downloads link in Home Page
	public void manageDownloads() throws Exception
	{
		Assert.assertEquals(objSearchPage.manageDownloads(),true);
		objSearchPage.mngDownloadsLnk();
	}
	//Verifying the product Description in Manage Downloads page
	public void verifyProductDesc() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyProductDesc(),true);
	}
	//Verifying the product Offer Code in Manage Downloads page
	public void verifyProductOfferCode() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyProductOfferCode(),true);
	}
	//Verifying the Download Count field in Manage Downloads page
	public void verifyDownloadCount() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyDownloadCount(),true);
	}
	//Verifying the Expiry date field in Manage Downloads page
	public void verifyExpiryDate() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyExpiryDate(),true);
	}
	//Verifying the Document File field in Manage Downloads page
	public void verifyDocFile() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyDocFile(),true);
	}
	public void verifyBrowseBtn() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyBrowseBtn(),true);
	}
	//Verifying the Upload Button in Manage Downloads page
	public void verifyUploadbtn() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyUploadbtn(),true);
	}
	//Verifying the Cancel Button in Manage Downloads page
	public void verifyCancelbtn() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyCancelbtn(),true);
	}
	//Clicking the Requested Connections Link
	public void requestedConnectionsLnk() throws Exception
	{
		Assert.assertEquals(objSearchPage.requestedConnectionsLnk(),true);
	}
	public void ConnectionsPage() throws Exception
	{
		Assert.assertEquals(objSearchPage.ConnectionsPage(),true);
	}
	//Verifying the Requested Connections Page
	public void requestedConnectionsPage() throws Exception
	{
		objSearchPage.requestedConnectionsPage();
	}
	//Verifying the Requested Connections page contents
	public void verifyInvitesReceived() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyInvitesReceived(),true);
	}
	//Verifying the Received field in Requested Connections Page
	public void verifyReceived() throws Exception
	{
		objSearchPage.verifyReceived();
	}
	//Verifying the RequestFor field in Requested Connections Page
	public void verifyRequestFor() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyRequestFor(),true);
	}
	//Verifying the Received From field in Requested Connections Page
	public void verifyReceivedFrom() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyReceivedFrom(),true);
	}
	//Verifying the Status field in Requested Connections Page
	public void verifyStatus() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyStatus(),true);
	}
	public void verifyInvitesSent() throws Exception
	{
		Assert.assertEquals(objSearchPage.verifyInvitesSent(),true);
	}

	//Verifying the Request For field in Requested Connections Page
	public void verifyTermsandConditions() throws Exception
	{
		objSearchPage.verifyTermsandConditions();
	}
	//Verifying the Register button
	public void verifyRegisterButton() throws Exception
	{
		objSearchPage.verifyRegisterButton();
	}
	//Verifying the Search button
	public void verifySearchButton() throws Exception
	{
		objSearchPage.verifySearchButton();
	}
	//Clicking the Edit My Profile Online Link
	public void clickEditmyProfile()
	{
		Assert.assertEquals(objSearchPage.clickEditmyProfile(),true);
	}
	//verifying the terms and Conditions Checkbox
	public void verifyTermsandCondtns()
	{
		Assert.assertEquals(objSearchPage.verifyTermsandCondtns(),true);
	}
	//verifying the Save Button
	public void verifySaveBtn()
	{
		Assert.assertEquals(objSearchPage.verifySaveBtn(),true);
	}
	//Clicking the New user Link
	public void clickNewUser()
	{
		Assert.assertEquals(objSearchPage.clickNewUser(),true);
	}
	//Verifying the My details tab
	public void verifyMydetails()
	{
		Assert.assertEquals(objSearchPage.verifyMydetails(),true);
	}
	//Clicking the Add Photos Link
	public void clickAddPhotos()
	{
		Assert.assertEquals(objSearchPage.clickAddPhotos(),true);
	}
	//Verifying the Company Profile tab
	public void verifyCompanyProfile()
	{
		Assert.assertEquals(objSearchPage.verifyCompanyProfile(),true);
	}
	//Verifying the My Account section
	public void verifyMyAccount()
	{
		Assert.assertEquals(objSearchPage.verifyMyAccount(),true);
	}
	//Verifying the Company Name field
	public void verifycompanyName()
	{
		Assert.assertEquals(objSearchPage.verifycompanyName(),true);
	}
	//Verifying the Location field
	public void verifyLocation()
	{
		Assert.assertEquals(objSearchPage.verifyLocation(),true);
	}
	//Verifying the Line Of Business field
	public void verifyLineofBusiness()
	{
		Assert.assertEquals(objSearchPage.verifyLineofBusiness(),true);
	}
	//Verifying the Claimed On field
	public void verifyClaimedOn()
	{
		Assert.assertEquals(objSearchPage.verifyClaimedOn(),true);
	}
	//Verifying the QR Code field
	public void verifyQRCode()
	{
		Assert.assertEquals(objSearchPage.verifyQRCode(),true);
	}
	//Clicking the Offers Code link
	public void clickOfferCodes()
	{
		Assert.assertEquals(objSearchPage.clickOfferCodes(),true);
	}
	//Verifying the Submit Button
	public void verifySubmitBtn()
	{
		Assert.assertEquals(objSearchPage.verifySubmitBtn(),true);
	}
	//Verifying the Profile Users tab
	public void verifyProfileUsers()
	{
		Assert.assertEquals(objSearchPage.verifyProfileUsers(),true);
	}
	//Verifying the User Type field
	public void verifyUserType()
	{
		Assert.assertEquals(objSearchPage.verifyUserType(),true);
	}
	//Verifying the User Count field
	public void verifyUserCount()
	{
		Assert.assertEquals(objSearchPage.verifyUserCount(),true);
	}
	//Selecting  Search criteria from User Options dropdown
	public void selectsearchdropdown()
	{
		Assert.assertEquals(objSearchPage.selectsearchdropdown(),true);
	}
	//Entering value in Search Term field
	public void enterCountry(String country)
	{
		objSearchPage.enterCountry(country);
	}
	//Clicking the Search button
	public void clickSearch()
	{
		objSearchPage.clickSearch();
	}
	//Clicking the Narrow Search section
	public void clickNarrowresults()
	{
		objSearchPage.clickNarrowresults();
	}
	//Selecting a value from Country dropdown
	public void selectCountry(String location)
	{
		objSearchPage.selectCountry(location);
	}
	//Selecting a value from State dropdown
	public void selectState(String state)
	{
		objSearchPage.selectState(state);
	}
	//Clicking the Apply Filters button
	public void clickApplyFilters()
	{
		objSearchPage.clickApplyFilters();
	}
	//To capture the total no of records displayed after the search function
	public void getTotalRecords()
	{
		objSearchPage.getTotalRecords();
	}
	//Clicking the Remove Filters option
	public void clickRemoveFilters()
	{
		objSearchPage.clickRemoveFilters();
	}
	//To display the overall search results
	public void getOverallResults()
	{
		objSearchPage.getOverallResults();
	}
	//To select a value from Currency dropdown
	public void selectCurrency(String currency)
	{
		objSearchPage.selectCurrency(currency);
	}
	//To select a value from Employee Range dropdown
	public void selectEmployeeRange(String employee)
	{
		objSearchPage.selectEmployeeRange(employee);
	}
	//To select a value from Revenue dropdown
	public void selectRevenue(String revenue)
	{
		objSearchPage.selectRevenue(revenue);
	}
	//To Compare the search result with the records displayed along with the country search value
	public void verifyCountryResults()
	{
		Assert.assertEquals(objSearchPage.verifyCountryResults(),true);
	}
	//To Compare the search result with the records displayed along with the currency search value
	public void verifyCurrencyResults()
	{
		Assert.assertEquals(objSearchPage.verifyCurrencyResults(),true);
	}
	//To Compare the search result with the records displayed along with the Employee search value
	public void verifyEmployeeResults()
	{
		Assert.assertEquals(objSearchPage.verifyEmployeeResults(),true);
	}
	//To Compare the search result with the records displayed along with the State search value
	public void verifyStateResults()
	{
		Assert.assertEquals(objSearchPage.verifyStateResults(),true);
	}
	//To Compare the search result with the records displayed along with the Revenue search value
	public void verifyRevenueResults()
	{
		Assert.assertEquals(objSearchPage.verifyRevenueResults(),true);
	}
	//To click the company link in result page
	public void clickCmpnyName()
	{
		Assert.assertEquals(objSearchPage.clickCmpnyName(),true);
	}	
	//Verifying the DNBVerifiedInformation tab
	public void clickDnbVerifiedInfoTab()
	{
		Assert.assertEquals(objSearchPage.clickDnbVerifiedInfoTab(),true);
	}
	//Verifying the Company Provided Information tab
	public void clickCompanyProvidedinfoTab()
	{
		Assert.assertEquals(objSearchPage.clickCompanyProvidedinfoTab(),true);
	}
	//Verifying the Overview section in Company Profile page
	public void verifyOverviewSection()
	{
		Assert.assertEquals(objSearchPage.verifyOverviewSection(),true);
	}
	//Verifying the Related Tags in Company Profile page
	public void verifyRelatedTags()
	{
		Assert.assertEquals(objSearchPage.verifyRelatedTags(),true);
	}
	//Verifying the Corporate Information Section in Company Profile page
	public void verifyCorporateInfosection()
	{
		Assert.assertEquals(objSearchPage.verifyCorporateInfosection(),true);
	}
	//Verifying the Registration Information section in Company Profile page
	public void verifyRegistrationInfo()
	{
		Assert.assertEquals(objSearchPage.verifyRegistrationInfo(),true);
	}
	//Verifying the Duns Number section in Company Profile page
	public void verifyDUNSNumberSection()
	{
		Assert.assertEquals(objSearchPage.verifyDUNSNumberSection(),true);
	}
	//Verifying the Key Employees Section in Company Profile page
	public void verifyKeyEmployeeSection()
	{
		Assert.assertEquals(objSearchPage.verifyKeyEmployeeSection(),true);
	}
	//Verifying the Financial information section in Company Profile page
	public void verifyFinancialInformationsection()
	{
		Assert.assertEquals(objSearchPage.verifyFinancialInformationsection(),true);
	}
	//Verifying the Products and Brands section in Company Profile page
	public void verifyProductsandBrandsSection()
	{
		Assert.assertEquals(objSearchPage.verifyProductsandBrandsSection(),true);
	}
	//Selecting the Company provided information tab in Company Profile page
	public void clickCompanyProvidedInfoTab()
	{
		Assert.assertEquals(objSearchPage.clickCompanyProvidedInfoTab(),true);
	}
	//Verifying the executives section in Company Profile page
	public void VerifyExecutives()
	{
		Assert.assertEquals(objSearchPage.VerifyExecutives(),true);
	}
	//Verifying the Name field in Company Profile page
	public void verifyName()
	{
		Assert.assertEquals(objSearchPage.verifyName(),true);
	}
	//Verifying the title field in Company Profile page
	public void verifyTitle()
	{
		Assert.assertEquals(objSearchPage.verifyTitle(),true);
	}
	//Verifying the Connect button in Company Profile page
	public void verifyConnectBtn()
	{
		Assert.assertEquals(objSearchPage.verifyConnectBtn(),true);
	}
	//Verifying the DUNS registered Seal in Company Profile page
	public void verifyDUNSRegSeal()
	{
		Assert.assertEquals(objSearchPage.verifyDUNSRegSeal(),true);
	}
	//Verifying the D&B verified Text displayed in Company Profile page
	public void DBVerifiedText()
	{
		Assert.assertEquals(objSearchPage.DBVerifiedText(),true);
	}
	//Verifying the About the company section in Company Profile page
	public void verifyAboutTheCpmny()
	{
		Assert.assertEquals(objSearchPage.verifyAboutTheCpmny(),true);
	}
	//Verifying the Line of Business in Company Profile page
	public void verifyLineofBusDesc()
	{
		Assert.assertEquals(objSearchPage.verifyLineofBusDesc(),true);
	}
	//Verifying the Search option in Company Profile page
	public void verifySearchOption()
	{
		Assert.assertEquals(objSearchPage.verifySearchOption(),true);
	}
	//Verifying the Disclaimer displayed in Company Profile page
	public void verifyDisclaimer()
	{
		Assert.assertEquals(objSearchPage.verifyDisclaimer(),true);
	}
	//Verifying the Signed in Link in Company Profile page
	public void verifySignedinLink(String username)
	{
		Assert.assertEquals(objSearchPage.verifySignedinasLink(username),true);
	}
	//Verifying the Sign Out link in Company Profile page
	public void verifySignOutLink()
	{
		Assert.assertEquals(objSearchPage.verifySignOutLink(),true);
	}
	//Verifying the Profile Claimed Button in Company Profile page
	public void VerifyProfileClaimedBtn()
	{
		Assert.assertEquals(objSearchPage.VerifyProfileClaimedBtn(),true);
	}
	public void clickMyDashboard()
	{
		Assert.assertEquals(objSearchPage.clickMyDashboard(),true);
	}
}
