package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * CirrusSearchCir8221 - This program calls serenity
 * story file
 *
 * @author Rajesh G
 ***********************************************************************************************/

public class CirrusSearchCir8221 extends SerenityStory{

}
