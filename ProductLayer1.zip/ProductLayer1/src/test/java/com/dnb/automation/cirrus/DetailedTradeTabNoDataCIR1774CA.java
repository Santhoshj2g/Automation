package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedTradeTabNoDataCIR1774CA - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/
public class DetailedTradeTabNoDataCIR1774CA extends SerenityStory{

}
