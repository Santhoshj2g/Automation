package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * SummaryCompanyProfileDbcredit841UkIe - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class DetailedCompanyProfileDbcredit841UkIe extends SerenityStory{

}
