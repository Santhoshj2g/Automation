package com.dnb.automation.bd.steps;

import net.thucydides.core.annotations.Steps;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import com.dnb.automation.bd.tests.AdminMyAccountMyDetailsTest;

public class AdminMyAccountMyDetailsSteps {
	@Steps
	AdminMyAccountMyDetailsTest objAdminMyAccountMyDetailsTest;
	
	@When("BD:I Select MyDetails Tab")
	public void selectMyDetailsTab()
	{
		objAdminMyAccountMyDetailsTest.selectMyDetailsTab();
	}

	@Then("BD:Manage Downloads should be visible")
	public void isManageDownloadsLinkVisible()
	{
		objAdminMyAccountMyDetailsTest.isManageDownloadsLinkVisible();
	}
	
	@When ("BD:I click on ManageDownloads link")
	public void clickManageDownloadsLink()
	{
		objAdminMyAccountMyDetailsTest.clickManageDownloadsLink();
	}
	
	@Then ("BD:Mangage Downloads section should be opened")
	public void isManageDownloadsSectionVisible()
	{
		objAdminMyAccountMyDetailsTest.isManageDownloadsSectionVisible();
	}
	
	@When("BD:I give Product Description <ProductDes>")
	public void giveProductDescription(@Named("ProductDes")String ProductDes)
	{
		objAdminMyAccountMyDetailsTest.giveProductDescription(ProductDes);
	}
	@When("BD:I give Product Offer Code <ProductOfferCode>")
	public void giveProductProductOfferCode(@Named("ProductOfferCode")String ProductOfferCode)
	{
		objAdminMyAccountMyDetailsTest.giveProductOfferCode(ProductOfferCode);
	}
	@When ("BD:I give DownLoad Count Limit <DownCountLmt>")
	public void giveDownLoadCountLimit(@Named("DownCountLmt")String Downcntlmt)
	{
		objAdminMyAccountMyDetailsTest.giveDownLoadCountLimit(Downcntlmt);
	}
	@When ("BD:I select Download Expiry Date as today")
	public void selectDownloadExpAsToDayDate()
	{
		objAdminMyAccountMyDetailsTest.selectDownloadExpAsToDayDate();
	}

	@When ("BD:I select the file <FileName> through Browse Button")
	public void selectFilethroughBrowseButton(@Named("FileName") String FileName)
	{
		objAdminMyAccountMyDetailsTest.selectFilethroughBrowseButton(FileName);
	}
	@Then ("BD:The selected file name should display")
	public void isFileNameVisible()
	{
		objAdminMyAccountMyDetailsTest.isFileNameVisible();
	}
	@When ("BD:Click on Upload Button")
	public void clickUploadButton()
	{
		objAdminMyAccountMyDetailsTest.clickUploadButton();
	}
	@Then ("BD:Uploaded Product Offer Code should be visible in the ManageDownLoads Table <ProductOfferCode>")
	public void isProductOfferCodePresent(@Named("ProductOfferCode")String ProductOfferCode)
	{
		objAdminMyAccountMyDetailsTest.isProductOfferCodePresent(ProductOfferCode);
	}
	@When ("BD:I click on Delete button")
	public void clickOnDeleteButton(@Named("ProductOfferCode") String ProductOfferCodes)
	{
		objAdminMyAccountMyDetailsTest.clickOnDeleteButton(ProductOfferCodes);
	}
	
	@Then ("BD:It should display the ConfirmationPrompt")
	public void isConfirmationPromptAvilable()
	{
		objAdminMyAccountMyDetailsTest.isConfirmationPromptAvilable();
	}
	@When ("BD:I select Ok button on the Confirmation")
	public void clickOnConfirmationButton()
	{
		objAdminMyAccountMyDetailsTest.clickOnConfirmationButton();
	}

	
	@Then ("BD:Product offercode should be deleted from the ManageDownloadsTable <ProductOfferCode>")
	public void isProductOfferCodeFileAvilable(@Named("ProductOfferCode")String ProductOfferCodefile)
	{
		objAdminMyAccountMyDetailsTest.isProductOfferCodeFileAvilable(ProductOfferCodefile);
	}
	
	
}
