package com.dnb.automation.bd.tests;

import java.sql.SQLException;

import org.junit.Assert;

import com.dnb.automation.bd.pages.DBConnectionPage;

import net.thucydides.core.steps.ScenarioSteps;

public class DataBaseTest extends ScenarioSteps{
	DBConnectionPage objDBConnectionPage;

	public void revertProfileClaimStatus(String duns) throws SQLException
	{
		objDBConnectionPage.revertProfileClaimStatus(duns);
	}
	
	public void VerifyUserPendingStatusDB(String emailId) throws SQLException
	{
		String status_code = objDBConnectionPage.getUserStatusDB(emailId);
		Assert.assertEquals("1",status_code);		
	}
}
