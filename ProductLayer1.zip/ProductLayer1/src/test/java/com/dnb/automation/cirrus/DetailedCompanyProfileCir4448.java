package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedCompanyProfileCir4448 - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class DetailedCompanyProfileCir4448 extends SerenityStory{

}
