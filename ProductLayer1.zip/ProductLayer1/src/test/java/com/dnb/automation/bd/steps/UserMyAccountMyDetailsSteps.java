package com.dnb.automation.bd.steps;

import java.sql.SQLException;

import net.thucydides.core.annotations.Steps;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import com.dnb.automation.bd.tests.UserMyAccountMyDetailsTest;

public class UserMyAccountMyDetailsSteps {
	
	@Steps
	UserMyAccountMyDetailsTest objMyAccountTest;
	
	@When("BD:I update the value in Prefix dropdown <prefix>")
	public void clickPrefixDropdown(@Named("prefix")String Prefix)throws Exception
	{
		objMyAccountTest.PrefixDropdown(Prefix);
	}
	@When("BD:I update the value in FirstName <firstname>")
	public void updateFirstName(@Named("firstname")String Firstname)throws Exception
	{
		objMyAccountTest.updateFirstName(Firstname);
	}
	@When("BD:I update the value in LastName <lastname>")
	public void updateLastName(@Named("lastname")String Lastname)throws Exception
	{
		objMyAccountTest.updateLastName(Lastname);
	}
	@When("BD:I update the value in CountryCode <countrycode>")
	public void updateCountryCode(@Named("countrycode")String Countrycode)throws Exception
	{
		objMyAccountTest.updateCountryCode(Countrycode);
	}
	@When("BD:I update the value in AreaCode <areacode>")
	public void updateAreaCode(@Named("areacode")String Areacode)throws Exception
	{
		objMyAccountTest.updateAreaCode(Areacode);
	}
	@When("BD:I update the value in PhoneNumber <phoneno>")
	public void updatePhoneNumber(@Named("phoneno")String Phoneno)throws Exception
	{
		objMyAccountTest.updatePhoneNumber(Phoneno);
	}
	@When("BD:I update the value in Extension <extension>")
	public void updateExtension(@Named("extension")String Extension)throws Exception
	{
		objMyAccountTest.updateExtension(Extension);
	}
	@When("BD:I update the value in Country DDL <countryddl>")
	public void updateCountryDDL(@Named("countryddl")String CountryDdl)throws Exception
	{
		objMyAccountTest.updateCountryDDL(CountryDdl);
	}
	@When("BD:I update the value in Company website URL <company website>")
	public void updateWebsiteUrl(@Named("company website")String CompanyWebsite)throws Exception
	{
		objMyAccountTest.updateWebsiteUrl(CompanyWebsite);
	}
	@When("BD:I click on Save Button")
	public void clickSaveBtn()
	{
		objMyAccountTest.clickSaveBtn();
	}
	@Then("BD:Changes should be saved successfully")
	public void clickMsg()
	{
		objMyAccountTest.clickMsg();
	}
	@Then("BD:Updated value should be displayed in prefix field <prefix>")
	public void verifyPrefix(@Named("prefix")String Prefix)throws Exception
	{
		objMyAccountTest.verifyPrefix(Prefix);
	}
	@Then("BD:Updated value should be displayed in FirstName field <firstname>")
	public void verifyFirstName(@Named("firstname")String FirstName)throws Exception
	{
		objMyAccountTest.verifyFirstName(FirstName);
	}
	@Then("BD:Updated value should be displayed in LastName field <lastname>")
	public void verifyLasttName(@Named("lastname")String LastName)throws Exception
	{
		objMyAccountTest.verifyLasttName(LastName);
	}
	@Then("BD:Updated value should be displayed in CountryCode field <countrycode>")
	public void verifyCountryCode(@Named("countrycode")String CountryCode)throws Exception
	{
		objMyAccountTest.verifyCountryCode(CountryCode);
	}
	@Then("BD:Updated value should be displayed in AreaCode field <areacode>")
	public void verifyAreaCode(@Named("areacode")String AreaCode)throws Exception
	{
		objMyAccountTest.verifyAreaCode(AreaCode);
	}
	@Then("BD:Updated value should be displayed in Phone Number field <phoneno>")
	public void verifyPhoneNo(@Named("phoneno")String PhoneNo)throws Exception
	{
		objMyAccountTest.verifyPhoneNo(PhoneNo);
	}
	@Then("BD:Updated value should be displayed in Extension field <extension>")
	public void verifyextension(@Named("extension")String Extension)throws Exception
	{
		objMyAccountTest.verifyExtension(Extension);
	}
	@Then("BD:Updated value should be displayed in CountryDDL field <countryddl>")
	public void verifycountryddl(@Named("countryddl")String CountryDdl)throws Exception
	{
		objMyAccountTest.verifycountryddl(CountryDdl);
	}
	@Then("BD:Updated value should be displayed in Company website Url field <company website>")
	public void verifycompanywebsiteurl(@Named("company website")String Companywebsite)throws Exception
	{
		objMyAccountTest.verifycompanywebsiteurl(Companywebsite);
	}
	@Then("BD:Updated Prefix value in UI should match with the Prefix value in DB <prefix>")
	public void verifyPrefixDB(@Named("prefix")String Prefix)throws Exception
	{
		String userName = System.getProperty("UserName");
		objMyAccountTest.verifyPrefixDB(Prefix,userName);
	}	
	@Then("BD:Updated Prefix value in UI should match with the Prefix value in DB <firstname>")
	public void verifyFirstnameDB(@Named("firstname")String FirstName)throws Exception
	{
		String userName = System.getProperty("UserName");
		objMyAccountTest.verifyFirstnameDB(FirstName,userName);
	}
	@Then("BD:Updated LastName value in UI should match with the Lastname value in DB <lastname>")
	public void verifyLastnameDB(@Named("lastname")String LastName)throws Exception
	{
		String userName = System.getProperty("UserName");
		objMyAccountTest.verifyLastnameDB(LastName,userName);
	}
	@Then("BD:Updated CountryCode value in UI should match with the CountryCode value in DB <countrycode>")
	public void verifyCountryCodeDB(@Named("countrycode")String CountryCode)throws Exception
	{
		String userName = System.getProperty("UserName");
		objMyAccountTest.verifyCountryCodeDB(CountryCode,userName);
	}
	@Then("BD:Updated AreaCode value in UI should match with the AreaCode value in DB <areacode>")
	public void verifyAreaCodeDB(@Named("areacode")String AreaCode)throws Exception
	{
		String userName = System.getProperty("UserName");
		objMyAccountTest.verifyAreaCodeDB(AreaCode,userName);
	}
	@Then("BD:Updated PhoneNumber value in UI should match with the PhoneNumber value in DB <phoneno>")
	public void verifyPhoneNumDB(@Named("phoneno")String PhoneNumber)throws Exception
	{
		String userName = System.getProperty("UserName");
		objMyAccountTest.verifyPhoneNumDB(PhoneNumber,userName);
	}
	@Then("BD:Updated Extension value in UI should match with the Extension value in DB <extension>")
	public void verifyExtensionDB(@Named("extension")String Extension)throws Exception
	{
		String userName = System.getProperty("UserName");
		objMyAccountTest.verifyExtensionDB(Extension,userName);
	}
	@Then("BD:Updated CountryDDL value in UI should match with the CountryDDL value in DB <countryddl>")
	public void verifyCountryDDLDB(@Named("countryddl")String CountryDDL)throws Exception
	{
		String userName = System.getProperty("UserName");
		objMyAccountTest.verifyCountryDDLDB(CountryDDL,userName);
	}
	@Then("BD:Updated CompanyWebsite Url value in UI should match with the CompanyWebsite Url value in DB <company website>")
	public void verifyCompanyWebsiteDB(@Named("company website")String CompanyWebsite)throws Exception
	{
		String userName = System.getProperty("UserName");
		objMyAccountTest.verifyCompanyWebsiteDB(CompanyWebsite,userName);
	}
	@When("BD:I click on My Details tab")
    public void selectMyDetailsTab() throws Exception    
    {
		objMyAccountTest.selectMyDetailsTab();
    }
	
}
