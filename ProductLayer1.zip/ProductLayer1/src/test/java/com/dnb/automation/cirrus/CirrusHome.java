package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * CirrusHomePg - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class CirrusHome extends SerenityStory {

}
