package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedTelephAcrossmarketsDbcredit1562 - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class DetailedTelephAcrossmarketsDbcredit1562 extends SerenityStory{

}
