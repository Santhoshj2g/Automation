package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class DetailedLegalEventsUkIeDbcredit1110 extends SerenityStory{

}
