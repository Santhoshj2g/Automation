package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * Left navigation tab - This program calls serenity
 * story file
 * 
 * @author Rajesh G 
 ***********************************************************************************************/

public class PortfolioPlottedGraph extends SerenityStory{

}
