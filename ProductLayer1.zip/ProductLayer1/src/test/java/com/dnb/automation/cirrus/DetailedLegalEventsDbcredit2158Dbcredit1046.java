package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class DetailedLegalEventsDbcredit2158Dbcredit1046 extends SerenityStory{

}
