package com.dnb.automation.bd.steps;

import java.sql.SQLException;

import net.thucydides.core.annotations.Steps;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;

import com.dnb.automation.bd.tests.DataBaseTest;
import com.dnb.automation.bd.tests.SearchTest;

public class DataBaseSteps {

	@Steps
	DataBaseTest objDataBaseTest;
	
	@Given("BD:I am changing the profile <DunsNo> status to Claim in Database")
	public void revertProfileClaimStatus(@Named("DunsNo")String dunsNo) throws SQLException
	{
		objDataBaseTest.revertProfileClaimStatus(dunsNo);
	}
}
