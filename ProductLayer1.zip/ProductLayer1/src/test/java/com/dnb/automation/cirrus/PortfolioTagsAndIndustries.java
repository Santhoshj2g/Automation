package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * ReportCompanyProfileUS - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/


public class PortfolioTagsAndIndustries extends SerenityStory{

}
