package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedLegalEventsTabCA - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/


public class DetailedLegalEventsTabCA extends SerenityStory{

}
