package com.dnb.automation.bd.steps;

import java.sql.SQLException;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import net.thucydides.core.annotations.Steps;

import com.dnb.automation.bd.tests.SearchTest;

public class SearchSteps {
	
	@Steps
	SearchTest objSearchTest;
	  

	@Given("BD:I am in home page")
	public void callInHomePage() throws Exception
	{
		objSearchTest.inHomePage();
	}	
	@When("BD:I select <Option> search and enter <DunsNo>")
	public void callSearchDuns(@Named("Option")String option,@Named("DunsNo")String dunsNo) throws Exception
	{
		objSearchTest.searchDuns(option,dunsNo);
	}
	@When("BD:I select <Option> search and enter <Value>")
	public void callSearchProfile(@Named("Option")String option,@Named("Value")String value) throws Exception
	{
		objSearchTest.searchDuns(option,value);
	}
	@When("BD:I select the profile to View")
	public void callSelectProfileToView()
	{
		objSearchTest.selectProfileToView();
	}	
	@Then("BD:profile <DunsNo> should be displayed")
	public void callVerifyProfile_Duns(@Named("DunsNo")String dunsNo) throws SQLException
	{
		objSearchTest.verifyProfile_Duns(dunsNo);
	}	
	@Then("BD:Result table should be displayed")
	public void callVerifyResultTable()
	{
		objSearchTest.VerifyResultTable();
	}	
	@Then("the total no of rows should be maximum 30 for guest user")
	public void callGetNoOfRowsInSearchResult()
	{
		objSearchTest.verifyNoOfRowsInSearchResult();
	}
	@When("BD:I click on Home")
	public void callclickHome() throws Exception
	{
		objSearchTest.clickHome();
	}	
	@When("BD:I click on the Manage Account Link")
	public void callmngAccLnk() throws Exception
	{
		objSearchTest.mngAccLnk();
	}
	@When("BD:I Click on Edit My Profile Online Link")
	public void clickEditmyProfile() throws Exception
	{
		objSearchTest.clickEditmyProfile();
	}	
	@When("BD:I click on reset password")
	public void callresetpswd() throws Exception
	{
		objSearchTest.resetPswdLnk();
	}	
	@Then("BD:Reset Paswword page should be dispalyed under My Account section")
	public void callverifyResetPswdPageadmin() throws Exception
	{
		objSearchTest.verifyResetPswdPageadmin();
	}	
	@Then("BD:Reset Paswword page should be dispalyed")
	public void callverifyResetPswdPage() throws Exception
	{
		objSearchTest.verifyResetPswdPage();
	}
	@Then("BD:Page should display Email Id field")
	public void callverifyEmailId() throws Exception
	{
		objSearchTest.verifyEmailId();
	}
	@Then("BD:Page should display First Name field")
	public void callverifyFirstName() throws Exception
	{
		objSearchTest.verifyFirstName();
	}
	@Then("BD:Page should display Last Name")
	public void callverifyLastName() throws Exception
	{
		objSearchTest.verifyLastName();
	}	
	@When("BD:I click on Edit My Profile Online")
	public void calleditprofile() throws Exception
	{
		objSearchTest.editprofile();
	}
	@Then("BD:Display Edit My Profile Online page")
	public void callverifyEditprofilePage() throws Exception
	{
		objSearchTest.verifyEditprofilePage();
	}
	@Then("BD:Details should be displayed under My Accounts section")
	public void verifyMyAcc() throws Exception
	{
		objSearchTest.verifyMyAcc();
	}
	@Then("BD:Page should display Email ID")
	public void verifyEmailid() throws Exception
	{
		objSearchTest.verifyEmailid();
	}
	@Then("BD:Page should display Prefix")
	public void verifyPrefix() throws Exception
	{
		objSearchTest.verifyPrefix();
	}
	@Then("BD:Page should display FirstName")
	public void verifyFirstName() throws Exception
	{
		objSearchTest.verifyFirstName();
	}
	@Then("BD:Page should display LastName")
	public void verifyLastName() throws Exception
	{
		objSearchTest.verifyLastName();
	}
	@Then("BD:Page should display CountryCode")
	public void verifyCountrycode() throws Exception
	{
		objSearchTest.verifyCountrycode();
	}
	@Then("BD:Page should display AreaCode")
	public void verifyAreacode() throws Exception
	{
		objSearchTest.verifyAreacode();
	}
	@Then("BD:Page should display PhoneNumber")
	public void verifyPhoneNo() throws Exception
	{
		objSearchTest.verifyPhoneNo();
	}
	@Then("BD:Page should display Extension")
	public void verifyPhoneExtn() throws Exception
	{
		objSearchTest.verifyPhoneExtn();
	}
	@Then("BD:Page should display Country")
	public void verifyCountry() throws Exception
	{
		objSearchTest.verifyCountry();
	}
	@Then("BD:Page should display Company Website URL")
	public void verifyCompanyUrl() throws Exception
	{
		objSearchTest.verifyCompanyUrl();
	}	
	@Then("BD:Page should display Role")
	public void verifyRole() throws Exception
	{
		objSearchTest.verifyRole();
	}
	@When("BD:I click on Create New User link")
	public void callcreateNewUser() throws Exception
	{
		objSearchTest.createNewUser();
	}
	@Then("BD:Display User Registration Management details")
	public void verifyUserRegMgmnt() throws Exception
	{
		objSearchTest.verifyUserRegMgmnt();
	}	
	@When("BD:I click on the Downloads and Offers Link")
	public void calldownloadsandoffersLnk() throws Exception
	{
		objSearchTest.downloadsandoffersLnk();
	}
	@When("BD:I click on Manage Downloads Link")
	public void callmanageDownloads() throws Exception
	{
		objSearchTest.manageDownloads();
	}	
	@Then("BD:Page should display Product Description")
	public void verifyProductDesc() throws Exception
	{
		objSearchTest.verifyProductDesc();
	}
	@Then("BD:Page should dispaly Product offer code")
	public void verifyProductOfferCode() throws Exception
	{
		objSearchTest.verifyProductOfferCode();
	}
	@Then("BD:Page should display Download Count limit")
	public void verifyDownloadCount() throws Exception
	{
		objSearchTest.verifyDownloadCount();
	}
	@Then("BD:Page should display Expiry Date")
	public void verifyExpiryDate() throws Exception
	{
		objSearchTest.verifyExpiryDate();
	}
	@Then("BD:Page should display Document File")
	public void verifyDocFile() throws Exception
	{
		objSearchTest.verifyDocFile();
	}	
	@Then("BD:Page should dispaly Browse button")
	public void verifyBrowseBtn() throws Exception
	{
		objSearchTest.verifyBrowseBtn();
	}
	@Then("BD:Page should display Upload button")
	public void verifyUploadbtn() throws Exception
	{
		objSearchTest.verifyUploadbtn();
	}
	@Then("BD:Page should dispaly Cancel button")
	public void verifyCancelbtn() throws Exception
	{
		objSearchTest.verifyCancelbtn();
	}
	@When("BD:I click on See My Requested Connections Link")
	public void requestedConnectionsLnk() throws Exception
	{
		objSearchTest.requestedConnectionsLnk();
	}	
	@Then("BD:It should display Connections page")
	public void ConnectionsPage() throws Exception
	{
		objSearchTest.ConnectionsPage();
	}	
	@Then("BD:My Requested Connections details should be dispalyed under My Account section")
	public void requestedConnectionsPage() throws Exception
	{
		objSearchTest.requestedConnectionsPage();
	}
	@Then("BD:Connections details should be dispalyed with Invites Received Header")
	public void verifyInvitesReceived() throws Exception
	{
		objSearchTest.verifyInvitesReceived();
	}
	@Then("BD:Page should dispaly Received field")
	public void verifyReceived() throws Exception
	{
		objSearchTest.verifyReceived();
	}	
	@Then("BD:Page should dispaly Request For field")
	public void verifyRequestFor() throws Exception
	{
		objSearchTest.verifyRequestFor();
	}
	@Then("BD:Page should display Received From field")
	public void verifyReceivedFrom() throws Exception
	{
		objSearchTest.verifyReceivedFrom();
	}
	@Then("BD:Page should display Status field")
	public void verifyStatus() throws Exception
	{
		objSearchTest.verifyStatus();
	}	
	@Then("BD:Page should display Invites Sent Header section")
	public void verifyInvitesSent() throws Exception
	{
		objSearchTest.verifyInvitesSent();
	}			
	@Then("BD:Page should dispaly the checkbox for accepting Terms and Conditions")
	public void verifyTermsandConditions() throws Exception
	{
		objSearchTest.verifyTermsandConditions();
	}
	@Then("BD:Page should display Register button")
	public void verifyRegisterButton() throws Exception
	{
		objSearchTest.verifyRegisterButton();
	}
	@Then("BD:Page should display Search button")
	public void verifySearchButton() throws Exception
	{
		objSearchTest.verifySearchButton();			
	}
	@Then("BD:Page should display Terms and Conditions checkbox")
	public void verifyTermsandCondtns() throws Exception
	{
		objSearchTest.verifyTermsandCondtns();			
	}
	@Then("BD:Page should display Save Button")
	public void verifySaveBtn() throws Exception
	{
		objSearchTest.verifySaveBtn();			
	}
	@When("BD:I Click on Add New Users to My Account Link")
	public void clickNewUser() throws Exception
	{
		objSearchTest.clickNewUser();			
	}
	@Then("BD:Display My Details page")
	public void verifyMydetails() throws Exception
	{
		objSearchTest.verifyMydetails();			
	}
	@Then("BD:Display Profile Users page")
	public void verifyProfileUsers() throws Exception
	{
		objSearchTest.verifyProfileUsers();			
	}	
	@When("BD:I Click on Add Photos Link")
	public void clickAddPhotos() throws Exception
	{
		objSearchTest.clickAddPhotos();			
	}
	@Then("BD:Display Company Profile details")
	public void verifyCompanyProfile() throws Exception
	{
		objSearchTest.verifyCompanyProfile();			
	}
	@Then("BD:Company Profile details should be displayed under My Account section")
	public void verifyMyAccount() throws Exception
	{
		objSearchTest.verifyMyAccount();			
	}
	@Then("BD:Page should display Company Name")
	public void verifycompanyName() throws Exception
	{
		objSearchTest.verifycompanyName();			
	}
	@Then("BD:Page should display Location")
	public void verifyLocation() throws Exception
	{
		objSearchTest.verifyLocation();			
	}
	@Then("BD:Page should display Line of Business Type")
	public void verifyLineofBusiness() throws Exception
	{
		objSearchTest.verifyLineofBusiness();			
	}
	@Then("BD:Page should display Claimed On")
	public void verifyClaimedOn() throws Exception
	{
		objSearchTest.verifyClaimedOn();			
	}
	@Then("BD:Page should display QR Code")
	public void verifyQRCode() throws Exception
	{
		objSearchTest.verifyQRCode();			
	}
	@When("BD:I Click on Click here to use your offercode(s) Link")
	public void clickOfferCodes() throws Exception
	{
		objSearchTest.clickOfferCodes();			
	}
	@Then("BD:Display Submit button")
	public void verifySubmitBtn() throws Exception
	{
		objSearchTest.verifySubmitBtn();			
	}	
	@Then("BD:Page should display User Type")
	public void verifyUserType() throws Exception
	{
		objSearchTest.verifyUserType();			
	}
	@Then("BD:Page should display User Count")
	public void verifyUserCount() throws Exception
	{
		objSearchTest.verifyUserCount();			
	}
	@When("BD:Select Country value from the search dropdown")
	public void selectsearchdropdown() throws Exception
	{
		objSearchTest.selectsearchdropdown();			
	}
	@When("BD:Enter Country value in Serach Term textbox<country>")
	public void enterCountry(@Named("country")String Country) throws Exception
	{
		objSearchTest.enterCountry(Country);			
	}
	@When("BD:I click on Search button")
	public void clickSearch() throws Exception
	{
		objSearchTest.clickSearch();			
	}
	@When("BD:I click on Narrow Results tab")
	public void clickNarrowresults() throws Exception
	{
		objSearchTest.clickNarrowresults();			
	}
	@When("BD:I select a value from Country/Location in Narrow Results<location>")
	public void selectCountry(String location) throws Exception
	{
		objSearchTest.selectCountry(location);			
	}	
	@When("BD:I select a value from State/Province in Narrow Results<state>")
	public void selectState(String state) throws Exception
	{
		objSearchTest.selectState(state);			
	}
	@When("BD:I click on Apply FIlters button")
	public void clickApplyFilters() throws Exception
	{
		objSearchTest.clickApplyFilters();			
	}
	@When("BD:I click on Total No of records displayed")
	public void getTotalRecords() throws Exception
	{
		objSearchTest.getTotalRecords();			
	}
	@When("BD:I click on Remove Filters in Narrow Results")
	public void clickRemoveFilters() throws Exception
	{
		objSearchTest.clickRemoveFilters();			
	}
	@Then("BD:Page should display Overall Search results")
	public void getOverallResults() throws Exception
	{
		objSearchTest.getOverallResults();			
	}
	@When("BD:I select value from Currency dropdown<currency>")
	public void selectCurrency(String currency) throws Exception
	{
		objSearchTest.selectCurrency(currency);			
	}
	@When("BD:I select value from #Employee dropdown<employee>")
	public void selectEmployeeRange(String employee) throws Exception
	{
		objSearchTest.selectEmployeeRange(employee);			
	}
	@When("BD:I select a value from Sales revenue Range in Narrow Results<revenue>")
	public void selectRevenue(String revenue) throws Exception
	{
		objSearchTest.selectRevenue(revenue);			
	}
	@Then("BD:The total no of records should be matched with the value displayed in the Country search term")
	public void verifyCountryResults() throws Exception
	{
		objSearchTest.verifyCountryResults();			
	}
	@Then("BD:The total no of records should be matched with the value displayed in the Currency search term")
	public void verifyCurrencyResults() throws Exception
	{
		objSearchTest.verifyCurrencyResults();			
	}
	@Then("BD:The total no of records should be matched with the value displayed in the #Employee search term")
	public void verifyEmployeeResults() throws Exception
	{
		objSearchTest.verifyEmployeeResults();			
	}
	@Then("BD:The total no of records should be matched with the value displayed in the State search term")
	public void verifyStateResults() throws Exception
	{
		objSearchTest.verifyStateResults();			
	}
	@Then("BD:The total no of records should be matched with the value displayed in the Revenue search term")
	public void verifyRevenueResults() throws Exception
	{
		objSearchTest.verifyRevenueResults();			
	}	
	@When("BD:I click on the company name in results section")
	public void clickCmpnyName() throws Exception
	{
		objSearchTest.clickCmpnyName();			
	}
	@Then("BD:Page should display D&B verified Information tab")
	public void clickDnbVerifiedInfoTab() throws Exception
	{
		objSearchTest.clickDnbVerifiedInfoTab();			
	}
	@Then("BD:Page should display Company Provided Information tab")
	public void clickCompanyProvidedinfoTab() throws Exception
	{
		objSearchTest.clickCompanyProvidedinfoTab();			
	}
	@Then("BD:Page should display the Overview section under D&B verified Information tab")
	public void verifyOverviewSection() throws Exception
	{
		objSearchTest.verifyOverviewSection();			
	}
	@Then("BD:Page should display the Related Tags section under D&B verified Information tab")
	public void verifyRelatedTags() throws Exception
	{
		objSearchTest.verifyRelatedTags();			
	}
	@Then("BD:Page should display Corporate Information section under D&B verified Information tab")
	public void verifyCorporateInfosection() throws Exception
	{
		objSearchTest.verifyCorporateInfosection();			
	}
	@Then("BD:Page should display Registration Information section under D&B verified Information tab")
	public void verifyRegistrationInfo() throws Exception
	{
		objSearchTest.verifyRegistrationInfo();			
	}
	@Then("BD:Page should display DUNS Number section under D&B verified Information tab")
	public void verifyDUNSNumberSection() throws Exception
	{
		objSearchTest.verifyDUNSNumberSection();			
	}
	@Then("BD:Page should display Key Employee section under D&B verified Information tab")
	public void verifyKeyEmployeeSection() throws Exception
	{
		objSearchTest.verifyKeyEmployeeSection();			
	}
	@Then("BD:Page should display Financial information section under D&B verified Information tab")
	public void verifyFinancialInformationsection() throws Exception
	{
		objSearchTest.verifyFinancialInformationsection();			
	}
	@Then("BD:Page should display Products and Brands section under D&B verified Information tab")
	public void verifyProductsandBrandsSection() throws Exception
	{
		objSearchTest.verifyProductsandBrandsSection();			
	}
	@When("BD:I Click on the Company provided Information tab")
	public void clickCompanyProvidedInfoTab() throws Exception
	{
		objSearchTest.clickCompanyProvidedInfoTab();			
	}
	@Then("BD:page should display Executives section")
	public void VerifyExecutives() throws Exception
	{
		objSearchTest.VerifyExecutives();			
	}
	@Then("BD:page should display Name field")
	public void verifyName() throws Exception
	{
		objSearchTest.verifyName();			
	}
	@Then("BD:page should display Title field")
	public void verifyTitle() throws Exception
	{
		objSearchTest.verifyTitle();			
	}
	@Then("BD:Page should dispaly the Connect button")
	public void verifyConnectBtn() throws Exception
	{
		objSearchTest.verifyConnectBtn();			
	}
	@Then("BD:Page should display the DUNS Registered seal")
	public void verifyDUNSRegSeal() throws Exception
	{
		objSearchTest.verifyDUNSRegSeal();			
	}
	@Then("BD:Page should display verified By DunBradstreet in D&B verified Information tab")
	public void DBVerifiedText() throws Exception
	{
		objSearchTest.DBVerifiedText();			
	}
	@Then("BD:Page should display About the Company section under D&B verified Information tab")
	public void verifyAboutTheCpmny() throws Exception
	{
		objSearchTest.verifyAboutTheCpmny();			
	}
	@Then("BD:Page should display Line of Business description under Related Tags")
	public void verifyLineofBusDesc() throws Exception
	{
		objSearchTest.verifyLineofBusDesc();			
	}
	@Then("BD:Search should be displayed in top of the page")
	public void verifySearchOption() throws Exception
	{
		objSearchTest.verifySearchOption();			
	}
	@Then("BD:General Disclaimer should be displayed at the bottom of the page")
	public void verifyDisclaimer() throws Exception
	{
		objSearchTest.verifyDisclaimer();			
	}
	@Then("BD:Page should display DRS Signed in as link")
	public void verifyDRSSignedinasLink() throws Exception
	{
		 String userName = System.getProperty("DrsUserName");
		 objSearchTest.verifySignedinLink(userName);			
	}
	@Then("BD:Page should display Non DRS Signed in as link")
	public void verifyNonDRSSignedinasLink() throws Exception
	{
		String userName = System.getProperty("NonDrsUserName");
		 objSearchTest.verifySignedinLink(userName);			
	}
	@Then("BD:Page should display SignOut link")
	public void verifySignOutLink() throws Exception
	{
		objSearchTest.verifySignOutLink();			
	}
	@Then("BD:Page should display profile Claimed button")
	public void VerifyProfileClaimedBtn() throws Exception
	{
		objSearchTest.VerifyProfileClaimedBtn();			
	}
	@When("BD:I Click on My Dashboard tab")
	public void clickMyDashboard() throws Exception
	{
		objSearchTest.clickMyDashboard();			
	}
	
	
	 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
