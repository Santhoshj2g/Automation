package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class DetailedCompanyProfileDbcredit1111 extends SerenityStory{

}
