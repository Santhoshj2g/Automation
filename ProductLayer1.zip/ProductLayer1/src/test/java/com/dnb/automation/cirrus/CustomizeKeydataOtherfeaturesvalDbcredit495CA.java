package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * CustomizeKeydataOtherfeaturesvalDbcredit495CA - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/
public class CustomizeKeydataOtherfeaturesvalDbcredit495CA extends SerenityStory{

}
