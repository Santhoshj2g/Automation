package com.dnb.automation.bd.tests;


import java.io.IOException;

import org.junit.Assert;

import com.dnb.automation.bd.pages.SuperAdminMyAccountPage;

import net.thucydides.core.steps.ScenarioSteps;

public class SuperAdminMyAccountTest extends ScenarioSteps {
		
	SuperAdminMyAccountPage superAdminMyAccountPage;
	
	//Test to click on My Account tab    
    public void clickMyAccountTab()
    {
    	superAdminMyAccountPage.clickMyAccountTab();
    }
    
    //Test to verify whether My Account title is displayed
    public void verifyMyAccountPageTitle(String myAccountTitle)
    {    
    	Assert.assertEquals(myAccountTitle,superAdminMyAccountPage.getMyAccountPgTitle());
    }
    
    //Test to click on My Details tab
    public void clickMyDetailsTab()
    {
    	superAdminMyAccountPage.clickMyDetailsTab();
    }
    
    //Test to verify whether manage ads link is displayed
    public void verifyManageAdsLink()
    {    	
    	Assert.assertEquals(true,superAdminMyAccountPage.isPresentManageAds());
    }
    
    //Test to click on manage ads link
    public void clickManageAdsLink()
    {
    	superAdminMyAccountPage.clickManageAdsLink();
    }
    
    //Test to verify whether manage advertisement title is displayed
    public void getManageAdvTitle(String manageAdvTitle)
    {    	
    	Assert.assertEquals(manageAdvTitle,superAdminMyAccountPage.getManageAdvTitle());
    }
    
    //Test to upload ads
    public void uploadAdTest() throws Exception
    {
    	superAdminMyAccountPage.uploadAds();
    }
    
    //Test to verify the upload status
    public void verifyUploadStatus() throws IOException
    {
    	Assert.assertEquals(true,superAdminMyAccountPage.imgUploadStatus());
    }
        
    //Test to click on reset password link
    public void clickOnResetPasswordTest()
    {
    	superAdminMyAccountPage.clickOnResetPassword();
    }
    
    //Test to verify whether reset password title is displayed
    public void getResetPwdPgTitleTest(String resetPwdTitle)
    {
    	Assert.assertEquals(resetPwdTitle,superAdminMyAccountPage.getResetPwdPgTitle(resetPwdTitle));
    }
    
    //Test to enter details to search for a registered user
    public void fillResetFieldsAndSearchTest(String email,String firstName,String lastName,String country)
    {
    	superAdminMyAccountPage.fillResetFieldsAndSearch(email,firstName,lastName,country);
    }
    
    
    //Test to select the registered user
    public void isUserDetailsDisplayedTest(String email)
    {
    	superAdminMyAccountPage.isUserDetailsDisplayed(email);
    }
    
    //Test to click on reset button
    public void clickOnResetBtnTest()
    {
    	superAdminMyAccountPage.clickOnResetBtn();    	
    }
    
    //Test to verify whether triggering mail message is displayed
    public void getResetMsgTest()
    {
    	Assert.assertEquals(true,superAdminMyAccountPage.getResetMsg().contains("successfully sent"));
    }
    
    //Test to launch gmail
    public void launchGmailTest() throws Exception
    {
    	superAdminMyAccountPage.launchGmail();
    }
    
    //Test to verify whether gmail login page is displayed
    public void isGmailLoginPgDisplayedTest()
    {
    	Assert.assertEquals(true,superAdminMyAccountPage.isGmailLoginPgDisplayed());
    }
    
    //Test to login into gmail
    public void loginWithUserRegMailIDTest(String userName,String password) throws Exception
    {
    	superAdminMyAccountPage.loginWithUserRegMailID(userName,password);
    }
    
    //Test to verify whether gmail home page of the user is displayed
    public void chkHomePgOfGmailDisplayed(String userName)
    {
    	Assert.assertEquals(userName,superAdminMyAccountPage.getUserNameFrmHomePg());
    }
    
    //Test to click on email to reset password
    public void clickMailTest()
    {
    	superAdminMyAccountPage.clickOnEmailMsg();
    }
    
    //Test to verify whether mail body contains the link to reset password
    public void isDisplayedMailBodyWithResetPwdLink()
    {
    	Assert.assertEquals(true,superAdminMyAccountPage.isDisplayedMailBodyWithResetPwdLink());
    }
    
    //Test to click on reset password link
    public void clickOnResetPwdLnkInMailTest()
    {
    	superAdminMyAccountPage.clickLinkToResetPwd();
    }
    
    //Test to verify whether Activate Account page is displayed
    public void verifyActivateAccPgIsDisplayed(String activateAccount)
    {
    	Assert.assertEquals(activateAccount,superAdminMyAccountPage.getActivateAccPgTitle());
    }
    
    //Test to enter new and confirm password and click on submit button
    public void enterNewAndConfirmPwdTest(String newPwd,String confirmPwd)
    {
    	superAdminMyAccountPage.enterNewAndConfirmPwd(newPwd, confirmPwd);
    }
    
    //Test to verify whether reset status is displayed
    public void verifyMsgActivationSuccessful(String resetPwdStatusMsg)
    {
    	Assert.assertEquals(resetPwdStatusMsg,superAdminMyAccountPage.getActivationMsg());
    }
    
    //Test to click on go to login page link
    public void clickOnGoToLoginPgLinkTest()
    {
    	superAdminMyAccountPage.clickGoToLoginPgAftrChangePwd();
    }
    
  /*  public void verifyHomePgOfSuperAdminIsDisplayed(String loggedInAs)
    {
    	Assert.assertEquals(loggedInAs,superAdminMyAccountPage.getLoggedInTxtFrmAdminHomePg());
    }
    */
    
    //Test to click on logout link
    public void clickOnLogoutLinkTest()
    {
    	superAdminMyAccountPage.clickLogoutLink();
    }

//    Test to click on Manage Ads link
	public void selectManageAds() {
		superAdminMyAccountPage.clickManageAdsLink();		
	}

//Test to select the Ad categories	
	public void selectAdCategories(String adCategories) {
		superAdminMyAccountPage.selectAdCategories(adCategories);		
	}

//Test to enter the Duns number	
	public void enterDuns(String duns) {
		superAdminMyAccountPage.enterDuns(duns);		
	}

//Test to enter the Ad descripton	
	public void enterAdDesc(String adsDesc) {
		superAdminMyAccountPage.enterAdDesc(adsDesc);		
	}


//Test to click on Browser button	
	public void clickBrowseButton() {
		superAdminMyAccountPage.clickBrowseButton();		
	}

//Test to select the CustomerPromotionImage	
	public void uploadAdvertisementImage(String ImageName) {
		superAdminMyAccountPage.uploadAdvertisementImage(ImageName);		
	}

//Test to verify that , selected file name is displayed	
	public void isSelectedFileDisplayed() {
		Assert.assertTrue(superAdminMyAccountPage.isSelectedFileDisplayed());		
	}

//Test to click on the advertisement upload button	
	public void clickAdvUpload() {
		superAdminMyAccountPage.clickAdvUpload();		
	}

//Test to verify that , the advertisement confirmation message is displayed 	
	public void isAdvConfirmationMsgDisp() {
		Assert.assertTrue(superAdminMyAccountPage.getAdvConfrimationMsg().equalsIgnoreCase("The advertisement has been uploaded successfully"));
		
	}

//Test to verify that, the uploaded advertisement is available in the uploaded Ads	
	public void isUploadedAddAvail(String AdsDesc) {
		Assert.assertTrue(superAdminMyAccountPage.isUploadedAddAvail(AdsDesc));		
	}

//Test to verify that , Add delete confirmaiton message is displayed	
	public void isAddDeleteConfirmationDisp() {
		Assert.assertTrue(superAdminMyAccountPage.isAddDeleteConfirmationDisp());		
	}

//Test to click on Ok button of the Adds delete confirmation	
	public void clickOkAddsDelete() {
		 superAdminMyAccountPage.clickOkAddsDelete();		 
	}

//Test to verify that , the add delete confirmation message is displayed	
	public void isAdvDeleteConfirMsgDisp() {
		Assert.assertTrue(superAdminMyAccountPage.getAdvConfrimationMsg().equalsIgnoreCase("Successfully deleted the Advertisement"));
		
	}

//Test to click on delete button of the advertisement	
	public void clickAddDeleteButton(String adsDesc) {
		superAdminMyAccountPage.clickAddDeleteButton(adsDesc);	
	}
    

}
