package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class AccountGlobalWithMeter extends SerenityStory {

}
