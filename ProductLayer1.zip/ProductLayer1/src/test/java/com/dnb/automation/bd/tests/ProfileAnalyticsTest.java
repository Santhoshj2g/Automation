package com.dnb.automation.bd.tests;

import java.sql.SQLException;

import org.hamcrest.Matchers;

//import junit.framework.Assert;




import com.dnb.automation.bd.pages.DBConnectionPage;
import com.dnb.automation.bd.pages.LoginPage;
import com.dnb.automation.bd.pages.ProfileAnalyticsPage;

import net.thucydides.core.steps.ScenarioSteps;

import org.junit.Assert;

public class ProfileAnalyticsTest extends ScenarioSteps {

	LoginPage objLoginPage;
	ProfileAnalyticsPage objProfileAnalyticsPage;
	DBConnectionPage objDBConnectionPage;

	//Test to verify Profile Analytics tab
	public void verifyProfileAnalyticsTab()
	{
		objProfileAnalyticsPage.verifyProfileAnalyticsTab();
	}
	//Test to verify Company Name field
	public void verifyCompanyNameFld()
	{
		objProfileAnalyticsPage.verifyCompanyNameFld();
	}
	//Test to verify Company Name field
	public void verifyAppearedinSearchRes()
	{
		objProfileAnalyticsPage.verifyAppearedinSearchRes();
	}
	//Test to verify Clicked From Search Result field
	public void verifyClickedFromSearchRes()
	{
		objProfileAnalyticsPage.verifyClickedFromSearchRes();
	}
	//Test to verify Clicked From Advertisement
	public void verifyClickedFromAd()
	{
		objProfileAnalyticsPage.verifyClickedFromAd();
	}
	//Test to verify Connect Count field
	public void verifyConnectCount()
	{
		objProfileAnalyticsPage.verifyConnectCount();
	}
	//Test to verify Company Name Link
	public void verifyCmpnyNameLink()
	{
		objProfileAnalyticsPage.verifyCmpnyNameLink();
	}
	//Test to capture the Appeared Search Result value
	public void clickAppearedinSearchResval()
	{
		objProfileAnalyticsPage.clickAppearedinSearchResval();
	}
	//Test to capture the Clicked From Search Result value
	public void getClickedfromSearchResVal()
	{
		objProfileAnalyticsPage.getClickedfromSearchResVal();
	}
	//Test to capture the Clicked From Advertisement value
	public void getClickedfromAddVal()
	{
		objProfileAnalyticsPage.getClickedfromAddVal();
	}
	//Test to capture the Connect Count value
	public void getConnectCount()
	{
		objProfileAnalyticsPage.getConnectCount();
	}
	//Test to search the Company record
	public void serachCmpny(String companyname)
	{
		objProfileAnalyticsPage.serachCmpny(companyname);		
	}	
	//Test to verify the Appeared Search Result count
	public void verifyAppearedinSearchResCnt()
	{
		objProfileAnalyticsPage.verifyAppearedinSearchResCnt();
	}
	//Test to verify the Company Name 
	public void clickCmpnyLink()
	{
		objProfileAnalyticsPage.clickCmpnyLink();
	}
	//Test to click on the My Account tab
	public void clickMyAccTab()
	{
		objProfileAnalyticsPage.clickMyAccTab();
	}
	//Test to Click on the Company Name in search result page
	public void clickCmpnyLink1(String companyname)
	{
		objProfileAnalyticsPage.clickCmpnyLink1(companyname);
	}
	//Test to click on the view button
	public void clickViewBtn(String dunsno)
	{
		objProfileAnalyticsPage.clickViewBtn(dunsno);
	}
	//Test to verify the Profile page
	public void verifyprofilePage(String companyname)
	{
		objProfileAnalyticsPage.verifyprofilePage(companyname);
	}
	//Test to compare the Appeared Search Result value
	public void compareAppearedSearchRes()
	{
		Assert.assertEquals(objProfileAnalyticsPage.compareAppearedSearchRes(),true);		
	}
	public void compareClickedSearchRes()
	{
		Assert.assertEquals(objProfileAnalyticsPage.compareClickedSearchRes(),true);		
	}
	//Test to capture the Appeared Search Result value displayed 
	public void getappearedresult()
	{		
		Assert.assertEquals(objProfileAnalyticsPage.getappearedresult(),true);
	}
	//Test to capture the Clicked Results value
	public void getclickedresults()
	{		
		Assert.assertEquals(objProfileAnalyticsPage.getclickedresults(),true);
	}
	//Test to capture the Connect value
	public void getConnectvalue()
	{
		Assert.assertEquals(objProfileAnalyticsPage.getConnectvalue(),true);
	}
	
}
