package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedCompanyProfileCir4788Us - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class DetailedCompanyProfileCir4788Us extends SerenityStory{

}
