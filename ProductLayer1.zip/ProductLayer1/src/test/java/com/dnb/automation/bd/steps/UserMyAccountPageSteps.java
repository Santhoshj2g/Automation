package com.dnb.automation.bd.steps;

import java.sql.SQLException;

import net.thucydides.core.annotations.Steps;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.When;
import org.jbehave.core.annotations.Then;

import com.dnb.automation.bd.tests.UserMyAccountPageTest;

public class UserMyAccountPageSteps {

	@Steps
	UserMyAccountPageTest objUserMyAccountPageTest;

	@Given("BD:I select the Company Profile tab")
	public void callSelectCompanyProfileTab()
	{
		objUserMyAccountPageTest.selectCompanyProfileTab();
	}
	
	@When("BD:I select Connection tab")
	public void callSelectConnectionTab()
	{
		objUserMyAccountPageTest.selectConnectionTab();
	}

	@When("BD:I select the Invites Sent section")
	public void callSelectInvitesSent()
	{
		objUserMyAccountPageTest.selectInviteSent();
	}

	@When("BD:I select the Invites Received section")
	public void callSelectInvitesReceived()
	{
		objUserMyAccountPageTest.selectInviteReceived();
	}

	@When("BD:I select the profile <DunsNo> and delete the connect request")
	public void callSelectProfileAndDeleteConnectRequest(@Named("DunsNo")String dunsNo) throws SQLException
	{
		objUserMyAccountPageTest.selectProfileAndDeleteConnectRequest(dunsNo);
	}

	@When("BD:I select the profile <DunsNo> and reject the connect request")
	public void callSelectProfileAndRejectConnectRequest(@Named("DunsNo")String dunsNo) throws SQLException
	{
		objUserMyAccountPageTest.selectProfileAndRejectConnectRequest(dunsNo);
	}

	@When("BD:I select the profile <DunsNo> and approve the connect request")
	public void callSelectProfileAndApproveConnectRequest(@Named("DunsNo")String dunsNo) throws SQLException
	{
		objUserMyAccountPageTest.selectProfileAndApproveConnectRequest(dunsNo);
	}
	
	@Then("BD:The Delete Confirmation Message should display")
	public void callIDeleteConfirmatoinDisplayed()
	{
		objUserMyAccountPageTest.isDeleteConfirmationDisplayed();
	}

	@Then("BD:The information message box should display")
	public void callIIsInformationDisplayed()
	{
		objUserMyAccountPageTest.isInformationBoxDisplayed();
	}
	
	@Then("BD:The Information message should disappeared")
	public void callIInformationBoxDisAppeared()
	{
		objUserMyAccountPageTest.isInformationBoxDisAppeared();
	}

	@When("BD:Click Ok button on the delete confirmation")
	public void callAcceptDeleteConfirmation()
	{
		objUserMyAccountPageTest.acceptDeleteConfirmation();
	}

	@When("BD:Click Ok button on the Information Message box")
	public void callAcceptInformationBox()
	{
		objUserMyAccountPageTest.acceptInformationBox();
	}
	
	@Then("BD:The profile <DunsNo> status should be pending in Invites Sent")
	public void callIsProfileStatusPendingInInviteSent(@Named("DunsNo")String dunsNo) throws SQLException
	{
		objUserMyAccountPageTest.isProfileStatusPendingInInviteSent(dunsNo);
	}
	@When("BD:I click on Profile users")
	public void clickProfileUsers()
	{
		objUserMyAccountPageTest.clickProfileUsers();
	}
	
	@Then("BD:Company Name should be displayed under Profile Users tab")
	public void verifyCompanyName() throws SQLException
	{
		objUserMyAccountPageTest.verifyCompanyName();
	}
	
	@When("BD:I select the profile <DunsNo>")
	public void selectProfile(String DunsNo) throws SQLException
	{
//		System.out.println(DunsNo);
		objUserMyAccountPageTest.selectProfile(DunsNo);
	}
		
	@Then("BD:I click on Add user button")
	public void clickAddUserBtn() throws SQLException
	{
		objUserMyAccountPageTest.clickAddUserBtn();
	}		
	@When("BD:I enter valid User id<emailid>")
	public void enterNewUser(String emailid)
	{
		objUserMyAccountPageTest.enterNewUser(emailid);
	}
	
	@When("BD:I click on the save button")
	public void clickSaveBtn() 
	{
		objUserMyAccountPageTest.clickSaveBtn();
	}	
	@When("BD:I click on the Edit Rights radio Button")
	public void selectEditRightsBtn() 
	{
		objUserMyAccountPageTest.selectEditRightsBtn();
	}
	@When("BD:I click on Submit changes button")
	public void clickSubmitBtn() 
	{
		objUserMyAccountPageTest.clickSubmitBtn();
	}
	@Then("BD:New user details should be submitted")
	public void verifyMsg()
	{
		objUserMyAccountPageTest.verifyMsg();
	}
	@When("BD:I click on close icon in Profile Users pop up")
	public void closePopUp() 
	{
		objUserMyAccountPageTest.closePopUp();
	}
	@When("BD:I click on the User Count<DunsNo>")
	public void getUserCnt(String DunsNo) throws SQLException 
	{
		System.out.println("ented first function");		
		objUserMyAccountPageTest.getUserCnt(DunsNo);
	}
	@When("BD:I click on the User Count<DunsNo> after adding the Secondary User")
	public void SecondaryUsrCnt(String DunsNo) throws SQLException 
	{
		//System.out.println("ented first function");		
		objUserMyAccountPageTest.SecondaryUsrCnt(DunsNo);
	}
	
	@Then("BD:The value in User Count should be increased")
	public void verifyUsrCnt()
	{
		objUserMyAccountPageTest.verifyUsrCnt();
	}	
	@When("BD:I click on User Type column")
	public void getUserType() throws SQLException 
	{
		objUserMyAccountPageTest.getUserType();
	}
	@Then("BD:The Edit button should be enabled for Primary User")
	public void verifyEditBtn()
	{
		objUserMyAccountPageTest.verifyEditBtn();
	}	
	@Then("BD:The Edit button should be disabled for Secondary User")
	public void secUsrEditBtn()
	{
		objUserMyAccountPageTest.secUsrEditBtn();
	}
	@When("BD:I click on secondary user details")
	public void getdetails()
	{
		objUserMyAccountPageTest.getdetails();
	}
	@When("BD:I add valid User id<emailid1>")
	public void addNewUser(String emailid1)
	{
		objUserMyAccountPageTest.addNewUser(emailid1);
	}
	@When("BD:It should not allow to provide Edit rights to more than one secondary user")
	public void verifyEditRights()
	{
		objUserMyAccountPageTest.verifyEditRights();
	}	
	@When("BD:It should not allow to provide Connect request to more than one secondary user")
	public void verifyConnectRequest()
	{
		objUserMyAccountPageTest.verifyConnectRequest();
	}	
	@When("BD:I click on the Connect recipient radio Button")
	public void clickConnectRecipient()
	{
		objUserMyAccountPageTest.clickConnectRecipient();
	}	
	@When("BD:I delete the secondary users")
	public void deleteUser()
	{
		objUserMyAccountPageTest.deleteUser();
	}	
	
}
