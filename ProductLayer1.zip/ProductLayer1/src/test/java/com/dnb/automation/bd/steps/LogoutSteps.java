package com.dnb.automation.bd.steps;

import net.thucydides.core.annotations.Steps;

import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import com.dnb.automation.bd.tests.LoginPageTest;
import com.dnb.automation.bd.tests.LogoutPageTest;

public class LogoutSteps {
    @Steps
    LogoutPageTest objLogoutPageTest;

	@When("BD:I click on logout button")
	public void callLogOut()
	{
		objLogoutPageTest.logout();	
	}

}
