package com.dnb.automation.bd.tests;

import java.sql.SQLException;

import com.dnb.automation.bd.pages.DBConnectionPage;
import com.dnb.automation.bd.pages.UserMyAccountPage;

import net.thucydides.core.steps.ScenarioSteps;

import org.junit.Assert;

public class UserMyAccountPageTest extends ScenarioSteps
{
	UserMyAccountPage objUserMyAccountPage;
	DBConnectionPage objDBConnectionPage;
	
//Test to select Connections tab
		public void selectConnectionTab()
		{			
			Assert.assertEquals(true,objUserMyAccountPage.selectConnectionsTab().equals("true"));
			
		}

//Test to select Invite sent section
		public void selectInviteSent()
		{			
			objUserMyAccountPage.selectInvitesSent();			
		}

//Test to select invite Received section
		public void selectInviteReceived()
		{			
			objUserMyAccountPage.selectInvitesReceived();			
		}
		
//Test to select the profile and delete the connect request
		public void selectProfileAndDeleteConnectRequest(String dunsNo) throws SQLException
		{
			String dbProfileName = objDBConnectionPage.getProfileName(dunsNo);
			Assert.assertEquals(true,objUserMyAccountPage.selectProfileConnectRequestAndDelete(dbProfileName));
		}

//Test to select the profile and reject the connect request
		public void selectProfileAndRejectConnectRequest(String dunsNo) throws SQLException
		{
			String dbProfileName = objDBConnectionPage.getProfileName(dunsNo);
			Assert.assertEquals(true,objUserMyAccountPage.selectProfileConnectRequestAndReject(dbProfileName));
		}
		
//Test to select the profile and reject the connect request
		public void selectProfileAndApproveConnectRequest(String dunsNo) throws SQLException
		{
			String dbProfileName = objDBConnectionPage.getProfileName(dunsNo);
			Assert.assertEquals(true,objUserMyAccountPage.selectProfileConnectRequestAndApprove(dbProfileName));
		}

//Test to verify the delete confirmation is displayed		
		public void isDeleteConfirmationDisplayed()
		{
			Assert.assertEquals(true,objUserMyAccountPage.isDeleteConfirmationDisplayed());
		}

//Test to verify the delete information is displayed		
		public void isInformationBoxDisplayed()
		{
			Assert.assertEquals(true,objUserMyAccountPage.isInformationBoxDisplayed());
		}
		
//Test to verify the information message is disappeared		
		public void isInformationBoxDisAppeared()
		{
			Assert.assertEquals(true,!objUserMyAccountPage.isInformationBoxDisplayed());
		}		
						
//Test to accept the delete confirmation
		public void acceptDeleteConfirmation()
		{
			objUserMyAccountPage.acceptDeleteConfirmation();
		}

//Test to accept the Information message box
		public void acceptInformationBox()
		{
			objUserMyAccountPage.acceptInformationBox();
		}

//Test to verify the profile status in invite sent section
		public void isProfileStatusPendingInInviteSent(String dunsNo) throws SQLException
		{
			String dbProfileName = objDBConnectionPage.getProfileName(dunsNo);
			Assert.assertEquals(true,objUserMyAccountPage.isProfileStatusPendingInInviteSent(dbProfileName));
		}
	
//Test to select Company Profile  tab
		public void selectCompanyProfileTab()
		{			
			Assert.assertEquals(true,objUserMyAccountPage.selectCompanyProfileTab().equals("true"));			
		}
		
		
//Test to click the Profile Users tab under My Account			
		public void clickProfileUsers()
		{
			Assert.assertEquals(true,objUserMyAccountPage.clickProfileUsers());
		}

//Test to verify the Company Name
		public void verifyCompanyName()
		{
			//Assert.assertEquals(objUserMyAccountPage.verifyCompanyName(),true);
			objUserMyAccountPage.verifyCompanyName();
		}
		
//Test to select the profile Name using database
		public void selectProfile(String dunsNo)throws SQLException
		{
			String dbProfileName = objDBConnectionPage.getProfileName(dunsNo);
		
			objUserMyAccountPage.selectProfile(dbProfileName);
			//Assert.assertEquals(true,objUserMyAccountPage.selectProfile(dbProfileName));
		}
		
//Test to click the Add User Button
		public void clickAddUserBtn()
		{
			objUserMyAccountPage.clickAddUserBtn();
		}
		
//Test to enter a new user details
		public void enterNewUser(String emailid)
		{
			objUserMyAccountPage.enterNewUser(emailid);
		}
		
//Test to click the Save button	
		public void clickSaveBtn()
		{
			objUserMyAccountPage.clickSaveBtn();
		}
		
//Test to select the Edit Rights button
		public void selectEditRightsBtn()
		{
			objUserMyAccountPage.selectEditRightsBtn();			
		}
		
//Test to click the Submit button
		public void clickSubmitBtn()
		{
			objUserMyAccountPage.clickSubmitBtn();
		}
		
//Test to verify the message displayed in Add Users pop up
		public void verifyMsg()
		{
			objUserMyAccountPage.verifyMsg();
		}
	
		//Test to close the Add Users pop up
		public void closePopUp()
		{
			objUserMyAccountPage.closePopUp();
		}
		
		//Test to get the User count value 
		public void getUserCnt(String dunsNo) throws SQLException
		{
			String dbProfileName = objDBConnectionPage.getProfileName(dunsNo);
			objUserMyAccountPage.getUserCnt(dbProfileName);			
		}
		
		//Test to get the Secondary User Count value
		public void SecondaryUsrCnt(String dunsNo)throws SQLException
		{
			String dbProfileName = objDBConnectionPage.getProfileName(dunsNo);
			objUserMyAccountPage.SecondaryUsrCnt(dbProfileName);				
		}
		
		//Test to verify the User Count value
		public void verifyUsrCnt()
		{
			//objUserMyAccountPage.verifyUsrCnt();
			Assert.assertEquals(true,objUserMyAccountPage.verifyUsrCnt());
		}
		
		//Test to get the User Type
		public void getUserType()
		{
			objUserMyAccountPage.getUserType();
		}
		
		//Test to verify the Edit Button status
		public void verifyEditBtn()
		{
			objUserMyAccountPage.verifyEditBtn();
		}
		
		//Test to verify the Edit Button status of Secondary User
		public void secUsrEditBtn()
		{
			objUserMyAccountPage.secUsrEditBtn();
		}
		
		//Test to get the User Details
		public void getdetails()
		{
			objUserMyAccountPage.getdetails();
		}
		
		//Test to add a Secondary User
		public void addNewUser(String emailid1)
		{
			objUserMyAccountPage.addNewUser(emailid1);
		}
		
		//Test to verify the Edit Rights 
		public void verifyEditRights()
		{
			Assert.assertEquals(true,objUserMyAccountPage.verifyEditRights());
		}
		
		//Test to verify the Connect Request
		public void verifyConnectRequest()
		{
			Assert.assertEquals(true,objUserMyAccountPage.verifyConnectRequest());
		}
		
		//Test to click the Connect Recipient
		public void clickConnectRecipient()
		{
			objUserMyAccountPage.clickConnectRecipient();
		}
		
		//Test to delete the Secondary user/users
		public void deleteUser()
		{
			objUserMyAccountPage.deleteUser();
		}
		
		
		
		
		
		
		
		
		
}
