package com.dnb.automation.bd.steps;

import java.sql.SQLException;

import net.thucydides.core.annotations.Steps;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import com.dnb.automation.bd.tests.UserMyAccountCompProfileTest;
import com.dnb.automation.bd.tests.UserMyAccountPageTest;

public class UserMyAccountCompProfileSteps {
	
	@Steps
	UserMyAccountCompProfileTest objUserMyAccountCompProfileTest;
	
	@Then("BD:The Profile <DunsNo> Edit button should be enabled")
	public void callIsProfileEditButtonEnabled(@Named("DunsNo")String dunsNo) throws SQLException
	{
		objUserMyAccountCompProfileTest.isProfileEditButtonEnabled(dunsNo);
	}

	@When("BD:I select the profile <DunsNo> and click on Edit button")
	public void callSelectProfileAndEdit(@Named("DunsNo")String dunsNo) throws SQLException
	{
		objUserMyAccountCompProfileTest.selectProfileAndEdit(dunsNo);
	}

}
