package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedFinancialsCir9719 - This program calls serenity
 * story file
 *
 * @author Rajesh G
 ***********************************************************************************************/

public class DetailedFinancialsCir9719 extends SerenityStory{

}
