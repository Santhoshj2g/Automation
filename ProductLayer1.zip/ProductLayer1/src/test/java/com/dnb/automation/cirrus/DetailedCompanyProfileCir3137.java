package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedCompanyProfileCir3137 - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/
public class DetailedCompanyProfileCir3137 extends SerenityStory{

}
