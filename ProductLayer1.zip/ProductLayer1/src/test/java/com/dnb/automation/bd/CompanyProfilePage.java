package com.dnb.automation.bd;
import net.serenitybdd.jbehave.SerenityStory;

public class CompanyProfilePage extends SerenityStory {

}
