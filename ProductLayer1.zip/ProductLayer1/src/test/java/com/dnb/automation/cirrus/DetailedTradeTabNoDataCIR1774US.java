package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedTradeTabNoDataCIR1774US - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/
public class DetailedTradeTabNoDataCIR1774US extends SerenityStory{

}
