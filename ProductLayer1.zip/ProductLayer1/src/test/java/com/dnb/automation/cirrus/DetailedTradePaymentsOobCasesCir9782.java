package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class DetailedTradePaymentsOobCasesCir9782 extends SerenityStory {

}
