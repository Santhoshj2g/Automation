package com.dnb.automation.bd;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.jbehave.core.io.CodeLocations;
import org.jbehave.core.io.StoryFinder;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import net.serenitybdd.jbehave.SerenityStories;

/**********************************************************************************************
 * Function : Invokes serenity story files
 * 
 *
 ***********************************************************************************************/

public class BD_SanityTest1 extends SerenityStories {
	
	private static Set<String> storyPaths = Sets.newHashSet();

	static{	
	storyPaths.add("**/verify_search_profile.story");	
	storyPaths.add("**/quick_links_adminusr_home_page.story");
	storyPaths.add("**/quick_links_companyusr_home_page.story");
	storyPaths.add("**/narrowresults_searchresults_screen.story");	
	}
	
	@Override
	public List<String> storyPaths() {
       return new StoryFinder().findPaths(CodeLocations.codeLocationFromClass(
                       this.getClass()), 
                       Lists.newArrayList(storyPaths), 
                       Arrays.asList(""));

    }
}
