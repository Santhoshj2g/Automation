package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * CirrusHomeCir5932 - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class CirrusHomeCir5932AndCir4940 extends SerenityStory{

}
