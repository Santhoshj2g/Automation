package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedLegalTabCIR2134CA - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class DetailedLegalTabCIR2134CA extends SerenityStory{

}
