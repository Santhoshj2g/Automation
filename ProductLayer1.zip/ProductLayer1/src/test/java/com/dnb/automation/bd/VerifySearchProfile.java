package com.dnb.automation.bd;
import net.serenitybdd.jbehave.SerenityStory;
/**********************************************************************************************
 * Function : Invokes serenity story file verify_search_results.story
 * 
 *
 ***********************************************************************************************/
public class VerifySearchProfile extends SerenityStory {
	
	
	
}
