package com.dnb.automation.bd.steps;

import java.sql.SQLException;

import net.thucydides.core.annotations.Steps;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.When;
import org.jbehave.core.annotations.Then;

import com.dnb.automation.bd.tests.BDRegistrationTest;
import com.dnb.automation.bd.tests.DataBaseTest;

/**********************************************************************************************
 * Steps to launch application and Register new user
 * 
 ***********************************************************************************************/

public class BDRegistrationSteps {
	
	@Steps
	BDRegistrationTest objBDRegistrationTest;
	@Steps
	DataBaseTest objDataBaseTest;
	
	@When("BD:I click on Register link")
	public void callClickRegisterLink()
	{
		objBDRegistrationTest.ClickRegisterLink();;
	}
	@Then("BD:Registration Page should be displayed")
	public void callRegistrationScreen()
	{
		objBDRegistrationTest.verifyRegistrationScreen();
	}
	@When("BD:I fill the registration form fields with Valid email id required as <EmailId>,Prefix as <Prefix>,First Name as <FirstName>,Last Name as <LastName>,Country Code as <CountryCode>,Area Code as <AreaCode>,Phone Number as <PhoneNum>,Ext Number as <EXtnum>,Country as <Country>,Company website as <CompWebsite>")
	public void callFillRegistrationForm(@Named("EmailId") String emailid,@Named("Prefix") String prefix,@Named("FirstName") String firstName,@Named("LastName") String lastName,@Named("CountryCode") String countryCode,@Named("AreaCode") String areaCode,@Named("PhoneNum") String phoneNum,@Named("EXtnum") String extnum,@Named("Country") String country,@Named("CompWebsite") String compwebsite)
	{
		objBDRegistrationTest.FillRegistrationForm(emailid,prefix,firstName,lastName,countryCode,areaCode,phoneNum,extnum,country,compwebsite);
	}
	@When("BD:I click on Terms and Condition link text")
	public void callClickTermsAndConditon()
	{
		objBDRegistrationTest.ClickTermsAndConditon();
	}
	@Then("BD:Terms and Condition popup should be displayed")
	public void callTermsAndConditonPopupAppeared()
	{
		objBDRegistrationTest.verifyTermsAndConditonPopupAppeared();
	}
	@When("BD:I click on Agree button")
	public void callClickAgree()
	{
		objBDRegistrationTest.ClickAgree();
	}
	@Then("BD:Terms and Condition popup should be disappeared")
	public void callTermsAndConditonPopupDissAppeared()
	{
		objBDRegistrationTest.verifyTermsAndConditonPopupDissAppeared();
	}

	@When("BD:I click on Register button")
	public void callClickRegister()
	{
		objBDRegistrationTest.ClickRegister();
	}
	@Then("BD:User registration success Message should be displayed")
	public void callRegSucessMsgAppeared()
	{
		objBDRegistrationTest.verifyRegSucessMsgAppeared();
	}
	
	@Then("BD:The User <EmailId> registration status shoulb be pending in the database")
	public void callVerifyUserPendingStatusDB(@Named("EmailId") String emaildid) throws SQLException
	{
		objDataBaseTest.VerifyUserPendingStatusDB(emaildid);
	}

}
