package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedLegalTabCIR5483US - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class DetailedLegalTabCIR5483US extends SerenityStory{

}
