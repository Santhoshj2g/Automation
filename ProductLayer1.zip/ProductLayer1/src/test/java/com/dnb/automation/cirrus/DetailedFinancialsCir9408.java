package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedFinancialsCir9408 - This program calls serenity
 * story file
 *
 * @author Rajesh G
 ***********************************************************************************************/

public class DetailedFinancialsCir9408 extends SerenityStory{

}
