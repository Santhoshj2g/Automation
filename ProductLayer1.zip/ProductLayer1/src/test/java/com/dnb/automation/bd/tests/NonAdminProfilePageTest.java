package com.dnb.automation.bd.tests;

import org.junit.Assert;

import com.dnb.automation.bd.pages.LoginPage;
import com.dnb.automation.bd.pages.NonAdminProfilePage;
import com.dnb.automation.bd.steps.NonAdminProfilePageSteps;

import net.thucydides.core.steps.ScenarioSteps;

public class NonAdminProfilePageTest extends NonAdminProfilePageSteps {

	NonAdminProfilePage objNonAdminProfilePage;

//Test to Click on Cliam profile button
	public void claimProfile()
	{
		Assert.assertEquals(true,objNonAdminProfilePage.clickProfileClaimButton());
	}

//Test to Click on Connect with Me button.
	public void connectProfile()
	{
		Assert.assertEquals(true,objNonAdminProfilePage.setProfileConnectWithMeButton());
		
	}
	
//Test to Verify the Thank you message is displayed after cliaming the profile	
	public void verifyClaimThankyouMessage()
	{
		Assert.assertEquals(true,objNonAdminProfilePage.ClaimThankyouMessage());
	}

//Test to Verify the Thank you message is displayed after Connecting the profile	
	public void verifyConnectThankyouMessage()
	{
		Assert.assertEquals(true,objNonAdminProfilePage.getConnectThankyouMessage());
	}

//Test to Verify the profile has been cliamed	
	public void verifyProfileClaimed()
	{
		Assert.assertEquals(true,objNonAdminProfilePage.getProfileClaimedVisibility());
	}

//Test to Verify the profile cliam button is displayed in the profile page	
	public void verifyProfileClaim()
	{
		Assert.assertEquals(true,objNonAdminProfilePage.getProfileClaimVisibility());
	}

}
