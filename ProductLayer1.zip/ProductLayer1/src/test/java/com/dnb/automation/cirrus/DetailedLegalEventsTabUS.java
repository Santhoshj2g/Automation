package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedLegalEventsTabUS - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/


public class DetailedLegalEventsTabUS extends SerenityStory{

}
