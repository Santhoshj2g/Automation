package com.dnb.automation.bd.steps;

import java.sql.SQLException;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import net.thucydides.core.annotations.Steps;

import com.dnb.automation.bd.tests.UserEditProfilePageTest;
import com.dnb.automation.bd.tests.UserMyAccountCompProfileTest;
import com.dnb.automation.bd.tests.UserMyAccountPageTest;

public class UserEditProfilePageSteps {
	
	@Steps
	UserEditProfilePageTest objUserEditProfilePageTest; 

	@Then("BD:Profile <DunsNo> should be opened in Edit mode")
	public void callIsProfileEditMode(@Named("DunsNo")String dunsNo) throws SQLException
	{
		objUserEditProfilePageTest.isProfileEditMode(dunsNo);
	}
	
	@When("BD:Select the Company-info tab")
	public void selectCompanyInfoTab()
	{
		objUserEditProfilePageTest.selectCompanyInfoTab();
	}	
	
	@When("BD:Update the Company-info With <CompanyInfo>")
	public void setCompanyInfo(@Named("CompanyInfo")String CompanyInfo)
	{
		objUserEditProfilePageTest.setCompanyInfo(CompanyInfo);
	}

	@When("BD:Select the Corporate Information tab")
	public void selectCorporateInfoTab()
	{
		objUserEditProfilePageTest.selectCorporateInfoTab();
	}

	@When("BD:Select the Registration Information / Line of business tab")
	public void selectRegInfoTab()
	{
		objUserEditProfilePageTest.selectRegInfoTab();
	}

	@When("BD:Select the KeyEmployees tab")
	public void selectKeyEmpTab()
	{
		objUserEditProfilePageTest.selectKeyEmpTab();
	}
	
	@When("BD:Update the Corporate Information with Phone number <PhoneType><ISDCode><PhoneNum>")
	public void setCorporateInfoWithPhoneNum(@Named("PhoneType")String PhoneType,@Named("ISDCode")String ISDCode,@Named("PhoneNum")String PhoneNum)
	{
		objUserEditProfilePageTest.setCorporateInfoWithPhoneNum(PhoneType,ISDCode,PhoneNum);
	}
	
	@When("BD:Update the Registration Information with Sic code<SicCode>")
	public void setSicCode(@Named("SicCode")String SicCode)
	{
		objUserEditProfilePageTest.setSicCode(SicCode);
	}

	@When("BD:Update the Employee details in Key Employee section <EmpTitle><EmpFirstName><EmpMiddleName><EmpLastName><EmpJobTitle>")
	public void setEmpDetails(@Named("EmpTitle")String EmpTitle,@Named("EmpFirstName")String EmpFirstName,@Named("EmpMiddleName")String EmpMiddleName,@Named("EmpLastName")String EmpLastName,@Named("EmpJobTitle")String EmpJobTitle)
	{
		objUserEditProfilePageTest.setEmpDetails(EmpTitle,EmpFirstName,EmpMiddleName,EmpLastName,EmpJobTitle);
	}

	@When("BD:Select the Business Information tab")
	public void selectBusinessInfoTab()
	{
		objUserEditProfilePageTest.selectBusinessInfoTab();
	}
	
	@When("BD:Update the Linkage Information <LinkageType> <LinkageDes> in Bussiness Information section")
	public void setLinkageInfo(@Named("LinkageType")String LinkageType,@Named("LinkageDes")String LinkageDes)
	{
		objUserEditProfilePageTest.setLinkageInfo(LinkageType,LinkageDes);
	}

	@When("BD:Select the Products and Brands tab")
	public void selectProductsAndBrandsTab()
	{
		objUserEditProfilePageTest.selectProductsAndBrandsTab();
	}
	
	@When("BD:Update the UNSPSC code  <UNSPSC> in Products and Brands section")
	public void setUNSPSCCode(@Named("UNSPSC")String UNSPSC)
	{
		objUserEditProfilePageTest.setUNSPSCCode(UNSPSC);
	}
	
	@When("BD:I click on Submit for Approval button")
	public void clickSubmitApproval()
	{
		objUserEditProfilePageTest.clickSubmitApproval();
	}
	
	@Then("BD:your updates have been saved successfuly message Should be displayed")
	public void verifyIsSubmitConfirmationDisp()
	{
		objUserEditProfilePageTest.isSubmitConfirmationDisp();
	}
}
