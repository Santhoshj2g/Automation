package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedOwnershipCir951 - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/
public class DetailedOwnershipCir951 extends SerenityStory{

}
