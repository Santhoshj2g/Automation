package com.dnb.automation.bd.steps;

import net.thucydides.core.annotations.Steps;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import com.dnb.automation.bd.tests.GetDunsRegisteredTest;

public class GetDunsRegisteredSteps {
	
	@Steps
	GetDunsRegisteredTest objGetDunsRegisteredTest;

	@When("BD:I select Prefix <Prefix>")
	public void selectPrefix(@Named("Prefix") String Prefix) {
		objGetDunsRegisteredTest.selectPrefix(Prefix);
	}

	@When("BD:I give First Name <FirstName>")
	public void giveFirstName(@Named("FirstName") String FirstName) {
		objGetDunsRegisteredTest.giveFirstName(FirstName);
	}
	@When("BD:I give Last Name <LastName>")
	public void giveLastName(@Named("LastName") String LastName) {
		objGetDunsRegisteredTest.giveLastName(LastName);
	}
	
	@When ("BD:I give Business Name <BusinessName>")
	public void giveBusinessName(@Named("BusinessName") String BusinessName) {
		objGetDunsRegisteredTest.giveBusinessName(BusinessName);
	}
	
	@When ("BD:I give Email <Email>")
	public void giveEmail(@Named("Email") String Email) {
		objGetDunsRegisteredTest.giveEmail(Email);
	}
	
	@When ("BD:I give Country Code <CountryCode>")
	public void giveCountryCode(@Named("CountryCode") String CountryCode) {
		objGetDunsRegisteredTest.giveCountryCode(CountryCode);
	}
	
	@When ("BD:I give Area Code <AreaCode>")
	public void giveAreaCode(@Named("AreaCode") String AreaCode) {
		objGetDunsRegisteredTest.giveAreaCode(AreaCode);
	}
	
	@When ("BD:I give Phone Number <PhoneNumber>")
	public void givePhoneNumber(@Named("PhoneNumber") String PhoneNumber) {
		objGetDunsRegisteredTest.givePhoneNumber(PhoneNumber);
	}
	
	@When ("BD:I give telExt <ext>")
	public void givetelExt(@Named("ext") String ext) {
		objGetDunsRegisteredTest.givetelExt(ext);
	}
	
	@When ("BD:I give Business Address <BusinessAddress>")
	public void giveBusinessAddress(@Named("BusinessAddress") String BusinessAddress) {
		objGetDunsRegisteredTest.giveBusinessAddress(BusinessAddress);
	}
	
	@When ("BD:I select Country <Country>")
	public void giveCountry(@Named("Country") String Country) {
		objGetDunsRegisteredTest.giveCountry(Country);
	}
	
	@When ("BD:I give Company Website URL <WebsiteURL>")
	public void giveWebsiteURL(@Named("WebsiteURL") String WebsiteURL) {
		objGetDunsRegisteredTest.giveWebsiteURL(WebsiteURL);
	}
	@When ("BD:I click on Submit button to submit the get duns registered")
	public void clickSubmitButton() {
		objGetDunsRegisteredTest.clickSubmitButton();
	}
	
	@Then ("BD:It should display the success message")
	public void successMessage() {
		objGetDunsRegisteredTest.successMessage();
	}
	@Then ("BD:BacktoHome link should displayed")
	public void backtoHomeLink() {
		objGetDunsRegisteredTest.backtoHomeLink();
	}

	
}
