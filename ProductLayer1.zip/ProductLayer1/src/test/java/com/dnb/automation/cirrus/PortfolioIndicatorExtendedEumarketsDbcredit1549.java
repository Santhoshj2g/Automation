package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class PortfolioIndicatorExtendedEumarketsDbcredit1549 extends SerenityStory {

}
