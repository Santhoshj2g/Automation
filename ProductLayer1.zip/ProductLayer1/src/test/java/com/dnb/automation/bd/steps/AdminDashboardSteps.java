package com.dnb.automation.bd.steps;

import java.sql.SQLException;

import net.thucydides.core.annotations.Steps;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import com.dnb.automation.bd.tests.AdminDashboardTest;

public class AdminDashboardSteps {
	
	@Steps
	AdminDashboardTest objAdminDashboardTest;
	
	@Given("BD:I select profile claim tab")
	public void callProfileClaimTab()
	{
		objAdminDashboardTest.ProfileClaimTab();
	}

	@When("BD:I select User Registration tab")
	public void callUserRegistrationTab()
	{
		objAdminDashboardTest.userRegistrationTab();
	}
	
	@When("BD:I search claim request by company name<DunsNo>")
	public void callSearchClaimByCompany(@Named("DunsNo")String dunsNo) throws InterruptedException, SQLException
	{
		objAdminDashboardTest.searchClaimByCompany(dunsNo);
	}

	@When("BD:I search user registration by user emailid<EmailId>")
	public void callSarchUserRegistration(@Named("EmailId") String EmailId)
	{
		objAdminDashboardTest.searchUserRegistrationByEmailId(EmailId);
	}
	
	@When("BD:I click on reject button")
	public void callRejectClaim()
	{
		objAdminDashboardTest.rejectTheClaimRequest();
	}

	@When("BD:I click on approve button")
	public void callApproveClaim()
	{
		objAdminDashboardTest.approveTheClaimRequest();
	}
	
	@When("BD:I click on Approve confirmation ok button")
	public void callAccepttApproveConfirmation()
	{
		objAdminDashboardTest.acceptApproveConfirmation();
	}

	@When("BD:I click on reject confirmation ok button")
	public void callAccepttRejectConfirmation()
	{
		objAdminDashboardTest.acceptRejectConfirmation();
	}
	
	@Then("BD:The Profile<DunsNo> claim status should be pending")
	public void callVerifyClaimedProfileStatusPending()
	{
		objAdminDashboardTest.verifyClaimedProfileStatusPending();
	}

	@Then("BD:The user emailid <EmailId> activation status should be pending")
	public void callVerifyRegUserStatusPending()
	{
		objAdminDashboardTest.verifyRegUserStatusPending();
	}
	@Then("BD:Approve confirmation should be displayed")
	public void callVerifyApproveConfimation()
	{
		objAdminDashboardTest.VerifyApproveConfirmation();
	}
	
	@Then("BD:Reject confirmation should be displayed")
	public void callVerifyRejectConfimation()
	{
		objAdminDashboardTest.VerifyRejectConfirmation();
	}

	@Then("BD:Claim Approve successmessage should be displayed")
	public void callVerifyApproveSuccessMessage()
	{
		objAdminDashboardTest.VerifyApproveSuccessMessage();
	}

	@Then("BD:Claim Reject successmessage should be displayed")
	public void callVerifyRejectSuccessMessage()
	{
		objAdminDashboardTest.VerifyRejectSuccessMessage();
	}
	
	@When("BD:I Select ProfileEdits Tab")
	public void callSelectProfileEditsTab()
	{
		objAdminDashboardTest.SelectProfileEditsTab();
	}
	
	@Then("BD:Profile editlist should displayed")
	public void callIsProfileEditListDisplayed()
	{
		objAdminDashboardTest.isProfileEditListDisplayed();
	}
	
	@When("BD:I search the profile <DunsNo> edit request")
	public void callSearchProfileEditReq(@Named("DunsNo") String DunsNo) throws SQLException
	{
		objAdminDashboardTest.SearchProfileEditReq(DunsNo);
	}

	@Then("BD:The Profile <DunsNo> edit status should be pending")
	public void callVerifyEditedProfileStatusPending()
	{
		objAdminDashboardTest.verifyEditedProfileStatusPending();
	}

	@Then("BD:Profile <DunsNo> should be opened in Edit mode for Approve/Reject")
	public void callIsProfileEditModeForApproveReject(@Named("DunsNo")String dunsNo) throws SQLException
	{
		objAdminDashboardTest.isProfileEditModeForApproveReject(dunsNo);
	}
	
	@When("BD:I select the profile <DunsNo> to Approve/Reject the changes")
	public void callSelectTheProfileFromEditList()
	{
		objAdminDashboardTest.selectTheProfileFromEditList();
	}
	
	@When("BD:Reject the changes in Company-info tab")
	public void callRejectCompanyInfoChages()
	{
		objAdminDashboardTest.rejectCompanyInfoChages();
	}

	@When("BD:Approve the changes in Company-info tab")
	public void callApproveCompanyInfoChages()
	{
		objAdminDashboardTest.approveCompanyInfoChages();
	}

	@When("BD:Reject the Phone number changes in Corporate Information tab")
	public void callRejectCorporateInfoChanges()
	{
		objAdminDashboardTest.rejectCorporateInfoChanges();
	}

	@When("BD:Approve the Phone number changes in Corporate Information tab")
	public void callApproveCorporateInfoChanges()
	{
		objAdminDashboardTest.approveCorporateInfoChanges();
	}
	
	@When("BD:Reject the changes in KeyEmployees tab")
	public void callRejectKeyEmployeeChanges()
	{
		objAdminDashboardTest.rejectKeyEmployeeChanges();
	}

	@When("BD:Approve the changes in KeyEmployees tab")
	public void callApproveKeyEmployeeChanges()
	{
		objAdminDashboardTest.approveKeyEmployeeChanges();
	}
	
	@When("BD:Reject the changes in Business Information tab")
	public void callRejectBusinessInfoChanges()
	{
		objAdminDashboardTest.rejectBusinessInfoChanges();
	}

	@When("BD:Approve the changes in Business Information tab")
	public void callApproveBusinessInfoChanges()
	{
		objAdminDashboardTest.approveBusinessInfoChanges();
	}
	
	@When("BD:I click on Submit button")
	public void callClickSubmit()
	{
		objAdminDashboardTest.clickSubmit();
	}
	
	@Then("BD:User should be navigated to User Registration tab")
	public void verifyIsUserRegistrationTabSelected()
	{
		objAdminDashboardTest.isUserRegistrationTabSelected();
	}
}
