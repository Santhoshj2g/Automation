package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class DetailedTradePaymentsUkIeBeneluxDbcredit1101 extends SerenityStory{

}
