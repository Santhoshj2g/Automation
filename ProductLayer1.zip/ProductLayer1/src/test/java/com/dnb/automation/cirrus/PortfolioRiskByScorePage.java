package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * ReportSummary - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/
public class PortfolioRiskByScorePage extends SerenityStory {

}
