package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedOwnershipCir2585Ca - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class DetailedOwnershipCir2585Ca extends SerenityStory{

}
