package com.dnb.automation.bd.tests;

import org.junit.Assert;

import com.dnb.automation.bd.pages.LogoutPage;

public class LogoutPageTest {
	LogoutPage objLogoutpage;
	
// Test to click on logout button
	public void logout()
	{
		Assert.assertEquals(true,objLogoutpage.logout());
	}


}
