package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;
/**********************************************************************************************
 * PortfolioFilterCompanylist - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class PortfolioFilterCompanylist extends SerenityStory{

}
