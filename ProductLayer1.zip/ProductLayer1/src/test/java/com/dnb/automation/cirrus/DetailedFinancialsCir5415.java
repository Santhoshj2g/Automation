package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedFinancialsCir5415 - This program calls serenity
 * story file
 *
 * @author Rajesh G
 ***********************************************************************************************/

public class DetailedFinancialsCir5415 extends SerenityStory{

}
