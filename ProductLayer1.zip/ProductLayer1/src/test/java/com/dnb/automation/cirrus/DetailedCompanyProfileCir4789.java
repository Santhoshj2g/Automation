package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedCompanyProfileCir4789 - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/
public class DetailedCompanyProfileCir4789 extends SerenityStory{

}
