package com.dnb.automation.bd.tests;

import static org.hamcrest.MatcherAssert.assertThat;

import org.hamcrest.Matchers;
import org.junit.Assert;

import com.dnb.automation.bd.pages.LoginPage;

import net.thucydides.core.steps.ScenarioSteps;


/**********************************************************************************************
 * Description : Class to test login page of GD
 * 
 ***********************************************************************************************/
public class LoginPageTest extends ScenarioSteps {

	LoginPage loginPg;

    // Test to launch application
    public void launchApplication(String appURL) throws Exception {
    	Assert.assertEquals(true,loginPg.getURLAndLaunchApplication(appURL));
    }
    
    // Test to click on login button
    public void login()
    {
    	Assert.assertEquals(true,loginPg.login());
    }

    // Test to login into GD application
    public void appLogin(String userName, String password) throws Exception {
        loginPg.login(userName, password);
    }

    // Test to verify whether user is in home page of GD application
    public void verifyUserInHomePage() throws Exception {
        assertThat(loginPg.userInHomePage(), Matchers.equalTo(true));
    }
    
    //Test to click on home tab
    public void clickOnHomeTabTest()
    {
    	loginPg.clickOnHomeTab();
    } 
}