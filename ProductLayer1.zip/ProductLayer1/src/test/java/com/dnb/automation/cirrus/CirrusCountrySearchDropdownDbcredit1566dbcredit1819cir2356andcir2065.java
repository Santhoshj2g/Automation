package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class CirrusCountrySearchDropdownDbcredit1566dbcredit1819cir2356andcir2065 extends SerenityStory {
	
	

}
