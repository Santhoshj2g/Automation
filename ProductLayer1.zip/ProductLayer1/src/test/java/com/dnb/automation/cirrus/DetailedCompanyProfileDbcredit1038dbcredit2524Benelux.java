package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedCompanyProfileDbcredit1038dbcredit2524Benelux - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/
public class DetailedCompanyProfileDbcredit1038dbcredit2524Benelux extends SerenityStory{

}
