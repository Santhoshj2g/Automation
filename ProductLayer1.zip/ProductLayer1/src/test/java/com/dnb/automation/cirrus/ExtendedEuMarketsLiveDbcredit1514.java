package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class ExtendedEuMarketsLiveDbcredit1514 extends SerenityStory {

}
