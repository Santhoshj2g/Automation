package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedFinancialsDbcredit1005 - This program calls serenity story file
 *
 * @author Rajesh
 ***********************************************************************************************/

public class DetailedFinancialsDbcredit1004Dbcredit1994 extends SerenityStory{

}
