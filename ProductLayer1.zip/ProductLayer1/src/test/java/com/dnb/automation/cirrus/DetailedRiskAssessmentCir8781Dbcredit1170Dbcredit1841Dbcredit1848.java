package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedRiskAssessmentCir8781 - This program calls serenity
 * story file
 *
 * @author Rajesh G
 ***********************************************************************************************/

public class DetailedRiskAssessmentCir8781Dbcredit1170Dbcredit1841Dbcredit1848 extends SerenityStory{

}
