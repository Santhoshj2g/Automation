package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedLegalTabCIR2300CA - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class DetailedLegalTabCIR2300CA extends SerenityStory{

}
