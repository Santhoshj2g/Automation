package com.dnb.automation.bd;

import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * Function : Invokes serenity story file profile_connect_reject_approve.story
 * 
 *
 ***********************************************************************************************/
public class ProfileConnectRejectApprove extends SerenityStory {

}
