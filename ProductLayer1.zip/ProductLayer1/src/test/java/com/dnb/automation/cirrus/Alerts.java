package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * Alerts - This program calls serenity story file
 *
 * @author Rajesh G
 ***********************************************************************************************/
public class Alerts extends SerenityStory{

}