package com.dnb.automation.bd.tests;

import java.sql.SQLException;

import net.thucydides.core.steps.ScenarioSteps;

import org.junit.Assert;

import com.dnb.automation.bd.pages.DBConnectionPage;
import com.dnb.automation.bd.pages.UserEditProfilePage;
import com.dnb.automation.bd.pages.UserMyAccountCompProfilePage;

public class UserEditProfilePageTest extends ScenarioSteps
{
	UserEditProfilePage objUserEditProfilePage;
	DBConnectionPage objDBConnectionPage;

//Test to verify that the profile is opened in edit mode.	
		public void isProfileEditMode(String dunsNo) throws SQLException {
			String dbProfileName = objDBConnectionPage.getProfileName(dunsNo);		
			String uiProfileName = objUserEditProfilePage.isProfileEditMode();
			String editProfileName = dunsNo+" - "+dbProfileName;
//			Assert.assertEquals(editProfileName,uiProfileName);
			Assert.assertTrue(editProfileName.equalsIgnoreCase(uiProfileName));
		}

//Test to select the company info tab in profile edit page.	
		public void selectCompanyInfoTab() {				
			Assert.assertEquals(true,objUserEditProfilePage.selectCompanyInfoTab());	
		}
//Test to update the company info in profile edit page
		public void setCompanyInfo(String CompanyInfo) {
			objUserEditProfilePage.setCompanyInfo(CompanyInfo);			
		}

//Test to select the Corporate info tab in profile edit page.		
		public void selectCorporateInfoTab() {
			Assert.assertEquals(true,objUserEditProfilePage.selectCorporateInfoTab());		
		}
//Test to update the Corporate info with phone number
		public void setCorporateInfoWithPhoneNum(String phoneType,String iSDCode, String phoneNum) {
			objUserEditProfilePage.setCorporateInfoWithPhoneNum(phoneType,iSDCode, phoneNum);
		}

//Test to select the Registration information / line of business tab		
		public void selectRegInfoTab() {
			Assert.assertEquals(true,objUserEditProfilePage.selectRegInfoTab());				
		}

//Test to add the sic code Reg info line of business tab		
		public void setSicCode(String sicCode) {
			objUserEditProfilePage.setSicCode(sicCode);
		}

//Test to select the KeyEmployee tab		
		public void selectKeyEmpTab() {
			Assert.assertEquals(true,objUserEditProfilePage.selectKeyEmpTab());			
		}

//Test to update the employee details 		
		public void setEmpDetails(String EmpTitle,String empFirstName, String empMiddleName,
				String empLastName, String empJobTitle) {
			objUserEditProfilePage.setEmpDetails(EmpTitle,empFirstName,empMiddleName,empLastName,empJobTitle);
			
		}

//Test to select the business information tab in the profile edit page		
		public void selectBusinessInfoTab() {
			 Assert.assertEquals(true,objUserEditProfilePage.selectBusinessInfoTab());	
			
		}

//Test to update the Linkage information in Business Information tab		
		public void setLinkageInfo(String linkageType, String linkageDes) {
			objUserEditProfilePage.setLinkageInfo(linkageType,linkageDes);
			
		}

//Test to Select the Products and Brands tab 		
		public void selectProductsAndBrandsTab() {
			Assert.assertEquals(true,objUserEditProfilePage.selectProductsAndBrandsTab());					
		}

//Test to add the unspsc code Product and Brands tab		
		public void setUNSPSCCode(String uNSPSC) {
			 objUserEditProfilePage.setUNSPSCCode(uNSPSC);
			
		}

//Test to click on Submit for Approval button in profile edit page.		
		public void clickSubmitApproval() {
			objUserEditProfilePage.clickSubmitApproval();			
		}

//Test to verify that is the edit profile submitted successfully		
		public void isSubmitConfirmationDisp() {
			objUserEditProfilePage.isSubmitConfirmationDisp();
			
		}

}
