package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedLegalTabCIR2134US - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class DetailedLegalTabCIR2134US extends SerenityStory{

}
