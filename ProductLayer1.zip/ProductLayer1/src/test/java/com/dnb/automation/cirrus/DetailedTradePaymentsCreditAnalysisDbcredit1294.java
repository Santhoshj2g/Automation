package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class DetailedTradePaymentsCreditAnalysisDbcredit1294 extends SerenityStory{

}
