package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;
/**********************************************************************************************
 * DetailedTradePaymentsUS - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/


public class DetailedTradePaymentsUS  extends SerenityStory {

}
