package com.dnb.automation.bd.tests;

import org.junit.Assert;

import net.thucydides.core.steps.ScenarioSteps;

import com.dnb.automation.bd.pages.GetDunsRegisteredPages;

public class GetDunsRegisteredTest extends ScenarioSteps  {
	
	
	GetDunsRegisteredPages objGetDunsRegisteredPages;

//Test to selec the prefix	
	public void selectPrefix(String Prefix) {
		
		objGetDunsRegisteredPages.selectPrefix(Prefix);
	}
//Test to enter the first name	
	public void giveFirstName(String firstName) {
		
		objGetDunsRegisteredPages.giveFirstName(firstName);
	}
	//Test to enter the Last name		
	public void giveLastName(String lastName) {
		
		objGetDunsRegisteredPages.giveLastName(lastName);	
	}
	//Test to enter the BusinessName	
	public void giveBusinessName(String businessName) {
		
		objGetDunsRegisteredPages.giveBusinessName(businessName);	
	}
	//Test to enter the Email	
	public void giveEmail(String email) {
				
		objGetDunsRegisteredPages.giveEmail(email);
		
	}
	//Test to enter the CountryCode	
	public void giveCountryCode(String countryCode) {
		
		objGetDunsRegisteredPages.giveCountryCode(countryCode);	
	}
	
	//Test to enter the AreaCode	
	public void giveAreaCode(String areaCode) {
		
		objGetDunsRegisteredPages.giveAreaCode(areaCode);	
	}
	//Test to enter the PhoneNumber	
	public void givePhoneNumber(String phoneNumber) {
		
		objGetDunsRegisteredPages.givePhoneNumber(phoneNumber);	
	}
	//Test to enter the ExtPhoneNumber	
	public void givetelExt(String ext) {
		
		objGetDunsRegisteredPages.givetelExt(ext);	
	}
	//Test to enter the BusinessAddress	
	public void giveBusinessAddress(String businessAddress) {
		
		objGetDunsRegisteredPages.giveBusinessAddress(businessAddress);
	}
	//Test to enter the CountryCode	
	public void giveCountry(String country) {
		
		objGetDunsRegisteredPages.giveCountry(country);	
	}
	//Test to enter the WebsiteURL	
	public void giveWebsiteURL(String websiteURL) {
		
		objGetDunsRegisteredPages.giveWebsiteURL(websiteURL);		
	}
	//Test to click SubmitButton	
	public void clickSubmitButton() {
		
		objGetDunsRegisteredPages.clickSubmitButton();	
	}
	//Test to Verify SuccessMessage	
	public void successMessage() {
		
		Assert.assertTrue(objGetDunsRegisteredPages.successMessage());
	}
	//Test to Verify backtoHome Link
	public void backtoHomeLink() {
		
		Assert.assertTrue(objGetDunsRegisteredPages.backtoHomeLink());	
	}

	
}
