package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class AdvancedSearchBusinessStatusCir1027 extends SerenityStory{

}
