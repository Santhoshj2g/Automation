package com.dnb.automation.bd.steps;

import java.sql.SQLException;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import net.thucydides.core.annotations.Steps;

import com.dnb.automation.bd.tests.ProfileAnalyticsTest;

public class ProfileAnalyticsSteps {
	
	@Steps
	ProfileAnalyticsTest objProfileAnalyticsTest;	  
	
	@Then("BD:Page should display Profile Analytics tab")
	public void verifyProfileAnalyticsTab()throws Exception
	{
		objProfileAnalyticsTest.verifyProfileAnalyticsTab();
	}	
	@Then("BD:Page should display Company Name field under Profile Analytics tab")
	public void verifyCompanyNameFld()throws Exception
	{
		objProfileAnalyticsTest.verifyCompanyNameFld();
	}
	@Then("BD:Page should display Appeared in Search Results field under Profile Analytics tab")
	public void verifyAppearedinSearchRes()throws Exception
	{
		objProfileAnalyticsTest.verifyAppearedinSearchRes();
	}	
	@Then("BD:Page should display Clicked From Search results field under Profile Analytics tab")
	public void verifyClickedFromSearchRes()throws Exception
	{
		objProfileAnalyticsTest.verifyClickedFromSearchRes();
	}
	@Then("BD:Page should display Clicked From Advertisements field under Profile Analytics tab")
	public void verifyClickedFromAd()throws Exception
	{
		objProfileAnalyticsTest.verifyClickedFromAd();
	}
	@Then("BD:Page should display ConnectCount field under Profile Analytics tab")
	public void verifyConnectCount()throws Exception
	{
		objProfileAnalyticsTest.verifyConnectCount();
	}
	@When("BD:I click on the company Name link in My Dashboard page")
	public void verifyCmpnyNameLink()throws Exception
	{
		objProfileAnalyticsTest.verifyCmpnyNameLink();
	}
	@When("BD:I get the value of Appeared in Search results")
	public void clickAppearedinSearchResval()throws Exception
	{
		objProfileAnalyticsTest.clickAppearedinSearchResval();
	}
	@When("BD:I get the value of Clicked From Search results")
	public void getClickedfromSearchResVal()throws Exception
	{
		objProfileAnalyticsTest.getClickedfromSearchResVal();
	}
	@When("BD:I get the value of Clicked From Advertisements")
	public void getClickedfromAddVal()throws Exception
	{
		objProfileAnalyticsTest.getClickedfromAddVal();
	}
	@When("BD:I get the value of Connect Count")
	public void getConnectCount()throws Exception
	{
		objProfileAnalyticsTest.getConnectCount();
	}
	@When("BD:I search for the company Name in the My Dashboard page<companyname>")
	public void serachCmpny(String companyname)throws Exception
	{
		objProfileAnalyticsTest.serachCmpny(companyname);
	}
	@Then("BD:The count in Appeared in Search results should be increased")
	public void verifyAppearedinSearchResCnt()throws Exception
	{
		objProfileAnalyticsTest.verifyAppearedinSearchResCnt();
	}
	@When("BD:I click on the My Account tab")
	public void clickMyAccTab()throws Exception
	{
		objProfileAnalyticsTest.clickMyAccTab();
	}
	@When("BD:I click on the Company Name Link<companyname>")
	public void clickCmpnyLink2(String companyname)throws Exception
	{
		objProfileAnalyticsTest.clickCmpnyLink1(companyname);
	}
	@When("BD:I click on View button<DunsNo>")
	public void clickViewBtn(String DunsNo)throws Exception
	{
		objProfileAnalyticsTest.clickViewBtn(DunsNo);
	}
	@Then("BD:The profile page should be displayed<companyname>")
	public void verifyprofilePage(String companyname)throws Exception
	{
		objProfileAnalyticsTest.verifyprofilePage(companyname);
	}
	@Then("BD:The value in Appeared Search result should not be increased")
	public void compareAppearedSearchRes()throws Exception
	{
		objProfileAnalyticsTest.compareAppearedSearchRes();
	}
	@Then("BD:The value in Clicked From Search result should not be increased")
	public void compareClickedSearchRes()throws Exception
	{
		objProfileAnalyticsTest.compareClickedSearchRes();
	}	
	@Then("BD:The Count in Appeared in Search results after company Search should be increased")
	public void getappearedresult()throws Exception
	{
		objProfileAnalyticsTest.getappearedresult();
	}
	@Then("BD:The Count in Clicked From Search results after company search should be increased")
	public void getclickedresults()throws Exception
	{
		objProfileAnalyticsTest.getclickedresults();
	}	
	@Then("BD:The Count in Connect Count should be increased")
	public void getConnectvalue()throws Exception
	{
		objProfileAnalyticsTest.getConnectvalue();
	}
	
	
}
