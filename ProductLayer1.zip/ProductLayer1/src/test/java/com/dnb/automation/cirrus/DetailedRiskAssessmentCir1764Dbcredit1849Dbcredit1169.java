package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedRiskAssessmentCir1764Dbcredit1849Dbcredit1169 - This program calls serenity
 * story file
 *
 * @author Rajesh G
 ***********************************************************************************************/

public class DetailedRiskAssessmentCir1764Dbcredit1849Dbcredit1169 extends SerenityStory{

}
