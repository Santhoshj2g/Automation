package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * CirrusLoginCir8051 - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class CirrusLoginCir8051 extends SerenityStory{

}
