package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class EntityListingServiceDataForAdditionalmarketsDbcredit2208 extends SerenityStory  {

}
