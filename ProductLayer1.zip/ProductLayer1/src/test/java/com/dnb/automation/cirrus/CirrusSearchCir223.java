package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * CirrusSearchCir223 - This program calls serenity
 * story file
 *
 * @author Rajesh G
 ***********************************************************************************************/

public class CirrusSearchCir223 extends SerenityStory{

}
