package com.dnb.automation.bd.steps;

import com.dnb.automation.bd.tests.LoginPageTest;

import net.thucydides.core.annotations.Steps;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;




/**********************************************************************************************
 * Steps to launch application and login
 * 
 ***********************************************************************************************/
public class BDLoginSteps {

    @Steps
    LoginPageTest objLoginPageTest;

    @Given("BD:I am launching application")
    public void getURL() throws Exception {
        String environment = System.getProperty("appURL");
        objLoginPageTest.launchApplication(environment);
    }
    
    // Enter URL to launch application
    @Given("BD:I am in login screen")
    public void login() throws Exception {       
        objLoginPageTest.login();
    }

    @Then("BD:Display the Home Page")
    public void callVerifyHomePage() throws Exception {
    	objLoginPageTest.verifyUserInHomePage();
    }

    // Give valid user name and password
    @When("BD:I give valid Non Drs UserName and Password")
    public void NonDrsLoginIntoApplication() throws Exception
    {
        String userName = System.getProperty("NonDrsUserName");
        String password = System.getProperty("NonDrsPassword");
        objLoginPageTest.appLogin(userName, password);
    }
        
    @When("BD:I give valid Drs UserName and Password")
    public void DrsLoginIntoApplication() throws Exception {
        String userName = System.getProperty("DrsUserName");
        String password = System.getProperty("DrsPassword");
        objLoginPageTest.appLogin(userName, password);
    }

    @When("BD:I give valid Admin UserName and Password")
    public void AdminLoginIntoApplication() throws Exception {
        String userName = System.getProperty("AdminUserName");
        String password = System.getProperty("AdminPassword");
        objLoginPageTest.appLogin(userName, password);
    }

    @When("BD:I give valid Super Admin UserName and Password")
    public void SuperAdminLoginIntoApplication() throws Exception {
        String userName = System.getProperty("SuperAdminUserName");
        String password = System.getProperty("SuperAdminPassword");
        objLoginPageTest.appLogin(userName, password);
    }

    @When("BD:I give valid UserName and Password")
    public void LoginIntoApplication() throws Exception {
        String userName = System.getProperty("UserName");
        String password = System.getProperty("Password");
        objLoginPageTest.appLogin(userName, password);
    }
    
    
    //Click on Home tab to navigate to home page
    @When("I click on Home tab")
    public void callClickOnHomeTab()
    {
    	objLoginPageTest.clickOnHomeTabTest();
    }
 
}
