package com.dnb.automation.bd.steps;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import com.dnb.automation.bd.tests.NonAdminProfilePageTest;

import net.thucydides.core.annotations.Steps;

public class NonAdminProfilePageSteps {

	@Steps
	NonAdminProfilePageTest objNonAdminProfilePageTest;
	
	@When("BD:I click on Claim profile button")
	public void callClaimProfile()
	{
		objNonAdminProfilePageTest.claimProfile();
	}

	@When("BD:I click on Connect profile button")
	public void callConnectProfile()
	{
		objNonAdminProfilePageTest.connectProfile();
	}

	@Then("BD:Claim Thank you message should display")
	public void callverifyClaimThankyouMessage()
	{
		objNonAdminProfilePageTest.verifyClaimThankyouMessage();
	}

	@Then("BD:Connect Thank you message should display")
	public void callverifyConnectThankyouMessage()
	{
		objNonAdminProfilePageTest.verifyConnectThankyouMessage();
	}
			
	@Then("BD:Profile claim should be displayed")
	public void callVerifyProfileClaim()
	{
		objNonAdminProfilePageTest.verifyProfileClaim();	
	}

	@Then("BD:Profile claim should be changed to Claimed")
	public void callProfileClaimed()
	{
		objNonAdminProfilePageTest.verifyProfileClaimed();	
	}

}
