package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * CirrusSearchCir3357 - This program calls serenity
 * story file
 *
 * @author Rajesh G
 ***********************************************************************************************/

public class CirrusSearchCir3357 extends SerenityStory{

}
