package com.dnb.automation.bd.tests;

import java.sql.SQLException;

import org.hamcrest.Matchers;
import org.junit.Assert;

import static org.hamcrest.MatcherAssert.assertThat;
import net.thucydides.core.steps.ScenarioSteps;

import com.dnb.automation.bd.pages.UserMyAccountMyDetailsPage;
import com.dnb.automation.bd.pages.BDTabsPage;
import com.dnb.automation.bd.pages.DBConnectionPage;

public class UserMyAccountMyDetailsTest extends ScenarioSteps {
	
	UserMyAccountMyDetailsPage objMyAccountPage;
	BDTabsPage objBDTabsPage;
	DBConnectionPage objDBConnectionPage;
	//Test to select a value form Prefix dropdown
	public void PrefixDropdown(String Prefix)throws Exception
	{
		objMyAccountPage.PrefixDropdown(Prefix);
	}
	//Test to update the value in FirstName field
	public void updateFirstName(String Firstname)
	{
		objMyAccountPage.updateFirstName(Firstname);
	}	
	//Test to update the value in LastName field
	public void updateLastName(String Lastname)
	{
		objMyAccountPage.updateLastName(Lastname);
	}
	//Test to update the value in Country Code field
	public void updateCountryCode(String Countrycode)
	{
		objMyAccountPage.updateCountryCode(Countrycode);		
	}
	//Test to update the value in AreaCode field
	public void updateAreaCode(String Areacode)
	{
		objMyAccountPage.updateAreaCode(Areacode);
	}
	//Test to update the value in Phone Number field
	public void updatePhoneNumber(String Phoneno)
	{
		objMyAccountPage.updatePhoneNumber(Phoneno);
	}
	//Test to update the value in Extension field
	public void updateExtension(String Extension)
	{
		objMyAccountPage.updateExtension(Extension);
	}
	//Test to update the value in CountryDDL field
	public void updateCountryDDL(String CountryDdl)
	{
		objMyAccountPage.updateCountryDDL(CountryDdl);
	}	
	//Test to update the value in Company Website field
	public void updateWebsiteUrl(String CompanyWebsite)
	{
		objMyAccountPage.updateWebsiteUrl(CompanyWebsite);
	}	
	//Test to click Save Button
	public void clickSaveBtn()
	{
		objMyAccountPage.clickSaveBtn();
	}
	//Test to validate the success Message
	public void clickMsg()
	{
		objMyAccountPage.clickMsg();
	}	
	//Test to verify the updated value in Prefix field
	public void verifyPrefix(String Prefix)
	{
		assertThat(objMyAccountPage.verifyPrefix(Prefix),Matchers.equalTo(true));
	}
	//Test to verify the updated value in FirstName field
	public void verifyFirstName(String FirstName)
	{
		assertThat(objMyAccountPage.verifyFirstName(FirstName),Matchers.equalTo(true));
	}
	//Test to verify the updated value in LastName field
	public void verifyLasttName(String LastName)
	{
		assertThat(objMyAccountPage.verifyLastName(LastName),Matchers.equalTo(true));
	}
	//Test to verify the updated value in Country Code field
	public void verifyCountryCode(String CountryCode)
	{
		assertThat(objMyAccountPage.verifyCountryCode(CountryCode),Matchers.equalTo(true));
	}
	//Test to verify the updated value in AreaCode field
	public void verifyAreaCode(String AreaCode)
	{
		assertThat(objMyAccountPage.verifyAreaCode(AreaCode),Matchers.equalTo(true));
	}	
	//Test to verify the updated value in Phone Number field
	public void verifyPhoneNo(String PhoneNo)
	{
		assertThat(objMyAccountPage.verifyPhoneNo(PhoneNo),Matchers.equalTo(true));
	}
	//Test to verify the updated value in Extension field
	public void verifyExtension(String Extension)
	{
		assertThat(objMyAccountPage.verifyExtension(Extension),Matchers.equalTo(true));
	}	
	//Test to verify the updated value in CountryDDL field
	public void verifycountryddl(String CountryDdl)
	{
		Assert.assertTrue(objMyAccountPage.verifycountryddl(CountryDdl));		
	}
	//Test to verify the updated value in Company Website field
	public void verifycompanywebsiteurl(String Companywebsite)
	{
		assertThat(objMyAccountPage.verifycompanywebsiteurl(Companywebsite),Matchers.equalTo(true));
	}
	//Test to verify the updated Prefix value in database
	public void verifyPrefixDB(String Prefix,String emailId)throws SQLException
	{
		String uiPrefix=objMyAccountPage.getPrefix();
		String dbPrefix=objDBConnectionPage.getPrefix(emailId).trim();		
		Assert.assertEquals(uiPrefix,dbPrefix);
	}	
	//Test to verify the updated FirstName value in database
	public void verifyFirstnameDB(String FirstName,String emailId)throws SQLException
	{
		String uiFirstName=objMyAccountPage.getFirstName();
		String dbFirstName=objDBConnectionPage.getFirstName(emailId).trim();		
		Assert.assertEquals(uiFirstName,dbFirstName);		
	}
	//Test to verify the updated LastName value in database
	public void verifyLastnameDB(String LastName,String emailId)throws SQLException
	{
		String uiLastName=objMyAccountPage.getLastName();
		String dbLastName=objDBConnectionPage.getLastName(emailId).trim();		
		Assert.assertEquals(uiLastName,dbLastName);		
	}
	//Test to verify the updated CountryCode value in database
	public void verifyCountryCodeDB(String CountryCode,String emailId)throws SQLException
	{
		String uiCountryCode=objMyAccountPage.getCountryCode();
		String dbCountryCode=objDBConnectionPage.getCountryCode(emailId).trim();		
		Assert.assertEquals(uiCountryCode,dbCountryCode);	
	}
	//Test to verify the updated AreaCode value in database	
	public void verifyAreaCodeDB(String AreaCode,String emailId)throws SQLException
	{
		String uiAreaCode=objMyAccountPage.getAreaCode();
		String dbAreaCode=objDBConnectionPage.getAreaCode(emailId).trim();		
		Assert.assertEquals(uiAreaCode,dbAreaCode);
	}
	//Test to verify the updated PhoneNumber value in database
	public void verifyPhoneNumDB(String PhoneNumber,String emailId)throws SQLException
	{
		String uiPhoneNum=objMyAccountPage.getPhoneNum();
		String dbPhoneNum=objDBConnectionPage.getPhoneNum(emailId).trim();		
		Assert.assertEquals(uiPhoneNum,dbPhoneNum);
	}
	//Test to verify the updated Extension value in database
	public void verifyExtensionDB(String Extension,String emailId)throws SQLException
	{
		String uiExtension=objMyAccountPage.getExtension();
		String dbExtension=objDBConnectionPage.getExtension(emailId).trim();		
		Assert.assertEquals(uiExtension,dbExtension);
	}	
	//Test to verify the updated CountryDDL value in database
	public void verifyCountryDDLDB(String CountryDDL,String emailId)throws SQLException
	{
		String uiCountryDDL=objMyAccountPage.getCountryDDL();
		String dbCountryDDL=objDBConnectionPage.getCountryDDL(emailId).trim();		
		Assert.assertEquals(uiCountryDDL,dbCountryDDL);
	}
	//Test to verify the updated Company Website value in database
	public void verifyCompanyWebsiteDB(String CompanyWebsite,String emailId)throws SQLException
	{
		String uiCompanyWebsite=objMyAccountPage.getCompanyWebsite();
		String dbCompanyWebsite=objDBConnectionPage.getCompanyWebsite(emailId).trim();		
		Assert.assertEquals(uiCompanyWebsite,dbCompanyWebsite);
	}
	//Test to select the My Details tab under My Account
	public void selectMyDetailsTab()
	{			
		assertThat(objMyAccountPage.selectMyDetailsTab(),Matchers.equalTo(true));
	}
	
	
		
}
