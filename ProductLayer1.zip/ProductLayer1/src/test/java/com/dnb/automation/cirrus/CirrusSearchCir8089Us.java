package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * CirrusSearchCir8089Us - This program calls serenity
 * story file
 *
 * @author Rajesh G
 ***********************************************************************************************/

public class CirrusSearchCir8089Us extends SerenityStory{

}
