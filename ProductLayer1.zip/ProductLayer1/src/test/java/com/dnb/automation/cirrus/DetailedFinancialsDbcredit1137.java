package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedFinancialsDbcredit1137 - This program calls serenity story file
 *
 * @author Rajesh G
 ***********************************************************************************************/

public class DetailedFinancialsDbcredit1137 extends SerenityStory{

}
