package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * CirrusLogin - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class CirrusLogin extends SerenityStory {

}
