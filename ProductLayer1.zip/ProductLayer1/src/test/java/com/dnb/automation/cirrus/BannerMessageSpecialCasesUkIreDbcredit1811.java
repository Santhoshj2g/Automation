package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class BannerMessageSpecialCasesUkIreDbcredit1811 extends SerenityStory {

}
