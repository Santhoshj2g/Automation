package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;


/**********************************************************************************************
 * DetailedFinancialsCir1729Ca - This program calls serenity
 * story file
 *
 * @author Rajesh G
 ***********************************************************************************************/

public class DetailedFinancialsCir1729Ca extends SerenityStory{

}
