package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class DetailedCompanyProfileDc1245Dc2327Dc837Dc1480Dc846 extends SerenityStory{

}
