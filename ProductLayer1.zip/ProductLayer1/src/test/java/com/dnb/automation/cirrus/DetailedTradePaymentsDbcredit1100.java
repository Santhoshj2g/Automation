package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

/**
 * Created by Agurul on 10/6/2016.
 */
public class DetailedTradePaymentsDbcredit1100 extends SerenityStory {
}
