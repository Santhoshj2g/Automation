package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * CustomizeKeydataDbcredit495CA - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class CustomizeKeydataDbcredit495CA extends SerenityStory{

}
