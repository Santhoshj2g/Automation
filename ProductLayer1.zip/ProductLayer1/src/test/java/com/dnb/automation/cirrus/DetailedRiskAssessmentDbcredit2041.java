package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedRiskAssessmentDbcredit1151 - This program calls serenity story file
 *
 * @author Rajesh G
 ***********************************************************************************************/
public class DetailedRiskAssessmentDbcredit2041 extends SerenityStory{

}