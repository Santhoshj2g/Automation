package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedTradeTabWithDataCIR1774US - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/
public class DetailedTradeTabWithDataCIR1774US extends SerenityStory{

}
