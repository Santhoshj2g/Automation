package com.dnb.automation.bd.tests;

import org.junit.Assert;

import com.dnb.automation.bd.pages.BDTabsPage;

import net.thucydides.core.steps.ScenarioSteps;

public class BDTabsTest extends ScenarioSteps{
	
	BDTabsPage objBDTabsPage;

//Test To verify the user in home tab	
	public void inHomeTab() throws Exception
	{
		Assert.assertEquals(true,objBDTabsPage.getHomeTabSelection());
	}
 
//Test To verify the user in DUNSNUMBER tab	
	public void inDUNSNUMBERTab() throws Exception
	{
		Assert.assertEquals(true,objBDTabsPage.getDUNSNUMBERTabSelection());
	}

//Test To verify the user in GETDUNSREGISTERED tab
	public void inGETDUNSREGISTEREDTab() throws Exception
	{
		Assert.assertEquals(true,objBDTabsPage.getGETDUNSREGISTEREDTabSelection());
	}

//Test To verify the user in MYACCOUNT tab	
	public void inMYACCOUNTTab() throws Exception
	{
		Assert.assertEquals(true,objBDTabsPage.getMYACCOUNTTabSelection());
	}

//Test To verify the user in MYDASHBOARD tab
	public void inMYDASHBOARDTab() throws Exception
	{
		Assert.assertEquals(true,objBDTabsPage.getMYDASHBOARDTabSelection());
	}
//Test to select my account tab
	public void selectMyAccountTab()
	{
		Assert.assertEquals(true,objBDTabsPage.selectMYACCOUNTTab());
	}
//Test to select the Get Duns Registered tab	
	public void SelectGetDunsRegisteredTab() {
		// TODO Auto-generated method stub
		Assert.assertEquals(true,objBDTabsPage.SelectGetDunsRegisteredTab());
	}
	
//	Test to select the Home tab	
	public void callSelectHomeTab() {
		// TODO Auto-generated method stub
		Assert.assertEquals(true,objBDTabsPage.SelectHomeTab());
	}

}
