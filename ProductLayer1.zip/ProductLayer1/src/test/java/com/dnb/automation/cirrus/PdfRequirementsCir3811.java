package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * ReportCompanyProfileUS - This program calls serenity story file
 *
 * @author Rajesh
 ***********************************************************************************************/


public class PdfRequirementsCir3811 extends SerenityStory{

}
