package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * CirrusSearch - This program calls serenity
 * story file
 *
 * @author Rajesh G
 ***********************************************************************************************/

public class CirrusSearch extends SerenityStory{

}
