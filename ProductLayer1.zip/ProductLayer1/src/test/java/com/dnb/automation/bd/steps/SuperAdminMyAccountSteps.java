package com.dnb.automation.bd.steps;

import java.io.IOException;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import net.thucydides.core.annotations.Steps;

import com.dnb.automation.bd.tests.LoginPageTest;
import com.dnb.automation.bd.tests.SuperAdminMyAccountTest;

public class SuperAdminMyAccountSteps {
	
	 @Steps
	 SuperAdminMyAccountTest superAdminMyAccountTest;	
	 
	 @Steps
	 LoginPageTest objLoginPageTest;
	 
	 //Click on MyAccount tab
	 @When("I click on MyAccount tab")
	 public void callClickMyAccountTab()
	 {
		 System.out.println("*******inside click acc tab steps");
		 superAdminMyAccountTest.clickMyAccountTab();
	 }
	 
	 //Verify MyAccount title is displayed
	 @Then("$myAccountTitle page should be displayed")
	 public void callVerifyMyAccountPageTitle(String myAccountTitle)
	 {
		 superAdminMyAccountTest.verifyMyAccountPageTitle(myAccountTitle.replace("{", "").replace("}", ""));
	 }
	 
	 //Click on My Details tab
	 @When("I click on MyDetails tab")
	 public void callClickMyDetailsTab()
	 {
		 superAdminMyAccountTest.clickMyDetailsTab();
	 }
	 
	 //Verify manage ads link is available in application
	 @Then("Manage Ads link should be available")
	 public void callVerifyManageAdsLink()
	 {
		 superAdminMyAccountTest.verifyManageAdsLink();
	 }
	 
	 //Click on manage ads link
	 @When("I click on Manage Ads link")
	 public void callClickManageAdsLink()
	 {
		 superAdminMyAccountTest.clickManageAdsLink();
	 }
	 
	 //Verify manage ads title is displayed
	 @Then("$manageAdvTitle title should be displayed")
	 public void callGetManageAdvTitle(String manageAdvTitle)
	 {
		 superAdminMyAccountTest.getManageAdvTitle(manageAdvTitle.replace("{", "").replace("}", ""));
	 }
	 
	 //Click on browse button and upload an image for ad
	 @When("I browse and upload the ad image")
	 public void callUploadAd() throws Exception
	 {
		 superAdminMyAccountTest.uploadAdTest();
	 }
	 
	 //Verify ad is uploaded successfully
	 @Then("ad should be uploaded successfully")
	 public void callVerifyUploadStatus() throws IOException
	 {
		 superAdminMyAccountTest.verifyUploadStatus();
	 }
	   
	 
	 //	Click on reset password link 
	 @When("Reset Password link is clicked")
	 public void callClickOnResetPassword()
	 {
		 superAdminMyAccountTest.clickOnResetPasswordTest();
	 }

	 //Verify reset password page is displayed with title 'Reset Password'
	 @Then("reset password page with title $resetPwdTitle should be displayed")
	 public void callGetResetPwdPgTitle(String resetPwdTitle)
	 {
		 superAdminMyAccountTest.getResetPwdPgTitleTest(resetPwdTitle.replace("{", "").replace("}", ""));
	 }
	 
	 //Enter email,firstname.lastname and select country and click on search button
	 @When("I fill <Email>,<FirstName>,<LastName> and <Country> and click on Search button")
	 public void callFillResetFieldsAndSearch(@Named("Email") String email,@Named("FirstName") String firstName,@Named("LastName") String lastName,@Named("Country") String country)
	 {
		 superAdminMyAccountTest.fillResetFieldsAndSearchTest(email,firstName,lastName,country);
	 }
	 
	 //verify user's registration details are displayed
	 @Then("the user's registration details should be displayed <Email>")
	 public void callIsUserDetailsDisplayed(@Named("Email") String email)
	 {
		 superAdminMyAccountTest.isUserDetailsDisplayedTest(email);
	 }
	 
	 //Select the user and click on reset button to reset the password
	 @When("I select the user detail and click on reset button")
	 public void callClickOnReset()
	 {
		 superAdminMyAccountTest.clickOnResetBtnTest();
	 }
	 
	 //Verify a msg is displayed for triggering mail to reset password
	 @Then("a msg should be displayed on triggering mail")
	 public void callIsMailTriggered() throws Exception
	 {
		 superAdminMyAccountTest.getResetMsgTest();
	 }
	 
	 //Launch gmail application
	 @When("I launch gmail")
	 public void callLoginToGmail() throws Exception
	 {
		 superAdminMyAccountTest.launchGmailTest();
	 }
	 
	 //Verify login page of gmail is displayed
	 @Then("login page of gmail should be displayed")
	 public void callIsLoginPgDisplayed()
	 {
		 superAdminMyAccountTest.isGmailLoginPgDisplayedTest();
	 }
	 
	 //Enter the registered user id and password and click on sign in button 
	 @When("I login with the user's mail id <UserName> and password <Password>")
	 public void callLoginIntoGmail(@Named("UserName") String userName,@Named("Password") String password) throws Exception
	 {
		 superAdminMyAccountTest.loginWithUserRegMailIDTest(userName,password);
	 }
	 
	 //Verify gmail home page of the user is displayed
	 @Then("home page of the user should be displayed")
	 public void callChkHomePgOfGmailDisplayed(@Named("UserName") String userName)
	 {
		 superAdminMyAccountTest.chkHomePgOfGmailDisplayed(userName);
	 }
	 
	 //Click on the new mail triggered to reset password
	 @When("I click on the received mail to reset password")
	 public void callClickOnMail()
	 {
		 superAdminMyAccountTest.clickMailTest();
	 }
	 
	 //Verify mail body contains the link to reset password
	 @Then("mail body should be displayed with the reset password link")
	 public void callIsDisplayedMailBodyWithResetPwdLink()
	 {
		 superAdminMyAccountTest.isDisplayedMailBodyWithResetPwdLink();
	 }
	 	 
	 //Click on the link to reset the password
	 @When("I click on the link to reset password")
	 public void callClickOnResetPwdLnkInMail()
	 {
		 superAdminMyAccountTest.clickOnResetPwdLnkInMailTest();
	 }
	 
	 //Verify Activate account page is displayed
	 @Then("activate account page with title $activateAccount should be displayed")
	 public void callVerifyActivateAccPgIsDisplayed(String activateAccount)
	 {
		 superAdminMyAccountTest.verifyActivateAccPgIsDisplayed(activateAccount.replace("{", "").replace("}", ""));
	 }
	 
	 //Enter new password and confirm password and click on submit button
	 @When("I enter the new password <NewPwd> and confirm password <ConfirmPwd> and click on Submit button")
	 public void callEnterNewAndConfirmPwd(@Named("NewPwd") String newPwd,@Named("ConfirmPwd") String confirmPwd)
	 {
		 superAdminMyAccountTest.enterNewAndConfirmPwdTest(newPwd,confirmPwd);
	 }
	 
	 //verify reset status is displayed
	 @Then("$resetPwdStatusMsg message should be displayed")
	 public void callVerifyMsgActivationSuccessful(String resetPwdStatusMsg)
	 {
		 superAdminMyAccountTest.verifyMsgActivationSuccessful(resetPwdStatusMsg.replace("{", "").replace("}", ""));
	 }
	 
	 //click on go to login page link
	 @When("I click on go to login page link")
	 public void callClickOnGoToLoginPgLink()
	 {
		 superAdminMyAccountTest.clickOnGoToLoginPgLinkTest();
	 }
	 
/*	 @Then("display Super admin's home page")
	 public void callVerifyHomePgOfSuperAdminIsDisplayed(String loggedInAs)
	 {
		 superAdminMyAccountTest.verifyHomePgOfSuperAdminIsDisplayed(loggedInAs.replace("{", "").replace("}", ""));
	 }
	
	 
	 //click on logout link
	 @When("I click on Logout link")
	 public void callClickOnLogoutLink()
	 {
		 superAdminMyAccountTest.clickOnLogoutLinkTest();
	 }
*/ 	 
	 //Verify login screen of BD is displayed
	 @Then("I am in login screen of BD")
	 public void callInLoginPg()
	 {
		 objLoginPageTest.login();
	 }
	 
	 //relogin with new password
	 @When("I relogin with new Non Drs UserName <UserName> and Password <NewPwd>")
	 public void callRelogin(@Named("UserName") String userName,@Named("NewPwd") String newPwd) throws Exception
	 {
		 objLoginPageTest.appLogin(userName, newPwd);
	 }

	 @When("I select AdCategories As <AdCategories>")
	 public void callSelectAdCategories(@Named("AdCategories") String AdCategories)
	 {
		 superAdminMyAccountTest.selectAdCategories(AdCategories);
	 }
	 
	 @When("I give Duns number As <Duns>")
	 public void callEnterDuns(@Named("Duns") String Duns)
	 {
		 superAdminMyAccountTest.enterDuns(Duns);
	 }
	 @When("I give AdvDescription As <AdsDesc>")
	 public void callEnterAdDesc(@Named("AdsDesc") String AdsDesc)
	 {
		 superAdminMyAccountTest.enterAdDesc(AdsDesc);
	 }
	 
	 @When("I click on Browse button")
	 public void callClickBrowseButton()
	 {
		 superAdminMyAccountTest.clickBrowseButton();
	 }
	 
	 @When("I select the <AdCategories> Advertisement image <ImageName> to upload")
	 public void calluploadAdvertisementImage(@Named("ImageName") String ImageName)
	 {
		 superAdminMyAccountTest.uploadAdvertisementImage(ImageName); 
	 }
	 
	 @Then("The selected file name should be displayed next to the browse button")
	 public void callIsSelectedFileDisplayed()
	 {
		 superAdminMyAccountTest.isSelectedFileDisplayed();
	 }
	 
	 @When("I Click on Advertisement upload button")
	 public void callClickAdvUpload()
	 {
		 superAdminMyAccountTest.clickAdvUpload();
	 }
	 
	 @Then("The advertisement has been uploaded successfully message should be visible")
	 public void callIsAdvConfirmationMsgDisp()
	 {
		 superAdminMyAccountTest.isAdvConfirmationMsgDisp();
	 }
	 
	 @Then("The Uploaded advertisement <AdsDesc> should be available in the uploaded ads")
	 public void callIsUploadedAddAvail(@Named("AdsDesc") String AdsDesc)
	 {
		 superAdminMyAccountTest.isUploadedAddAvail(AdsDesc);
	 }
	 
	 @When("I click on Delete button of Add <AdsDesc>")
	 public void callClickAddDeleteButton(@Named("AdsDesc") String AdsDesc)
	 {
		 superAdminMyAccountTest.clickAddDeleteButton(AdsDesc);
	 }
	 
	 @Then("Adds delete Confirmation message should displayed")
	 public void callIsAddDeleteConfirmationDisp()
	 {
		 superAdminMyAccountTest.isAddDeleteConfirmationDisp();
	 }
	 
	 @When("I click on Ok button of The adds delete Confirmation message")
	 public void callClickOkAddsDelete()
	 {
		 superAdminMyAccountTest.clickOkAddsDelete();
	 }
	 
	 @Then("Successfully deleted the Advertisement message should be visible")
	 public void callIsAdvDeleteConfirMsgDisp()
	 {
		 superAdminMyAccountTest.isAdvDeleteConfirMsgDisp();
	 }
}

