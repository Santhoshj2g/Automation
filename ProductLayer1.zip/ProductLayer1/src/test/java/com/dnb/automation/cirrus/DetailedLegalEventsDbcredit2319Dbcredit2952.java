package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class DetailedLegalEventsDbcredit2319Dbcredit2952 extends SerenityStory{

}
