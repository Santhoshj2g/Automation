package com.dnb.automation.bd.steps;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.When;
import com.dnb.automation.bd.tests.BDTabsTest;

import net.thucydides.core.annotations.Steps;

public class BDTabsSteps {
	@Steps
	BDTabsTest objBDTabsTest;

	@Given("BD:I am in Admin my dashboard page")
    public void callInMyDashboard() throws Exception    
    {
		objBDTabsTest.inMYDASHBOARDTab();
    }
	@Given("BD:I select MyAccount tab")
    public void callSelectMyAccountTab() throws Exception    
    {
		objBDTabsTest.selectMyAccountTab();
    }
	
	@Given ("BD:I select GetDunsRegistered tab")
	public void callSelectGetDunsRegisteredTab() throws Exception    
    {
		objBDTabsTest.SelectGetDunsRegisteredTab();
    }
	
	@Given ("BD:I select Home tab")
	public void callSelectHomeTab() throws Exception    
    {
		objBDTabsTest.callSelectHomeTab();
    }


	
}
