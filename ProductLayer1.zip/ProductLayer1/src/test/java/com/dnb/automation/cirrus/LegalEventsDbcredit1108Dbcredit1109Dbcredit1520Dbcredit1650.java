package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class LegalEventsDbcredit1108Dbcredit1109Dbcredit1520Dbcredit1650 extends SerenityStory{

}
