package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedCompanyProfileCir2029 - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class DetailedCompanyProfileCir2029 extends SerenityStory{

}
