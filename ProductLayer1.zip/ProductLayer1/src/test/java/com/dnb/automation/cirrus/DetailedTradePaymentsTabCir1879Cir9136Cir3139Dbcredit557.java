package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class DetailedTradePaymentsTabCir1879Cir9136Cir3139Dbcredit557 extends SerenityStory{

}
