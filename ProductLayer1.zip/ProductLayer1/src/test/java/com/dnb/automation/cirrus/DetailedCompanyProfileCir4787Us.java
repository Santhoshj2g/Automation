package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedCompanyProfileCir4787Us - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class DetailedCompanyProfileCir4787Us extends SerenityStory{

}
