package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedOwnershipCir2585Us - This program calls serenity story file
 * 
 * @author Anitha 
 ***********************************************************************************************/

public class DetailedOwnershipCir2585Us extends SerenityStory{

}
