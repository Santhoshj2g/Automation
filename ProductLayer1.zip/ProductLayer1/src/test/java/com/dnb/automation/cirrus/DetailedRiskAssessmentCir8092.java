package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedRiskAssessmentCir8092 - This program calls serenity
 * story file
 *
 * @author Rajesh G
 ***********************************************************************************************/

public class DetailedRiskAssessmentCir8092 extends SerenityStory{

}
