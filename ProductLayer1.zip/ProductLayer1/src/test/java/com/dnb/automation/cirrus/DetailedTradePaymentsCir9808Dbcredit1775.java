package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class DetailedTradePaymentsCir9808Dbcredit1775 extends SerenityStory{

}
