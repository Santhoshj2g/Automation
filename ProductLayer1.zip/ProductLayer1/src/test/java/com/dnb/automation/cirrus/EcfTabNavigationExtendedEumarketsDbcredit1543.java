package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class EcfTabNavigationExtendedEumarketsDbcredit1543 extends SerenityStory {

}
