package com.dnb.automation.cirrus;

import net.serenitybdd.jbehave.SerenityStory;

public class AdvancedSearchPortfolioStatusCir1028 extends SerenityStory{

}
