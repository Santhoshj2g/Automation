package com.dnb.automation.cirrus;
import net.serenitybdd.jbehave.SerenityStory;

/**********************************************************************************************
 * DetailedFinancialsDbcredit1008 - This program calls serenity story file
 *
 * @author Rajesh G
 ***********************************************************************************************/

public class DetailedFinancialsDbcredit1842 extends SerenityStory{

}
