package com.dnb.automation.bd.tests;

import org.junit.Assert;

import net.thucydides.core.steps.ScenarioSteps;

import com.dnb.automation.bd.pages.AdminMyAccountMyDetailsPage;

public class AdminMyAccountMyDetailsTest extends ScenarioSteps {
	
	AdminMyAccountMyDetailsPage  objAdminMyAccountMyDetailsPage;

	public void selectMyDetailsTab() {
		
		objAdminMyAccountMyDetailsPage.selectMyDetailsTab();
		
	}

	public void isManageDownloadsLinkVisible() { 
		Assert.assertTrue(objAdminMyAccountMyDetailsPage.isManageDownloadsLinkVisible());
	}

	public void clickManageDownloadsLink() {
		objAdminMyAccountMyDetailsPage.clickManageDownloadsLink();
	}

	public void isManageDownloadsSectionVisible() {
		Assert.assertEquals(true,objAdminMyAccountMyDetailsPage.isManageDownloadsSectionVisible());
	}

	public void giveProductDescription(String ProductDes) {
		// TODO Auto-generated method stub
		objAdminMyAccountMyDetailsPage.giveProductDescription(ProductDes);
	}

	public void giveProductOfferCode(String productOfferCode) {
		// TODO Auto-generated method stub
		
		objAdminMyAccountMyDetailsPage.giveProductOfferCode(productOfferCode);
	}

	public void giveDownLoadCountLimit(String downcntlmt) {
		// TODO Auto-generated method stub
		objAdminMyAccountMyDetailsPage.giveDownLoadCountLimit(downcntlmt);
	}

	public void selectDownloadExpAsToDayDate() {
		// TODO Auto-generated method stub
		objAdminMyAccountMyDetailsPage.selectDownloadExpAsToDayDate();	
	}

	public void selectFilethroughBrowseButton(String FileName) {
		objAdminMyAccountMyDetailsPage.selectFilethroughBrowseButton(FileName);	
		
	}

	public void isFileNameVisible() {
		// TODO Auto-generated method stub
		Assert.assertTrue(objAdminMyAccountMyDetailsPage.isFileNameVisible());
	}

	public void clickUploadButton() {
		// TODO Auto-generated method stub
		Assert.assertTrue(objAdminMyAccountMyDetailsPage.clickUploadButton());
	}

	public void isProductOfferCodePresent(String productOfferCode) {
		// TODO Auto-generated method stub
		Assert.assertTrue(objAdminMyAccountMyDetailsPage.isProductOfferCodePresent(productOfferCode));
	}

	public void clickOnDeleteButton(String productOfferCodes) {
		// TODO Auto-generated method stub
		objAdminMyAccountMyDetailsPage.clickOnDeleteButton(productOfferCodes);
		
	}

	public void isProductOfferCodeFileAvilable(String productOfferCodefile) {
		// TODO Auto-generated method stub
		Assert.assertFalse("File already deleted so verification code return false",objAdminMyAccountMyDetailsPage.isProductOfferCodeFileAvilable( productOfferCodefile));	
	}

	public void isConfirmationPromptAvilable() {
//		Assert.assertTrue(objAdminMyAccountMyDetailsPage.isConfirmationPromptAvilable());	
		objAdminMyAccountMyDetailsPage.isConfirmationPromptAvilable();
	}

	public void clickOnConfirmationButton() {
		// TODO Auto-generated method stub
		objAdminMyAccountMyDetailsPage.clickOnConfirmationButton();
	}

}
