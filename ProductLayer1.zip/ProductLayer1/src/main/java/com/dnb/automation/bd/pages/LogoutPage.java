package com.dnb.automation.bd.pages;

import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class LogoutPage extends PageObject {

	@FindBy(xpath = "//*[@id='headerlinks']//a[@class='login']")
    private WebElementFacade btnLogIn;

    @FindBy(xpath = ".//*[@id='headerlinks']//a[@href='logout']")
    private WebElementFacade btnLogOut;

    /***********************************************************************************
     * Function: Click on login button 
     * Input : NA
     * Action : NA 
     * Output : NA
     ***********************************************************************************/
    public boolean logout()
    {
    	UIHelper.waitForPageToLoad(getDriver());
    	btnLogOut.waitUntilClickable();
    	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	btnLogOut.click();
    	UIHelper.waitForPageToLoad(getDriver());
    	btnLogIn.waitUntilPresent();
    	if(btnLogIn.isPresent())
    	{
    		return true;    		
    	}else
    	{
    		return false;
    	}
    	
    }
    


}
