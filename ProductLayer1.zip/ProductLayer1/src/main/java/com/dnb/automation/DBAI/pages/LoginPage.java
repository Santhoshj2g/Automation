package com.dnb.automation.DBAI.pages;

import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

/**
 * Created by 630239 on 5/8/2017.
 */
public class LoginPage extends PageObject{

    @FindBy(xpath=".//table/tbody/tr/td/input[@name ='DBID']")
    private WebElementFacade userName;
    
    @FindBy(xpath=".//table/tbody/tr/td/input[@name ='DBPASSWORD']")
    private WebElementFacade password;

    @FindBy(xpath=".//table/tbody/tr/td/a/img[contains(@src,'logon')]")
    private WebElementFacade loginbtn;
    
    @FindBy(name="selector")
    private WebElementFacade countrySelect;

    public void launchURL(String appURL) {
        getDriver().manage().deleteAllCookies();
        getURLtoLaunch(appURL);
    }

    private void getURLtoLaunch(String appURL) {
        getDriver().manage().window().maximize();
        getDriver().get(appURL);
    }

    public void login(String username, String pwd, String country) {
    	selectCountry(country);
        enterUser(username);
        enterPassword(pwd);
        clickLogin();
    }

    private void clickLogin() {
        try {
            UIHelper.highlightElement(getDriver(), loginbtn);
            loginbtn.click();
        } catch (AssertionError e) {
            // e.printStackTrace();
        }

    }

    private void enterPassword(String pwd) {
        try {
            UIHelper.highlightElement(getDriver(), password);
            password.type(pwd);
        } catch (AssertionError e) {
            // e.printStackTrace();
        }

    }

    private void enterUser(String username) {
        getDriver().switchTo().frame("Main");
        try {
            UIHelper.highlightElement(getDriver(), userName);
            userName.type(username);
        } catch (AssertionError e) {
            // e.printStackTrace();
        }
    }
    
    private void selectCountry(String country) {
    	try {
    		UIHelper.highlightElement(getDriver(), countrySelect);
    		Select selectCountry = new Select(countrySelect);
    		selectCountry.selectByVisibleText(country);
    	} catch (AssertionError e) {
    		
    	}
    }
}
