package com.dnb.automation.sba.pages;

import java.util.Map;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.sba.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class SuppFamilyWithBUPage extends PageObject{

	int totalDuns;
	/*Supplier Family WebElements*/

	@FindBy(xpath = "//*[@id='supplierFamily']/a")
	private WebElementFacade supplierFamily;

	@FindBy(xpath ="//*[@id='ui-id-7']")
	private WebElementFacade analysisSubTab;

	@FindBy(xpath ="//*[@id='analysisFilter-button']/span[2]")
	private WebElementFacade filter;

	@FindBy(xpath ="//*[@id='analysisFilter-menu']//*[contains(text(),'Taxonomy')]")
	private WebElementFacade taxonomy;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[4]/span/a") 
	private WebElementFacade parentItem;

	@FindBy(xpath ="//*[@id='SfAnalysisTotalCount']")
	private WebElementFacade totalRecords;

	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[2]")
	private WebElementFacade dunsNumber;

	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[3]")
	private WebElementFacade spend;

	@FindBy(xpath ="//*[@id='supplierAnalysis-ManageBtn']")
	private WebElementFacade manageCols;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[1]/span/a")
	private WebElementFacade cmpnyProfile_AF;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[2]/span/a")
	private WebElementFacade corpLinkage_AF;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[3]/span/a")
	private WebElementFacade socialResp_AF;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[4]/span/a")
	private WebElementFacade spend_AF;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[5]/span/a")
	private WebElementFacade risk_AF;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[6]/span/a")
	private WebElementFacade diversity_AF;

	@FindBy(xpath ="//*[@id='manageColumn-addBtn']")
	private WebElementFacade manageColAddBtn;

	@FindBy(xpath ="//*[@id='manageColumn-applyBtn']")
	private WebElementFacade applyBtn;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[4]/ul/li[1]/span/a")
	private WebElementFacade forestryServices;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[4]/ul/li[2]/span/a")
	private WebElementFacade timberTracts;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[4]/span/span[1]")
	private WebElementFacade parentNode;

	@FindBy(xpath ="//*[@id='supplierAnalysis-DownloadListBtn']")
	private WebElementFacade export;

	@FindBy(xpath ="//*[@id='gridExcel']")
	private WebElementFacade exportToExcel;

	@FindBy(xpath ="(//*[@id='100'])[1]")
	private WebElementFacade itemsPerPage;

	@FindBy(xpath ="//*[@id='dynaBlockHolder']/div[1]/div/a[2]")
	private WebElementFacade nextPageOfBU;

	@FindBy(xpath ="//*[@id='block_jump_valSF']")
	private WebElementFacade pageNum;

	@FindBy(xpath ="//*[@id='block_jumpSF']")
	private WebElementFacade goButton;
	
    @FindBy(xpath = ".//*[@id='wrapper']//*[@class='container']//*[@class='dashboard-container']//*[@class='page-heading']/h1")
    private WebElementFacade dashboardTitleEle;

	/*Business Unit WebElements*/

	@FindBy(xpath ="//*[@id='businessUnits']/a")
	private WebElementFacade bussienessUnits;

	@FindBy(xpath ="//*[@id='ui-id-7']")
	private WebElementFacade analysisTabofBU;

	@FindBy(xpath ="//*[@id='analysisFilter-button']/span[1]")
	private WebElementFacade filterOfBU;

	@FindBy(xpath ="//*[@id='analysisFilter-menu']//*[contains(text(),'Taxonomy')]")
	private WebElementFacade taxonomyofBU;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[4]/span/a")
	private WebElementFacade agriculturalProductionCropsOfBU;

	@FindBy(xpath ="//*[@id='BuAnalysisTotalCount']")
	private WebElementFacade totalRecordsOfBU;

	@FindBy(xpath ="//*[@id='supplierAnalysisTBodyBU']/tr[1]/td[2]")
	private WebElementFacade dunsOfBU;

	@FindBy(xpath ="//*[@id='supplierAnalysisTBodyBU']/tr[1]/td[3]")
	private WebElementFacade spendOfBU;

	@FindBy(xpath ="//*[@id='manageColumn-addBtnBU']")
	private WebElementFacade manageColAddBtnBU;

	@FindBy(xpath ="//div[@id='container']/div[3]/img")
	private WebElementFacade manageColAddBtnOfBU;

	@FindBy(xpath ="//*[@id='dynaPagHolder']/div[1]/div/a[2]")
	private WebElementFacade nextPage;

	@FindBy(xpath ="//*[@id='block_jump_valGrid']")
	private WebElementFacade pageBlockOfBU;


	@FindBy(xpath ="//*[@id='block_jumpGrid']")
	private WebElementFacade goButtonOfBU;

	@FindBy(xpath ="//a[@href='analysisDashboard']")
	private WebElementFacade analysisTab;

	int totalDunsOfBU;

	public boolean isInSRMDesktopPage()
	{
		UIHelper.waitForVisibilityOfElement(dashboardTitleEle);
		return dashboardTitleEle.getText().contains("Supplier Risk Manager Dashboard");
	}
	
	public boolean isInSupplierFamily()
	{
		String xpathOfSF="//*[@id='supplierFamily' and @class='selected ShowSubMenu']/a";
		return UIHelper.isElementDisplayed(getDriver(), xpathOfSF);
	}
	
	public void clickAnalysisTab()
	{
		UIHelper.clickAnElement(analysisTab);
	}

	public void clickOnSupplierFamily(){
		UIHelper.clickAnElement(supplierFamily);
	}

	public void clickOnAnalysisSubTab(){
		UIHelper.clickAnElement(analysisSubTab);
	}

	public void chooseTaxonomy(){
		UIHelper.clickAnElement(filter);
		UIHelper.clickAnElement(taxonomy);

	}

	public void clickOnParentItem(){
		UIHelper.switchToTab(getDriver(),"supplierFamily");
		String pNodeSF="(//*[@id='analysisTreeView']//*[@class='dynatree-container']//*[@class='dynatree-expander'])[1]";
		UIHelper.clickAnElement(getDriver(), pNodeSF);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public boolean isTotalRecDisplayed()
	{
		return UIHelper.isElementDisplayed(totalRecords);
	}

	public int getTotalRecords(){
		//getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDuns=UIHelper.getTotalRecords(totalRecords);
		System.out.println("getTotalRecords :"+totalDuns);
		return UIHelper.getTotalRecords(totalRecords);
	}

	public Map<String,String> getSpendValue(){
		UIHelper.switchToTab(getDriver(),"supplierFamily");
		String preXpath="//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.clickAnElement(itemsPerPage);
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDuns, nextPage);
	}

	public Map<String, String> getSpendValueOfChild(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDuns=UIHelper.getTotalRecords(totalRecords);
		UIHelper.clickAnElement(itemsPerPage);
		return getSpendAfterAddcols();
	}

	public void clickOnExportToExcel(){
		UIHelper.switchToTab(getDriver(), "supplierFamily");
		UIHelper.mouseOveranElement(getDriver(),export);
	}

	public boolean isDataExported(){
		return exportToExcel.isPresent();
	}

	public void clickOnExportToExcelInBU(){
		UIHelper.switchToTab(getDriver(), "notSF");
		UIHelper.mouseOveranElement(getDriver(),export);
	}

	public boolean isDataExportedInBU(){
		return exportToExcel.isPresent();
	}

	public void clickOnManageColumns(){
		UIHelper.switchToTab(getDriver(),"supplierFamily");
		UIHelper.gotoFirstPage(pageNum,goButton);
		UIHelper.clickAnElement(manageCols);
	}

	public void addcolumnsAndClickApply(){
		UIHelper.waitForVisibilityOfElement(cmpnyProfile_AF);

		if(cmpnyProfile_AF.isPresent())
		{
			UIHelper.clickAnElement(cmpnyProfile_AF);
			UIHelper.clickAnElement(manageColAddBtn);
		}
		if(corpLinkage_AF.isPresent())
		{
			UIHelper.clickAnElement(corpLinkage_AF);
			UIHelper.clickAnElement(manageColAddBtn);
		}
		if(socialResp_AF.isPresent())
		{
			UIHelper.clickAnElement(socialResp_AF);
			UIHelper.clickAnElement(manageColAddBtn);
		}
		if(spend_AF.isPresent())
		{
			UIHelper.clickAnElement(spend_AF);
			UIHelper.clickAnElement(manageColAddBtn);
		}
		if(risk_AF.isPresent())
		{
			UIHelper.clickAnElement(risk_AF);
			UIHelper.clickAnElement(manageColAddBtn);
		}
		if(diversity_AF.isPresent())
		{
			UIHelper.clickAnElement(diversity_AF);
			UIHelper.clickAnElement(manageColAddBtn);
		}
		UIHelper.clickAnElement(applyBtn);
	}

	public Map<String,String> getSpendAfterAddcols(){
		String preXpath="//*[@id='supplierAnalysisTable']//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDuns, nextPage);
	}

	/*Bussiness Unit page*/

	public void clickOnBussienessUnits(){
		String URL=getDriver().getCurrentUrl();
		UIHelper.openInNewTab(getDriver(),URL);
		UIHelper.clickAnElement(bussienessUnits);
	}

	public void clickOnAnalysisTabofBU(){
		UIHelper.clickAnElement(analysisTabofBU);
	}

	public void chooseTaxonomyofBU(){
		UIHelper.clickAnElement(filterOfBU);
		UIHelper.clickAnElement(taxonomyofBU);
	}

	public void clickOnParentItemOfBU(){
		UIHelper.switchToTab(getDriver(),"notSF");
		String pNode="(//*[@id='analysisTreeView']//*[@class='dynatree-container']//*[@class='dynatree-expander'])[1]";
		UIHelper.clickAnElement(getDriver(), pNode);
	}

	public int getTotalRecordsOfBU(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDunsOfBU=UIHelper.getTotalRecords(totalRecordsOfBU);
		System.out.println("getTotalRecordsOfBU :"+totalDunsOfBU);
		return UIHelper.getTotalRecords(totalRecordsOfBU);
	}

	public Map<String,String> getSpendValueOfBU(){
		UIHelper.switchToTab(getDriver(),"notSF");
		String preXpath="//*[@id='supplierAnalysisTBodyBU']/tr[";
		UIHelper.clickAnElement(itemsPerPage);
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDunsOfBU, nextPageOfBU);
	}

	public Map<String, String> getSpendValueOfChildInBU(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDunsOfBU=UIHelper.getTotalRecords(totalRecordsOfBU);
		UIHelper.clickAnElement(itemsPerPage);
		return getSpendAfterAddColsOfBU();
	}

	public void clickOnManageColsOfBU(){
		UIHelper.switchToTab(getDriver(),"notSF");
		UIHelper.gotoFirstPage(pageBlockOfBU, goButtonOfBU);
		UIHelper.clickAnElement(manageCols);
	}

	public void addColsAndClickApplyOfBU(){
		UIHelper.waitForVisibilityOfElement(cmpnyProfile_AF);
		if(cmpnyProfile_AF.isPresent())
		{
			UIHelper.clickAnElement(cmpnyProfile_AF);
			UIHelper.clickAnElement(manageColAddBtnOfBU);
		}
		if(corpLinkage_AF.isPresent())
		{
			UIHelper.clickAnElement(corpLinkage_AF);
			UIHelper.clickAnElement(manageColAddBtnOfBU);
		}
		if(socialResp_AF.isPresent())
		{
			UIHelper.clickAnElement(socialResp_AF);
			UIHelper.clickAnElement(manageColAddBtnOfBU);
		}
		if(spend_AF.isPresent())
		{
			UIHelper.clickAnElement(spend_AF);
			UIHelper.clickAnElement(manageColAddBtnOfBU);
		}
		if(risk_AF.isPresent())
		{
			UIHelper.clickAnElement(risk_AF);
			UIHelper.clickAnElement(manageColAddBtnOfBU);
		}
		if(diversity_AF.isPresent())
		{
			UIHelper.clickAnElement(diversity_AF);
			UIHelper.clickAnElement(manageColAddBtnOfBU);
		}
		UIHelper.clickAnElement(applyBtn);
	}

	public Map<String,String> getSpendAfterAddColsOfBU(){
		String preXpath="//*[@id='supplierAnalysisTBodyBU']/tr[";
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDunsOfBU, nextPageOfBU);
	}
}
