package com.dnb.automation.gdm.pages;

import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

/**
 * Created by 630239 on 6/16/2017.
 */
public class ReportSelectionPage extends PageObject{

    @FindBy(xpath = ".//span[contains(text(),'Available')]")
    private WebElementFacade pageTitle;

    @FindBy(xpath=".//td/select[@name='rule']/option")
    private List<WebElementFacade> ruleDD;

    @FindBy(xpath = ".//td/input[@name='Submit']")
    private WebElementFacade makeDecisionbtn;

    String selectReport=".//a[contains(text(),'SERENITY')]";

    String selectReportType=".//a[contains(text(),'SERENITY')]";

    private boolean reportAvailability;

    public boolean verifyTitle() {
        UIHelper.waitForPageToLoad(getDriver());
        if(pageTitle.isPresent())
            return true;
        else
            return false;
    }

    public boolean SelectReport(String reportname) {
        WebElementFacade actualReport = find(By.xpath(selectReport.replace("SERENITY",reportname)));
        if(actualReport.isPresent()){
            UIHelper.highlightElement(getDriver(),actualReport);
            actualReport.click();
            reportAvailability = true;
            return true;
        }else {
            reportAvailability= false;
            return false;
        }
    }

    public boolean ToSelectReportType(String reportType) {
        WebElementFacade actualReportType = find(By.xpath(selectReportType.replace("SERENITY",reportType)));
        if(actualReportType.isPresent()){
            UIHelper.highlightElement(getDriver(),actualReportType);
            actualReportType.click();
            return true;
        }else {
            return false;
        }
    }

    public boolean  ToSelectRuleName(String ruleName) {
        boolean result = false;
            UIHelper.waitForPageToLoad(getDriver());
            for (WebElementFacade abc : ruleDD) {
                String optionValue = abc.getText().toLowerCase().trim();
                if (optionValue.contains(ruleName.toLowerCase())) {
                    abc.click();
                    result = true;
                    break;
                }
            }
           try{
                Alert alert = getDriver().switchTo().alert();
                alert.accept();
           }catch(NoAlertPresentException e){
                System.out.println("No alert Present");
           }
       return result;
    }

    public void clickMakeDecision() {
        UIHelper.waitForPageToLoad(getDriver());
        if(makeDecisionbtn.isPresent()){
            UIHelper.highlightElement(getDriver(),makeDecisionbtn);
            makeDecisionbtn.click();
        }
    }
}
