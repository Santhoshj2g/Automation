package com.dnb.automation.bd.pages;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class RegistrationPage extends PageObject {
	
	//Xpaths
	@FindBy(xpath="//*[@id='headerlinks']//a[contains(text(),'REGISTER')]")
	private WebElementFacade linkregister;

	@FindBy(xpath="//*[@id='registerEmail']")
	private WebElementFacade txtemailId;

	@FindBy(xpath="//*[@id='prefix']")
	private WebElementFacade dropdownPrefix;
	
	@FindBy(xpath="//*[@id='registerFirstName']")
	private WebElementFacade txtfirstname;

	@FindBy(xpath="//*[@id='registerLastName']")
	private WebElementFacade txtlastname;

	@FindBy(xpath="//*[@id='registerCountryCode']")
	private WebElementFacade txtcountryCode;

	@FindBy(xpath="//*[@id='registerAreaCode']")
	private WebElementFacade txtareaCode;

	@FindBy(xpath="//*[@id='registerPhonNum']")
	private WebElementFacade txtphoneNumber;
	
	@FindBy(xpath="//*[@id='registerPhoneExt']")
	private WebElementFacade txtExt;

	@FindBy(xpath="//*[@id='registerCountry']")
	private WebElementFacade dropdowncountry;

	@FindBy(xpath="//*[@id='registerUrl']")
	private WebElementFacade txtCompanyWebsite;
	
	@FindBy(xpath="//*[@id='register-form']//a[text() = 'Terms and Conditions']")
	private WebElementFacade termsandconditions;

	@FindBy(xpath="//*[@id='registration_body']")
	private WebElementFacade termsandconditionsBody;
	
	@FindBy(xpath="//*[@id='agreeButton']")
	private WebElementFacade btnAgree;

	@FindBy(xpath="//*[@id='button-register']")
	private WebElementFacade btnRegister;

	@FindBy(xpath="//*[@id='userRegisterSuccess']/h3")
	private WebElementFacade regSucessMsg;
	
	@FindBy(xpath="//*[@id='registerConErrorMessages']")
	private WebElementFacade regErrorMsg;

	@FindBy(xpath="//*[@id='iamcheckregister']")
	private WebElementFacade regMandCheckMsg;
	
		
	@FindBy(xpath="//*[@id='interactive']/div[1]")
	private WebElementFacade imgLoading;
		
		
    /***********************************************************************************
	 * Function: Click on RegisterLink 
	 * Input : email id
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public void clickRegister()
	{
		linkregister.click();
		UIHelper.waitForPageToLoad(getDriver());
		btnRegister.waitUntilClickable();
	}
    /***********************************************************************************
	 * Function: Fill registration form
	 * Input : registration form mandatory fields
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public void fillRegistrationForm(String email,String prefix,String firstname,String lastName,String counryCode,String aredCode,String phoneNum,String extn,String country,String compWebsite)
	{
		enterEmail(email);
		setPrefix(prefix);
		enterFirstName(firstname);
		enterLasttName(lastName);
		enterCountryCode(counryCode);
		enterAreaCode(aredCode);
		enterPhoneNum(phoneNum);
		setExtNum(extn);
		selectCountry(country);
		setCompanyWebsite(compWebsite);
		
	}

    /***********************************************************************************
	 * Function: Enter the email in Email text box 
	 * Input : email id
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public void enterEmail(String email)	
	{
		txtemailId.waitUntilEnabled();
		txtemailId.sendKeys(email);
	}
	
    /***********************************************************************************
	 * Function: Select the Prefix. 
	 * Input : prefix
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public void setPrefix(String prefix)	
	{
		dropdownPrefix.waitUntilEnabled();
//		dropdownPrefix.selectByVisibleText(prefix);
		dropdownPrefix.sendKeys(prefix);
	}

    /***********************************************************************************
	 * Function: Enter the firstname in Firstname text box 
	 * Input : firstname
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public void enterFirstName(String firstname)	
	{
		txtfirstname.waitUntilEnabled();
		txtfirstname.sendKeys(firstname);
	}

    /***********************************************************************************
	 * Function: Enter the lastname in lastname text box 
	 * Input : firstname
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public void enterLasttName(String lastname)	
	{
		txtlastname.waitUntilEnabled();
		txtlastname.sendKeys(lastname);
	}

    /***********************************************************************************
	 * Function: Enter the country code in country text box 
	 * Input : country code
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public void enterCountryCode(String ccode)
	{
//		Select sel = new Select(txtcountryCode);
		txtcountryCode.waitUntilEnabled();
		txtcountryCode.sendKeys(ccode);
	}

    /***********************************************************************************
	 * Function: Enter the area code in area text box 
	 * Input : area code
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public void enterAreaCode(String aCode)
	{
		txtareaCode.waitUntilEnabled();
		txtareaCode.sendKeys(aCode);
	}
	
    /***********************************************************************************
	 * Function: Enter the phone number in phone number box 
	 * Input : phone number
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public void enterPhoneNum(String phoneNum)	
	{
		txtphoneNumber.waitUntilEnabled();
		txtphoneNumber.sendKeys(phoneNum);
	}


    /***********************************************************************************
	 * Function: Enter the Extension number in extension box 
	 * Input : phone number
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public void setExtNum(String extnum)	
	{
		txtExt.waitUntilEnabled();
		txtExt.sendKeys(extnum);
	}
		
	/***********************************************************************************
	 * Function: Enter the phone number in phone number box 
	 * Input : phone number
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public void selectCountry(String country)
	{
		dropdowncountry.waitUntilEnabled();
//		dropdowncountry.selectByVisibleText(country);
		dropdowncountry.sendKeys(country);
	}

    /***********************************************************************************
	 * Function: Enter the company website 
	 * Input : website
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public void setCompanyWebsite(String compWebsite)
	{
		txtCompanyWebsite.waitUntilEnabled();
		txtCompanyWebsite.sendKeys(compWebsite);
	}
	
	/***********************************************************************************
	 * Function: click on the terms and condition link text 
	 * Input : NA
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public void clickTermsAndCondition()
	{
		termsandconditions.waitUntilEnabled();
		termsandconditions.click();
		termsandconditionsBody.waitUntilVisible();
		btnAgree.waitUntilEnabled();
	}

	/***********************************************************************************
	 * Function: get term and conditons popup visibility 
	 * Input : NA
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public boolean getTermsAndConditionPopUpDisplayed()
	{		
		return termsandconditionsBody.isCurrentlyVisible();				
	}

	/***********************************************************************************
	 * Function: click on the Agree button 
	 * Input : NA
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public void acceptTermsAndCondtion()
	{
		btnAgree.click();
		btnAgree.waitUntilNotVisible();
		btnRegister.waitUntilClickable();
	}

	/***********************************************************************************
	 * Function: click on the Register button 
	 * Input : NA
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public void submitRegister()
	{
		UIHelper.waitForPageToLoad(getDriver());
		btnRegister.click();
		while(!regSucessMsg.isCurrentlyVisible() && !regErrorMsg.isCurrentlyVisible() && !regMandCheckMsg.isCurrentlyVisible())
		{
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	/***********************************************************************************
	 * Function: get the Register button visibility 
	 * Input : NA
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public boolean getRegisterVisibility()
	{
		return btnRegister.isDisplayed();
	}

	/***********************************************************************************
	 * Function: get registration sucess message visibility 
	 * Input : NA
	 * Action: NA
	 * Output : NA
	***********************************************************************************/
	public boolean getRegSucessMsgDisplayed()
	{
		return regSucessMsg.isCurrentlyVisible();
	}
	
	
}
