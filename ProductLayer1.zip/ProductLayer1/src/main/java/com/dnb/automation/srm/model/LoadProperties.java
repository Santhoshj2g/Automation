package com.dnb.automation.srm.model;



import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

public class LoadProperties 
{
	@SuppressWarnings("resource")
	public Properties CommentryMapping(){
		    Properties commentryprop = new Properties ();
		    InputStream is = null;

		    // First try loading from the current directory
		    try {
		        File f = new File("/src/test/resources/AppTestData/SRM/CommentryMapping.properties");
		        is = new FileInputStream( f );
		    }
		    catch ( Exception e ) { e.printStackTrace();is = null; }

		    try {
		        if ( is == null ) {
		            // Try loading from classpath
		            is = getClass().getResourceAsStream("/src/test/resources/AppTestData/SRM/CommentryMapping.properties");
//		            ClassLoader classLoader = getClass().getClassLoader();
//		            File configurationFile = new File(classLoader.getResource(CONFIGURATION_FILE_NAME).getFile());
		        }

		        // Try loading properties from the file (if found)
		        commentryprop.load( is );
		    }
		    catch ( Exception e ) { e.printStackTrace();}
			return commentryprop;
		}
	
	@SuppressWarnings("resource")
	public Properties SERBackgroundColorMapping()
	{
		  Properties serBackcolorprop = new Properties ();
		    InputStream is = null;

		    // First try loading from the current directory
		    try {
		        File f = new File("src/test/resources/AppTestData/SRM/SERBackgroundColorMapping.properties");
		        is = new FileInputStream( f );
		    }
		    catch ( Exception e ) { e.printStackTrace();is = null; }

		    try {
		        if ( is == null ) {
		            // Try loading from classpath
		            is = getClass().getResourceAsStream("src/test/resources/AppTestData/SRM/SERBackgroundColorMapping.properties");
//		            ClassLoader classLoader = getClass().getClassLoader();
//		            File configurationFile = new File(classLoader.getResource(CONFIGURATION_FILE_NAME).getFile());
		        }

		        // Try loading properties from the file (if found)
		        serBackcolorprop.load( is );
		    }
		    catch ( Exception e ) { e.printStackTrace();}
			return serBackcolorprop;
	}

    public Properties LoadPropertiesSpain(){
        Properties commentryprop = new Properties();
        InputStream is = null;
        InputStreamReader input = null;

        // First try loading from the current directory
        try {
            File f = new File("src/test/resources/AppTestData/SRM/CommentryMappingSpain.properties");
            is = new FileInputStream(f);
            //input= new InputStreamReader(is,"UTF-8");
        }
        catch ( Exception e ) { e.printStackTrace();is = null; }

        try {
            if ( is == null ) {
                // Try loading from classpath
                is = getClass().getResourceAsStream("src/test/resources/AppTestData/SRM/CommentryMappingSpain.properties");
//		            ClassLoader classLoader = getClass().getClassLoader();
//		            File configurationFile = new File(classLoader.getResource(CONFIGURATION_FILE_NAME).getFile());
            }

            // Try loading properties from the file (if found)
            commentryprop.load( is );
        }
        catch ( Exception e ) { e.printStackTrace();}
        return commentryprop;
    }

	public Properties LoadPropertiesSlovenia(){
		Properties commentryprop = new Properties();
		InputStream is = null;
		InputStreamReader input = null;

		// First try loading from the current directory
		try {
			File f = new File("src/test/resources/AppTestData/SRM/CommentryMappingSlovenia.properties");
			is = new FileInputStream(f);
			//input= new InputStreamReader(is,"UTF-8");
		}
		catch ( Exception e ) { e.printStackTrace();is = null; }

		try {
			if ( is == null ) {
				// Try loading from classpath
				is = getClass().getResourceAsStream("src/test/resources/AppTestData/SRM/CommentryMappingSlovenia.properties");
//		            ClassLoader classLoader = getClass().getClassLoader();
//		            File configurationFile = new File(classLoader.getResource(CONFIGURATION_FILE_NAME).getFile());
			}

			// Try loading properties from the file (if found)
			commentryprop.load( is );
		}
		catch ( Exception e ) { e.printStackTrace();}
		return commentryprop;
	}

}


