package com.dnb.automation.imreg.pages;

import java.io.File;
import java.util.List;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.WebElement;

import com.dnb.automation.utils.UIHelper;

public class FileImportPage extends PageObject {
	
	@FindBy(xpath="//*[@id='i3']/h3")
	private WebElementFacade importIcon;
	
	@FindBy(xpath="//*[contains(text(),'File Import')]")
	private WebElementFacade fileImport;
	
	@FindBy(xpath = "//input[@type='file']")
	private WebElementFacade upload;
	
	@FindBy(xpath="//*[text()='Continue']")
	private WebElementFacade continueBtn;
	
	@FindBy(xpath = "//*[@id='delimitOptionId']//select[@name='delimiter']//option")
	private List<WebElement> typeDelimiter;

	@FindBy(xpath = "//*[@id='pageSheet']//*[@id='grid']//input[@id='firstrow']")
	private WebElementFacade checkBoxForColumn;

	@FindBy(xpath = "//*[@id='toolbar2']//*[contains(text(),'Continue')]")
	private WebElementFacade continueTonext;

	@FindBy(xpath = "//*[@class='gridForm']//input[@name='tableName']")
	private WebElementFacade tableName;

	@FindBy(xpath = "//*[@id='toolbar']//*[contains(text(),'Import')]")
	private WebElementFacade importBtnforCmplt;
	
	@FindBy(xpath = "//*[@id='banner_top_part']//*[@id='tblNav']//*/a[contains(.,'Home')]")
	private WebElementFacade homeLink;
	
	public void clickImportBtn() throws Exception
	{
		try {
		getDriver().switchTo().frame("Main");
		importIcon.waitUntilClickable();
		importIcon.click();
		} 
		catch (Exception e) { 
			throw e;
		}
	}
	
	public boolean verifyFileImportPageDisplayed() throws Exception
	{
		fileImport.waitUntilVisible();
		if(fileImport.isDisplayed())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void selectInputFile() throws Exception
	{
		try {
		File file = new File(
				"c://Automation//IMv7.0//Regression_Batch//Input");
		File[] fileArray = file.listFiles();
		for (File f : fileArray) {
			if (f.isFile()) {
				upload.sendKeys(f.getAbsolutePath());
				Thread.sleep(5000);
			}
		}
	  } catch (Exception e) {
		e.printStackTrace();
	 }	
   }
	
	public void clckContinue() throws Exception
	{
		try {
			continueBtn.waitUntilClickable();
			continueBtn.click();
			UIHelper.waitForPageToLoad(getDriver());
		} catch (Exception e) {
			throw e;
		}
	}
	
	public boolean verifyFileFormatPageDisplayed()
	{
		fileImport.waitUntilVisible();
		if(fileImport.isDisplayed())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void fileFormat() throws Exception
	{
		try {
			checkBoxForColumn.click();
			Thread.sleep(2000);
			for (WebElement element : typeDelimiter) {
				if (element.getText().trim().contains("Verticalbar")) {
					element.click();
					Thread.sleep(3000);
				}
			}	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void selectContinue() throws Exception
	{
		try {
			continueTonext.waitUntilClickable();
			continueTonext.click();
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void createTable(String tableNames) throws Exception
	{
		try {
			tableName.waitUntilClickable();
			tableName.type(tableNames);
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}
	
	public void clckImport() throws Exception
	{
		try {
			importBtnforCmplt.click();
			getDriver().switchTo().alert().accept();
			Thread.sleep(10000);
			getDriver().switchTo().alert().accept();
			getDriver().switchTo().defaultContent();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean verifyImportingPageDisplayed() throws Exception
	{
		fileImport.waitUntilVisible();
		if(fileImport.isDisplayed())
		{
			getDriver().switchTo().defaultContent();
			return true;
		}
		else
		{
			return false;
		}
	}
	

}
