package com.dnb.automation.dnbcom.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;
import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * InfoPage.java - Program consists of the following actions 1. Clicking on the
 * button Proceed to the site 2. Verifying navigation to the Home page
 *
 * @author Kumaran Balasubramaniam
 ***********************************************************************************************/

public class InfoPage extends PageObject {
    // Locators for elements Proceed to the site Button and Home page element
    // (next page element)

    @FindBy(xpath = ".//input[@name='PrefNoShow']/../a")
    private WebElementFacade proceedButton;

    @FindBy(xpath = "//img[@alt='Company Reports']/..")
    private WebElementFacade homePage;

    // To click Proceed to the site button

    public void clickProceedButton() throws Exception {
        try {
            if (proceedButton.isPresent()) {
                UIHelper.highlightElement(getDriver(), proceedButton);
                proceedButton.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    // To wait for the Home page navigation

    public void waitForHomePage() throws Exception {
        try {
            homePage.waitUntilPresent();
        } catch (Exception e) {
            throw e;
        }
    }

    // To verify Home page element

    public boolean hasHomePageElement() {
        if (homePage.isPresent()) {
            return true;
        } else {
            return false;
        }
    }
}
