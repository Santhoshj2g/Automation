package com.dnb.automation.dnbi.pages;

import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class AdminPageFieldsPage extends PageObject{
	
	@FindBy(xpath="//*[@id='header_mainApp']//*[@id='primaryNav']//*[contains(text(),'Admin')]")
	private WebElementFacade adminTab;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/ul[1]/li[1]/a/strong")
	private WebElementFacade administerUsers;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/ul[1]/li[2]/a/strong")
	private WebElementFacade defineFieldRanges;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/ul[1]/li[3]/a/strong")
	private WebElementFacade setCreditBureauAccess;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/ul[2]/li[1]/a/strong")
	private WebElementFacade documentsLink;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/ul[2]/li[2]/a/strong")
	private WebElementFacade usageSummary;
	
	@FindBy(xpath="html/body/div[2]/p/a")
	private WebElementFacade takeTour;
	
	@FindBy(xpath="//*[@id='main']/div[2]/ul/li[2]/a")
	private WebElementFacade accountManagerAdmin;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/table[1]/tbody/tr/td[2]/b/a")
	private WebElementFacade manageAccountFields;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/table[2]/tbody/tr/td[2]/b/a")
	private WebElementFacade buildAccountScore;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/table[3]/tbody/tr/td[2]/b/a")
	private WebElementFacade creditLimitTerms;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/table[4]/tbody/tr/td[2]/b/a")
	private WebElementFacade setAccountReviewRules;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[4]/table[1]/tbody/tr/td[2]/b/a")
	private WebElementFacade importAccountData;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[4]/table[2]/tbody/tr/td[2]/b/a")
	private WebElementFacade reviewAccounts;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[4]/table[3]/tbody/tr/td[2]/b/a")
	private WebElementFacade reScoreAccounts;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[4]/table[4]/tbody/tr/td[2]/b/a")
	private WebElementFacade clearAccountStatus;
	
	@FindBy(xpath="//*[@id='main']/div[2]/ul/li[3]/a")
	private WebElementFacade creditApplicationsAdmin;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/table[1]/tbody/tr/td[2]/a/b")
	private WebElementFacade configureCreditAppln;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/table[2]/tbody/tr/td[2]/b/a")
	private WebElementFacade buildApplicationScore;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/table[3]/tbody/tr/td[2]/b/a")
	private WebElementFacade defineCreditLimit;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/table[4]/tbody/tr/td[2]/b/a")
	private WebElementFacade setDecisionMakerRules;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/table[5]/tbody/tr/td[2]/a")
	private WebElementFacade manageNotifications;
	
	@FindBy(xpath="//*[@id='main']//*[@class='ecf_toc']//li//a[contains(.,'Data Management')]")
	private WebElementFacade dataManagement;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/ul[1]/li[1]/a")
	private WebElementFacade importData;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/ul[1]/li[2]/a/strong")
	private WebElementFacade deleteCreditFiles;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/ul[1]/li[3]/a/strong")
	private WebElementFacade exportData;
	
	@FindBy(xpath="//*[@id='main']//*[@class='ecf_page ad_wid750']//*[@class='widget adminbasic']//*[@class='basicMenu']//strong[contains(.,'Fraud/Write-Off')]")
	private WebElementFacade fraudWrite;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/ul[2]/li[1]/a/strong")
	private WebElementFacade fieldRanges;
	
	@FindBy(xpath="//*[@id='main']/div[3]/div[3]/ul[2]/li[2]/a/strong")
	private WebElementFacade financialStatementOptions;
	@FindBy(xpath="//*[@id='main']//div[contains(.,'Fraud/Write-Off for Decisioning')]//*[@id='fraudYes']")
	private WebElementFacade enablefraudwrite;
	@FindBy(xpath="//*[@id='main']//div[contains(.,'Fraud/Write-Off for Decisioning')]//*[@id='fraudNo']")
	private WebElementFacade disablefraudwrite;
	@FindBy(xpath="//*[@id='main']//*[@class='btn btnPrimary bold']")
	private WebElementFacade fradwritesubmit;
	@FindBy(xpath="//*[@class='modal']//*[@class='modal_content']//*[@class='modal_buttons']//input[@class='btn bold btnPrimary'][@type='submit']")
	private WebElementFacade fradwritesubmitalert;
	
	public void navigateToAdmin(){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), adminTab);
		adminTab.click();
	}
	
	public boolean administerUserIsDisplayed(){
		administerUsers.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), administerUsers);
		return administerUsers.isDisplayed();
	}
	
	public boolean defineFieldRangesIsDisplayed(){
		defineFieldRanges.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), defineFieldRanges);
		return defineFieldRanges.isDisplayed();
	}
	
	public boolean setCreditBureauAccessIsDisplayed(){
		setCreditBureauAccess.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), setCreditBureauAccess);
		return setCreditBureauAccess.isDisplayed();
	}
	
	public boolean documentsLinkIsDisplayed(){
		documentsLink.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), documentsLink);
		return documentsLink.isDisplayed();
	}
	
	public boolean usageSummaryIsDisplayed(){
		usageSummary.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), usageSummary);
		return usageSummary.isDisplayed();
	}
	
	public boolean takeTourIsDisplayed(){
		takeTour.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), takeTour);
		if(takeTour.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public void navigateAccountManagerAdmin(){
		accountManagerAdmin.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), accountManagerAdmin);
		accountManagerAdmin.click();
	}
	
	public boolean manageAccountFieldsIsDisplayed(){
		manageAccountFields.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), manageAccountFields);
		if(manageAccountFields.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean buildAccountScoreIsDisplayed(){
		buildAccountScore.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), buildAccountScore);
		if(buildAccountScore.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean creditLimitTermsIsDisplayed(){
		creditLimitTerms.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), creditLimitTerms);
		if(creditLimitTerms.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean setAccountReviewRulesIsDisplayed(){
		setAccountReviewRules.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), setAccountReviewRules);
		if(setAccountReviewRules.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean importAccountDataIsDisplayed(){
		importAccountData.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), importAccountData);
		if(importAccountData.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean reviewAccountsIsDisplayed(){
		reviewAccounts.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), reviewAccounts);
		if(reviewAccounts.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean reScoreAccountsIsDisplayed(){
		reScoreAccounts.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), reScoreAccounts);
		if(reScoreAccounts.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean clearAccountStatusIsDisplayed(){
		clearAccountStatus.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), clearAccountStatus);
		if(clearAccountStatus.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public void creditApplicationsAdmin(){
		creditApplicationsAdmin.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), creditApplicationsAdmin);
		creditApplicationsAdmin.click();
	}
	
	public boolean configureCreditApplnAppIsDisplayed(){
		configureCreditAppln.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), configureCreditAppln);
		if(configureCreditAppln.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean buildApplicationScoreIsDisplayed(){
		buildApplicationScore.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), buildApplicationScore);
		if(buildApplicationScore.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean defineCreditLimitIsDisplayedAppln(){
		defineCreditLimit.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), defineCreditLimit);
		if(defineCreditLimit.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean setDecisionMakerRulesIsDisplayed(){
		setDecisionMakerRules.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), setDecisionMakerRules);
		if(setDecisionMakerRules.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean manageNotificationsIsDisplayed(){
		manageNotifications.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), manageNotifications);
		if(manageNotifications.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public void dataManagement(){
		dataManagement.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), dataManagement);
		dataManagement.click();
	}
	
	public boolean importDataIsDisplayed(){
		importData.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), importData);
		if(importData.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean deleteCreditFilesIsDisplayed(){
		deleteCreditFiles.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), deleteCreditFiles);
		if(deleteCreditFiles.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean exportDataDisplayed(){
		exportData.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), exportData);
		if(exportData.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean fraudWriteIsDisplayed(){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), adminTab);
		adminTab.click();
UIHelper.highlightElement(getDriver(), dataManagement);
		dataManagement.click();
		UIHelper.highlightElement(getDriver(), fraudWrite);
		if(fraudWrite.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	public boolean click_fraudWrite(){
		fraudWrite.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), fraudWrite);
		if(fraudWrite.isDisplayed()){
			fraudWrite.click();
			return true;
		}
		else 
			return false;
	}
	public void enablefraudWrite(String Option){
		enablefraudwrite.waitUntilClickable();
		if(Option.contains("Yes")){
			UIHelper.highlightElement(getDriver(), enablefraudwrite);
			enablefraudwrite.click();
		}
		else if (Option.contains("No")){
			UIHelper.highlightElement(getDriver(), disablefraudwrite);
			disablefraudwrite.click();
		}
	}
	
	public boolean fieldRangesIsDisplayed(){
		fieldRanges.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), fieldRanges);
		if(fieldRanges.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean financialStatementOptionsIsDisplayed(){
		financialStatementOptions.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), financialStatementOptions);
		if(financialStatementOptions.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
}
