package com.dnb.automation.dnbcom.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;
import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * HomePage.java - Program consists of the following actions 1. Clicking on the
 * link Company Reports 2. Verifying navigation to the Company reports domestic
 * search page
 *
 * @author Kumaran Balasubramaniam
 ***********************************************************************************************/

public class HomePage extends PageObject {
    // Locators for the elements Company Report Link and Company Report Page
    // element (next page element)

    @FindBy(xpath = "//img[@alt='Company Reports']/..")
    private WebElementFacade companyreport;

    @FindBy(xpath = "//input[@name='INPUTDUNS']")
    private WebElementFacade searchpage;

    // To click on the link Company Report

    public void clickCompanyReportLink() throws Exception {
        try {
            if (companyreport.isPresent()) {
                UIHelper.highlightElement(getDriver(), companyreport);
                companyreport.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    // To wait for the navigation of Company Report domestic search Page

    public void waitForSearchPage() throws Exception {
        try {
            searchpage.isPresent();
        } catch (Exception e) {
            throw e;
        }
    }
}
