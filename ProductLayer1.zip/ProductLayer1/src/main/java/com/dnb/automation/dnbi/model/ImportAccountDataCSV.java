package com.dnb.automation.dnbi.model;

/**********************************************************************************************
 * ImportAccountDataCSV.java - This class contains getter and setter methods for
 * ImportAccountData.csv file columns
 * 
 * @author Duvvuru Naveen
 * @version 1.0
 ***********************************************************************************************/
public class ImportAccountDataCSV {

    private String AccountNumber;
    private String DUNSNumber;
    private String BusinessName;
    private String StateProvince;
    private String Country;
    private Float Current;
    private Float From1to30DaysPastDue;
    private Float From31to60DaysPastDue;
    private Float From61to90DaysPastDue;
    private Float From91to120DaysPastDue;
    private Float From91PlusDaysPastDue;
    private Float From121to150DaysPastDue;
    private Float MoreThan151DaysPastDue;
    private Float TotalOutstanding;

    public String getAccountNumber() {
        return AccountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        AccountNumber = accountNumber;
    }

    public String getDUNSNumber() {
        return DUNSNumber;
    }

    public void setDUNSNumber(String dUNSNumber) {
        DUNSNumber = dUNSNumber;
    }

    public String getBusinessName() {
        return BusinessName;
    }

    public void setBusinessName(String businessName) {
        BusinessName = businessName;
    }

    public String getStateProvince() {
        return StateProvince;
    }

    public void setStateProvince(String stateProvince) {
        StateProvince = stateProvince;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String country) {
        Country = country;
    }

    public Float getCurrent() {
        return Current;
    }

    public void setCurrent(Float current) {
        Current = current;
    }

    public Float getFrom1to30DaysPastDue() {
        return From1to30DaysPastDue;
    }

    public void setFrom1to30DaysPastDue(Float from1to30DaysPastDue) {
        From1to30DaysPastDue = from1to30DaysPastDue;
    }

    public Float getFrom31to60DaysPastDue() {
        return From31to60DaysPastDue;
    }

    public void setFrom31to60DaysPastDue(Float from31to60DaysPastDue) {
        From31to60DaysPastDue = from31to60DaysPastDue;
    }

    public Float getFrom61to90DaysPastDue() {
        return From61to90DaysPastDue;
    }

    public void setFrom61to90DaysPastDue(Float from61to90DaysPastDue) {
        From61to90DaysPastDue = from61to90DaysPastDue;
    }

    public Float getFrom91to120DaysPastDue() {
        return From91to120DaysPastDue;
    }

    public void setFrom91to120DaysPastDue(Float from91to120DaysPastDue) {
        From91to120DaysPastDue = from91to120DaysPastDue;
    }

    public Float getFrom91PlusDaysPastDue() {
        return From91PlusDaysPastDue;
    }

    public void setFrom91PlusDaysPastDue(Float from91PlusDaysPastDue) {
        From91PlusDaysPastDue = from91PlusDaysPastDue;
    }

    public Float getFrom121to150DaysPastDue() {
        return From121to150DaysPastDue;
    }

    public void setFrom121to150DaysPastDue(Float from121to150DaysPastDue) {
        From121to150DaysPastDue = from121to150DaysPastDue;
    }

    public Float getMoreThan151DaysPastDue() {
        return MoreThan151DaysPastDue;
    }

    public void setMoreThan151DaysPastDue(Float moreThan151DaysPastDue) {
        MoreThan151DaysPastDue = moreThan151DaysPastDue;
    }

    public Float getTotalOutstanding() {
        return TotalOutstanding;
    }

    public void setTotalOutstanding(Float totalOutstanding) {
        TotalOutstanding = totalOutstanding;
    }
}
