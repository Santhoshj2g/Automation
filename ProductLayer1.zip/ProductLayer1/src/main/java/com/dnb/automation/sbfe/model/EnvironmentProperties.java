package com.dnb.automation.sbfe.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class EnvironmentProperties {
	@SuppressWarnings("resource")
	public Properties EnvironmentProperties(){
		    Properties environmentProp = new Properties ();
		    InputStream is = null;

		    // First try loading from the current directory
		    try {
		        File f = new File("src/test/resources/AppTestData/SBFE/EnvironmentProperties/EnvironmentProperties.properties");
		        is = new FileInputStream( f );
		    }
		    catch ( Exception e ) { e.printStackTrace();is = null; }

		    try {
		        if ( is == null ) {
		            // Try loading from classpath
		            is = getClass().getResourceAsStream("src/test/resources/AppTestData/SBFE/EnvironmentProperties/EnvironmentProperties.properties");
//		            ClassLoader classLoader = getClass().getClassLoader();
//		            File configurationFile = new File(classLoader.getResource(CONFIGURATION_FILE_NAME).getFile());
		        }

		        // Try loading properties from the file (if found)
		        environmentProp.load( is );
		    }
		    catch ( Exception e ) { e.printStackTrace();}
			return environmentProp;
		}
}