package com.dnb.automation.sba.pages;

import java.util.Map;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.sba.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class suppFamilyWithDiversityPage extends PageObject{

	/*Supplier Family WebElements*/
	int totalDuns;

	@FindBy(xpath = "//*[@id='supplierFamily']/a")
	private WebElementFacade supplierFamily;

	@FindBy(xpath ="//*[@id='ui-id-7']")
	private WebElementFacade analysisSubTab;

	@FindBy(xpath ="//*[@id='analysisFilter-button']/span[1]")
	private WebElementFacade filter;

	@FindBy(xpath ="//*[@id='analysisFilter-menu']/li[4]/a")
	private WebElementFacade diversity;

	@FindBy(xpath ="//a[contains(text(),'Woman Owned')]")
	private WebElementFacade womanOwned;

	@FindBy(xpath ="//*[@id='SfAnalysisTotalCount']")
	private WebElementFacade totalRecords;

	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[2]")
	private WebElementFacade dunsNumber;

	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[3]")
	private WebElementFacade spend;

	@FindBy(xpath ="//*[@id='supplierAnalysis-ManageBtn']")
	private WebElementFacade manageCols;

	@FindBy(xpath ="//*[@id='manageColumnsTreeViewAnalysis']/ul/li[1]/span/a")
	private WebElementFacade cmpnyProfile_DS;

	@FindBy(xpath ="//*[@id='manageColumnsTreeViewAnalysis']/ul/li[2]/span/a")
	private WebElementFacade corpLinkage_DS;

	@FindBy(xpath ="//*[@id='manageColumnsTreeViewAnalysis']/ul/li[6]/span/a")
	private WebElementFacade socialResp_DS;

	@FindBy(xpath ="//*[@id='manageColumnsTreeViewAnalysis']/ul/li[7]/span/a")
	private WebElementFacade spend_DS;

	@FindBy(xpath ="//*[@id='manageColumnsTreeViewAnalysis']/ul/li[5]/span/a")
	private WebElementFacade risk_DS;

	@FindBy(xpath ="//*[@id='manageColumnsTreeViewAnalysis']/ul/li[3]/span/a")
	private WebElementFacade diversity_DS;

	@FindBy(xpath ="//*[@id='manageColumn-addbtnAnalysis']")
	private WebElementFacade manageColAddBtn;

	@FindBy(xpath ="//*[@id='manageColumn-applyBtnAnalysis']")
	private WebElementFacade applyBtn;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[4]/ul/li[1]/span/a")
	private WebElementFacade forestryServices;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[4]/ul/li[2]/span/a")
	private WebElementFacade timberTracts;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[1]/span/span[1]")
	private WebElementFacade parentItem;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[1]/ul/li[1]/span/a")
	private WebElementFacade WomanOwnedSB;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[1]/ul/li[2]/span/a")
	private WebElementFacade WomanOwnedBE;

	@FindBy(xpath ="//*[@id='100']")
	private WebElementFacade itemsPerPage;

	@FindBy(xpath ="//*[@id='dynaPagHolder']/div[1]/div/a[2]")
	private WebElementFacade nextPage;

	@FindBy(xpath ="//*[@id='block_jump_valSF']")
	private WebElementFacade pageNum;

	@FindBy(xpath ="//*[@id='supplierAnalysis-DownloadListBtn']")
	private WebElementFacade export;

	@FindBy(xpath ="//*[@id='gridExcel']")
	private WebElementFacade exportToExcel;

	/*Diversity WebElements*/
	int totalDunsOfDiversity;

	@FindBy(xpath ="//*[@id='diversity']/a")
	private WebElementFacade diversityTab;

	@FindBy(xpath ="//*[@id='ui-id-7']")
	private WebElementFacade analysisTabOfDiversity;

	@FindBy(xpath ="//*[@id='analysisFilter-button']/span[1]")
	private WebElementFacade filterOfBU;

	@FindBy(xpath ="//*[@id='searchInpDIV']")
	private WebElementFacade diversityCategory;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[4]/span/a")
	private WebElementFacade agriculturalProductionCropsOfBU;

	@FindBy(xpath ="//*[@id='DiAnalysisTotalCount']")
	private WebElementFacade totalRecordsOfDiversity;

	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[2]")
	private WebElementFacade dunsOfDiversity;

	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[3]")
	private WebElementFacade spendOfDiversity;

	@FindBy(xpath ="//*[@id='manageColumn-addbtnAnalysis']")
	private WebElementFacade manageColAddBtnDiversity;

	@FindBy(xpath ="//*[@id='supplierAnalysisPiecontainer']//*[@class='highcharts-container']//*[contains(@class,'highcharts-data-labels highcharts-tracker')]//*//*//*[contains(.,'Woman Owned')]")
	private WebElementFacade womanOwnedOfDiversity;

	@FindBy(xpath ="//*[@id='supplierAnalysisPiecontainer']//*[@class='highcharts-container']//*[contains(@class,'highcharts-data-labels highcharts-tracker')]//*//*//*[contains(.,'Woman Owned Sma...')]")
	//@FindBy(xpath ="//*[@id='highcharts-100']/*[name()='svg']/*[name()='g'][1]/*[name()='g'][1]/*[name()='path'][2]")
	private WebElementFacade womanOwnedSBOfDiversity;

	@FindBy(xpath ="//*[@id='supplierAnalysisPiecontainer']//*[@class='highcharts-container']//*[contains(@class,'highcharts-data-labels highcharts-tracker')]//*//*//*[contains(.,'Woman Owned Bus...')]")
	//@FindBy(xpath ="//*[@id='highcharts-100']/*[name()='svg']/*[name()='g'][1]/*[name()='g'][1]/*[name()='path'][1]")
	private WebElementFacade womanOwnedBEOfDiversity;

	@FindBy(xpath ="//*[@id='dynaBlockHolder']/div[1]/div/a[2]")
	private WebElementFacade nextPageOfDiversity;

	@FindBy(xpath ="(//*[@id='100'])[2]")
	private WebElementFacade itemsPerPageDiversity;

	@FindBy(xpath ="//*[@id='dynaBlockHolder']//*[@id='block_jump_valGrid']")
	private WebElementFacade pageNumDiversity;
	
	@FindBy(xpath ="//*[@id='block_jumpGrid']")
	private WebElementFacade goButtonOfDiversity;

	public void chooseDiversity(){
		filter.click();
		diversity.click();
	}

	public void clickOnParentItem(){
		UIHelper.switchToTab(getDriver(),"supplierFamily");
		String pNodeSF="(//*[@id='analysisTreeView']//*[@class='dynatree-container']//*[@class='dynatree-expander'])[1]";
		UIHelper.clickAnElement(getDriver(), pNodeSF);
	}


	public int getTotalRecords(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDuns=UIHelper.getTotalRecords(totalRecords);
		System.out.println("getTotalRecords :"+totalDuns);
		return UIHelper.getTotalRecords(totalRecords);
	}

	public boolean isTotalRecDisplayed()
	{
		return UIHelper.isElementDisplayed(totalRecords);
	}

	public Map<String,String> getSpendValue(){
		UIHelper.switchToTab(getDriver(),"supplierFamily");
		String preXpath="//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.clickAnElement(itemsPerPage);
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDuns, nextPage);
	}

	public Map<String, String> getSpendValueOfChild(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDuns=UIHelper.getTotalRecords(totalRecords);
		UIHelper.clickAnElement(itemsPerPage);
		return getSpendAfterAddcols();
	}

	public Map<String,String> getSpendAfterAddcols(){
		String preXpath="//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDuns, nextPage);
	}

	/*Diversity page*/

	public void clickOnDiversity(){
		String URL=getDriver().getCurrentUrl();
		UIHelper.openInNewTab(getDriver(),URL);
		UIHelper.clickAnElement(diversityTab);
	}

	public void clickOnAnalysisTabofDiversity(){
		UIHelper.clickAnElement(analysisTabOfDiversity);
	}

	public void clickOnParentItemInDiversity(){
		UIHelper.switchToTab(getDriver(),"notSF");
		UIHelper.clickAnElement(womanOwnedOfDiversity);
		UIHelper.waitForVisibilityOfElement(womanOwnedSBOfDiversity);
	}

	public int getTotalRecordsOfDiversity(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDunsOfDiversity=UIHelper.getTotalRecords(totalRecordsOfDiversity);
		System.out.println("getTotalRecordsOfDiversity :"+totalDunsOfDiversity);
		return UIHelper.getTotalRecords(totalRecordsOfDiversity);
	}

	public Map<String,String> getSpendValueOfDiversity(){
		UIHelper.switchToTab(getDriver(),"notSF");
		String preXpath="//*[@id='supplierAnalysisTable']//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.clickAnElement(itemsPerPageDiversity);
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDunsOfDiversity, nextPageOfDiversity);
	}

	public Map<String, String> getSpendValueOfChildInDiversity(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDunsOfDiversity=UIHelper.getTotalRecords(totalRecordsOfDiversity);
		UIHelper.clickAnElement(itemsPerPageDiversity);
		return getSpendAfterAddColsOfDiversity();
	}

	public void clickOnManageColsOfDiversity(){
		UIHelper.switchToTab(getDriver(),"notSF");
		UIHelper.gotoFirstPage(pageNumDiversity,goButtonOfDiversity);
		UIHelper.clickAnElement(manageCols);
	}

	public void addColsAndClickApplyOfDiversity(){
		UIHelper.waitForVisibilityOfElement(cmpnyProfile_DS);
		UIHelper.clickAnElement(cmpnyProfile_DS);
		UIHelper.clickAnElement(manageColAddBtnDiversity);

		if(corpLinkage_DS.isPresent())
		{
			UIHelper.clickAnElement(corpLinkage_DS);
			UIHelper.clickAnElement(manageColAddBtnDiversity);
		}
		if(socialResp_DS.isPresent())
		{
			UIHelper.clickAnElement(socialResp_DS);
			UIHelper.clickAnElement(manageColAddBtnDiversity);
		}
		if(spend_DS.isPresent())
		{
			UIHelper.clickAnElement(spend_DS);
			UIHelper.clickAnElement(manageColAddBtnDiversity);
		}
		if(risk_DS.isPresent())
		{
			UIHelper.clickAnElement(risk_DS);
			UIHelper.clickAnElement(manageColAddBtnDiversity);
		}
		if(diversity_DS.isPresent())
		{
			UIHelper.clickAnElement(diversity_DS);
			UIHelper.clickAnElement(manageColAddBtnDiversity);
		}
		UIHelper.clickAnElement(applyBtn);
	}

	public Map<String,String> getSpendAfterAddColsOfDiversity(){
		String preXpath="//*[@id='supplierAnalysisTBody']/tr[";
		System.out.println("before getAllSpendValues");
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDunsOfDiversity, nextPageOfDiversity);
	}

	public void gotoChildItemsOfDiversity()
	{
		UIHelper.clickAnElement(diversityTab);
		UIHelper.clickAnElement(analysisTabOfDiversity);
		UIHelper.clickAnElement(womanOwnedOfDiversity);
	}

	public void clickOnExportToExcelInDiversity(){
		UIHelper.switchToTab(getDriver(), "notSF");
		UIHelper.mouseOveranElement(getDriver(),export);
	}

	public boolean isDataExportedInDiversity(){
		return exportToExcel.isPresent();
	}

}
