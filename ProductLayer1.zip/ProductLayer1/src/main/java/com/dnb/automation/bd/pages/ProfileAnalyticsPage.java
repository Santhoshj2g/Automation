package com.dnb.automation.bd.pages;

import java.util.List;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;

public class ProfileAnalyticsPage extends PageObject{

	//Variable declaration
	private String profile_Name,appearedSearchRes,clickedfromsearchval,connectcountval;	
	String recordcnt;
	
	
	//Xpaths
	
	int i,j,k;
	
	 @FindBy(xpath = "//table[@id='userProfileAnalyticsTableId']/thead/tr/th")
	 private List<WebElementFacade> profileAnalyticsFlds;	
	
	 @FindBy(xpath = "//a[@id='ui-id-1']")
	 private WebElementFacade profileAnalyticsTab;
	 
	 @FindBy(xpath = "//a[contains(text(),'Company Name')]")
	 private WebElementFacade companyNameFld;
	 
	 @FindBy(xpath = "html/body/div[3]/div[1]/div/div/div[3]/div[3]/div/div/table/tbody/tr[2]/td[2]/a")
	 private WebElementFacade appearedinSearchResFld;
	 
	 @FindBy(xpath = "//a[@title='Clicked from Advertisements']")
	 private WebElementFacade clickedFromAddFld;	 
	 
	 @FindBy(xpath = "//a[@title='Clicked from Search Results']")
	 private WebElementFacade clickedFromSearchResFld;	 
	 
	 @FindBy(xpath = "//a[contains(text(),'Connect Count')]")
	 private WebElementFacade connectCountFld;	 
	 
	 @FindBy(xpath = "//span[@title='CHAO SHU ENTERPRISE CO., LTD.']")
	 private WebElementFacade companyNameLink;	 

	 @FindBy(xpath = "//table[@id='userProfileAnalyticsTableId']/tbody/tr/td/a")
	 private List<WebElementFacade> tablevalues;
	 
	 @FindBy(xpath = "//a[@id='companyNameClkId']")
	 private List<WebElementFacade> tableFrame;	 
	 
	 @FindBy(xpath = "//a[contains(text(),'MY ACCOUNT')]")
	 private WebElementFacade myAccTab; 
	 
	 @FindBy(xpath = "html/body/div[5]/div[1]/div/div/div[4]/div[3]/div[1]/div/table/tbody/tr/td/span")
	 private List<WebElementFacade> myAccTableFrm;	

	 @FindBy(xpath = "//h1[@itemprop='legalName']")
	 private WebElementFacade header; 
	
 /***********************************************************************************
 * Function: Verify the Profile Analytics tab
 * Input : NA 
 * Action:  NA
 * Output : NA
***********************************************************************************/
	public void verifyProfileAnalyticsTab()
	{
		if(profileAnalyticsTab.isPresent())
		{
			String tab1=profileAnalyticsTab.getText();
			System.out.println(tab1);			
		}
		int tablecnt=tablevalues.size();
		for(int i=0;i<4;i++)
		{
			String tableval=tablevalues.get(i).getText();
			System.out.println("tableval is"+tableval);
		}
	}	
	/***********************************************************************************
	 * Function: Verify the Company Name field
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public boolean verifyCompanyNameFld()
	{		
		if(companyNameFld.isPresent())
		{
			return true;
		}
		else
		{
			return false;
		}		
	}
	/***********************************************************************************
	 * Function: Verify the Appeared in Search Result field
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public boolean verifyAppearedinSearchRes()
	{
		if(appearedinSearchResFld.isPresent())
		{
			String fld2=appearedinSearchResFld.getText();
			System.out.println(fld2);
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
	 * Function: Verify the Clicked From Search result field
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public boolean verifyClickedFromSearchRes()
	{
		if(clickedFromSearchResFld.isPresent())
		{
			String fld3=clickedFromSearchResFld.getText();
			System.out.println(fld3);
			return true;			
		}
		else
		{
			return false;
		}
	} 
	/***********************************************************************************
	 * Function: Verify the Clicked from Advertisement field
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public boolean verifyClickedFromAd()
	{
		if(clickedFromAddFld.isPresent())
		{
			String fld4=clickedFromAddFld.getText();
			System.out.println(fld4);
			return true;
		}
		else
		{
			return false;
		}
	}
	/***********************************************************************************
	 * Function: Verify the Connect Count field
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public boolean verifyConnectCount()
	{
		if(connectCountFld.isPresent())
		{
			String fld5=connectCountFld.getText();
			System.out.println(fld5);
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
	 * Function: Verify the Company Name link
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public void verifyCmpnyNameLink()
	{
		String companyname=companyNameLink.getText();
		System.out.println(companyname);
		
	}
	/***********************************************************************************
	 * Function:Capturing the Appeared Search Result value displayed in Profile Analytics tab
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public String clickAppearedinSearchResval()
	{
		WebElement searchres=getDriver().findElement(By.xpath("html/body/div[3]/div[1]/div/div/div[3]/div[3]/div/div/table/tbody/tr["+j+"]/td[2]/a"));
		appearedSearchRes=searchres.getText();
		System.out.println("The value of Appeared Search result is"+appearedSearchRes);
		return appearedSearchRes;
	}
	/***********************************************************************************
	 * Function:Capturing the Clicked From Search Result value displayed in Profile Analytics tab
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public String getClickedfromSearchResVal()
	{
		WebElement clickedfromsearch=getDriver().findElement(By.xpath("html/body/div[3]/div[1]/div/div/div[3]/div[3]/div/div/table/tbody/tr["+j+"]/td[3]/a"));
		clickedfromsearchval=clickedfromsearch.getText();
		System.out.println("The value of Clicked From Search Result value is"+clickedfromsearchval);
		return clickedfromsearchval;
	}
	/***********************************************************************************
	 * Function:Capturing the Clicked From Advertisement value displayed in Profile Analytics tab
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public String getClickedfromAddVal()
	{
		WebElement clickedfromadd=getDriver().findElement(By.xpath("html/body/div[3]/div[1]/div/div/div[3]/div[3]/div/div/table/tbody/tr["+j+"]/td[4]/a"));		
		String clickedfromaddval=clickedfromadd.getText();
		System.out.println("The value of Clicked from Add value is"+clickedfromaddval);
		return clickedfromaddval;
	}
	/***********************************************************************************
	 * Function: Capturing the Connect Count value displayed in Profile Analytics tab
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public String getConnectCount()
	{
		WebElement connectcount=getDriver().findElement(By.xpath("html/body/div[3]/div[1]/div/div/div[3]/div[3]/div/div/table/tbody/tr["+j+"]/td[5]/a"));
		String connectcountval=connectcount.getText();
		System.out.println("The value of Connect Count is"+connectcountval);
		return connectcountval;
	}
	/***********************************************************************************
	 * Function: searching the Company record
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public int serachCmpny(String companyname)
	{	
		System.out.println(companyname);
		int tablesize=tableFrame.size();
		System.out.println(tablesize);		
		for (i=0;i<tablesize;i++)
		{
			String cmpy=tableFrame.get(i).getText();
			System.out.println(cmpy);
			if(cmpy.equals(companyname))
			{
				System.out.println("both the company name matches");			
				break;
			}else
			{
				System.out.println("both the company name doesnt match");
			}
		}
		j=i+1;
		return j;		
	}
	/***********************************************************************************
	 * Function: Verifying the Appeared in Search result value
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public void verifyAppearedinSearchResCnt()
	{
		clickAppearedinSearchResval();		
	}
	/***********************************************************************************
	 * Function: Clicking on the Company name Link displayed in Profile Analytics tab
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public void clickCmpnyLink()
	{
		WebElement cmpnylink=getDriver().findElement(By.xpath("html/body/div[3]/div[1]/div/div/div[3]/div[3]/div/div/table/tbody/tr["+j+"]/td[1]/span/a"));
		cmpnylink.click();
		UIHelper.waitForPageToLoad(getDriver());		
	}
	/***********************************************************************************
	 * Function: Clicking on My Account tab
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public void clickMyAccTab()
	{
		myAccTab.click();
		UIHelper.waitForPageToLoad(getDriver());
	}
	/***********************************************************************************
	 * Function: Clicking on the Company Name Link displayed in My Account page
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public void clickCmpnyLink1(String companyname)
	{
		WebElement cmpny=getDriver().findElement(By.xpath("//span[@title='"+companyname+"']"));
		cmpny.click();		
		UIHelper.waitForPageToLoad(getDriver());		
	}
	/***********************************************************************************
	 * Function: Clicking on the view button in My Account page to view the Company Profile page
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public void clickViewBtn(String dunsno)
	{
		System.out.println(dunsno);
		WebElement profile=getDriver().findElement(By.xpath("//a[@dunsnumber='"+dunsno+"']/span[contains(text(),'View')]"));
		profile.click();
		UIHelper.waitForPageToLoad(getDriver());		
	}
	/***********************************************************************************
	 * Function: Verifying the Company profile page
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public void verifyprofilePage(String companyname)
	{
		System.out.println(companyname);
		String hvalue=header.getText();		
		if(companyname.equals(hvalue))
		{
			System.out.println("The company profile page is diaplyed");
		}else
		{
			System.out.println("The company  profile page is not dispalyed");
		}
	}
	/***********************************************************************************
	 * Function: To compare the Appeared in Search Result value
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public boolean compareAppearedSearchRes()
	{
		
		String appearedSearchResval1=appearedSearchRes;		
		clickAppearedinSearchResval();	
		String appearedSearchResval2=appearedSearchRes;		
		if(appearedSearchRes.equals(appearedSearchResval2))
		{
			System.out.println("the count in Appeared Search result is not increased");
			return true;
		}else
		{
			System.out.println("the count in Appeared Search result is increased");
			return false;
		}
	}
	/***********************************************************************************
	 * Function: To compare the Appeared in Search Result value
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public boolean compareClickedSearchRes()
	{
		
		String clickedfromsearchval1=clickedfromsearchval;		
		getClickedfromSearchResVal();	
		String clickedfromsearchval2=clickedfromsearchval;		
		if(clickedfromsearchval1.equals(clickedfromsearchval2))
		{
			return true;
		}else
		{
			return false;
		}
	}
	
	
	/***********************************************************************************
	 * Function: To get the Appeared in Search result value displayed in Profile Analytics page
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public boolean getappearedresult()
	{		
		WebElement searchresval2=getDriver().findElement(By.xpath("html/body/div[3]/div[1]/div/div/div[3]/div[3]/div/div/table/tbody/tr["+j+"]/td[2]/a"));
		String appearedSearchResval2=searchresval2.getText();		
		if(appearedSearchResval2.equals(appearedSearchRes))
		{
			return false;
		}else
		{
			return true;
		}
	}
	/***********************************************************************************
	 * Function: To get the Clicked Result value in Profile Analytics page
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public boolean getclickedresults()
	{
		WebElement val1=getDriver().findElement(By.xpath("html/body/div[3]/div[1]/div/div/div[3]/div[3]/div/div/table/tbody/tr["+j+"]/td[3]/a"));
		String clickedfromsearchval2=val1.getText();		
		if(clickedfromsearchval2.equals(clickedfromsearchval))
		{
			return false;
		}
		else
		{
			return true;
		}		
	}
	/***********************************************************************************
	 * Function: To get the Connect value in Profile Analytics page
	 * Input : NA 
	 * Action:  NA
	 * Output : NA
	***********************************************************************************/
	public boolean getConnectvalue()
	{
		WebElement value1=getDriver().findElement(By.xpath("html/body/div[3]/div[1]/div/div/div[3]/div[3]/div/div/table/tbody/tr["+j+"]/td[5]"));
		String connectvalue1=value1.getText();
		if(connectvalue1.equals(connectcountval))
		{
			return false;
		}else
		{
			return true;
		}
	}
}
