package com.dnb.automation.sba.pages;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.support.FindBy;

import com.dnb.automation.sba.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class FileAnalysisPage extends PageObject{

	@FindBy(xpath = "//*[@id='fileAnalysis']/a")
	private WebElementFacade fileAnalysis;

	@FindBy(xpath = "//*[@id='ui-id-8']")
	private WebElementFacade country;

	@FindBy(xpath = "//*[@id='fileAnalysisCountry']//*[contains(text(),'USA')]//ancestor::tr//td[2]")
	private WebElementFacade totRecordsUSA;

	@FindBy(xpath = "//*[@id='fileAnalysisCountry']//*[contains(text(),'USA')]//ancestor::tr//td[4]")
	private WebElementFacade spendUSA;

	@FindBy(xpath = "//*[@id='diversity']/a")
	private WebElementFacade diversity;

	@FindBy(xpath = "//*[@id='dashboardClassificationTable']//*[@class='yellowTD ']/td[2]")
	private WebElementFacade totRecordsUSAInDiversity;
	
	@FindBy(xpath = "//*[@id='dashboardClassificationTable']//*[@class='yellowTD ']/td[3]")
	private WebElementFacade spendUSAInDiversity;

	@FindBy(xpath = "//*[@id='socialResp']/a")
	private WebElementFacade socialResp;

	@FindBy(xpath = "//*[@id='socRespClassificationTbl']/tr[1]/td[2]")
	private WebElementFacade totRecordsUSAInSocialResp;

	@FindBy(xpath = "//*[@id='socRespClassificationTbl']/tr[1]/td[3]")
	private WebElementFacade spendUSAInSocialResp;
	
	@FindBy(xpath = "//*[@id='matRec']")
	private WebElementFacade matchedRecords;
	
	@FindBy(xpath = "//*[@id='matSpend']")
	private WebElementFacade mathcedSpend;
	
	@FindBy(xpath = "//*[@id='unmatchedTab']")
	private WebElementFacade unmatchedTab;
	
	@FindBy(xpath = "//*[@id='allUnmatchedBreakout']/tr[1]/td[2]")
	private WebElementFacade mRecordsInUnmatchedTab;
	
	@FindBy(xpath = "//*[@id='allUnmatchedBreakout']/tr[1]/td[3]")
	private WebElementFacade mSpendInunmatchedTab;
	
	@FindBy(xpath = "//*[@id='100']")
	private WebElementFacade itemsPerPage;
	
	@FindBy(xpath = "//*[@id='analysisTabs-3']//*[@class='jp-next']")
	private WebElementFacade nextPage;
	
	@FindBy(xpath = "//*[@id='analysisTabs-3']//*[@class='jp-next jp-disabled']")
	private WebElementFacade nextPageDisabled;


	public void clickOnFileAnalysis(){
		UIHelper.clickAnElement(fileAnalysis);	
	}

	public Map<String,String> getMatchedRecordsAndSpendInUnmathcedTab(){
		Map<String,String> matchedRecAndSpend=new HashMap<String, String>();
		UIHelper.highlightElement(getDriver(), mRecordsInUnmatchedTab);
		matchedRecAndSpend.put(mRecordsInUnmatchedTab.getText().trim(),mSpendInunmatchedTab.getText().trim().replaceAll("\\s+",""));
		return matchedRecAndSpend;
	}

	public void clickOnUnmatchedTab(){
		UIHelper.clickAnElement(unmatchedTab);
	}
	
	public Map<String,String> getMatchedRecordsAndSpend(){
		Map<String,String> matchedRecAndSpend=new HashMap<String, String>();
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), "//*[@class='searchTabLoading']//img[@src='static/images/ajax-loader.gif']");
		String mRecords=matchedRecords.getText();
		mRecords=mRecords.substring(0, mRecords.indexOf('(')).trim();
		UIHelper.highlightElement(getDriver(), matchedRecords);
		String mSpend=mathcedSpend.getText();
		mSpend=mSpend.substring(0, mSpend.indexOf('(')).trim().replaceAll("\\s+","");
		matchedRecAndSpend.put(mRecords,mSpend);
		return matchedRecAndSpend;
	}

	public void clickOnCountry(){
		UIHelper.clickAnElement(country);
	}
	
	public Map<String,String> getTotalMatchedRecordsAndSpendForUSA(){
		Map<String,String> totRecAndSpend=new HashMap<String, String>();
		
		while(!UIHelper.isElementDisplayed(totRecordsUSA)&&!UIHelper.isElementDisplayed(nextPageDisabled))
		{
			UIHelper.clickAnElement(nextPage);
		}
		String totRec=totRecordsUSA.getText();
		String spend=spendUSA.getText();
		totRecAndSpend.put(totRec, spend);
		return totRecAndSpend;
	}

	public void clickOnDiversity(){
		UIHelper.clickAnElement(diversity);
	}

	public Map<String,String> getTotalUSMatchedSuppliersInDiversity(){
		Map<String,String> totRecAndSpendInDiversity=new HashMap<String, String>();
		UIHelper.waitForVisibilityOfElement(totRecordsUSAInDiversity);
		String totRecInDiversity=totRecordsUSAInDiversity.getText();
		String spendInDiversity=spendUSAInDiversity.getText().replace(".00", "");
		totRecAndSpendInDiversity.put(totRecInDiversity, spendInDiversity);
		return totRecAndSpendInDiversity;
	}

	public void clickOnSocialResponsibility(){
		UIHelper.clickAnElement(socialResp);
	}
	
	public Map<String,String> getTotalUSMatchedSuppliersInSocialResponsibility(){
		UIHelper.waitForVisibilityOfElement(totRecordsUSAInSocialResp);
		Map<String,String> totRecAndSpendInSocialResp=new HashMap<String, String>();
		String totRecInSocialResp=totRecordsUSAInSocialResp.getText();
		String spendInSocialResp=spendUSAInSocialResp.getText().replace(".00", "");
		totRecAndSpendInSocialResp.put(totRecInSocialResp, spendInSocialResp);
		return totRecAndSpendInSocialResp;
	}
}
