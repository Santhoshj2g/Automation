package com.dnb.automation.imreg.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class NLMIManualPage extends PageObject {
	
	@FindBy(xpath = "//select[@name='workflowProfileId']//option[contains(text(),'Sample_Manual_NLMI_Batch_Template [public]')]")
	private WebElement sampleFlows;
	
	@FindBy(xpath = "//*[contains(text(),'Save As')]")
	private WebElementFacade saveBtn;
	
	public void clckNLMI() throws Exception
	{
		try  {
			UIHelper.clickanElement(sampleFlows);
			Thread.sleep(5000);
			saveBtn.click();
		} catch (Exception e) {
			throw e;
		}
	}
}
