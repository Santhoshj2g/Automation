package com.dnb.automation.dnbi.pages;

import java.util.ArrayList;
import java.util.List;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * CreateRuleEvaluationPage.java - This class contains methods for configure
 * ruleEvaluation order for rule sets
 * 
 * @author Duvvuru Naveen
 * @version 1.0
 ***********************************************************************************************/
public class CreateRuleEvaluationPage extends PageObject {
    // Setting an Evaluation order in Credit Admin Application by using decision
    // maker rules

    @FindBy(xpath = "//*[@id='header_mainApp']//*[@class='primaryNav_div']//a[text()='Admin']")
    private WebElementFacade adminTabEle;

    @FindBy(xpath = "//*[@id='main']//*[@class='ecf_toc']//a[text()='Credit Applications Admin']")
    private WebElementFacade creditApplicationAdmin;

    @FindBy(xpath = ".//*[@id='main']//*[@class='ecf_page']//a[text()='Set Decision Maker Rules']")
    private WebElementFacade setDecisionMakerRules;

    @FindBy(xpath = ".//*[@id='main']//*[@class='btn bold btnPrimary']")
    private WebElementFacade nextBtn;

    @FindBy(xpath = ".//*[@id='main']//*[@value='Set Evaluation Order']")
    private WebElementFacade setEvaluationOrder;

    @FindBy(xpath = ".//*[@id='main']//*[@id='pageHead']//a[text()='DECLINED_FIRST']")
    private WebElementFacade declinedFirst;

    @FindBy(xpath = ".//*[@id='main']//*[@width='100%']//*[@value='APPROVED_FIRST']")
    private WebElementFacade approvedFirst;

    @FindBy(xpath = "//*[@id='main']//input[@value='CUSTOM']")
    private WebElementFacade customorder;

    @FindBy(xpath = "//*[@id='main']//input[@value='CREDIT_HOLD_FIRST']")
    private WebElementFacade creditHoldFirst;

    @FindBy(xpath = "//*[@id='main']//input[@value='CREDIT_INCREASE_FIRST']")
    private WebElementFacade creditIncreaseFirst;

    @FindBy(xpath = ".//*[@id='backRight']//*[@value='Next']")
    private WebElementFacade nextButton;

    @FindBy(xpath = ".//*[@id='main']//table//tbody//tr//td[3]//a[1]//img")
    private WebElementFacade upImeEle;

    @FindBy(xpath = "//*[@id='main']//*[contains(@href,'moveOptionDown')]//img")
    private WebElementFacade downEle;
    
    @FindBy(xpath = "//*[@id='main']//*[contains(@href,'moveOptionUp')]//img")
    private WebElementFacade upEle;
    
    @FindBy(xpath = ".//*[@id='backRight']//*[@value='Next']")
    private WebElementFacade clickNextbtn;
    
    private WebElement srName1;
    private WebElement srName;
    private String rname;
    
    private int countno;
   // Select select= new Select(getDriver().findElement(By.xpath("//*[@id='amt_title']/select")));
    
    
    //[contains(@src,'arrow_blue_up')]

    @FindBy(xpath = ".//*[@id='amt_title']/select/option[1]")
    private WebElementFacade option1;
    
    @FindBy(xpath = "//*[@id='amt_title']/select/option")
    private List<WebElementFacade> createdRuleNames;

    @FindBy(xpath = ".//*[@id='page_title']/h2")
    private WebElementFacade decisionRules;

    @FindBy(xpath = "//*[@id='main']//table//tbody//tr[2]//td//table//tbody/tr[7]//td[1]//table//tbody//tr[1]//td[2]//input")
    private WebElementFacade radioBtnOptForEvaluationForCreditHoldsFirstEle;

    @FindBy(xpath = "//*[@id='main']//table//tbody//tr[2]//td//table//tbody/tr[7]//td[1]//table//tbody//tr[3]//td[2]//input")
    private WebElementFacade radioBtnOptForEvaluationForCreditIncFirstEle;

    @FindBy(xpath = "//*[@id='main']//table//tbody//tr[2]//td//table//tbody/tr[7]//td[1]//table//tbody//tr[5]//td[2]//input")
    private WebElementFacade radioBtnOptForSetCustomOrderEle;

    @FindBy(xpath = "//*[@id='main']//*[@id='tab1']//span[contains(.,'Loading')]")
    private WebElementFacade loadingRulesEle;

    private String loadingRulesEleXPath = "//*[@id='main']//*[@id='tab1']//span[contains(.,'Loading')]";

    public void goToRuleEvaluationOrderPage() throws Exception {
        try {
            // Clicking the Credit Application Link
            adminTabEle.click();

            creditApplicationAdmin.waitUntilPresent();
            creditApplicationAdmin.click();

            setDecisionMakerRules.waitUntilPresent();
            setDecisionMakerRules.click();

            nextBtn.waitUntilPresent();
            nextBtn.click();

            setEvaluationOrder.waitUntilPresent();
            setEvaluationOrder.click();

        } catch (Exception e) {
            // throw e;
        }

    }

    public void configureRuleEvaluationOrder(String inputfield)
            throws Exception {

        try {
        if (inputfield.equalsIgnoreCase("Set Custom Order")) {
            radioBtnOptForSetCustomOrderEle.click();
        }
        
        else if (inputfield.equalsIgnoreCase("Evaluate for Credit Holds First")) {
                radioBtnOptForEvaluationForCreditHoldsFirstEle.click();
            } else if (inputfield
                    .equalsIgnoreCase("Evaluate for Credit Increases First")) {
                radioBtnOptForEvaluationForCreditIncFirstEle.click();
            

        }
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
    

    public void clickNextInSetEvaluationOrderPage() {
        try {
            nextButton.waitUntilPresent();
            nextButton.click();
            UIHelper.waitForPageToLoad(getDriver());
            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                    loadingRulesEleXPath);

            if (option1.isPresent()) {
                option1.click();
                UIHelper.waitForPageToLoad(getDriver());
                downEle.click();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void selectRequiredRule(String Rulename) {
        try {
    		
        	for (int getcount = 1; getcount <= createdRuleNames.size(); getcount++){

        		rname="//*[@id='amt_title']/select/option["+getcount+"]";
        		srName=getDriver().findElement(By.xpath(rname));
        		        		
        		if (!srName.getText().contains(Rulename)){
        		}else{
        			countno=getcount;
        			break;
        		}
        	}
    		Select sel = new Select(getDriver().findElement(By.xpath("//*[@id='amt_title']/select")));
    		sel.selectByIndex(countno-1);
    		sel.deselectByIndex(1);
        	for(int count=0; count<countno; count++){
        		System.out.println("how many times has to click"+count);
        		upEle.click();
        		
        	}
        	
        	
        	/*for (WebElement options : createdRuleNames){
        		System.out.println("rulename----------------"+options.getText());
        		if (!options.getText().contains(Rulename)){
        			System.out.println("if loop passed------------------"+options.getText());
        			//upEle.click();
        			break;
        		}else{
        			System.out.println("inside else loop--------------------------");
        			String rname2="//*[@id='amt_title']/select/option[contains(.,'"+Rulename+"')]";
        			srName1=getDriver().findElement(By.xpath(rname2));
        			srName1.click();
        			System.out.println("rool name clicked----------------------");
        			upEle.click();
        			
        		}
        	}*/
        	
        	      
           
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void clickNextButton(){
    	try{
    		
    		if (clickNextbtn.isVisible()){
    			clickNextbtn.click();
    		}
    	}catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getPageTitleForRuleEvalOrder() {
        return decisionRules.getText();
    }
}
