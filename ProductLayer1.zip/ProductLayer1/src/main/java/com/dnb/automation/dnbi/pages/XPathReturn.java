package com.dnb.automation.dnbi.pages;

public interface XPathReturn {

	String XPath(String propname);
	String XPath(String appvalue, String propname);
	String XPath(String appvalue1, String appvalue2,
			String propname);
	
	
}
