package com.dnb.automation.onboard.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.onboard.model.LoadProperties;
import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class ComplianceReport extends PageObject

{


	
    @FindBy(xpath = "//*[@id='ecfLiveReportTitleValue']")
    private WebElementFacade businessName;
    @FindBy(xpath = "//*[@id='ecfLiveReportTitle']")
    private WebElementFacade reportTitle;

    @FindBy(xpath = "//*[@id='ecfDunsNumberValue']")
    private WebElementFacade dunsnumbervalue;

    @FindBy(xpath = "//*[@id='reportTabHolder']//*[@id='ecfSummarySidebar']//*[@id='Business_Report_link_id']")
    private WebElementFacade businessreport;

    @FindBy(xpath = "//*[@id='Business_Report']")
    private WebElementFacade businessreportframe;

    @FindBy(xpath = "//*[@id='identification']//*[@class='layout']/tbody/tr[1]/td//*[@class='vertical']/tbody/tr[1]/td//*[@class='risk-indicator']/tbody/tr/td[contains(@bgcolor,'#00FF00')]|//*[@id='identification']//*[@class='layout']/tbody/tr[1]/td//*[@class='vertical']/tbody/tr[1]/td//*[@class='risk-indicator']/tbody/tr/td[contains(@bgcolor,'#00CC99')]|//*[@id='identification']//*[@class='layout']/tbody/tr[1]/td//*[@class='vertical']/tbody/tr[1]/td//*[@class='risk-indicator']/tbody/tr/td[contains(@bgcolor,'#ffd400')]|//*[@id='identification']//*[@class='layout']/tbody/tr[1]/td//*[@class='vertical']/tbody/tr[1]/td//*[@class='risk-indicator']/tbody/tr/td[contains(@bgcolor,'#ff0000')]")
    private WebElementFacade riskindvalue;
    
    @FindBy(xpath = "//*[@id='Identification']/table[2]/tbody/tr/td[1]/table/tbody/tr[4]/td[2]|//*[@id='Identification']/table[2]/tbody/tr/td[1]/table/tbody/tr[6]/td[2]/a")
	private WebElementFacade dnbratvalue;

    @FindBy(xpath = "//*[@id='identification']/tbody/tr/td[2]/table/tbody/tr[1]/td[1]/table/tbody/tr[2]/td")
    private WebElementFacade failurescorevalue;
    
    @FindBy(xpath = "//*[@id='Identification']/table[2]/tbody/tr/td[1]/table/tbody/tr[5]/td[2]")
	private WebElementFacade dnbscorevalue;
    
    @FindBy(xpath = "//*[@id='Identification']/table[2]/tbody/tr/td[1]/table/tbody/tr[6]/td[1]/b")
    private WebElementFacade paydex;

    @FindBy(xpath = "//*[@id='identification']/tbody/tr/td[2]/table/tbody/tr[1]/td[1]/table/tbody/tr[3]/td")
    private WebElementFacade creditlimitvalue;
            
    String creditvalxpathstr = "//*[@id='Identification']/table[2]/tbody/tr/td[1]/table/tbody/tr[";
	String creditvalxpathend = "]/td[2]/a";

    @FindBy(xpath = "//*[@id='risk-assessment']/tbody/tr/td[2]/table/tbody/tr[2]/td[1]/table[1]/thead/tr/th[2]")
    private WebElementFacade riskassesratingvalue;
        
    @FindBy(xpath = "//*[@id='risk-assessment']/tbody/tr/td[2]/table/tbody/tr[2]/td[1]/table[1]/tbody/tr[1]/td[1]")
    private WebElementFacade riskassesfinstgvalue;
           
    @FindBy(xpath = "//*[@id='DnB']/table[1]/tbody/tr/td[1]/table[4]/tbody/tr[2]//*[@width = '70%']/span")
	private WebElementFacade dnbratvalue_riskassess;

    @FindBy(xpath = "//*[@id='risk-assessment']/tbody/tr/td[2]/table/tbody/tr[2]/td[1]/table[1]/tbody/tr[2]/td[1]")
    private WebElementFacade riskassesriskindvalue;
    
    @FindBy(xpath = "//*[@id='DnB']/table[1]/tbody/tr/td[1]/table[4]/tbody/tr[6]/td[2]//*[@class='h4']")
	private WebElementFacade dnbScr1value;

    @FindBy(xpath = "//*[@id='risk-assessment']/tbody/tr/td[2]/table/tbody/tr[2]/td[2]/table[1]/thead/tr[1]/th[2]")
    private WebElementFacade riskassescrdlmtvalue;
    
    @FindBy(xpath = "//*[@id='DnB']/table[1]/tbody/tr/td[1]/table[4]/tbody/tr[10]/td[2]//*[@class='h4']")
	private WebElementFacade high_crdValue;
    
    @FindBy(xpath = "//*[@id='risk-assessment']/tbody/tr/td[2]/table/tbody/tr[2]/td[1]/table[2]/thead/tr/th[2]/Font[1]")
	private WebElementFacade riskassesflrscrvalue;
    
    @FindBy(xpath = "//*[@id='DnB']/table[1]/tbody/tr/td[1]/table[4]/tbody/tr[9]/td[2]//*[@class='h4']")
	private WebElementFacade maxCrdScrValue;

    @FindBy(xpath = "//*[@id='searchNavButton']")
    private WebElementFacade searchnavbutton;

    @FindBy(xpath = "//*[@id='confirmationMsgContainer']//*[@id='confirmationCancelBtn']")
    private WebElementFacade donotsavebutton;
    
    @FindBy(xpath=".//*[@id='predictiveIndicators_link_id']")
    private WebElementFacade predictivescorelink;

    @FindBy(xpath=".//*[@id='predictiveIndicators']/h2")
    private WebElementFacade failtoLoad;
    
    @FindBy(xpath=".//*[@id='DBRATINGECF']/div/table/tbody/tr[3]/td/table/tbody/tr[2]/td[2]/b")
    private WebElementFacade riskindicatorinPS;
    
    @FindBy(xpath=".//*[@id='DBFAILSCRECF']/div/table/tbody/tr/td/table/tbody/tr[1]/td[1]/b")
    private WebElementFacade failpercentileinPS;
    
    @FindBy(xpath=".//*[@id='RSKASMTContent']/tbody/tr/td/table/tbody/tr[1]/td/b")
    private WebElementFacade creditlimitinPS;
    
    @FindBy(xpath=".//*[@id='RATCMNTECF']/div/table/tbody/tr/td/table/tbody/tr/td/ul")
    private WebElementFacade commentryTable;
           
    @FindBy(xpath=".//*[@id='ecfExitBtn']")
    private WebElementFacade exitbtninPS;
    
    @FindBy(xpath=".//*[@id='confirmationCancelBtn']")
    private WebElementFacade donotsavebtninPS;
    
    @FindBy(xpath=".//*[@id='OOB_ECF']/div")
    private WebElementFacade OOBframe;
    
    @FindBy(xpath=".//*[@id='RSKASMT_BLContent']/tbody/tr[2]/td/table/tbody/tr/td/center/span/font")
	private WebElementFacade OutofbusText;	  
    
    @FindBy(xpath=".//*[@id='RATCMNTECF']/div/table/tbody/tr/td/table/tbody/tr/td/ul/li")
    private List<WebElementFacade> commelements;
    
    private String CommentryTextinPS=".//*[@id='RATCMNTECF']/div/table/tbody/tr/td/table/tbody/tr/td/ul/li[%s]";
    private String RskIndVal;
	private String DnbRatVal;
	private String FlrScrVal;
	private String DnbScrVal;
	private String CrdLmtVal;
	private String HighCrdval;
	private String RatVal;
	private String MaxCredVal;
	private String FinStrengthVal;

    // User navigates to the Business-Report section

    public void clickBusinessReportLink() throws Exception {
        try {
            businessreport.waitUntilPresent();
            UIHelper.highlightElement(getDriver(), businessreport);
            businessreport.click();
            UIHelper.waitForPageToLoad(getDriver());
        }

        catch (Exception e) {
            e.printStackTrace();
        }
    }

    // User checks the compliance-report visibility

    public boolean reportFrameLoad() {

        businessreport.waitUntilPresent();
        if (businessreportframe.isPresent()) {
            return true;
        }

        else {
            return false;
        }
    }

    // User checks the Duns number

    public boolean dunsNumber() {
        if (dunsnumbervalue.isPresent()) {
            UIHelper.highlightElement(getDriver(), dunsnumbervalue);
            return true;
        }

        else {
            return false;
        }
    }

    // User verifies the value of D&B Risk Indicator in Identification and
    // Summary section

    public String riskindicator() throws Exception {
        try {
            if (riskindvalue.isPresent()) {
                RskIndVal = riskindvalue.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), riskindvalue);
            }

        }

        catch (Exception e) {
            e.printStackTrace();
        }
        return RskIndVal;
    }

    // Verify Failure score in Identification & Summary section

    public String failurescore() throws Exception {
        try {
            if (failurescorevalue.isPresent()) {
                FlrScrVal = failurescorevalue.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), failurescorevalue);
            }
        }

        catch (Exception e) {
            e.printStackTrace();
        }
        return FlrScrVal;
    }

    // Verify Credit Limit in Identification & Summary section

    public String creditlimit() throws Exception {
        try {
            if (creditlimitvalue.isPresent()) {
                CrdLmtVal = creditlimitvalue.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), creditlimitvalue);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return CrdLmtVal;
    }

    // Verify D&B Rating in D&B Risk Assessment section

    public String dbrating() throws Exception {
        try {
            if (riskassesratingvalue.isPresent()) {
                RatVal = riskassesratingvalue.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), riskassesratingvalue);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return RatVal;
    }

    // Verify financial strength in D&B Risk Assessment section

    public String finstrength(String finstrengthvalue) throws Exception {
		try

		{
			if (riskassesfinstgvalue.isPresent()){
				FinStrengthVal = riskassesfinstgvalue.getText().toString().trim();
				UIHelper.highlightElement(getDriver(), riskassesfinstgvalue);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FinStrengthVal;
	}

    // User verifies the Risk-Indicator Assessment value in D&B Risk Assessment
    // section

public String riskind(String riskIndicator) throws Exception {
		
		try {
			if (riskassesriskindvalue.isPresent()){
				RskIndVal = riskassesriskindvalue.getText().toString().trim();	 
				UIHelper.highlightElement(getDriver(), riskassesriskindvalue);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return RskIndVal;
	}

    // verifies the D&B Credit-Limit as in D&B Risk Assessment section

	public String creditlimiAsmt(String creditLimitAsmt) throws Exception {
		
		try {
	
			if (riskassescrdlmtvalue.isPresent()){
				CrdLmtVal = riskassescrdlmtvalue.getText().toString().trim();
				UIHelper.highlightElement(getDriver(), riskassescrdlmtvalue);
			}
	
		} catch (Exception e) {
			e.printStackTrace();
		}
		return CrdLmtVal;
	}

    // User verifies the D&B Failure-score in D&B Risk Assessment section

    public String failurescoreAsmt(String failureScoreAsmt) throws Exception {
		try {
			if (riskassesflrscrvalue.isPresent()){
				FlrScrVal = riskassesflrscrvalue.getText().toString().trim();
				UIHelper.highlightElement(getDriver(), riskassesflrscrvalue);
			}
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return FlrScrVal;
	}
    
 // User verifies the value of D&B Rating in Identification and
 			// Summary section

 		public String dnbratings() throws Exception {
 			try {
 				if (dnbratvalue.isPresent()) {
 					DnbRatVal = dnbratvalue.getText().toString().trim();
 					UIHelper.highlightElement(getDriver(), dnbratvalue);
 				}

 			}

 			catch (Exception e) {
 				e.printStackTrace();
 			}
 			return DnbRatVal;
 		}
 		
// Verify Failure score in Identification & Summary section

		public String dnbscore() throws Exception {
			try {
				if (dnbscorevalue.isPresent()) {
					DnbScrVal = dnbscorevalue.getText().toString().trim();
					UIHelper.highlightElement(getDriver(), dnbscorevalue);
				}
			}

			catch (Exception e) {
				e.printStackTrace();
			}
			return DnbScrVal;
		}
		
// Verify high credit in Identification & Summary section

		public String highcreditlimits(String highCredit) throws Exception {
			try {
				
				if(dnbscorevalue.isPresent() && !dnbscorevalue.getText().trim().equalsIgnoreCase("")){
					WebElementFacade highcreditLnk = findBy(creditvalxpathstr+7+creditvalxpathend);
					HighCrdval = findBy(creditvalxpathstr+7+creditvalxpathend).getText().toString().trim();
					UIHelper.highlightElement(getDriver(), highcreditLnk);
				}else if(dnbscorevalue.isPresent() && dnbscorevalue.getText().trim().equalsIgnoreCase("") && !paydex.getText().trim().equalsIgnoreCase("Paydex")){
					WebElementFacade highcreditLnk = findBy(creditvalxpathstr+6+creditvalxpathend);
					HighCrdval = findBy(creditvalxpathstr+6+creditvalxpathend).getText().toString().trim();
					UIHelper.highlightElement(getDriver(), highcreditLnk);
				}else if(dnbscorevalue.isPresent() && dnbscorevalue.getText().trim().equalsIgnoreCase("") && paydex.getText().trim().equalsIgnoreCase("Paydex")){
					WebElementFacade highcreditLnk = findBy(creditvalxpathstr+7+creditvalxpathend);
					HighCrdval = findBy(creditvalxpathstr+7+creditvalxpathend).getText().toString().trim();
					UIHelper.highlightElement(getDriver(), highcreditLnk);
					
				}else{
					WebElementFacade highcreditLnk = findBy(creditvalxpathstr+6+creditvalxpathend);
					HighCrdval = findBy(creditvalxpathstr+8+creditvalxpathend).getText().toString().trim();
					UIHelper.highlightElement(getDriver(), highcreditLnk);
					
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
			return HighCrdval;
		}
		
// User verifies the value of Maximum High Credit in D&B Risk Assessment section

		public String maxCredRating() throws Exception {
			try {
				if(dnbscorevalue.isPresent() && !dnbscorevalue.getText().trim().equalsIgnoreCase("")){
					WebElementFacade maxcreditLnk = findBy(creditvalxpathstr+8+creditvalxpathend);
					MaxCredVal = findBy(creditvalxpathstr+8+creditvalxpathend).getText().toString().trim();
					UIHelper.highlightElement(getDriver(), maxcreditLnk);
				}else if(dnbscorevalue.isPresent() && dnbscorevalue.getText().trim().equalsIgnoreCase("") && !paydex.getText().trim().equalsIgnoreCase("Paydex")){
					WebElementFacade maxcreditLnk = findBy(creditvalxpathstr+7+creditvalxpathend);
					MaxCredVal = findBy(creditvalxpathstr+7+creditvalxpathend).getText().toString().trim();
					UIHelper.highlightElement(getDriver(), maxcreditLnk);
				}else if(dnbscorevalue.isPresent() && dnbscorevalue.getText().trim().equalsIgnoreCase("") && paydex.getText().trim().equalsIgnoreCase("Paydex")){
					WebElementFacade maxcreditLnk = findBy(creditvalxpathstr+8+creditvalxpathend);
					MaxCredVal = findBy(creditvalxpathstr+7+creditvalxpathend).getText().toString().trim();
					UIHelper.highlightElement(getDriver(), maxcreditLnk);
				}else{
					WebElementFacade maxcreditLnk = findBy(creditvalxpathstr+9+creditvalxpathend);
					MaxCredVal = findBy(creditvalxpathstr+9+creditvalxpathend).getText().toString().trim();
					UIHelper.highlightElement(getDriver(), maxcreditLnk);
					
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return MaxCredVal;
		}
		
//  User verifies the value of D&B Rating value in D&B Risk Assessment section

		public String dnbRat() throws Exception {
			
			try{
				if(dnbratvalue_riskassess.isPresent()){
					RatVal = dnbratvalue_riskassess.getText().trim();
					UIHelper.highlightElement(getDriver(), dnbratvalue_riskassess);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return RatVal;
		}

//User verifies the D&B Score value in D&B Risk Assessment section

		public String dnbScrValue1(String scrVal) throws Exception {
			try {
				if (dnbScr1value.isPresent()) {
					DnbScrVal = dnbScr1value.getText().toString().trim();
					UIHelper.highlightElement(getDriver(), dnbScr1value);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return DnbScrVal;
		}
		
// verifies the D&B high credit as in D&B Risk Assessment section

		public String highCrdVal1() throws Exception {
			
			try {

				if (high_crdValue.isPresent()) {
					HighCrdval = high_crdValue.getText().toString().trim();
					UIHelper.highlightElement(getDriver(), high_crdValue);
					}

			} catch (Exception e) {
				e.printStackTrace();
			}
			return HighCrdval;
		}
		
// User verifies the Maximum High Credit in D&B Risk Assessment section

		public String maxHighScrVal() throws Exception {
			try {
				if (maxCrdScrValue.isPresent()){
					MaxCredVal = maxCrdScrValue.getText().toString().trim();
					UIHelper.highlightElement(getDriver(), maxCrdScrValue);
				}
			}

			catch (Exception e) {
				e.printStackTrace();
			}
			return MaxCredVal;
		}
		
//User click Predictive score link
		
		public void clickPredictiveScore()
		{
			try
			{
				predictivescorelink.waitUntilPresent();
				UIHelper.highlightElement(getDriver(), predictivescorelink);
				predictivescorelink.click();
				UIHelper.waitForPageToLoad(getDriver());
			}
			catch (Exception e) {
	            e.printStackTrace();
	        }
		}
		
//User verifies Risk Indicator in Predictive Score

		public String verifyRiskindicator() throws Exception
		{
			try
			{
				if(riskindicatorinPS.isPresent())
				{
					RskIndVal = riskindicatorinPS.getText().toString().trim();
					UIHelper.highlightElement(getDriver(), riskindicatorinPS);
				}else{
					RskIndVal="";
				}
			}
				 catch (Exception e) {
					 if(failtoLoad.isPresent())
							 return failtoLoad.getText().toString().trim();
			        }
			        return RskIndVal;
		}

//User verifies Fail Percentile in Predictive score
		public String verifyFailPercentil() throws Exception
		{
			try
			{
				if(failpercentileinPS.isPresent())
				{
					FlrScrVal = failpercentileinPS.getText().toString().trim();
					  UIHelper.highlightElement(getDriver(), failpercentileinPS);
		                FlrScrVal = FlrScrVal.replace("D&B Failure Score: ","");
		                FlrScrVal = FlrScrVal.replace(" out of 100","").trim();
				}else{
					FlrScrVal="";
				}
			}
				 catch (Exception e) {
			            e.printStackTrace();
			        }
			        return FlrScrVal;
		}

//User verifies Credit Limit in Predictive score
		
		public String verifyCreditLimit() throws Exception
		{
			try
			{
				if(creditlimitinPS.isPresent())
				{
					CrdLmtVal = creditlimitinPS.getText().toString().trim();
					UIHelper.highlightElement(getDriver(), creditlimitinPS);
	                CrdLmtVal = CrdLmtVal.replace("D&B Credit Advice:","").replace("€","").trim();
					
				}else{
					CrdLmtVal="";
				}
			}
				 catch (Exception e) {
			            e.printStackTrace();
			        }
			        return CrdLmtVal ;
		}
//User verifies Commentry code in predictive score
		
		public String verifyCommentry(String commText) throws Exception
		{
			String CommentryText="";
			String tempText= "";
			int size = commelements.size();
			if(commentryTable.isPresent()){
				for(int j=1;j<=size;j++){
						
				tempText= getPath(CommentryTextinPS,j).toString().trim();
					
				  	if(commText.trim().equals(tempText)){
				
					UIHelper.highlightElement(getDriver(), commentryTable);
					CommentryText=tempText.toString().trim();
					break;
					}
				}
			}
			return CommentryText;
		}

		private String getPath(String xpath, int i)
		{
			String tempText= String.format(xpath, i);
			String value= UIHelper.getTextvalue(getDriver(), tempText);
					
			return value;
		}
//User clicks on exit button in predictive score
		
		public void clickexitbtn() throws Exception
		{
			try{
			exitbtninPS.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), exitbtninPS);
			exitbtninPS.click();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
//User clicks Do not save report
		
		public void clickdoNotSaveReport() throws Exception
		{
			try{
				donotsavebtninPS.waitUntilPresent();
				UIHelper.highlightElement(getDriver(), donotsavebtninPS);
				donotsavebtninPS.click();
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}

    // User back to Dash-board page

    public void searchscreen() {
        try {
            if (searchnavbutton.isPresent()) {
                UIHelper.highlightElement(getDriver(), searchnavbutton);
                searchnavbutton.click();
                donotsavebutton.waitUntilPresent();
                UIHelper.highlightElement(getDriver(), donotsavebutton);
                donotsavebutton.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        }

        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getBusinessName() {
        businessName.waitUntilPresent();
        return businessName.getText();
    }

    public String getReportTitle() {
        reportTitle.waitUntilPresent();
        return reportTitle.getText();
    }
    
  //Function to format credit limit
  		public String formatCreditLimit(String creditlimit){
  			String strLast,strFirst,temp;
  			temp="";
  			strFirst="";
  			strLast ="";
  			if(creditlimit.length()<=3){
  				creditlimit = creditlimit+".00";
  				return creditlimit;
  						}else{
  							int value = creditlimit.length();
  							for(int count=1;count<=value;count++){
  								if (creditlimit.length()>=3){
  									strLast = creditlimit.substring(creditlimit.length()-3);
  									strFirst = creditlimit.substring(0,creditlimit.length()-3);
  								}
  								if(strFirst.length()>3){
  									if(count==1){
  										temp = ","+strLast+temp;
  										creditlimit = strFirst;
  										}
  									else{
  										temp = ","+strLast+temp;
  										creditlimit = strFirst;
  										}
  								}else if(strFirst.length()<=3){
  									if(count==1){
  										strFirst = strFirst+","+strLast;
  										creditlimit = strFirst;
  									}else{
  										strFirst = strFirst+","+strLast+temp;
  										creditlimit = strFirst;
  										}
  									return strFirst+".00";
  									}
  								}
  							}
  			
  			return strFirst;
  			
  						}
  		
  		public boolean verifyOOBtext() throws Exception
  		{
  			
  			if(OOBframe.isPresent()){
  				return true;
  				
  		    }else{
  		    	return false;
  		    }
  			
  		}

}
