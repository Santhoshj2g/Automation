package com.dnb.automation.srm.pages;

import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

/**
 * Created by 630239 on 5/11/2017.
 */
public class ProfilePage extends PageObject{

    @FindBy(xpath=".//div[@id='cmp_SSISlider']/div/div")
    private WebElementFacade profileSSI;

    @FindBy(xpath=".//div[@id='cmp_SERSlider']/div/div")
    private WebElementFacade profileSER;

    @FindBy(xpath=".//div[@id='cmp_FssSlider']/div/div")
    private WebElementFacade profileFailScr;

    @FindBy(xpath=".//div[@id='cmp_DNB_Slider']/div/div")
    private WebElementFacade profileDnBRat;

    public boolean verifyProfileSSI() {
        if(profileSSI.isPresent())
            return true;
        else
            return false;
    }

    public String verifyProfileSER() {
        if(profileSER.isPresent()){
            UIHelper.highlightElement(getDriver(),profileSER);
            return profileSER.getText();
        }else
            return null;
            }

    public String ProfileFSSValue() {
        if(profileFailScr.isPresent()){
            UIHelper.highlightElement(getDriver(),profileFailScr);
            return profileFailScr.getText();
        }else
            return null;
    }

    public String verifyProfileDnBRat() {
        if(profileDnBRat.isPresent()){
            UIHelper.highlightElement(getDriver(),profileDnBRat);
            return profileDnBRat.getText();
        }else
            return null;
    }
}
