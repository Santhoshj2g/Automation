package com.dnb.automation.dbiaopal.pages;

import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * Created by 630239 on 5/30/2017.
 */
public class ReportPage extends PageObject {
    @FindBy(xpath=".//td[contains(text(),'D&B Report')]")
    private WebElementFacade reportTitle;

    @FindBy(xpath = ".//*[@id='ID_SPContent']//table/tbody/tr/td[contains(text(),'Risk Assessment')]")
    private WebElementFacade RiskAssesment;

    @FindBy(xpath=".//*[@id='RSKASMT_SP']//td[contains(text(),'Risk Indicator')]/parent::tr/td[4]")
    private WebElementFacade riskIndicator;

    @FindBy(xpath = ".//*[@id='RSKASMT_SP']//td[contains(text(),'Failure Score')]/parent::tr/td[4]")
    private WebElementFacade failScore;

    @FindBy(xpath=".//*[@id='ID_SPContent']//td[contains(text(),'Maximum Credit')]/parent::tr/td[2]")
    private WebElementFacade creditLimit;

    @FindBy(xpath = ".//*[@id='RSKASMT_SP']//td[contains(text(),'Financial Strength')]/parent::tr/td[4]")
    private WebElementFacade finStrength;

    @FindBy(xpath =".//*[@id='RSKASMT_SP']//table[@class='databox']/tbody/tr/td/ul/li")
    private List<WebElementFacade> commentryText;

    private String commentryTable=".//*[@id='RSKASMT_SP']//table[@class='databox']/tbody/tr[num]/td/ul/li";


    public boolean  VerifyReportHeader() throws Exception{
        UIHelper.switchToChildWindow1(getDriver());
        if(reportTitle.isPresent()){
            UIHelper.highlightElement(getDriver(),reportTitle);
            return true;
        }
        else
            return false;
    }

    public boolean verifyAvailabiltyofDBRisk() {
        if(RiskAssesment.isPresent()) {
            UIHelper.highlightElement(getDriver(), RiskAssesment);
            return true;
        }
        else
            return false;
    }

    public String verifyRiskIndicator() {
        String result="";
            if(riskIndicator.isPresent()){
                UIHelper.highlightElement(getDriver(),riskIndicator);
                result= riskIndicator.getText().trim();
            }
            return result;
    }

    public String verifyFailScore() {
        String result="";
        if(failScore.isPresent()){
            UIHelper.highlightElement(getDriver(),failScore);
            result= failScore.getText().trim();
            result= result.replace("out of 100","").trim();
        }
        return result;
    }

    public String verifyCreditLimit() {
        String result="";
        if(creditLimit.isPresent()){
            UIHelper.highlightElement(getDriver(),creditLimit);
            result= creditLimit.getText().trim();
        }
        return result;
    }

    public String verifyFinancialStrength() {
        String result="";
        if(finStrength.isPresent()){
            UIHelper.highlightElement(getDriver(),finStrength);
            result = finStrength.getText().trim().toLowerCase();
        }
        ;
        return result;
    }

    private void closeWindow(WebDriver driver) {
        String childWindow = getDriver().getWindowHandle();
        Set<String> allWindows = getDriver().getWindowHandles();
        Iterator<String> windowIterator = allWindows.iterator();
        while (windowIterator.hasNext()) {
            String homeWindow = windowIterator.next();
            if (childWindow.equals(homeWindow)) {
                getDriver().switchTo().window(childWindow);
                getDriver().close();
                getDriver().switchTo().window(homeWindow);
            }
        }
    }
    public List<String> verifyCommentry() {
        List<String> actual = new ArrayList<>();
        if (!commentryText.isEmpty()) {
            for (int i = 0; i <= commentryText.size(); i++) {
                WebElementFacade actualCommentry = find(By.xpath(commentryTable.replace("num",String.valueOf(i+2))));
                UIHelper.highlightElement(getDriver(), actualCommentry);
                actual.add(actualCommentry.getText().toString());
               // UIHelper.closeCurrentWindow(getDriver());

            }
        }
        return actual;
    }
}
