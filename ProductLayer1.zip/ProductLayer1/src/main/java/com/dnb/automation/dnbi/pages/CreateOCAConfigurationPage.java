package com.dnb.automation.dnbi.pages;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;
import com.google.common.base.Predicate;

/**********************************************************************************************
 * AdminPage.java - This class contains all functionalities of Admin Tab
 * 
 * @author Vamsi Krishna NV
 * @version 1.0
 ***********************************************************************************************/
public class CreateOCAConfigurationPage extends PageObject {

	private static final String JavascriptExecutor = null;

	@FindBy(xpath = ".//*[@id='page_title_links']/h2")
	private WebElementFacade ocaPageHeading;

	@FindBy(xpath = ".//*[@id='main']//*[@id='pageHead']//*[@id='page_title']/h2")
	private WebElementFacade pageHeading;

	@FindBy(xpath = "//*[@id='header_mainApp']//*[@id='primaryNav']//*[contains(text(),'Admin')]")
	private WebElementFacade tabAdmin;

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(text(),'Configure Your Credit Application')]")
	private WebElementFacade lnkConfigureYourCreditApplication;

	@FindBy(xpath = "//*[@class='outerDiv']//a[contains(.,'Credit Applications Admin')]")
	private WebElementFacade creditAppLinkEle;

	@FindBy(xpath = "//*[@id='main']/input[@value='Create New Application']")
	private WebElementFacade CNAbutton;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='applicationForm']//*[@id='Start_wiz_popup']//*[@id='start_wiz_txt']")
	private WebElementFacade NameForCNAForm;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='applicationForm']//*[@id='Start_wiz_popup']//*[@id='sel_chkbox']")
	private WebElementFacade CreatefromExistingBtn;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='applicationForm']//*[@id='Start_wiz_popup']//*[@id='template']")
	private WebElementFacade cnalistbox;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='applicationForm']//*[@id='Start_wiz_popup']//*[@id='createAppBtn' and @value='Create']")
	private WebElementFacade createbtn;

	@FindBy(xpath = "//*[@id='page_title']/h2")
	private WebElementFacade ConfigPageHeader;

	@FindBy(xpath = "//iframe[@name='__modal_iframe_target']")
	private WebElementFacade iFrameEle;

	@FindBy(xpath = "//*[@class='modal_content']//h4[2]")
	private WebElementFacade iFrameEle1;

	@FindBy(xpath = "//*[@class='modal_title']//a[@class='close']")
	private WebElementFacade modalClosemark;

	@FindBy(xpath = "//*[@id='editModalView']//*[@class='modal_content']//*[@id='saveBtn']")
	private WebElementFacade savebtn;

	@FindBy(css = ".pageNamesCategory")
	private WebElementFacade selectSection;

	@FindBy(xpath = "//*[@id='conditonalWrap']//*[contains(@class,'pageNamesCategory')]//option")
	private List<WebElement> selectSectionxpath;

	@FindBy(css = ".fieldPool")
	private WebElementFacade selectField;

	@FindBy(css = ".operatorPool")
	private WebElementFacade selectLogic;

	@FindBy(xpath = "//*[@id='conditonalWrap']/div/select[@class='operatorPool']/following-sibling::*[starts-with(@class,'expression')]")
	private WebElementFacade expressionValue;

	@FindBy(css = ".glyphicon.row-remove")
	private WebElementFacade deleteIcon;

	@FindBy(xpath = "html/body/div[@class='modal_buttons']/input[@value='Cancel']")
	private WebElementFacade btnCancel;

	@FindBy(xpath = "html/body/div[@class='modal_buttons']/input[@value='Set']")
	private WebElementFacade btnSet;

	@FindBy(xpath = "//*[@class='container']//*[@id='manage-questions']//following-sibling::div//button[contains(.,'Continue to Step 2')]")
	private WebElementFacade continuetostep2;

	@FindBy(xpath = "//*[@id='termsAndConditionsForm']//*[@id='wrap']//h3")
	private WebElementFacade termsAndConditionsPageHeader;

	@FindBy(xpath = "//*[@id='termsAndConditionsForm']//*[@id='wrap']//*[@id='titleCustomTermsCondition']")
	private WebElementFacade TcTitle;

	@FindBy(css = "#tinymce>p")
	private WebElementFacade TcContent;

	@FindBy(xpath = "//*[@id='termsAndConditionsForm']//*[@id='wrap']//input[@id='emailTermsConditions']")
	private WebElementFacade ETCcheckbox;

	@FindBy(xpath = "//*[@id='termsAndConditionsForm']//*[@id='wrap']//*[@id='sigBlockWrap']//input[@id='label1']")
	private WebElementFacade Label1;

	@FindBy(xpath = "//*[@id='termsAndConditionsForm']//*[@id='wrap']//*[@id='sigBlockWrap']//input[@id='title1']")
	private WebElementFacade Title1;
	@FindBy(xpath = "//*[@id='termsAndConditionsForm']//*[@id='wrap']//*[@id='sigBlockWrap']//input[@value='eSignature']")
	private WebElementFacade eSignatureRadioBtn;

	@FindBy(xpath = "//*[@id='termsAndConditionsForm']//*[@id='wrap']//*[@id='sigBlockWrap']//input[@value='textSignature']")
	private WebElementFacade textSignatureRadioBtn;

	@FindBy(xpath = "//*[@id='termsAndConditionsForm']//*[@id='wrap']//*[@id='addsig']//input[@value='Add Signature']")
	private WebElementFacade AddSignatureBtn;

	@FindBy(xpath = "//*[contains(@class,'mce-tinymce')]//*[contains(@class,'mce-container-body')]//*[contains(@class,'mce-edit-area')]//iframe[@id='texta_ifr']")
	private WebElementFacade iFrameEleTerms;

	@FindBy(xpath = "//*[@id='wrap']//button[contains(.,'Continue to Step 3')]")
	private WebElementFacade ContinetoStep3btn;

	@FindBy(xpath = "//*[@id='wrap']//h3")
	private WebElementFacade DesginPageHeaderelement;

	@FindBy(xpath = "//*[@id='FinalizeForm']//*[@id='onlyThanks']")
	private WebElementFacade thanksradiobtn;

	@FindBy(xpath = "//*[@id='FinalizeForm']//*[@id='showDecision']")
	private WebElementFacade decessionradiobtn;

	@FindBy(xpath = "//*[@id='mce_8']")
	private WebElementFacade Tmessagehighlight;

	@FindBy(xpath = "//*[@id='mce_16']")
	private WebElementFacade Amessagehighlight;

	@FindBy(xpath = "//*[@id='mce_24']")
	private WebElementFacade Dmessagehighlight;

	@FindBy(xpath = "//*[@id='mce_32']")
	private WebElementFacade PFmessagehighlight;

	@FindBy(xpath = "//*[@id='thanks-message']//*[@class='form-inline row-buffer redirectUrl']//*[@class='checkbox']//label//*[@class='redirector']")
	private WebElementFacade TMailchekbox;

	@FindBy(xpath = "//*[@id='thanks-message']//*[@class='form-inline row-buffer redirectUrl']//*[@class='form-group']//*[@class='form-control']")
	private WebElementFacade TMailtextbox;

	@FindBy(xpath = "//*[@id='FinalizeForm']//*[@id='publish']")
	private WebElementFacade PublishBtn;
	@FindBy(xpath = "//*[@id='submit']")
	private WebElementFacade SaveandReturnbtn;

	@FindBy(xpath = "//*[@id='mce_4']//*[@id='mce_4-body']//*[@id='mce_8']/iframe[@id='thankYouMessage_ifr']")
	private WebElementFacade Thankyouiframexpath;

	@FindBy(xpath = "//*[@id='mce_12']//*[@id='mce_12-body']//*[@id='mce_16']/iframe[@id='cfaDecisionMessageInfo[0].thankYouMessage_ifr']")
	private WebElementFacade Approvediframexpath;

	@FindBy(xpath = "//*[@id='mce_20']//*[@id='mce_20-body']//*[@id='mce_24']/iframe[@id='cfaDecisionMessageInfo[1].thankYouMessage_ifr']")
	private WebElementFacade Declinediframexpath;

	@FindBy(xpath = "//*[@id='mce_28']//*[@id='mce_28-body']//*[@id='mce_32']/iframe[@id='cfaDecisionMessageInfo[2].thankYouMessage_ifr']")
	private WebElementFacade pendingiframexpath;

	@FindBy(xpath = "//*[@id='FinalizeForm']//*[@id='imageFile']")
	private WebElementFacade uploadfile;

	@FindBy(xpath = "//*[@id='FinalizeForm']//*[contains(@class,'form-inline')]//button[contains(.,'Upload Logo')]")
	private WebElementFacade Uploadbtn;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='calcModalInner']//*[@id='fieldDisplayText']")
	private WebElementFacade displayTextElement;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='calcModalInner']//table//select[@name='fieldDataType']")
	private WebElementFacade calculatedOutPutType;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='calcModalInner']//select[@id='pool']//option")
	private List<WebElementFacade> selectVeriable;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='calcModalInner']//select[@id='pool']")
	private WebElementFacade selectVeriable1;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='calcModalInner']//*[@class='opera_container']//*[@id='varOperatorValue']//option")
	private List<WebElementFacade> selectOperator;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='calcModalInner']//*[@class='opera_container']//*[@id='varOperatorValue']")
	private WebElementFacade selectOperator1;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='calcModalInner']//*[@id='expressionBox']")
	private WebElementFacade textArea;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='ruleForm']//*[@class='modal_buttons']//input[@value='Submit']")
	private WebElementFacade CalsubmitButton;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='ruleForm']//*[@class='modal_buttons']//input[@value='Cancel']")
	private WebElementFacade CalCancelButton;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='calcModalInner']//*[@class='alert_box']//h3[@class='error']")
	private WebElementFacade Calerrormessage;

	@FindBy(xpath = "//*[@id='radioAlertModal']//*[@class='modal_content']//*[@class='modal_buttons']//input[@value='Proceed']")
	private WebElementFacade settingProceedBtn;

	@FindBy(xpath = "//*[@id='FinalizeForm']//*[@id='letterHeadText']")
	private WebElementFacade letterHeadText;

	@FindBy(xpath = "//*[@class='manage-section-footer']//*[@id='newSectinName']")
	private WebElementFacade customSectionTextBox;

	@FindBy(xpath = "//*[@class='manage-section-footer']//*[@id='createNewSectinBtn']")
	private WebElementFacade customSectionCreateBtn;
	@FindBy(xpath = "//body[@class='iframe_modal']//*[@id='modal_buttons']/input[@value='Yes']")
	private WebElementFacade alertdeleteudf;

	@FindBy(xpath = "//*[@class='modal-dialog']//*[@class='modal_content']")
	private WebElementFacade alertmodelwindow;
	@FindBy(xpath = "//*[@class='modal_buttons']//input[@value='Continue']")
	private WebElementFacade timeoutcontinue;
	@FindBy(xpath = "//*[@id='pageListContentWrap']/div[@class='CompanyInfoPage']")
	private WebElementFacade companyInfopagewidget;

	private WebElement Questionname;

	private WebElement Donebtnxpath;

	private WebElement RemovedQuestionname;

	private WebElement RemovedQuestionbtn;
	private WebElement DeleteQuestionname;

	private WebElement DeleteQuestionbtn;
	private WebElement txtArea;
	private WebElementFacade tabWriteQuestions;
	private WebElementFacade txtWriteQuestions;
	private WebElementFacade SelectType;
	private WebElementFacade butnAdd;
	private WebElementFacade settingsRadioBtn;
	private WebElementFacade selectSettingsRadioBtn;

	int vFlag = 0;
	String adminTab = "//*[@id='header_mainApp']//*[@id='primaryNav']//*[contains(text(),'Admin')]";
	String creditAppLinkXPath = "//*[@class='outerDiv']//a[contains(.,'Credit Applications Admin')]";
	String configYourCreditAppLinkXPath = "//*[@class='outerDiv']//*[contains(.,'Configure Your Credit Application')]";
	String createnewappbtn = "//*[@id='main']/input[@value='Create New Application']";
	String applinamewidget = "//*[@id='main']//*[@id='srcRecordList']/tbody";
	String companyInfopage = "//*[@id='pageListContentWrap']/div[@class='CompanyInfoPage']";
	String impAcntDataPageTitleXPath = "//*[@id='page_title']/h2";
	String framexpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']";
	String framexpath1 = "//*[@class='modal_content']//h4[2]";
	String OCA2pageElement1 = "//*[@id='termsAndConditionsForm']//*[@id='wrap']//h3";
	String iframexpathTerms = "//*[contains(@class,'mce-tinymce')]//*[contains(@class,'mce-container-body')]//*[contains(@class,'mce-edit-area')]//iframe[@id='texta_ifr']";
	String DesginpageHeader = "//*[@id='wrap']//h3";
	String thanksMsgRadiobutton = "//*[@id='FinalizeForm']//*[@id='onlyThanks']";
	String DecisionMsgRadiobutton = "//*[@id='FinalizeForm']//*[@id='showDecision']";
	String Tiframexpath = "//*[@id='mce_4']//*[@id='mce_4-body']//*[@id='mce_8']/iframe[@id='thankYouMessage_ifr']";
	String Aiframexpath = "//*[@id='mce_12']//*[@id='mce_12-body']//*[@id='mce_16']/iframe[@id='cfaDecisionMessageInfo[0].thankYouMessage_ifr']";
	String Diframexpath = "//*[@id='mce_20']//*[@id='mce_20-body']//*[@id='mce_24']/iframe[@id='cfaDecisionMessageInfo[1].thankYouMessage_ifr']";
	String PFiframexpath = "//*[@id='mce_28']//*[@id='mce_28-body']//*[@id='mce_32']/iframe[@id='cfaDecisionMessageInfo[2].thankYouMessage_ifr']";
	String cmatchingRadiobtn = "//*[@class='row row-buffer']//*[@id='companyMatchInd']";
	String udfTextBoxXpath = "//*[@id='working-add-row']//*[contains(.,'xlsectionname')]//following-sibling::div//*[contains(@class,'form-inline')]//*[@id='working-new-question']";

	public void navigateConfigureYourCreditApplicationPage() {

		tabAdmin.waitUntilClickable();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), adminTab);
		tabAdmin.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), creditAppLinkXPath);
		creditAppLinkEle.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				configYourCreditAppLinkXPath);
		lnkConfigureYourCreditApplication.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), createnewappbtn);

	}

	public void applicationNameEnter(String ApplicationName, String FileName)
			throws Exception {

		CNAbutton.waitUntilPresent();
		String applicationname;
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), createnewappbtn);
		CNAbutton.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
		getDriver().switchTo().frame(iFrameEle);
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssms");
		Date date = new Date();
		applicationname = ApplicationName + dateFormat.format(date);
		String filePath1 = System.getProperty("user.dir");
		String mypath = filePath1.replace(":", ":\\");
		String filePath = mypath + FileName;
		System.out.println("File Path============" + filePath);
		// String filePath =
		// System.getProperty("user.dir")+"\\src\\test\\resources\\OCA\\applicationName.txt";
		// FileWriter fstreamWrite = new FileWriter(filePath, true); //-- it
		// will not over write
		FileWriter fstreamWrite = new FileWriter(filePath, false); // -- it will
																	// over
																	// write
		BufferedWriter out = new BufferedWriter(fstreamWrite);
		out.write(applicationname);
		out.write("\r\n");
		out.close();
		fstreamWrite.close();
		UIHelper.highlightElement(getDriver(), NameForCNAForm);
		NameForCNAForm.clear();
		NameForCNAForm.type(applicationname);

	}

	public void applicationNameEnterDefaultFields(String ApplicationName)
			throws Exception {
		String applicationname;
		CNAbutton.waitUntilPresent();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), createnewappbtn);
		CNAbutton.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
		System.out
				.println("iframe going to display-------------------------------------");
		getDriver().switchTo().frame(iFrameEle);
		System.out.println("iframe switched--------------------------------");
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssms");
		Date date = new Date();
		applicationname = ApplicationName + dateFormat.format(date);
		System.out.println("application name-------------------"
				+ applicationname);
		UIHelper.highlightElement(getDriver(), NameForCNAForm);
		NameForCNAForm.clear();
		NameForCNAForm.type(applicationname);

	}

	public void click_Create_Btn() {

		createbtn.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), createbtn);
		createbtn.click();
		getDriver().switchTo().defaultContent();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), companyInfopage);
		UIHelper.highlightElement(getDriver(), ConfigPageHeader);

	}

	public void SelectApplicationTemplate(String TemplateOption) {

		CreatefromExistingBtn.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), CreatefromExistingBtn);
		CreatefromExistingBtn.click();
		UIHelper.highlightElement(getDriver(), cnalistbox);
		cnalistbox.selectByVisibleText(TemplateOption);

	}

	public void SelectApplicationForExistingTemplate(String FileName)
			throws Exception {
		CreatefromExistingBtn.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), CreatefromExistingBtn);
		CreatefromExistingBtn.click();
		UIHelper.highlightElement(getDriver(), cnalistbox);
		String line = "";
		String filePath1 = System.getProperty("user.dir");
		String mypath = filePath1.replace(":", ":\\");
		String filePath = mypath + FileName;
		System.out.println("File Path============" + filePath);

		BufferedReader br = new BufferedReader(new FileReader(filePath));
		try {
			line = br.readLine();
			br.close();
			System.out.println("application Name-----------------" + line);
		} finally {

		}
		waitFor(5000).milliseconds();
		cnalistbox.selectByVisibleText(line.trim());
	}

	public boolean ApplicationNamedhasplayed() {
		waitFor(15000).milliseconds();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), companyInfopage);
		companyInfopagewidget.waitUntilPresent();
		if (ConfigPageHeader.isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}

	public void editFieldName(String xlfieldname, String xlsectionname,
			String ModifiedFieldName) {
		Questionname = (getDriver()
				.findElement(By
						.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ xlfieldname + "')]")));

		Donebtnxpath = (getDriver()
				.findElement(By
						.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ xlfieldname
								+ "')]//following-sibling::input[@value='Done']")));
		if (Questionname.isDisplayed()) {
			System.out
					.println("filed is displayed--------------------------------");
			Questionname.clear();
			Questionname.sendKeys(ModifiedFieldName);
			waitFor(2000).milliseconds();
			Donebtnxpath.click();
			System.out.println("done buton has clicked------------");
			if (savebtn.isPresent()) {
				System.out
						.println("save button inside if method--------------------");
				UIHelper.highlightElement(getDriver(), savebtn);
				savebtn.click();

			}

		}

	}

	public void editUDFFieldName(String xlfieldname, String xlsectionname,
			String ModifiedFieldName) {

		Questionname = (getDriver()
				.findElement(By
						.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ xlfieldname + "')]")));

		Donebtnxpath = (getDriver()
				.findElement(By
						.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ xlfieldname
								+ "')]//following-sibling::input[@value='Done']")));
		if (Questionname.isDisplayed()) {
			System.out
					.println("filed is displayed--------------------------------");
			Questionname.clear();
			Questionname.sendKeys(ModifiedFieldName);
			waitFor(2000).milliseconds();
			Donebtnxpath.click();
			System.out.println("done buton has clicked------------");
			waitFor(3000).milliseconds();
			// if((find(By.xpath("//*[@id='editModalView']//*[@class='modal_content']//*[@id='saveBtn']"))).isPresent()){
			if (savebtn.isPresent()) {
				System.out
						.println("udf save button has present ------------------------------");
				WebElementFacade udfsavebtn = find(By
						.xpath("//*[@id='editModalView']//*[@class='modal_content']//*[@id='saveBtn']"));
				System.out
						.println("udf save button inside if method--------------------");
				UIHelper.highlightElement(getDriver(), udfsavebtn);
				udfsavebtn.click();
				if (savebtn.isCurrentlyVisible()) {
					savebtn.click();
				}

			}

		}

	}

	public boolean isFieldNameModified(String xlsectionname,
			String ModifiedFieldName) {
		Questionname = (getDriver()
				.findElement(By
						.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ ModifiedFieldName + "')]")));
		String afieldtext = Questionname.getAttribute("value");
		System.out.println("field name has modified ------------------"
				+ afieldtext);
		if (afieldtext.equalsIgnoreCase(ModifiedFieldName)) {
			System.out.println("return true----------------------------");
			return true;
		} else {
			System.out.println("return false----------------------------");
			return false;
		}

	}

	public void remove_Field(String xlfieldname, String xlsectionname) {

		RemovedQuestionname = (getDriver()
				.findElement(By
						.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ xlfieldname + "')]")));

		RemovedQuestionbtn = getDriver()
				.findElement(
						By.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ xlfieldname
								+ "')]//ancestor::div[1]//following-sibling::div//span[@class='glyphicon row-remove']"));

		System.out.println("inside remvoe method----------------");
		if (RemovedQuestionname.isDisplayed()) {
			System.out
					.println("removed question displayed-----------------------------");
			UIHelper.highlightElement(getDriver(), RemovedQuestionname);
			RemovedQuestionbtn.click();

		}

	}

	public boolean is_Field_has_Removed(String xlfieldname,
			String xlsectionname, String Datatype) {
		String value = "1";
		WebElement ExistingQuestion = (getDriver()
				.findElement(By
						.xpath("//*[@id='working-add-row']//*[contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div//div//ul//li//a[contains(text(),'Choose From Existing Questions')]")));

		List<WebElement> Questionslist = (getDriver()
				.findElements(By
						.xpath("//*[@id='working-add-row']//*[contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div//div[contains(@class,'tab-pane')]//select//option")));

		String removedfiled = xlfieldname + "(" + Datatype + ")";

		UIHelper.highlightElement(getDriver(), ExistingQuestion);
		ExistingQuestion.click();
		for (WebElement ele : Questionslist) {
			if (ele.getText().equalsIgnoreCase(removedfiled)) {
				System.out
						.println("fiedl has remove--------------------------");
				value = "2";
				break;

			} else {
				System.out
						.println("fiedl has not removed--------------------------");
				value = "3";
			}

		}
		System.out.println("value returned------------" + value);
		if (value.equals("2")) {
			return true;
		} else {
			return false;
		}
	}

	public void Adding_A_Field(String xlfieldname, String Datatype,
			String xlsectionname) {

		WebElement ExistingQuestion = (getDriver()
				.findElement(By
						.xpath("//*[@id='working-add-row']//*[contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div//div//ul//li//a[contains(text(),'Choose From Existing Questions')]")));

		WebElement Questionslistbox = (getDriver()
				.findElement(By
						.xpath("//*[@id='working-add-row']//*[contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div//div[contains(@class,'tab-pane')]//select")));

		List<WebElement> Questionslist = (getDriver()
				.findElements(By
						.xpath("//*[@id='working-add-row']//*[contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div//div[contains(@class,'tab-pane')]//select//option")));
		WebElement Addbtn = (getDriver()
				.findElement(By
						.xpath("//*[@id='working-add-row']//*[contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div//div[contains(@class,'tab-pane')]//button[@id='add-fixed-question-value']")));

		String removedfiled = xlfieldname + "(" + Datatype + ")";

		UIHelper.highlightElement(getDriver(), ExistingQuestion);
		ExistingQuestion.click();
		Select selectElement = new Select(Questionslistbox);
		for (WebElement ele : Questionslist) {
			if (ele.getText().equalsIgnoreCase(removedfiled)) {
				selectElement.selectByVisibleText(removedfiled);
				System.out.println("field has added--------------------------");
				Addbtn.click();
				break;

			} else {
				System.out
						.println("field has not added--------------------------");

			}

		}

	}

	public boolean is_Field_Added(String xlfieldname, String xlsectionname) {
		String value = "1";
		List<WebElement> Questionname = (getDriver()
				.findElements(By
						.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//div//input[@type='text']")));
		for (WebElement options : Questionname) {
			System.out.println("field names------------------------"
					+ options.getAttribute("value"));
			if (options.getAttribute("value").contains(xlfieldname)) {
				UIHelper.mouseOveranElement(getDriver(), options);
				// UIHelper.highlightElement(getDriver(), options);
				System.out
						.println("filed is added and displayed--------------------------------");
				value = "2";
				break;
			} else {

				value = "3";
			}

		}
		if (value.equals("2")) {
			System.out
					.println("filed is added true--------------------------------");
			return true;
		} else {
			System.out
					.println("filed is added false--------------------------------");
			return false;
		}

	}

	public void click_On_Display_Section_Condition(String xlsectionname) {

		WebElement SectionCheckbox = (getDriver()
				.findElement(By
						.xpath("//*[@id='manageSectionDivId']//*[@id='sortableLeftCol']//*//span/a[contains(.,'"
								+ xlsectionname
								+ "')]//ancestor::span[1]//preceding-sibling::span//input")));

		WebElement Sectionname = (getDriver()
				.findElement(By
						.xpath("//*[@id='manageSectionDivId']//*[@id='sortableLeftCol']//*//span/a[contains(.,'"
								+ xlsectionname + "')]")));

		String sectiondisplayed = "//*[@id='pageListContentWrap']//div//h4//span[contains(.,'"
				+ xlsectionname + "')]";
		Sectionname.click();
		if (!SectionCheckbox.isSelected()) {
			SectionCheckbox.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					sectiondisplayed);
		}

		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), sectiondisplayed);

		if ((getDriver()
				.findElement(By
						.xpath("//*[@id='pageListContentWrap']//div//h4//span[contains(.,'"
								+ xlsectionname
								+ "')]//preceding-sibling::a//span")))
				.isDisplayed()) {
			WebElement displaylink = (getDriver()
					.findElement(By
							.xpath("//*[@id='pageListContentWrap']//div//h4//span[contains(.,'"
									+ xlsectionname
									+ "')]//preceding-sibling::a//span")));
			displaylink.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);

		}

	}

	public void placeSectionCondition(String ConditionSection,
			String fieldName, String logic, String expressionVal) {

		int flag = 0;
		getDriver().switchTo().frame(iFrameEle);
		System.out.println("iframe switched--------------------------------");
		UIHelper.highlightElement(getDriver(), selectSection);
		for (WebElement options : selectSectionxpath) {
			if (options.getText().contains(ConditionSection)) {
				flag = 1;
				System.out
						.println("ConditionSection is displayed------------------------");
				selectSection.selectByVisibleText(ConditionSection);
				selectField.selectByVisibleText(fieldName);
				if (logic.contains("Is Blank")
						|| logic.contains("Is Not Blank")) {
					selectLogic.selectByVisibleText(logic);
				} else {
					selectLogic.selectByVisibleText(logic);
					expressionValue.sendKeys(expressionVal);
				}
				UIHelper.highlightElement(getDriver(), btnSet);
				btnSet.click();
				getDriver().switchTo().defaultContent();
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						companyInfopage);
				break;

			} else {
				System.out
						.println("ConditionSection is not displayed------------------------");
				flag = 2;
			}

		}
		if (flag != 1) {
			System.out
					.println("ConditionSection has not displayed so cancel button going to click-------------");
			btnCancel.click();
			getDriver().switchTo().defaultContent();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), companyInfopage);

		}

	}

	// selecting a required section from manage sections

	public void required_Section_Has_Selected(String xlsectionname) {

		WebElement SectionCheckbox = (getDriver()
				.findElement(By
						.xpath("//*[@id='manageSectionDivId']//*[@id='sortableLeftCol']//*//span/a[contains(.,'"
								+ xlsectionname
								+ "')]//ancestor::span[1]//preceding-sibling::span//input")));

		WebElement Sectionname = (getDriver()
				.findElement(By
						.xpath("//*[@id='manageSectionDivId']//*[@id='sortableLeftCol']//*//span/a[contains(.,'"
								+ xlsectionname + "')]")));

		String sectiondisplayed = "//*[@id='pageListContentWrap']//div//h4//span[contains(.,'"
				+ xlsectionname + "')]";

		if (!SectionCheckbox.isSelected()) {
			SectionCheckbox.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					sectiondisplayed);
		}
		Sectionname.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), sectiondisplayed);

	}

	public boolean count_Of_Section_Has_Selected(String xlsectionname) {

		WebElement SectionCheckbox = (getDriver()
				.findElement(By
						.xpath("//*[@id='manageSectionDivId']//*[@id='sortableLeftCol']//*//span/a[contains(.,'"
								+ xlsectionname
								+ "')]//ancestor::span[1]//preceding-sibling::span//input")));

		WebElement Sectionname = (getDriver()
				.findElement(By
						.xpath("//*[@id='manageSectionDivId']//*[@id='sortableLeftCol']//*//span/a[contains(.,'"
								+ xlsectionname + "')]")));

		UIHelper.highlightElement(getDriver(), Sectionname);
		if (SectionCheckbox.isSelected()) {

			return true;
		} else {
			return false;
		}

	}

	public void Select_Section_Checkbox(String xlsectionname) {

		WebElement SectionCheckbox = (getDriver()
				.findElement(By
						.xpath("//*[@id='manageSectionDivId']//*[@id='sortableLeftCol']//*//span/a[contains(.,'"
								+ xlsectionname
								+ "')]//ancestor::span[1]//preceding-sibling::span//input")));

		WebElement Sectionname = (getDriver()
				.findElement(By
						.xpath("//*[@id='manageSectionDivId']//*[@id='sortableLeftCol']//*//span/a[contains(.,'"
								+ xlsectionname + "')]")));

		UIHelper.highlightElement(getDriver(), Sectionname);
		if (!SectionCheckbox.isSelected()) {
			SectionCheckbox.click();
		}

	}

	public void Select_GuarantorSection_Checkbox(String xlsectionname) {

		WebElement SectionCheckbox = (getDriver()
				.findElement(By
						.xpath("//*[@id='manageSectionDivId']//*[@id='sortableLeftCol']//*//span/a[contains(.,'"
								+ xlsectionname
								+ "')]//ancestor::span[1]//preceding-sibling::span//input")));

		WebElement Sectionname = (getDriver()
				.findElement(By
						.xpath("//*[@id='manageSectionDivId']//*[@id='sortableLeftCol']//*//span/a[contains(.,'"
								+ xlsectionname + "')]")));

		UIHelper.highlightElement(getDriver(), Sectionname);
		Sectionname.click();
		if (SectionCheckbox.isEnabled()) {
			if (!SectionCheckbox.isSelected()) {
				SectionCheckbox.click();
			}
		} else {
			getDriver().navigate().refresh();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), companyInfopage);
			SectionCheckbox.isEnabled();
			if (!SectionCheckbox.isSelected()) {
				SectionCheckbox.click();
			}
		}

	}

	public void click_On_Display_Question_Condition(String xlsectionname,
			String xlfieldname) {

		if ((getDriver()
				.findElement(By
						.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//div//input[contains(@value,'"
								+ xlfieldname.trim() + "')]"))).isDisplayed()) {
			WebElement questionconditionname = (getDriver()
					.findElement(By
							.xpath("//*[contains(@class,'questions-section') and contains(.,'"
									+ xlsectionname
									+ "')]//following-sibling::div[contains(@class,'row question-row')]//div//input[contains(@value,'"
									+ xlfieldname.trim() + "')]")));

			UIHelper.highlightElement(getDriver(), questionconditionname);

			WebElement questioncondition = (getDriver()
					.findElement(By
							.xpath("//*[contains(@class,'questions-section') and contains(.,'"
									+ xlsectionname
									+ "')]//following-sibling::div[contains(@class,'row question-row')]//div//input[contains(@value,'"
									+ xlfieldname
									+ "')]//ancestor::div[1]//following-sibling::div//a//span")));
			questioncondition.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);

		}
	}

	public void make_Field_Manadatory(String xlfieldname, String xlsectionname) {

		Questionname = (getDriver()
				.findElement(By
						.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ xlfieldname + "')]")));

		WebElement Mandatoryfield = getDriver()
				.findElement(
						By.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ xlfieldname
								+ "')]//ancestor::div[1]//following-sibling::div[2]//input"));

		if (Questionname.isDisplayed()) {
			UIHelper.highlightElement(getDriver(), Questionname);
			if (!Mandatoryfield.isSelected()) {
				Mandatoryfield.click();
			}

		}

	}

	public boolean verify_Manadatory_Field(String xlfieldname,
			String xlsectionname) {

		Questionname = (getDriver()
				.findElement(By
						.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ xlfieldname + "')]")));

		WebElement Mandatoryfield = getDriver()
				.findElement(
						By.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ xlfieldname
								+ "')]//ancestor::div[1]//following-sibling::div[2]//input"));

		UIHelper.highlightElement(getDriver(), Questionname);
		if (Mandatoryfield.isSelected()) {
			return true;
		} else {
			return false;
		}

	}

	public void make_Field_Non_Manadatory(String xlfieldname,
			String xlsectionname) {

		Questionname = (getDriver()
				.findElement(By
						.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ xlfieldname + "')]")));

		WebElement Mandatoryfield = getDriver()
				.findElement(
						By.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ xlfieldname
								+ "')]//ancestor::div[1]//following-sibling::div[2]//input"));

		if (Questionname.isDisplayed()) {
			UIHelper.highlightElement(getDriver(), Questionname);
			if (Mandatoryfield.isSelected()) {
				Mandatoryfield.click();
			}

		}

	}

	public boolean verify_NonManadatory_Field(String xlfieldname,
			String xlsectionname) {

		Questionname = (getDriver()
				.findElement(By
						.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ xlfieldname + "')]")));

		WebElement Mandatoryfield = getDriver()
				.findElement(
						By.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ xlfieldname
								+ "')]//ancestor::div[1]//following-sibling::div[2]//input"));

		UIHelper.highlightElement(getDriver(), Questionname);
		if (!Mandatoryfield.isSelected()) {
			return true;
		} else {
			return false;
		}

	}

	public void Click_On_Continue_Btn1() {

		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", continuetostep2);
		continuetostep2.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), continuetostep2);
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].click();", continuetostep2);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), OCA2pageElement1);

	}

	public boolean isTermsAndConditionsPagedisplayed() {

		if (termsAndConditionsPageHeader.isVisible()) {
			UIHelper.highlightElement(getDriver(), termsAndConditionsPageHeader);
			return true;
		} else {
			return false;
		}
	}

	public void enterTermsAndCondtions(String Title) {
		TcTitle.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), TcTitle);
		TcTitle.type(Title);
	}

	public void enter_Content(String Content) {

		getDriver().switchTo().frame(iFrameEleTerms);
		txtArea = getDriver().findElement(By.id("tinymce"));
		txtArea.clear();
		txtArea.sendKeys(Content);
		// ((JavascriptExecutor)
		// driver).executeScript("arguments[0].scrollIntoView(true);", txtArea);
		// ((JavascriptExecutor)
		// driver).executeScript("arguments[0].value=Content;", txtArea);

		getDriver().switchTo().defaultContent();
		/*
		 * UIHelper.waitForVisibilityOfEleByXpath(driver,
		 * "//*[@id='characterCount']/span"); String characters =
		 * driver.findElement(
		 * By.xpath(".//*[@id='characterCount']/span")).getText(); String[]
		 * charLen = characters.split(":"); int charLength =
		 * Integer.parseInt(charLen[1]); if (charLength < Content.length()) { }
		 */
	}

	public void selectEmail() {
		UIHelper.highlightElement(getDriver(), ETCcheckbox);
		if (!ETCcheckbox.isSelected()) {
			ETCcheckbox.click();
		}

	}

	public boolean verifyEmailhasSelected() {

		if (ETCcheckbox.isSelected()) {
			return true;
		} else {
			return false;
		}

	}

	public void enterSignature(String Lable, String Title) {
		Label1.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), Label1);
		Label1.sendKeys(Lable);
		UIHelper.highlightElement(getDriver(), Title1);
		Title1.sendKeys(Title);
	}

	public void Click_On_Continue_Btn2() {

		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", ContinetoStep3btn);
		UIHelper.highlightElement(getDriver(), ContinetoStep3btn);
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].click();", ContinetoStep3btn);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), DesginpageHeader);

	}

	public boolean isAppearanceAndSettingsPagedisplayed() {

		if (DesginPageHeaderelement.isVisible()) {
			UIHelper.highlightElement(getDriver(), DesginPageHeaderelement);
			return true;
		} else {
			return false;
		}

	}

	public void select_Thanks_Msg_RadioBtn_And_Enter_Message(String text) {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				thanksMsgRadiobutton);
		selectDecisionNEnterMessage(text, thanksradiobtn, Tmessagehighlight,
				Thankyouiframexpath, Tiframexpath);
	}

	public void select_Decision_Msg_RadioBtn_And_Enter_Approved_Message(
			String text) {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				DecisionMsgRadiobutton);
		selectDecisionNEnterMessage(text, decessionradiobtn, Amessagehighlight,
				Approvediframexpath, Aiframexpath);
	}

	public void select_Decision_Msg_RadioBtn_And_Enter_Declined_Message(
			String text) {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				DecisionMsgRadiobutton);
		selectDecisionNEnterMessage(text, decessionradiobtn, Dmessagehighlight,
				Declinediframexpath, Diframexpath);
	}

	public void select_Decision_Msg_RadioBtn_And_Enter_Pending_Message(
			String text) {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				DecisionMsgRadiobutton);
		selectDecisionNEnterMessage(text, decessionradiobtn,
				PFmessagehighlight, pendingiframexpath, PFiframexpath);
	}

	public void selectDecisionNEnterMessage(String atext,
			WebElementFacade element, WebElementFacade elementTinyMce,
			WebElementFacade elementTinyMceXpath, String framexpath) {

		if (element.isSelected()) {
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
			enterMessage(atext, elementTinyMce, elementTinyMceXpath);
		} else {
			element.click();
			if (element.isSelected()) {
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
				enterMessage(atext, elementTinyMce, elementTinyMceXpath);
			}
		}

	}

	public void enterMessage(String atext, WebElementFacade elementTinyMce,
			WebElementFacade elementTinyMceXpath) {
		UIHelper.highlightElement(getDriver(), elementTinyMce);
		getDriver().switchTo().frame(elementTinyMceXpath);
		txtArea = getDriver().findElement(By.id("tinymce"));
		txtArea.clear();
		txtArea.sendKeys(atext);
		getDriver().switchTo().defaultContent();
	}

	public void ThanksMsgRedirect(String mailid) {
		UIHelper.highlightElement(getDriver(), TMailtextbox);
		if (!TMailchekbox.isSelected()) {
			TMailchekbox.click();
			TMailtextbox.sendKeys(mailid);
		} else {
			TMailtextbox.sendKeys(mailid);
		}
	}

	public void PublishBtnclick() {

		PublishBtn.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), PublishBtn);
		PublishBtn.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), applinamewidget);

	}

	public void SaveandReturn() {

		SaveandReturnbtn.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), SaveandReturnbtn);
		SaveandReturnbtn.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), applinamewidget);

	}

	public void uploadLogo(String filename) throws Exception {
		try {
			uploadfile.waitUntilClickable();
			UIHelper.highlightElement(getDriver(), uploadfile);
			uploadfile.click();
			String filePath1 = System.getProperty("user.dir");
			String mypath = filePath1.replace(":", ":\\");
			String filePath = mypath + filename;
			System.out.println("File Path============" + filePath);
			// uploadfile.sendKeys(filePath);
			// String
			// filePath="D:\\BDDDnbi\\src\\test\\resources\\OCA\\google.exe";
			Runtime.getRuntime().exec(filePath);
			waitFor(10000).milliseconds();
			UIHelper.highlightElement(getDriver(), Uploadbtn);
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].click();", Uploadbtn);
			String logoxpath = ".//*[@id='FinalizeForm']//img[@id='imgId']";
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), logoxpath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean verify_Default_FieldName(String xlfieldname,
			String xlsectionname) {
		System.out.println("Default field name before verify-------------"
				+ xlfieldname);
		if ((getDriver()
				.findElement(By
						.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[@type='text'] [contains(@value,'"
								+ xlfieldname.trim() + "')]"))).isDisplayed()) {
			Questionname = (getDriver()
					.findElement(By
							.xpath("//*[contains(@class,'questions-section') and contains(.,'"
									+ xlsectionname
									+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
									+ xlfieldname.trim() + "')]")));
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", Questionname);
			UIHelper.highlightElement(getDriver(), Questionname);
			System.out.println("Default field is available-------------"
					+ xlfieldname);
			return true;

		} else {
			System.out.println("Default field not available-------------"
					+ xlfieldname);
			return false;
		}

	}

	public void click_Write_Your_Own_Questions_Tab(String xlsectionname) {
		if ((find(By
				.xpath("//*[@id='working-add-row']//*[contains(.,'"
						+ xlsectionname
						+ "')]//following-sibling::div//div//ul//li//a[contains(text(),'Write Your Own Question')]")))
				.isPresent())

		{
			tabWriteQuestions = (find(By
					.xpath("//*[@id='working-add-row']//*[contains(.,'"
							+ xlsectionname
							+ "')]//following-sibling::div//div//ul//li//a[contains(text(),'Write Your Own Question')]")));
			UIHelper.mouseOveranElement(getDriver(), tabWriteQuestions);
			tabWriteQuestions.click();
			udfTextBoxXpath = udfTextBoxXpath.replace("xlsectionname",
					xlsectionname);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), udfTextBoxXpath);

		}
	}

	public void enter_UDF_Or_FDF_Field_Name(String xlsectionname,
			String FieldName) {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), udfTextBoxXpath);
		txtWriteQuestions = (find(By
				.xpath("//*[@id='working-add-row']//*[contains(.,'"
						+ xlsectionname
						+ "')]//following-sibling::div//*[contains(@class,'form-inline')]//*[@id='working-new-question']")));
		UIHelper.highlightElement(getDriver(), txtWriteQuestions);
		txtWriteQuestions.clear();
		txtWriteQuestions.sendKeys(FieldName);

	}

	public void select_Field_Type_From_List(String xlsectionname,
			String FieldType) {
		SelectType = (find(By
				.xpath("//*[@id='working-add-row']//*[contains(.,'"
						+ xlsectionname
						+ "')]//following-sibling::div//*[contains(@class,'form-inline')]//*[@id='working-new-type']")));
		UIHelper.highlightElement(getDriver(), SelectType);
		SelectType.selectByVisibleText(FieldType);

	}

	public void udfcreation2(String xlsectionname, String FieldName,
			String FieldType) {
		if ((find(By
				.xpath("//*[@id='working-add-row']//*[contains(.,'"
						+ xlsectionname
						+ "')]//following-sibling::div//div//ul//li//a[contains(text(),'Write Your Own Question')]")))
				.isPresent())

		{
			tabWriteQuestions = (find(By
					.xpath("//*[@id='working-add-row']//*[contains(.,'"
							+ xlsectionname
							+ "')]//following-sibling::div//div//ul//li//a[contains(text(),'Write Your Own Question')]")));
			UIHelper.mouseOveranElement(getDriver(), tabWriteQuestions);
			waitFor(1000).milliseconds();
			tabWriteQuestions.click();
			waitFor(1000).milliseconds();
			udfTextBoxXpath = udfTextBoxXpath.replace("xlsectionname",
					xlsectionname);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), udfTextBoxXpath);

		}
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), udfTextBoxXpath);
		txtWriteQuestions = (find(By
				.xpath("//*[@id='working-add-row']//*[contains(.,'"
						+ xlsectionname
						+ "')]//following-sibling::div//*[contains(@class,'form-inline')]//*[@id='working-new-question']")));
		UIHelper.highlightElement(getDriver(), txtWriteQuestions);
		txtWriteQuestions.clear();
		txtWriteQuestions.sendKeys(FieldName);
		SelectType = (find(By
				.xpath("//*[@id='working-add-row']//*[contains(.,'"
						+ xlsectionname
						+ "')]//following-sibling::div//*[contains(@class,'form-inline')]//*[@id='working-new-type']")));
		UIHelper.highlightElement(getDriver(), SelectType);
		SelectType.selectByVisibleText(FieldType);
	}

	public void udfcreation(String xlsectionname, String FieldName,
			String FieldType, String lableName, String lableValue) {
		if ((find(By
				.xpath("//*[@id='working-add-row']//*[contains(.,'"
						+ xlsectionname
						+ "')]//following-sibling::div//div//ul//li//a[contains(text(),'Write Your Own Question')]")))
				.isPresent())

		{
			tabWriteQuestions = (find(By
					.xpath("//*[@id='working-add-row']//*[contains(.,'"
							+ xlsectionname
							+ "')]//following-sibling::div//div//ul//li//a[contains(text(),'Write Your Own Question')]")));
			UIHelper.mouseOveranElement(getDriver(), tabWriteQuestions);
			tabWriteQuestions.click();
			udfTextBoxXpath = udfTextBoxXpath.replace("xlsectionname",
					xlsectionname);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), udfTextBoxXpath);

		}
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), udfTextBoxXpath);
		txtWriteQuestions = (find(By
				.xpath("//*[@id='working-add-row']//*[contains(.,'"
						+ xlsectionname
						+ "')]//following-sibling::div//*[contains(@class,'form-inline')]//*[@id='working-new-question']")));
		UIHelper.highlightElement(getDriver(), txtWriteQuestions);
		txtWriteQuestions.clear();
		txtWriteQuestions.sendKeys(FieldName);
		SelectType = (find(By
				.xpath("//*[@id='working-add-row']//*[contains(.,'"
						+ xlsectionname
						+ "')]//following-sibling::div//*[contains(@class,'form-inline')]//*[@id='working-new-type']")));
		UIHelper.highlightElement(getDriver(), SelectType);
		SelectType.selectByVisibleText(FieldType);

		if (FieldType == "List") {
			String addNewFiledBtnxpath = "//*[@id='working-add-row']//*[contains(.,'"
					+ xlsectionname
					+ "')]//following-sibling::div//*[@class='row newLabel addQueRowWrap']//*[@id='addListDataType'][@value='Add New Field']";

			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					addNewFiledBtnxpath);
			WebElementFacade addNewFiledBtn = (find(By
					.xpath(addNewFiledBtnxpath)));
			String[] lables = lableName.split(":");
			for (int i = 0; i < lables.length; i++) {
				addNewFiledBtn.click();
				waitFor(2000).milliseconds();
			}
			String[] lableValues = lableValue.split(":");
			int lableValuecount = lableValues.length;
			int vcount = lableValuecount;
			String eneterLableValuexpath = "//*[@id='working-add-row']//*[contains(.,'"
					+ xlsectionname
					+ "')]//following-sibling::div//*[@class='row newLabel addQueRowWrap']//table[@id='addQueRow']//input[@name='labelValue']";

			List<WebElementFacade> lableValuelist = (findAll(By
					.xpath(eneterLableValuexpath)));
			for (WebElementFacade lablev : lableValuelist) {
				System.out.println("lable value need to enter--------"
						+ lableValues[lableValuecount - vcount]);
				lablev.sendKeys(lableValues[lableValuecount - vcount]);
				vcount--;
			}
			String[] lablenames = lableName.split(":");
			int lablenamecount = lablenames.length;
			int count = lablenamecount;
			String enterLableNamexpath = "//*[@id='working-add-row']//*[contains(.,'"
					+ xlsectionname
					+ "')]//following-sibling::div//*[@class='row newLabel addQueRowWrap']//table[@id='addQueRow']//input[@name='labelName']";

			List<WebElementFacade> lableNamelist = (findAll(By
					.xpath(enterLableNamexpath)));
			for (WebElementFacade lablen : lableNamelist) {
				System.out.println("lable name need to enter--------"
						+ lablenames[lablenamecount - count]);
				lablen.sendKeys(lablenames[lablenamecount - count]);

				count--;
			}
		}

	}

	public void click_Add_Button_For_UDF_Or_FDF(String xlsectionname) {
		butnAdd = (find(By
				.xpath("//*[@id='working-add-row']//*[contains(.,'"
						+ xlsectionname
						+ "')]//following-sibling::Div//*[contains(@class,'form-inline')]//*[contains(@class,'add-question btn btn-default')]")));
		butnAdd.click();
		UIHelper.waitForPageToLoad(getDriver());

	}

	public boolean verify_Fieldname_In_popup() {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
		getDriver().switchTo().frame(iFrameEle);
		if (displayTextElement.isVisible()) {
			UIHelper.highlightElement(getDriver(), displayTextElement);
			return true;

		} else {
			return false;
		}

	}

	public void select_Data_Type_FDF(String DataType) {
		if (calculatedOutPutType.isVisible()) {
			calculatedOutPutType.selectByVisibleText(DataType);
		}

	}

	public boolean verify_VeriableName(String VeriableName) {
		UIHelper.highlightElement(getDriver(), selectVeriable1);
		for (WebElementFacade Vname : selectVeriable) {

			if (Vname.getText().contains(VeriableName)) {
				System.out.println("veriable name is matched----------------"
						+ Vname.getText());
				vFlag = 1;
				break;
			} else {
				System.out.println("veriable name not matched----------------"
						+ Vname.getText());
				vFlag = 2;
			}

		}
		System.out.println("return veriable value-----------------------"
				+ vFlag);
		if (vFlag == 1) {
			return true;

		} else {
			return false;
		}
	}

	public boolean verify_Operator_Name(String OperatorName) {
		UIHelper.highlightElement(getDriver(), selectOperator1);
		for (WebElementFacade Opname : selectOperator) {
			if (Opname.getText().contains(OperatorName)) {
				System.out.println("veriable name is matched----------------"
						+ Opname.getText());
				vFlag = 1;
				break;
			} else {
				System.out.println("veriable name not matched----------------"
						+ Opname.getText());
				vFlag = 2;
			}

		}
		System.out.println("return operator value-----------------------"
				+ vFlag);
		if (vFlag == 1) {
			return true;

		} else {
			return false;
		}
	}

	public void type_ConditionIn_TextArea(String Condition) {
		if (textArea.isVisible()) {
			UIHelper.highlightElement(getDriver(), textArea);
			textArea.clear();
			textArea.sendKeys(Condition);

		}
	}

	public void Click_Cal_Submit_Btn(String xlsectionname) {
		CalsubmitButton.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), CalsubmitButton);
		CalsubmitButton.click();
		/*
		 * //error message handled here waitFor(4000).milliseconds();
		 * if(Calerrormessage.isVisible()){ CalCancelButton.click();
		 * 
		 * }
		 */
		getDriver().switchTo().defaultContent();
		udfTextBoxXpath = udfTextBoxXpath.replace("xlsectionname",
				xlsectionname);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), udfTextBoxXpath);

	}

	public void delete_Field(String xlfieldname, String xlsectionname) {

		DeleteQuestionname = (getDriver()
				.findElement(By
						.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@type,'text')][contains(@value,'"
								+ xlfieldname + "')]")));

		DeleteQuestionbtn = getDriver()
				.findElement(
						By.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ xlfieldname
								+ "')]//ancestor::div[1]//following-sibling::div//span[@class='glyphicon row-delete']"));
		DeleteQuestionname.isDisplayed();
		UIHelper.highlightElement(getDriver(), DeleteQuestionname);
		DeleteQuestionbtn.click();
		waitFor(10000).milliseconds();
		alertdeleteudf.click();
		waitFor(5000).milliseconds();

	}

	public void delete_Field2(String xlfieldname, String xlsectionname) {
		UIHelper.waitForPageToLoad(getDriver());
		DeleteQuestionname = (getDriver()
				.findElement(By
						.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@type,'text')][contains(@value,'"
								+ xlfieldname + "')]")));
		((JavascriptExecutor)
				getDriver()).executeScript("arguments[0].scrollIntoView(true);",DeleteQuestionname);
		UIHelper.highlightElement(getDriver(), DeleteQuestionname);
		DeleteQuestionbtn = getDriver()
				.findElement(
						By.xpath("//*[contains(@class,'questions-section') and contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div[contains(@class,'row question-row')]//*//input[contains(@value,'"
								+ xlfieldname
								+ "')]//ancestor::div[1]//following-sibling::div//span[@class='glyphicon row-delete']"));
		((JavascriptExecutor)
				getDriver()).executeScript("arguments[0].scrollIntoView(true);",DeleteQuestionbtn);
		waitFor(1000).milliseconds();
		DeleteQuestionbtn.click();
		UIHelper.waitForPageToLoad(getDriver());
		getDriver().switchTo().frame(iFrameEle);
		waitFor(500).milliseconds();
		alertdeleteudf.click();
		getDriver().switchTo().defaultContent();
/*try{		
		if (timeoutcontinue.isVisible()) {
			UIHelper.highlightElement(getDriver(), timeoutcontinue);
			timeoutcontinue.click();
		}
} catch (Exception e) {
	e.printStackTrace();
}*/
}

	public boolean is_UDF_Or_FDF_Field_has_Removed(String xlfieldname,
			String xlsectionname, String Questiontype) {

		WebElement ExistingQuestion = (getDriver()
				.findElement(By
						.xpath("//*[@id='working-add-row']//*[contains(.,'"
								+ xlsectionname
								+ "')]//following-sibling::div//div//ul//li//a[contains(text(),'Choose From Existing Questions')]")));
		System.out
				.println("went to questions type method------------------------");
		UIHelper.highlightElement(getDriver(), ExistingQuestion);
		// ((JavascriptExecutor)
		// getDriver()).executeScript("arguments[0].click;",ExistingQuestion);

		ExistingQuestion.click();

		WebElementFacade Questionslist = (find(By
				.xpath("//*[@id='working-add-row']//*[contains(.,'"
						+ xlsectionname
						+ "')]//following-sibling::div//div[contains(@class,'tab-pane')]//select")));
		Questionslist.selectByVisibleText(Questiontype);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath1);

		UIHelper.highlightElement(getDriver(), iFrameEle1);
		// getDriver().switchTo().frame(iFrameEle1);
		WebElementFacade QuestionName = (find(By
				.xpath("//*[@class='modal_content']//h4[contains(.,'Custom Questions')]//following-sibling::table[contains(@class,'table udfTable')]//tbody//tr//td[contains(.,'"
						+ xlfieldname + "')]")));

		if (QuestionName.isVisible()) {
			UIHelper.highlightElement(getDriver(), QuestionName);
			modalClosemark.click();
			// getDriver().switchTo().frame(iFrameEle1);
			getDriver().switchTo().defaultContent();
			return true;
		} else {
			modalClosemark.click();
			getDriver().switchTo().defaultContent();
			return false;
		}
	}

	public void allMesssgesRedirect(String Decession, String mailid) {
		UIHelper.waitForPageToLoad(getDriver());
		WebElementFacade decessionCheckbox = (find(By
				.xpath("//*[@id='decision-messages']//strong[contains(.,'"
						+ Decession.trim()
						+ "')]//ancestor::div[1]//following-sibling::div//*[@class='checkbox']//input[@type='checkbox']")));
		WebElementFacade decessionMailbox = (find(By
				.xpath("//*[@id='decision-messages']//strong[contains(.,'"
						+ Decession.trim()
						+ "')]//ancestor::div[1]//following-sibling::div//*[@class='form-group']//input[@type='text']")));
		UIHelper.highlightElement(getDriver(), decessionCheckbox);
		if (!decessionCheckbox.isSelected()) {
			decessionCheckbox.click();
			decessionMailbox.sendKeys(mailid);
		} else {
			decessionMailbox.sendKeys(mailid);
		}
	}

	public void select_Settings_Radio_Button(String RadioButtonOption) {
		UIHelper.waitForPageToLoad(getDriver());
		String settingsRadioBtnXPath = "//*[@id='FinalizeForm']//*[contains(@class,'col-sm-')]//strong[.='"
				+ RadioButtonOption + "']";
		String settingsRadioBtnXPath1 = "//*[@id='FinalizeForm']//*[contains(@class,'col-sm-')]//strong[.='"
				+ RadioButtonOption
				+ "']//ancestor::div[1]//preceding-sibling::div//input[@type='radio']";
		if (RadioButtonOption.contains("Order International Data")) {
			settingsRadioBtn = find(By.xpath(settingsRadioBtnXPath));
			UIHelper.highlightElement(getDriver(), settingsRadioBtn);
			waitFor(15000).milliseconds();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					settingsRadioBtnXPath);
			selectSettingsRadioBtn = find(By.xpath(settingsRadioBtnXPath1));
			selectSettingsRadioBtn.click();
			System.out
					.println("radio btn clicked--------------------------------------");

		} else {
			settingsRadioBtn = find(By.xpath(settingsRadioBtnXPath));
			UIHelper.highlightElement(getDriver(), settingsRadioBtn);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					settingsRadioBtnXPath);
			selectSettingsRadioBtn = find(By.xpath(settingsRadioBtnXPath1));
			UIHelper.highlightElement(getDriver(), selectSettingsRadioBtn);
			selectSettingsRadioBtn.click();

		}

	}

	public void click_Setting_Proceed_Btn() {
		if (settingProceedBtn.isPresent()) {
			settingProceedBtn.click();
			UIHelper.waitForPageToLoad(getDriver());
		}
	}

	public void click_AddNewField_Btn(String xlsectionname, String lableName) {

		String addNewFiledBtnxpath = "//*[@id='working-add-row']//*[contains(.,'"
				+ xlsectionname
				+ "')]//following-sibling::div//*[@class='row newLabel addQueRowWrap']//*[@id='addListDataType'][@value='Add New Field']";

		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), addNewFiledBtnxpath);
		WebElementFacade addNewFiledBtn = (find(By.xpath(addNewFiledBtnxpath)));
		String[] lablename1 = lableName.split(":");
		for (int i = 0; i < lablename1.length; i++) {
			addNewFiledBtn.click();
			waitFor(2000).milliseconds();
		}
	}

	public void enterLablename(String xlsectionname, String lableName) {
		String[] lablename1 = lableName.split(":");
		int lablenamecount = lablename1.length;
		int count = lablenamecount;
		String enterLableNamexpath = "//*[@id='working-add-row']//*[contains(.,'"
				+ xlsectionname
				+ "')]//following-sibling::div//*[@class='row newLabel addQueRowWrap']//table[@id='addQueRow']//input[@name='labelName']";

		List<WebElementFacade> lableNamelist = (findAll(By
				.xpath(enterLableNamexpath)));
		for (WebElementFacade lablen : lableNamelist) {
			System.out.println("lable name need to enter--------"
					+ lablename1[lablenamecount - count]);
			lablen.sendKeys(lablename1[lablenamecount - count]);

			count--;
		}

	}

	public void enterLableValue(String xlsectionname, String lableValue) {
		String[] lableValue1 = lableValue.split(":");
		int lableValuecount = lableValue1.length;
		int vcount = lableValuecount;
		String eneterLableValuexpath = "//*[@id='working-add-row']//*[contains(.,'"
				+ xlsectionname
				+ "')]//following-sibling::div//*[@class='row newLabel addQueRowWrap']//table[@id='addQueRow']//input[@name='labelValue']";

		List<WebElementFacade> lableValuelist = (findAll(By
				.xpath(eneterLableValuexpath)));
		for (WebElementFacade lablev : lableValuelist) {
			System.out.println("lable value need to enter--------"
					+ lableValue1[lableValuecount - vcount]);
			lablev.sendKeys(lableValue1[lableValuecount - vcount]);
			vcount--;
		}

	}

	public void select_Esignature() {
		if (!eSignatureRadioBtn.isSelected()) {
			eSignatureRadioBtn.click();

		}

	}

	public boolean verify_Esignature_Has_Selected() {
		if (eSignatureRadioBtn.isSelected()) {
			return true;

		} else {
			return false;
		}

	}

	public void enter_Letter_Head_Text(String inputText) {
		UIHelper.highlightElement(getDriver(), letterHeadText);
		letterHeadText.sendKeys(inputText);

	}

	public void select_LetterheadText_Alignment(String Alignment) {
		String alignmentXpath = "//*[@id='FinalizeForm']//*[@class='btn-group letterhead-alignment']//button//i[@alignval='"
				+ Alignment.trim() + "']";
		WebElementFacade alignment = find(By.xpath(alignmentXpath));
		alignment.click();
	}

	public void veriableselection(String decesionname, String veriablesection,
			String veriablename) {

		String veriablebtnxpath = "//*[@id='decision-messages']//strong[contains(.,'"
				+ decesionname
				+ "')]//ancestor::div[1]//following-sibling::div[1]//button[@type='button'][contains(.,'Variable')]";
		String veriableModalframexpath = "//*[@id='variableModalView']//*[@class='modal-dialog']//*[@class='modal_content']";
		String veriablesectionXpath = "//*[@id='variableModalView']//h3[contains(.,'"
				+ veriablesection + "')]";
		String veriablenameXpath = "//*[@id='variableModalView']//h3[contains(.,'"
				+ veriablesection
				+ "')]//following-sibling::ul//li//a[contains(.,'"
				+ veriablename + "')]";
		if (decesionname.contains("Approved")) {
			change__ApprovedDecession_Veriable_Message(veriablename);

		} else if (decesionname.contains("Declined")) {
			change__DeclinedDecession_Veriable_Message(veriablename);

		} else if (decesionname.contains("Pending")) {
			change__PendingDecession_Veriable_Message(veriablename);

		}

		WebElementFacade veriablebtn = (find(By.xpath(veriablebtnxpath)));
		veriablebtn.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				veriableModalframexpath);
		WebElementFacade vframe = find(By.xpath(veriableModalframexpath));
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", vframe);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				veriablesectionXpath);
		WebElementFacade veriableSection = find(By.xpath(veriablenameXpath));
		UIHelper.highlightElement(getDriver(), veriableSection);
		WebElementFacade veriablefield = find(By.xpath(veriablenameXpath));

		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", veriablefield);
		UIHelper.highlightElement(getDriver(), veriablefield);
		veriablefield.click();
		UIHelper.waitForPageToLoad(getDriver());
		getDriver().switchTo().defaultContent();
	}

	public void change__ApprovedDecession_Veriable_Message(String VeriableName) {

		setThe_Decession_Veriable_Message(VeriableName, Amessagehighlight,
				Approvediframexpath, Aiframexpath);

	}

	public void change__DeclinedDecession_Veriable_Message(String VeriableName) {

		setThe_Decession_Veriable_Message(VeriableName, Dmessagehighlight,
				Declinediframexpath, Diframexpath);

	}

	public void change__PendingDecession_Veriable_Message(String VeriableName) {

		setThe_Decession_Veriable_Message(VeriableName, PFmessagehighlight,
				pendingiframexpath, PFiframexpath);

	}

	public void setThe_Decession_Veriable_Message(String VeriableName,
			WebElementFacade elementTinyMce,
			WebElementFacade elementTinyMceXpath, String framexpath) {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
		UIHelper.highlightElement(getDriver(), elementTinyMce);
		getDriver().switchTo().frame(elementTinyMceXpath);
		txtArea = getDriver().findElement(By.id("tinymce"));
		String lablename = " " + VeriableName + " : ";
		System.out.println("lable name given------------" + lablename);
		txtArea.sendKeys(lablename);
		System.out.println("enteredmessage=====   " + txtArea.getText());
		getDriver().switchTo().defaultContent();

	}

	public static boolean verifyObjectPresent(WebDriver driver,
			String elementxpath) {

		try {

			driver.findElement(By.xpath(elementxpath));

			return true;

		} catch (Exception e) {

			return false;

		}

	}

	public void enter_Custom_Section_Name(String customSectionName) {

		String customSectionNameXpath = "//*[contains(@class,'questions-section') and contains(.,'"
				+ customSectionName.trim() + "')]";
		UIHelper.highlightElement(getDriver(), customSectionTextBox);
		customSectionTextBox.clear();
		customSectionTextBox.sendKeys(customSectionName.trim());
		customSectionCreateBtn.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				customSectionNameXpath);

	}

	public boolean verify_Custom_Section_Name(String customSectionName) {
		try {
			String customSectionNameXpath = "//*[contains(@class,'questions-section') and contains(.,'"
					+ customSectionName.trim() + "')]";

			WebElementFacade cSectionName = find(By
					.xpath(customSectionNameXpath));
			UIHelper.mouseOveranElement(getDriver(), cSectionName);
			UIHelper.highlightElement(getDriver(), cSectionName);

			return true;
		} catch (Exception e) {

			return false;

		}
	}

}