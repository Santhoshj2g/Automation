package com.dnb.automation.MAUI.pages;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebDriver;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;


public class ResultPage extends PageObject{

	@FindBy(xpath=".//*[@id='bodycolumn']/table/tbody/tr[2]/td[2]/p/table/tbody/tr/td")
	private WebElementFacade resultTable;

	@FindBy(xpath=".//td/font[contains(text(),'ASMT_DT')]/parent::td/following-sibling::td[2]/font/b")
	private List<WebElementFacade> assDate;

	@FindBy(xpath=".//td/font[contains(text(),'ALGM_ID')]/parent::td/following-sibling::td[2]/font/b")
	private List<WebElementFacade> algId;

	@FindBy(xpath=".//td/font[contains(text(),'FAIL_SCR')]/parent::td/following-sibling::td[2]/font/b")
	private WebElementFacade failscr;

	@FindBy(xpath=".//td/font[contains(text(),'FAIL_SCR_NATL_PCTG')]/parent::td/following-sibling::td[2]/font/b")
	private WebElementFacade failpercent;

	@FindBy(xpath=".//td/font[contains(text(),'DNB_RATG')]/parent::td/following-sibling::td[2]/font/b")
	private WebElementFacade dnbrat;

	@FindBy(xpath=".//td/font[contains(text(),'DEFU_INDN')]/parent::td/following-sibling::td[2]/font/b")
	private WebElementFacade definci;

	@FindBy(xpath=".//td/font[contains(text(),'SCR_CLAS')]/parent::td/following-sibling::td[2]/font/b")
	private WebElementFacade scrclass;

	@FindBy(xpath=".//td/font[contains(text(),'SER_RAT')]/parent::td/following-sibling::td[2]/font/b")
	private WebElementFacade serrat;

	@FindBy(xpath=".//td/font[contains(text(),'MAX_CR')]/parent::td/following-sibling::td[2]/font/b")
	private WebElementFacade maxCred;

	@FindBy(xpath=".//td/font[contains(text(),'FAIL_SCR_CMTY')]/parent::td/following-sibling::td[2]/font/b")
	private List<WebElementFacade> commentrylist;

	public String verifyAssDate(String toolkitresponse)
	{
		String expected="";
		if(!assDate.isEmpty()) {
			for (WebElementFacade abc : assDate) {
				if (toolkitresponse.equalsIgnoreCase(abc.getText().toString())) {
					expected = abc.getText().toString().toLowerCase();
					UIHelper.highlightElement(getDriver(), abc);
					break;
				}
			}
		}
		return expected;
	}

	public String verifyAlgorithm(String toolkitresponse) {
		String expected="";

		if(!algId.isEmpty()){
			for(WebElementFacade abc : algId){
				if(toolkitresponse.equalsIgnoreCase(abc.getText().toString())){
					expected = abc.getText().toString().toLowerCase();
					UIHelper.highlightElement(getDriver(), abc);
					break;
				}
			}
		}

		return expected;
	}

	public String verifyFailScr()
	{
		String expected="";

		if(resultTable.isPresent()){
			if(failscr.isPresent()){
				UIHelper.highlightElement(getDriver(), failscr);
				expected= failscr.getText();
			}
		}
		return expected;
	}

	public String verifyFailPercent()
	{
		String expected="";

		if(resultTable.isPresent()){
			if(failpercent.isPresent()){
				UIHelper.highlightElement(getDriver(), failpercent);
				expected= failpercent.getText();
			}
		}
		return expected;
	}

	public String verifyDnbRat() {
		String expected="";

		if(resultTable.isPresent()){
			if(dnbrat.isPresent()){
				UIHelper.highlightElement(getDriver(), dnbrat);
				expected= dnbrat.getText().toLowerCase();
			}
		}
		return expected;
	}

	public String verifyDefIncidence() {
		String expected="";

		if(resultTable.isPresent()){
			if(definci.isPresent()){
				UIHelper.highlightElement(getDriver(), definci);
				expected= definci.getText();
			}
		}
		return expected;
	}

	public String verifyScrClass() {
		String expected="";

		if(resultTable.isPresent()){
			if(scrclass.isPresent()){
				UIHelper.highlightElement(getDriver(), scrclass);
				expected= scrclass.getText();
			}
		}
		return expected;
	}

	public String verifySERRat(){
		String expected="";

		if(resultTable.isPresent()){
			if(serrat.isPresent()){
				UIHelper.highlightElement(getDriver(), serrat);
				expected= serrat.getText();
			}
		}
		return expected;
	}

	public void closeWindow()
	{
		closeWindow(getDriver());

	}

	private void closeWindow(WebDriver driver) {
		driver.quit();
		// driver.switchTo().window(driver.getWindowHandle());
		 /*String homeWindow = driver.getWindowHandle();
	     Set<String> allWindows = driver.getWindowHandles();
	     Iterator<String> windowIterator =  allWindows.iterator();
	     while(windowIterator.hasNext()){
	    	 String childWindow = windowIterator.next();
	    	 if (homeWindow.equals(childWindow)){
	                driver.switchTo().window(childWindow);
	                driver.close();
	    	 }
	}*/
	}

	public String verifyMaxCredit()
	{
		String expected="";

		if(resultTable.isPresent()){
			if(maxCred.isPresent()){
				UIHelper.highlightElement(getDriver(), maxCred);
				expected= maxCred.getText();
			}
		}
		return expected;
	}

	public String[] verifyCommentry()
	{
		String expected[]=null;

		if(resultTable.isPresent()){
			for(int i=0;i<= commentrylist.size();i++){
				UIHelper.highlightElement(getDriver(), commentrylist.get(i));
				expected[i] =commentrylist.get(i).getText();
			}
		}

		return expected;
	}
}
