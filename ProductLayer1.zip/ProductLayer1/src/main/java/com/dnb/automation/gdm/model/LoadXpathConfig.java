package com.dnb.automation.gdm.model;


import org.bouncycastle.jcajce.provider.asymmetric.ec.KeyFactorySpi;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;
import java.util.Scanner;

public class LoadXpathConfig {
    @SuppressWarnings("resource")
    public ArrayList<ArrayList<String>> getDelimitedFile() throws Exception {
        ArrayList<ArrayList<String>> resultArray = new ArrayList<>();
        try {
            Scanner scan = new Scanner(new File("D:\\c drive\\418415\\Test\\ProductLayer1\\src\\test\\resources\\AppTestData\\GDM\\XpathConfig.csv"));
            while (scan.hasNextLine()) {
                resultArray.add(new ArrayList<String>(Arrays.asList(scan.nextLine().split(";"))));

            }
            scan.close();
        } catch (Exception e) {

        }
        return resultArray;
    }

    public ArrayList<ArrayList<String>> getriskBandFile() throws Exception {
        ArrayList<ArrayList<String>> resultArray = new ArrayList<>();
        try {
            Scanner scan = new Scanner(new File("D:\\c drive\\418415\\Test\\RiskBandConfig.csv"));
            while (scan.hasNextLine()) {
                resultArray.add(new ArrayList<String>(Arrays.asList(scan.nextLine().split(","))));

            }
            scan.close();
        } catch (Exception e) {

        }
        return resultArray;
    }


    public Properties LoadRiskBandProperties() {
        Properties riskBandProperties = new Properties();
        InputStream is = null;

        // First try loading from the current directory
        try {
            File f = new File("D:\\c drive\\418415\\Test\\ProductLayer1\\src\\test\\resources\\AppTestData\\GDM\\RiskBandProperties.properties");
            is = new FileInputStream(f);
        } catch (Exception e) {
            e.printStackTrace();
            is = null;
        }

        try {
            if (is == null) {
                // Try loading from classpath
                is = getClass().getResourceAsStream("D:\\c drive\\418415\\Test\\ProductLayer1\\src\\test\\resources\\AppTestData\\GDM\\RiskBandProperties.properties");
//		            ClassLoader classLoader = getClass().getClassLoader();
//		            File configurationFile = new File(classLoader.getResource(CONFIGURATION_FILE_NAME).getFile());
            }

            // Try loading properties from the file (if found)
            riskBandProperties.load(is);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return riskBandProperties;
    }

}



