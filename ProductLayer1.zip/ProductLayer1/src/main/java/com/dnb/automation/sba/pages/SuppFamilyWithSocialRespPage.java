package com.dnb.automation.sba.pages;

import java.util.Map;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.sba.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class SuppFamilyWithSocialRespPage extends PageObject{

	/*Supplier Family WebElements*/
	int totalDuns;

	@FindBy(xpath = "//*[@id='supplierFamily']/a")
	private WebElementFacade supplierFamily;

	@FindBy(xpath ="//*[@id='ui-id-7']")
	private WebElementFacade analysisSubTab;

	@FindBy(xpath ="//*[@id='analysisFilter-button']/span[1]")
	private WebElementFacade filter;

	@FindBy(xpath ="//*[@id='analysisFilter-menu']/li[7]/a")
	private WebElementFacade SocialResp;

	@FindBy(xpath ="//*[@id='SfAnalysisTotalCount']")
	private WebElementFacade totalRecords;

	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[2]")
	private WebElementFacade dunsNumber;

	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[3]")
	private WebElementFacade spend;

	@FindBy(xpath ="//*[@id='supplierAnalysis-ManageBtn']")
	private WebElementFacade manageCols;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[1]/span/a")
	private WebElementFacade cmpnyProfile_DS;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[2]/span/a")
	private WebElementFacade corpLinkage_DS;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[6]/span/a")
	private WebElementFacade socialResp_DS;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[7]/span/a")
	private WebElementFacade spend_DS;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[5]/span/a")
	private WebElementFacade risk_DS;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[3]/span/a")
	private WebElementFacade diversity_AF;

	@FindBy(xpath ="//*[@id='manageColumn-addbtnAnalysis']")
	private WebElementFacade manageColAddBtn;

	@FindBy(xpath ="//*[@id='manageColumn-applyBtn']")
	private WebElementFacade applyBtn;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[4]/ul/li[1]/span/a")
	private WebElementFacade forestryServices;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[4]/ul/li[2]/span/a")
	private WebElementFacade timberTracts;

	@FindBy(xpath ="//span/a[contains(text(),'Green')]")
	private WebElementFacade parentItem;

	@FindBy(xpath ="//*[@id='100']")
	private WebElementFacade itemsPerPage;

	@FindBy(xpath ="//*[@id='dynaPagHolder']/div[1]/div/a[2]")
	private WebElementFacade nextPage;

	@FindBy(xpath ="//*[@id='block_jump_valSF']")
	private WebElementFacade pageNum;
	
	@FindBy(xpath ="//*[@id='supplierAnalysis-DownloadListBtn']")
	private WebElementFacade export;

	@FindBy(xpath ="//*[@id='gridExcel']")
	private WebElementFacade exportToExcel;

	/*SocialResp WebElements*/
	int totalDunsOfSocialResp;

	@FindBy(xpath ="//*[@id='socialResp']/a")
	private WebElementFacade SocialRespTab;

	@FindBy(xpath ="//*[@id='ui-id-7']")
	private WebElementFacade analysisTabOfSocialResp;

	@FindBy(xpath ="//*[@id='analysisFilter-button']/span[2]")
	private WebElementFacade filterOfBU;

	@FindBy(xpath ="//*[@id='searchInpDIV']")
	private WebElementFacade SocialRespCategory;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[4]/span/a")
	private WebElementFacade agriculturalProductionCropsOfBU;

	@FindBy(xpath ="//*[@id='SrAnalysisTotalCount']")
	private WebElementFacade totalRecordsOfSocialResp;

	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[2]")
	private WebElementFacade dunsOfSocialResp;

	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[3]")
	private WebElementFacade spendOfSocialResp;

	@FindBy(xpath ="//*[@id='manageColumn-addBtn']")
	private WebElementFacade manageColAddBtnSocialResp;

	@FindBy(xpath ="//*[@id='highcharts-8']/*[name()='svg']/*[name()='g'][2]/*[name()='g'][1]/*[name()='text']/*[name()='tspan']")
	private WebElementFacade parentItemInSocialResp;

	@FindBy(xpath ="//*[@id='highcharts-20']/*[name()='svg']/*[name()='g'][2]/*[name()='g']/*[name()='text']/*[name()='tspan']")
	private WebElementFacade childItemInSocialResp;

	@FindBy(xpath ="//*[@id='dynaPagHolder']/div[1]/div/a[2]")
	private WebElementFacade nextPageOfSocialResp;

	@FindBy(xpath ="//*[@id='100']")
	private WebElementFacade itemsPerPageSocialResp;

	@FindBy(xpath ="//*[@id='block_jump_valSF']")
	private WebElementFacade pageNumSocialResp;
	
	@FindBy(xpath ="//*[@id='block_jumpSF']")
	private WebElementFacade goButtonOfSocialResp;

	public void chooseSocialResp(){
		filter.waitUntilPresent();
		UIHelper.clickAnElement(filter);
		SocialResp.waitUntilPresent();
		UIHelper.clickAnElement(SocialResp);
	}

	public void clickOnParentItem(){
		UIHelper.switchToTab(getDriver(),"supplierFamily");
		UIHelper.clickAnElement(parentItem);
	}

	public int getTotalRecords(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDuns=UIHelper.getTotalRecords(totalRecords);
		System.out.println("getTotalRecords :"+totalDuns);
		return UIHelper.getTotalRecords(totalRecords);
	}

	public Map<String,String> getSpendValue(){
		UIHelper.switchToTab(getDriver(),"supplierFamily");
		String preXpath="//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.clickAnElement(itemsPerPage);
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDuns, nextPage);
	}

	public Map<String,String> getSpendAfterAddcols(){
		String preXpath="//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDuns, nextPage);
	}

	/*SocialResp page*/

	public void clickOnSocialResp(){
		String URL=getDriver().getCurrentUrl();
		UIHelper.openInNewTab(getDriver(),URL);
		UIHelper.clickAnElement(SocialRespTab);
	}

	public void clickOnAnalysisTabOfSocialResp(){
		UIHelper.clickAnElement(analysisTabOfSocialResp);
	}

	public void clickOnParentItemInSocialResp(){
		UIHelper.switchToTab(getDriver(),"notSF");
		UIHelper.clickAnElement(parentItemInSocialResp);
	}

	public int getTotalRecordsInSocialResp(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDunsOfSocialResp=UIHelper.getTotalRecords(totalRecordsOfSocialResp);
		System.out.println("getTotalRecordsOfBU :"+totalDunsOfSocialResp);
		return UIHelper.getTotalRecords(totalRecordsOfSocialResp);
	}

	public Map<String,String> getSpendValueInSocialResp(){
		UIHelper.switchToTab(getDriver(),"notSF");
		String preXpath="//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.clickAnElement(itemsPerPageSocialResp);
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDunsOfSocialResp, nextPageOfSocialResp);
	}

	public void clickOnManageColsOfSocialResp(){
		UIHelper.switchToTab(getDriver(),"notSF");
		UIHelper.gotoFirstPage(pageNumSocialResp,goButtonOfSocialResp);
		UIHelper.clickAnElement(manageCols);
	}

	public void addColsAndClickApplyInSocialResp(){
		UIHelper.clickAnElement(cmpnyProfile_DS);
		UIHelper.clickAnElement(manageColAddBtnSocialResp);

		if(corpLinkage_DS.isPresent())
		{
			UIHelper.clickAnElement(corpLinkage_DS);
			UIHelper.clickAnElement(manageColAddBtnSocialResp);
		}
		if(socialResp_DS.isPresent())
		{
			UIHelper.clickAnElement(socialResp_DS);
			UIHelper.clickAnElement(manageColAddBtnSocialResp);
		}
		if(spend_DS.isPresent())
		{
			UIHelper.clickAnElement(spend_DS);
			UIHelper.clickAnElement(manageColAddBtnSocialResp);
		}
		if(risk_DS.isPresent())
		{
			UIHelper.clickAnElement(risk_DS);
			UIHelper.clickAnElement(manageColAddBtnSocialResp);
		}
		if(diversity_AF.isPresent())
		{
			UIHelper.clickAnElement(diversity_AF);
			UIHelper.clickAnElement(manageColAddBtnSocialResp);
		}
		UIHelper.clickAnElement(applyBtn);
	}

	public Map<String,String> getSpendAfterAddColsInSocialResp(){
		String preXpath="//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDunsOfSocialResp, nextPageOfSocialResp);
	}

	public void clickOnExportToExcelInSocialResp(){
		UIHelper.switchToTab(getDriver(), "notSF");
		UIHelper.mouseOveranElement(getDriver(),export);
	}

	public boolean isDataExportedInSocialResp(){
		return exportToExcel.isPresent();
	}
}
