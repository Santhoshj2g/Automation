package com.dnb.automation.gdm.pages;

import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.ui.Select;

/**
 * Created by 630239 on 6/16/2017.
 */
public class SearchPage extends PageObject{

    @FindBy(xpath=".//a[contains(text(),'Company Search')]")
    private WebElementFacade companySearch;

    @FindBy(xpath=".//nobr[contains(text(),'D-U-N-S')]/parent::a")
    private WebElementFacade dunsNumberOption;

    @FindBy(xpath=".//*[@id='lstReasons']")
    private WebElementFacade reasonDD;

    @FindBy(xpath = ".//input[@name='duns']")
    private WebElementFacade dunsTxt;

    @FindBy(xpath = ".//input[@value='Submit']")
    private WebElementFacade submitbtn;

    public void clickCompanySearch() {
        UIHelper.waitForPageToLoad(getDriver());
        if(companySearch.isPresent()){
            UIHelper.highlightElement(getDriver(),companySearch);
            companySearch.click();
        }
    }

    public void selectDunsNumberOption() {
        if(dunsNumberOption.isPresent()){
            UIHelper.highlightElement(getDriver(),dunsNumberOption);
            dunsNumberOption.click();
        }
    }

    public void enterDunsNum(String duns) {
        if(reasonDD.isPresent()){
            UIHelper.highlightElement(getDriver(),reasonDD);
            Select se = new Select(reasonDD);
            se.selectByIndex(1);
        }
        if (dunsTxt.isPresent()) {
            UIHelper.highlightElement(getDriver(), dunsTxt);
            dunsTxt.type(duns);
        }
    }

    public void submitforReport() {
        if(submitbtn.isPresent()){
            UIHelper.highlightElement(getDriver(),submitbtn);
            submitbtn.click();
        }
    }
}
