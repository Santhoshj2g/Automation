package com.dnb.automation.onboard.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

public class DunsSearch extends PageObject

{

    @FindBy(xpath = "//*[@id='onboard-body']/div[1]//*[@id='basicSearchPanel']//*[@id='searchBox']")
    private WebElementFacade searchBox;
  @FindBy(xpath = "//*[@id='countryList']")
    private WebElementFacade countryName;
    
    @FindBy(xpath = ".//*[@id='countryListBtn']")
    private WebElementFacade countryListBtnEle;

    private String countryItemXpath="//li[contains(.,'SERENITY')]/a";

    @FindBy(xpath = "//*[@id='onboard-body']/div[1]//*[@id='basicSearchPanel']//*[@id='companySearchBtn']")
    private WebElementFacade searchIcon;

    @FindBy(xpath = "//*[@id='resultDiv']")
    private WebElementFacade searchresultsframe;
@FindBy(xpath = "//*[@id='onboard-body']/header/div//*[@id='searchNavButton']")
	private WebElementFacade searchTab;
		
	@FindBy(id="confirmationMsgContainer")
	private WebElementFacade popupmsg;
	@FindBy(id="confirmationCancelBtn")
	private WebElementFacade donotsavebtn;
	
	@FindBy(id="emptyMessage")
	private WebElementFacade searchmsg;
	
	
	@FindBy(xpath="html/body/div[1]/div[3]/ul/li[1]")
	private WebElementFacade searcherror;

			
	private String searchpage="//*[@id='companySearchResultsLoading']/img";
	
	private String searchresultsframeStr = "//*[@id='resultDiv']";

    boolean iscountryList;
    boolean iscountryListDropDown;
    boolean issearchIcon;

    // User enters the DUNS number in text box named as Search

    public void searchBox(String DUNSNO, String country) throws Exception {
        try {
            if (searchBox.isPresent()) {
                searchBox.waitUntilPresent();
                UIHelper.highlightElement(getDriver(), searchBox);
                searchBox.type(DUNSNO);
                waitFor(4000).milliseconds();
                UIHelper.mouseOverandElementdoubleClick(getDriver(),
                        countryListBtnEle);
                String tempCountryItemXpath = countryItemXpath.replace(
                        "SERENITY", country);
                WebElementFacade countryItemEle = find(By
                        .xpath(tempCountryItemXpath));
                UIHelper.mouseOverandElementdoubleClick(getDriver(),
                        countryItemEle);
                waitFor(2000).milliseconds();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // User clicks the search button
    public void searchButton() throws Exception {
        try {
            issearchIcon = searchIcon.isPresent();
            searchIcon.waitUntilPresent();
            searchIcon.waitUntilVisible();
            UIHelper.highlightElement(getDriver(), searchIcon);
            searchIcon.click();
            UIHelper.waitForPageToLoad(getDriver());
            if (popupmsg.isPresent())
			{
				donotsavebtn.click();				
			}
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), searchpage);
			
        }

        catch (Exception e) {
            e.printStackTrace();
        }
    }

    // User verifies the DUNs details

    public boolean searchFrame() throws Exception {
        if (searchresultsframe.isPresent()) {
           // getDriver().switchTo().frame(searchresultsframeStr);
            return true;
        }

        else {
            return false;
        }
    }

    public boolean isIscountryList() {
        return iscountryList;
    }

    public boolean isIscountryListDropDown() {
        return iscountryListDropDown;
    }

    public boolean isIssearchIcon() {
        return issearchIcon;
    }
public void enterduns(String DUNSNO)throws Exception
	
	{
	try
	{
		if(searchBox.isPresent()==true)
		{
			searchBox.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), searchBox);
			System.out.println("Duns Number given" + DUNSNO);
			searchBox.type(DUNSNO);
		}
	}
	catch(Exception E)
	{
		E.printStackTrace();
	 }
	}

}
