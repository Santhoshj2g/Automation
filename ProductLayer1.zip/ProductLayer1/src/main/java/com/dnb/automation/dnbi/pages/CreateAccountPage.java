package com.dnb.automation.dnbi.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;
import com.google.common.base.Predicate;

/**********************************************************************************************
 * CreateAccountPage.java - This class contains method for create an Account
 * 
 * @author Duvvuru Naveen
 * @version 1.0
 ***********************************************************************************************/
public class CreateAccountPage extends PageObject {

    ArrayList<String> valsFromCIP = new ArrayList<String>();
    ArrayList<String> valuesinIframefoRAccFields = new ArrayList<String>();
    ArrayList<String> valuesinIframefoRAccFieldsTemp = new ArrayList<String>();

    // Account Information - Start

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='ecf_toc1']//*[contains(text(),'Information')]")
    private WebElementFacade accInformationHREF;

    @FindBy(xpath = "//*[@class='outerDiv']")
    private WebElementFacade mainDOMEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='ecf_toc1']//*[contains(text(),'Company Sum')]")
    private WebElementFacade compSummaryHREF;
    
    // accInformationwidgetContWidgetFull

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='widget_container']//*[contains(@class,'widget_full')]")
    private List<WebElementFacade> accInformationwidgetContWidgetFull;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='widget_container']//*[contains(@class,'widget_full')]//*[@class='frmSecEdit']//*[@id='Business'and@type='button']")
    private WebElementFacade accInformationCompanyEdit;

    @FindBy(xpath = "//*[contains(@class,'modal')]//*[contains(@class,'modal_inner_content')]//*[@class='frmSecEdit']//input")
    private List<WebElementFacade> accFieldstoEditinIFrame;

    @FindBy(xpath = "//*[contains(@class,'modal')]//*[contains(@class,'modal_button')]//*[contains(@class,'btnPrimary ') and @value='Submit']")
    private WebElementFacade accFieldsinIFrameSubmit;

    @FindBy(xpath = "//*[contains(@class,'modal')]//*[contains(@class,'modal_button')]//*[@value='Cancel']")
    private WebElementFacade accFieldsinIFrameCancel;

    @FindBy(xpath = ".//*[@class='outerDiv']//*[@id='backRight']//*[contains(@value,'ext')]")
    private WebElementFacade nextBtnCreateAccPage;

    @FindBy(xpath = ".//*[@class='outerDiv']//*[contains(@class,'frmField')]//*[contains(@id,'Field')]//ancestor::tr//*[contains(text(),'Automation')]//ancestor::tr//*[contains(@name,'UDF')]")
    private List<WebElementFacade> createAccpageFieldsToEnter;

    @FindBy(xpath = "//*[@class='outerDiv']//*[not(contains(@id,'UDF')) and @type='text']")
    private List<WebElementFacade> createAccpageFieldsnonUDFFDFToEnter;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'frmField')]//*[contains(@id,*)]//ancestor::tr//*[contains(text(),*)]")
    private List<WebElementFacade> createAccpageAllInputFields;

    @FindBy(xpath = "//*[@id='Acct-AccountNumber']")
    private WebElementFacade createAccpageAllInputFieldAcntNumber;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'frmField')]//*[contains(@id,'BizInfo') and contains(@name,'BusinessName')]")
    private WebElementFacade createAccpageAllInputFieldBizName;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'frmField')]//*[contains(@id,'AccountNumber') and contains(@name,'AccountNumber')]")
    private WebElementFacade createAccpageAllInputFieldAccNumber;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'frmField')]//*[contains(@id,'BizInfo') and contains(@name,'State')]")
    private WebElement createAccpageAllInputFieldBizState;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'frmField')]//*[contains(@id,'BizInfo') and contains(@name,'State')]")
    private WebElementFacade createAccpageAllInputFieldBizStateEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'frmField')]//*[contains(@id,'Country') and contains(@name,'Country')]")
    private WebElementFacade createAccpageAllInputFieldBizCtry;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='breadcrumb']//li[3]")
    private WebElementFacade createAccpageBrdCrumb;

    @FindBy(xpath = ".//*[@class='outerDiv']//*[contains(@class,'frmField')]//*[contains(@id,'Field')]//ancestor::tr//*[contains(text(),'Auto')]")
    private List<WebElementFacade> createAccPageAutomationFields;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='actionButtons']//input[@type='button' and  @value='Create Account']")
    private WebElementFacade createAccountfromECF;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='actionButtons']//input[@type='button' and  contains(@value,'Create App')]")
    private WebElementFacade createAppfromECF;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='actionButtons']//input[@type='button' and  contains(@value,'Order Investi')]")
    private WebElementFacade orderInvestigationfromECF;

    @FindBy(xpath = ".//*[@class='outerDiv']//*[contains(@class,'frmField')]//*[contains(@id,'Field')]//ancestor::tr//*[contains(text(),'UDF001')]//ancestor::tr//*[contains(@name,'UDF')]")
    private WebElementFacade createAccpageFieldsToEnterUDF1;

    @FindBy(xpath = ".//*[@class='outerDiv']//*[contains(@class,'frmField')]//*[contains(@id,'Field')]//ancestor::tr//*[contains(text(),'UDF002')]//ancestor::tr//*[contains(@name,'UDF')]")
    private WebElementFacade createAccpageFieldsToEnterUDF2;

    @FindBy(xpath = ".//*[@class='outerDiv']//*[contains(@class,'frmField')]//*[contains(@id,'Field')]//ancestor::tr//*[contains(text(),'UDF003')]//ancestor::tr//*[contains(@name,'UDF')]")
    private WebElementFacade createAccpageFieldsToEnterUDF3;

    @FindBy(xpath = ".//*[@class='outerDiv']//*[contains(@class,'frmField')]//*[contains(@id,'Field')]//ancestor::tr//*[contains(text(),'UDF0004')]//ancestor::tr//*[contains(@name,'UDF')]")
    private WebElementFacade createAccpageFieldsToEnterUDF4;

    @FindBy(xpath = ".//*[@class='outerDiv']//*[contains(@class,'frmField')]//*[contains(@id,'Field')]//ancestor::tr//*[contains(text(),'UDF005')]//ancestor::tr//*[contains(@name,'UDF')]")
    private WebElementFacade createAccpageFieldsToEnterUDF5;

    @FindBy(xpath = "//*[@class='outerDiv']//*//select[contains(@id,'UDF')]")
    private WebElementFacade createAccpageFieldsToEnterUDF5Select;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='ecf_page']//*[@class='widget wideWidget']//*[@class='reviewStatus']//*[contains(@value,'Reevaluate')]")
    private WebElementFacade reEvaluateCreditBtn;

    @FindBy(xpath = "//*[@class='iframe_modal']//*[@id='reevaluate_modal']//*[@class='results full']//tbody//tr//td//input[@type='radio'][1]")
    private WebElementFacade reEvaluatePopupRadioBtn;

    @FindBy(xpath = "//*[@class='iframe_modal']//*[@class='modal_buttons']//*[@value='Continue']")
    private WebElementFacade continueBtn;

    @FindBy(xpath = "//*[@class='iframe_modal']//*[@class='modal_buttons']//*[@value='Continue']")
    private WebElementFacade continueBtn1;

    @FindBy(xpath = ".//*[@class='outerDiv']//*[@class='alert_box']")
    private WebElementFacade createAccPageAlertBox;

    // Review Details;
    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='widget_container']//*[@class='review_details']")
    private WebElementFacade ecfPageReviewDetailsFull;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='widget_container']//*[@class='review_details']/span[1]")
    private WebElementFacade ecfPageReviewDetailsSpan1;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='widget_container']//*[@class='review_details']/span[2]")
    private WebElementFacade ecfPageReviewDetailsSpan2;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='widget_container']//*[@class='results tab_border']//tr//td")
    private WebElementFacade ecfPageReviewDetailsTableDetailsCreditTerms;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='widget_container']//*[@class='review_details']//*[@id='viewAccountAction']")
    private WebElementFacade ecfPageReviewViewCreditTerms;

    // viewDetails
    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='widget_container']//*[@class='review_details']//*[@id='viewDetails']")
    private WebElementFacade ecfPageReviewViewReasons;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='widget_container']//*[@id='reviewOutcome']//*[@id='credit_hold_details']/p")
    private WebElementFacade ecfPageReviewViewCreditHoldDetails;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'widget')]//*[@type='radio' and @value='N']")
    private WebElementFacade intPageProceedWithoutOrderingReport;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'btn') and @value='Next']")
    private WebElementFacade intPageProceedWithoutOrderingReportNxt;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='widget_container']//*[@class='alert_box']")
    private WebElementFacade ecfAlertBox;

    // viewDetails
    // Fields in Create Acc Page
    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='ecf_toc1']//*[contains(text(),'Audit Tra')]")
    private WebElementFacade auditTrailEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='widget_container']//*[@class='widget_full']")
    private WebElementFacade auditTrailWidgetFullEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='widget_container']//*[@class='widget_full']//*[contains(@id,'aud_tab1')]")
    private WebElementFacade auditTrailInternalTabEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='widget_container']//*[@class='widget_full']//*[contains(@id,'aud_tab1')]//*[contains(@class,'results')]")
    private WebElementFacade internalAuditTableResultsEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='ecf_header']//*[@id='entNumber']")
    private WebElementFacade entNumberEle;

    @FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//*[contains(@src,'dnbi')]")
    private WebElementFacade accFrameWindowEle;

    @FindBy(xpath = "//*[@class='iframe_modal']//form//*[contains(@class,'modal_inner')]//div//table//tbody")
    private WebElementFacade accFrameWindowInnerEle;
    
    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]")
    private WebElementFacade tabResultsEle;
    
    private String tabresult="//*[@class='outerDiv']//*[contains(@class,'results')]//thead";

    private String brdCrumbData;

    public static String getAccnumber;

    public ArrayList<String> getFinalListOFUDFs = new ArrayList<String>();
    public ArrayList<String> getFinalListOFModifiedUDFs = new ArrayList<String>();

    // Account Manager
    @FindBy(xpath = "//*[@id='header_mainApp']//a[text()='Account Manager']")
    private WebElementFacade accManagerHref;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@value,'Create Acc') and @type='button']")
    private WebElementFacade accManagerCreateAccBTN;

    String textToEnterModifiedListData = null;

    // ECF Page Tab Links
    @FindBy(xpath = "//*[@id='ecf_toc1']//a[contains(.,'D&B Report')]")
    private WebElementFacade dandbReportLink;

    @FindBy(xpath = "//*[@class='outerDiv']//table[@class='results full']//tbody//tr//a[contains(@href,'javascript:createAccount')]")
    private WebElementFacade createAccount;

    @FindBy(xpath = "//*[contains(@id,'UDF-Field') and contains(text(),.)]//ancestor::tr//input")
    private List<WebElementFacade> getObjsEle;

    @FindBy(xpath = ".//*[@id='widget_container']/div")
    private WebElementFacade widgetContScoreBarDivasStringEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='widget_container']")
    private WebElementFacade widgetEle;

    @FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//*[@class='review_buttons']")
    private WebElementFacade reviewBoxButtonsEleInPane;

    @FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//*[contains(@src,'dnbi')]")
    private WebElementFacade popupEle;

    @FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//*[contains(@src,'dnbi')]")
    private WebElementFacade allFieldsToEnterModifiedDataEle;

    @FindBy(xpath = "//*[@id='page_title_links']/h2")
    private WebElementFacade pageTitleEle;

    private String widgetData = "//*[@class='outerDiv']//*[contains(@class,'frmSecEdit')]//*[contains(text(),'FIFAAutomationTOOL')]//ancestor::tr//*[contains(@class,'frmView')]";

    private String contentAreaXpath = ".//*[@id='contentarea']/div";

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='backRight']//*[contains(@value,'Nex')]")
    private WebElementFacade nextButtonCreatAccFromAccMGRTab;
    
    

 // added code for the accountinformtion Tab------siva--------------
  

     @FindBy(xpath = "//div[@id='widget_container']/div[1]/div[@class='widget_ecfbox']/h3")
     private WebElementFacade AccountInformationPage;
     
     @FindBy(xpath = "//div[@id='widget_container']/div[1]/div[3]/input[@value='Add Trade and Bank Reference']")
     private WebElementFacade AddTradeandBankReference;
     
     @FindBy(xpath ="//a[contains(text(),'Account Manager')]")
     private WebElementFacade AccountmanagerTab;
     
     @FindBy(xpath ="//table[@class='results full_company']/tbody/tr[1]//a")
     private WebElementFacade FirstRowDatalink;
     
     @FindBy(xpath ="//div[@id='ecf_toc_main']//ul[@id='ecf_toc1']//li//a[contains(text(),'Account Information')]")
     private WebElementFacade AccountInformationTab;
      
     @FindBy(xpath ="//div[@id='ecf_toc_main']//ul[@class='ecf_toc']/li[6]/a")
     private WebElementFacade PredectiveScoreTab;
     
     @FindBy(xpath ="//div[@id='widget_container']/div[4]/table/tbody/tr[3]/td[2]/p/span[contains(text(),'Portfolio Comparison')]")
     private WebElementFacade Portfoliocomparison;
   //td[@class='rating_title']/p[@ class='rating_desc']/span[contains(text(),'Portfolio Comparison')]
     @FindBy(xpath ="//div[@id='widget_container']/div[4]/table/tbody/tr[3]/td[2]//preceding-sibling::td[1]/img")
     private WebElementFacade PortfoliocomparisonImg;
     
     @FindBy(xpath ="//a[contains(text(),'Financials')]")
     private WebElementFacade finacialstatementTab;
     
     @FindBy(xpath ="//div[@id='widget_container']/div[1]/div[1]/h3")  
     private WebElementFacade predectivescorepage;
   
     @FindBy(xpath ="//*[@class='results tab_border']//*[contains(text(),'Number of Employees Total:')]")
     private WebElementFacade predectiveEmployee;
   
     @FindBy(xpath ="//*[@class='results tab_border']//*[contains(text(),'Number of Employees Total:')]//following-sibling::td")
     private WebElementFacade predectiveEmployeeTotal;
     
     
     @FindBy(xpath ="//ul[@class='pi_notes_li']/li[3]/strong")
     private WebElementFacade financialStressscorevalue;
     
     @FindBy(xpath ="//select[@id='dataSourceType']")
     private WebElementFacade  selectOption;
     
     @FindBy(xpath ="//table/tbody/tr/td[contains(text(),'Total Assets')]//following-sibling::td")
     private WebElementFacade totalAssets;
     
     @FindBy(xpath ="//div[@id='widget_container']/div[@class='widget_full']/ul[@class='pi_notes_li']/li[4]/strong")
     private WebElementFacade commercialCreditScore;
     
     @FindBy(xpath ="//table[@class='viability_rating']/tbody/tr[1]/td[@class='rating_score']/img")
     private WebElementFacade viabilityrating;
     
     @FindBy(xpath ="//div[@id='widget_container']/div/span[1]")
     private WebElementFacade imageLoading;
     
     @FindBy(xpath ="//div[@class='ui-widget']//input[@id='quickSearchFld']")
     private WebElementFacade searchField;
     
     @FindBy(xpath ="//input[@id='BizRefs-ReferenceBusinessName']")
     private WebElementFacade bankReferenceName;
     
     @FindBy(xpath ="//div[@class='modal_button floatRight']/input[@value='Submit']")
     private WebElementFacade bankReferenceSubmit;
     
     @FindBy(xpath ="//div[@id='widget_container']/div[1]/div[3]/input[@value='Add Guarantor']")
     private WebElementFacade gurantor;
     @FindBy(xpath ="//input[@id='Guarantor-Name-First']")
     private WebElementFacade gurantorInputText;
     @FindBy(xpath ="//div[@class='modal_button floatRight']/input[@value='Submit']")
     private WebElementFacade gurantorSubmit;
     
     @FindBy(xpath ="//*[@id='widget_container']//*[contains(@class,'reviewStatus')]//*[contains(@class,'review_details')]//span")
     private WebElementFacade reviewStatus;
     
     private String ruletriggered ="//*[@id='widget_container']//*[contains(@class,'reviewStatus')]//*[contains(@id,'reviewOutcome')]//p//b[contains(.,'dnbi')]";
     private String CSSectionHearder="//*[@id='compTitle']//*[contains(.,'Company Summary')]";
     
     private String liveReportPage="//*[@class='ecf_header']"; 
     private WebElement ruleTriggered1;
     
     @FindBy(xpath ="//*[@id='widget_container']//h3[contains(.,'Bank/Trade References')]") 
     private WebElementFacade bankRference;
     
     @FindBy(xpath ="//*[@id='widget_container']//h3[contains(.,'Guarantor')]") 
     private WebElementFacade gurantorsectionheader;
     
     private String rstatus;
     private String rtriggered;
     
     private String gurantorxpath="//div[@id='widget_container']/div[1]/div[3]/input[@value='Add Guarantor']";
     private String accInforamtionheader="//div[@id='widget_container']/div[1]/div[3]/input[@value='Add Trade and Bank Reference']//ancestor::div[1]//preceding-sibling::div[2]//h3[contains(.,'Account Information')]";
     
     private String gurantorheader="//*[@id='widget_container']//h3[contains(.,'Guarantor')]";
     
     private String tradeReferencesheader="//*[@id='widget_container']//h3[contains(.,'Bank/Trade References')]";
     
     String accHeaderXpath="//*[@id='main']//*[@id='page_title_links']//h2";
     
     
     public static  int j = 23;
     public static String calcFieldValue;
     public static String userFieldValue;
     public String resultAfterEvalution;
     public static int count=0;
     public static int count2=0;
     public static int divValue=12;
     public static int guarantorDiv=23;
 //---------------------------------code ended here------------------   
    

    // Click the Create Account Link in Search Results
    public void clickCreateAccLinkInSearchResultsTable() {
    	UIHelper.waitForPageToLoad(getDriver());
        if (createAccount.isPresent()) {
            createAccount.click();
        }

        mainDOMEle.waitUntilPresent();

    }

    // Verify Data in Audit Trail Section
    public void verifyDatainAuditTrial(String companyName) {

    	UIHelper.waitForPageToLoad(getDriver());       	
            ArrayList<String> getAuditData = new ArrayList<String>();
            boolean getAuditDataValidator = true;
            getAuditData.add("Re Evaluate");
            getAuditData.add("Recommended Action Triggered");
            getAuditData.add("D&B Report Found");
            getAuditData.add("D&B Report Searched");
            getAuditData.add("Account Created");

            if (auditTrailEle.isPresent()) {

                auditTrailEle.click();

            }

            auditTrailWidgetFullEle.waitUntilPresent();
            auditTrailInternalTabEle.waitUntilPresent();

            try {

                for (String getAuditDataList : getAuditData) {

                    if (!(StringUtils.containsIgnoreCase(
                            internalAuditTableResultsEle.getText(),
                            getAuditDataList))) {

                        getAuditDataValidator = false;
                        break;

                    }

                }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Click Create Account Button in ECF Page
    public void clickCreateAccBtnInECFPage() {

        try {
        	createAccountfromECF.waitUntilPresent();
           /* brdCrumbData = createAccpageBrdCrumb
                    .getText()
                    .substring(createAccpageBrdCrumb.getText().lastIndexOf(":"))
                    .toString().trim();*/
        	createAccountfromECF.click();
        	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), accHeaderXpath);
        } catch (Exception E) {
        	 E.printStackTrace();
        }

    }

    // Check Account is created or not in ECF Page
    public String checkIfAccntisCreated() {
    	UIHelper.waitForPageToLoad(getDriver());
        if (entNumberEle.isPresent()) {

            return entNumberEle.getText().toString().trim();
        }
        return null;

    }

    public void returnGeneratedAccNumber() {
    	UIHelper.waitForPageToLoad(getDriver());
        if (createAccpageAllInputFieldAccNumber.isPresent()) {

            getAccnumber = createAccpageAllInputFieldAccNumber
                    .getAttribute("value").toString().trim();

        }

    }

    int AccIterator = 0;

    public void createAccountFromAccManagerTab() throws Exception {

        try {
        	UIHelper.waitForPageToLoad(getDriver());
            if (accManagerHref.isPresent()) {
                accManagerHref.click();
            }

            mainDOMEle.waitUntilPresent();
            accManagerCreateAccBTN.waitUntilPresent();

            if (accManagerCreateAccBTN.isPresent()) {
                accManagerCreateAccBTN.click();
                UIHelper.waitForPageToLoad(getDriver());
            }

        } catch (Exception e) {
        	e.printStackTrace();
        }

    }

    public void fillCreateAccPageWithData(ArrayList<String> udfValues,
            ArrayList<String> textToEnter, String compName,
            String createAcntOption, String getCurrentState,
            String countryToSeLect, String createFromAppOptVal)
            throws Exception {

        try {
            waitFor(5000).milliseconds();
            returnGeneratedAccNumber();

            if (createFromAppOptVal.contains("App")) {
                Random rn = new Random();
                int randomNum = rn.nextInt(1000);

                createAccpageAllInputFieldAcntNumber.type(getAccnumber
                        + randomNum);

                returnGeneratedAccNumber();
            }

            if (createAcntOption.equalsIgnoreCase("ACCMGR") ||createFromAppOptVal.contains("App")) {
                if (createAccpageAllInputFieldBizName.isPresent()) {

                    createAccpageAllInputFieldBizName.type(compName);
                }
            }

            if (createAcntOption.equalsIgnoreCase("ACCMGR")) {

                if (createAccpageAllInputFieldBizCtry.isPresent()) {

                    List<WebElement> options = createAccpageAllInputFieldBizCtry
                            .findElements(By.tagName("option"));

                    Select variable = new Select(
                            createAccpageAllInputFieldBizCtry);

                    for (WebElement option : options) {
                        String optionTxt = option.getText();

                        if (optionTxt.equalsIgnoreCase(countryToSeLect)) {
                            variable.selectByVisibleText(countryToSeLect);

                            break;
                        }
                    }
                }
            }

            // Chk For createAccpageAllInputFieldBizState
            if (createAcntOption.equalsIgnoreCase("ACCMGR")) {

                if (!getCurrentState.isEmpty() && getCurrentState != null) {
                    if (createAccpageAllInputFieldBizStateEle.isPresent()) {

                        createAccpageAllInputFieldBizStateEle
                                .selectByVisibleText(getCurrentState.toString()
                                        .trim());
                    }
                }
            }

            String textToEnterListData = null;
            for (String getIDTitleFromLableData : udfValues) {

                for (String textToEnterList : textToEnter) {

                    textToEnterListData = textToEnterList;
                    getFinalListOFUDFs.add(getIDTitleFromLableData);

                    break;
                }

                if (!getIDTitleFromLableData.isEmpty()
                        && getIDTitleFromLableData != null) {
                	 waitFor(5000).milliseconds();
                    String allFieldsToEnter = ".//*[@class='outerDiv']//*[contains(@class,'frmField')]//*[contains(@id,'Field')]//ancestor::tr//*[contains(text(),'dnbi.')]//ancestor::tr//*[contains(@name,'UDF')]";

                    allFieldsToEnter = allFieldsToEnter.replace("dnbi.",
                            getIDTitleFromLableData.toString().trim());

                    WebElement allFieldsToEnterEle = getDriver().findElement(
                            By.xpath(allFieldsToEnter));

                    boolean cValFind;

                    if (textToEnterListData.equalsIgnoreCase("Yes")
                            | textToEnterListData.equalsIgnoreCase("No")
                            | textToEnterListData.equalsIgnoreCase("True")
                            | textToEnterListData.equalsIgnoreCase("False")) {

                        cValFind = true;

                    } else {
                        cValFind = false;
                    }

                    if (cValFind) {

                        UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
                                allFieldsToEnter);
                        Select clickThis = new Select(allFieldsToEnterEle);
                        clickThis.selectByVisibleText(textToEnterListData
                                .toString().trim());

                    } else {

                        allFieldsToEnterEle.click();
                        allFieldsToEnterEle.clear();
                        allFieldsToEnterEle.sendKeys(textToEnterListData
                                .toString().trim());
                    }

                    allFieldsToEnter = null;

                }

                textToEnter.remove(textToEnterListData);
                textToEnterListData = null;
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public void clickNextBtnInAccMgrPage() {
        try {
            if (nextBtnCreateAccPage.isPresent()) {

                nextBtnCreateAccPage.click();
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), liveReportPage);
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), CSSectionHearder);
              
            }
        } catch (Exception e) {

            
        }
    }
    public void clickNextBtnInAccMgrPage1() {
        try {
            if (nextBtnCreateAccPage.isPresent()) {

                nextBtnCreateAccPage.click();
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tabresult);
                
            }
        } catch (Exception e) {

            // e.printStackTrace();
        }
    }

    public void fillTheCreateAccountPageWithData(String searchType,
            String dunsNumber, String keysToTest, String getCurrentState,
            ArrayList<String> textToEnter, ArrayList<String> udfValues,
            String countryToSeLect, boolean sayTrueToReEvaluateCredit,
            String createAccountFrom, boolean addtoFolderandCreateSnapshot,
            String getFolderName, boolean boolGenSnap,
            ArrayList<String> modifiedUDFValuesToEnter) throws Exception {

        AccIterator++;

        try {

            SearchResultPage searchResultData = new SearchResultPage();

            try {

                if (!createAccountFrom.isEmpty() && createAccountFrom != null) {

                    if (createAccountFrom.toString().trim().contains("ECF")) {
                        searchResultData.pullLiveReportAndGotoECFPage();

                        // Add to Folder

                        if (addtoFolderandCreateSnapshot) {

                            new ECFPage()
                                    .addProducttoSpecificFolder(getFolderName);

                        }

                        if (boolGenSnap) {

                            // Add SnapShot

                            new ECFPage().saveaSnapshot();

                        }

                        clickCreateAccBtnInECFPage();

                    } else if (createAccountFrom.toString().trim()
                            .contains("Search")) {
                        searchResultData
                                .clickCreateAcntLinkAndgotoECFpage(dunsNumber);

                    } else {

                        searchResultData.pullLiveReportAndGotoECFPage();

                        clickCreateAccBtnInECFPage();
                    }
                }
            } catch (Exception E) {

                throw E;
            }

            try {

                fillCreateAccPageWithData(udfValues, textToEnter, keysToTest,
                        searchType, getCurrentState, countryToSeLect, "");

                clickNextBtnInAccMgrPage();

            } catch (Exception E) {
                throw E;

            }

            if (createAccountFrom.toString().trim().contains("Search")) {
                new ECFPage().addProducttoSpecificFolder(getFolderName);
            }

            // Chk for International Page

            validateInternationalOrderPage(keysToTest, true, udfValues,
                    modifiedUDFValuesToEnter);
        }

        catch (Exception E) {

            throw E;

        }

    }

    public void validateInternationalOrderPage(String keysToTest,
            boolean sayTrueToReEvaluateCredit, ArrayList<String> udfValues,
            ArrayList<String> modifiedUDFValuesToEnter) throws Exception {

        // Chk for International Page
        try {
            if (intPageProceedWithoutOrderingReport.isPresent()) {

                intPageProceedWithoutOrderingReport.click();

            }

            if (intPageProceedWithoutOrderingReportNxt.isPresent()) {

                intPageProceedWithoutOrderingReportNxt.click();

                widgetEle.waitUntilPresent();
            }

            // Chk For createAccpageAllInputFieldBizName
            // Re-Eval Before Edit
            if (sayTrueToReEvaluateCredit) {
                performReEvalCredit();
            }

            verifyDatainAuditTrial(keysToTest);

            if (accInformationHREF.isPresent()) {
                accInformationHREF.click();

                auditTrailWidgetFullEle.waitUntilPresent();
            }

            for (WebElementFacade accInformationwidgetContWidgetFullViews : accInformationwidgetContWidgetFull) {

                if (accInformationwidgetContWidgetFullViews.isPresent()) {

                    UIHelper.highlightElement(getDriver(),
                            accInformationwidgetContWidgetFullViews);
                }

            }

            // Click on Edit Button

            if (accInformationCompanyEdit.isPresent()) {

                accInformationCompanyEdit.click();

            }

            accFrameWindowEle.waitUntilPresent();

            getDriver().switchTo().frame(accFrameWindowEle);
            // Now Edit the Values and Compare Again

            editValuesInCompanySummarypopUPWidget(udfValues,
                    modifiedUDFValuesToEnter);

            // Re-Eval After Edit
            if (sayTrueToReEvaluateCredit) {
                performReEvalCredit();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void performReEvalCredit(){
    	UIHelper.waitForPageToLoad(getDriver());
                    compSummaryHREF.click();
                    UIHelper.waitForVisibilityOfEleByXpath(getDriver(), CSSectionHearder);
            if (reEvaluateCreditBtn.isPresent()) {

                reEvaluateCreditBtn.click();
                waitFor(2000).milliseconds();
                getDriver().switchTo().frame(popupEle);
                reEvaluatePopupRadioBtn.click();

                continueBtn.click();
                waitFor(3000).milliseconds();
                if(continueBtn1.isDisplayed()){
                	continueBtn1.click();
                	
                }
               // continueBtn1.waitUntilPresent();

                //continueBtn1.click();

                getDriver().switchTo().defaultContent();

                reviewBoxButtonsEleInPane.waitUntilPresent();
                }

        }

    public void getValuesInCompanySummarypopUPWidget(ArrayList<String> udfValues) {

        try {
            valuesinIframefoRAccFields.clear();

            for (String udfValuesList : udfValues) {

                String companyInfoAccPopUPXpath = "//*[contains(@id,'UDF-Field') and contains(text(),'FIFADNBI')]//ancestor::tr//input";

                companyInfoAccPopUPXpath = companyInfoAccPopUPXpath.replace(
                        "FIFADNBI", udfValuesList.toString().trim());

                WebElementFacade companyInfoAccntPopupEle = find(By
                        .xpath(companyInfoAccPopUPXpath));

                if (companyInfoAccntPopupEle.isPresent()) {

                    valuesinIframefoRAccFields.add(companyInfoAccntPopupEle
                            .getText());

                }

            }
        } catch (Exception e) {

            throw e;
        }

    }

    public void editValuesInCompanySummarypopUPWidget(
            ArrayList<String> udfValues,
            ArrayList<String> modifiedUDFValuesToEnter) {

 
                if (accFrameWindowInnerEle.isPresent()) {

                    UIHelper.highlightElement(getDriver(),
                            accFrameWindowInnerEle);
                }

            try {

                for (WebElementFacade getData : getObjsEle) {

                    if (getData.isPresent()) {

                        UIHelper.highlightElement(getDriver(), getData);
                    }

                }
            } catch (Exception e) {

            }

            for (String getIDTitleFromLableData : udfValues) {

                for (String textToEnterList : modifiedUDFValuesToEnter) {

                    textToEnterModifiedListData = textToEnterList;
                    getFinalListOFModifiedUDFs.add(getIDTitleFromLableData);

                    break;
                }

                if (!getIDTitleFromLableData.isEmpty()
                        && getIDTitleFromLableData != null) {

                    String allFieldsToEnterModifiedData = "//*[contains(@id,'UDF-Field') and contains(text(),'FIFADNBI')]//ancestor::tr//*[contains(@name,'UDF')]";

                    allFieldsToEnterModifiedData = allFieldsToEnterModifiedData
                            .replace("FIFADNBI", getIDTitleFromLableData
                                    .toString().trim());

                    WebElement allFieldsToEnterModifiedDataEle = getDriver()
                            .findElement(By.xpath(allFieldsToEnterModifiedData));

                    UIHelper.highlightElement(getDriver(),
                            allFieldsToEnterModifiedDataEle);

                    boolean cValFind;

                    if (textToEnterModifiedListData.equalsIgnoreCase("Yes")
                            | textToEnterModifiedListData
                                    .equalsIgnoreCase("No")
                            | textToEnterModifiedListData
                                    .equalsIgnoreCase("True")
                            | textToEnterModifiedListData
                                    .equalsIgnoreCase("False")) {

                        cValFind = true;

                    } else {
                        cValFind = false;
                    }

                    if (cValFind) {

                        UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
                                allFieldsToEnterModifiedData);
                        Select clickThis = new Select(
                                allFieldsToEnterModifiedDataEle);
                        clickThis
                                .selectByVisibleText(textToEnterModifiedListData
                                        .toString().trim());
                    } else {
                        allFieldsToEnterModifiedDataEle.click();
                        allFieldsToEnterModifiedDataEle.clear();
                        allFieldsToEnterModifiedDataEle
                                .sendKeys(textToEnterModifiedListData
                                        .toString().trim());

                    }

                    allFieldsToEnterModifiedData = null;

                }

                modifiedUDFValuesToEnter.remove(textToEnterModifiedListData);
                textToEnterModifiedListData = null;

            }

            if (accFieldsinIFrameSubmit.isPresent()) {
                accFieldsinIFrameSubmit.click();
            }

            getDriver().switchTo().defaultContent();


    }

    public void getValuesInAccInfoWidget() {

        try {

            valsFromCIP.clear();

            for (String udfValuesList : getFinalListOFUDFs) {

                String tempWidgetData = widgetData.replace(
                        "FIFAAutomationTOOL", udfValuesList);

                WebElementFacade widgetDataEle = find(By.xpath(tempWidgetData));

                if (widgetDataEle.isPresent()) {

                    valsFromCIP.add(widgetDataEle.getText().toString().trim());

                }

            }

        } catch (Exception E) {

            throw E;

        }

    }
  	public void clickOnFirstRowDatalink() {
  		FirstRowDatalink.waitUntilClickable();
  		FirstRowDatalink.click();
  		System.out.println("-----------------FirstRowDatalink.click();--------------");
  		UIHelper.waitForPageToLoad(getDriver());
  	}

  	public void clickOnAccountInformationTab() {
  		AccountInformationTab.waitUntilClickable();
  		AccountInformationTab.click();
  	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), accInforamtionheader);
  	//UIHelper.waitForPageToLoad(getDriver());
  		System.out.println("-----------------AccountInformationTab.click()--------------");
  		
  	}

  	public void isCalculativeFieldIsPresent(String field) {
  		System.out.println("-----------------isCalculativeFieldIsPresent()--------------");
  		UIHelper.waitForPageToLoad(getDriver());
  		//div[@class='frmSecEdit']//tr//td[contains(text(),'calculatorField1')]
  		String s1 = "//div[@class='frmSecEdit']//tr//td[contains(text(),'"+field+":"+"')]";
  		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),"//div[@class='frmSecEdit']//tr//td[contains(text(),'"+field+":"+"')]");
  		UIHelper.waitForPageToLoad(getDriver());
  	
  		String s2 = "//div[@class='frmSecEdit']//tr//td[contains(text(),'" +field+ "')]//following-sibling::td[1]";
  			
  		String calcfieldname=getDriver().findElement(By.xpath(s1)).getText().replace(":"," ");
  			System.out.println("the calculative field --------->"+calcfieldname);	
  			UIHelper.waitForPageToLoad(getDriver());
  		if(field.equalsIgnoreCase(calcfieldname.trim())){
  			calcFieldValue=getDriver().findElement(By.xpath(s2)).getText();
  			System.out.println("the ui value of custom field------->"+calcFieldValue);
  		}
  		
  	}

  	public void clickOnPredicteveScoreTab(String datatype)
  	{
  		System.out.println("---------------clickOnPredicteveScoreTab()-------------"+datatype);
  		UIHelper.waitForPageToLoad(getDriver());
  		
  		switch(datatype)
  		{
  			case "Text":				
  				//Predictive Scores > Portfolio Comparison	
  				System.out.println("--------Text------------------");
  				PredectiveScoreTab.click();
  				 UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),"//div[@id='widget_container']/div/span[contains(text(),'Loading')]");
  				 UIHelper.waitForPageToLoad(getDriver());
  				 /*if(Portfoliocomparison.getText().equalsIgnoreCase("Portfolio Comparison")){
  					 PortfoliocomparisonImg.isVisible();
  				 String src=getDriver().findElement(By.xpath("//div[@id='widget_container']/div[4]/table/tbody/tr[3]/td[1]/img")).getAttribute("src");
  				 
  				 
  				 }*/
  				 resultAfterEvalution="";
  				 break;
  			case "Number":
  				//- Predictive Scores > Financial Stress Score 
  				System.out.println("---------------number-------------");
  				PredectiveScoreTab.click();
  				imageLoading.waitUntilNotVisible();
  				UIHelper.waitForPageToLoad(getDriver());
  				 financialStressscorevalue.getText();
  				 break;
  			case "True/False" :
  				//Predictive Scores > employees
  				System.out.println("---------------True/False-------------");
  				PredectiveScoreTab.click();
  				imageLoading.waitUntilVisible();
  				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),"//div[@id='widget_container']/div/span[contains(text(),'Loading')]");
  				UIHelper.waitForPageToLoad(getDriver());
  				System.out.println("---------------True/False-------------");
  				resultAfterEvalution=predectiveEmployeeTotal.getText();
  				System.out.println("----------------------------"+resultAfterEvalution);
  				break;
  			case "Date" :
  				//Predictive Scores > Financial Stress Score
  				PredectiveScoreTab.click();
  				imageLoading.waitUntilNotVisible();
  				UIHelper.waitForPageToLoad(getDriver());
  				financialStressscorevalue.getText();
  			case "Percentage" :
  				//Predictive Scores > Financial Stress Score
  				PredectiveScoreTab.click();
  				imageLoading.waitUntilNotVisible();
  				UIHelper.waitForPageToLoad(getDriver());			
  				break;
  			case "currency" :
  				// Financials > View company financials from -D&B > Additional Financial Data
  				finacialstatementTab.click();
  				 UIHelper.waitForPageToLoad(getDriver());
  				 break;
  		}
  	
  	}

  	public String validateFormulaeWithDataType(String datatype, String formulae,String field) {
  			
  		System.out.println("The passed data type--------------->"+datatype);
  		switch(datatype){
  		
  		case "Text":
  			
  			//Predictive Scores > Portfolio Comparison
  			PredectiveScoreTab.click();
  			return calcFieldValue;
  		case "Number":
  			//- Predictive Scores > Financial Stress Score 
  			PredectiveScoreTab.click();
  			imageLoading.waitUntilNotVisible();
  			 UIHelper.waitForPageToLoad(getDriver());
  			 
  			resultAfterEvalution=financialStressscorevalue.getText();
  			return resultAfterEvalution;
  			
  			
  		case "True/False" :
  			//Predictive Scores > employees
  			System.out.println("----It is clicking Predictive score tab------");
            UIHelper.waitForPageToLoad(getDriver());
  			System.out.println("----ui value--------------"+calcFieldValue);
  			 return calcFieldValue;
  		case "Date" :
  			//Predictive Scores > Financial Stress Score 
  			PredectiveScoreTab.click();
  			imageLoading.waitUntilNotVisible();
  			UIHelper.waitForPageToLoad(getDriver());
  			resultAfterEvalution=financialStressscorevalue.getText(); 
//  			return resultAfterEvalution;
  			return calcFieldValue;
  		case "Percentage" :
  			
  			//Predictive Scores > Financial Stress Score 
  			PredectiveScoreTab.click();
  			imageLoading.waitUntilNotVisible();
  			 UIHelper.waitForPageToLoad(getDriver());
  			
//  			 return resultAfterEvalution;
  			 return calcFieldValue;
  		case "currency" :
  			// Financials > View company financials from -D&B > Additional Financial Data
  			finacialstatementTab.click();
  			 UIHelper.waitForPageToLoad(getDriver());
  			 selectOption.isVisible();
  			 Select selectByValue = new Select(getDriver().findElement(By.xpath("//select[@id='dataSourceType']")));
  			 selectByValue.selectByValue("D&B");
  			 UIHelper.waitForPageToLoad(getDriver());
  			 resultAfterEvalution=totalAssets.getText();
  			       
  			 return resultAfterEvalution;
  	}
  		return " ";


  	}

  	public boolean isPredicteveScorePageDisplayed() {

  		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),"//div[@id='widget_container']/div/span[contains(text(),'Loading')]");
  		UIHelper.waitForPageToLoad(getDriver());
  		return predectivescorepage.isDisplayed();
  		 
  	
  	}
  	
  	public String getEmployeeValue(){
  		String totalEmaployee = null;
//  		System.out.println("---------getEmployeeValue()----------");
//  		PredectiveScoreTab.click();
  		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),"//div[@id='widget_container']/div/span[contains(text(),'Loading')]");
  		UIHelper.waitForPageToLoad(getDriver());
  		System.out.println("-----------------"+predectiveEmployeeTotal.getText());
  		String value= predectiveEmployeeTotal.getText();
  		System.out.println("------"+value);
  		if(value.contains("")){
  			String totalvalue[] = value.split("\\s");
  			  totalEmaployee= totalvalue[0].replace(",","");
  			  System.out.println(totalEmaployee);
  			  return totalEmaployee;
  		}else
  			return value;
  
  	}
  	
  	
  	public String getFinancialStressScore(){
  		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),"//div[@id='widget_container']/div/span[contains(text(),'Loading')]");
  		UIHelper.waitForPageToLoad(getDriver());
  		return financialStressscorevalue.getText();
  		
  	}
  	
  	public String getTotalAssets(){
  		finacialstatementTab.click();
  		 UIHelper.waitForPageToLoad(getDriver());
  		 selectOption.isVisible();
  		 Select selectByValue = new Select(getDriver().findElement(By.xpath("//select[@id='dataSourceType']")));
  		 selectByValue.selectByValue("D&B");
  		 UIHelper.waitForPageToLoad(getDriver());
  		 String result=totalAssets.getText();
  		return result;
  	}
  	
  	public String getTotalCurrentAssets(){
  		finacialstatementTab.click();
  		 UIHelper.waitForPageToLoad(getDriver());
  		 selectOption.isVisible();
  		 Select selectByValue = new Select(getDriver().findElement(By.xpath("//select[@id='dataSourceType']")));
  		 selectByValue.selectByValue("D&B");
  		 UIHelper.waitForPageToLoad(getDriver());
  		String result=totalAssets.getText();
  		return result;
  		
  		
  	}
  	public String CommercialCreditScore(){
  		PredectiveScoreTab.click();
  		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),"//div[@id='widget_container']/div/span[contains(text(),'Loading')]");
  		UIHelper.waitForPageToLoad(getDriver());
  		return commercialCreditScore.getText();	
  	}
  	
  	public String getDBViabilityRating(){
  		System.out.println("------i am in getDBViability Rating-------");
  		PredectiveScoreTab.click();
  		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),"//div[@id='widget_container']/div/span[contains(text(),'Loading')]");
  		UIHelper.waitForPageToLoad(getDriver());
  		String src=getDriver().findElement(By.xpath("//table[@class='viability_rating']/tbody/tr[1]/td[@class='rating_score']/img")).getAttribute("src");
  		System.out.println(src);
  		String value=src.substring(src.lastIndexOf(".")-1,src.lastIndexOf("."));
  		System.out.println("-------------==========="+value);
  		return viabilityrating.getSelectedVisibleTextValue();
  		
  	}
  	
  	public String getPortfolioComparison(){
  		System.out.println("-----i am in getPortfolioComparison--------");
  		PredectiveScoreTab.click();
  		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),"//div[@id='widget_container']/div/span[contains(text(),'Loading')]");
  		UIHelper.waitForPageToLoad(getDriver());
  		String src=getDriver().findElement(By.xpath("//div[@id='widget_container']/div[4]/table/tbody/tr[3]/td[2]//preceding-sibling::td[1]/img")).getAttribute("src");
  		System.out.println(src);
  		String value=src.substring(src.lastIndexOf(".")-1,src.lastIndexOf("."));
  		System.out.println("-----------getPortfolioComparison--==========="+value);
  		return value;
  	}

  	public void enterDunsNumberInSearchField(String dunsNumber) {
  		searchField.waitUntilPresent();
  		searchField.sendKeys(dunsNumber);
  		searchField.sendKeys(Keys.ENTER);
  		UIHelper.waitForPageToLoad(getDriver());
  	}

  	public void clickOnAddTradeReference() {
  		AddTradeandBankReference.waitUntilClickable();
  		AddTradeandBankReference.click();
  		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),"//div[@class='modal_title']/h3[contains(text(),'Bank/Trade References')]");
  		UIHelper.waitForPageToLoad(getDriver());
  	}

  	public void isAccountInformationPageDisplayed() {
  		
  		AccountInformationPage.isVisible();
  	}

  	public void clickOnAddBankreferenceTab() {
  		if (AddTradeandBankReference.isVisible()){
  		AddTradeandBankReference.click();
  		waitFor(5000).milliseconds();
  		UIHelper.waitForPageToLoad(getDriver());
  		getDriver().switchTo().frame("__modal_iframe_target");
  		}
  	}

  	public void giveCompanyName(String company) {
  		bankReferenceName.waitUntilPresent();
  		bankReferenceName.sendKeys(company);
  	}

  	public void clickOnBankReferenceSubmitTab() {
  		bankReferenceSubmit.waitUntilClickable();
  		//if(count<3){
  		bankReferenceSubmit.click();
  		getDriver().switchTo().defaultContent();
  		//UIHelper.waitForPageToLoad(getDriver());
  		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), accInforamtionheader);
  		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tradeReferencesheader);
  		
  			//}
  		//count++;
  		
  	}

  	public boolean isbankReferenceNameDisplayed(String companyname) {
  		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),gurantorxpath);
  		UIHelper.highlightElement(getDriver(), bankRference);
  		String referenceName=getDriver().findElement(By.xpath("//div[@id='widget_container']//*[contains(@id,'BizRefs-ReferenceBusinessName')]//following-sibling::td[1]")).getText();
  		System.out.println("the entereed bank Reference name"+referenceName);
  		
  		if (referenceName.contains(referenceName)){ 	
  			System.out.println("AddTradeandBankReference is visible-----------");
  			return true;
  		}else{
  			System.out.println("AddTradeandBankReference is not visible-----------");
  			return false;
  		}
  			
  		//if(divValue<15){
  		//String referenceName=getDriver().findElement(By.xpath("//div[@id='widget_container']/div["+divValue+"]/div[1]/div[1]/table/tbody/tr[1]/td[@class='frmView']")).getText();
  		
  		
  		//divValue++;
  		//}
  	
  	}

  	public void clickOnAddGuarantorTab() {
  		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),gurantorxpath);
  		if (gurantor.isDisplayed()){
  		gurantor.click();
  		waitFor(5000).milliseconds();
  		UIHelper.waitForPageToLoad(getDriver());
  		getDriver().switchTo().frame("__modal_iframe_target");
  		}
  	}

  	public void giveGurantorName(String guarantor) {
  		gurantorInputText.waitUntilPresent();
  		gurantorInputText.sendKeys(guarantor);
  	}

  	public void clickOnAddGuarantorSubmit() {
  		gurantorSubmit.waitUntilClickable();
  		//if(count2<3){
  		gurantorSubmit.click();
  		getDriver().switchTo().defaultContent();
  		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), accInforamtionheader);
  		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tradeReferencesheader);
  		  		
  		//}
  		//count2++;
  	}

  	public boolean isGurantorNamevisible(String gname) {
  		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),gurantorxpath);
  		UIHelper.highlightElement(getDriver(), gurantorsectionheader);
  		String gurantorName=getDriver().findElement(By.xpath("//div[@id='widget_container']//*[contains(@id,'Guarantor-Name-First')]//following-sibling::td[1]")).getText();
  		System.out.println("the entereed bank Reference name"+gurantorName);
  		
  		if (gurantorName.contains(gname)){ 	
  			System.out.println("gurantor name is visible-----------");
  			return true;
  		}else{
  			System.out.println("gurantor name is not visible-----------");
  			return false;
  		}
  		
  		/*if (gurantor.isDisplayed()){
  		if(guarantorDiv<26){
  		String gurantorName=getDriver().findElement(By.xpath("//div[@id='widget_container']//*[contains(@id,'Guarantor-Name-First')]//following-sibling::td[1]")).getText();
  		System.out.println("the entereed bank gurantorName "+gurantorName);
  		j++;
  		}
  		guarantorDiv++;
  		}*/
  	}

	public void isUserDefinedFieldIsPresent(String userfield) {
		
		System.out.println("-----------------isCalculativeFieldIsPresent()--------------");
  		UIHelper.waitForPageToLoad(getDriver());
  		
  		String s1 = "//div[@class='frmSecEdit']//tr//td[contains(text(),'"+userfield+":"+"')]";
  		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),"//div[@class='frmSecEdit']//tr//td[contains(text(),'"+userfield+":"+"')]");
  		UIHelper.waitForPageToLoad(getDriver());
  		String s2 = "//div[@class='frmSecEdit']//tr//td[contains(text(),'" +userfield+ "')]//following-sibling::td[1]";
  			
  		String userfieldname=getDriver().findElement(By.xpath(s1)).getText().replace(":"," ");
  			System.out.println("the calculative field --------->"+userfieldname);	
  			UIHelper.waitForPageToLoad(getDriver());
  		if(userfield.equalsIgnoreCase(userfieldname.trim())){
  			userFieldValue=getDriver().findElement(By.xpath(s2)).getText();
  			System.out.println("the ui value of custom field------->"+userFieldValue);
  		}
  		
	}

	public boolean compareUserfiedwithEcfValue(String ecfvalue) {
	
		if(ecfvalue.equalsIgnoreCase(userFieldValue)){
         return true;
         }
		else
			return false;
		
	}

	public boolean getRuleTriggeredStatus(String rstatus) {

		reviewStatus.waitUntilVisible();
		if (reviewStatus.getText().contains(rstatus)) {
			System.out.println("rule status has changed---------------------------"+reviewStatus.getText());
			return true;
		} else {
			System.out.println("rule status has not changed---------------------------"+reviewStatus.getText());
			return false;
		}
		
	}
	public boolean getTriggeredRulenameDisplayed(String Rulename){
		rtriggered=ruletriggered.replace("dnbi", Rulename);
		System.out.println("rule name in ecf----------------"+rtriggered);
		ruleTriggered1=getDriver().findElement(By.xpath(rtriggered));
		if (ruleTriggered1.isDisplayed()){
			return true;
			}else{
				return false;
			}
	 }
	    

    
    
}
