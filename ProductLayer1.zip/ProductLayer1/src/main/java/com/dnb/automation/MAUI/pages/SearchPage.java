package com.dnb.automation.MAUI.pages;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class SearchPage extends PageObject
{

	@FindBy(xpath=".//*[@id='frmLookup']/table[2]/tbody")
	private WebElementFacade dunssearchframe;
	
	@FindBy(xpath=".//td/a[1]/img[contains(@alt,'D-U-N-S® number')]")
	private WebElementFacade dunsearchlink;
	
	@FindBy(xpath=".//td[2]/input[@name='Duns']")
	private WebElementFacade dunstxtbox;
	
	@FindBy(xpath=".//td/input[@id='BUTTON1']")
	private WebElementFacade submitbtn;
	
	@FindBy(xpath=".//*[@id='home']/table/tbody/tr[1]/td[2]/a")
	private WebElementFacade toolkithome;
	
	@FindBy(xpath=".//span/a/img[contains(@src,'Go-Button')]")
	private WebElementFacade gobtn;
	
	public boolean verifyDunsSearchFrame() throws Exception
	{
		UIHelper.switchToChildWindow2(getDriver());
		UIHelper.waitForPageToLoad(getDriver());
			if(dunssearchframe.isPresent())
			{
				UIHelper.highlightElement(getDriver(), dunssearchframe);
				return true;
			}else{
                getDriver().quit();
				return false;
		}
	}

	public void clickDunsSearch() 
	{
		try{
			UIHelper.waitForPageToLoad(getDriver());
			if(dunsearchlink.isPresent()){
				UIHelper.highlightElement(getDriver(), dunsearchlink);
				dunsearchlink.click();
			}
			}catch(Exception e){
				
			}
	}

	public void enterDunsdetails(String duns) 
	{
		try{
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.highlightElement(getDriver(), dunstxtbox);
			dunstxtbox.type(duns);
			
			}catch(Exception e){
				
			}	
	}

	public void clickSubmitbtn() 
	{
		try{
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.highlightElement(getDriver(), submitbtn);
			submitbtn.click();
			
			}catch(Exception e){
				
			}	
	}

	public void clickToolkitHome() 
	{
		try{
			UIHelper.waitForPageToLoad(getDriver());
			if(toolkithome.isPresent()){
				UIHelper.highlightElement(getDriver(), toolkithome);
				toolkithome.click();
			}
			}catch(Exception e){
				
			}
		
	}

	public void clickgobtn() {
		try{
			UIHelper.waitForPageToLoad(getDriver());
			if(gobtn.isPresent()){
				UIHelper.highlightElement(getDriver(), gobtn);
				gobtn.click();
			}
			}catch(Exception e){
				
			}
		
	}

}
