package com.dnb.automation.bd.pages;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.dnb.automation.utils.UIHelper;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/******************************************************************************************************
 * Description : DbConnection page to connect to the BD Database and get the
 * values.
 * 
 *******************************************************************************************************/
public class DBConnectionPage extends PageObject {

	private ResultSet resultSet;
	private Connection connection = null;
	private Statement statement;
	private String profile_Name = null;
	private String status_Code = null;	
	private String ServerName = "//DBQLGLDDBV01.us.dnb.com";
	private String PortNumber = "1521";
	private String Sid = "GLDQA";
	private String DBUserName = "gduser";
	private String DBPassword = "gduser";
	private String URL = "jdbc:oracle:thin:@"+ServerName +":" + PortNumber + "/"+Sid;
	private int DltCnt = 0;	
	static {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e1) {
			System.out.println("JDBC and oracal connection driver is missing.");
		}

	}

	/***********************************************************************************
	 * Function: Connect to BD Database and get the profile name. 
	 * Input : Duns number 
	 * Action : Connecting 
	 * DB Output : Profile Name	
	 * @throws SQLException
	 ***********************************************************************************/
	public String getProfileName(String duns) throws SQLException {

		 try {
			connection = DriverManager.getConnection(URL,DBUserName,DBPassword);
			System.out.println("You made it, take control your database now!");
			statement = connection.createStatement();
			resultSet = statement
					.executeQuery("select nme_txt from subj_nme_txt where subj_nme_id in (select subj_nme_id from subj_nme where subj_id = (select subj_id from subj where duns_nbr = '"
							+ duns
							+ "') And row_cre_id = 1) And lang_cd = 39 and row_inac_indc = 0");
			if (resultSet.next()) {
				profile_Name = resultSet.getString("nme_txt");
			} else {
				System.out
						.println("No records available with this duns number");
			}

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
		} finally {
			if (connection != null) {
				connection.close();

			}

		}

		return profile_Name;
	}
	
	/***********************************************************************************
	 * Function: Connect to BD Database and change the claimed profile status to Claim profile. 
	 * Input : Duns number 
	 * Action : Connecting 
	 * DB Output : NA	
	 * @throws SQLException
	 ***********************************************************************************/
	public void revertProfileClaimStatus(String duns) throws SQLException
	{
		 try {
			 
				connection = DriverManager.getConnection(URL,DBUserName,DBPassword);
				System.out.println("You made it, take control your database now!");
				statement = connection.createStatement();
				
				DltCnt = statement.executeUpdate("Delete from pfl_usr where usr_id in (select usr_id from pfl_clm_stat where pfl_clm_reqs_id in (select pfl_clm_reqs_id from pfl_clm_reqs where subj_id in (select subj_id from subj where duns_nbr = '" + duns + "')) and stat_cd=1) and subj_id = (select subj_id from subj where duns_nbr = '" + duns + "')");
				System.out.println("Deleted record count" +DltCnt);
				
				DltCnt = statement.executeUpdate("Delete from pfl_clm_stat where pfl_clm_reqs_id in (select pfl_clm_reqs_id from pfl_clm_reqs where subj_id in (select subj_id from subj where duns_nbr = '" + duns + "'))");
				System.out.println("Deleted record count" +DltCnt);
				
				DltCnt  = statement.executeUpdate("Delete from pfl_clm_reqs where subj_id in (select subj_id from subj where duns_nbr ='" + duns + "')");
				System.out.println("Deleted record count" +DltCnt);
				
				statement.executeUpdate("commit");
		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
		} finally {
			if (connection != null) {
				connection.close();
			}

		}

	}

	/***********************************************************************************
	 * Function: Connect to BD Database and get the user activation status 
	 * Input : Email id
	 * Action : NA
	 * DB Output : NA	
	 * @throws SQLException 
	 ***********************************************************************************/
	
	public String getUserStatusDB(String emailId) throws SQLException
	{
		 try {
			connection = DriverManager.getConnection(URL,DBUserName,DBPassword);
			System.out.println("You made it, take control your database now!");
			statement = connection.createStatement();
			resultSet = statement.executeQuery("select regn_Stat_code from usr where usr_eml_adr = '"+ emailId+ "'");
			if (resultSet.next()) {
				status_Code = resultSet.getString("regn_Stat_code");
			} else {
				System.out
						.println("No records available with this email id");
			}

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
		} finally {
			if (connection != null) {
				connection.close();

			}

		}

		return status_Code;
	}

	/***********************************************************************************
	 * Function: Connect to BD Database and get the FirstName 
	 * Input : Email id
	 * Action : NA
	 * DB Output : NA	
	 * @throws SQLException 
	 ***********************************************************************************/
	
	public String getFirstName(String emailId) throws SQLException
	{
		String DBfirstname = null;
		try {
			connection = DriverManager.getConnection(URL,DBUserName,DBPassword);
			System.out.println("You made it, take control your database now!");
			statement = connection.createStatement();
			resultSet = statement.executeQuery("SELECT INDV_FRNM FROM USR WHERE USR_EML_aDR = '"+ emailId+ "'");
			if (resultSet.next()) {
				DBfirstname = resultSet.getString("INDV_FRNM");
				System.out.println("DB name"+DBfirstname);
			} else {
				System.out
						.println("No records available with this email id");
			}

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
		} finally {
			if (connection != null) {
				connection.close();

			}
		}
		return DBfirstname;
	}	
	/***********************************************************************************
	 * Function: Connect to BD Database and get the Prefix
	 * Input : Email id
	 * Action : NA
	 * DB Output : NA	
	 * @throws SQLException 
	 ***********************************************************************************/
	
	public String getPrefix(String emailId) throws SQLException
	{
		String DBPrefix = null;
		try {
			connection = DriverManager.getConnection(URL,DBUserName,DBPassword);
			System.out.println("You made it, take control your database now!");
			statement = connection.createStatement();
			resultSet = statement.executeQuery("SELECT NME_PFX_CD FROM USR WHERE USR_EML_aDR = '"+ emailId+ "'");
			if (resultSet.next()) {
				DBPrefix = resultSet.getString("NME_PFX_CD");
				System.out.println("DB prefix"+DBPrefix);
			} else {
				System.out
						.println("No records available with this email id");
			}

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			System.out.println(e.getStackTrace());
		} finally {
			if (connection != null) {
				connection.close();

			}
		}
		return DBPrefix;
	}	
	/***********************************************************************************
	 * Function: Connect to BD Database and get the LastName
	 * Input : Email id
	 * Action : NA
	 * DB Output : NA	
	 * @throws SQLException 
	 ***********************************************************************************/
	public String getLastName(String emailId) throws SQLException
	{
		String DBLastName = null;
		try {
			connection = DriverManager.getConnection(URL,DBUserName,DBPassword);
			System.out.println("You made it, take control your database now!");
			statement = connection.createStatement();
			resultSet = statement.executeQuery("SELECT INDV_SRNME FROM USR WHERE USR_EML_aDR = '"+ emailId+ "'");
			if (resultSet.next()) {
				DBLastName = resultSet.getString("INDV_SRNME");
				System.out.println("DB LastName"+DBLastName);
			} else {
				System.out
						.println("No records available with this email id");
			}

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
		} finally {
			if (connection != null) {
				connection.close();

			}
		}
		return DBLastName;
	}
	/***********************************************************************************
	 * Function: Connect to BD Database and get the CountryCode
	 * Input : Email id
	 * Action : NA
	 * DB Output : NA	
	 * @throws SQLException 
	 ***********************************************************************************/
	public String getCountryCode(String emailId) throws SQLException
	{
		String DBCountryCode = null;
		try {
			connection = DriverManager.getConnection(URL,DBUserName,DBPassword);
			System.out.println("You made it, take control your database now!");
			statement = connection.createStatement();
			resultSet = statement.executeQuery("SELECT INTL_DILG_CODE FROM USR WHERE USR_EML_aDR = '"+ emailId+ "'");
			if (resultSet.next()) {
				DBCountryCode = resultSet.getString("INTL_DILG_CODE");
				System.out.println("DB CountryCode"+DBCountryCode);
			} else {
				System.out
						.println("No records available with this email id");
			}

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
		} finally {
			if (connection != null) {
				connection.close();

			}
		}
		return DBCountryCode;
	}
	/***********************************************************************************
	 * Function: Connect to BD Database and get the AreaCode 
	 * Input : Email id
	 * Action : NA
	 * DB Output : NA	
	 * @throws SQLException 
	 ***********************************************************************************/
	public String getAreaCode(String emailId) throws SQLException
	{
		String DBAreaCode = null;
		try {
			connection = DriverManager.getConnection(URL,DBUserName,DBPassword);
			System.out.println("You made it, take control your database now!");
			statement = connection.createStatement();
			resultSet = statement.executeQuery("SELECT AREA_CD_NBR FROM USR WHERE USR_EML_aDR = '"+ emailId+ "'");
			if (resultSet.next()) {
				DBAreaCode = resultSet.getString("AREA_CD_NBR");
				System.out.println("DB AreaCode"+DBAreaCode);
			} else {
				System.out
						.println("No records available with this email id");
			}

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
		} finally {
			if (connection != null) {
				connection.close();

			}
		}
		return DBAreaCode;
	}
	/***********************************************************************************
	 * Function: Connect to BD Database and get the PhoneNumber
	 * Input : Email id
	 * Action : NA
	 * DB Output : NA	
	 * @throws SQLException 
	 ***********************************************************************************/
	public String getPhoneNum(String emailId) throws SQLException
	{
		String DBPhoneNumber = null;
		try {
			connection = DriverManager.getConnection(URL,DBUserName,DBPassword);
			System.out.println("You made it, take control your database now!");
			statement = connection.createStatement();
			resultSet = statement.executeQuery("SELECT TLCM_NBR FROM USR WHERE USR_EML_aDR = '"+ emailId+ "'");
			if (resultSet.next()) {
				DBPhoneNumber = resultSet.getString("TLCM_NBR");
				System.out.println("DB PhoneNumber"+DBPhoneNumber);
			} else {
				System.out
						.println("No records available with this email id");
			}

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
		} finally {
			if (connection != null) {
				connection.close();

			}
		}
		return DBPhoneNumber;
	}
	/***********************************************************************************
	 * Function: Connect to BD Database and get the Extension
	 * Input : Email id
	 * Action : NA
	 * DB Output : NA	
	 * @throws SQLException 
	 ***********************************************************************************/
	public String getExtension(String emailId) throws SQLException
	{
		String DBExtension = null;
		try {
			connection = DriverManager.getConnection(URL,DBUserName,DBPassword);
			System.out.println("You made it, take control your database now!");
			statement = connection.createStatement();
			resultSet = statement.executeQuery("SELECT PHON_EXTN_NBR FROM USR WHERE USR_EML_aDR = '"+ emailId+ "'");
			if (resultSet.next()) {
				DBExtension = resultSet.getString("PHON_EXTN_NBR");
				System.out.println("DB Extension"+DBExtension);
			} else {
				System.out
						.println("No records available with this email id");
			}

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
		} finally {
			if (connection != null) {
				connection.close();

			}
		}
		return DBExtension;
	}
	/***********************************************************************************
	 * Function: Connect to BD Database and get the CountryDDL
	 * Input : Email id
	 * Action : NA
	 * DB Output : NA	
	 * @throws SQLException 
	 ***********************************************************************************/
	public String getCountryDDL(String emailId) throws SQLException
	{
		String DBCountryDDL = null;
		try {
			connection = DriverManager.getConnection(URL,DBUserName,DBPassword);
			System.out.println("You made it, take control your database now!");
			statement = connection.createStatement();
			resultSet = statement.executeQuery("SELECT CTRY_GEO_REF_ID FROM USR WHERE USR_EML_aDR = '"+ emailId+ "'");
			if (resultSet.next()) {
				DBCountryDDL = resultSet.getString("CTRY_GEO_REF_ID");
				System.out.println("DB Extension"+DBCountryDDL);
			} else {
				System.out
						.println("No records available with this email id");
			}

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
		} finally {
			if (connection != null) {
				connection.close();

			}
		}
		return DBCountryDDL;
	}
	/***********************************************************************************
	 * Function: Connect to BD Database and get the CompanyWebsite
	 * Input : Email id
	 * Action : NA
	 * DB Output : NA	
	 * @throws SQLException 
	 ***********************************************************************************/
	public String getCompanyWebsite(String emailId) throws SQLException
	{
		String DBCompanyWebsite = null;
		try {
			connection = DriverManager.getConnection(URL,DBUserName,DBPassword);
			System.out.println("You made it, take control your database now!");
			statement = connection.createStatement();
			resultSet = statement.executeQuery("SELECT WEB_PG_ADR FROM USR WHERE USR_EML_aDR = '"+ emailId+ "'");
			if (resultSet.next()) {
				DBCompanyWebsite = resultSet.getString("WEB_PG_ADR");
				System.out.println("DB Extension"+DBCompanyWebsite);
			} else {
				System.out
						.println("No records available with this email id");
			}

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
		} finally {
			if (connection != null) {
				connection.close();

			}
		}
		return DBCompanyWebsite;
	}
	
	
}