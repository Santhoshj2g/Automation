package com.dnb.automation.gdm.pages;

import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.pages.PageObject;

/**
 * Created by 630239 on 6/15/2017.
 */
public class HomePage extends PageObject {

    @FindBy(xpath = ".//*[@id='NavigationMenu']/ul/li/a[text()='Sign In']")
    private WebElementFacade homeLink;

    public void launchURL(String applicationURL) {

        getDriver().manage().deleteAllCookies();
        getDriver().manage().window().maximize();
        launchapplicationURL(applicationURL);

    }

    private void launchapplicationURL(String applicationURL) {
        getDriver().get(applicationURL);

    }

    public void clickonSignInLink() {
        UIHelper.waitForPageToLoad(getDriver());
        if (homeLink.isPresent()) {
            UIHelper.highlightElement(getDriver(), homeLink);
            homeLink.click();
        }
    }
}
