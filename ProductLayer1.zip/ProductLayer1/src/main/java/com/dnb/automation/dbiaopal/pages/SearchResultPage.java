package com.dnb.automation.dbiaopal.pages;

import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import java.nio.channels.SelectableChannel;
import java.util.Iterator;
import java.util.Set;

/**
 * Created by 630239 on 5/29/2017.
 */
public class SearchResultPage extends PageObject{

    @FindBy(xpath=".//*[@id='searchedbyduns']")
    private WebElementFacade pageTitle;

    @FindBy(xpath=".//button[@id='btnOrderReport']")
    private WebElementFacade orderbtn;

    @FindBy(xpath=".//button[contains(@class,'ok-btn')]")
    private WebElementFacade okbtn;

    @FindBy(xpath =".//span[@class='btn btn-primary']")
    private WebElementFacade viewReportbtn;

    String reportPopup =".//span[@class='btn btn-primary']";

    String reportTable =".//*[@id='OrderProductForm']//div[contains(text(),'Reports Available')]";

    String Title=".//*[@id='searchedbyduns']";

    String languageOPtion=".//label[contains(text(),'SERENITY')]/parent::div/parent::div/div[2]/select[contains(@id,'LanguageDropDownList')]";

    String reportOption =".//label[contains(text(),'SERENITY')]/parent::div/input[@id='ProductList']";

    String reportname= ".//input[@id='ProductList']/parent:: div/label[contains(text(),'SERENITY')]";

    public boolean VerifyPageTitle() {

        UIHelper.waitForVisibilityOfEleByXpath(getDriver(),Title);
        UIHelper.waitForPageToLoad(getDriver());
        if(pageTitle.isPresent())
            return true;
        else
            return false;
    }

    public boolean verifyReportAvailability(String reportExpectedName) {
        UIHelper.waitForPageToLoad(getDriver());
        UIHelper.waitForVisibilityOfEleByXpath(getDriver(),reportTable);
        WebElementFacade reportActualName= find(By.xpath(reportname.replace("SERENITY",reportExpectedName)));
        String reportName =reportActualName.getText();
        Boolean result= false;
        if(reportName.equalsIgnoreCase(reportExpectedName));
            result= true;

        return result;
    }

    public void selectReport(String reportExpectedName) {
        WebElementFacade reportActualOption= find(By.xpath(reportOption.replace("SERENITY",reportExpectedName)));
        if(reportActualOption.isPresent()){
            UIHelper.highlightElement(getDriver(),reportActualOption);
            reportActualOption.click();
        }
    }

    public void selectLanguage(String reportExpectedName, String language) {
        WebElementFacade languageActualOption= find(By.xpath(languageOPtion.replace("SERENITY",reportExpectedName)));
        if(languageActualOption.isPresent()){
            UIHelper.highlightElement(getDriver(),languageActualOption);
            Select se = new Select(languageActualOption);
            se.selectByVisibleText(language);
        }
    }

    public void clickOrderReport() {
        if(orderbtn.isPresent()){
            UIHelper.highlightElement(getDriver(), orderbtn);
            orderbtn.click();
        }
        UIHelper.waitForPageToLoad(getDriver());
        if(okbtn.isPresent()){
            UIHelper.highlightElement(getDriver(),okbtn);
            okbtn.click();
        }
        UIHelper.waitForVisibilityOfEleByXpath(getDriver(),reportPopup);
        UIHelper.waitForPageToLoad(getDriver());
        if(viewReportbtn.isPresent()){
            UIHelper.highlightElement(getDriver(),viewReportbtn);
            viewReportbtn.click();
        }
    }

}
