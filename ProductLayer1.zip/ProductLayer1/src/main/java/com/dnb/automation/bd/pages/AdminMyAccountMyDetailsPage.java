package com.dnb.automation.bd.pages;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dnb.automation.utils.UIHelper;

public class AdminMyAccountMyDetailsPage extends PageObject {

	@FindBy(xpath = "//a[@id='myAdminDetails']")
	private WebElementFacade tabMyDetails;

	@FindBy(xpath = "//div[@class='loadmask-msg']")
	private WebElementFacade imgLoading;
	
	String loadicon="//div[@class='loadmask-msg']";

	@FindBy(xpath = "//a[@id='manageDownloadLink']")
	private WebElementFacade manageDownLoadLink;

	@FindBy(xpath = "//div[@id='try3']/div[1]/h3[contains(text(),'Manage Downloads')]")
	private WebElementFacade manageDownLoadSection;

	@FindBy(xpath = "//input[@id='productDescription']")
	private WebElementFacade ProductDescriptionInput;

	@FindBy(xpath = "//input[@id='productOfferCode']")
	private WebElementFacade ProductOfferCode;

	@FindBy(xpath = "//input[@id='downloadCountLimit']")
	private WebElementFacade DownLoadCountLimit;

	@FindBy(xpath = "//input[@id='expiryDate']")
	private WebElementFacade DateField;

	@FindBy(xpath = "//div[@id='ui-datepicker-div']")
	private WebElementFacade DatePicker;
	//Serenity is not supporting window handle browse button
	String Browsebutton= "//a[input[@id='documentFile']]";
	
	//file pATH
//	String filePath="C:/Users/ManigamS/Downloads/51447403_PFStatement.pdf";
	
//	@FindBy(xpath = "//label[@id='docFilename']")
	@FindBy(css="label#docFilename")
	private WebElementFacade VisibleFile;
//	String VisibleFile="//label[@id='docFilename']";
	
	@FindBy(xpath = "//a[@id='uploadManageDownlaods']")
	private WebElementFacade UploadButton;
	@FindBy(xpath="//div[@id='reportErrorMessage']")
	private WebElementFacade ReportMessage;
	
	
	@FindBy(xpath="//a[@id='deleteDownloads']")
	private WebElementFacade DeleteDownloadbutton;
	

	// //*[@id='warning_body']/span/a[1]
	
//	@FindBy(xpath="//div[@id='warning_1']//a[@class='buttonBlue']/span")
//	private WebElementFacade ConfirmationBox;
	
	@FindBy(xpath="//*[@id='delete-confirm-dialog-mangdowload']//*[@id='warning_body']//span[contains(text(),'OK')]")
	private WebElementFacade ConfirmationBox;
	
	
//	private  int intOfferRowNo =0;
	 private String first_part = "//table[@id='manageDownloadsTable']/tbody/tr[";
	 private String second_part = "]/td[";
	 private String third_part = "]";
	 String DeleteButton="/a[@id='deleteDownloads']";
	
	/***********************************************************************************
	 * Function: Select the my details tab in admin my account page Input : NA
	 * Action: NA Output : NA
	 ***********************************************************************************/
	public void selectMyDetailsTab() {
		tabMyDetails.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		imgLoading.waitUntilNotVisible();
	}

	/***********************************************************************************
	 * Function: Verify Manage download link is visible on Admin Mydetails tab.
	 * Input : NA Action: NA Output : NA
	 ***********************************************************************************/
	public boolean isManageDownloadsLinkVisible() {
		return manageDownLoadLink.isVisible();
	}

	/***********************************************************************************
	 * Function: Verify Manage download link is clickable on Admin Mydetails
	 * tab. Input : NA Action: NA Output : NA
	 ***********************************************************************************/

	public void clickManageDownloadsLink() {
		manageDownLoadLink.click();
	}

	/***********************************************************************************
	 * Function: Verify Manage download section is visible on Admin Mydetails
	 * tab. Input : NA Action: NA Output : NA
	 ***********************************************************************************/

	public boolean isManageDownloadsSectionVisible() {
		System.out.println("Test1..." + manageDownLoadSection.isVisible());
		return manageDownLoadSection.isVisible();
	}

	/***********************************************************************************
	 * Function: Need to Enter ProductDescription details. Input : String
	 * Action: NA Output : NA
	 ***********************************************************************************/
	public void giveProductDescription(String ProductDes) {
		// TODO Auto-generated method stub
		ProductDescriptionInput.sendKeys(ProductDes);
	}

	/***********************************************************************************
	 * Function: Need to Enter ProductOfferCode details. Input : String Action:
	 * NA Output : NA
	 ***********************************************************************************/
	public void giveProductOfferCode(String productOfferCode) {
		// TODO Auto-generated method stub
		ProductOfferCode.sendKeys(productOfferCode);
	}

	/***********************************************************************************
	 * Function: Need to Enter DownLoadCountLimit details. Input : String
	 * Action: NA Output : NA
	 ***********************************************************************************/
	public void giveDownLoadCountLimit(String downcntlmt) {
		
		DownLoadCountLimit.sendKeys(downcntlmt);

	}

	/***********************************************************************************
	 * Function: Need to Enter todays date details. Input : String Action: NA
	 * Output : NA
	 ***********************************************************************************/
	public void selectDownloadExpAsToDayDate() {
		// TODO Auto-generated method stub

		DateField.click();
		DatePicker.waitUntilEnabled();

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd");
		Date date1 = new Date();
		String today = dateFormat.format(date1);
		String str = ((String) today).replaceAll("^0*", "");
		
		WebElement dateWidget = getDriver().findElement(
				By.xpath("//div[@id='ui-datepicker-div']"));

		List<WebElement> columns = dateWidget.findElements(By.tagName("td"));

		for (WebElement cell : columns) {
			if (cell.getText().equals(str)) {
				
				cell.findElement(By.linkText(str)).click();
				break;
			}
		}
		
	}
	/***********************************************************************************
	 * Function: Need to selectFILE through Browsebutton.
	 *  Input :file: NA
	 * Output : NA
	 ***********************************************************************************/
	public void selectFilethroughBrowseButton(String FileName) {
		
/*		getDriver().findElement(By.cssSelector("input#documentFile")).click();
		getDriver().switchTo().activeElement();
	    getDriver().manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
						
		try {
			Thread.sleep(15000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		try {
//			Runtime.getRuntime().exec("C:/Users/ManigamS/Desktop/BDManageDown.exe");
			System.out.println("------------calling auto it-----------------");
//			Runtime.getRuntime().exec("C:/Users/ManigamS/Desktop/Fileuploads.exe");
			Runtime.getRuntime().exec("C:\\BD_AutoIT\\AutoIt_UploadFile.exe "+FileName+"");
		} catch (IOException e) {
			
			e.printStackTrace();
		}
*/		
		String UploadImagePath = System.getProperty("user.dir")+"\\src\\test\\resources\\AppTestData\\BusinessDirectory\\UploadImages\\"+FileName;
		getDriver().findElement(By.id("documentFile")).sendKeys(UploadImagePath);
		VisibleFile.waitUntilPresent();
		System.out.println("File uploaded successfully-------------");

		
	}

	/***********************************************************************************
	 * Function: Need to verify FileName is Visible.
	 *  Input :file: NA
	 * Output : NA
	 ***********************************************************************************/
	public boolean isFileNameVisible() {

		System.out.println("-------File visible------------"+VisibleFile.getText());
		return VisibleFile.isVisible();
			
	}

	/***********************************************************************************
	 * Function: Need to click UploadButton.
	 *  Input :file: NA
	 * Output : NA
	 ***********************************************************************************/
	public boolean clickUploadButton() {
		// TODO Auto-generated method stub
		UploadButton.click();
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadicon);
//		getDriver().manage().timeouts().implicitlyWait(600, TimeUnit.SECONDS);
		
		if(ReportMessage.isCurrentlyVisible())
			return false;
		else
			
		return true;
		
	}

	/***********************************************************************************
	 * Function: Need to verify ProductOfferCodePresent in the ManageDownload page.
	 *  Input :file: productOfferCode
	 * Output : boolean
	 ***********************************************************************************/
	public boolean isProductOfferCodePresent(String productOfferCode) {
			
		return verifyOffercode(productOfferCode);
		
	}

	/***********************************************************************************
	 * Function: Need to clickOnDeleteButton.
	 *  Input :file: NA
	 * Output : NA
	 ***********************************************************************************/
	
	public void clickOnDeleteButton(String productOfferCodes) {

	try{
		getDriver().findElement(By.xpath("//*[text()='"+productOfferCodes+"']/following-sibling::td/a")).click();
		
		getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		
//		String wb = getDriver().findElement(By.xpath("//*[@id='warning_body']/div[contains(text(),'Are you sure you want to remove the document?')]")).getText();
//		System.out.println(wb);
		
//		WebElement element=getDriver().findElement(By.xpath("//*[@id='delete-confirm-dialog-mangdowload']//*[@id='warning_body']//span[contains(text(),'OK')]"));
		
//		System.out.println(element.getText());
//		element.click();
		
	     
        
	}catch (Exception e) {
		e.printStackTrace();
	}

	}
	
	/***********************************************************************************
	 * Function:Need to verify  isConfirmationbox avilable.
	 *  Input :file: NA
	 * Output : NA
	 ***********************************************************************************/
	
	public void isConfirmationPromptAvilable() {

		System.out.println("we are calling this for confirmation box ok");
 		ConfirmationBox.isDisplayed();
			
		
	}
	
	/***********************************************************************************
	 * Function: Need to click on  confirmationbox .
	 *  Input :file: NA
	 * Output : NA
	 ***********************************************************************************/
   
	public void clickOnConfirmationButton() {
	
		ConfirmationBox.click();

	}

	/***********************************************************************************
	 * Function: Need to check ProductOfferCode in ManageDownloads table.
	 *  Input :file: productOfferCodefile
	 * Output : NA
	 ***********************************************************************************/
	
	public boolean isProductOfferCodeFileAvilable(String productOfferCodefile) {
		return verifyOffercode(productOfferCodefile);		
	}

	/***********************************************************************************
	 * Function: Need to verify Offercode in MangeDownloadsTable using Utility Method.
	 *  Input :file: offerCode 
	 * Output : boolean
	 ***********************************************************************************/
	//
	
	public boolean verifyOffercode(String offerCode){
		         // Grab the table 		
				//table[@id='manageDownloadsTable'] "table-6"
				  WebElement table = getDriver().findElement(By.xpath("//table[@id='manageDownloadsTable']/tbody")); 

				  //Get number of rows in table 
				  int numOfRow = table.findElements(By.tagName("tr")).size(); 
				  System.out.println("NO OF ROWS IN THE TABLE-------"+numOfRow);
				  //Get number of columns In table.
				  int numOfCol = getDriver().findElements(By.xpath("//table[@id='manageDownloadsTable']/tbody/tr[1]/td")).size();

				  System.out.println("NO OF Columns IN THE TABLE------"+numOfCol);
 

				  //take the second column values
				  int j=2;

				  //Loop through the rows and get the second column and put it in a list
				  for (int i=1; i<=numOfRow; i++){

				    //Prepared final xpath of specific cell as per values of i and j.
				       String final_xpath = first_part+i+second_part+j+third_part;
				       //Will retrieve value from located cell and print It.
				       System.out.println("final path:------"+final_xpath);
				       String test_name = getDriver().findElement(By.xpath(final_xpath)).getText();
				       System.out.println(test_name);
				       if(test_name.equalsIgnoreCase(offerCode)){
				       System.out.println(test_name);
//				       intOfferRowNo = i;
				       return true;
				       }

				  }
				return false;
	}

	
	

}
