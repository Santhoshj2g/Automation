package com.dnb.automation.dnbi.pages;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;

public class DnbiAdminCreatUserPages extends PageObject {

	@FindBy(xpath = "//div[@class='widget adminbasic']/ul[@class='basicMenu']//a/strong[contains(text(),'Administer Users')]")
	private WebElementFacade administerUserslink;

	@FindBy(xpath = "//div[@id='pageHead']//div[@id='page_title']//h2[contains(text(),'Administer Users')]")
	private WebElementFacade administerUserspage;

	@FindBy(xpath = "//div[@id='adminLayout']//div[@id='tab1']//input[@value='Add New User']")
	private WebElementFacade addNewUser;

	@FindBy(xpath = "//div[@id='main']//div[@id='page_title']/h2[contains(.,'	Administer Users - Add')]")
	private WebElementFacade adminUsersAdd;

	@FindBy(xpath = "//div[@id='div']//table[@class='form_leftMargin']//select[@name='salutation']")
	private WebElementFacade salutation;

	@FindBy(xpath = "//div[@class='widget_form']/table[@class='form_leftMargin']//input[@id='BizInfo-Fname']")
	private WebElementFacade FirstName;

	@FindBy(xpath = "//div[@class='widget_form']/table[@class='form_leftMargin']//input[@id='BizInfo-Lname']")
	private WebElementFacade lastName;

	@FindBy(xpath = "//div[@class='widget_form']/table[@class='form_leftMargin']//input[@id='BizInfo-Login']")
	private WebElementFacade loginmail;

	@FindBy(xpath = "//div[@class='widget_form']/table[@class='form_leftMargin']//input[@name='confirmNewEmail']")
	private WebElementFacade confirmNewEmail;

	@FindBy(xpath = "//div[@class='widget_form']/table[@class='form_leftMargin']//input[@id='BizInfo-Address']")
	private WebElementFacade UserAddress;

	@FindBy(xpath = "//div[@class='widget_form']/table[@class='form_leftMargin']//input[@id='BizInfo-City']")
	private WebElementFacade UserCity;

	@FindBy(xpath = "//div[@class='widget_form']/table[@class='form_leftMargin']//select[@id='state']")
	private WebElementFacade state;

	@FindBy(xpath = "//div[@class='widget_form']/table[@class='form_leftMargin']//input[@id='BizInfo-Zip']")
	private WebElementFacade UserZip;
    
	@FindBy(xpath = "//div[@class='widget_form']/table[@class='form_leftMargin']//select[@name='country']")
	private WebElementFacade country;

	@FindBy(xpath = "//div[@class='widget_form']/table[@class='form_leftMargin']//input[@id='BizInfo-Phone']")
	private WebElementFacade UserPhone;

	@FindBy(xpath = "//div[@class='widget_form']/table[@class='form_leftMargin']//select[@ name='availRoles1']")
	private WebElementFacade availRoles1;

	@FindBy(xpath = "//div[@class='widget_form']/table[@class='form_leftMargin']//a[1]/img")
	private WebElementFacade addimgbutton;

	@FindBy(xpath = "//div[@class='widget_form']/table[@class='form_leftMargin']//a[2]/img")
	private WebElementFacade removeimgbutton;

	@FindBy(xpath = "//div[@class='widget_form']/table[@class='form_leftMargin']//select[@name='assignedRoles']")
	private WebElementFacade assignedRoles;

	@FindBy(xpath = "//div[@id='formButton2']//input[@value='Submit']")
	private WebElementFacade submitbutton;
	
	@FindBy(xpath="//div[@id='adminLayout']//div[@id='adminContainer']//div[@id='terr_viewItems']//select[@id='viewItems']")
	private WebElementFacade selectPageNo;

	@FindBy(xpath = "//div[@id='tab_contents']//table[@id='srcRecordList']//tr[2]/td[7]/a[contains(text(),'Delete')]")
	private WebElementFacade deletelink;

	@FindBy(xpath = "//div[@class='modal']/div[@class='modal_title']/h3[contains(text(),'Delete User')]")
	private WebElementFacade deleteDialgoxbox;

	@FindBy(xpath = "//div[@class='modal_content']//div[@class='modal_buttons']/input[@id='yesDelBtn']")
	private WebElementFacade yesDelBtn;

	@FindBy(xpath = "//div[@class='modal_content']//div[@class='modal_buttons']/input[@value='OK']")
	private WebElementFacade OKBtn;

	@FindBy(xpath = "//div[@id='tab_contents']//table[@id='srcRecordList']//tr[2]/td[1]/a")
	private WebElementFacade editlink;

	@FindBy(xpath = "//form[@name='userDetailsForm']//div[@id='page_title']/h2[contains(.,'User Details')]")
	private WebElementFacade userdetailspage;

	@FindBy(xpath = "//div[@id='formButton2']/input[@value='Edit Details']")
	private WebElementFacade EditDetails;

	@FindBy(xpath = "//div[@id='main']//div[@id='page_title']/h2[contains(.,'Administer Users - Edit')]")
	private WebElementFacade editAdministerUserspage;

	@FindBy(xpath = "//div[@id='div']//table[@class='form_leftMargin']//tr//td/input[@name='firstName']")
	private WebElementFacade editfirstName;

	@FindBy(xpath = "//div[@id='div']//table[@class='form_leftMargin']//tr//td/input[@name='newEmail']")
	private WebElementFacade editnewEmail;

	@FindBy(xpath = "//div[@id='div']//table[@class='form_leftMargin']//tr//td/input[@name='confirmNewEmail']")
	private WebElementFacade editconfirmNewEmail;

	@FindBy(xpath = "//div[@id='div']//table[@class='form_leftMargin']//tr//td/input[@name='address']")
	private WebElementFacade editaddress;

	@FindBy(xpath = "//div[@id='div']//table[@class='form_leftMargin']//tr//td/input[@name='city']")
	private WebElementFacade editcity;

	@FindBy(xpath = "//div[@id='div']//table[@class='form_leftMargin']//select[@id='state']")
	private WebElementFacade editstate;

	@FindBy(xpath = "//div[@id='div']//table[@class='form_leftMargin']//tr//td/input[@name='zip']")
	private WebElementFacade editzip;

	@FindBy(xpath = "//div[@id='div']//table[@class='form_leftMargin']//tr//td/input[@name='phone']")
	private WebElementFacade editphone;

	@FindBy(xpath = "//div[@id='formButton2']/input[@value='Submit']")
	private WebElementFacade editValueSubmitButton;

	@FindBy(xpath = "//div[@id='div']//table[@class='form_leftMargin']//select[@name='title']")
	private WebElementFacade edittitle;

	@FindBy(xpath = "//div[@id='div']//table[@class='form_leftMargin']//select[@name='jobFunction']")
	private WebElementFacade editjobFunction;
	
	@FindBy(xpath = "//div[@id='widget_container']//div[@class='review_buttons']/input")
	private WebElementFacade decisionMakerInputButtons;
	
	@FindBy(xpath = "//div[@id='main']//div[@class='action_header']/div[@class='actionButtons']/input")
	private WebElementFacade decisionMakerActionButtons;
//-----------------------	
	
	
	@FindBy(xpath = "//div[@id='adminContainer']//div[@id='tabs1']//a[@id='terrMgrTab']")
	private WebElementFacade territorysTab;
	
	@FindBy(xpath = "//*[@id='tab5']//*[@id='enableCheckId']//ancestor::div[2]//following-sibling::input[@id='enableCheckId']")
	private WebElementFacade enableCheckId;
	
	@FindBy(xpath = "//*[@id='main']//div[@id='tab5']//div[@id='manage_terr_btn_div']/input[@value='Create New Territory']")
	private WebElementFacade createNewterritory;
	
	
	
	@FindBy(xpath = "//div[@id='main']//div[@id='page_title']/h2[contains(text(),'Territory Builder')]")
	private WebElementFacade TerritoryBuilderpage;
	
	@FindBy(xpath = "//div[@class='clear filt_bottomPad']//input[@id='territory_name']")
	private WebElementFacade territory_namebox;
	
	@FindBy(xpath = "//div[@class='filt_leftWrapper']//select[@id='data_fields']")
	private WebElementFacade selectVariable;
	
	@FindBy(xpath = "//div[@class='filt_btnWrapper']//img[@id='addDataFieldsAnd']")
	private WebElementFacade addDataFieldsAnd;
	
	@FindBy(xpath = "//div[@class='filt_tblOvrflow']//table[@class='data_table']//tr/td[1]/ancestor::table/ancestor::div[1]/preceding::div[1]/span/strong[contains(.,'AND Condition(s)')]")
	private WebElementFacade andcondition;
	
	@FindBy(xpath ="//div[@class='filt_tblOvrflow']//table[@class='data_table']//tr[1]/td[1]/following::select[@id='fieldInfoBean1_operator']")
	private WebElementFacade follwoingselect;
	
	@FindBy(xpath ="//div[@class='filt_tblOvrflow']//input[@id='fieldInfoBean1_operand1']")
	private WebElementFacade inputvar;
	
	@FindBy(xpath ="//div[@class='filt_tblOvrflow']//*[@id='fieldInfoBean1_operands']/a")
	private WebElementFacade anchorvalue;
	
	@FindBy(xpath ="//div[@class='modal']")
	private WebElementFacade divwindow;
	
	@FindBy(xpath ="//div[@class='filt_valPic_verAlign']//*[@id='filt_fieldName']")
	private WebElementFacade inputvariablewindow;
	
	@FindBy(xpath ="//div[@class='filt_valPic_verAlign']/span/a/strong[contains(.,'Add')]")
	private WebElementFacade adddivbutton;
	
	@FindBy(xpath ="//div[@class='modal_buttons']//input[@id='modal_filt_variableBtn']")
	private WebElementFacade submitdivbutton;
	
	@FindBy(xpath ="//div[@class='floatRight filt_btnWrapperTopPadding']//input[@id='form_submit']")
	private WebElementFacade formsubmitbutton;
	
	@FindBy(xpath ="//table[@id='manage_terr_table_id']/tbody/tr")
	private WebElementFacade territoryUserTable;
	
	@FindBy(xpath ="//table[@id='manage_terr_table_id']//tr[1]/td[3]/a[contains(.,'Assign Users')]")
	private WebElementFacade assignUsers;
	
	@FindBy(xpath="//body[@class='iframe_modal']//div[contains(@class,'modal_inner_content')]//select[@id='crntUserSlctBox']//option")
	private List <WebElementFacade> deselectScoreVariables;
	
	@FindBy(xpath="//body[@class='iframe_modal']//div[contains(@class,'modal_inner_content')]//select[@id='slctUserSlctBox']")
	private WebElementFacade selectUserFrame;
	
	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
	private WebElementFacade iFrameEle;
	
	@FindBy(xpath = "//body[@class='iframe_modal']//div[contains(@class,'modal_inner_content')]//img[@id='removeDataFields']")
	private WebElementFacade removeFrameBtn;
	
	@FindBy(xpath = "//body[@class='iframe_modal']//div[contains(@class,'modal_inner_content')]//img[@id='addDataFields']")
	private WebElementFacade addFrameBtn;
	
	@FindBy(xpath="//*[@class='modal_buttons']//input[@value='Save']")
	private WebElementFacade saveFrameBtn;
	
	@FindBy(xpath ="//div[@id='page_modal1']//div[@class='terr_btnColumn']//*[@id='addDataFields']")
	private WebElementFacade addDataFieldsbutton;
	
	@FindBy(xpath ="//div[@id='page_modal1']//div[@class='terr_btnColumn']//*[@id='removeDataFields']")
	private WebElementFacade removeDataFieldsbutton;
	
	@FindBy(xpath ="//*[@id='page_modal1']//div[@class='modal_buttons']/input[@class='btn bold btnPrimary' and @value='Save']")
	private WebElementFacade addDataFieldsavebutton;
	
	@FindBy(xpath ="//table[@id='manage_terr_table_id']//tr/td[2]/img[@class='view_terr_Images']")
	private WebElementFacade imglink;
	
	@FindBy(xpath ="//*[@id='manage_terr_table_id']/tbody/tr[2]/td[2]//table[@class='results userSmallTable']//tr[@class='RowWhite']/td[1]")
	private WebElementFacade addedUser;
	
	@FindBy(xpath ="//div[@id='header_mainApp']//ul[@id='primaryNav']//li/a[contains(.,'Decision Maker')]")
	private WebElementFacade DecisionMakerTab;
	
	@FindBy(xpath ="//ul[@class='tabs_section']//a[@id='inbox_preference_assigned' and contains(.,'My Applications')]")
	private WebElementFacade myApplications;
	
	@FindBy(xpath ="//div[@id='main']//div[@class='ap_dm_table_results1 ap_dm_table_results']/table[@class='results full_company']/tbody/tr/td[2]/a")
	private WebElementFacade resulttablerows;
	@FindBy(xpath ="//div[@id='main']//div[@class='ap_dm_table_results1 ap_dm_table_results']/table[@class='results full_company']")
	private WebElementFacade resulttable;
	
	@FindBy(xpath ="//ul[@class='tabs_section']//a[@id='inbox_preference_all' and contains(.,'All Applications')]")
	private WebElementFacade allApplications;
	
	@FindBy(xpath ="//div[@id='main']//div[@class='ap_dm_table_results1 ap_dm_table_results']/table[@class='results full_company']/tbody/tr")
	private WebElementFacade allApplicationsrows;
	
	@FindBy(xpath ="//div[@class='tab_div']//a[@id='inbox_preference_assigned' and contains(.,'My Accounts')]")
	private WebElementFacade myAccounts;
	
	@FindBy(xpath ="//div[@class='primaryNav_div']//ul[@id='primaryNav']/li/a[contains(text(),'Portfolio Risk Manager')]")
	private WebElementFacade portfolioRiskManagertab;
	
	@FindBy(xpath ="//div[@class='prm_left_box']//a[@id='selected_prm_link']")
	private WebElementFacade Delinquencytab;
	
	@FindBy(xpath ="//table[@id='failureDelinquencyTable']/tbody//tr/td[@id='fd_total']")
	private WebElementFacade totallink;
	
	@FindBy(xpath="//div[@id='failureDelinquencyReport']/h1[contains(.,'Risk by Failure & Delinquency')]")
	private WebElementFacade riskbyFailurepage;
	
	@FindBy(xpath="//div[@class='hScroller']//table[@id='drillDownTable']/tbody/tr")
	private WebElementFacade portfoliocount;
	
	@FindBy(xpath="//div[@class='terr_thirdColumn']//select[@id='crntUserSlctBox']")
	private WebElementFacade removeSelectTerritoryUser;
	
	@FindBy(xpath="//div[@class='terr_btnWrapper']//img[@id='removeDataFields']")
	private WebElementFacade imgremoveUser;
	
	@FindBy(xpath="//div[@id='page_modal1']//div[@class='modal_buttons']/input[@value='Save']")
	private WebElementFacade removeUserSave;
	
	@FindBy(xpath="//div[@id='compTitle']/h3[contains(text(),'Company Summary')]")
	private WebElementFacade CompanySummary;
	
	@FindBy(xpath="//div[@id='widget_container']//div[@class='review_buttons']/input")
	private WebElementFacade AccountManagerAllAccountsInputButtons;
	
	@FindBy(xpath="//div[@id='main']//div[@class='action_header']/div[@class='actionButtons']/input")
	private WebElementFacade AccountManagerAllAccountsActionbuttons;
	
	@FindBy(xpath="//div[@id='tabs1']//a[@id='terrTab' and contains(text(),'Groups')]")
	private WebElementFacade groupsTab;
	
	@FindBy(xpath="//div[@class='clear']//input[@id='submitBtn']")
	private WebElementFacade groupSubmit;
	
	@FindBy(xpath="//div[@id='main']//div[@class='role_group_marginB20']//input[@name='groupName']")
	private WebElementFacade mygroupName;
	
	@FindBy(xpath="//div[@id='tab3']//input[@value='Add Groups']")
	private WebElementFacade addGroupsbutton;
	
	@FindBy(xpath ="//*[@id='folder_bar']//div[@class='matchesResult']/strong")
	private WebElementFacade foldervalue;
	@FindBy(xpath ="//div[@class='tab_div']//a[@id='inbox_preference_all' and contains(.,'All Accounts')]")
	private WebElementFacade allAccountsTab;
	
	
	@FindBy(xpath ="//div[@id='main']//ul[@class='ecf_toc']//li//a[contains(.,'Basic Admin')]")
	private WebElementFacade basicAdminTab;
	@FindBy(xpath ="//*[@id='main']//ul/li/a/strong[contains(.,'Usage Summary')]")
	private WebElementFacade usagessummary;
	

	private static int totalusers;
	
	
	@FindBy(xpath ="//div[@id='fraud_box']")
	private WebElementFacade fraudRiskbox;
	private static int myterritoryAccounts;
	private static int allAccountsCount;
	private static int accountcount;
	public String[] myDunArray;
	public String[] myAllapplicationArray;
	public boolean isChangesDone=false;
	
	@FindBy(xpath="//div[@id='backMiddle']/input[@value='Home']")
	private WebElementFacade editHome;
	
	
	@FindBy(xpath="//div[@id='adminContainer']//div[@class='blueTablist']//a[@id='roleTab']")
	private WebElementFacade roleTab;
	
	@FindBy(xpath="//div[@id='adminLayout']//div[@id='tab4']//input[@value='Set Role Permissions']")
	private WebElementFacade setRolePermissions;
	
	@FindBy(xpath = "//div[@class='Search_Criteria search_searchCriteria']//*[@id='folder_bar']//a[contains(text(),'Search Now')]")
    private WebElementFacade buttonSearch;
	
	@FindBy(xpath = "//*[@class='RowGray']//label[contains(.,'CheckboxName')]//ancestor::td[1]//preceding-sibling::td[1]//input[@type='checkbox']")
    private WebElementFacade checkName;
	
	@FindBy(xpath = "//*[@id='primaryNav']//a[contains(.,'Account Manager')]")
	private WebElementFacade accountManagerTab;
	
	@FindBy(xpath = "//table[@id='terr_valueTable']//tbody//tr//td[3]")
	private List <WebElementFacade> groupNames;
	
	@FindBy(xpath = "//form[@name='assignUserGroupForm']/div[@class='modal_buttons']/input[@value='Submit']")
	private WebElementFacade assignUserSubmitBtn;
	
	@FindBy(xpath = "//*[@id='tab4']//*[@id='viewByRoleUser']")
	private WebElementFacade roleuserRadioBtn;
	
	@FindBy(xpath = "//div[@class='widget_form']/table[@class='form_leftMargin']//select[@name='country']")
	private WebElementFacade adminUserCountryField;
	
	
	
	private static String confirmEmailDate;
	private static String actualFirstName;
	//div[@class='primaryNav_div']//ul[@id='primaryNav']/li/a[contains(text(),'Account Manager')]
	private WebElementFacade sampleremove;
	public static String[] userRoles;
	private  static int verifyRolecheck=1;
	private static int nousReports;
	private static int nointReports;
	private int firstUsReports;
	private int firstInternationalReports;
	private int secondUsReports;
	private int secondInternationalReports;
	String groupTableXpath="//table[@id='terr_valueTable']//tbody//tr";
	String userTableXpath="//*[@id='tab3']//table[@id='srcRecordList']//tbody//tr";
	String rolesTableXpath="//*[@id='role_valueTable']/tbody/tr";
	String rolesUserTableXpath="//*[@id='tab4']//table[@id='srcRecordList']//tbody//tr";
	String viewPermissionpageXpath="//*[@id='main']//h2";
	String newGroupNametextboxXpath="//div[@id='main']//div[@class='role_group_marginB20']//input[@name='groupName']";
public int getVerifyRolecheck() {
	if(isChangesDone)
		return verifyRolecheck;
	return 0;
	}

/**
 * 
 * 
 * aLL business logic METHODS 
 * 
 */
	

	public boolean isAdminsterUserPageDisplayed() {
		// TODO Auto-generated method stub
		System.out.println("---------------isAdminsterUserPageDisplayed---------------------");
		UIHelper.waitForVisibilityOfEleByXpath(
				getDriver(),
				"//div[@id='pageHead']//div[@id='page_title']//h2[contains(text(),'Administer Users')]");
		if (administerUserspage.isDisplayed()) {
			return true;
		}
		return false;
	}

	public void clickAddNewUserTab() {

		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				"//div[@id='adminLayout']//div[@id='tab1']//input[@value='Add New User']");
		addNewUser.click();
	}

	public boolean isAdminsterUserAddUserPageDisplayed() {

		UIHelper.waitForVisibilityOfEleByXpath(
				getDriver(),
				"//div[@id='main']//div[@id='page_title']/h2[contains(.,'	Administer Users - Add')]");
		if (adminUsersAdd.isDisplayed()) {
			return true;
		}
		return false;
	}

	public void selectSalutation() {
		// TODO Auto-generated method stub
		Select dropdown = new Select(
				getDriver()
						.findElement(
								By.xpath("//div[@id='div']//table[@class='form_leftMargin']//select[@name='salutation']")));
		dropdown.selectByVisibleText("Mr");
	}

	public void enterFirstname(String fname) {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(
				getDriver(),
				"//div[@class='widget_form']/table[@class='form_leftMargin']//input[@id='BizInfo-Fname']");
//		DateFormat dateFormat = new SimpleDateFormat("yyMMddmmss");
//        Date date = new Date();
//        fname = dateFormat.format(date); 
//        actualFirstName= "Ajith"+fname;
		FirstName.sendKeys(fname);
	}

	public void enterLastname(String lname) {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(
				getDriver(),
				"//div[@class='widget_form']/table[@class='form_leftMargin']//input[@id='BizInfo-Lname']");
		lastName.sendKeys(lname);
	}

	public void enterLoginEmail(String loginEmail) {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(
				getDriver(),
				"//div[@class='widget_form']/table[@class='form_leftMargin']//input[@id='BizInfo-Login']");
//		DateFormat dateFormat = new SimpleDateFormat("yyMMddmmss");
//        Date date = new Date();
//        String emailDate = dateFormat.format(date);
//        String loginEmail="Ajith"+emailDate+fname;
//        confirmEmailDate=loginEmail;
		loginmail.sendKeys(loginEmail);
	}
	
	public void deleteExistingUser(String userDelete) throws InterruptedException{
		try{
			List<WebElement> userNames=getDriver().findElements(By.xpath("//*[@id='srcRecordList']/tbody/tr/td[2]"));
			if(userNames.size()>=1)
			for(int i=2;i<=userNames.size();i++){
				WebElement checkUser=getDriver().findElement(By.xpath("//*[@id='srcRecordList']/tbody/tr["+i+"]/td[2]"));
				String getUsername=checkUser.getText();
				if(getUsername.equalsIgnoreCase(userDelete)){
					WebElement deleteUser=getDriver().findElement(By.xpath("//*[@id='srcRecordList']/tbody/tr[contains(.,'"+userDelete+"')]/td[contains(.,'Delete')]/a"));
					deleteUser.click();
					Thread.sleep(3000);
					WebElement clickYesBtn=getDriver().findElement(By.xpath("//div[@class='modal']//div[@class='modal_content']//div[@class='modal_buttons']//input[@id='yesDelBtn']"));
					Thread.sleep(3000);
					clickYesBtn.click();
					Thread.sleep(3000);
					WebElement clickOKbtn=getDriver().findElement(By.xpath("//div[@class='modal']//div[@class='modal_content']//div[@class='modal_buttons']//input[@value='OK']"));
					clickOKbtn.click();
					Thread.sleep(3000);
				}
				
			}
			
		
		
		
		
		
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void enterConfirmEmail(String confirmEmail) {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(
				getDriver(),
				"//div[@class='widget_form']/table[@class='form_leftMargin']//input[@name='confirmNewEmail']");
		confirmNewEmail.sendKeys(confirmEmail);
	}

	public void enterAddress(String address) {

		UIHelper.waitForVisibilityOfEleByXpath(
				getDriver(),
				"//div[@class='widget_form']/table[@class='form_leftMargin']//input[@id='BizInfo-Address']");
		UserAddress.sendKeys(address);
	}

	public void enterCity(String city) {
		// TODO Auto-generated method stub
		UserCity.sendKeys(city);
	}

	public void selectState() {
		// TODO Auto-generated method stub
		Select dropdown = new Select(
				getDriver()
						.findElement(
								By.xpath("//div[@class='widget_form']/table[@class='form_leftMargin']//select[@id='state']")));
		dropdown.selectByVisibleText("Massachusetts");
	}

	public void enterZipcode(String postalcode) {
		// TODO Auto-generated method stub
		UserZip.sendKeys(postalcode);
	}

	public void selectCountry() {
		// TODO Auto-generated method stub
		Select dropdown = new Select(
				getDriver()
						.findElement(
								By.xpath("//div[@class='widget_form']/table[@class='form_leftMargin']//select[@name='country']")));
		dropdown.selectByVisibleText("United States Of America");
	}
	
	public void selectCountry1(String Country) {
		// TODO Auto-generated method stub
		Select dropdown = new Select(
				getDriver()
						.findElement(
								By.xpath("//div[@class='widget_form']/table[@class='form_leftMargin']//select[@name='country']")));
		dropdown.selectByVisibleText(Country);
	}


	public void enterPhoneNumber(String phone) {
		// TODO Auto-generated method stub
		UserPhone.sendKeys(phone);
	}

	public void selectUserRoles() {
		// TODO Auto-generated method stub
		ArrayList<String> al = new ArrayList<String>();
		al.add("Admin");
		/*al.add("Credit Manager");
		al.add("IT Support");
		al.add("Credit Supervisor");*/
		UIHelper.selectMultipleFromDropdownList(getDriver(), availRoles1, al,
				addimgbutton);
	}

	public void clickOnAddImageButton() {
		// TODO Auto-generated method stub

	}

	public void clickOnSubmitButton() {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				"//div[@id='formButton2']//input[@value='Submit']");
		submitbutton.click();
	}

	public boolean isFirstNameDisplayed(String firstName) {
		List<WebElement> userNames=getDriver().findElements(By.xpath("//*[@id='srcRecordList']/tbody/tr/td[2]"));
		if(userNames.size()>=1)
		for(int i=2;i<=userNames.size();i++){
			WebElement checkUser=getDriver().findElement(By.xpath("//*[@id='srcRecordList']/tbody/tr["+i+"]/td[2]"));
			String getUsername=checkUser.getText();
			System.out.println("Actual User names are:************" +getUsername);
			System.out.println("Expected User names are:************" +firstName);
			if(getUsername.equalsIgnoreCase(firstName)){
			
				return true;
			}
		}
		return false;
	}
	
	public void selectAllRecords(){
		try{
		UIHelper.waitForPageToLoad(getDriver());
		selectPageNo.selectByVisibleText("500");
		Thread.sleep(5000);
		}catch(Exception e){
			e.printStackTrace();
		}
		}

	public void clickOnDeleteButton() {
		// TODO Auto-generated method stub
		deletelink.click();
	}

	public boolean isDialogboxDisplayedwithYes() {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(
				getDriver(),
				"//div[@class='modal']/div[@class='modal_title']/h3[contains(text(),'Delete User')]");
		if (deleteDialgoxbox.isDisplayed()) {
			yesDelBtn.click();
			return true;
		}
		return false;
	}

	public void clickOOKDialogbox() {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				"//div[@class='modal_content']//div[@class='modal_buttons']/input[@value='OK']");
		OKBtn.click();
	}

	public boolean isFirstNameNotDisplayed(String firstName) {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				"//div[@id='tab_contents']//table[@id='srcRecordList']//tr");
		int size = getDriver()
				.findElements(
						By.xpath("//div[@id='tab_contents']//table[@id='srcRecordList']//tr"))
				.size();
//		System.out.println("table size--------" + size);
		for (int i = 2; i <= size; i++) {
			String value = getDriver()
					.findElement(
							By.xpath("//div[@id='tab_contents']//table[@id='srcRecordList']//tr["
									+ i + "]/td[1]/a")).getText();
//			System.out.println("table VALUES DISPLAYED--------" + value);
			if (value.contains(firstName)) {
				return true;
			}
		}
		return false;
	}

	public void clickOnEditUser(String firstName) {
		// TODO Auto-generated method stub
//		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
//				"//div[@id='tab_contents']//table[@id='srcRecordList']//tr");
		int size = getDriver().findElements(By.xpath("//div[@id='tab_contents']//table[@id='srcRecordList']//tr")).size();
		System.out.println("table size--------" + size);
		for (int i = 2; i <= size; i++) {
			String value = getDriver().findElement(By.xpath("//div[@id='tab_contents']//table[@id='srcRecordList']//tr["+ i + "]/td[1]/a")).getText().trim();
			System.out.println("table VALUES DISPLAYED--------" + value+"-------------"+firstName);
//			String []st=value.split(",");
//			for (int j = 0; j < st.length; i++) {
			if (value.equalsIgnoreCase(firstName)) {
				System.out.println("---------22-------"+i);
				getDriver().findElement(By.xpath("//div[@id='tab_contents']//table[@id='srcRecordList']//tr["+i+"]/td[1]/a")).click();
				break;
			}	
				
//			}
			

			
		}
	}

	public boolean isuserdetailspage() {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//form[@name='userDetailsForm']//div[@id='page_title']/h2[contains(.,'User Details')]");
		if (userdetailspage.isDisplayed()) {
			return true;
		}
		return false;
	}

	public void clickEditDetailsbutton() {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//div[@id='formButton2']/input[@value='Edit Details']");
		EditDetails.click();
	}

	public boolean isAdminusersEditpageDisplayed() {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),	"//div[@id='main']//div[@id='page_title']/h2[contains(.,'Administer Users - Edit')]");
		if (editAdministerUserspage.isDisplayed()) {
			return true;
		}
		return false;
	}

	public void editFirstname(String fname) {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//div[@id='div']//table[@class='form_leftMargin']//tr//td/input[@name='firstName']");
		editfirstName.clear();
		//editfirstName.sendKeys(fname);
//		DateFormat dateFormat = new SimpleDateFormat("yyMMddmmss");
//        Date date = new Date();
//        fname = dateFormat.format(date); 
        editfirstName.sendKeys(fname);
	}

	public void editnewEmail(String email) {
		// TODO Auto-generated method stub
		editnewEmail.clear();
		//editnewEmail.sendKeys(email);
//		DateFormat dateFormat = new SimpleDateFormat("yyMMddmmss");
//        Date date = new Date();
//        String emailDate = dateFormat.format(date); 
        editnewEmail.sendKeys(email);
	}

	public void editConfirmEmail(String confirmEmail) {
		// TODO Auto-generated method stub
		editconfirmNewEmail.clear();
		editconfirmNewEmail.sendKeys(confirmEmail);
	}

	public void editAddress(String address) {
		// TODO Auto-generated method stub
		editaddress.clear();
		editaddress.sendKeys(address);
	}

	public void editCity(String city) {
		// TODO Auto-generated method stub
		editcity.clear();
		editcity.sendKeys(city);
	}

	public void editselectState(String state) {
		// TODO Auto-generated method stub
		Select dropdown = new Select(
				getDriver()
						.findElement(
								By.xpath("//div[@id='div']//table[@class='form_leftMargin']//select[@id='state']")));
		dropdown.selectByVisibleText(state);
	}

	public void editZipcode(String postalcode) {
		// TODO Auto-generated method stub
		editzip.clear();
		editzip.sendKeys(postalcode);
	}

	public void editPhoneNumber(String phone) {
		// TODO Auto-generated method stub
		editphone.clear();
		editphone.sendKeys(phone);
	}

	public void clickEditSubmitbutton() {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				"//div[@id='formButton2']/input[@value='Submit']");
		editValueSubmitButton.click();
	}

	public void editselectTitle(String title) {
		// TODO Auto-generated method stub
		Select dropdown = new Select(
				getDriver()
						.findElement(
								By.xpath("//div[@id='div']//table[@class='form_leftMargin']//select[@name='title']")));
		dropdown.selectByVisibleText(title);
	}

	public void editselectJobFunction(String jobFunction) {
		// TODO Auto-generated method stub
		Select dropdown = new Select(
				getDriver()
						.findElement(
								By.xpath("//div[@id='div']//table[@class='form_leftMargin']//select[@name='jobFunction']")));
		dropdown.selectByVisibleText(jobFunction);
	}

	public void isEditedusersDisplayed(String fname) {
		// TODO Auto-generated method stub
		int size = getDriver().findElements(By.xpath("//div[@id='div']//table[@class='form_leftMargin']//tr")).size();
		System.out.println("table size--------" + size);
		for (int i = 3; i <= size; i++) {
		
			String value = getDriver().findElement(By.xpath("//div[@id='div']//table[@class='form_leftMargin']//tr["
									+ i + "]/td[1]")).getText().trim();
			System.out.println("table VALUES DISPLAYED-------->" + value);
			if (value.equalsIgnoreCase("First Name")) {
				String modified=getDriver().findElement(By.xpath("//div[@id='div']//table[@class='form_leftMargin']//tr["+ i + "]/td[1]/following::td[1]")).getText();
				System.out.println("the modified value---------------------"+modified);
				if(modified.contains(fname)){
				break;
				}
					
			}
		}
//		return false;
	}

	public void clickterritorysTab() {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='adminContainer']//div[@id='tabs1']//a[@id='terrMgrTab']");
		((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", territorysTab);
		territorysTab.click();
	}

	public void isterritorysTabEnabled() {

System.out.println("isterritorysTabEnabled");
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[@id='tab5']//*[@id='enableCheckId']//ancestor::div[2]//following-sibling::input[@id='enableCheckId']");
		System.out.println("the true value ------------------------"+getDriver().findElement(By.xpath("//*[@id='tab5']//*[@id='enableCheckId']//ancestor::div[2]//following-sibling::input[@id='enableCheckId']")).isSelected());
		if(!getDriver().findElement(By.xpath("//*[@id='tab5']//*[@id='enableCheckId']//ancestor::div[2]//following-sibling::input[@id='enableCheckId']")).isSelected()){
			System.out.println("isterritorysTabEnabled if loop");
			enableCheckId.click();
		}else {
			System.out.println("isterritorysTabEnabled else loop");
//			enableCheckId.click();
		}
	}

	public void clickonAlertbox() {
		// TODO Auto-generated method stub
	UIHelper.processalert(getDriver());	
	UIHelper.waitForPageToLoad(getDriver());
	System.out.println("process alert finished-------------------");
	waitFor(3000).milliseconds();
	}

	public void clickonNewterritorysButton() {
		// TODO Auto-generated method stub
		System.out.println("-------- I am in the clickonNewterritorysButton -------------");
		String newterritorybtn="//*[@id='main']//div[@id='tab5']//div[@id='manage_terr_btn_div']/input[@value='Create New Territory']";
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),newterritorybtn);
		System.out.println("-----------I am in the click on new Territory-------------------");
		WebElement createnewterritorybutton=getDriver().findElement(By.xpath(newterritorybtn));
		((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", createnewterritorybutton);
		createnewterritorybutton.click();
//		 ((JavascriptExecutor)getDriver()).executeScript("arguments[0].click();", createNewterritory);
//		if(createnewterritorybutton.isDisplayed()){
//			System.out.println("-----------I am in the if block on new Territory3333-------------------");
//			createnewterritorybutton.click();
//		}
		
		
		waitFor(3000).milliseconds();
		System.out.println("-----------I am in the click on new Territory3333-------------------");
			
	}

	public boolean isTerritorybuilderpageDisplayed() {
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
		System.out.println("-----------I am in the isTerritorybuilderpageDisplayed-------------------");
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='main']//div[@id='page_title']/h2[contains(text(),'Territory Builder')]");
		if(TerritoryBuilderpage.isDisplayed()){
			System.out.println("-----------I am in the isTerritorybuilderpageDisplayed-----if block--------------");
			return true;
		}
		return false;
	}

	public void enterTerritoryandselectVariables(String territoryname,String variable,String variable1) {
		// TODO Auto-generated method stub
		territory_namebox.sendKeys(territoryname);
		ArrayList<String> al= new ArrayList<String>();
		al.add(variable);
		al.add(variable1);
		
		UIHelper.selectMultipleFromDropdownList(getDriver(), selectVariable, al, addDataFieldsAnd);
		getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	public void isVariableDisplayed(String condition,String operator) {
		// TODO Auto-generated method stub
		int size=0;
		String text=andcondition.getText().trim();
		System.out.println("The value of text-----"+text+"----condition-----"+condition);
		if(text.equalsIgnoreCase(condition))
		size= getDriver().findElements(By.xpath("//div[@class='filt_tblOvrflow']//table[@class='data_table']//tr/td[1]")).size();
		System.out.println("--------------size------------------------9999-->"+size);
		for (int i = 1; i <=size; i++) {
		if(getDriver().findElement(By.xpath("//div[@class='filt_tblOvrflow']//table[@class='data_table']//tr["+i+"]/td[1]/span")).getText().trim().length()>0){
//			if(follwoingselect.isDisplayed()){
				System.out.println("i am in select place--------------------"+size);
//				for(int j=1;j<=size;j++){
				Select select= new Select(getDriver().findElement(By.xpath("//div[@class='filt_tblOvrflow']//table[@class='data_table']//tr[@id='tr_"+i+"']/td[1]/following::select[1]")));  
				select.selectByVisibleText(operator);
				if(operator.equalsIgnoreCase("Contains")|| operator.equalsIgnoreCase("Does Not Contain")){
					System.out.println("i am in select place----------Contains----------");
					inputvar.sendKeys("US");
//					formsubmitbutton.click();
				}else if (operator.equalsIgnoreCase("Is Equal To")|| operator.equalsIgnoreCase("Is Not Equal To")) {
					System.out.println("i am in select place----------Is Equal To----------");
					
					if(i==1){
					getDriver().findElement(By.xpath("//div[@class='filt_tblOvrflow']//tr[@id='tr_"+i+"']//span/a")).click();
//					anchorvalue.click();
					UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//div[@class='modal']");
					inputvariablewindow.sendKeys("US");
					adddivbutton.click();
					getDriver().manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
					submitdivbutton.click();
					}
					if(i==2){
						getDriver().findElement(By.xpath("//div[@class='filt_tblOvrflow']//tr[@id='tr_"+i+"']//span/a")).click();
						UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//div[@class='modal']");
						inputvariablewindow.sendKeys("CA");
						adddivbutton.click();
						getDriver().manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
						submitdivbutton.click();
						}
				
					formsubmitbutton.click();
					System.out.println("i am in select place----------Is Equal To--------6--");
				}else {
					System.out.println("------not working properly-------");
					formsubmitbutton.click();
				}
//			}
		}
		}	
//		}
	}

	public void clickonAssignedUsers(String territoryName) {
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//table[@id='manage_terr_table_id']//tr[contains(.,'"+territoryName+"')]/td[3]/a[contains(.,'Assign Users')]");
		WebElement selectUserFrame1 = getDriver().findElement(By.xpath("//table[@id='manage_terr_table_id']//tr[contains(.,'"+territoryName+"')]/td[3]/a[contains(.,'Assign Users')]"));
		selectUserFrame1.click();
	}

	public void isSelecterUsersAssigned(String user) {
		
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
		getDriver().switchTo().frame(iFrameEle);
//		Select select= new Select(getDriver().findElement(By.xpath("//div[@id='page_modal1']//div[@class='terr_firstCol']//select[@id='slctUserSlctBox']")));  
//		select.selectByVisibleText(user);
//		addDataFieldsbutton.click();
		
		
//			for (WebElementFacade deselectOptions:deselectScoreVariables) {
//			
//			deselectOptions.click();
//			waitFor(200).milliseconds();
//			removeFrameBtn.click();
//			waitFor(200).milliseconds();
//		}
		WebElement selectUserFrame1 = getDriver().findElement(By.xpath("//body[@class='iframe_modal']//div[contains(@class,'modal_inner_content')]//select[@id='slctUserSlctBox']//option[contains(.,'"+user+"')]"));
		
		selectUserFrame1.click();
			waitFor(200).milliseconds();
		
			addFrameBtn.click();
			waitFor(200).milliseconds();
			saveFrameBtn.click();
		
	}

	public boolean isUsersDisplayedinCurrentDirectory(String user) {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//table[@id='manage_terr_table_id']//tr/td[2]/img[@class='view_terr_Images']");
		imglink.click();
		System.out.println("-----------addedUser.getText().trim()----------"+addedUser.getText().trim());
		if(addedUser.getText().trim().equalsIgnoreCase(user)){
			return true;
		}
		
		return false;
	}

	public void clickonAccountFolders() {
		// TODO Auto-generated method stub
		int rowcount=getDriver().findElements(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr")).size();
		for (int i = 1; i <=rowcount; i++) {
			String value = getDriver().findElement(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr["
									+ i + "]/td[2]/a")).getText().trim();
			System.out.println("------------------clickonAccountFolders()---------------"+value);
			if(value.equalsIgnoreCase("Accounts")){
				getDriver().findElement(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr["
						+ i + "]/td[2]/a")).click();
				break;
				
			}
			
		}
		
		
	}

	public boolean countTheAccountsinAccountFolder() {
		// TODO Auto-generated method stub
		int rowcount=getDriver().findElements(By.xpath("//div[@id='main']//table[@class='results full_company']/tbody/tr")).size();
		for (int i = 1; i <=rowcount; i++) {
			String value = getDriver().findElement(By.xpath("//div[@id='main']//table[@class='results full_company']/tbody/tr["
									+ i + "]/td[3]")).getText().trim();
			if(value.contains("CA")){
				return true;
				
			}
			
		}
		return false;
	}

	public void clickonApplicationsFolders() {
		UIHelper.waitForPageToLoad(getDriver());
		int rowcount=getDriver().findElements(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr")).size();
		for (int i = 1; i <=rowcount; i++) {
			String value = getDriver().findElement(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr["
									+ i + "]/td[2]/a")).getText().trim().replace("<br/>", "");
			if(value.equalsIgnoreCase("Applications")){
				getDriver().findElement(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr["
						+ i + "]/td[2]/a")).click();
				
			}
			
		}
	}

	public boolean countTheAccountsinApplicationsFolder() {
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
		int rowcount=getDriver().findElements(By.xpath("//div[@id='main']//table[@class='results full_company']/tbody/tr")).size();
		for (int i = 1; i <=rowcount; i++) {
			String value = getDriver().findElement(By.xpath("//div[@id='main']//table[@class='results full_company']/tbody/tr["
									+ i + "]/td[3]")).getText().trim().replace("<br/>", "");
			System.out.println("contains-------------"+value.contains("CA"));
			if(value.contains("CA")){
				return true;
				
			}
			
		}
		return false;
	}

	public void clickonMyApplicationTab() {
		// TODO Auto-generated method stub
		myApplications.click();
	}

	public void countMyApplicationAccounts() {
		// TODO Auto-generated method stub
//		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='main']//div[@class='ap_dm_table_results1 ap_dm_table_results']/table[@class='results full_company']");
		myterritoryAccounts=getDriver().findElements(By.xpath("//div[@id='main']//div[@class='ap_dm_table_results1 ap_dm_table_results']/table[@class='results full_company']/tbody/tr")).size();
		System.out.println("My Applications count for assigned users::::::::::::::"+myterritoryAccounts);
		 myDunArray=new String[myterritoryAccounts];
		for (int i = 1; i <= myterritoryAccounts; i++) {
			getDriver().findElement(By.xpath("//div[@id='main']//div[@class='ap_dm_table_results1 ap_dm_table_results']/table[@class='results full_company']/tbody/tr["+i+"]/td[2]/a")).click();
			UIHelper.waitForPageToLoad(getDriver());
			/*String dunsNum=getDriver().findElement(By.xpath("//div[@id='infoContainer']//ul[@class='dunsNo']//li[@id='duns']")).getText().trim();
			System.out.println("dunsno-------------------------->"+dunsNum);
			String value=dunsNum.substring(0, dunsNum.lastIndexOf('-')).trim();
			myDunArray[i-1]=value.substring(value.indexOf(':')+1, value.length()).trim();*/
			getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			isDecisionmakerinputbuttonsVisible();
			isDecisionmakeractionbuttonsVisible();
			getDriver().findElement(By.xpath("//ul[@id='breadcrumb']/li[2]/a[contains(.,'Decision Maker Home')]")).click();
			UIHelper.waitForPageToLoad(getDriver());
		}

		
	}

	public boolean isDecisionmakerinputbuttonsVisible() {
		System.out.println("-------------isDecisionmakerinputbuttonsVisible()-------------");
		/*UIHelper.waitForPageToLoad(getDriver());
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='widget_container']//div[@class='review_buttons']/input");
		WebElement el=getDriver().findElement(By.xpath("//div[@id='widget_container']//div[@class='review_buttons']/input"));
		UIHelper.highlightElement(getDriver(), el);
		int rowcount=getDriver().findElements(By.xpath("//div[@id='widget_container']//div[@class='review_buttons']/input")).size();*/
		if(decisionMakerInputButtons.isDisplayed()){
//		if(rowcount>0)
			return true;
		}
		
		return false;
	}

	public boolean isDecisionmakeractionbuttonsVisible() {
		// TODO Auto-generated method stub
		/*UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='main']//div[@class='action_header']/div[@class='actionButtons']/input");
		WebElement el=getDriver().findElement(By.xpath("//div[@id='main']//div[@class='action_header']/div[@class='actionButtons']/input"));
		UIHelper.highlightElement(getDriver(), el);
		int rowcount=getDriver().findElements(By.xpath("//div[@id='main']//div[@class='action_header']/div[@class='actionButtons']/input")).size();*/
		if(decisionMakerActionButtons.isDisplayed()){
//		if(rowcount>0)
			return true;
		}
		
		return false;
	}

	public boolean clickonAllApplicationTab() {
		// TODO Auto-generated method stub
		if(allApplications.isDisplayed()){
			return true;
		
		}
		return false;
	}
	public boolean AllApplicationTabNotVisible() {
		// TODO Auto-generated method stub
		if(!allApplications.isPresent()){
		return true;
		}
		return false;
		
	}
	

	public void countAllApplicationAccounts() {
		// TODO Auto-generated method stub
		

		allAccountsCount=getDriver().findElements(By.xpath("//div[@id='main']//div[@class='ap_dm_table_results1 ap_dm_table_results']/table[@class='results full_company']/tbody/tr")).size();
//		myAllapplicationArray= new String[allAccountsCount];
	
		for (int i = 1; i <= allAccountsCount; i++) {
			getDriver().findElement(By.xpath("//div[@id='main']//div[@class='ap_dm_table_results1 ap_dm_table_results']/table[@class='results full_company']/tbody/tr["+i+"]/td[2]/a")).click();
			
			/*String dunsNum=getDriver().findElement(By.xpath("//div[@id='infoContainer']//ul[@class='dunsNo']//li[@id='duns']")).getText().trim();
			
			String value=dunsNum.substring(0, dunsNum.lastIndexOf('-')).trim();
			
			System.out.println("--------------------"+value.substring(value.indexOf(':')+1, value.length()).trim());
			myAllapplicationArray[i-1]=value.substring(value.indexOf(':')+1, value.length()).trim();
			getDriver().findElement(By.xpath("//ul[@id='breadcrumb']/li[2]/a[contains(.,'Decision Maker Home')]")).click();
			getDriver().manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
		}
			System.out.println("myAllapplicationArray----------------->"+myAllapplicationArray.length);
			System.out.println("myDunArray----------------->"+myDunArray.length);
			
			for (int i = 1; i <= allAccountsCount; i++) {
				getDriver().findElement(By.xpath("//div[@id='main']//div[@class='ap_dm_table_results1 ap_dm_table_results']/table[@class='results full_company']/tbody/tr["+i+"]/td[2]/a")).click();
				
				for(int k=0;k<myDunArray.length;k++){
				
				   for(int j=0;j<myAllapplicationArray.length;j++){
					 
					   System.out.println("myapplication value----------"+myDunArray[k]+"AllApplication value-----"+myAllapplicationArray[j]);
				      if((myDunArray[k].equalsIgnoreCase(myAllapplicationArray[j]))){
				    	  continue;
				      }
				      else{
				    	*/
//					getDriver().manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
				    	isDecisionmakerInputButtonsnotDisplayed();
				    	isDecisionmakeractionButtonsnotDisplayed();
						
							getDriver().findElement(By.xpath("//ul[@id='breadcrumb']/li[2]/a[contains(.,'Decision Maker Home')]")).click();
						

				   					 


			
		}
		
		
	}

	public boolean isDecisionmakerInputButtonsnotDisplayed() {
		// TODO Auto-generated method stub
//		System.out.println("-----i AM IN THE InputButtonsnotDisplayed-------------------"+getDriver().findElements(By.xpath("//div[@id='widget_container']//div[@class='review_buttons']/input")).isEmpty());
		UIHelper.waitForPageToLoad(getDriver());
		if(getDriver().findElements(By.xpath("//div[@id='widget_container']//div[@class='review_buttons']/input")).isEmpty()){

			System.out.println("-----i AM IN THE DecisionMaker InputButtonsnotDisplayed--------compleated-----------");	
			return true;
		}
		
		return false;
	}

	public boolean isDecisionmakeractionButtonsnotDisplayed() {
		// TODO Auto-generated method stub
		System.out.println("-----i AM IN THE DecisionMaker actionButtonsnotDisplayed-------------------");
		UIHelper.waitForPageToLoad(getDriver());
		int rowcount=getDriver().findElements(By.xpath("//div[@id='main']//div[@class='action_header']/div[@class='actionButtons']/input")).size();
		System.out.println("-----rowcount-------------------"+rowcount);
		if(rowcount>1){
			System.out.println("-----i AM IN THE actionButtonsnotDisplayed--------compleated-----------");
			return true;
		}
		
		return false;
	}

	public void clickonMyAccountstab() {
		// TODO Auto-generated method stub
		myAccounts.click();
	}

	public void countAccountManagerAccounts() {
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='dd_inboxR']//table[@class='results full_company']/tbody/tr");
		accountcount=getDriver().findElements(By.xpath("//div[@id='dd_inboxR']//table[@class='results full_company']/tbody/tr")).size();

		for (int j = 1; j <= accountcount; j++) {
			System.out.println("j value------------------"+j);
	
		System.out.println("0000000000000000000000000000000000000000000000000");
		UIHelper.waitForPageToLoad(getDriver());
		WebElement  element=getDriver().findElement(By.xpath("//div[@id='dd_inboxR']//table[@class='results full_company']/tbody/tr["+j+"]/td[1]/a"));
		((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
		element.click();
	
		iscomapanySummaryPageDisplayed();
		System.out.println("3333333333333333333333333333333333333333333333333");
		isAccountReviewinputbuttonsVisible();
		System.out.println("44444444444444444444444444444444444444444444444444");
		isAccountReviewactionbuttonsVisible();
		System.out.println("55555555555555555555555555555555555555555555");
	
		getDriver().findElement(By.xpath("//ul[@id='breadcrumb']/li/a[contains(.,'Account Manager Home')]")).click();
		System.out.println("6666666666666666666666666666666666666666666666");
	
	}

	}

	public boolean iscomapanySummaryPageDisplayed() {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='compTitle']/h3[contains(text(),'Company Summary')]");
		UIHelper.highlightElement(getDriver(),CompanySummary );
		if(CompanySummary.getText().trim().equalsIgnoreCase("Company Summary")){
			return true;
		}
		return false;
	}
	
	public boolean isAccountReviewinputbuttonsVisible() {
		// TODO Auto-generated method stub
	
		
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='widget_container']//div[@class='review_buttons']/input");
		int rowcount=getDriver().findElements(By.xpath("//div[@id='widget_container']//div[@class='review_buttons']/input")).size();
		if(rowcount==0){
			return true;
		}
		
		return false;
	}

	public boolean isAccountReviewactionbuttonsVisible() {
		
		
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='main']//div[@class='action_header']/div[@class='actionButtons']/input");
		int rowcount=getDriver().findElements(By.xpath("//div[@id='main']//div[@class='action_header']/div[@class='actionButtons']/input")).size();
		if(rowcount>0){
//			getDriver().findElement(By.xpath("//ul[@id='breadcrumb']/li/a[contains(.,'Account Manager Home')]")).click();
			return true;
		}
//		getDriver().findElement(By.xpath("//ul[@id='breadcrumb']/li/a[contains(.,'Account Manager Home')]")).click();
		return false;
	}

	public void clickonAllAccountstabAccountManager() {
		// TODO Auto-generated method stub
		waitFor(3000).milliseconds();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@class='tab_div']//a[@id='inbox_preference_all' and contains(.,'All Accounts')]");
		getDriver().findElement(By.xpath("//div[@class='tab_div']//a[@id='inbox_preference_all' and contains(.,'All Accounts')]")).click();
	}

	public void countAllApplicationAccountManager() {
		// TODO Auto-generated method stub
		waitFor(3000).milliseconds();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='dd_inboxR']//table[@class='results full_company']/tbody/tr");
		int rowcount=getDriver().findElements(By.xpath("//div[@id='dd_inboxR']//table[@class='results full_company']/tbody/tr")).size();
		System.out.println("total no of row counts------------------------->"+rowcount);
		for (int j = 1; j <= rowcount; j++) {
			getDriver().findElement(By.xpath("//div[@id='dd_inboxR']//table[@class='results full_company']/tbody/tr["+j+"]/td[1]/a")).click();
			System.out.println("-------------------------01-------------------------------");
			iscomapanySummaryPageDisplayed();
			System.out.println("-------------------------01-------------------------------");
			isAccontManagerinputbuttonsnotVisible();
			isAccountReviewactionbuttonsnotVisible();
			getDriver().manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			getDriver().findElement(By.xpath("//ul[@id='breadcrumb']/li/a[contains(.,'Account Manager Home')]")).click();
		}
		/*if(rowcount>0){
			return true;
		}
		
		return false;*/
	}

	public boolean isAccontManagerinputbuttonsVisible() {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='widget_container']//div[@class='review_buttons']/input");
		int rowcount=getDriver().findElements(By.xpath("//div[@id='widget_container']//div[@class='review_buttons']/input")).size();
		if(rowcount>0){
			return true;
		}
		
		return false;
	}

	public boolean isAccontManagerinputbuttonsnotVisible() {
		// TODO Auto-generated method stub
		/*List<WebElement> input=getDriver().findElements(By.xpath("//div[@id='widget_container']//div[@class='review_buttons']/input"));
		for (WebElement buttons : input){
			if(buttons.isDisplayed()){
				UIHelper.highlightElement(getDriver(), buttons);
				
			}
		}
		
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='widget_container']//div[@class='review_buttons']/input");*/
		int rowcount=getDriver().findElements(By.xpath("//div[@id='widget_container']//div[@class='review_buttons']/input")).size();
		if(rowcount==0){
		System.out.println("------------------isAccontManagerinputbuttonsnotVisible--------------------------------");
//		if(!AccountManagerAllAccountsInputButtons.isDisplayed()){
			return true;
		}
		
		return false;
	}

	public boolean isAccountReviewactionbuttonsnotVisible() {
	/*	List<WebElement> input=getDriver().findElements(By.xpath("//div[@id='main']//div[@class='action_header']/div[@class='actionButtons']/input"));
		for (WebElement buttons : input){
			if(buttons.isDisplayed()){
				UIHelper.highlightElement(getDriver(), buttons);
				
			}
		}
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='main']//div[@class='action_header']/div[@class='actionButtons']/input");*/
		int rowcount=getDriver().findElements(By.xpath("//div[@id='main']//div[@class='action_header']/div[@class='actionButtons']/input")).size();
		if(rowcount==0){
		System.out.println("------------------isAccountReviewactionbuttonsnotVisible--------------------------------");
//		if(!AccountManagerAllAccountsActionbuttons.isDisplayed()){
			return true;
		}
		
		return false;	
	}
	
	
	public void uncheckterritorysTabEnabled() {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[@id='tab5']//*[@id='enableCheckId']//ancestor::div[2]//following-sibling::input[@id='enableCheckId']");
		if(getDriver().findElement(By.xpath("//*[@id='tab5']//*[@id='enableCheckId']//ancestor::div[2]//following-sibling::input[@id='enableCheckId']")).isSelected()){
			enableCheckId.click();
		}else {
//			enableCheckId.click();	
	}
		
}

	public void deleteterritory(String territory) {
		try{
		int size=getDriver().findElements(By.xpath("//div[@id='tab5']//table[@id='manage_terr_table_id']/tbody/tr")).size();
		for (int i = 1; i <size; i++) {
			if(getDriver().findElement(By.xpath("//div[@id='tab5']//table[@id='manage_terr_table_id']/tbody/tr["+i+"]//td[1]")).getText().equalsIgnoreCase(territory)){
			getDriver().findElement(By.xpath("//div[@id='tab5']//table[@id='manage_terr_table_id']/tbody/tr["+i+"]/td[3]/a[2]")).click();
			UIHelper.processalert(getDriver());
			Thread.sleep(5000);
			}
		}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void clickonportfolioRiskManagerTab() {
		// TODO Auto-generated method stub
		portfolioRiskManagertab.click();
	}

	public void clickonDelinquencytab() {
		// TODO Auto-generated method stub
		Delinquencytab.click();
	}

	public boolean isRiskbyFailurepageDisplyed() {
		// TODO Auto-generated method stub
		if(riskbyFailurepage.isDisplayed()){
			return true;
		}
		return false;
	}

	public void clickontotalvalue() {
		// TODO Auto-generated method stub
		totallink.click();
		UIHelper.waitForPageToLoad(getDriver());
	}

	public boolean countDunsNumberDisplayed() {
		// TODO Auto-generated method stub
	int dunsCount=getDriver().findElements(By.xpath("//div[@class='hScroller']//table[@id='drillDownTable']/tbody/tr")).size();
	if(myterritoryAccounts==dunsCount){
		return true;
	}
	return false;
	
	}

	public void deleteUserfromterritory(String user,String territory) {
		// TODO Auto-generated method stub
		System.out.println("--------***************----------------");
		getDriver().switchTo().frame("__modal_iframe_target");
		Select select= new Select(getDriver().findElement(By.xpath("//div[@class='terr_thirdColumn']//select[@id='crntUserSlctBox']")));  
		select.selectByVisibleText(user);
		imgremoveUser.click();
//		ArrayList<String> al= new ArrayList<String>();
//		al.add(territory);
//		UIHelper.selectMultipleFromDropdownList(getDriver(), removeSelectTerritoryUser, al, imgremoveUser);
		getDriver().manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
		removeUserSave.click();
	}

	public void clickOnPortFolioRiskManagerTab() {
		// TODO Auto-generated method stub
		portfolioRiskManagertab.click();
	}

	

	public boolean isFailureDelinquencypageDisplayed() {
		// TODO Auto-generated method stub
		if(riskbyFailurepage.isDisplayed()){
			return true;
		}
		return false;
	}

	public void clickFailureDelinquencyTab() {
		// TODO Auto-generated method stub
		
		getDriver().findElement(By.xpath("//div[@id='prm_main_left']//div/ul//li/a[contains(.,'Failure & Delinquency')]")).click();
//		Delinquencytab.click();	
	}

	public void clickTotalcolumnTable() {
		// TODO Auto-generated method stub
		totallink.click();
	}

	public boolean verifyCountofRows() {
		// TODO Auto-generated method stub
		int total=getDriver().findElements(By.xpath("//div[@id='drillDownDiv']//div[@class='hScroller']//table[@id='drillDownTable']/tbody/tr")).size();
		System.out.println("accountcount------------------>"+accountcount+"-----total---------------->"+total);
		if(accountcount==total){
			return true;
		}
		return false;
	}

	public void clickonGroupTab() {

		System.out.println("I am  in the clickonGroupTab-------");
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='tabs1']//a[@id='terrTab' and contains(text(),'Groups')]");
		waitFor(3000).milliseconds();
		groupsTab.waitUntilClickable();
		JavascriptExecutor executor = (JavascriptExecutor)getDriver();
		executor.executeScript("arguments[0].click();", groupsTab);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), groupTableXpath);

	}

	public void clickAddGroupsbutton() {
		// TODO Auto-generated method stub
		System.out.println("I am in the clickAddGroupsbutton-------");
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='tab3']//input[@value='Add Groups']");
		JavascriptExecutor executor = (JavascriptExecutor)getDriver();
		executor.executeScript("arguments[0].click();", addGroupsbutton);
//		addGroupsbutton.click();
	}

	public void enterGroupName(String groupName) {
		
		System.out.println("I am entering the groupname-------");
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='main']//div[@class='role_group_marginB20']//input[@name='groupName']");
		mygroupName.sendKeys(groupName);
	}

	public void clickgroupSubmitButton() {
		
		groupSubmit.click();
		UIHelper.processalert(getDriver());
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), groupTableXpath);
	}

	public void editsHomebutton() {
		
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='backMiddle']/input[@value='Home']");
		editHome.click();	
	}

	public void removeGroup(String groupName) {
		// TODO Auto-generated method stub
		int rowcnt=getDriver().findElements(By.xpath("//div[@id='div_viewByGroup']//table[@id='terr_valueTable']//tbody//tr")).size();
		
		for (int i = 2; i <=rowcnt; i++) {
			String value=getDriver().findElement(By.xpath(" //div[@id='div_viewByGroup']//table[@id='terr_valueTable']//tbody//tr["+i+"]/td[3]")).getText().trim();
			if(value.contains(groupName)){
				getDriver().findElement(By.xpath(" //div[@id='div_viewByGroup']//table[@id='terr_valueTable']//tbody//tr["+i+"]/td[3]//following-sibling::td[6]/a[contains(text(),'Delete')]")).click();
			}
		}
	}

	public void clickLoggedINUser(String user) {
		getDriver().findElement(By.xpath("//table[@id='srcRecordList']//tr//td[1]/a[contains(text(),'"+user+"')]")).click();
		UIHelper.waitForPageToLoad(getDriver());
		
	}



	public void storeUserRoles() {
		
	userRoles=	getDriver().findElement(By.xpath("//div[@class='widget_form']//table[@class='form_leftMargin']//tr//td[contains(.,'User Roles')]/following-sibling::td[1]")).getText().split("\\n");
	Arrays.sort(userRoles);
	//System.out.println("------------------------888888--------------"+userRoles[0]+"-----"+userRoles[1]);
	}

	public void selectTabandCheckPermission(String checkbox1,String checkbox2,String checkbox3,String checkbox4,String checkbox5){
//		for(String S : userRoles){
//			WebElement clickTab=getDriver().findElement(By.xpath("//table[@class='rp_mainborder_outer']//tr//td//a[contains(.,'"+S+"')]"));
//			System.out.println("i am here------------------------------");
//			clickTab.click();
//			verifyCheckbox(checkbox1);
//			verifyCheckbox(checkbox2);
//			verifyCheckbox(checkbox3);
//			verifyCheckbox(checkbox4);
//			verifyCheckbox(checkbox5);
//			getDriver().findElement(By.xpath("//*[@id='role_permission_main']/div[@class='rightAlign ad_marT15']/input[@value='Submit']")).click();
//		}
		UIHelper.waitForPageToLoad(getDriver());
		WebElement clickTab=getDriver().findElement(By.xpath("//table[@class='rp_mainborder_outer']//tr//td//a[contains(.,'Admin')]"));
		System.out.println("i am here------------------------------");
		clickTab.click();
		verifyCheckbox(checkbox1);
		verifyCheckbox(checkbox2);
		verifyCheckbox(checkbox3);
		verifyCheckbox(checkbox4);
		verifyCheckbox(checkbox5);
		getDriver().findElement(By.xpath("//*[@id='role_permission_main']/div[@class='rightAlign ad_marT15']/input[@value='Submit']")).click();
		
	}
	public void disableTabandCheckPermission(String checkbox1,String checkbox2,String checkbox3,String checkbox4,String checkbox5){
//		for(String S : userRoles){
//			WebElement clickTab=getDriver().findElement(By.xpath("//table[@class='rp_mainborder_outer']//tr//td//a[contains(.,'"+S+"')]"));
//			clickTab.click();
//			
//			verifydisableCheckbox(checkbox1);
//			verifydisableCheckbox(checkbox2);
//			verifydisableCheckbox(checkbox3);
//			verifydisableCheckbox(checkbox4);
//			verifydisableCheckbox(checkbox5);
//			waitFor(5000).milliseconds();
//			getDriver().findElement(By.xpath("//*[@id='role_permission_main']/div[@class='rightAlign ad_marT15']/input[@value='Submit']")).click();	
//		
//		}
		
		UIHelper.waitForPageToLoad(getDriver());
		WebElement clickTab=getDriver().findElement(By.xpath("//table[@class='rp_mainborder_outer']//tr//td//a[contains(.,'Admin')]"));
		System.out.println("i am here------------------------------");
		clickTab.click();
		verifydisableCheckbox(checkbox1);
		verifydisableCheckbox(checkbox2);
		verifydisableCheckbox(checkbox3);
		verifydisableCheckbox(checkbox4);
		verifydisableCheckbox(checkbox5);
		waitFor(5000).milliseconds();
		getDriver().findElement(By.xpath("//*[@id='role_permission_main']/div[@class='rightAlign ad_marT15']/input[@value='Submit']")).click();	
	}
	
	
public void verifyCheckbox(String CheckboxName){
	if((getDriver().findElement(By.xpath("//*[@class='RowGray']//label[contains(.,'"+CheckboxName+"')]//ancestor::td[1]//preceding-sibling::td[1]//input[@type='checkbox']"))).isDisplayed()){
		WebElement checkbox=getDriver().findElement(By.xpath("//*[@class='RowGray']//label[contains(.,'"+CheckboxName+"')]//ancestor::td[1]//preceding-sibling::td[1]//input[@type='checkbox']"));
		if(!checkbox.isSelected()){
			checkbox.click();
			verifyRolecheck=1;
		}
		verifyRolecheck=2;
	}
	
}
	
/*	public void verifyCheckbox(String CheckboxName){
	String  abc="//*[@class='RowGray']//label[contains(.,'bdd')]";
	abc=abc.replace("bdd", CheckboxName);
//	WebElementFacade ele=find(By.xpath(abc));
	System.out.println("00000000000000000");
	if((find(By.xpath(abc))).isPresent()){
//		UIHelper.highlightElement(getDriver(), ele);
		WebElement checkbox=getDriver().findElement(By.xpath("//*[@class='RowGray']//label[contains(.,'"+CheckboxName+"')]//ancestor::td[1]//preceding-sibling::td[1]//input[@type='checkbox']"));
//		WebElementFacade eleme=find(By.xpath("//ancestor::td[1]//preceding-sibling::td[1]//input[@type='checkbox']"));
		System.out.println("1111111111111100000000000000000");
		UIHelper.highlightElement(getDriver(), checkbox);
		if(!checkbox.isSelected()){
			checkbox.click();
			verifyRolecheck=1;
		}
		verifyRolecheck=2;
	}
	else{
		System.out.println("element is not displayed------");
	}
	
}*/
	

public void verifydisableCheckbox(String CheckboxName){
	
	if((getDriver().findElement(By.xpath("//*[@class='RowGray']//label[contains(.,'"+CheckboxName+"')]//ancestor::td[1]//preceding-sibling::td[1]//input[@type='checkbox']"))).isDisplayed()){
		WebElement checkbox=getDriver().findElement(By.xpath("//*[@class='RowGray']//label[contains(.,'"+CheckboxName+"')]//ancestor::td[1]//preceding-sibling::td[1]//input[@type='checkbox']"));
		if(checkbox.isSelected()){
			checkbox.click();
			isChangesDone=true;
			waitFor(30000).milliseconds();
			
		}
		
	}
	
}


	public void clickonRolesTab() {
		waitFor(10000).milliseconds();
		UIHelper.highlightElement(getDriver(), roleTab);
		roleTab.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), rolesTableXpath);
	}

	public void clicksetRolesPermissions() {
		// TODO Auto-generated method stub
		UIHelper.highlightElement(getDriver(), setRolePermissions);
		setRolePermissions.click();
	}

	
	public boolean isAllAccountsTabVisible() {
		
		if(getDriver().findElement(By.xpath("//div[@class='tab_div']//a[@id='inbox_preference_all' and contains(.,'All Accounts')]")).isDisplayed()) {
			return true;
		}
		return false;
	}
	
public boolean isAllAccountsTabNotVisible() {
//	WebElement element=getDriver().findElement(By.xpath("//div[@class='tab_div']//a[@id='inbox_preference_all' and contains(.,'All Accounts')]"));
//		boolean value=getDriver().findElement(By.xpath("//div[@class='tab_div']//a[@id='inbox_preference_all' and contains(.,'All Accounts')]")).isDisplayed();
		System.out.println("boolean value--------"+allApplications.isPresent());
//		if(!value) {
	if(!allAccountsTab.isPresent()) {
			return true;
		}
		return false;
	}
	

	public boolean isAllApplicationTabVisible() {
		
		if(allApplications.isDisplayed()) {
			return true;
		}
		return false;
	}

	public boolean isfraudRiskboxVisible() {
	
//	WebElement fraudRiskbox=getDriver().findElement(By.xpath("//div[@id='fraud_box']"));
		boolean value=fraudRiskbox.isPresent();
		return value;
	}

	public void checkandverifyfraudRiskboxVisible() {
		// TODO Auto-generated method stub
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", foldervalue);
		foldervalue.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), foldervalue);
		int i=Integer.parseInt(foldervalue.getText().trim());

		if(i>0){
			buttonSearch.waitUntilClickable();
			UIHelper.highlightElement(getDriver(), buttonSearch);
			buttonSearch.click();
			UIHelper.waitForPageToLoad(getDriver());
			isfraudRiskboxVisible();	
		}
		else if(i==0){
			isfraudRiskboxVisible();		
		}
		
	}

	public void isDunsliveReportPresent() {
		// TODO Auto-generated method stub
		int size=getDriver().findElements(By.xpath("//div[@id='main']//table[@class='results full']/tbody//tr")).size();
		System.out.println("I am in the  size-------------------------"+size);
		for (int i = 1; i <= size; i++) {
			String text=getDriver().findElement(By.xpath("//div[@id='main']//table[@class='results full']/tbody//tr["+i+"]//td/span/a")).getText().trim();
			if(text.contains("D&B Live Report")){
				System.out.println("I am in the  if condintion----------------");
				getDriver().findElement(By.xpath("//div[@id='main']//table[@class='results full']/tbody//tr["+i+"]//td/span/a[contains(.,'D&B Live Report')]")).click();
				break;
			}
			System.out.println("I am in the  if condintion--------2--------");
//			getDriver().findElement(By.xpath("//div[@id='main']//table[@class='results full']/tbody//tr["+i+"]//td/span/a[contains(.,'D&B Live Report')]")).click();
//			break;
		}
		//div[@id='main']//table[@class='results full']/tbody//tr[2]//td/span/a[contains(.,'D&B Live Report')]	
		waitFor(5000).milliseconds();
	}

	public boolean isnotAuthorizedmessagePresent() {
	
	String message=	getDriver().findElement(By.xpath("//div[@id='main']/form[@name='searchOrderForm']/div[@class='alert_box']/h3")).getText().trim();
	if(message.contains("Not Authorized")){
		return true;
	}
	return false;
	}

	public void clickAllRadioOptions(String opt1,String opt2,String opt3,String opt4,String opt5) {
		// TODO Auto-generated method stub
		checkAllOPT(opt1);
		checkAllOPT(opt2);
		checkAllOPT(opt3);
		checkAllOPT(opt4);
		checkAllOPT(opt5);
		
	}
	public void checkAllOPT(String s){
		if(!getDriver().findElement(By.xpath("//div[@id='main']/form/div[@class='floatLeft']/strong[contains(.,'"+s+"')]//preceding-sibling::input[1]")).isSelected())
		getDriver().findElement(By.xpath("//div[@id='main']/form/div[@class='floatLeft']/strong[contains(.,'"+s+"')]//preceding-sibling::input[1]")).click();
	}

	public void disableallRadioOptions(String opt1,String opt2,String opt3,String opt4,String opt5) {
		// TODO Auto-generated method stub
		disableAllradioOptions(opt1);
		disableAllradioOptions(opt2);
		disableAllradioOptions(opt3);
		disableAllradioOptions(opt4);
		disableAllradioOptions(opt5);
		
	}
	
	
	public void disableAllradioOptions(String s){
		if(getDriver().findElement(By.xpath("//div[@id='main']/form/div[@class='floatLeft']/strong[contains(.,'"+s+"')]//preceding-sibling::input[1]")).isSelected()){
			getDriver().findElement(By.xpath("//div[@id='main']/form/div[@class='floatLeft']/strong[contains(.,'"+s+"')]//preceding-sibling::input[1]")).click();	
		}
	}

	public void isGroupPresentwithUserzero(String groupname) {
		
		int tabsize=getDriver().findElements(By.xpath("//table[@id='terr_valueTable']//tbody//tr")).size();
		for (int i = 2; i < tabsize; i++) {
			String text=getDriver().findElement(By.xpath("//table[@id='terr_valueTable']/tbody/tr["+i+"]/td[3]")).getText();
			if(text.equalsIgnoreCase(groupname)){
				String value=getDriver().findElement(By.xpath("//table[@id='terr_valueTable']/tbody/tr["+i+"]/td[3]/span")).getText().replace("(", "").replace("(", "");
				if(value.equalsIgnoreCase("0"))
				break;
			}
			
			
		}	
		}


	public void clickUserRadionbuttonGroups() {
		waitFor(5000).milliseconds();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), groupTableXpath);
		WebElementFacade userRadioBtn=find(By.xpath("//div[@id='adminContainer']//div[@id='tab3']//input[@id='viewByGroupUser']"));
		userRadioBtn.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), userRadioBtn);
		userRadioBtn.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), userTableXpath);
		waitFor(300).milliseconds();
	}

	public void clickAssignUserToGroup(String user) {
		
		getDriver().findElement(By.xpath("//*[@id='srcRecordList']/tbody/tr[contains(.,'"+user+"')]/td[5]/a[contains(.,'Assign')]")).click();	
	}
	
	public void clickUnAssignUserToGroup(String user) {
		// TODO Auto-generated method stub
		System.out.println("i am coming------------------------------0");
		getDriver().findElement(By.xpath("//*[@id='srcRecordList']/tbody/tr[contains(.,'"+user+"')]/td[5]/a[contains(.,'Unassign')]")).click();	
	}
	public void AssignUserToGroup(String group, String user) {
		// TODO Auto-generated method stub
		getDriver().switchTo().frame("__modal_iframe_target");
		waitFor(300).milliseconds();
		WebElement el= getDriver().findElement(By.xpath("//select[@id='groupIdList']"));
		Select select= new Select(el);
		select.selectByVisibleText(group);
		UIHelper.highlightElement(getDriver(), assignUserSubmitBtn);
		assignUserSubmitBtn.click();
		//getDriver().findElement(By.xpath("//form[@name='assignUserGroupForm']/div[@class='modal_buttons']/input[@value='Submit']")).click();
		getDriver().switchTo().defaultContent();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), userTableXpath);
		waitFor(3000).milliseconds();
	}

	public void clickOnEditButtonofGroupButton(String group) {
		// TODO Auto-generated method stub
		getDriver().findElement(By.xpath("//table[@id='terr_valueTable']/tbody//tr//td[contains(.,'"+group+"')]//following-sibling::td[6]/a[contains(.,'Edit |')]")).click();
	}

	public boolean VerifyUserExisting(String firstName) {
		
		int size = getDriver().findElements(By.xpath("//div[@id='tab_contents']//table[@id='srcRecordList']//tr")).size();
		System.out.println("table size--------" + size);
		for (int i = 2; i <= size; i++) {
			String value = getDriver().findElement(By.xpath("//div[@id='tab_contents']//table[@id='srcRecordList']//tr["+ i + "]/td[1]/a")).getText().trim();
			System.out.println("table VALUES DISPLAYED--------" + value+"-------------"+firstName);
			if (value.equalsIgnoreCase(firstName)) {
				
				return true;
			}
			
		}
		return false;
		
	}

	public boolean isTotalsSheetsAsUnlimitedDisplaying() {
		// TODO Auto-generated method stub  
		String text=getDriver().findElement(By.xpath("//*[@id='main']//table//tr//td[contains(.,'Number of Seats Allowed:')]/following::td[1]")).getText().trim();
		
		if (text.equalsIgnoreCase("Unlimited")) {
			return true;
			
		}
		return false;
	}

	public void getTotalUserHaveSeats() {
		// TODO Auto-generated method stub
		String text=getDriver().findElement(By.xpath("//*[@id='main']//table//tr//td[contains(.,'Number of Users Assigned to Seats:')]/following::td[1]")).getText().trim();
		totalusers=Integer.parseInt(text);
		System.out.println("totalusers--------"+totalusers);
	}
	

	public boolean compareUserHaveSeats() {
		// TODO Auto-generated method stub
		String value=getDriver().findElement(By.xpath("//div[@id='viewUserHomeDivPagingContainer']//ul//li//strong[2]")).getText().trim();
		
		int nototalusers=Integer.parseInt(value);
		if(nototalusers==totalusers){
			return true;
		}
		return true;
	}

	public void getNumberOfUSandInternationalReportsPulled() {
		// TODO Auto-generated method stub
		
String usReports=getDriver().findElement(By.xpath("//*[@id='main']//table/tbody//tr/td[contains(.,'Number of US Reports Pulled:')]/following::td[1]")).getText().trim();
String intReports=getDriver().findElement(By.xpath("//*[@id='main']//table/tbody//tr/td[contains(.,'Number of International Reports Pulled:')]/following::td[1]")).getText().trim();
		
		nousReports=Integer.parseInt(usReports);
		nointReports=Integer.parseInt(intReports);
	     firstUsReports=nousReports;
		 firstInternationalReports=nointReports;
	
		
		
	}

	public void getsecondNumberOfUSandInternationalReportsPulled() {
		// TODO Auto-generated method stub
		String usReports=getDriver().findElement(By.xpath("//*[@id='main']//table/tbody//tr/td[contains(.,'Number of US Reports Pulled:')]/following::td[1]")).getText().trim();
		String intReports=getDriver().findElement(By.xpath("//*[@id='main']//table/tbody//tr/td[contains(.,'Number of International Reports Pulled:')]/following::td[1]")).getText().trim();
				
		 secondUsReports=Integer.parseInt(usReports);
		 secondInternationalReports=Integer.parseInt(intReports);
	}

	public boolean isPulledReportsIncreased() {
		// TODO Auto-generated method stub
		System.out.println("------------firstUsReports----------"+firstUsReports);
		System.out.println("------secondUsReports-----"+secondUsReports);
		System.out.println("------firstInternationalReports------"+firstInternationalReports);
		System.out.println("-----secondInternationalReports------"+secondInternationalReports);
		if(firstUsReports+1==secondUsReports && firstInternationalReports+1==secondInternationalReports){
			return true;
		}
		return true;
	}
	
public void isGroupPresentwithUser(String groupname, String Options) {
		int groupFlag=0;
		/*int tabsize=getDriver().findElements(By.xpath("//table[@id='terr_valueTable']//tbody//tr")).size();
		for (int i = 2; i < tabsize; i++) {
			String text=getDriver().findElement(By.xpath("//table[@id='terr_valueTable']/tbody/tr["+i+"]/td[3]")).getText();
			
			if(text.contains(groupname)){*/
		String grouptableXpath="//table[@id='terr_valueTable']//tbody/tr[@class='parentRow']/td[3]";
		List<WebElementFacade> groupTableelement=findAll(By.xpath(grouptableXpath));
		for(WebElementFacade groupName: groupTableelement ){
			UIHelper.mouseOveranElement(getDriver(), groupName);
			
			if(groupName.getText().contains(groupname)){
				System.out.println("inside if method------");
				String grouptableEditBtnXpath="//table[@id='terr_valueTable']//tbody//tr/td[3][contains(.,'"+groupname+"')]//following-sibling::td/a[contains(.,'Edit')]";
				WebElementFacade grouptableEditBtnelement=find(By.xpath(grouptableEditBtnXpath));
				UIHelper.highlightElement(getDriver(),grouptableEditBtnelement );
				grouptableEditBtnelement.click();
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),newGroupNametextboxXpath );
				waitFor(2000).milliseconds();
					String [] selectOptions=Options.split(":");
					for(String opt1 : selectOptions){
						checkAllOPT(opt1);
					}
					
				
				
				clickgroupSubmitButton();
				UIHelper.processalert(getDriver());
				groupFlag=1;
				break;
			}else{
				System.out.println("inside if method------");
				groupFlag=2;
			}
			
			
		}
		System.out.println("value returned----"+groupFlag);
		if(groupFlag==2){
			clickAddGroupsbutton();
			enterGroupName(groupname);
			String [] selectOptions=Options.split(":");
			for(String opt1 : selectOptions){
				checkAllOPT(opt1);
			}
			clickgroupSubmitButton();
			UIHelper.processalert(getDriver());
		}
		}

public void createGroupWithOutOptions(String groupname) {
	int groupFlag=0;
	String grouptableXpath="//table[@id='terr_valueTable']//tbody/tr[@class='parentRow']/td[3]";
	List<WebElementFacade> groupTableelement=findAll(By.xpath(grouptableXpath));
	for(WebElementFacade groupName: groupTableelement ){
		UIHelper.mouseOveranElement(getDriver(), groupName);
		
		if(groupName.getText().contains(groupname)){
			
			groupFlag=1;
			break;
		}else{
			
			groupFlag=2;
		}
		
		
	}
	if(groupFlag==2){
		clickAddGroupsbutton();
		enterGroupName(groupname);
		clickgroupSubmitButton();
		UIHelper.processalert(getDriver());
	}
	}
	
	public void select_Roles_User_Radio_Btn(){
		try{
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), rolesTableXpath);
			waitFor(3000).milliseconds();
			roleuserRadioBtn.waitUntilClickable();
			roleuserRadioBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), rolesUserTableXpath);
			waitFor(3000).milliseconds();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void click_View_Permissions(String LoginName){
		String roleUserNamesXpath="//*[@id='tab4']//table[@id='srcRecordList']//tbody//tr//td[3]";
		String viewPermissionslinkXpath="//*[@id='tab4']//table[@id='srcRecordList']//tbody//tr//td[3][contains(.,'"+LoginName+"')]//following-sibling::td/a[contains(.,'View Permissions')]";
		List<WebElementFacade> roleUserNames=findAll(By.xpath(roleUserNamesXpath));
		for(WebElementFacade users:roleUserNames){
			if(users.getText().contains(LoginName)){
				WebElementFacade viewPermissionslinkelement=find(By.xpath(viewPermissionslinkXpath));
				UIHelper.highlightElement(getDriver(), viewPermissionslinkelement);
				viewPermissionslinkelement.click();
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), viewPermissionpageXpath);
				break;
			}
		}
		
	}
	
	public boolean verify_the_user_Permissions(String PermissionHeader, String Permissions){
		int permissionFlag=0;
		String userPermissionsXpath="//*[@id='main']//h3[contains(.,'"+PermissionHeader+"')]//following-sibling::table/tbody/tr/td";
		List<WebElementFacade> userPermissions=findAll(By.xpath(userPermissionsXpath));
		for(WebElementFacade users:userPermissions){
			UIHelper.mouseOveranElement(getDriver(), users);
			if(Permissions.contains(users.getText().trim())){
				permissionFlag=1;
			}else{
				permissionFlag=2;
			}
		}
		if(permissionFlag==1){
			return true;
		}else{
			return false;
		}
	}
	
	public void editGroupPermissions(String groupname) {
		
		int groupFlag=0;
		String grouptableXpath="//table[@id='terr_valueTable']//tbody/tr[@class='parentRow']/td[3]";
		String grouptableEditBtnXpath="//table[@id='terr_valueTable']//tbody//tr/td[3][contains(.,'"+groupname+"')]//following-sibling::td/a[contains(.,'Edit')]";
		List<WebElementFacade> groupTableelement=findAll(By.xpath(grouptableXpath));
		for(WebElementFacade groupName: groupTableelement ){
			if(groupName.getText().contains(groupname)){
				groupFlag=1;
				break;
			}else{
				
				groupFlag=2;
			}
		}
		
		if(groupFlag==1){
			WebElementFacade grouptableEditBtnelement=find(By.xpath(grouptableEditBtnXpath));
			grouptableEditBtnelement.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),newGroupNametextboxXpath );
			waitFor(2000).milliseconds();
			String permissionsCheckboxXpath="//div[@id='main']/form/div[@class='floatLeft']/input";
			List<WebElementFacade> permissionsCheckboxElements=findAll(By.xpath(permissionsCheckboxXpath));
			for(WebElementFacade permCheck : permissionsCheckboxElements){
				if(permCheck.isSelected()){
					permCheck.click();
				}
			}
			clickgroupSubmitButton();
		}
		}
	
	public boolean verify_the_user_Permissions_Not_Exist(String PermissionHeader){
		int permissionFlag=0;
		String userPermissionsXpath="//*[@id='main']//h3";
		List<WebElementFacade> userPermissions=findAll(By.xpath(userPermissionsXpath));
		for(WebElementFacade users:userPermissions){
			UIHelper.mouseOveranElement(getDriver(), users);
			if(users.getText().contains(PermissionHeader)){
				permissionFlag=1;
				break;
			}else{
				permissionFlag=2;
			}
		}
		if(permissionFlag!=1){
			return true;
		}else{
			return false;
		}
	}
	
	 public boolean verify_CountryName_Not_In_List_Admin(String CountryName){
  	   int countryFlag=0;
  	    UIHelper.mouseOveranElement(getDriver(), adminUserCountryField);
  	   String adminuserCountryListXpath="//div[@class='widget_form']/table[@class='form_leftMargin']//select[@name='country']//option";
  	   List<WebElementFacade> adminUserCountryList=findAll(By.xpath(adminuserCountryListXpath));
  	   for(WebElementFacade options: adminUserCountryList){
  		   if(options.getText().trim().equals(CountryName)){
  			
  			   countryFlag=1;
  			   break;
  		   }
  		   else{
  			   countryFlag=2;
  		   }
  	   }
  	   if(countryFlag==1){
  		   return false;
  	   }else{
  		   return true;
  	   }
     }
	 
	 public boolean verify_CountryName__In_List_Admin(String CountryName){
	  	   int countryFlag=0;
	  	  UIHelper.mouseOveranElement(getDriver(), adminUserCountryField);
	  	   String adminuserCountryListXpath="//div[@class='widget_form']/table[@class='form_leftMargin']//select[@name='country']//option";
	  	   List<WebElementFacade> adminUserCountryList=findAll(By.xpath(adminuserCountryListXpath));
	  	   for(WebElementFacade options: adminUserCountryList){
	  		   if(options.getText().trim().equals(CountryName)){
	  			 adminUserCountryField.selectByVisibleText(CountryName);
	  			   countryFlag=1;
	  			   break;
	  		   }
	  		   else{
	  			   countryFlag=2;
	  		   }
	  	   }
	  	   if(countryFlag==1){
	  		   return true;
	  	   }else{
	  		   return false;
	  	   }
	     }
	
	
}