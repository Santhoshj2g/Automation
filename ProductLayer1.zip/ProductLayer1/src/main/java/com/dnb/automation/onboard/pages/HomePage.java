package com.dnb.automation.onboard.pages;

import java.util.List;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

public class HomePage extends PageObject {

   // @FindBy(xpath = "//*[@id='onboard-body']/header/div//*[@id='searchNavButton']")
   // private WebElementFacade searchicon;
    
    @FindBy(id="searchNavButton")
    private WebElementFacade searchicon;
    
    @FindBy(xpath = "//*[@id='onboard-body']//*[@class='mainbody']")
    private WebElementFacade onboardHomeFrm;
    
    @FindBy(xpath = ".//*[@id='searchLink']")
    private WebElementFacade searchLinkEle;

    @FindBy(xpath = ".//*[@id='business']")
    private WebElementFacade businessEle;

    @FindBy(xpath = ".//*[@id='searchBox']")
    private WebElementFacade searchBoxEle;
 @FindBy(xpath = "//*[@id='searchNavButton']")
    private WebElementFacade searchnavbutton;

    @FindBy(xpath = ".//*[@id='confirmationMsgContainer']")
    private WebElementFacade confirMsgContainerEle;

    @FindBy(xpath = ".//*[@id='confirmationCancelBtn']")
    private WebElementFacade donotsavebutton;

 @FindBy(xpath = ".//*[@id='summary_link_id']")
    private WebElementFacade summaryLinkEle;
    
    @FindBy(xpath = ".//*[@id='additionalProducts']")
    private WebElementFacade additionalProductsEle;
    
    @FindBy(xpath = "//*[@id='reportActions'][@class='reportActions dropdown-toggle']")
	private WebElementFacade actionsBtn;
    
    @FindBy(xpath = "//*[@id='showCreateNewCaseLink'][@class='newCaseIcon actionLink showCreateNewCaseLink']")
	private WebElementFacade createNewCaseBtn;
    
    @FindBy(xpath = "//*[@id='confirmationCancelBtn']")
	private WebElementFacade confirmationCancelBtn;
    
    @FindBy(xpath = "//*[@id='caseReference'][@class='mandatory']")
	private WebElementFacade caseReferenceTxtBox;
    
    @FindBy(xpath = "//*[@id='saveCase'][@class='actionBtn']")
	private WebElementFacade saveCaseBtn;
    
    String editCaseManagementCaseloader = "//div[@id='editCaseManagementCase']//img[@class='loader'][contains(@src,'/onboard/resources/5.0.0.8/images/ajax-loader.gif')]";
    
    @FindBy(xpath = "//*[@class='ui-dialog-titlebar-close ui-corner-all']")
	private WebElementFacade caseDialogClsBtn;
    
    @FindBy(xpath = "//*[@id='showEditCaseLink']")
	private WebElementFacade viewandEditCaselink;
    
    @FindBy(xpath = "//*[@id='notes']")
	private WebElementFacade enterNotes;
    
    @FindBy(xpath = "//*[@id='editCase'][@class='actionBtn']")
	private WebElementFacade editCaseBtn;
    
    @FindBy(xpath = "//*[@id='changeCaseLink']")
	private WebElementFacade changeCaseLink;
    
    @FindBy(xpath = "//*/div//form/input[@id='caseInput']")
	private WebElementFacade caseInput;
    
    @FindBy(xpath = "//*/div/form/button[@id='searchCase']")
	private WebElementFacade searchCase;
	
	String Searchwait = "html/body/div[18]/div[2]/div[2]/div/img";
	
	@FindBy(xpath = "//div/table/tbody/tr/td[@class='dataTables_empty']")
	private WebElementFacade searchResultsEmpty;
	
	@FindBy(xpath = "//*[@id='cancel'][@class='actionBtn']")
	private WebElementFacade changeCaseCancelBtn;
	
	@FindBy(xpath = "//div/table[@id='casesResultTable'][@class='searchResults']/tbody")
	private WebElement casesResultTable;
	
	@FindBy(xpath = "//*[@id='selectCase']")
	private WebElement selectCaseBtn;
	
	@FindBy(xpath = "//div[18]/div[2]/div[3]/div[1]/div/div[2]/div[1]/div/div[2]/a[2][@id='casesResultTable_next']")
	private WebElementFacade casesResultTable_next;
	
	@FindBy(xpath = "//div/div/div[2]/div[1]/div[1]/span[@id='currentCaseReference']")
	private WebElement currentCaseReference;
	
	@FindBy(xpath = "//*[@id='setNoCaseLink']")
	private WebElementFacade setNoCaseLink;
	
	@FindBy(xpath = "//div[1]/div[10]/div[2]/div/div[1]/div[1]/ul/li/ul/li[5]/a[@id='showCreateNewCaseLink']")
	private WebElementFacade createNewcaseRptActions;
	
	@FindBy(xpath = "//*[@id='portfolioNavButton']")
	private WebElementFacade portfolioNavButton;
	
	private String portfolioLoad ="//*[@id='reportViewerLoading']/img[contains(@src,'/onboard/resources/images/ajax-loader.gif')]";

    // User navigates to Dash-board page

    public void navigateToHomeTab() {
        try {
            if (additionalProductsEle.isPresent()) {
                if (searchicon.isPresent()) {
                    UIHelper.waitForPageToLoad(getDriver());
                    UIHelper.highlightElement(getDriver(), searchicon);
                    searchicon.click();
                    UIHelper.waitForPageToLoad(getDriver());
                    waitFor(3000).milliseconds();
                    if (confirMsgContainerEle.isPresent()) {
                        donotsavebutton.waitUntilPresent();
                        UIHelper.mouseOverandElementdoubleClick(getDriver(),
                                donotsavebutton);
                        UIHelper.waitForPageToLoad(getDriver());
                        if (donotsavebutton.isPresent()) {
                            UIHelper.mouseOverandElementdoubleClick(
                                    getDriver(), donotsavebutton);
                        }
                    }

                    onboardHomeFrm.waitUntilPresent();
                    businessEle.waitUntilPresent();
                    searchBoxEle.waitUntilPresent();
                    UIHelper.waitForPageToLoad(getDriver());
                }
            } else {
                if (searchicon.isPresent()) {
                    UIHelper.waitForPageToLoad(getDriver());
                }
            }
        } catch (Exception e) {
        	e.printStackTrace();
        }
    }

    public boolean onboardHomePage() {
        if (searchicon.isPresent()) {
            return true;
        }

        else {
            return false;
        }
    }

    public boolean ActionsBtn()
	{
	
		
		if (actionsBtn.isPresent())
		{
			UIHelper.highlightElement(getDriver(), actionsBtn);
			actionsBtn.click();
			return true;
		}
		
		else
		{
			return false;
		}

	}
    
    public void clickCreateaNewCase()
	{
		
		
		
		try{
			if(createNewCaseBtn.isPresent())
			{
				UIHelper.highlightElement(getDriver(), createNewCaseBtn);
				createNewCaseBtn.click();
				if(confirmationCancelBtn.isPresent())
				{
					confirmationCancelBtn.click();
				}
				System.out.println("switched to createacase dialogbox");
			}	
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
			
				
	}
    
    public void enterCaseReferenceName(String caseName)  
	{	
	  
		if(caseReferenceTxtBox.isPresent())
		{
			UIHelper.highlightElement(getDriver(), caseReferenceTxtBox);
			caseReferenceTxtBox.type(caseName);	
			saveCaseBtn.waitUntilEnabled();
			saveCaseBtn.click();				
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), editCaseManagementCaseloader);
		}

	}
    
public boolean verifyCaseRefSuccessMsg() throws InterruptedException
	
	{	
	
	System.out.println("in verification loop");
	
	
		if(caseReferenceTxtBox.isPresent())
		{			
			UIHelper.highlightElement(getDriver(), caseDialogClsBtn);				
			caseDialogClsBtn.click();
			System.out.println("case already available");
			return false;
		}
		
			
			else
				System.out.println("case created successfully");				
				return true;
}

public boolean enterNotes(String notes)
{
	ActionsBtn();    	
	viewandEditCaselink.waitUntilEnabled();
	if(viewandEditCaselink.isPresent())
		UIHelper.highlightElement(getDriver(), viewandEditCaselink);
		viewandEditCaselink.click();   	
	
	if(enterNotes.isPresent())    		
		{
		enterNotes.type(notes);  
		editCaseBtn.waitUntilEnabled();
		UIHelper.highlightElement(getDriver(), editCaseBtn);
		editCaseBtn.click();				
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), editCaseManagementCaseloader);
		return true;      		  
		}
	
	
	else
		return false;
}

public boolean verifyNotesAvail(String notes)
{
	ActionsBtn();    	
	viewandEditCaselink.waitUntilEnabled();
	if(viewandEditCaselink.isPresent())
		viewandEditCaselink.click();
	
	if (enterNotes.getAttribute("value").equals(notes))
	{
		UIHelper.highlightElement(getDriver(), enterNotes);
		if(caseDialogClsBtn.isPresent()){
			UIHelper.highlightElement(getDriver(), caseDialogClsBtn);
			caseDialogClsBtn.click();
		}
		return true;
	}
		    	
	
	else 
		return false;
}

public boolean verifyCaseChangelnk()
{
	return changeCaseLink.isPresent();
}

public boolean searchCaseRefNametoChange(String changeToCaseRef) throws InterruptedException
{
	UIHelper.highlightElement(getDriver(), changeCaseLink);
	changeCaseLink.click();
	caseInput.type(changeToCaseRef);
	searchCase.submit();
	UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), Searchwait);		
	
	//if no search results are available
	if(searchResultsEmpty.isPresent())
	{
		UIHelper.highlightElement(getDriver(), searchResultsEmpty);
		System.out.println("Case Reference(s) do not exist");			
		UIHelper.highlightElement(getDriver(), changeCaseCancelBtn);
		changeCaseCancelBtn.click();
		return false;
		
	}
	
	//search for case from cases table
	else		
	search:
		do
		{			
			List <WebElement> row = casesResultTable.findElements(By.tagName("tr"));				
	        int row_count =  row.size();        
	        System.out.println("row count is " + row_count);
	        
	      
	        for (int i=0; i<row_count; i++)
	        {
	        	List <WebElement> col = row.get(i).findElements(By.tagName("td"));	        	  	        	
	            System.out.println("case name is : " + col.get(1).getText() + "  link is :" + i ); 	           
	            
	            if(col.get(1).getText().equalsIgnoreCase(changeToCaseRef)){
	            	System.out.println("case found and clicking link" + i);	            	
	            	i++;
	            	WebElement caseSelectRadioButton = getDriver().findElement(By.xpath("//div/table/tbody/tr["+i+"]/td[1]/input[@class='caseSelectRadioButton']"));	   	
	            	UIHelper.highlightElement(getDriver(), caseSelectRadioButton);
	            	caseSelectRadioButton.click();	
	            	Thread.sleep(3000);
	            	UIHelper.highlightElement(getDriver(), selectCaseBtn);
	            	selectCaseBtn.click();
	            	Thread.sleep(3000);
	            	break search;
	            }	

	        } 
	        UIHelper.highlightElement(getDriver(), casesResultTable_next);
	        casesResultTable_next.click();	        
		}
	        while(casesResultTable_next.isPresent());
	return true;
	

	}

public boolean verifyCaseRefChange(String changeToCaseRef){
	
	if(currentCaseReference.getText().equalsIgnoreCase(changeToCaseRef))
	{
		UIHelper.highlightElement(getDriver(), currentCaseReference);
		return true;
	}
		
		else
		{
			return false;
		}
	
}

public boolean setNocaseRef()
{
	if(setNoCaseLink.isPresent())
	{
		UIHelper.highlightElement(getDriver(), setNoCaseLink);
		setNoCaseLink.click();
		return true;
	}
	else
		return false;
}

public void verifyCreateaNewCaseRptActions()
{
	try{
		if(createNewcaseRptActions.isPresent())
		{
			UIHelper.highlightElement(getDriver(), createNewcaseRptActions);
			createNewcaseRptActions.click();
			if(confirmationCancelBtn.isPresent())
			{
				confirmationCancelBtn.click();
			}
			
		}	
		
		
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
}

public boolean naviagateToPortfolio()
{
	if(portfolioNavButton.isPresent())
	{
		portfolioNavButton.click();
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), portfolioLoad);    		
		if(confirmationCancelBtn.isPresent())
		{
			UIHelper.highlightElement(getDriver(), confirmationCancelBtn);
			confirmationCancelBtn.click();
		}    		
		return true;
	}
	else 
		return false;
}

}
