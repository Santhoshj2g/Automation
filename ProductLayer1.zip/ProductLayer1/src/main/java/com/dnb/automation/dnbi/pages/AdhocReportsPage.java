package com.dnb.automation.dnbi.pages;


import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.jsoup.Jsoup;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;
import com.itextpdf.text.log.SysoCounter;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

import java.io.FilterInputStream;
import java.io.InputStream;




public class AdhocReportsPage extends PageObject{

	 @FindBy(xpath = "//*[@id='header_mainApp']//*[@id='primaryNav']//*[contains(text(),'Account Manager')]")
	 private WebElementFacade accountManagerTab;

	 @FindBy(xpath="//div[@id='widget_container']//input[@class='btn wid_creatrep']")
	 private WebElementFacade createReportBtn;

	 @FindBy(xpath="//ul[@id='select_report']//input[contains(@value,'TABULAR')]")
	 private WebElementFacade selectTabularReport;

	 @FindBy(xpath="//ul[@id='select_report']//input[@value='SUMMARY']")
	 private WebElementFacade selectSummaryReport;

	 @FindBy(xpath="//ul[@id='select_report']//input[@value='SUMMARY_DRILLDOWN']")
	 private WebElementFacade selectSummaryReportDrillDown;

	 @FindBy(xpath="//form[@name='customReportForm']//input[@class='btn btnPrimary']")
	 private WebElementFacade NEXT;

	 @FindBy(xpath="//div[@class='report_widget widget_form']//select[@name='selectedCategory']")
	 private WebElementFacade selectCategory;

	 @FindBy(xpath="//div[@id='vars']//select[@id='pool']")
	 private WebElementFacade addVariables;

	 @FindBy(xpath="//img[@src='/dnbi/skins/credit/us/images/img_ico/arrow_right_blue_add.gif']")
	 private WebElementFacade clickAddVariables;

	 @FindBy(xpath="//div[@id='backRight']//input[@value='Next >']")
	 private WebElementFacade clickNEXTVariables;

	 @FindBy(xpath="//table[@class='results customBorder']//select[@id='SORT_NAME_0']")
	 private WebElementFacade sortByFilter;

	 @FindBy(xpath="//div[@id='reportArea_mainMill']//input[@value='Next >']")
	 private WebElementFacade sortNEXT;

	 @FindBy(xpath="//ul[@class='save_report']//input[@name='reportName']")
	 private WebElementFacade ReportNameXpath;

	 @FindBy(xpath="//input[@id='savereport']")
	 private WebElementFacade saveReport;

	 @FindBy(xpath="//div[@id='widget_container']//a[@id='saveTemplates']")
	 private WebElementFacade savedTemplates;

	 @FindBy(xpath="//div[@id='widget_container']//a[@id='generatedTab']")
	 private WebElementFacade completedReports;

	 @FindBy(xpath="//div[@class='reports_backRight']//input[@value='Next >']")
	 private WebElementFacade groupNEXT;

	 @FindBy(xpath="//img[@src='/dnbi/skins/credit/us/images/img_ico/arrow_right_blue_add.gif']")
	 private WebElementFacade addSummaryVariable;

	 @FindBy(xpath="//div[@id='reportArea_main']//input[@value='Next >']")
	 private WebElementFacade clickSummaryNEXT;

	 @FindBy(xpath="//*[@id='sumFunction[0]']")
	 private WebElementFacade sumFirstVariable;

	 @FindBy(xpath="//div[@class='reportArea_inside marLR0']//input[@id='sumFunction[0]']")
	 private WebElementFacade sumFirstVar;

	 @FindBy(xpath="//div[@class='reportArea_inside marLR0']//input[@id='sumFunction[1]']")
	 private WebElementFacade sumSecondVar;

	 @FindBy(xpath="//div[@class='reportArea_inside marLR0']//input[@id='sumFunction[2]']")
	 private WebElementFacade sumThirdVar;

	 @FindBy(xpath="//div[@class='reportArea_inside marLR0']//input[@id='sumFunction[3]']")
	 private WebElementFacade sumForthVar;

	 @FindBy(xpath="//div[@class='reportArea_inside marLR0']//input[@id='avgFunction[0]']")
	 private WebElementFacade avgFirstVar;

	 @FindBy(xpath="//div[@class='reportArea_inside marLR0']//input[@id='avgFunction[1]']")
	 private WebElementFacade avgSecondVar;

	 @FindBy(xpath="//div[@class='reportArea_inside marLR0']//input[@id='avgFunction[2]']")
	 private WebElementFacade avgThirdVar;

	 @FindBy(xpath="//div[@class='reportArea_inside marLR0']//input[@id='avgFunction[3]']")
	 private WebElementFacade avgForthVar;

	 @FindBy(xpath="//div[@class='reportArea_inside marLR0']//input[@id='minFunction[0]']")
	 private WebElementFacade minFirstVar;

	 @FindBy(xpath="//div[@class='reportArea_inside marLR0']//input[@id='minFunction[1]']")
	 private WebElementFacade minSecondVar;

	 @FindBy(xpath="//div[@class='reportArea_inside marLR0']//input[@id='minFunction[2]']")
	 private WebElementFacade minThirdVar;

	 @FindBy(xpath="//div[@class='reportArea_inside marLR0']//input[@id='minFunction[3]']")
	 private WebElementFacade minForthVar;

	 @FindBy(xpath="//div[@class='reportArea_inside marLR0']//input[@id='maxFunction[0]']")
	 private WebElementFacade maxFirstVar;

	 @FindBy(xpath="//div[@class='reportArea_inside marLR0']//input[@id='maxFunction[1]']")
	 private WebElementFacade maxSecondVar;

	 @FindBy(xpath="//div[@class='reportArea_inside marLR0']//input[@id='maxFunction[2]']")
	 private WebElementFacade maxThirdVar;

	 @FindBy(xpath="//div[@class='reportArea_inside marLR0']//input[@id='maxFunction[3]']")
	 private WebElementFacade maxForthVar;

	 @FindBy(xpath="//*[@id='sumFunction[1]']")
	 private WebElementFacade sumSecondVariable;

	 @FindBy(xpath="//*[@id='sumFunction[2]']")
	 private WebElementFacade sumThirdVariable;

	 @FindBy(xpath="//div[@id='page_modal']//input[@value='Download']")
	 private WebElementFacade downloadBtn;

	 @FindBy(xpath="//div[@id='backRight']//input[@value='Next >']")
	 private WebElementFacade summaryNEXT;

	 @FindBy(xpath="//div[@id='widget_container']//input[@value='Create Cross Tab Report']")
	 private WebElementFacade createCrossTabButton;

	 @FindBy(xpath="//form[@name='crossTabAnalysisForm']//input[@id='reportName']")
	 private WebElementFacade crossTabReportName;

	 @FindBy(xpath="//input[@type='radio' and @value='PUBLIC']")
	 private WebElementFacade publicRadioButton;

	 @FindBy(xpath="//input[@type='radio' and @value='PRIVATE']")
	 private WebElementFacade privateRadioButton;

	 @FindBy(xpath="//div[@id='viewOptId']//input[@value='SUM']")
	 private WebElementFacade sumRadioButton;

	 @FindBy(xpath="//div[@id='viewOptId']//input[@value='PERCENTAGE']")
	 private WebElementFacade percentageRadioButton;

	 @FindBy(xpath="//div[@id='viewOptId']//input[@value='AVG']")
	 private WebElementFacade averageRadioButton;

	 @FindBy(xpath="//input[@id='high' and @name='priority']")
	 private WebElementFacade highRadioButton;

	 @FindBy(xpath="//input[@id='normal' and @name='priority']")
	 private WebElementFacade normalRadioButton;

	 @FindBy(xpath="//div[@class='report_intend marTminus15 clear']//input[@name='SaveRun']")
	 private WebElementFacade saveCrossTabReport;

	 @FindBy(xpath="//div[@id='widget_container']//input[@value='Create Exposure Report']")
	 private WebElementFacade createExposureReport;

	 @FindBy(xpath="//form[@name='exposureRollUpReportLayoutForm']//input[@id='reportName']")
	 private WebElementFacade exposureReportName;

	 @FindBy(xpath="//input[@id='globalDunsNumber']")
	 private WebElementFacade globalUltimateDUNSNumber;

	 @FindBy(xpath="//input[@id='HDunsNumber']")
	 private WebElementFacade HQDUNSNumber;

	 @FindBy(xpath="//input[@id='NationalAcctNumber']")
	 private WebElementFacade nationalAccountNumber;

	 @FindBy(xpath="//input[@id='expSummary']")
	 private WebElementFacade summaryRollupType;

	 @FindBy(xpath="//input[@id='expDetailed']")
	 private WebElementFacade detailedRollupType;

	 @FindBy(xpath="//input[@id='BusinessName']")
	 private WebElementFacade exposureBusinessName;

	 @FindBy(xpath="//input[@id='Outstanding']")
	 private WebElementFacade exposureTotalOutstanding;

	 @FindBy(xpath="//input[@name='Save']")
	 private WebElementFacade saveExposureReport;

	 @FindBy(xpath="//*[@id='main']//input[@value='Create New']")
	 private WebElementFacade createNewTemplate;

	 @FindBy(xpath="//input[@name='dataTemplateName']")
	 private WebElementFacade newTemplateName;

	 @FindBy(xpath="//img[@id='addToTemp']")
	 private WebElementFacade addIconTemplateVaraible;

	 @FindBy(xpath="//input[@id='editSave']")
	 private WebElementFacade saveColumnTemplate;

	 @FindBy(xpath="//span[@id='columnTempSelect']//select[@id='dataTemplateId']")
	 private WebElementFacade selectColumnTemplate;

	 @FindBy(xpath="//div[@class='filter_widget_form']//input[@value='Create New']")
	 private WebElementFacade createNewFilterBtn;

	 @FindBy(xpath="//div[@class='filter_widget_form']//select[@id='filterName']")
	 private WebElementFacade availableFilterNames;

	 @FindBy(xpath="//div[@id='main']//input[@id='filter_name']")
	 private WebElementFacade writeFilterName;

	 @FindBy(xpath="//div[@id='main']//img[@id='addDataFieldsAnd']")
	 private WebElementFacade filterADDCondition;

	 @FindBy(xpath="//div[@class='floatRight filt_btnWrapperTopPadding']//input[@name='Submit']")
	 private WebElementFacade saveFilter;

	 @FindBy(xpath="//div[@id='main']//img[@class='remove']")
	 private WebElementFacade removeVariableName;

	 @FindBy(xpath="//div[@id='editDataTemplate']//input[@id='usagePublic']")
	 private WebElementFacade publicUsageNewTemplate;

	 @FindBy(xpath="//div[@id='editDataTemplate']//input[@id='usagePrivate']")
	 private WebElementFacade privateUsageNewTemplate;

	 @FindBy(xpath="//div[@class='floatRight']//input[@value='Next >']")
	 private WebElementFacade clickHighNEXT;
	 
	 @FindBy(xpath="//div[@class='filter_widget_form']//input[@value='Pre-Count Filter Results']")
	 private WebElementFacade preCountFilterBtn;

	 @FindBy(xpath="//div[@id='header_mainApp']//a[@href='/dnbi/coreAdmin/dispatchAdminHome']")
	 private WebElementFacade clickAdminTab;

	 @FindBy(xpath="//div[@class='ecf_page ad_wid750']//a[@href='/dnbi/coreAdmin/showUserHomeByUsers?tabToOpen=fullListTab']")
	 private WebElementFacade administerUserBtn;

	 @FindBy(xpath="//a[@id='terrMgrTab']")
	 private WebElementFacade territoriesTab;

	 @FindBy(xpath="//input[@id='enableCheckId']")
	 private WebElementFacade enableTerritories;

	 @FindBy(xpath="//input[@value='Create New Territory']")
	 private WebElementFacade createNewTerritoryBtn;

	 @FindBy(xpath="//input[@id='territory_name']")
	 private WebElementFacade writeTerritoryName;

	 @FindBy(xpath="//div[@class='filt_leftWrapper']//select[@id='data_fields']")
	 private WebElementFacade availableVariableTerritories;

	 @FindBy(xpath="//div[@class='filt_btnWrapper']//img[@id='addDataFieldsAnd']")
	 private WebElementFacade addVariablesTerritories;

	 @FindBy(xpath="//input[@id='form_submit']")
	 private WebElementFacade saveTerritories;

	 @FindBy(xpath="//input[@id='fieldInfoBean1_operand1']")
	 private WebElementFacade enterStateName;
	 
	 @FindBy(xpath="//body[@class='iframe_modal']//input[@id='preCountResultBtn']")
	 private WebElementFacade preCountFilterModalOKBtn;
	 
	 @FindBy(xpath="//body[@class='iframe_modal']//div[@id='filt_modalContent1']//div[@id='widget_container1']")
	 private WebElementFacade totalPreCountFilterRecords;

	 public String getExposureReportName;
	 public String getStatus;
	 private String strDate;
	 private String HMS;

	 private int totalPreCountFilterRecord;

	 public void clickCreateReportBtn(){

		 UIHelper.waitForPageToLoad(getDriver());
		 createReportBtn.waitUntilClickable();
		 createReportBtn.click();

	 }

	 public void clickTabularReport(){
		 UIHelper.waitForPageToLoad(getDriver());
		 selectTabularReport.waitUntilClickable();
		 selectTabularReport.click();
		 }

	 public void clickSummaryReport(){

			 UIHelper.waitForPageToLoad(getDriver());
			 selectSummaryReport.waitUntilClickable();
			 selectSummaryReport.click();
	
	 }

	 public void clickSummaryReportDrillDown(){

			 UIHelper.waitForPageToLoad(getDriver());
			 selectSummaryReportDrillDown.waitUntilClickable();
			 selectSummaryReportDrillDown.click();


	 }

	 public void clickNEXTbtn(){

			 UIHelper.waitForPageToLoad(getDriver());
			 NEXT.waitUntilClickable();
			 NEXT.click();

	 }

	 public void clickHighNEXT(){
		 UIHelper.waitForPageToLoad(getDriver());
		 clickHighNEXT.waitUntilClickable();
		 clickHighNEXT.click();
	 }

	 public void selectCategoryVariables(String category, String variableName1, String variableName2, String variableName3, String variableName4, String variableName5) throws InterruptedException{
		 try{
		 UIHelper.waitForPageToLoad(getDriver());
		 Select selectCategory = new Select(getDriver().findElement(By.xpath("//div[@class='report_widget widget_form']//select[@name='selectedCategory']")));
		 selectCategory.selectByVisibleText(category);
		 Select addVariables = new Select(getDriver().findElement(By.xpath("//div[@id='vars']//select[@id='pool']")));
		 addVariables.selectByVisibleText(variableName1);
		 addVariables.selectByVisibleText(variableName2);
		 addVariables.selectByVisibleText(variableName3);
		 addVariables.selectByVisibleText(variableName4);
		 addVariables.selectByVisibleText(variableName5);
		 Thread.sleep(3000);
		 clickAddVariables.click();
		 clickNEXTVariables.click();
		 Thread.sleep(5000);
		 }catch(Exception e)
		 {
			 e.printStackTrace();
		 }
		 
	 }
	 public void selectCategoryVariables2(String category, String variableName1){

		 if (variableName1.contains(":")) {
				String[] fieldsList = variableName1.split(":");
				for (String fieldname : fieldsList) {
					String fieldnameXpath = "//*[@id='fields']//*[@id='pool']//option[contains(.,'"+fieldname+"')]";
					WebElementFacade fieldnameEle = find(By.xpath(fieldnameXpath));
					fieldnameEle.click();
					waitFor(1000).milliseconds();
					clickAddVariables.click();
				}
			} else {
				List<WebElement> optionlist = getDriver().findElements(
						By.xpath("//*[@id='fields']//*[@id='pool']//option"));
				for (WebElement getoption : optionlist) {
					if (getoption.getText().equals(variableName1)) {
						/*
						 * String fieldnameXpath =
						 * "//*[@id='main']//*[@id='data_fields']//option[.='" +
						 * Fields + "']"; WebElementFacade fieldnameEle =
						 * find(By.xpath(fieldnameXpath));
						 */
						getoption.click();
						waitFor(1000).milliseconds();
						clickAddVariables.click();
					}
				}
			}
		 clickNEXTVariables.click();
	 }

	 public void selectMaximumCategoryVariables(String category, String variableName1, String variableName2, String variableName3, String variableName4, String variableName5,String variableName6, String variableName7, String variableName8, String variableName9, String variableName10) throws InterruptedException{
		 try{
		 UIHelper.waitForPageToLoad(getDriver());
		 Select selectCategory = new Select(getDriver().findElement(By.xpath("//div[@class='report_widget widget_form']//select[@name='selectedCategory']")));
		 selectCategory.selectByVisibleText(category);
		 Select addVariables = new Select(getDriver().findElement(By.xpath("//div[@id='vars']//select[@id='pool']")));
		 addVariables.selectByVisibleText(variableName1);
		 addVariables.selectByVisibleText(variableName2);
		 addVariables.selectByVisibleText(variableName3);
		 addVariables.selectByVisibleText(variableName4);
		 addVariables.selectByVisibleText(variableName5);
		 addVariables.selectByVisibleText(variableName6);
		 addVariables.selectByVisibleText(variableName7);
		 addVariables.selectByVisibleText(variableName8);
		 addVariables.selectByVisibleText(variableName9);
		 addVariables.selectByVisibleText(variableName10);
		 Thread.sleep(3000);
		 clickAddVariables.click();
		 clickNEXTVariables.click();
		 Thread.sleep(5000);
		 }catch(Exception e)
		 {
			 e.printStackTrace();
		 }
	 }

	 public void removeAddVariable(String variableName1, String variableName2,String variableName3, String variableName4,String variableName5, String variableNameRemove, String variableNameAdd){
		 try{
			 System.out.println("Into Remove/Add variables:++++++++++++++++");

		 UIHelper.waitForPageToLoad(getDriver());
		 Select selectedCategory = new Select(getDriver().findElement(By.xpath("//div[@id='main']//select[@name='selectedFields']")));
		 System.out.println("Into de select section:++++++++++++++");
		 selectedCategory.deselectByVisibleText(variableName1);
		 selectedCategory.deselectByVisibleText(variableName2);
		 selectedCategory.deselectByVisibleText(variableName3);
		 selectedCategory.deselectByVisibleText(variableName4);
		 selectedCategory.deselectByVisibleText(variableName5);



		 waitFor(5000);

		 selectedCategory.selectByVisibleText(variableNameRemove);
		 waitFor(5000);
		 removeVariableName.click();
		 System.out.println("Removed old variable name for the list:+++++++++++++");
		 waitFor(3000);
		 Select addVariable = new Select(getDriver().findElement(By.xpath("//div[@id='vars']//select[@id='pool']")));
		 addVariable.selectByVisibleText(variableNameAdd);
		 System.out.println("Added new variable to the list:++++++++++++++++++++++");
		 waitFor(3000);
		 clickAddVariables.click();
		 clickNEXTVariables.click();
		 waitFor(5000);
		 UIHelper.processalert(getDriver());
		 //getDriver().switchTo().alert().accept();
		 //getDriver().switchTo().defaultContent();
		 waitFor(5000);
		 System.out.println("Clicked on Alert acceptance:++++++++++++++");
		 }catch(StaleElementReferenceException e){
			 e.printStackTrace();
		 }
	 }

	public void sortFilter(String SortVariable, String sortOrder){
		try{
			UIHelper.waitForPageToLoad(getDriver());
			Select filter = new Select(getDriver().findElement(By.xpath("//table[@class='results customBorder']//select[@id='SORT_NAME_0']")));
			filter.selectByVisibleText(SortVariable);
			Select order = new Select(getDriver().findElement(By.xpath("//table[@class='results customBorder']//select[@id='ASC_OR_DESC0']")));
			if(sortOrder.equals("Ascending")){
				order.selectByIndex(0);
			}
			else
				order.selectByIndex(1);
			Thread.sleep(3000);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void sortFilter2(String SortVariable, String SortVariable2){
		try{
			UIHelper.waitForPageToLoad(getDriver());
			Select filter = new Select(getDriver().findElement(By.xpath("//table[@class='results customBorder']//select[@id='SORT_NAME_0']")));
			filter.selectByVisibleText(SortVariable);
			Select filter2 = new Select(getDriver().findElement(By.xpath("//*[@id='SORT_NAME_3']")));
			filter2.selectByVisibleText(SortVariable2);
			sortNEXT.click();
			Thread.sleep(3000);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	public void saveTemplate(String ReportName, String OutputFormat, String ReportType, String Priority){

		UIHelper.waitForPageToLoad(getDriver());
		ReportNameXpath.clear();
		ReportNameXpath.sendKeys(ReportName);

		//Select the Output Format
		if(OutputFormat.contains("HTML"))
		{
			getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[2]/span/input[1]")).click();
		}
		else if(OutputFormat.contains("PDF")){
			getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[2]/span/input[2]")).click();
		}
		else if(OutputFormat.contains("Excel")){
			getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[2]/span/input[3]")).click();
		}
		else{
			getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[2]/span/input[4]")).click();
		}

		//Specify the report
		List<WebElement> getReportType = getDriver().findElements(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[3]/span/input"));
		for(int i=1;i<=getReportType.size();i++)
		{
			String reportType=getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[3]/span/input[" +i +"]")).getText();
			if(ReportType.equalsIgnoreCase(reportType))
			{
				getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[3]/span/input[" +i +"]")).click();
			}
		}


		//Report Priority
		if(Priority.contains("High"))
			getDriver().findElement(By.xpath("//input[@id='highPriority']")).click();
		else
			getDriver().findElement(By.xpath("//input[@id='normalPriority']")).click();

		//Save Report
		saveReport.waitUntilClickable();
		saveReport.click();


	}


	public void saveEditTemplate(String editReportName, String OutputFormat, String ReportType, String Priority){

		UIHelper.waitForPageToLoad(getDriver());
		ReportNameXpath.clear();
		ReportNameXpath.sendKeys(editReportName);

		//Select the Output Format
		if(OutputFormat.contains("HTML"))
		{
			getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[2]/span/input[1]")).click();
		}
		else if(OutputFormat.contains("PDF")){
			getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[2]/span/input[2]")).click();
		}
		else if(OutputFormat.contains("Excel")){
			getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[2]/span/input[3]")).click();
		}
		else{
			getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[2]/span/input[4]")).click();
		}

		//Specify the report
		List<WebElement> getReportType = getDriver().findElements(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[3]/span/input"));
		for(int i=1;i<=getReportType.size();i++)
		{
			String reportType=getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[3]/span/input[" +i +"]")).getText();
			if(ReportType.equalsIgnoreCase(reportType))
			{
				getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[3]/span/input[" +i +"]")).click();
			}
		}


		//Report Priority
		if(Priority.contains("High"))
			getDriver().findElement(By.xpath("//input[@id='highPriority']")).click();
		else
			getDriver().findElement(By.xpath("//input[@id='normalPriority']")).click();

		//Save Report
		saveReport.waitUntilClickable();
		saveReport.click();

	}


	public void runReport(String ReportName){

		waitFor(3000).milliseconds();
		UIHelper.waitForPageToLoad(getDriver());
		List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr/td[1]"));
		for(int i=1;i<=getReportNames.size();i++)
		{
			String getReportName=getDriver().findElement(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr[" +i +"]/td[1]")).getText();
			System.out.println("All report Names are:++++++++" +getReportName);
			if(getReportName.equalsIgnoreCase(ReportName))
			{
				getDriver().findElement(By.xpath("//div[@id='template_widget_container']/form/table/tbody/tr[" +i +"]/td[7]/a")).click();
				System.out.println("Clicked Run for reportName:+++++" +ReportName);
				waitFor(3000).milliseconds();
			}
		}

	}


	public void runEditReport(String editReportName){

		waitFor(3000).milliseconds();
		UIHelper.waitForPageToLoad(getDriver());

		List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr/td[1]"));
		for(int i=1;i<=getReportNames.size();i++)
		{
			String getReportName=getDriver().findElement(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr[" +i +"]/td[1]")).getText();
			System.out.println("All report Names are:++++++++" +getReportName);
			if(getReportName.equalsIgnoreCase(editReportName))
			{
				getDriver().findElement(By.xpath("//div[@id='template_widget_container']/form/table/tbody/tr[" +i +"]/td[7]/a")).click();
				System.out.println("Clicked Run for reportName:+++++" +editReportName);
				waitFor(3000).milliseconds();
			}
		}

	}

	public String checkStatus(String reportName){

		UIHelper.waitForPageToLoad(getDriver());
		waitFor(3000).milliseconds();
		savedTemplates.click();
		waitFor(5000).milliseconds();
		completedReports.click();
		waitFor(90000).milliseconds();
		completedReports.click();

		List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr/td[1]"));
		for(int i=1;i<=getReportNames.size();i++)
		{
			String getReportName= getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
			System.out.println("All report Name:++++" +getReportName);
			if(getReportName.equalsIgnoreCase(reportName))
			{
				getStatus=getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[7]")).getText();
			}
		}
		System.out.println("Current status:+++++" +getStatus);
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", getStatus);
		return getStatus;
	}

	public String checkEditStatus(String editReportName){
		try{
		UIHelper.waitForPageToLoad(getDriver());
		waitFor(3000).milliseconds();
		savedTemplates.click();
		waitFor(5000).milliseconds();
		completedReports.click();
		waitFor(90000).milliseconds();
		completedReports.click();

		List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr/td[1]"));
		for(int i=1;i<=getReportNames.size();i++)
		{
			String getReportName= getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
			System.out.println("All report Name:++++" +getReportName);
			if(getReportName.equalsIgnoreCase(editReportName))
			{
				getStatus=getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[7]")).getText();
			}
		}
		System.out.println("Current status:+++++" +getStatus);

		}catch(StaleElementReferenceException e)
		{
			e.printStackTrace();
		}
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", getStatus);
		return getStatus;
	}

	public void openReport(String ReportName){

		List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr/td[1]"));
		for(int i=1;i<=getReportNames.size();i++)
		{
			String getReportName= getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
			System.out.println("All report Name:++++" +getReportName);
			if(getReportName.equalsIgnoreCase(ReportName))
			{
				waitFor(6000).milliseconds();
				getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).click();
			}
		}
		waitFor(6000).milliseconds();
	}

	public void openEditReport(String editReportName){
		
		List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr/td[1]"));
		for(int i=1;i<=getReportNames.size();i++)
		{
			String getReportName= getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
			System.out.println("All report Name:++++" +getReportName);
			if(getReportName.equalsIgnoreCase(editReportName))
			{
				getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).click();
			}
		}
		waitFor(6000).milliseconds();
	}

	public void deleteSingleReport(String ReportName){
		List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr/td[1]"));
		for(int i=1;i<=getReportNames.size();i++)
		{
			String getReportName= getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
			System.out.println("All report Name:++++" +getReportName);
			if(getReportName.equalsIgnoreCase(ReportName))
			{
				getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[9]")).click();
				UIHelper.processalert(getDriver());
			}
		}
	}

	public void deleteReport(){
		try{
		UIHelper.waitForPageToLoad(getDriver());
		List<WebElement> deleteReports=getDriver().findElements(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr/td[9]/a"));
		System.out.println("Number of reports displayed:++++++++++++++++" +deleteReports.size());
		if(deleteReports.size()>=1)
		{
			for(int i=1;i<=deleteReports.size();i++){
				UIHelper.waitForPageToLoad(getDriver());
				getDriver().findElement(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[9]/a")).click();
				UIHelper.processalert(getDriver());
				UIHelper.waitForPageToLoad(getDriver());
			}
		}
		waitFor(3000);
		deleteCompletedReports();
		}catch(StaleElementReferenceException e){
			e.printStackTrace();
		}
	}

	public void deleteCompletedReports(){
		try{
		completedReports.click();
		UIHelper.waitForPageToLoad(getDriver());
		List<WebElement> deleteCompletedReports=getDriver().findElements(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr/td[9]/a"));
		System.out.println("Total number of Completed reports:++++++" +deleteCompletedReports.size());
		if(deleteCompletedReports.size()>=1)
		{
		for(int i=1;i<=deleteCompletedReports.size();i++)
		{
			UIHelper.waitForPageToLoad(getDriver());
			getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[9]/a")).click();
			UIHelper.processalert(getDriver());
			UIHelper.waitForPageToLoad(getDriver());
		}
		}
		else
			accountManagerTab.click();
			UIHelper.waitForPageToLoad(getDriver());
		}
		catch(StaleElementReferenceException e){
			e.printStackTrace();
		}

	}
	public void groupInfo(String businessName, String Country, String DBRating)
		{
			UIHelper.waitForPageToLoad(getDriver());
			Select selectGroup1= new Select(getDriver().findElement(By.xpath("//ul[@class='group_report']//select[@name='groupFieldInfoList[0].groupFieldName']")));
			selectGroup1.selectByVisibleText(businessName);
			Select selectGroup2 = new Select(getDriver().findElement(By.xpath("//ul[@class='group_report']//select[@name='groupFieldInfoList[1].groupFieldName']")));
			selectGroup2.selectByVisibleText(Country);
			Select selectGroup3 = new Select(getDriver().findElement(By.xpath("//ul[@class='group_report']//select[@name='groupFieldInfoList[2].groupFieldName']")));
			selectGroup3.selectByVisibleText(DBRating);
			groupNEXT.click();
		}

	public void reportColumns(String selectedCategory, String variableName1, String variableName2, String variableName3,String variableName4)
	{
		Select selectCategory = new Select(getDriver().findElement(By.xpath("//div[@class='report_widget widget_form']//select[@name='selectedCategory']")));
		selectCategory.selectByVisibleText(selectedCategory);

		Select variableNames= new Select(getDriver().findElement(By.xpath("//div[@id='vars']//select[@id='pool']")));
		variableNames.selectByVisibleText(variableName1);
		variableNames.selectByVisibleText(variableName2);
		variableNames.selectByVisibleText(variableName3);
		variableNames.selectByVisibleText(variableName4);
		addSummaryVariable.click();
		clickSummaryNEXT.click();
	}




	public void selectVariableAndFunction(String columnName, String function) {
		if ((getDriver().findElement(By
				.xpath("//*[@class='widget_form']//tbody//tr//td[contains(.,'"
						+ columnName +"')]"))).isDisplayed()) {
			WebElement limitfunction = getDriver()
					.findElement(
							By.xpath("//*[@class='widget_form']//tbody//tr//td[contains(.,'"
									+ columnName
									+ "')]//following-sibling::td//input[contains(@id,'"
									+ function +"')]"));
			limitfunction.click();

		}
	}


	public void clickSummaryNEXT(){
		summaryNEXT.waitUntilClickable();
		summaryNEXT.click();
	}




	public void clickCreateCrossTabReport(){
		UIHelper.waitForPageToLoad(getDriver());
		createCrossTabButton.waitUntilClickable();
		createCrossTabButton.click();
	}

	public void saveCrossTabReport(String ReportName,String usage, String rowData,String ColumnData, String OutputView, String view, String territoryName, String priority,  int reportType){

		UIHelper.waitForPageToLoad(getDriver());
		crossTabReportName.sendKeys(ReportName);
		if(usage.contains("Public"))
			publicRadioButton.click();
		else if(usage.contains("Private"))
			privateRadioButton.click();
		Select selectRowData = new Select(getDriver().findElement(By.xpath("//select[@id ='rowData']")));
		selectRowData.selectByVisibleText(rowData);
		Select selectColumnData = new Select(getDriver().findElement(By.xpath("//select[@id ='columnData']")));
		selectColumnData.selectByVisibleText(ColumnData);
		Select selectOutputView = new Select(getDriver().findElement(By.xpath("//select[@id ='outputView']")));
		selectOutputView.selectByVisibleText(OutputView);
		if(view.contains("SUM"))
			sumRadioButton.click();
		else if(view.contains("PERCENTAGE"))
			percentageRadioButton.click();
		else if(view.contains("AVG"))
			averageRadioButton.click();
		Select selectTerritory = new Select(getDriver().findElement(By.xpath("//table[@id='tabbb']//select[@id='territoryId']")));
		selectTerritory.selectByVisibleText(territoryName);

		if(priority.contains("High"))
			highRadioButton.click();
		else if(priority.contains("Normal"))
			normalRadioButton.click();



		Select outputType = new Select(getDriver().findElement(By.xpath("//*[@id='outputTypeSelect']")));
		outputType.selectByIndex(reportType);
		saveCrossTabReport.click();
		waitFor(2000);
		accountManagerTab.click();

	}

	public void clickCreateExposureReport()
	{
		createExposureReport.waitUntilClickable();
		createExposureReport.click();
	}

	public void createExistingNewTemplate(String templateName, String templateUsage, String templateVariable1, String templateVariable2, String templateVariable3){
		try{
		Thread.sleep(2000);




		System.out.println("Entered filter name is:==-=====------------" +templateName);
		System.out.println("Into checking existing filters or not++++++++++++++++++++++++++++++++++");
		Select selectTemplate= new Select(getDriver().findElement(By.xpath("//div[@class='floatLeft']//select[@id='dataTemplateId']")));


		if(checkExisitingColumnTemplate()){
		List<WebElement> dropDownValues=selectTemplate.getOptions();
		for(int i=0; i<dropDownValues.size();i++){
			waitFor(6000);
			String availableDropDown=dropDownValues.get(i).getText();
			//System.out.println("Drop down in the list are:" +availableDropDown);
			waitFor(5000);
			if(availableDropDown.contains(templateName)){
				selectTemplate.selectByVisibleText(templateName);
				System.out.println("Selected the entered template name+++++" +templateName);
				saveExposureReport.click();
				Thread.sleep(3000);
				accountManagerTab.click();


			}

		}



	    }

			createNewTemplate.waitUntilEnabled();
			createNewTemplate.click();

			getDriver().switchTo().frame("__modal_iframe_target");
			newTemplateName.waitUntilVisible();
			newTemplateName.sendKeys(templateName);

			//Select Priate/Public usage
			if(templateUsage.contains("Public")){
				publicUsageNewTemplate.click();

			}
			else
				privateUsageNewTemplate.click();

			Select selectAvailableVariable = new Select(getDriver().findElement(By.xpath("//select[@id='pool_left']")));
			selectAvailableVariable.selectByVisibleText(templateVariable1);
			selectAvailableVariable.selectByVisibleText(templateVariable2);
			selectAvailableVariable.selectByVisibleText(templateVariable3);

			addIconTemplateVaraible.click();
			saveColumnTemplate.click();
			System.out.println("Saved the template:+++++++++++++++++++++++=");
			waitFor(3000);
			getDriver().switchTo().defaultContent();
			waitFor(3000);
			exposureReportName.clear();
			System.out.println("Report Name:+++++++++++++"+getExposureReportName);
			exposureReportName.sendKeys(getExposureReportName);
			waitFor(3000);
			saveExposureReport.click();
			Thread.sleep(3000);
			accountManagerTab.click();

		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void saveNewTemplate(String templateName, String templateVaraible){
		try{
			SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//dd/MM/yyyy
		    Date now = new Date();
		    strDate = sdfDate.format(now);
		    HMS=strDate.substring(10).replace(":", "");

		Thread.sleep(3000);
		getDriver().switchTo().frame("__modal_iframe_target");
		newTemplateName.waitUntilVisible();
		newTemplateName.sendKeys(templateName+HMS.trim());

		Select selectAvailableVariable = new Select(getDriver().findElement(By.xpath("//select[@id='pool_left']")));
		selectAvailableVariable.selectByVisibleText(templateVaraible);

		addIconTemplateVaraible.click();
		saveColumnTemplate.click();
		Thread.sleep(3000);
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	public void saveExposureReport(String reportName,String Usage,String LinkageType, String RollupType, String SortBy, String Priority, int reportType){
try{
		getDriver().switchTo().defaultContent();
		UIHelper.waitForPageToLoad(getDriver());
		Thread.sleep(3000);
		getExposureReportName=reportName;
		exposureReportName.sendKeys(reportName);
		if(Usage.contains("Public"))
			publicRadioButton.click();
		else if(Usage.contains("Private"))
			privateRadioButton.click();
		if(LinkageType.contains("Global Ultimate D-U-N-S Number"))
			globalUltimateDUNSNumber.click();
		else if(LinkageType.contains("Headquarters D-U-N-S Number"))
			HQDUNSNumber.click();
		else if(LinkageType.contains("National Account Number"))
			nationalAccountNumber.click();

		if(RollupType.contains("Summary"))
			summaryRollupType.click();
		else if(RollupType.contains("Detailed"))
			detailedRollupType.click();

		if(SortBy.contains("Business Name"))
			exposureBusinessName.click();
		else if(SortBy.contains("Total Outstanding"))
			exposureReportName.click();

		if(Priority.contains("High"))
			highRadioButton.click();
		else if(Priority.contains("Normal"))
			normalRadioButton.click();
		Select outputType = new Select(getDriver().findElement(By.xpath("//*[@id='outputTypeSelect']")));
		outputType.selectByIndex(reportType);
		//saveExposureReport.click();
		//Thread.sleep(3000);
		//accountManagerTab.click();
}catch(Exception e){
	e.printStackTrace();
}
	}

	public void deleteReport(String reportName){
		try{
			savedTemplates.waitUntilClickable();
			waitFor(5000);
			savedTemplates.click();
			UIHelper.waitForPageToLoad(getDriver());
			List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr/td[1]"));
			if(getReportNames.size()>=1)
			for(int i=1;i<=getReportNames.size();i++){
				String getReportName=getDriver().findElement(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
				if(getReportName.contains(reportName)){
					getDriver().findElement(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[9]/a")).click();
					UIHelper.processalert(getDriver());
					UIHelper.waitForPageToLoad(getDriver());
					waitFor(3000);
				}
			}

			completedReports.waitUntilClickable();
			completedReports.click();
			UIHelper.waitForPageToLoad(getDriver());
			List<WebElement> getReportNameCompleted=getDriver().findElements(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr/td[1]"));
			if(getReportNameCompleted.size()>=1)
			for(int i=1;i<=getReportNameCompleted.size();i++)
			{
				String getReportName= getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
				if(getReportName.equalsIgnoreCase(reportName))
				{
					getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[9]")).click();
					UIHelper.processalert(getDriver());
					UIHelper.waitForPageToLoad(getDriver());
				}
			}

		}catch(StaleElementReferenceException e){
			e.printStackTrace();
		}
	}


	public void deleteReportEdit(String editReportName){
		try{
			savedTemplates.waitUntilClickable();
			waitFor(5000);
			savedTemplates.click();
			UIHelper.waitForPageToLoad(getDriver());
			List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr/td[1]"));
			if(getReportNames.size()>=1)
			for(int i=1;i<=getReportNames.size();i++){
				String getReportName=getDriver().findElement(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
				if(getReportName.equalsIgnoreCase(editReportName)){
					getDriver().findElement(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[9]/a")).click();
					UIHelper.processalert(getDriver());
					UIHelper.waitForPageToLoad(getDriver());
					waitFor(3000);
				}
			}

			completedReports.waitUntilClickable();
			completedReports.click();
			UIHelper.waitForPageToLoad(getDriver());
			List<WebElement> getReportNameCompleted=getDriver().findElements(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr/td[1]"));
			if(getReportNameCompleted.size()>=1)
			for(int i=1;i<=getReportNameCompleted.size();i++)
			{
				String getReportName= getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
				if(getReportName.equalsIgnoreCase(editReportName))
				{
					getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[9]")).click();
					UIHelper.processalert(getDriver());
					UIHelper.waitForPageToLoad(getDriver());
				}
			}

		}catch(StaleElementReferenceException e){
			e.printStackTrace();
		}
	}

	public void editReport(String reportName){

		savedTemplates.waitUntilClickable();
		waitFor(5000);
		savedTemplates.click();
		UIHelper.waitForPageToLoad(getDriver());
		List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr/td[1]"));
		if(getReportNames.size()>=1)
		for(int i=1;i<=getReportNames.size();i++){
			String getReportName=getDriver().findElement(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
			if(getReportName.equalsIgnoreCase(reportName)){
				getDriver().findElement(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[8]/a")).click();
				System.out.println("Clicked on Edit link. Edit Report Done+++++++++++++++++");
			}
		}

	}

	public void checkDeletedReport(String reportName){
		waitFor(3000);
		savedTemplates.waitUntilClickable();
		savedTemplates.click();
		UIHelper.waitForPageToLoad(getDriver());
		String getReportName="";
		List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr/td[1]"));
		System.out.println("Number of reports displayed:" +getReportNames.size());
		for(int i=1;i<=getReportNames.size();i++){
			UIHelper.waitForPageToLoad(getDriver());
			getReportName=getDriver().findElement(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
			Assert.assertFalse(reportName.contains(getReportName));
		}
	}

	public void runHighReport(String ReportName){

			savedTemplates.waitUntilClickable();
			waitFor(5000);
			savedTemplates.click();

		List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr/td[1]"));
		for(int i=1;i<=getReportNames.size();i++)
		{
			String getReportName=getDriver().findElement(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
			System.out.println("All report Names are:++++++++" +getReportName);
			if(getReportName.equalsIgnoreCase(ReportName))
			{
				waitFor(3000).milliseconds();
				getDriver().findElement(By.xpath("//div[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[7]/a")).click();
				System.out.println("Clicked Run for reportName:+++++" +ReportName);
				waitFor(65000).milliseconds();
				getDriver().switchTo().frame("__modal_iframe_target");
				downloadBtn.waitUntilClickable();
				downloadBtn.click();
				System.out.println("Clicked on Download button++++++++++++++++++++++++++++++");
			}
		}

	}

	public void downloadReport(){
		UIHelper.waitForPageToLoad(getDriver());
		waitFor(5000);
		getDriver().switchTo().frame("__modal_iframe_target");
		downloadBtn.waitUntilClickable();
		downloadBtn.click();
	}

	public void validateVariableSummary(String VariableName1,String VariableName2,String VariableName3, String VariableName4){
try{
		Thread.sleep(90000);
        File file = new File("C:\\Users\\QAAdmin\\Downloads\\report(1).xls");
        FileInputStream fis = new FileInputStream(file);
        HSSFWorkbook wrk = new HSSFWorkbook(fis);
        HSSFSheet ws = wrk.getSheetAt(0);
        HSSFRow row = ws.getRow(2);
        HSSFCell cell1 = row.getCell(4);
        System.out.println(VariableName1);
        String VariableExcel1=cell1.toString();
        System.out.println(VariableExcel1);
        System.out.println(VariableName2);
        HSSFCell cell2 = row.getCell(5);
        String VariableExcel2 = cell2.toString();
        System.out.println(VariableExcel2);
        System.out.println(VariableName3);
        HSSFCell cell3 = row.getCell(6);
        String VariableExcel3 = cell3.toString();

        System.out.println(VariableName4);
        HSSFCell cell4 = row.getCell(7);
        String VariableExcel4 = cell3.toString();
        System.out.println(VariableExcel4);

        Assert.assertEquals("SUM of "+VariableName1, VariableExcel1);
        Assert.assertEquals("SUM of "+VariableName2, VariableExcel2);
        Assert.assertEquals("SUM of "+VariableName3, VariableExcel3);
        Assert.assertEquals("SUM of "+VariableName4, VariableExcel4);
}catch(Exception e){
	e.printStackTrace();
}
	}


	public boolean validateHTMLReport(String variableName1,String variableName2,String variableName3, String variableName4) throws Exception{
		FileReader htmlFilePath = new FileReader("C:\\Users\\selvarajk\\Downloads\\report.htm");
		BufferedReader br = new BufferedReader(htmlFilePath);
		StringBuilder htmlContent = new StringBuilder(1024);
		String s;
		String textOnly = null;
		while((s=br.readLine())!=null){
			htmlContent.append(s);
			textOnly = Jsoup.parse(htmlContent.toString()).text();
		}


		String variable[] ={variableName1,variableName2,variableName3,variableName4};


		String[] sarr =textOnly.split("\\n");

		for (String sa:variable) {
			if(textOnly.contains(sa))
			return true;
		}
		return false;
	}

	public boolean validatePDFReport(String templateVariable1,String templateVariable2,String templateVariable3) throws Exception{
		
		PdfReader reader = new PdfReader("C:\\Users\\selvarajk\\Downloads\\report.pdf");
		int noPage = reader.getNumberOfPages();
		System.out.println("Number of pages are:" +noPage);
		String pdfText=PdfTextExtractor.getTextFromPage(reader, 1);
		System.out.println("*********************************************");
		System.out.println(pdfText);
		String variable[] ={templateVariable1,templateVariable2,templateVariable3};


		for (String sa:variable) {
			if(pdfText.contains(sa))
			return true;
		}
		return false;

	}
	
	
	public boolean validatePDFReportDM(String variableName1,String variableName2,String variableName3, String variableName4) throws Exception{
		
		PdfReader reader = new PdfReader("C:\\Users\\selvarajk\\Downloads\\report.pdf");
		int noPage = reader.getNumberOfPages();
		System.out.println("Number of pages are:" +noPage);
		String pdfText=PdfTextExtractor.getTextFromPage(reader, 1);
		System.out.println("*********************************************");
		System.out.println(pdfText);
		String variable[] ={variableName1,variableName2,variableName3,variableName4};


		for (String sa:variable) {
			if(pdfText.contains(sa))
			return true;
		}
		return false;

	}
	
	public List<String> getAllContectFromPDFDoc(String filePath) throws Exception{
		List<String> pdfContent=new ArrayList<String>();
		PdfReader reader = new PdfReader(filePath);
		int pageCount = reader.getNumberOfPages();
		//System.out.println("Number of pages are:" +pageCount);
		for (int i=1;i<=pageCount;i++){
			pdfContent.add(PdfTextExtractor.getTextFromPage(reader, i));
			//System.out.println("PDF Text content:" +pdfContent);
		}
		return pdfContent;
	}

	public void validateCrossTabReport(String RowData,String ColumnData){
		try{
		Thread.sleep(90000);
        File file = new File("C:\\Users\\selvarajk\\Downloads\\report.xls");
        FileInputStream fis = new FileInputStream(file);
        HSSFWorkbook wrk = new HSSFWorkbook(fis);
        HSSFSheet ws = wrk.getSheetAt(0);
        HSSFRow row = ws.getRow(2);

        HSSFCell cell0 = row.getCell(0);
        String RowDataExcel=cell0.toString();
        System.out.println("Row data in excel is" +RowDataExcel);
        System.out.println("Row data in UI is" +RowData);

        HSSFCell cell1 = row.getCell(1);
        String columnDataExcel = cell1.toString();
        System.out.println("Column data in excel is"+columnDataExcel);
        System.out.println("Column data in UI is" +ColumnData);


        Assert.assertEquals(RowData, RowDataExcel);
        Assert.assertEquals(ColumnData, columnDataExcel);


		}catch(Exception e){
			e.printStackTrace();
		}

	}


	public void validateVariableTabular(String VariableName1,String VariableName2,String VariableName3,String VariableName4,String VariableName5) throws Exception{
		Thread.sleep(90000);
		String splitBy = ",";
		String VariableCSV1;
		String VariableCSV2;
		String VariableCSV3;
		String VariableCSV4;
		String VariableCSV5;
		BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\selvarajk\\Downloads\\report.csv"));
		List<String> lines = new ArrayList<>();
		String line = null;
		while ((line = br.readLine()) !=null) {
			lines.add(line);
		}

		String getColumnRow = lines.get(0);
		br.close();

		String [] columnNames = getColumnRow.split(splitBy);
		VariableCSV1 = columnNames[0];
		VariableCSV2 = columnNames[1];
		VariableCSV3 = columnNames[2];
		VariableCSV4 = columnNames[3];
		VariableCSV5 = columnNames[4];
		System.out.println("Get CSV column values:");
		System.out.println(VariableName1);
		System.out.println(VariableCSV1);
		System.out.println(VariableName2);
		System.out.println(VariableCSV2);
		System.out.println(VariableName3);
		System.out.println(VariableCSV3);
		System.out.println(VariableName4);
		System.out.println(VariableCSV4);
		System.out.println(VariableName5);
		System.out.println(VariableCSV5);
		Assert.assertEquals(VariableName1, VariableCSV1);
		Assert.assertEquals(VariableName2, VariableCSV2);
		Assert.assertEquals(VariableName3, VariableCSV3);
		Assert.assertEquals(VariableName4, VariableCSV4);
		Assert.assertEquals(VariableName5, VariableCSV5);
		}
	public void validateVariableTabular2(String variables) throws Exception{
		Thread.sleep(90000);
		String splitBy = ",";
		if(variables.contains(",")){
			String[] fieldsList = variables.split(":");
			for (String fieldname : fieldsList) {
			for(int i=0;i<=fieldname.length();i++){
		BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\selvarajk\\Downloads\\report.csv"));
		List<String> lines = new ArrayList<>();
		String line = null;
		while ((line = br.readLine()) !=null) {
			lines.add(line);
		}

		String getColumnRow = lines.get(0);
		br.close();

		String [] columnNames = getColumnRow.split(splitBy);
		fieldsList[i] = columnNames[i];
		}
	}
		}
	}
	
		public boolean totalRecordCountCSV() throws Exception{
			InputStream is = new BufferedInputStream(new FileInputStream("C:\\Users\\selvarajk\\Downloads\\report.csv"));
			try {
		        byte[] c = new byte[1024];
		        int count = 0;
		        int readChars = 0;
		        boolean empty = true;
		        while ((readChars = is.read(c)) != -1) {
		            empty = false;
		            for (int i = 0; i < readChars; ++i) {
		                if (c[i] == '\n') {
		                    ++count;
		                }
		            }
		        }
		        System.out.println("Total number of records in CSV file is********************"+count);
		        if(count==totalPreCountFilterRecord){
		        	System.out.println("Count in Pre Count Filter has matched:++++++++++++++" +totalPreCountFilterRecord);
		        	return true;
		        }
		        else{
		        	return false;
		        }
		    } finally {
		        is.close();
		    }
		}
		
		public boolean totalRecordCountExcel() throws Exception{
			Thread.sleep(90000);
	        File file = new File("C:\\Users\\selvarajk\\Downloads\\report.xls");
	        FileInputStream fis = new FileInputStream(file);
	        HSSFWorkbook wrk = new HSSFWorkbook(fis);
	        HSSFSheet ws = wrk.getSheetAt(0);
	        int totalRows=ws.getPhysicalNumberOfRows();
	        System.out.println("Total number of records in excel file***************" +totalRows);
	        if(totalRows==totalPreCountFilterRecord){
	        	return true;
	        }
	        else 
	        	return false;
		}

	public void validateMaximumVariableTabular(String VariableName1,String VariableName2,String VariableName3,String VariableName4,String VariableName5,String VariableName6,String VariableName7,String VariableName8,String VariableName9,String VariableName10) throws Exception{
		Thread.sleep(120000);
		String splitBy = ",";
		String VariableCSV1;
		String VariableCSV2;
		String VariableCSV3;
		String VariableCSV4;
		String VariableCSV5;
		String VariableCSV6;
		String VariableCSV7;
		String VariableCSV8;
		String VariableCSV9;
		String VariableCSV10;
		BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\selvarajk\\Downloads\\report.csv"));
		List<String> lines = new ArrayList<>();
		String line = null;
		while ((line = br.readLine()) !=null) {
			lines.add(line);
		}

		String getColumnRow = lines.get(0);
		br.close();

		String [] columnNames = getColumnRow.split(splitBy);
		VariableCSV1 = columnNames[0];
		VariableCSV2 = columnNames[1];
		VariableCSV3 = columnNames[2];
		VariableCSV4 = columnNames[3];
		VariableCSV5 = columnNames[4];
		VariableCSV6 = columnNames[5];
		VariableCSV7 = columnNames[6];
		VariableCSV8 = columnNames[7];
		VariableCSV9 = columnNames[8];
		VariableCSV10 = columnNames[9];
		System.out.println("Get CSV column values:");
		System.out.println(VariableName1);
		System.out.println(VariableCSV1);
		System.out.println(VariableName2);
		System.out.println(VariableCSV2);
		System.out.println(VariableName3);
		System.out.println(VariableCSV3);
		System.out.println(VariableName4);
		System.out.println(VariableCSV4);
		System.out.println(VariableName5);
		System.out.println(VariableCSV5);
		System.out.println(VariableName5);
		System.out.println(VariableCSV5);
		System.out.println(VariableName6);
		System.out.println(VariableCSV6);
		System.out.println(VariableName7);
		System.out.println(VariableCSV7);
		System.out.println(VariableName8);
		System.out.println(VariableCSV8);
		System.out.println(VariableName9);
		System.out.println(VariableCSV9);
		System.out.println(VariableName10);
		System.out.println(VariableCSV10);
		Assert.assertEquals(VariableName1, VariableCSV1);
		Assert.assertEquals(VariableName2, VariableCSV2);
		Assert.assertEquals(VariableName3, VariableCSV3);
		Assert.assertEquals(VariableName4, VariableCSV4);
		Assert.assertEquals(VariableName5, VariableCSV5);
		Assert.assertEquals(VariableName6, VariableCSV6);
		Assert.assertEquals(VariableName7, VariableCSV7);
		Assert.assertEquals(VariableName8, VariableCSV8);
		Assert.assertEquals(VariableName9, VariableCSV9);
		Assert.assertEquals(VariableName10, VariableCSV10);
		}

	public void validateMaximumVariableTabularDM(String VariableName1,String VariableName2,String VariableName3,String VariableName4,String VariableName5,String VariableName6,String VariableName7,String VariableName8,String VariableName9,String VariableName10) throws Exception{
		Thread.sleep(120000);
		String splitBy = ",";
		String VariableCSV1;
		String VariableCSV2;
		String VariableCSV3;
		String VariableCSV4;
		String VariableCSV5;
		String VariableCSV6;
		String VariableCSV7;
		String VariableCSV8;
		String VariableCSV9;
		String VariableCSV10;
		BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\selvarajk\\Downloads\\report.csv"));
		List<String> lines = new ArrayList<>();
		String line = null;
		while ((line = br.readLine()) !=null) {
			lines.add(line);
		}

		String getColumnRow = lines.get(0);
		br.close();

		String [] columnNames = getColumnRow.split(splitBy);
		VariableCSV1 = columnNames[0];
		VariableCSV2 = columnNames[1];
		VariableCSV3 = columnNames[2];
		VariableCSV4 = columnNames[3];
		VariableCSV5 = columnNames[4];
		VariableCSV6 = columnNames[5];
		VariableCSV7 = columnNames[6];
		VariableCSV8 = columnNames[7];
		VariableCSV9 = columnNames[8];
		VariableCSV10 = columnNames[9];
		System.out.println("Get CSV column values:");
		System.out.println(VariableName1);
		System.out.println(VariableCSV1);
		System.out.println(VariableName2);
		System.out.println(VariableCSV2);
		System.out.println(VariableName3);
		System.out.println(VariableCSV3);
		System.out.println(VariableName4);
		System.out.println(VariableCSV4);
		System.out.println(VariableName5);
		System.out.println(VariableCSV5);
		System.out.println(VariableName5);
		System.out.println(VariableCSV5);
		System.out.println(VariableName6);
		System.out.println(VariableCSV6);
		System.out.println(VariableName7);
		System.out.println(VariableCSV7);
		System.out.println(VariableName8);
		System.out.println(VariableCSV8);
		System.out.println(VariableName9);
		System.out.println(VariableCSV9);
		System.out.println(VariableName10);
		System.out.println(VariableCSV10);
		Assert.assertEquals(VariableName1, VariableCSV1);
		Assert.assertEquals(VariableName2, VariableCSV2);
		Assert.assertEquals(VariableName3, VariableCSV3);
		Assert.assertEquals(VariableName4, VariableCSV4);
		Assert.assertEquals(VariableName5, VariableCSV5);
		Assert.assertEquals(VariableName6, VariableCSV6);
		Assert.assertEquals(VariableName7, VariableCSV7);
		Assert.assertEquals(VariableName8, VariableCSV8);
		Assert.assertEquals(VariableName9, VariableCSV9);
		Assert.assertEquals(VariableName10, VariableCSV10);
		}


	public void validateVariableTabularEdit(String VariableName1,String VariableName2,String VariableName3,String VariableName4,String VariableNameAdd) throws Exception{
		Thread.sleep(90000);
		String splitBy = ",";
		String VariableCSV1;
		String VariableCSV2;
		String VariableCSV3;
		String VariableCSV4;
		String VariableCSV5;
		BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\selvarajk\\Downloads\\report (1).csv"));
		List<String> lines = new ArrayList<>();
		String line = null;
		while ((line = br.readLine()) !=null) {
			lines.add(line);
		}

		String getColumnRow = lines.get(0);
		br.close();

		String [] columnNames = getColumnRow.split(splitBy);
		VariableCSV1 = columnNames[0];
		VariableCSV2 = columnNames[1];
		VariableCSV3 = columnNames[2];
		VariableCSV4 = columnNames[3];
		VariableCSV5 = columnNames[4];
		System.out.println("Get CSV column values:");
		System.out.println(VariableName1);
		System.out.println(VariableCSV1);
		System.out.println(VariableName2);
		System.out.println(VariableCSV2);
		System.out.println(VariableName3);
		System.out.println(VariableCSV3);
		System.out.println(VariableName4);
		System.out.println(VariableCSV4);
		System.out.println(VariableNameAdd);
		System.out.println(VariableCSV5);
		Assert.assertEquals(VariableName1, VariableCSV1);
		Assert.assertEquals(VariableName2, VariableCSV2);
		Assert.assertEquals(VariableName3, VariableCSV3);
		Assert.assertEquals(VariableName4, VariableCSV4);
		Assert.assertEquals(VariableNameAdd, VariableCSV5);
		}


	public void createNewFilterOrExisting(String filterName,String selectedCategoryFilter,String variableNameFilter1,String variableNameFilter2)
	{

		System.out.println("Entered filter name is:==-=====------------" +filterName);
		System.out.println("Into checking existing filters or not++++++++++++++++++++++++++++++++++");
		Select selectFilter= new Select(getDriver().findElement(By.xpath("//div[@class='filter_widget_form']//select[@id='filterName']")));
try{
int availableoptioncount=0;

		List<WebElement> dropDownValues=selectFilter.getOptions();
		for(int i=0; i<dropDownValues.size();i++){
			waitFor(6000);
			String availableDropDown=dropDownValues.get(i).getText();
			System.out.println("Drop down in the list are:" +availableDropDown);
			waitFor(5000);
			if(availableDropDown.contains(filterName)){
				selectFilter.selectByVisibleText(filterName);
				System.out.println("Selected the entered filter name+++++" +filterName);				
				//Extract total number of records in Pre Count Filter
				preCountFilterBtn.click();
				waitFor(5000);
				getDriver().switchTo().frame("__modal_iframe_target");
				System.out.println("Into IFrame window**********************************");
				Thread.sleep(5000);
				totalPreCountFilterRecord=Integer.parseInt(totalPreCountFilterRecords.getText());
				Thread.sleep(5000);
				System.out.println("Content inside are:++++++++++++++++++++++++++++++"+totalPreCountFilterRecord);
				Thread.sleep(5000);
				preCountFilterModalOKBtn.click();
				System.out.println("Clicked on modal window OK button:---------------------------");
				getDriver().switchTo().defaultContent();
				sortNEXT.click();
				availableoptioncount=1;
				break;
			}
		}
			if(availableoptioncount==0){
				System.out.println("Clicked Create New button+++++");
				createNewFilterBtn.waitUntilClickable();
				createNewFilterBtn.click();
				createSubmitNewFilter(filterName, selectedCategoryFilter, variableNameFilter1, variableNameFilter2);
				preCountFilterBtn.click();
				waitFor(5000);
				getDriver().switchTo().frame("__modal_iframe_target");
				System.out.println("Into IFrame window**********************************");
				Thread.sleep(5000);
				totalPreCountFilterRecord=Integer.parseInt(totalPreCountFilterRecords.getText());
				Thread.sleep(5000);
				System.out.println("Content inside are:++++++++++++++++++++++++++++++"+totalPreCountFilterRecord);
				Thread.sleep(5000);
				preCountFilterModalOKBtn.click();
				System.out.println("Clicked on modal window OK button:---------------------------");
				getDriver().switchTo().defaultContent();
				sortNEXT.click();
				}
	}catch(Exception e){
		e.printStackTrace();
	}
	}
	
	
	public void createSubmitNewFilter(String filterName,String selectedCategoryFilter,String variableNameFilter1,String variableNameFilter2){
		try{
		UIHelper.waitForPageToLoad(getDriver());
		writeFilterName.sendKeys(filterName);
		Select selectCategory = new Select(getDriver().findElement(By.xpath("//div[@class='filt_wrapper']//select[@id='data_category']")));
		selectCategory.selectByVisibleText(selectedCategoryFilter);
		Select selectVariables = new Select(getDriver().findElement(By.xpath("//div[@class='filt_wrapper']//select[@id='data_fields']")));
		selectVariables.selectByVisibleText(variableNameFilter1);
		filterADDCondition.click();
		Select variable1 = new Select(getDriver().findElement(By.xpath("//tbody[@id='dataFieldAndTable']//select[@id='fieldInfoBean1_operator']")));
		variable1.selectByVisibleText("Is Not Blank");
		waitFor(5000);
		selectVariables.selectByVisibleText(variableNameFilter2);
		filterADDCondition.click();
		Select variable2 = new Select(getDriver().findElement(By.xpath("//tbody[@id='dataFieldAndTable']//select[@id='fieldInfoBean2_operator']")));
		variable2.selectByVisibleText("Is Not Blank");
		saveFilter.click();
		waitFor(5000);
		
		
		//Extract total number of records in Pre Count Filter
		preCountFilterBtn.click();
		waitFor(5000);
		getDriver().switchTo().frame("__modal_iframe_target");
		System.out.println("Into IFrame window**********************************");
		Thread.sleep(5000);
		totalPreCountFilterRecord=Integer.parseInt(totalPreCountFilterRecords.getText());
		Thread.sleep(5000);
		System.out.println("Content inside are:++++++++++++++++++++++++++++++"+totalPreCountFilterRecord);
		Thread.sleep(5000);
		preCountFilterModalOKBtn.click();
		System.out.println("Clicked on modal window OK button:---------------------------");
		getDriver().switchTo().defaultContent();
		
		
		
		sortNEXT.click();
		}catch(Exception e){
			e.printStackTrace();
		}

	}

		public boolean checkExisitingFilter(){
			Select selectFilter= new Select(getDriver().findElement(By.xpath("//div[@class='filter_widget_form']//select[@id='filterName']")));
			List<WebElement> filtersAvailable=selectFilter.getOptions();
			System.out.println("Total filters available are:" +filtersAvailable.size());
			if(filtersAvailable.size()>0)
				return true;
			else
				return false;

		}


		public boolean checkExisitingColumnTemplate(){
			Select columnTemplate= new Select(getDriver().findElement(By.xpath("//div[@class='floatLeft']//select[@id='dataTemplateId']")));
			List<WebElement> columnTemplateAvailable=columnTemplate.getOptions();
			System.out.println("Total filters available are:" +columnTemplateAvailable.size());
			if(columnTemplateAvailable.size()>0)
				return true;
			else
				return false;

		}


		 public void clickTerritoriesTab(){

				UIHelper.waitForPageToLoad(getDriver());
				clickAdminTab.click();
				waitFor(5000);
				administerUserBtn.click();
				territoriesTab.click();

			}

		 public void deleteTerritory(String territoryName){

			 if(getDriver().findElement(By.xpath("//*[@id='manage_terr_table_id']/tbody//tr//td[contains(.,'"+territoryName+"')]")).isDisplayed()){
				getDriver().findElement(By.xpath("//*[@id='manage_terr_table_id']/tbody//tr//td[contains(.,'"+territoryName+"')]//following-sibling::td[2]//a[2]")).click();
				UIHelper.processalert(getDriver());
				waitFor(5000);
				territoriesTab.click();
			 }

		 }

		 public void enableCreateNewTerritories(){

			 if(!enableTerritories.isSelected()){
			 enableTerritories.click();
			 UIHelper.processalert(getDriver());
			 createNewTerritoryBtn.waitUntilClickable();
			 createNewTerritoryBtn.click();
			 }else{
			 createNewTerritoryBtn.waitUntilClickable();
			 createNewTerritoryBtn.click();
			 }

		 }

		 public void disableTerritories(){

			 if(enableTerritories.isSelected()){
			 enableTerritories.click();
			 UIHelper.processalert(getDriver());
			 waitFor(5000);
			 territoriesTab.click();
			 accountManagerTab.click();
			 }

		 }

		public void enterNameVariable(String territoryName, String variable){

			 writeTerritoryName.sendKeys(territoryName);
			 Select variableTerritories = new Select(availableVariableTerritories);
			 variableTerritories.selectByVisibleText(variable);
			 addVariablesTerritories.click();

		 }


		public void enterStateSave(String stateName){

			enterStateName.sendKeys(stateName);
			saveTerritories.click();
			UIHelper.waitForPageToLoad(getDriver());

		}
	}
