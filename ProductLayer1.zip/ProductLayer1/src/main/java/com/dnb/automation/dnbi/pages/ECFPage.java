/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.dnb.automation.dnbi.pages;

import static org.hamcrest.MatcherAssert.assertThat;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.apache.commons.lang3.StringUtils;
import org.hamcrest.Matchers;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * ECFPage.java - This class contains methods for add products to companies
 * folders, validate internation order page, verify all buttons in ECF page and
 * verify all sections in ECF page
 * 
 * @author Duvvuru Naveen and Vamsi Krishna NV
 * @version 1.0
 ***********************************************************************************************/

public class ECFPage extends PageObject {

	ArrayList<String> boolframeModaladdToFolderFormList = new ArrayList<String>();

	public static ArrayList<String> ecfValuesFromScoreBar = new ArrayList<String>();
	public static ArrayList<String> ecfValuesfromwidgetForm = new ArrayList<String>();
	public static ArrayList<String> ecfValuesfrompreDictiveScores = new ArrayList<String>();
	private final Logger log=Logger.getLogger(this.getClass().getPackage().getName());
	// Predictive Scores - Start

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='ecf_toc1']//*[contains(text(),'Predictive')]")
	public WebElementFacade predictiveScoresHREF;

	// Max Credit Limit

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(@id,'DBMAXCREDIT')]")
	public WebElementFacade predictiveScoresDBMAXCREDIT;

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(@id,'DBMAXCREDIT')]//*//table//*/td//*[contains(text(),'Maximum')]")
	public WebElementFacade predictiveScoresDBMAXCREDITValue;

	// DnB Rating

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(@id,'DBRATINGECF')]")
	public WebElementFacade predictiveScoresDBRATINGECF;

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(@id,'DBRATINGECF')]//*//table//*/td//*[contains(text(),'Rating')]")
	public WebElementFacade predictiveScoresDBRATINGECFValue;

	// DnB FailureScore

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(@id,'DBFAILSCRECF')]")
	public WebElementFacade predictiveScoresFailureScoreECF;

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(@id,'DBFAILSCRECF')]//*//table//*/td//*[contains(text(),'D&B Failure Score')]")
	public WebElementFacade predictiveScoresFailureScoreECFValue;

	// D&B Delinquency Score

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(@id,'DBPAYDEXSCRECF')]")
	public WebElementFacade predictiveScoresDelinquencyScoreECF;

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(@id,'DBPAYDEXSCRECF')]//*//table//*/td//*[contains(text(),'D&B Delinquency Score')]")
	public WebElementFacade predictiveScoresDelinquencyScoreECFValue;
	// Predictive Scores - End

	// Entries for NA2, NA3
	@FindBy(xpath = "//*[@id='main']//*[@class='widget widget1 wideWidget']//*[@id='scorebar1']//*[contains(text(),'Commercial Credit Score') and not(contains(text(),'Percen')) and not(contains(text(),'Class'))]")
	private WebElementFacade ecfCOMMERCIALCREDITSCORE;

	@FindBy(xpath = "//*[@id='main']//*[@class='widget widget1 wideWidget']//*[@id='scorebar1']//*[contains(text(),'Commercial Credit Score Perc')]")
	private WebElementFacade ecfCOMMERCIALCREDITSCOREPERCENTILE;

	@FindBy(xpath = "//*[@id='main']//*[@class='widget widget1 wideWidget']//*[@id='scorebar1']//*[contains(text(),'Commercial Credit Score Class')]")
	private WebElementFacade ecfCOMMERCIALCREDITSCORECLASS;

	@FindBy(xpath = "//*[@id='main']//*[@class='widget widget1 wideWidget']//*[@id='scorebar1']//*[contains(text(),'Financial Stress Score') and not(contains(text(),'Class'))]")
	private WebElementFacade ecfFINANCIALSTRESSSCORE;

	@FindBy(xpath = "//*[@id='main']//*[@class='widget widget1 wideWidget']//*[@id='scorebar1']//*[contains(text(),'Financial Stress Score Class')]")
	private WebElementFacade ecfFINANCIALSTRESSSCORECLASS;

	@FindBy(xpath = "//*[@id='main']//*[contains(text(),'Commercial Credit Score') and not(contains(text(),'Percen')) and not(contains(text(),'Class'))]//ancestor::tr[1]//*[@class='tablelight' and @align='right'][1]")
	private WebElementFacade ecfCOMMERCIALCREDITSCORECompanyScoreTabAfterAppCreation;

	@FindBy(xpath = "//*[@id='main']//*[contains(text(),'Commercial Credit Score Perc')]//ancestor::tr[1]//*[@class='tablelight' and @align='right'][1]")
	private WebElementFacade ecfCOMMERCIALCREDITSCOREPERCENTILECompanyScoreTabAfterAppCreation;

	@FindBy(xpath = "//*[@id='main']//*[contains(text(),'Commercial Credit Score Class')]//ancestor::tr[1]//*[@class='tablelight' and @align='right'][1]")
	private WebElementFacade ecfCOMMERCIALCREDITSCORECLASSCompanyScoreTabAfterAppCreation;

	@FindBy(xpath = "//*[@id='main']//*[contains(text(),'Financial Stress Score') and not(contains(text(),'Class'))]//ancestor::tr[1]//*[@class='tablelight' and @align='right'][1]")
	private WebElementFacade ecfFINANCIALSTRESSSCORECompanyScoreTabAfterAppCreation;

	@FindBy(xpath = "//*[@id='main']//*[contains(text(),'Financial Stress Score Class')]//ancestor::tr[1]//*[@class='tablelight' and @align='right'][1]")
	private WebElementFacade ecfFINANCIALSTRESSSCORECLASSCompanyScoreTabAfterAppCreation;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='breadcrumb']")
	private WebElementFacade searchResultsnapShot;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@id='pp_side_icon']")
	private WebElementFacade searchResultsnapShotSideicon;
	
	private String snapShotSideicon="//*[@class='outerDiv']//*[@id='main']//*[@id='pp_side_icon']";

	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='addFolder_ecf']")
	private WebElementFacade searchResultsnapShotSideiconAddFolder;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='save_modal']/input[@value='yes']")
	private WebElementFacade searchResultsnapShotSideiconAddFoldermodalWindowYes;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='save_modal']/input")
	private WebElementFacade searchResultsnapShotAddFoldermodalWindowInputs;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@class='modal_buttons']/input[@type='button' and @value='Submit']")
	private WebElementFacade searchResultsnapShotAddFolderSubmit;

	String searchResultsnapShotAddFolderSubmitXpath = "//*[@class='modal_buttons']//*[@value='Submit']";

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@id='pp_side_icon']//*[@class='deleteFolder_ecf']")
	private WebElementFacade searchResultsnapShotSideiconDeleteFolder;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@id='pp_side_icon']//*[@class='saveToFolder_ecf']")
	private WebElementFacade saveToPortfolio;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@id='pp_side_icon']//*[@class='print_ecf']")
	private WebElementFacade searchResultsnapShotSideiconprintECF;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@id='pp_side_icon']//*[@class='email_ecf']")
	private WebElementFacade searchResultsnapShotSideiconemailECF;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@id='pp_side_icon']//*[@class='preferences_ecf']")
	private WebElementFacade searchResultsnapShotSideiconPrefECF;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@class='ecf_page']//*[@id='widget_container' ]//*[@id='intlReport']")
	private WebElementFacade searchResultsnapShotintlReport;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@class='ecf_page']//*[@id='intlReport']/pre")
	private WebElementFacade searchResultsnapShotintlReportpre;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@class='ecf_page']//*[@id='intlReport']/pre//text()")
	private WebElementFacade searchResultsnapShotintlReportText;

	// --------------------------------------------

	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='actionButtons']//*[contains(@value,'Snapshot')]")
	private WebElementFacade saveASnapshotEle;

	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//*[contains(@src,'dnbi')]")
	private WebElementFacade saveSnapshotIframeID;

	@FindBy(xpath = "//*[@class='modal_buttons']//*[contains(@value,'Save')]")
	private WebElementFacade saveSnapshotSaveBTNEle;

	@FindBy(xpath = "//*[contains(@class,'alert_box include_filterBG')]//*[@id='subFilter']")
	private WebElementFacade subFilterSnpshotFolder;

	@FindBy(xpath = "//*[contains(@class,'alert_box include_filterBG')]//*[@id='entityFilter']")
	private WebElementFacade viewFilterFolder;

	@FindBy(xpath = "//*[contains(@class,'alert_box include_filterBG')]//*[@id='MODIFICATION_DATE']")
	private WebElementFacade dateFilterSnpshotFolder;

	@FindBy(xpath = "//*[contains(@class,'alert_box include_filterBG')]//*[@value='Apply']")
	private WebElementFacade applyBtnrSnpshotFolder;

	@FindBy(xpath = "//*[@id='main']//*[contains(@class,'floatLeft')][contains(.,'View Items')]//select[@id='viewItems']")
	private WebElementFacade viewlistListbox;

	@FindBy(xpath = "//*[@id='main']/table[contains(@class,'results full_company')]//thead")
	private WebElementFacade tableSnapshotFolder;

	@FindBy(xpath = "//*[@action='showAllFolderSummary']//tbody//*[contains(@class,'RowGray')]//td[contains(@class,'leftAlign')]//a[contains(.,'Snapshots')]")
	private WebElementFacade snapshotlink;

	@FindBy(xpath = "//*[@id='header_mainApp']//li//a[contains(.,'Companies')]")
	private WebElementFacade CompaniesTabEle;

	@FindBy(xpath = "//*[@id='main']//*[@class='compHome_newFolder']//input[@value='Create New Folder']")
	private WebElementFacade createNewFolderBtn;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='quickSearchFld']")
	private WebElementFacade searchCompBox;

	@FindBy(xpath = "//*[@id='main']/table[contains(@class,'results full_company')]/tbody/tr/td[2]/span/a")
	private WebElementFacade folderResults;

	// -------------------------------------

	@FindBy(xpath = "//*[@id='main']//*[@class='actionButtons']//input[@type='button' and  @value='Create Account']")
	private WebElementFacade createAccountfromECF;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@action='/dnbi/companies/saveSnapshot']")
	private WebElementFacade ecfForm;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@action='/dnbi/companies/saveSnapshot']//*[@id='ecf_note_submit']")
	private WebElementFacade ecfnoteSubmitBtn;

	@FindBy(xpath = "//*[@id='addnote_ecf']//*[@class='noteerror_ecf']//select")
	private WebElementFacade saveSnapshotIframeIDSelectEle;

	@FindBy(xpath = "//*[@id='addnote_ecf']//*[@id='save_modal']//input[@value='yes']")
	private WebElementFacade addToFolderIYesRadioBtn;

	@FindBy(xpath = "//*[@id='addnote_ecf']//*[@id='folderAdd']//*[contains(@id,'folder_id')]")
	private WebElementFacade addToFolderListBox;

	@FindBy(xpath = "//body[@class='iframe_modal']//div[@class='modal_inner_content']//table[@class='results full']/tbody//textarea")
	private WebElementFacade saveSnapshotnotationTextAreaEle;

	private String saveSnapshotIframeIDSelectXpath = "//*[@id='addnote_ecf']//*[@class='noteerror_ecf']//select";

	@FindBy(xpath = "//*[@id='ecf_note_submit']")
	private WebElementFacade frameIDSubmit;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@class='ecf_page']//*[@id='intlReport']/pre")
	private WebElementFacade informationReportInnerText;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='actionButtons']//input[@type='button']")
	private WebElementFacade actionButtons;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@class='ecf_page']//*[@id='intlReport']")
	private WebElementFacade informationReportPanel;

	@FindBy(xpath = "//*[@id='main']//*[@id='confirmSaveModal']//*[@id='modal_buttons']//*[@value='Save']")
	private WebElementFacade modalconfirmSave;

	@FindBy(xpath = "//*[@id='main']//*[@id='confirmSaveModal']")
	private WebElementFacade modalconfirmSaveouter;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//*[@class='outer_scorebar']")
	private WebElementFacade ecfPageScorebar;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//*[@class='outer_scorebar']//*")
	private WebElementFacade ecfPageScorebarAllContents;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//*[@class='outer_scorebar']//*[@id='scorebar1']//*[@class='scorelabel' and contains(text(),'Failure')]//parent::div/a")
	private WebElementFacade companySummaryFailureScoreDnB;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//*[@class='outer_scorebar']//*[@id='scorebar1']//*[@class='scorelabel' and contains(text(),'Average')]//parent::div/a")
	private WebElementFacade companySummaryaverageDays;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//*[@class='outer_scorebar']//*[@id='scorebar1']//*[@class='scorelabel' and contains(text(),'Credit Recommend')]//parent::div/a")
	private WebElementFacade companySummarycreditRecommendation;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//*[@class='outer_scorebar']//*[@id='scorebar1']//*[@class='scorelabel' and contains(text(),'D&B Rat')]//parent::div/a")
	private WebElementFacade companySummaryDnbRating;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//*[@class='outer_scorebar']//*[@id='scorebar1']//*[@class='scorelabel' and contains(text(),'D&B Delinq')]//parent::div/a")
	private WebElementFacade companySummaryDelinquencyScore;

	// Scorebar

	@FindBy(xpath = ".//*[@id='widget_container']/div//div")
	private WebElementFacade widgetContScoreBarDiv;

	@FindBy(xpath = ".//*[@id='widget_container']//div")
	private WebElementFacade widgetContainerAllDivs;

	@FindBy(xpath = "//*[@id='main']//*[contains(@class,'warn')]")
	private WebElementFacade widgetContainerWarningMessage;

	@FindBy(xpath = "//*[@id='main']//*[@class='ecf_page']//*[@id='widget_container']//*[@id='FAILURE_SCORE']//*[@class='barScore']//*[contains(@class,'barScore')]")
	private WebElementFacade companySummaryFailureScoreDnBScorebar;

	@FindBy(xpath = "//*[@id='main']//*[@class='ecf_page']//*[@id='widget_container']//*[@id='MAX_CREDIT_LIMIT']//*[@class='solidBottomBlankLine']/span[contains(text(),'D&B Max Credit Recommendation')]")
	private WebElementFacade companySummarycreditRecommendationScorebar;

	@FindBy(xpath = "//*[@id='main']//*[@class='ecf_page']//*[@id='widget_container']//*[@id='DNB_RATINGS']//*[@class='ecf_rating tab_border']//*/span[contains(text(),'D&B Rating:')]")
	private WebElementFacade companySummaryDnbRatingScorebar;

	@FindBy(xpath = "//*[@id='main']//*[@class='ecf_page']//*[@id='widget_container']//*[@id='DELINQUENCY_SCORE']//*[@class='barScore']//*[contains(@class,'barScore')]")
	private WebElementFacade companySummaryDelinquencyScoreScorebar;

	@FindBy(xpath = "//*[@id='main']//*[@id='ecf_toc_main']//*[@id='ecf_toc1']//a[contains(text(),'Predictive Scores')]")
	private WebElementFacade companySummarypreScore;

	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_title']")
	public WebElementFacade frameModaltitle;

	@FindBy(xpath = "//*[@id='to_folder_id']")
	public WebElementFacade frameModaladdToFolderForm;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='save_modal']//input[@value='yes']")
	public WebElementFacade frameCompanyToAddFolderYesEle;

	@FindBy(xpath = "//*[@id='addToFolderForm']//*[@id='to_folder_id']")
	public WebElementFacade frameModaladdToFolderFromEle;

	String frameCompanyToAddFolderYesXpath = "//*[@class='iframe_modal']//*[@id='save_modal']//input[@value='yes']";

	String frameModaladdToFolderFromXpath = "//*[@id='addToFolderForm']//*[@id='to_folder_id']";

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='addToFolderForm']//*[@class='ecfaddfo']//*[@id='to_folder_id']")
	public WebElementFacade frameModaladdTodirectly;

	@FindBy(xpath = "//*[@id='confirmSaveModal']//*[@class='modal_content']//*[@id='modal_buttons']//*[@value='Save']")
	public WebElementFacade frameModalactionSave;

	@FindBy(xpath = "//*[@id='main']//*[@id='confirmSaveModal']")
	public WebElementFacade confirmSaveModal;

	@FindBy(xpath = "//*[@id='main']//*[@id='ecf_toc_main']")
	public WebElementFacade ecfPageForm;

	@FindBy(xpath = "//*[@id='main']//*[@class='ecf_page']//*")
	public WebElementFacade ecfPageFull;

	@FindBy(xpath = "//*[@id='main']//*[@class='actionButtons']//*[contains(@value,'Order Inve')]")
	public WebElementFacade ecForderInvestigation;

	@FindBy(xpath = "//*[@id='entity_header']//h2")
	public WebElementFacade ecfPageTileEle;

	@FindBy(xpath = "//*[@id='main']//*[@class='DnBAddress']//h3")
	public WebElementFacade dAndBAddressElementInECF;

	@FindBy(xpath = "//*[@id='duns']//li[contains(@class,'first')]")
	public WebElementFacade dunsNumberInECF;
	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//input[@value='Save']")
	public WebElementFacade modelpopupxpath;
	
	// Company Summary

	@FindBy(xpath = ".//*[@id='widget_container']//*[@class='widget wideWidget']//*[@class='review_details']/span")
	public WebElementFacade companySummaryAppDecisionReason;

	@FindBy(xpath = "//*[@id='widget_container']//*[@class='widget wideWidget']//*[@id='viewDetails']")
	public WebElementFacade companySummaryAppDecisionReasonView;

	@FindBy(xpath = "//*[@id='widget_container']//*[@class='widget wideWidget']//*/a[contains(.,'View Reason')]")
	public WebElementFacade companySummaryAppDecisionReasonViewviewEnabled;

	@FindBy(xpath = "//*[@id='widget_container']//*[@class='widget wideWidget']//*/a[contains(.,'Hide')]")
	public WebElementFacade companySummaryAppDecisionReasonViewHideEnabled;

	@FindBy(xpath = "//*[@class='reviewStatus']//*[@id='credit_hold_details']/table//*/td[1]")
	public WebElementFacade companySummaryAppDecisionReasonViewCondition;

	@FindBy(xpath = "//*[@class='reviewStatus']//*[@id='credit_hold_details']/table//*/td[2]")
	public WebElementFacade companySummaryAppDecisionReasonViewValue;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='ecf_toc1']//*[contains(text(),'Summary')]")
	public WebElementFacade companySummaryHREF;

	@FindBy(xpath = "//*[@id='main']//*[@id='ecf_toc_main']//*[@id='ecf_toc1']//*[contains(text(),'Global Family Tree')]")
	public WebElementFacade globalFamilyTreeLinkEle;

	@FindBy(xpath = "//*[@id='main']//*[@id='ecf_toc_main']//*[@id='ecf_toc1']//*[contains(text(),'Company Documents')]")
	public WebElementFacade compDocumentsLinkEle;

	@FindBy(xpath = "//*[@id='main']//*[@class='ecf_page']//a[contains(.,'Order Global Family Tree')]")
	public WebElementFacade orderGFTBtnEle;

	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
	public WebElementFacade iFrameEle;

	@FindBy(xpath = "//iframe[@name='__modal_iframe_target']")
	public WebElementFacade anotheriFrameEle;

	@FindBy(xpath = "//*[@class='actionButtons']//*[@value='Send Notification']")
	private WebElementFacade sendNotification;

	private String notificationNameXpath = "//*[@id='modalNotificationBody']//select//option[contains(.,'FIFA')]";

	@FindBy(xpath = "//*[@id='modalNotificationBody']//select")
	private WebElementFacade notificationsDropdownEle;

	@FindBy(xpath = "//*[@id='previewNotification']")
	private WebElementFacade sendBtnInIframe;

	@FindBy(xpath = ".//*[@class='actionButtons']//*[@value='Send Notification']")
	private WebElementFacade sendNotificationEle;

	@FindBy(xpath = "//*[@id='asdf']//*[@class='modal_inner_content']//p//strong")
	private WebElementFacade dnbiPricingScreenTextEle;

	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_title']//a")
	private WebElementFacade closeFrameEle;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@class='modal_buttons']//*[@id='asdf']//*[@id='ok']")
	private WebElementFacade okButtonEleInDNBiPricingScreen;

	private String imageLoadingXpath = "//*[@id='loading']//img";

	private String dnbiPricingScreenText;

	@FindBy(xpath = "//*[@id='main']//*[@id='widget_container']//*[@class='widget_full']")
	public WebElementFacade companySummarywidgetContainer;

	@FindBy(xpath = "//*[@id='main']//*[@class='reviewStatus']//*[@id='credit_hold_details']/table[@class='results tab_border']//*/a")
	public WebElementFacade companySummaryConditionLink;

	@FindBy(xpath = "//*[@class='outerDiv']//*/div/h3[contains(@class,'warning')]")
	public WebElementFacade companySummaryWarningCell;

	// Custom Scores

	@FindBy(xpath = "//*[@id='main']//*[@id='ecf_toc1']//*[contains(text(),'Custom')]")
	public WebElementFacade ecFCustomScores;

	@FindBy(xpath = "//*[@id='widget_container']//*//table[@class='results full tab_border']//*/a")
	public WebElementFacade ecFCustomScoresHREF;

	@FindBy(xpath = "//*[@id='main']//*[@id='widget_container']//*[@class='widget_full']//*/table//*//td[3]")
	public WebElementFacade ecFCustomScoresValue;

	@FindBy(xpath = "//*[@id='main']//*[@id='tab1']//*//table//*[contains(text(),'Delin')]//ancestor::tr[1]//*[@class='tablelight' and @align='right'][1]")
	public WebElementFacade ecFCustomScoresnewWindowDelinQuencyScore;

	@FindBy(xpath = "//*[@id='main']//*[@id='tab1']//*//table//*[contains(text(),'Fail')]//ancestor::tr[1]//*[@class='tablelight' and @align='right'][1]")
	public WebElementFacade ecFCustomScoresnewWindowFailureScore;

	@FindBy(xpath = "//*[@id='main']//*[@id='tab1']//*//table//*[contains(text(),'Indicat')]//ancestor::tr[1]//*[@class='tablelight' and @align='right'][1]")
	public WebElementFacade ecFCustomScoresnewWindowRIScore;

	@FindBy(xpath = "//*[@id='main']//*[@id='tab1']//*//table//*[contains(text(),'Recommen')]//ancestor::tr[1]//*[@class='tablelight' and @align='right'][1]")
	public WebElementFacade ecFCustomScoresnewWindowCRScore;
	
	@FindBy(xpath = "//div[@class='outerDiv']//div[contains(.,'Select Score')]/select[@name='graphScoreFilter']")
	public WebElementFacade selectScore;
	
	@FindBy(xpath = "//*[@id='widget_container']//*[@class='widget_full']/iframe[contains(@src,'score_trending&GRAPH')]")
	public WebElementFacade ScoreTrendGraphIframeElement;
	
	@FindBy(xpath = "//div[@id='main']//div[@id='tab1']//div[@class='ecf_scorcurr']//table[1]//tr//td//form[@id='CURRform']//select")
	public WebElementFacade ScoreTimeStamp;

	// Audit Trial

	@FindBy(xpath = "//*[@id='main']//*[@id='ecf_toc1']//*[contains(text(),'Audit Tr')]")
	public WebElementFacade companySummaryAuditTrial;

	@FindBy(xpath = "//*[@id='main']//*[@id='widget_container']//*[@class='widget_full']//*//*//table/tbody/tr[1]//*[contains(text(),'More')]")
	public WebElementFacade companySummaryauditTrialMoreINFO;

	@FindBy(xpath = "//*[@id='main']//*[@id='widget_container']//*[@class='widget_full']//*//*//table/tbody/tr[1]/td[4]")
	public WebElementFacade companySummaryauditTrialMoreINFOMessage;

	@FindBy(xpath = "//*[@id='main']//input[@value='Order Investigation']")
	public WebElementFacade OrderInvestigationBtnEle;

	@FindBy(xpath = "//*[@id='main']//*[@class='frmField']//textarea")
	private WebElementFacade additionalInfoTextArea;

	@FindBy(xpath = "//*[@id='main']//input[contains(@value,'6347')]")
	private WebElementFacade standardRadioBtnEle;

	@FindBy(xpath = "//*[@id='main']//input[contains(@name,'emailRequestedIndicator')]")
	private WebElementFacade emailInvestReportChkboxEle;

	@FindBy(xpath = "//*[@id='main']//input[contains(@value,'6347')]")
	private WebElementFacade priorityRadioBtnEle;

	@FindBy(xpath = "//*[@id='main']//input[contains(@value,'Order') or contains(@value,'Submit')][@type='button']")
	private WebElementFacade orderBtn;

	@FindBy(xpath = "//*[@id='main']//input[contains(@value,'Back To Report')][@type='button']")
	private WebElementFacade backToReportBtnEle;

	@FindBy(xpath = "//*[@id='header_mainApp']//a[text()='Dashboard']")
	private WebElementFacade dashBoardTabEle;

	// Widget
	@FindBy(xpath = "//*[@id='main']//*[@class='widget widget1 wideWidget']/div")
	private WebElementFacade companySummarywidgetwidget1wideWidget;

	@FindBy(xpath = "//*[@id='addToFolderForm']//a[contains(text(),'Create a new folder')]")
	private WebElementFacade ecfaddfolderCreateFolderasNew;

	@FindBy(xpath = "//*[contains(@class,'iframe')]//*[@id='createFolder']//*[contains(@id,'NewFolderName') or contains(@name,'NewFolderName')]")
	private WebElementFacade newFolderName;

	@FindBy(xpath = "//*[contains(@class,'iframe')]//*[@id='createFolder']//*[contains(@id,'user_profile') or contains(@name,'user_profile')]")
	private WebElementFacade newFolderNameAlertProfile;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='ecf_header']")
	private WebElementFacade ecfHeaderEle;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='ecf_header']//ul")
	private List<WebElementFacade> ecf_headerListElts;

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'addFolder')]//a")
	private WebElementFacade searchResultsnapShotSideiconAddFolderEle;

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'deleteFolder')]//a")
	private WebElementFacade ecfRemoveFolderEle;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='actionButtons']")
	private WebElementFacade actionButtonsEle;
	private String actionBtnelement = "//*[@class='outerDiv']//*[@class='actionButtons']";

	private String foldername = "//*[contains(@class,'iframe')]//*[@id='createFolder']//*[contains(@id,'NewFolderName') or contains(@name,'NewFolderName')]";

	private String loadingImgXpath = "//*[@id='loading']//img";

	@FindBy(xpath = "//*[@id='or-content']/div[1]/div")
	private WebElementFacade dAndbReportNameEle;

	@FindBy(xpath = "//*[@id='main']//*[@id='ecf_toc_main']//*[@id='ecf_toc1']")
	private WebElementFacade ecfPageSectionsEle;

	@FindBy(xpath = "//*[@id='ecf_toc1']//a[contains(.,'D&B Report')]")
	private WebElementFacade dandbReportLink;

	@FindBy(xpath = "//*[@id='ecf_toc1']//a[contains(.,'Detailed Trade Risk')]")
	private WebElementFacade detailedTradeRiskInsightLink;

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Financials')]")
	private WebElementFacade financialsLinkEle;

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Small Business Financial Exchange')]")
	private WebElementFacade SBFELinkEle;
	
	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Small Business Risk Insight')]")
	private WebElementFacade SBRILinkEle;
	
	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Detailed Trade Risk Insight')]")
	private WebElementFacade DTRILinkEle;
	
	

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Principals')]")
	private WebElementFacade principalsLinkEle;

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'D&B Report')]")
	private WebElementFacade dAndBReportLinkEle;

	@FindBy(xpath = "//*[contains(@id,'plLoading')]//input[@value='OK']")
	private WebElementFacade ploadingOkbtn;

	@FindBy(xpath = "//*[@id='ecf_toc1']//a[contains(.,'Notes & Documents')]")
	private WebElementFacade notesAdnDocsLinkEle;

	@FindBy(xpath = "//*[@id='ecf_toc1']//a[contains(.,'Custom Scores')]")
	private WebElementFacade customScoresLinkEle;

	@FindBy(xpath = "//*[@id='ecf_toc1']//a[contains(.,'Audit Trail')]")
	private WebElementFacade auditTrailLinkEle;

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Small Business Risk')]")
	private WebElementFacade smallBusinesRiskLinkEle;

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Corporate Linkage')]")
	private WebElementFacade corporateLinkageLinkEle;

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Company Summary')]")
	private WebElementFacade companySummaryLinkEle;

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Notes')]")
	private WebElementFacade notesLinkEle;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'ecfbox')]//h3[contains(.,'Notes')]")
	private WebElementFacade notesSectionLinkEle;

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Associations')]")
	private WebElementFacade AssociationsLinkEle;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'summary_links')]//h3[contains(.,'Associations')]")
	private WebElementFacade AssociationsSectionLinkEle;

	private String associationssectiontitle = "//*[@id='widget_container']//*[contains(@class,'summary_links')]//h3[contains(.,'Associations')]";

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Your Information')]")
	private WebElementFacade yourInformationLinkEle;

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Predictive Scores')]")
	private WebElementFacade predictiveScoresLinkEle;

	@FindBy(xpath = "//*[@id='widget_container']//img[contains(@src,'sbri')]")
	private WebElementFacade sBRIImageEle;
	
	@FindBy(xpath = "//*[@id='widget_container']//*[@class='widget_full']//*[@class='alert_box']/h3[contains(.,'not found')]")
	private WebElementFacade noSBRIDataMssg;
	
	@FindBy(xpath = "//*[@id='widget_container']//img[contains(@src,'us')]")
	private WebElementFacade dTRIImageEle;
	
	@FindBy(xpath = "//*[@id='widget_container']//*[@class='alert_box clear']/h3[contains(.,'No Detailed Trade Data is available for this D-U-N-S® Number.')]")
	private WebElementFacade noDTRIDataMssg;
	
	@FindBy(xpath ="//*[@id='widget_container']/div[@class='widget widgetA']/h3")
	private WebElementFacade companyOverview;
	
	@FindBy(xpath ="//*[@id='widget_container']//*[contains(@class,'ecfbox')]//h3[contains(.,'D&B PAYDEX')]")
	private WebElementFacade dbPaydex;
	
	@FindBy(xpath ="//*[@id='widget_container']//*[contains(@class,'ecfbox')]//h3[contains(.,'PAYDEX® Yearly Trend - 24 Month PAYDEX')]")
	private WebElementFacade paydexYearlyTrend;
	
	@FindBy(xpath ="//*[@id='widget_container']/div[6]/h3")
	private WebElementFacade locationMap;
	
	@FindBy(xpath ="//*[@id='widget_container']/div[4]/h3")
	private WebElementFacade locationMapCA;
	
	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Trade Payments')]")
	private WebElementFacade tradePaymentsLinkEle;

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Public Filings')]")
	private WebElementFacade publicFilingsLinkEle;

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Special Events')]")
	private WebElementFacade specialEventsLinkEle;

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'History & Operations')]")
	private WebElementFacade historyAndOperationsLinkEle;

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Fraud Risk Score')]")
	private WebElementFacade fraudRiskScoreLinkEle;

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Associations')]")
	private WebElementFacade associationsLinkEle;

	@FindBy(xpath = "//*[@id='widget_container']//h3[contains(@class,'warning')]")
	private WebElementFacade warningMsgEle;

	@FindBy(xpath = "//*[@class='ecf_page']//b[contains(.,'No notes') or contains(.,'No documents')]")
	private WebElementFacade noNotesOrDocsEle;

	@FindBy(xpath = "//*[@class='ecf_page']//b[contains(.,'No scores')]")
	private WebElementFacade noCustomScoreEle;

	@FindBy(xpath = "//*[@id='aud_tabs1']//a[contains(.,'Current Event')]")
	private WebElementFacade auditCurrentEventEle;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='aud_tab1']//table[@class='results full tab_border']//tbody//tr[1]")
	private WebElementFacade auditCurrentEventConfirmValEle;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='sbriAcc']//strong[contains(.,'View a summary')]")
	private WebElementFacade msgInSmallBusinessRisk;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//h3[contains(.,'Corporate')]")
	private WebElementFacade msgInCorporateLinkage;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//h3[contains(.,'D&B Viability')]")
	private WebElementFacade msgInPredictiveScoreSec;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//h3[contains(.,'D&B PAYDEX')]")
	private WebElementFacade msgInTradePayments;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//h3[contains(.,'Summary')]")
	private WebElementFacade msgInPublicFilings;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//h3[contains(.,'Special Events')]")
	private WebElementFacade msgInSpecialEvents;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//*[@class='widget_full']//h3[contains(.,'History')]")
	private WebElementFacade msgInHistoryAndOperations;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//input[contains(@value,'Generate a Fraud Risk Score')]")
	private WebElementFacade btnInFraudRiskScore;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//h3[contains(.,'Originating Credit File')]")
	private WebElementFacade msgInAssociations;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//h3[contains(.,'Company Financials')]")
	private WebElementFacade msgInFinancials;

	@FindBy(xpath = "//*[@id='entity_header']/h2")
	private WebElementFacade companyNameEle;

	private String ajaxLoadingEleXpath = "//*[@class='ecf_page']//*[@id='widget_container']//span[contains(.,'Loading')]";

	private String dAnBReportName;

	private String compName;

	private String dunsNumberInECFPage;

	@FindBy(xpath = "//*[@id='tree_div']//table[@class='comp_doc']//tbody//tr[1]//td[1]//input")
	private WebElementFacade chBoxOptionEleForSelectCompDocs;

	private String chBoxOptionEleForSelectCompDocsXpath = "//*[@id='tree_div']//table[@class='comp_doc']//tbody//tr[1]//td[1]//input";

	@FindBy(xpath = "//*[@id='tree_div']//table[@class='comp_doc']//tbody//tr[1]//td[3]//div[1]")
	private WebElementFacade documnetDescEle;

	@FindBy(xpath = "//*[@id='tree_div']//*[@class='itm_filter']//input[contains(@value,'Download Selected')]")
	private WebElementFacade downloadSelectBtnEleInCompDocs;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@class='ecf_page']//*[@id='widget_container']//*[@class='reviewStatus']//*[@class='review_details']//span[1]")
	private WebElementFacade appStatusDetails;

	private String documnetDescription;

	private String appStatusValue;

	@FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//input[contains(@value,'Re-Decision')]")
	private WebElementFacade reDecisionBtnEle;
	
	@FindBy(xpath = "//div[@class='review_buttons']//input[@value='Reevaluate Credit']")
	private WebElementFacade reEvaluateBtnEle;

	@FindBy(xpath = "//*[@id='reevaluate_modal']//table[@class='results full']//tbody//input[contains(@value,'use_current')]")
	private WebElementFacade chkBoxOptionForUseExistingDataInReDecisionWindow;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@class='modal_buttons']//input[contains(@value,'Continue')]")
	private WebElementFacade continueBtnEleInReDecisionWindow;

	@FindBy(xpath = "//*[@id='ecf_callcreditopt']//input[contains(@value,'Accept')]")
	private WebElementFacade acceptBtnEleInAppOutcomeWindow;

	
	
	@FindBy(xpath = "//body[@class='iframe_modal']//div[@class='modal_buttons']//input[@value='Continue']")
	private WebElementFacade acceptBtnEleInAccOutcomeWindow;
	
	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//*[contains(@src,'dnbi')]")
	private WebElementFacade saveSnapShotEle;

	@FindBy(xpath = "//*[@class='ecf_header']//*[@id='infoContainer']//*[@id='entNumber']")
	private WebElementFacade resultAcNo;

	@FindBy(xpath = "//*[@id='main']//*[@id='ecf_toc_main']//*[@id='ecf_toc1']//a[contains(text(),'Aging')]")
	private WebElementFacade agingLinkEleInEcpPage;

	@FindBy(xpath = "//*[@id='cl_widget_div']//*[contains(@class,'ecfbox')]//h3")
	private WebElementFacade crLinkageParentSectionTitle;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'ecfbox')]//h3")
	private WebElementFacade yourInformationSectionTitle;

	@FindBy(xpath = "//*[@id='widget_container']//*[@class='widget_full']//table//td[contains(.,'Endorsement/Billing Reference')]")
	private WebElementFacade endorsementBilling;

	@FindBy(xpath = "//*[@id='widget_container']//*[@class='widget_full']//table//td[contains(.,'Endorsement/Billing Reference')]//following-sibling::td")
	private WebElementFacade endorsementBillingLoginid;

	//@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'summary_links')]//h3")
	@FindBy(xpath = "//*[@id='widget_container']//*[@class='summary_links']//h3[contains(.,'Small Business Risk Insight')]")
	private WebElementFacade sBRITitle;
	
	@FindBy(xpath = "//*[@id='widget_container']")
	private WebElementFacade sBRIimagetitle;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'summary_links')]//*[contains(.,'Predictive Scores')]")
	private WebElementFacade pSTitle;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'summary_links')]//*[contains(.,'Trade Payments')]")
	private WebElementFacade tradePaymentsTitle;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'summary_links')]//*[contains(.,'Public Filings')]")
	private WebElementFacade publicFillingTitle;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@id,'specialEvents')]//*[contains(.,'Special Events')]")
	private WebElementFacade specialEventsTitle;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'summary_links')]//*[contains(.,'History & Operations')]")
	private WebElementFacade historyOperationsTitle;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'summary_links')]//div//*[contains(.,'Financial')]")
	private WebElementFacade financialsTitle;
	private String financialsheader = "//*[@id='widget_container']//*[contains(@class,'summary_links')]//div//*[contains(.,'Financial')]";

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'summary_links')]//h3[contains(.,'Small Business Financial Exchange')]")
	private WebElementFacade SBEFTitle;
	
	@FindBy(xpath = "//*[@id='widget_container']//h3[contains(.,'Small Business Risk Insight')]")
	private WebElementFacade SBRITitle;
	
	//@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'summary_links')]//h3[contains(.,'Detailed Trade Risk Insight')]")
	@FindBy(xpath = "//*[@id='widget_container']//h2[contains(.,'Detailed Trade Risk Insight')]")
	private WebElementFacade DTRITitle;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'summary_links')]//h2[contains(.,'Principals')]")
	private WebElementFacade PrincipalsTitle;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@id,'intlReport')]//*[contains(.,'D&B Report')]")
	private WebElementFacade dAndBReportTitle;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(.,'Corporate Linkage')]")
	private WebElementFacade cReportTitle;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'summary_links')]//*[contains(.,'Special Events')]")
	private WebElementFacade specialEventsTitleUK;

	@FindBy(xpath = "//*[contains(@id,'companyFinancialWidget')]//select[contains(@id,'dataSourceType')]")
	private WebElementFacade dataSourceTypeList;

	@FindBy(xpath = "//*[@id='compTitle']//*[@id='pp_side_icon']//*[contains(text(),'Customize')]")
	private WebElementFacade customizeicon;

	@FindBy(xpath = "//*[@id='compTitle']//*[contains(.,'Company Summary')]")
	private WebElementFacade companySummarySection;

	@FindBy(xpath = ".//*[@id='page_title']//*[contains(.,'Company  Summary Customization')]")
	private WebElementFacade companySummaryCustomizationPageheader;

	@FindBy(xpath = "//*[@id='com_cust_us']//tr//input[@type='checkbox'][@checked='']")
	private List<WebElementFacade> allVeriablesUncheck;

	@FindBy(xpath = "//*[@id='main']//input[@type='button'][contains(@value,'Return to Company Summary')]")
	private WebElementFacade rturnTonCompanySummarybtn;

	@FindBy(xpath = ".//*[@id='widget_container']//*[contains(@class,'widget widget')]//h3[@class='moreinfo_title floatLeft']")
	private List<WebElementFacade> widgetcontainercount;

	@FindBy(xpath = "//*[@class='dash_container']//*[@class='dash_button']//input[@value='Remove Item'][not(contains(@disabled,'disabled'))]")
	private List<WebElementFacade> removeItemBtncount;

	@FindBy(xpath = "//*[@class='dash_container']//*[@class='dash_button']//input[@value='Remove Item'][not(contains(@disabled,'disabled'))]")
	private WebElementFacade removeItemBtn;
	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//*[@id='modal_buttons']//input[2]")
	private WebElementFacade dontsaved;
	
	@FindBy(xpath = "//*[@id='page_title_links']//*[contains(text(),'Edit Score Bar')]")
	private WebElementFacade editScorePageHearder;

	@FindBy(xpath = "//*[@id='pagingContainer']//*[@id='next']")
	private WebElementFacade scorePageNextBtn;

	@FindBy(xpath = "//*[@id='pagingContainer']//*[@id='numCollector']//a")
	private List<WebElementFacade> pagecount;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'view_morelink')]//strong[contains(text(),'Customize Score Bar')]")
	private WebElementFacade cSScoreBarLink;

	@FindBy(xpath = "//input[@type='button'][contains(@value,'Return to Score Bar')]")
	private WebElementFacade returnToScoreBtn;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'widget widget1')]//*[contains(.,'Customize Score Bar Button to configure the Score Bar')]")
	private WebElementFacade configureTheScoreBarMessage;

	@FindBy(xpath = "//*[contains(@class,'jspContainer')]//*[@id='scorebar1']//span[contains(@class,'scorelabel')]")
	private List<WebElementFacade> sectionCount;

	@FindBy(xpath = "//*[@id='noteForm']//input[@value='Add Note']")
	private WebElementFacade addNoteBtn;
	@FindBy(xpath = "//*[@class='iframe_modal']")
	private WebElementFacade iframemodal;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='addnote_ecf']//select")
	private WebElementFacade selectType;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='addnote_ecf']//*[@id='notation']")
	private WebElementFacade enterText;

	@FindBy(xpath = "//*[@id='NoteList']//table//tbody")
	private WebElementFacade notesCreated;

	private String notestableResult = "//*[@id='NoteList']//table//tbody";

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'ecfbox')]//h3[contains(.,'Additional Financial Statements')]")
	private WebElementFacade FinancialStatementSection;
	
	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'ecfbox')]//h3[contains(.,'Request Financial Statements')]")
	private WebElementFacade requestFinancialStatementSection;
	
	@FindBy(xpath = "//*[contains(@action,'submitRequestFinancials')]//*[contains(text(),'Company Contact Name')]//following-sibling::td//input")
	private WebElementFacade companyContactname;
	
	@FindBy(xpath = "//*[contains(@action,'submitRequestFinancials')]//*[contains(text(),'Company Email address')]//following-sibling::td//input")
	private WebElementFacade companyEmailAddress;
	
	@FindBy(xpath = "//*[@id='main']//*[@id='page_title']//h2[contains(.,'Request Financials')]")
	private WebElementFacade requestFinancialsPageHeader;
	
	@FindBy(xpath = "//*[contains(@action,'submitRequestFinancials')]//input[@type='button' and @value='Submit']")
	private WebElementFacade requestFinancialsSubmitBtn;
	
	@FindBy(xpath = "//*[contains(@id,'reqFinancialForm')]//input[@value='Request Financial Statements']")
	private WebElementFacade requestFinancialBtn;
	
	@FindBy(xpath = "//*[contains(@id,'requestFinancialsListForm')]//table[contains(@class,'results full tab_border')]//tbody//tr")
	private WebElementFacade verifyRequestFinancialdata;
	
	
	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@id,'fin_tab')]//input[@value='Add Financial']")
	private WebElementFacade addFinancialBtn;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='financial_addDiv']")
	private WebElementFacade FinancialIframe;

	@FindBy(xpath = "//*[contains(@class,'frmSecEdit')]//*[@id='Financials-DateofFinancials']")
	private WebElementFacade FinancialIframeDate;

	@FindBy(xpath = "//*[contains(@class,'frmSecEdit')]//*[@id='Financials-FinancialsPeriod']")
	private WebElementFacade FinancialIframePeriod;

	@FindBy(xpath = "//*[contains(@id,'fin_tab1')]//table[contains(@class,'results full tab_borde')]//tbody//tr")
	private WebElementFacade verifyFinancialdata;
	
	

	@FindBy(xpath = "//*[contains(@id,'fin_tab1')]//table[contains(@class,'results full tab_borde')]//tbody//tr//input[@id='delFinancial']")
	private WebElementFacade delFinancialdata;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@id,'fin_tab')]//input[@value='Delete Financials']")
	private WebElementFacade delFinancialdatabtn;

	@FindBy(xpath = "//*[contains(@id,'fin_tab1')]//table[contains(@class,'results full tab_borde')]//tbody//tr//b[contains(.,'No financials data found')]")
	private WebElementFacade verifydelFinancialdata;

	@FindBy(xpath = "//*[@id='companyFinancialWidget']//*[@id='display_bus_financials']")
	private WebElementFacade SpreadFinancialsBtn;

	@FindBy(xpath = "//*[@id='page_title']//h2[contains(.,'Spread Financials')]")
	private WebElementFacade SpreadFinancialswindowheader;

	@FindBy(xpath = "//*[@id='pageHead']//*[@id='pp_side_icon']//li//a//span")
	private WebElementFacade downloadElements;

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'ecfbox')]//h3[contains(.,'Score Summary')]")
	private WebElementFacade scorestriggered;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='ecf_page']//*[@class='widget wideWidget']//*[@class='reviewStatus']//*[contains(@value,'Send to Credit Review')]")
	private WebElementFacade SendToCreditReviewBtn;

	  @FindBy(xpath ="//*[@class='iframe_modal']//*[@class='modal_inner_content']//form")
	    private WebElementFacade Iframepopup;
	  
	   @FindBy(xpath ="//*[@class='modal_inner_content']//*[@class='ecfanalystReasons']//*[@class='comcopyarea']//b[contains(.,'Next')]")
	    private WebElementFacade nextBtnIframe;
	    
	    @FindBy(xpath = "//*[@class='iframe_modal']//*[@class='modal_buttons']//*[@value='Continue']")
	    private WebElementFacade continueBtn1;
	
	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Custom Score')]")
	private WebElementFacade CustomScoreLinkEle;

	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Audit Trail')]")
	private WebElementFacade AuditTrailtab;
	
	@FindBy(xpath = "//*[@id='aud_tab1']//*[@action='dispatchHistoryList']//table//tr//td[1]")
	private WebElementFacade AuditTrailtable1;
	@FindBy(xpath = "//*[@id='aud_tab1']//*[@action='dispatchHistoryList']//table//tr//td[2]")
	private WebElementFacade AuditTrailtable12;
	@FindBy(xpath = "//*[@id='aud_tab1']//*[@action='dispatchHistoryList']//table//tr//td[4]")
	private WebElementFacade AuditTrailtable13;

	@FindBy(xpath = "//*[@id='main']//*[@class='bgHeadBody']//div[1][@class='floatLeft']")
	private WebElementFacade requestDetails;
	
	
	@FindBy(xpath = "//*[@id='main']//*[@class='bgHeadBody']//div[2][@class='floatLeft']")
	private WebElementFacade requestedByDetails;
	
	
	@FindBy(xpath = "//*[@id='main']//*[@id='scorebar_div']")
	private WebElementFacade scorebarWidget;
	
	@FindBy(xpath = "//*[@id='main']//*[@id='pp_side_icon']//li//a")
	private WebElementFacade customizeLink;
	
	@FindBy(xpath = "//*[@id='fields_cus']//*[@id='pool']//option")
	private List <WebElementFacade> availableFieldsList;
	
	@FindBy(xpath = "//*[@id='seld_cus']//select//option")
	private List <WebElementFacade> selectedFieldsList;
	
	@FindBy(xpath = "//*[@id='sel_cus']//a[contains(@href,'copySelectedOptions')]//img")
	private WebElementFacade fieldsAddArrowBtn;
	
	@FindBy(xpath = "//*[@class='modal_buttons']//input[@value='Update List']")
	private WebElementFacade updateListBtn;
	
	@FindBy(xpath = "//*[@class='modal_buttons']//input[@value='Cancel']")
	private WebElementFacade iframecancelBtn;
	
	@FindBy(xpath = "//*[@id='main']//table//thead//th")
	private List <WebElementFacade> tableHeaderList;
	
    @FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
    private WebElementFacade iFrameElement;
    
    
    @FindBy(xpath = "//*[@id='outOfBusiness']//*[@type='radio'][@value='true']")
    private WebElementFacade oobYesRadioBtn;

    
    @FindBy(xpath = "//*[@class='modal_buttons']//input[@type='button'][@value='Continue']")
    private WebElementFacade oobContinueBtn;
    
    
    @FindBy(xpath = "//*[@id='outOfBusiness']")
    private WebElementFacade oobMessageElement;
    
    @FindBy(xpath = "//*[@id='noBackground']//h3[contains(.,'This company is out of business')]")
    private WebElementFacade outOFBusinessMessage;
    
    @FindBy(xpath = "//*[@class='widget_form']//*[contains(text(),'Registration Number')] [@class='frmTitleF']//following-sibling::td[@class='frmField']//input")
    private WebElementFacade registrationNoelement;

    @FindBy(xpath = "//*[@class='widget_form']//*[contains(text(),'Country')] [@class='frmTitleF']")
    private WebElementFacade countryelement;
    
    @FindBy(xpath = "//*[@class='widget_form']//*[contains(text(),'Country')] [@class='frmTitleF']//following-sibling::td[@class='frmField']//input")
    private WebElementFacade countryelementvalue;
    
    @FindBy(xpath = "//*[@id='main']//h3[contains(.,'Investigation Information')]")
    private WebElementFacade investigationPageHeader;
    
  
    @FindBy(xpath = ".//*[@id='main']//table//tbody//tr//td[contains(.,'Country')]//following-sibling::td[1]")
    private WebElementFacade confirmationPageCountryelement;
    
    
    @FindBy(xpath = "//*[@id='backRight']//input[@value='Next']")
    private WebElementFacade acc_next_btn;
    
    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[contains(@class,'results full')]//tbody//tr[1]//span//a[contains(.,'Preview')]")
    private WebElementFacade previewLink;
    
    @FindBy(xpath = "//*[@class='modal_content']//*[@class='modal_buttons']//input[contains(@value,'Continue')]")
    private WebElementFacade modal_ContinueBtn;
    
    
    @FindBy(xpath = "//*[@id='main']//*[@class='ecf_header']//*[@id='entNumber']")
    private WebElementFacade accNumberInEcfPage;
    
    @FindBy(xpath="//form[@id='plNoteForm']//div[@class='ecf_header']//div[@id='entity_header']/h2")
    private WebElementFacade companyNameLabel;
    
    @FindBy(xpath="//form[@id='plNoteForm']//div[@class='ecf_header']//ul[@id='duns']//li[2]")
    private WebElementFacade dunsNumberLabel;
    
    @FindBy(xpath="//form[@id='plNoteForm']//div[@class='ecf_header']/div[2]/ul[@id='tradeNames']/li[2]")
    private WebElementFacade tradeNameLabel;
    
    @FindBy(xpath="//form[@id='plNoteForm']//div[@class='DnBAddress']//ul[@class='add_listAcc']/li/span/div[1]")
    private WebElementFacade addressLabel;
    
    @FindBy(xpath="//form[@id='plNoteForm']//div[@class='DnBAddress']//ul[@class='add_listAcc']/li/span/div[2]")
    private WebElementFacade cityStateZipLabel;
    
    @FindBy(xpath="//form[@id='plNoteForm']//div[@class='DnBAddress']//ul[@class='add_listAcc']/li[2]/span")
    private WebElementFacade phoneNumberLabel;
    
    @FindBy(xpath="//form[@id='plNoteForm']//div[@class='DnBAddress']//ul[@class='add_listAcc']/li[3]/span")
    private WebElementFacade faxLabel;
    
    @FindBy(xpath="//form[@id='plNoteForm']//div[@class='DnBAddress']/ul[2]/li/span")
    private WebElementFacade locationType;
    
    @FindBy(xpath="//div[@class='DnBAddress']/Descendant::strong[contains(.,'Web Address')]")
    private WebElementFacade webAddress;
    
    @FindBy(xpath="//div[@class='ecf_page']//div[@id='widget_container']/div[2]/img[@src='/dnbi/skins/credit/us/images/img_ico/application/16x16/flag_canada.png']")
    private WebElementFacade canadaFlagDisplay;
    
    @FindBy(xpath="//div[@class='inner_header_title_bar']//div[@id='infoIcon']/span/a")
    private WebElementFacade predictiveScoresToolTip;
   
    @FindBy(xpath="//div[@class='inner_header_title_bar']//div[@id='infoIcon']/span[@class='tooltip']/span/div/p")
    private WebElementFacade predictiveScoresToolTipMessage;
    
    @FindBy(xpath="//div[@class='widget_full']//div[@class='widget_ecfbox']//div[@id='infoIcon']/span/a")
    private WebElementFacade DBViabilitySummaryToolTip;
   
    @FindBy(xpath="//div[@class='widget_full']//div[@class='widget_ecfbox']//div[@id='infoIcon']/span[@class='tooltip']/span/div/p")
    private WebElementFacade DBViabilitySummaryToolTipMessage;
    
    @FindBy(xpath="//table[@class='viability_rating']//tr[1]//div[@id='infoIcon']/span/a")
    private WebElementFacade ViabilityScoreToolTip;
   
    @FindBy(xpath="//table[@class='viability_rating']//tr[1]//div[@id='infoIcon']/span[@class='tooltip']/span/div/p")
    private WebElementFacade ViabilityScoreToolTipMessage;
    
    @FindBy(xpath="//table[@class='viability_rating']//tr[3]//div[@id='infoIcon']/span/a")
    private WebElementFacade PortfolioComparisonToolTip;
   
    @FindBy(xpath="//table[@class='viability_rating']//tr[3]//div[@id='infoIcon']/span[@class='tooltip']/span/div/p")
    private WebElementFacade PortfolioComparisonToolTipMessage;
    
    @FindBy(xpath="//table[@class='viability_rating']//tr[5]//div[@id='infoIcon']/span/a")
    private WebElementFacade DataDepthIndicatorToolTip;
   
    @FindBy(xpath="//table[@class='viability_rating']//tr[5]//div[@id='infoIcon']/span[@class='tooltip']/span/div/p")
    private WebElementFacade DataDepthIndicatorToolTipMessage;
    
    @FindBy(xpath="//table[@class='viability_rating']//tr[7]//div[@id='infoIcon']/span/a")
    private WebElementFacade CompanyProfileToolTip;
   
    @FindBy(xpath="//table[@class='viability_rating']//tr[7]//div[@id='infoIcon']/span[@class='tooltip']/span/div/p")
    private WebElementFacade CompanyProfileToolTipMessage;
    
    @FindBy(xpath="//*[@id='widget_container']/div[5]/div[1]//div[@id='infoIcon']/span/a")
    private WebElementFacade CreditCapacityToolTip;
   
    @FindBy(xpath="//*[@id='widget_container']/div[5]/div[1]//div[@id='infoIcon']/span[@class='tooltip']/span/div/p")
    private WebElementFacade CreditCapacityToolTipMessage;
    
    @FindBy(xpath="//*[@id='widget_container']/div[6]/div[1]//div[@id='infoIcon']/span/a")
    private WebElementFacade FinancialStressToolTip;
   
    @FindBy(xpath="//*[@id='widget_container']/div[6]/div[1]//div[@id='infoIcon']/span[@class='tooltip']/span/div/p")
    private WebElementFacade FinancialStressToolTipMessage;
    
    @FindBy(xpath="//*[@id='widget_container']/div[7]/div[1]//div[@id='infoIcon']/span/a")
    private WebElementFacade CreditScoreToolTip;
   
    @FindBy(xpath="//*[@id='widget_container']/div[7]/div[1]//div[@id='infoIcon']/span[@class='tooltip']/span/div/p")
    private WebElementFacade CreditScoreToolTipMessage;
    
    @FindBy(xpath="//*[@id='widget_container']/div[3]/div[1]/h3")
    private WebElementFacade clickPredictive;
    
    @FindBy(xpath="//div[@class='widget_full']/div/h3")
    private WebElementFacade dbFinancialStatement;
    
    @FindBy(xpath="//div[@class='widget_full']//table[@class='results tab_border']/tbody/tr[1]/td/strong")
    private WebElementFacade dbFinancialStatementField;
    
    @FindBy(xpath="//div[@class='widget_full']//div[@class='widget_ecfbox']/h3")
    private WebElementFacade keyBusinessRatios;
    
    @FindBy(xpath="//div[@class='widget_full']//table[@class='results tab_border']/tbody/tr[1]/td[1]")
    private WebElementFacade keyBusinessRatiosFirstValue;
    
    @FindBy(xpath="//div[@id='reqFinancialsList']//div[1]//h3")
    private WebElementFacade requestFinancialsHeading;
    
    @FindBy(xpath="//div[@id='reqFinancialsList']/form[@id='reqFinancialForm']//input[@value='Request Financial Statements']")
    private WebElementFacade requestFinancialButton;
    
    
    @FindBy(xpath="//*[@id='searchHead']/h2")
    private WebElementFacade fRSInformationHeading;
    
    @FindBy(xpath="//*[@id='generateFRSForm']//input[@value='Generate a Fraud Risk Score']")
    private WebElementFacade generateFRSBtn;
    
    @FindBy(xpath="//*[@id='pageHead']/h2")
    private WebElementFacade pageHeader;
    
    @FindBy(xpath="//*[contains(@id,'TOP_TEN_COMPANY_SUMMARY')]//tbody//tr//td[1]")
    private List<WebElementFacade> topTenResultsTable;
    
    @FindBy(xpath="//*[@id='widget_container']//h3")
    private List <WebElementFacade> cSSummaryWidgets;
    
    @FindBy(xpath="//*[@id='widget_container']//div[1][@class='widget wideWidget']")
    private WebElementFacade aDRHeaderElement;
    
    @FindBy(xpath="//*[@id='widget_container']//h3[contains(.,'No Detailed Trade Data is available')]")
    private WebElementFacade dtriNoDataElement;
   
    @FindBy(xpath="//*[@id='widget_container']//h3[contains(.,'SBRI Origination Lease Score')]")
    private WebElementFacade sbriOrls;
    
    @FindBy(xpath="//*[@id='main']//table//tbody//tr[1]//td//a[contains(@href,'/dnbi/ap/showEcf')]")
    private WebElementFacade applicationFirstRowLink;
    
    @FindBy(xpath="//*[@id='dd_inboxR']//table//tbody//tr[1]//td//a[contains(@href,'/dnbi/ap/showEcf')]")
    private WebElementFacade dmApplicationFirstrecordLink;
    
    @FindBy(xpath="//*[@id='creditScore']/div[4]/a")
    private WebElementFacade ccsViewLink;
    
    @FindBy(xpath="//*[@id='financialStress']/div[4]/a")
    private WebElementFacade fssClassViewLink;
    
    @FindBy(xpath="//*[@class='ecf_page']//*[@id='widget_container']//h3")
    private WebElementFacade tabHeaders;
    
    @FindBy(xpath="//*[@class='ng-scope']//*[@class='cl-container']//*[@class='cl-header']/h4")
    private WebElementFacade corpLinkagetabHeaders; 
    
    @FindBy(xpath="//body[@class='ng-scope']//div[@class='cmpn-header-dtl']//div[contains(text(),'Companies')]")
    private WebElementFacade corpLinkCompanies;
    @FindBy(xpath="//body[@class='ng-scope']//div[@class='cmpn-header-dtl']//div[contains(text(),'Subsidaries')]")
    private WebElementFacade corpLinkSubDom;
    @FindBy(xpath="//body[@class='ng-scope']//div[@class='cmpn-header-dtl']//div[contains(text(),'Subsidaries')]")
    private WebElementFacade corpLinkSubInt;
    @FindBy(xpath="//body[@class='ng-scope']//div[@class='cmpn-header-dtl']//div[contains(text(),'Branches')]")
    private WebElementFacade corpLinkBranchDom;
    @FindBy(xpath="//body[@class='ng-scope']//div[@class='cmpn-header-dtl']//div[contains(text(),'Branches')]")
    private WebElementFacade corpLinkBranchInt;
    @FindBy(xpath="//div[@class='cl-container']//div[@class='cl-tabs']/a[contains(text(),'Tree')]")
    private WebElementFacade CorptreeIcon;
    @FindBy(xpath="//div[@class='cl-container']//div[@class='cl-tabs']/a[contains(text(),'List')]")
    private WebElementFacade CorpListIcon;
    
    @FindBy(xpath="//div[@class='cl-container']//div[@class='cl-tabs']//*[@value='Print']")
    private WebElementFacade CorpPrintIcon;
    
    @FindBy(xpath="//*[@id='clTree']//*[@id='clTree-label']/div//*[@class='company-dtl-wrap']//*[@class='location-type']/img")
    private WebElementFacade CorpLinkageHQName;
    String CorpLinkageHQNameImg = "//*[@id='clTree']//*[@id='clTree-label']/div//*[@class='company-dtl-wrap']//*[@class='location-type']/img";
    @FindBy(xpath="//*[@class='ng-scope']//*[@class='cl-tabs-content']//*[@id='clList']/div//*[@class='dataTables_scrollBody']//*[@id='listViewTable']/tbody/tr")
    private WebElementFacade CorpLinkageListView;
    String CorpLinkageHQNameListView = "//*[@class='ng-scope']//*[@class='cl-tabs-content']//*[@id='clList']/div//*[@class='dataTables_scrollBody']//*[@id='listViewTable']/tbody/tr";
    
    @FindBy(xpath="//*[@class='ecf_page']//*[@id='widget_container']//h2")
    private WebElementFacade tabHeaders2;
    
    @FindBy(xpath="//*[@id='main']//*[@id='ecf_toc_main']//*[@id='ecf_toc1']//li[contains(a,'Corporate Linkage')]")
    private WebElementFacade corporateLinkageLink;
    
    @FindBy(xpath="//*[@id='widget_container']/div[1]/div[1]/h3")
    private WebElementFacade corporateLinkageTab;
  
    @FindBy(xpath="//*//*[@id='main']//*[@id='ecf_toc_main']//*[@id='ecf_toc1']//li[contains(a,'Detailed Trade Risk Insight')]")
    private WebElementFacade detailedTradeRiskLink;
    
    @FindBy(xpath="//div[@id='main']//input[@value='Add to Folder']")
    private WebElementFacade addToFolderBtnInSearchResults;
    
    @FindBy(xpath="//*[@id='addToFolderForm']//*[@id='to_folder_id']//option")
    private List <WebElementFacade> folderOptions;
    
    @FindBy(xpath="//*[@id='addToFolderForm']//*[@id='to_folder_id']")
    private WebElementFacade folderOptionsList;
    
    @FindBy(xpath="//*[@id='additionalHeaderForm']//table//tbody//tr/td[1]")
    private List<WebElementFacade> investigationRequestDetailsTablerows;
  
    /*******************Acc ECF****************************************************/
    @FindBy(xpath = "//*[@id='ecf_toc_main']//*[@id='ecf_toc1']/li/a[contains(text(),'Financials')]")
    private WebElementFacade financialsTab;
    @FindBy(xpath = "//*[@id='widget_container']//*[@class='summary_links']/ul/li/a[contains(text(),'Company Financials')]")
    private WebElementFacade compFinAnchor;
    @FindBy(xpath = "//*[@id='widget_container']//*[@class='summary_links']/ul/li/a[contains(text(),'Additional Financial Data')]")
    private WebElementFacade addFinDataAnchor;
    @FindBy(xpath = "//*[@id='widget_container']//*[@class='summary_links']/ul/li/a[contains(text(),'Additional Financial Statements')]")
    private WebElementFacade addFinStatementAnchor;
    @FindBy(xpath = "//*[@id='widget_container']//*[@class='summary_links']/ul/li/a[contains(text(),'Key Business Ratios')]")
    private WebElementFacade keyBusinessRatio;
    @FindBy(xpath = "//*[@id='ecf_toc_main']//*[@id='ecf_toc1']/li/a[contains(text(),'Notes & Documents')]")
    private WebElementFacade notesDocTab;
    @FindBy(xpath = "//*[@id='widget_container']//*[@id='Notes_Widget']//*[@id='NoteList']//*[@id='noteForm']//*[@id='expNoteData']/span[contains(text(),'Export')]")
    private WebElementFacade docExportlinl;
    @FindBy(xpath = "//*[@id='widget_container']//*[@id='Document_Widget']//*[@class='widget_full']//*[@value='Add Document']")
    private WebElementFacade docAddDoc;
    @FindBy(xpath = "//*[@id='widget_container']//*[@id='Document_Widget']//*[@class='widget_full']//*[@value='Delete Selected']")
    private WebElementFacade docDelSelected;
    @FindBy(xpath = "//*[@id='ecf_toc_main']//*[@id='ecf_toc1']/li/a[contains(text(),'Aging')]")
     private WebElementFacade agingAccTab;
    @FindBy(xpath = "//*[@id='ecf_toc_main']//*[@id='ecf_toc1']/li/a[contains(text(),'Associations')]")
    private WebElementFacade  asscAccTab;    
    @FindBy(xpath = "//*[@id='ecf_toc_main']//*[@id='ecf_toc1']/li/a[contains(text(),'Audit Trail')]")
    private WebElementFacade auditTrailTab;
    @FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//*[@class='widget_full']//*[@id='aud_tabs1']/a[contains(text(),'Current Event')]")
    private WebElementFacade currentEvent;	
    @FindBy(xpath = "//*[@id='aud_tab1']//*[@id='mainFirst']//*[@id='textBtn']")
    private WebElementFacade AtrialTextBttn;
    @FindBy(xpath = "//*[@id='aud_tab1']//*[@id='mainFirst']//*[@id='timelineBtn']")
    private WebElementFacade AtrialTimeLineBttn;
    @FindBy(xpath = "//*[@id='text']/table/tbody/tr/td/form/table/tbody/tr/td[5]/a")
    private WebElementFacade AtrialTextElementsDisplayed;
    @FindBy(xpath = "//div//*[@id='header']//*[@class='main-header clearfix']/h1[contains(text(),'DNBi Audit Trail Time Line')]")
    private WebElementFacade AtrialTimeLineElementsDisplayed;
    @FindBy(xpath = "//*[@id='widget_container']//*[@id='agingList']//*[@id='agingForm']/span//*[@id='agingOption']//option[contains(text(),'Aging Records')]")
    private WebElementFacade AgingViewDropAgRec;
    @FindBy(xpath = "//*[@id='widget_container']//*[@id='agingList']//*[@id='agingForm']/span//*[@id='agingOption']//option[contains(text(),'Aging Trend Graph')]")
    private WebElementFacade AgingViewDropAgTrnd;
    @FindBy(xpath = "//*[@id='widget_container']//*[@id='agingList']//*[@id='agingForm']/span//*[@id='agingOption']//option[contains(text(),'Aging Trend Summary')]")
    private WebElementFacade AgingViewTrndSummry;
    @FindBy(xpath = "//*[@id='ecf_toc_main']//*[@id='ecf_toc1']/li/a[contains(text(),'Custom Scores')]")
    private WebElementFacade customScoreTab;
    @FindBy(xpath = "//*[@class='ecf_page']//*[@id='widget_container']//*[@id='scoreTrendWidget']/form/table/tbody/tr[1]")
    private WebElementFacade customScoreNameDisplayed;
   
    @FindBy(xpath = "//*[@id='widget_container']//iframe[@id='form-iframe']")
    private WebElementFacade crpIframe;
    private static String accNumberECF;
      
	public static String getAccNumberECF() {
		return accNumberECF;
	}
		String investigationRequestDetailsTableXpath="//*[@id='additionalHeaderForm']//table//tbody";
	String aDRHeaderXpath="//*[@id='widget_container']//div[1][@class='widget wideWidget']";
	String fRSPageNewWindowHeader="//*[@id='pageHead']/h2";
	String dunsRightNewWindowHeader="//*[contains(@class,'Page') or contains(@id,'page')]";
	String fRSInformationHeadingXpath="//*[@id='searchHead']/h2";
	String modal_ContinueBtnXpath="//*[@class='modal_content']//*[@class='modal_buttons']//input[contains(@value,'Continue')]";
    private String searchResultsConatiner="//*[@class='outerDiv']//*[@id='main']//*[contains(@class,'results full')]//thead";
    String backtoReportBtnxpath="//*[@id='main']//input[contains(@value,'Back To Report')][@type='button']";
    String publicFilingTabxpath="//*[@id='widget_container']//h3[contains(.,'Public Filings')]";
	String oobYesBtnXpath="//*[@id='outOfBusiness']//*[@type='radio'][@value='true']";
	private String scoresscetion = "//*[@id='widget_container']//*[contains(@class,'ecfbox')]//h3[contains(.,'Score Summary')]";
	private String auditTrailscetion = "//*[@id='widget_container']//*[contains(@class,'ecfbox')]//h3[contains(.,'Audit Trail')]";
private String saveSnapshotIframeIDSelectEle1 = "//*[@id='addnote_ecf']//*[@class='noteerror_ecf']//select";
	private String sfWindowhearder = "//*[@id='page_title']//h2[contains(.,'Spread Financials')]";

	private String financialTableHeader = "//*[contains(@id,'fin_tab1')]//table[contains(@class,'results full tab_borde')]//thead";
	
	private String requestFinancialTableHeader = "//*[contains(@id,'requestFinancialsListForm')]//table[contains(@class,'results full tab_border')]//thead";
	
	private String requestFinancialsHeader="//*[@id='main']//*[@id='page_title']//h2[contains(.,'Request Financials')]" ;
	
	private String folderTable = "//*[@id='main']//table//thead";
	
	private String requestDetailsHeader="//*[@id='main']//*[@class='ecf_header']//*[@id='entity_header']//h2";
	String cnfBtnxpath="//*[@id='main']//*[@class='compHome_newFolder']//input[@value='Create New Folder']";
	private String CSSectionHearder = "//*[@id='compTitle']//*[contains(.,'Company Summary')]";
	private String allWidgets = "//*[@id='widget_container']//*[contains(@class,'widget widget')]//h3[@class='moreinfo_title floatLeft']";
	String framexpath="//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']";
	String OIConfirmPageHeader="//*[@id='pageHead']//h2";
	private int widgetCount;
	private WebElement veriableName;
	private WebElement veriableName1;
	private String widgetavailable = "0";
	private String notestable = "//*[@id='NoteList']//table//thead";
	int resultflag=0;
	List<String> Fieldvalues = new ArrayList<String> ();
	public List<String> getFieldvalues() {
		return Fieldvalues;
	}

	int i;
	boolean deletevalue;
	private WebElement Sectionname;

	private WebElement Foldername;

	private String loginIdDisplayed;

	private String accntNoInResults;

	public String getAccntNoInResults() {
		return accntNoInResults;
	}

	private String getEnabledNotification;

	boolean detailsTradDispVal;

	public boolean getDetailsTradDispVal() {
		return detailsTradDispVal;
	}

	boolean financialsInfoDispVal;

	public boolean getFinancialsInfoDispVal() {
		return financialsInfoDispVal;
	}

	boolean notesAdnDocsInfoDispVal;

	public boolean getNotesAdnDocsInfoDispVal() {
		return notesAdnDocsInfoDispVal;
	}

	boolean customScoreInfoDispVal;

	public boolean getCustomScoreInfoDispVal() {
		return customScoreInfoDispVal;
	}

	boolean auditTrailInfoDispVal;

	public boolean getAuditTrailInfoDispVal() {
		return auditTrailInfoDispVal;
	}

	boolean smallBusinessRiskInfoDispVal;

	public boolean getSmallBusinessRiskInfoDispVal() {
		return smallBusinessRiskInfoDispVal;
	}

	boolean corporateInfoDispVal;

	public boolean getCorporateInfoDispVal() {
		return corporateInfoDispVal;
	}

	boolean predictiveScoreInfoDispVal;

	public boolean getPredictiveScoreInfoDispVal() {
		return predictiveScoreInfoDispVal;
	}

	boolean tradePaymentInfoDispVal;

	public boolean getTradePaymentInfoDispVal() {
		return tradePaymentInfoDispVal;
	}

	boolean publicFilingsInfoDispVal;

	public boolean getPublicFilingsInfoDispVal() {
		return publicFilingsInfoDispVal;
	}

	boolean specialEventInfoDispVal;

	public boolean getSpecialEventInfoDispVal() {
		return specialEventInfoDispVal;
	}

	boolean historyAndOperInfoDispVal;

	public boolean getHistoryAndOperInfoDispVal() {
		return historyAndOperInfoDispVal;
	}

	boolean fraudRiskScoreInfoDispVal;

	public boolean getFraudRiskScoreInfoDispVal() {
		return fraudRiskScoreInfoDispVal;
	}

	boolean associationsInfoDispVal;

	public boolean getAssociationsInfoDispVal() {
		return associationsInfoDispVal;
	}

	boolean dandBReportDispVal;

	public boolean getDandBReportDispVal() {
		return dandBReportDispVal;
	}

	boolean ecfSecDispVal;

	public boolean getEcfSecDispVal() {
		return ecfSecDispVal;
	}

	boolean snapshotadded;

	public boolean isSnapshotadded() {
		return snapshotadded;
	}

	private String sanpshot;

	// Get the DUNS Number from ECF Page
	public String getDUNSNumberFromECFPage() {
		if (dunsNumberInECF.isVisible()) {
			dunsNumberInECFPage = dunsNumberInECF.getText();
		}
		if (modelpopupxpath.isVisible()) {
			modelpopupxpath.clear();
		}
		return dunsNumberInECFPage;
	}
	
	public String getDUNSNumberFromSnapPage() {
		if (dunsNumberInECF.isVisible()) {
			dunsNumberInECFPage = dunsNumberInECF.getText();
		}

		return dunsNumberInECFPage;
	}
	
	

	public String getReportName() {
		if (ecfPageSectionsEle.isVisible()) {
			if (dandbReportLink.isVisible()) {
				dandbReportLink.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						ajaxLoadingEleXpath);

				dAnBReportName = dAndbReportNameEle.getText();
			}
		}

		return dAnBReportName;
	}

	public String getCompanyNameFromECFPage() {
		String compNameInECF = companyNameEle.getText();

		if (compNameInECF.contains(":")) {
			String slitCompName[] = compNameInECF.split(":");
			compName = slitCompName[1];
		} else {
			compName = compNameInECF;
		}

		return compName;
	}

	/**********************************************************************************************
	 * Function: performOrderInvestigationFromSearchResults Method Description:
	 * Click the Order Investigation Button in ECF Page and perform order
	 * investigation
	 * 
	 ***********************************************************************************************/
	public void clickOrderInvestigationInECFPage() {
		if (OrderInvestigationBtnEle.isVisible()) {

			OrderInvestigationBtnEle.click();
			UIHelper.waitForPageToLoad(getDriver());
		}
	}

	public void putOrderInvestigationInEcF() {
		if (OrderInvestigationBtnEle.isVisible()) {

			OrderInvestigationBtnEle.click();
			UIHelper.waitForPageToLoad(getDriver());
			/*if (orderBtn.isDisplayed()) {
				orderBtn.click();
				backToReportBtnEle.waitUntilPresent();
				backToReportBtnEle.click();
				UIHelper.waitForPageToLoad(getDriver());
				
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						CSSectionHearder);

			}*/
		}
	}

	public void performOrderInvestigationFromECFPage(
			String additionalInformation, String levelOfInvestigation,
			String emailTheInvestReport) throws Exception {

		try {
			if (orderBtn.isDisplayed()) {
				additionalInfoTextArea.type(additionalInformation);

				if (levelOfInvestigation.equalsIgnoreCase("Standard")) {
					standardRadioBtnEle.click();
				} else if (levelOfInvestigation.equalsIgnoreCase("Priority")) {
					priorityRadioBtnEle.click();
				}

				if (emailTheInvestReport.equalsIgnoreCase("Yes")) {
					emailInvestReportChkboxEle.click();
				}

				orderBtn.waitUntilPresent();

				orderBtn.click();
				backToReportBtnEle.waitUntilPresent();
			}

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public void clickBackToReport() {
		backToReportBtnEle.waitUntilClickable();
		backToReportBtnEle.click();
		dashBoardTabEle.waitUntilPresent();
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
				ajaxLoadingEleXpath);
	}

	/**********************************************************************************************
	 * Function: validateGFTFromECFPage Method Description: 1. Click the GFT
	 * Link in ECF PAge 2. Get the DNBi Pricing Screen alert message description
	 * 
	 ***********************************************************************************************/
	public String validateGFTFromECFPage() {
		if (globalFamilyTreeLinkEle.isVisible()) {
			globalFamilyTreeLinkEle.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
					ajaxLoadingEleXpath);

			if (orderGFTBtnEle.isVisible()) {
				orderGFTBtnEle.click();

				iFrameEle.waitUntilPresent();

				if (iFrameEle.isVisible()) {
					getDriver().switchTo().frame(iFrameEle);

					if (okButtonEleInDNBiPricingScreen.isVisible()) {
						okButtonEleInDNBiPricingScreen.click();
						getDriver().switchTo().defaultContent();
						UIHelper.waitForPageToLoad(getDriver());
						UIHelper.waitForInvisibilityOfAjaxImgByXpath(
								getDriver(), imageLoadingXpath);
					} else {
						dnbiPricingScreenText = dnbiPricingScreenTextEle
								.getText();
						closeFrameEle.click();
						getDriver().switchTo().defaultContent();
					}
				}
			}
		}

		return dnbiPricingScreenText;
	}

	/**********************************************************************************************
	 * Function: getCompanyDescriptionFromECFPage Method Desctription: 1. Click
	 * the Company Documents Link in ECF Page 2. Select the first document and
	 * Download 3. Get Company Document Description
	 * 
	 * 
	 ***********************************************************************************************/
	public String getCompanyDescriptionFromECFPage() {
		if (compDocumentsLinkEle.isVisible()) {
			compDocumentsLinkEle.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
					ajaxLoadingEleXpath);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					chBoxOptionEleForSelectCompDocsXpath);

			if (chBoxOptionEleForSelectCompDocs.isVisible()) {
				chBoxOptionEleForSelectCompDocs.click();
				documnetDescEle.waitUntilPresent();

				documnetDescription = documnetDescEle.getText();

				downloadSelectBtnEleInCompDocs.click();
				UIHelper.waitForPageToLoad(getDriver());
			}
		}

		return documnetDescription;
	}

	/****************************************************************************************
	 * Function: Verify the placed application details in ECF Page. Input : NA
	 * Action : getText Output : Should get the placed application data in ECF
	 * Page.
	 ****************************************************************************************/
	public String getApplicationStatusFromECFPage() {
		try {
			// Capturing the newly placed application Status
			String statusValue = appStatusDetails.getText();
			appStatusValue = statusValue.replace("Status: ", "");

		} catch (Exception e) {
			throw e;
		}

		return appStatusValue;
	}

	/****************************************************************************************
	 * Function: Verify Application Re-Decisioning in ECF Page. Input : NA
	 * 
	 ****************************************************************************************/
	public void validateApplicationReDecisioning() {

			if (reDecisionBtnEle.isVisible()) {
				reDecisionBtnEle.click();

				iFrameEle.waitUntilPresent();

				getDriver().switchTo().frame(iFrameEle);

				if (chkBoxOptionForUseExistingDataInReDecisionWindow
						.isVisible()) {
					chkBoxOptionForUseExistingDataInReDecisionWindow.click();

					continueBtnEleInReDecisionWindow.click();
					UIHelper.waitForPageToLoad(getDriver());

					if (acceptBtnEleInAppOutcomeWindow.isVisible()) {
						acceptBtnEleInAppOutcomeWindow.click();
						UIHelper.waitForPageToLoad(getDriver());
						UIHelper.waitForInvisibilityOfAjaxImgByXpath(
								getDriver(), ajaxLoadingEleXpath);
					}
				}
			}

	}
	
	
	public void validateAccountReevaluate() {

			if (reEvaluateBtnEle.isVisible()) {
				reEvaluateBtnEle.click();

				iFrameEle.waitUntilPresent();

				getDriver().switchTo().frame(iFrameEle);

				if (chkBoxOptionForUseExistingDataInReDecisionWindow
						.isVisible()) {
					chkBoxOptionForUseExistingDataInReDecisionWindow.click();

					continueBtnEleInReDecisionWindow.click();
					UIHelper.waitForPageToLoad(getDriver());

				
					
					if(acceptBtnEleInAccOutcomeWindow.isDisplayed()){
						acceptBtnEleInAccOutcomeWindow.click();
						UIHelper.waitForPageToLoad(getDriver());
					}
					
					
				}
			}

	}

	// Add product to specific folder in ECF Page
	public void addProducttoSpecificFolder(String folderName)
			throws InterruptedException, Exception {

		try {
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
					loadingImgXpath);
			// waitFor(3000).milliseconds();
			if (ecfHeaderEle.isVisible()) {

				UIHelper.highlightElement(getDriver(), ecfHeaderEle);

			}

			if (searchResultsnapShotSideiconAddFolderEle.isVisible()) {
				searchResultsnapShotSideiconAddFolderEle.waitUntilClickable();
				searchResultsnapShotSideiconAddFolderEle.click();

				iFrameEle.waitUntilPresent();
				// waitFor(3000).milliseconds();
				getDriver().switchTo().frame(iFrameEle);
			}

			boolean boolframeModaladdToFolderForm = false;

			try {

				if (frameCompanyToAddFolderYesEle.isVisible()) {

					frameCompanyToAddFolderYesEle.click();
					frameModaladdToFolderFromEle.waitUntilPresent();

					if (frameModaladdToFolderFromEle.isVisible()) {

						UIHelper.getAllAvailableOptions(
								frameModaladdToFolderFromEle,
								boolframeModaladdToFolderFormList);

					}
				} else {
					if (frameModaladdToFolderFromEle.isVisible()) {

						UIHelper.getAllAvailableOptions(
								frameModaladdToFolderFromEle,
								boolframeModaladdToFolderFormList);

					}
				}

				for (String boolframeModaladdToFolderFormListData : boolframeModaladdToFolderFormList) {

					if (StringUtils.containsIgnoreCase(
							boolframeModaladdToFolderFormListData, folderName)) {

						boolframeModaladdToFolderForm = true;

						break;

					}

				}

			} catch (Exception e) {

			}

			if (boolframeModaladdToFolderForm) {

				if (frameModaladdToFolderFromEle.isVisible()) {

					frameModaladdToFolderFromEle.selectByVisibleText(folderName
							.toString().trim());

					searchResultsnapShotAddFolderSubmit.click();

					getDriver().switchTo().defaultContent();
					UIHelper.waitForPageToLoad(getDriver());
				}

				actionButtonsEle.waitUntilPresent();

			} else {

				if (ecfaddfolderCreateFolderasNew.isVisible()) {
					ecfaddfolderCreateFolderasNew.click();

					iFrameEle.waitUntilPresent();
					getDriver().switchTo().frame(iFrameEle);

				}

				if (newFolderName.isVisible()) {

					if (!folderName.isEmpty() && folderName != null) {

						newFolderName.type(folderName);

					} else {

						newFolderName.type("AutomationFolder");
					}

				}

				if (newFolderNameAlertProfile.isVisible()) {

					newFolderNameAlertProfile.selectByVisibleText("Standard");

					searchResultsnapShotAddFolderSubmit.click();

					getDriver().switchTo().defaultContent();
					UIHelper.waitForPageToLoad(getDriver());

					actionButtonsEle.waitUntilPresent();

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Save the Snapshot in ECF Page
	public void saveaSnapshot() {
			UIHelper.waitForPageToLoad(getDriver());
			if (ecfHeaderEle.isVisible()) {
				UIHelper.highlightElement(getDriver(), ecfHeaderEle);
			}
				if (saveASnapshotEle.isVisible()) {

					saveASnapshotEle.click();

					saveSnapShotEle.waitUntilPresent();
					getDriver().switchTo().frame(saveSnapShotEle);
					UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
							saveSnapshotIframeIDSelectXpath);
				}
					
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						saveSnapshotIframeIDSelectEle1);
						saveSnapshotIframeIDSelectEle
								.selectByVisibleText("Everyone");
					
				
						System.out.println("Select Everyone and moving to Text are now**********************");
					saveSnapshotnotationTextAreaEle.sendKeys("Hello");

					saveSnapshotSaveBTNEle.waitUntilClickable();
					saveSnapshotSaveBTNEle.click();

					getDriver().switchTo().defaultContent();
					UIHelper.waitForPageToLoad(getDriver());
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							loadingImgXpath);
				
	}

	public void resultAcntNoCheck() throws Exception {

		try {
			resultAcNo.waitUntilPresent();
			accntNoInResults = resultAcNo.getText().trim();
		} catch (Exception E) {

			// throw E;
		}
	}

	public void clickAging() throws Exception {

		try {

			// Aging link click
			agingLinkEleInEcpPage.click();

		} catch (Exception E) {

			// throw E;
		}

	}

	// Validate Submitted notification in ECF Page
	public String validateManageNotificationsInECFPage(String notificationName)
			throws Exception {
		try {
			sendNotification.click();
			iFrameEle.waitUntilPresent();
			getDriver().switchTo().frame(iFrameEle);

			notificationNameXpath = notificationNameXpath.replace("FIFA",
					notificationName);
			notificationsDropdownEle.selectByVisibleText(notificationName);
			// waitFor(2000).milliseconds();
			WebElementFacade notificationNameEle = find(By
					.xpath(notificationNameXpath));
			getEnabledNotification = notificationNameEle.getText();

			sendBtnInIframe.click();
			getDriver().switchTo().defaultContent();
			sendNotificationEle.waitUntilPresent();

		} catch (Exception e) {
			// throw e;
		}

		return getEnabledNotification;
	}

	/****************************************************************************************
	 * Function: Click the all 'ECF Page Tab links' in ECF Page. Input : NA
	 * Action : Click and getText Output : ECF Page Tab links should be click
	 * and get & store the confirmation message data in variable from ECF Page.
	 ****************************************************************************************/
	public void clickAllTabLinksInECFPage() {
		try {

			if (ecfPageSectionsEle.isVisible()) {
				ecfSecDispVal = true;
				if (dandbReportLink.isVisible()) {
					dandbReportLink.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							ajaxLoadingEleXpath);

					dandBReportDispVal = !warningMsgEle.isVisible();
				}

				if (detailedTradeRiskInsightLink.isVisible()) {
					detailedTradeRiskInsightLink.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							ajaxLoadingEleXpath);

					detailsTradDispVal = !warningMsgEle.isVisible();
				}

				if (smallBusinesRiskLinkEle.isVisible()) {
					smallBusinesRiskLinkEle.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							ajaxLoadingEleXpath);

					smallBusinessRiskInfoDispVal = msgInSmallBusinessRisk
							.isVisible();
				}

				if (corporateLinkageLinkEle.isVisible()) {
					corporateLinkageLinkEle.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							ajaxLoadingEleXpath);

					corporateInfoDispVal = msgInCorporateLinkage.isVisible();
				}

				if (predictiveScoresLinkEle.isVisible()) {
					predictiveScoresLinkEle.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							ajaxLoadingEleXpath);

					predictiveScoreInfoDispVal = msgInPredictiveScoreSec
							.isVisible();
				}

				if (tradePaymentsLinkEle.isVisible()) {
					tradePaymentsLinkEle.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							ajaxLoadingEleXpath);

					tradePaymentInfoDispVal = msgInTradePayments.isVisible();
				}

				if (publicFilingsLinkEle.isVisible()) {
					publicFilingsLinkEle.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							ajaxLoadingEleXpath);

					publicFilingsInfoDispVal = msgInPublicFilings.isVisible();
				}

				if (financialsLinkEle.isVisible()) {
					financialsLinkEle.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							ajaxLoadingEleXpath);

					financialsInfoDispVal = msgInFinancials.isVisible();
				}

				if (notesAdnDocsLinkEle.isVisible()) {
					notesAdnDocsLinkEle.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							ajaxLoadingEleXpath);

					notesAdnDocsInfoDispVal = !noNotesOrDocsEle.isVisible();
				}

				if (specialEventsLinkEle.isVisible()) {
					specialEventsLinkEle.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							ajaxLoadingEleXpath);

					specialEventInfoDispVal = msgInSpecialEvents.isVisible();
				}

				if (historyAndOperationsLinkEle.isVisible()) {
					historyAndOperationsLinkEle.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							ajaxLoadingEleXpath);

					historyAndOperInfoDispVal = msgInHistoryAndOperations
							.isVisible();
				}

				if (fraudRiskScoreLinkEle.isVisible()) {
					fraudRiskScoreLinkEle.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							ajaxLoadingEleXpath);

					fraudRiskScoreInfoDispVal = btnInFraudRiskScore.isVisible();
				}

				if (associationsLinkEle.isVisible()) {
					associationsLinkEle.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							ajaxLoadingEleXpath);

					associationsInfoDispVal = msgInAssociations.isVisible();
				}

				if (customScoresLinkEle.isVisible()) {
					customScoresLinkEle.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							ajaxLoadingEleXpath);

					customScoreInfoDispVal = !noCustomScoreEle.isVisible();
				}

				if (auditTrailLinkEle.isVisible()) {
					auditTrailLinkEle.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							ajaxLoadingEleXpath);

					auditTrailInfoDispVal = auditCurrentEventConfirmValEle
							.isVisible();
				}
			}
		} catch (Exception e) {
			throw e;
		}

	}

	public void click_CoroporateLinkageTab() {
		try {
			if (corporateLinkageLinkEle.isVisible()) {
				corporateLinkageLinkEle.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						ajaxLoadingEleXpath);

			}
		} catch (Exception e) {
			throw e;
		}
	}

	public boolean getParentSectionTitle() {
		try {
			if (crLinkageParentSectionTitle.isVisible()) {
				// UIHelper.highlightElement(getDriver(),
				// crLinkageParentSectionTitle);
				return true;

			} else {
				return false;
			}
		} catch (Exception e) {
			throw e;
		}

	}

	public boolean getSubsidiariesDomesticTitle() {
		try {
			if (crLinkageParentSectionTitle.isVisible()) {
				// UIHelper.highlightElement(getDriver(),
				// crLinkageParentSectionTitle);
				return true;

			} else {
				return false;
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public boolean getSubsidiariesInternationalTitle() {
		try {
			if (crLinkageParentSectionTitle.isVisible()) {
				// UIHelper.highlightElement(getDriver(),
				// crLinkageParentSectionTitle);
				return true;

			} else {
				return false;
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public boolean getBranchesDomesticTitle() {
		try {
			if (crLinkageParentSectionTitle.isVisible()) {
				// UIHelper.highlightElement(getDriver(),
				// crLinkageParentSectionTitle);
				return true;

			} else {
				return false;
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public boolean getBranchesInternationalTitle() {
		try {
			if (crLinkageParentSectionTitle.isVisible()) {
				// UIHelper.highlightElement(getDriver(),
				// crLinkageParentSectionTitle);
				return true;

			} else {
				return false;
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void click_YourInformationTab() {
				yourInformationLinkEle.click();
				UIHelper.waitForPageToLoad(getDriver());
				
				yourInformationSectionTitle.waitUntilPresent();

	}

	public String verifyLoginIDInEndorsement() {

			UIHelper.highlightElement(getDriver(), endorsementBilling);
			loginIdDisplayed = endorsementBillingLoginid.getText();
		return loginIdDisplayed;
	}

	public void click_SBRITab() {
		try {
			if (smallBusinesRiskLinkEle.isVisible()) {
				smallBusinesRiskLinkEle.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						ajaxLoadingEleXpath);

				if (sBRITitle.isVisible()) {

					sBRITitle.waitUntilPresent();
				} else if (sBRIimagetitle.isVisible()) {

				}

			}
		} catch (Exception e) {
			throw e;
		}
	}

	public boolean verifySBRISections(String fieldname) {
		try {
			System.out.println("Field Name is:****************"+fieldname);
			Sectionname = (getDriver().findElement(By.xpath("//*[@id='widget_container']//*[contains(@class,'ecfbox')]//h3[contains(.,'"+fieldname+"')]")));
			if (Sectionname.isDisplayed()) {
				return true;

			} else if (sBRIImageEle.isVisible()) {
				return true;
			} else if (noSBRIDataMssg.isVisible()){
				return false;
			} else{
				return true;
			}
			
		} catch (Exception e) {
			throw e;
		}
	}
	
	public boolean verifyDTRISections(String fieldname) {
		try {
			System.out.println("Field Name is:****************"+fieldname);
			Sectionname = (getDriver().findElement(By.xpath("//*[@id='widget_container']//*[contains(@class,'widget wideWidget')]//h3[contains(.,'"+fieldname+"')]")));
			if (Sectionname.isDisplayed()) {
				return true;
			} else if (dTRIImageEle.isVisible()) {
				return true;
			} else if (noDTRIDataMssg.isVisible()){
				return true;
			} else{
				return false;
		  } 
		}catch (Exception e) {
			throw e;
		}
	}
	public boolean verifyCompanyOverview(){
		
		UIHelper.highlightElement(getDriver(), companyOverview);
		if(companyOverview.isVisible()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean dbPaydexSection(){
		
		UIHelper.highlightElement(getDriver(), dbPaydex);
		if(dbPaydex.isVisible()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean verifyCompanyOverviewCA(){
		
		UIHelper.highlightElement(getDriver(), companyOverview);
		if(companyOverview.isVisible()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean verifyLocationMapCA(){
		UIHelper.highlightElement(getDriver(), locationMapCA);
		if(locationMapCA.isVisible()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean dbPaydexYearlyTrendSection(){
		
		UIHelper.highlightElement(getDriver(), paydexYearlyTrend);
		if(paydexYearlyTrend.isVisible()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean verifyLocationMap(){
		UIHelper.highlightElement(getDriver(), locationMap);
		if(locationMap.isVisible()){
			return true;
		}
		else 
			return false;
	}

	public void click_PredictiveScoresTab() {
		try {
			if (predictiveScoresLinkEle.isVisible()) {
				predictiveScoresLinkEle.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						ajaxLoadingEleXpath);
				pSTitle.waitUntilPresent();

			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void click_TradePaymentsTab() {
		try {
			if (tradePaymentsLinkEle.isVisible()) {
				tradePaymentsLinkEle.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						ajaxLoadingEleXpath);

				tradePaymentsTitle.waitUntilPresent();

			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void click_PublicFilingsTab() {
		try {
				publicFilingsLinkEle.isVisible();
				publicFilingsLinkEle.click();
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), publicFilingTabxpath);
			} catch (Exception e) {
			
		}
	}

	public void click_SpecialEventsTab() {
		try {
			if (specialEventsLinkEle.isVisible()) {
				specialEventsLinkEle.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						ajaxLoadingEleXpath);
				// specialEventsTitle.waitUntilPresent();

			}
		} catch (Exception e) {
			throw e;
		}
	}

	public boolean getSpecialEventsTitle() {
		try {
			if (specialEventsTitle.isVisible()
					|| specialEventsTitleUK.isVisible()) {
				// UIHelper.highlightElement(getDriver(), specialEventsTitle);
				return true;

			} else {
				return false;
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void click_HistoryOperationsTab() {
		try {
			if (historyAndOperationsLinkEle.isVisible()) {
				historyAndOperationsLinkEle.click();
				UIHelper.waitForPageToLoad(getDriver());

			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void click_FinancialsTab() {
		try {
			if (financialsLinkEle.isVisible()) {
				financialsLinkEle.click();
				/*
				 * UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
				 * ajaxLoadingEleXpath); financialsTitle.waitUntilPresent();
				 */
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						financialsheader);

			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void click_SBFETab() {
		try {
			if (SBFELinkEle.isVisible()) {
				SBFELinkEle.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						ajaxLoadingEleXpath);
				SBEFTitle.waitUntilPresent();

			}
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void click_SBRIUSTab() {
		try {
			if (SBRILinkEle.isVisible()) {
				SBRILinkEle.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						ajaxLoadingEleXpath);
				SBRITitle.waitUntilPresent();
			}
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void click_DTRITab(){
		try {
			if (DTRILinkEle.isVisible()) {
				DTRILinkEle.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						ajaxLoadingEleXpath);
				DTRITitle.waitUntilPresent();
			}
		} catch (Exception e) {
			throw e;
		}
	}
	

	public void click_PrincipalsTab() {
		try {
			if (principalsLinkEle.isVisible()) {
				principalsLinkEle.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						ajaxLoadingEleXpath);
				PrincipalsTitle.waitUntilPresent();

			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void select_EdgarOtion(String Option) {
		try {
			if (dataSourceTypeList.isVisible()) {
				dataSourceTypeList
						.selectByVisibleText(Option.toString().trim());
				// waitFor(2000).milliseconds();
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void set_Filter_For_Snapshot_Folder(String duns) {
		try {

			tableSnapshotFolder.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), tableSnapshotFolder);
waitFor(3000).milliseconds();
			if (subFilterSnpshotFolder.isVisible()) {
				subFilterSnpshotFolder.selectByVisibleText("Created After ...");
				// waitFor(2000).milliseconds();
				UIHelper.highlightElement(getDriver(), dateFilterSnpshotFolder);
				// Create object of SimpleDateFormat class and decide the format
				DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
				// get current date time with Date()
				Date date = new Date();
				// Now format the date

				String date1 = dateFormat.format(date);

				dateFilterSnpshotFolder.sendKeys(date1);
				UIHelper.highlightElement(getDriver(), applyBtnrSnpshotFolder);

				applyBtnrSnpshotFolder.click();
				tableSnapshotFolder.waitUntilPresent();
				if (viewlistListbox.isVisible()) {
					UIHelper.highlightElement(getDriver(), viewlistListbox);
					viewlistListbox.selectByVisibleText("100");
					tableSnapshotFolder.waitUntilPresent();
					viewlistListbox.waitUntilPresent();

				}

				List<WebElement> options = getDriver()
						.findElements(
								By.xpath("//*[@id='main']/table[contains(@class,'results full_company')]/tbody/tr/td[2]/span/a"));

				for (WebElement option : options) {
					System.out.println("snapshot folder added"
							+ option.getText());
					if (option.getText().contains(duns)) {

						sanpshot = "2";
						System.out.println("----------------- " + sanpshot);
						break;
					} else {
						sanpshot = "3";
						System.out.println("----------------- " + sanpshot);
					}
				}

				if (sanpshot.equals("3")) {
					// less than one day from current date
					Calendar cal = Calendar.getInstance();
					cal.add(Calendar.DATE, -1);
					Date dateBefore30Days = cal.getTime();
					String date2 = dateFormat.format(dateBefore30Days);
					dateFilterSnpshotFolder.clear();
					dateFilterSnpshotFolder.sendKeys(date2);
					System.out
							.println("date2 part yesterdays date-----------------"
									+ date2);
					UIHelper.highlightElement(getDriver(),
							applyBtnrSnpshotFolder);

					applyBtnrSnpshotFolder.click();
					tableSnapshotFolder.waitUntilPresent();
					if (viewlistListbox.isVisible()) {
						UIHelper.highlightElement(getDriver(), viewlistListbox);
						viewlistListbox.selectByVisibleText("100");
						tableSnapshotFolder.waitUntilPresent();
						viewlistListbox.waitUntilPresent();
					}
					List<WebElement> options1 = getDriver()
							.findElements(
									By.xpath("//*[@id='main']/table[contains(@class,'results full_company')]/tbody/tr/td[2]/span/a"));

					for (WebElement option : options1) {
						System.out.println("snapshot folder added"
								+ option.getText());
						if (option.getText().contains(duns)) {

							sanpshot = "2";
							System.out.println("----------------- " + sanpshot);
							break;
						} else {
							sanpshot = "3";
							System.out.println("----------------- " + sanpshot);
						}
					}

				}
				if (sanpshot.equals("2")) {
					snapshotadded = true;
				} else {
					snapshotadded = false;
				}

			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void set_Filter_For_Acount_Folder(String companyname) {
		try {

			tableSnapshotFolder.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), tableSnapshotFolder);
			if (viewFilterFolder.isVisible()) {
				viewFilterFolder.selectByVisibleText("Accounts");
				if (subFilterSnpshotFolder.isVisible()) {
					subFilterSnpshotFolder
							.selectByVisibleText("With Changes Since ...");
					// waitFor(2000).milliseconds();
					UIHelper.highlightElement(getDriver(),
							dateFilterSnpshotFolder);
					// Create object of SimpleDateFormat class and decide the
					// format
					DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy ");
					// get current date time with Date()
					Date date = new Date();
					// Now format the date

					String date1 = dateFormat.format(date);
					System.out.println("----------------" + date1);
					dateFilterSnpshotFolder.sendKeys(date1);
					UIHelper.highlightElement(getDriver(),
							applyBtnrSnpshotFolder);
					applyBtnrSnpshotFolder.click();
					tableSnapshotFolder.waitUntilPresent();
					viewlistListbox.waitUntilPresent();
					UIHelper.highlightElement(getDriver(), viewlistListbox);
					viewlistListbox.selectByVisibleText("100");
					tableSnapshotFolder.waitUntilPresent();
					viewlistListbox.waitUntilPresent();
					List<WebElement> options = getDriver()
							.findElements(
									By.xpath("//*[@id='main']/table[contains(@class,'results full_company')]/tbody/tr/td[3]"));

					for (WebElement option : options) {
						System.out.println("Account has created"
								+ option.getText());
						if (option.getText().contains(companyname)) {

							sanpshot = "2";
							System.out.println("----------------- " + sanpshot);
							break;
						} else {
							sanpshot = "3";
							System.out.println("----------------- " + sanpshot);
						}
					}
					if (sanpshot.equals("2")) {
						snapshotadded = true;
					} else {
						snapshotadded = false;
					}

				}
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void click_Snapshot_Link(String foldername) {
		UIHelper.waitForPageToLoad(getDriver());
		CompaniesTabEle.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), cnfBtnxpath);

		Foldername = (getDriver()
				.findElement(By
						.xpath("//*[@action='showAllFolderSummary']//tbody//td[contains(@class,'leftAlign')]//a[contains(.,'"
								+ foldername.toString().trim() + "')]")));
		// *[@action='showAllFolderSummary']//tbody//*[contains(@class,'RowGray')]//td[contains(@class,'leftAlign')]//a[contains(.,'Snapshots')]
		if (Foldername.isDisplayed()) {
			System.out.println("folder has displayed-----------------------");
			UIHelper.highlightElement(getDriver(), Foldername);
			Foldername.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), folderTable);

		}

	}

	public boolean verifyInternationsDunsSectionsAvailability(String fieldname) {
		try {

			Sectionname = (getDriver()
					.findElement(By
							.xpath("//*[@id='widget_container']//*[contains(@class,'or-container-table')]//div//*[contains(.,'"
									+ fieldname + "')]")));
			if (Sectionname.isDisplayed()) {
				UIHelper.highlightElement(getDriver(), Sectionname);
				return true;

			} else {
				return false;
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void click_DAndBReportTab() {
		try {

			if (ploadingOkbtn.isVisible()) {
				UIHelper.highlightElement(getDriver(), ploadingOkbtn);
				ploadingOkbtn.click();
			}
			dAndBReportLinkEle.waitUntilPresent();

			if (dAndBReportLinkEle.isVisible()) {
				dAndBReportLinkEle.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						ajaxLoadingEleXpath);
				dAndBReportTitle.waitUntilPresent();

			}
		} catch (Exception e) {
			throw e;
		}
	}

	public boolean getDAndBReportSectionTitle() {
		try {
			if (dAndBReportTitle.isVisible()) {
				UIHelper.highlightElement(getDriver(), dAndBReportTitle);
				return true;

			} else {
				return false;
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public boolean getCReportSectionTitle() {
		try {
			if (cReportTitle.isVisible()) {
				UIHelper.highlightElement(getDriver(), cReportTitle);
				return true;

			} else {
				return false;
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void click_NotesTab() {
		try {

			if (notesLinkEle.isVisible()) {
				notesLinkEle.click();
				/*
				 * UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
				 * ajaxLoadingEleXpath);
				 */
				notesSectionLinkEle.waitUntilPresent();
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public boolean getNotesTitle() {
		try {

			if (notesSectionLinkEle.isVisible()) {
				UIHelper.highlightElement(getDriver(), notesSectionLinkEle);
				return true;

			} else {
				return false;
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void click_AssociationsTab() {
		try {

			if (AssociationsLinkEle.isVisible()) {
				AssociationsLinkEle.click();
				/*
				 * UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
				 * ajaxLoadingEleXpath);
				 * AssociationsSectionLinkEle.waitUntilPresent();
				 */
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						associationssectiontitle);
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public boolean getAssociationsTitle() {
		try {
			if (AssociationsSectionLinkEle.isVisible()) {
				UIHelper.highlightElement(getDriver(),
						AssociationsSectionLinkEle);
				return true;

			} else {
				return false;
			}
		} catch (Exception e) {
			throw e;
		}
	}

	// Save the Snapshot and add to folder in ECF Page
	public void saveaSnapshotBySelectingTheFolder(String foldername) {

		try {
			UIHelper.waitForPageToLoad(getDriver());
			if (ecfHeaderEle.isVisible()) {
				UIHelper.highlightElement(getDriver(), ecfHeaderEle);
			}

			try {

				if (saveASnapshotEle.isVisible()) {

					saveASnapshotEle.click();

					saveSnapShotEle.waitUntilPresent();
					getDriver().switchTo().frame(saveSnapShotEle);
					UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
							saveSnapshotIframeIDSelectXpath);
				}

				try {

					if (saveSnapshotIframeIDSelectEle.isVisible()) {

						saveSnapshotIframeIDSelectEle
								.selectByVisibleText("Everyone");
					}
				} catch (Exception e) {

				}
				if (addToFolderIYesRadioBtn.isVisible()) {
					UIHelper.highlightElement(getDriver(),
							addToFolderIYesRadioBtn);
					addToFolderIYesRadioBtn.click();
					addToFolderListBox.waitUntilPresent();
					UIHelper.highlightElement(getDriver(), addToFolderListBox);
					addToFolderListBox.selectByVisibleText(foldername);
				}

				if (saveSnapshotnotationTextAreaEle.isVisible()) {

					saveSnapshotnotationTextAreaEle.type("Bonjour!!- Serenity");
				}

				// Save

				if (saveSnapshotSaveBTNEle.isVisible()) {

					saveSnapshotSaveBTNEle.waitUntilClickable();
					saveSnapshotSaveBTNEle.click();

					getDriver().switchTo().defaultContent();
					UIHelper.waitForPageToLoad(getDriver());
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
							loadingImgXpath);
				}

			} catch (Exception E) {

			}

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public void clickSaveToPortfoliolink() {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), snapShotSideicon);
		if (saveToPortfolio.isVisible()) {
			saveToPortfolio.click();
			waitFor(10000).milliseconds();
		}
	}

	public void ecfAddtoFolder(String FolderName) {

		if (searchResultsnapShotSideiconAddFolderEle.isVisible()) {
			searchResultsnapShotSideiconAddFolderEle.waitUntilClickable();
			searchResultsnapShotSideiconAddFolderEle.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
			waitFor(5000).milliseconds();
			getDriver().switchTo().frame(iFrameEle);
			if (frameCompanyToAddFolderYesEle.isVisible()) {
				frameCompanyToAddFolderYesEle.click();
			}
			if (frameModaladdToFolderFromEle.getText().contains(FolderName)) {
				frameModaladdToFolderFromEle.selectByVisibleText(FolderName
						.toString().trim());
				searchResultsnapShotAddFolderSubmit.click();
				
			} else {
				System.out
						.println("new folder need to create---------------------");
				if (ecfaddfolderCreateFolderasNew.isVisible()) {
					ecfaddfolderCreateFolderasNew.click();
					
					getDriver().switchTo().defaultContent();
					UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
					
					getDriver().switchTo().frame(iFrameEle);

					if (newFolderName.isVisible()) {
						newFolderName.type(FolderName.toString().trim());
						newFolderNameAlertProfile
								.selectByVisibleText("Standard");
						searchResultsnapShotAddFolderSubmit.click();
						getDriver().switchTo().defaultContent();
					}

				}

			}
			getDriver().switchTo().defaultContent();
			UIHelper.waitForPageToLoad(getDriver());
			actionButtonsEle.waitUntilPresent();
		}
	}

	public void ecfRemoveFromFolder() {
		System.out
				.println("inside remove from folder method---------------------------------");

		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), actionBtnelement);
		if (ecfRemoveFolderEle.isVisible()) {
			System.out
					.println("Remove folder Element is displayed---------------------");
			ecfRemoveFolderEle.waitUntilClickable();
			ecfRemoveFolderEle.click();
			UIHelper.processalert(getDriver());
			UIHelper.waitForPageToLoad(getDriver());

		}
	}
	
	public void ecfRemoveFromFolderForAnAccount() {
		System.out
				.println("inside remove account from folder method---------------------------------");

		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), actionBtnelement);
		if (ecfRemoveFolderEle.isVisible()) {
			System.out
					.println("Remove folder Element is displayed for an account ---------------------");
			ecfRemoveFolderEle.waitUntilClickable();
			ecfRemoveFolderEle.click();
			waitFor(3000).milliseconds();
			UIHelper.processalert(getDriver());
			waitFor(5000).milliseconds();
			/*nextBtnIframe.click();
			System.out.println("next btn in iframe is clicked");*/
			if (continueBtn1.isDisplayed()) {
				getDriver().switchTo().frame(anotheriFrameEle);
				System.out.println("iframe switched---------------------------------");
				continueBtn1.click();
				getDriver().switchTo().defaultContent();
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						CSSectionHearder);
			}

		}
	}

	public boolean veriyEcfAddedToFolder(String DunsNumber) {

		tableSnapshotFolder.waitUntilPresent();

		UIHelper.highlightElement(getDriver(), tableSnapshotFolder);
		WebElement dunsinResults = getDriver()
				.findElement(
						By.xpath("//*[@id='main']/table[contains(@class,'results full_company')]/tbody/tr/td[2]/span/a[contains(.,'"
								+ DunsNumber.toString().trim() + "')]"));
		// if (folderResults.getText().contains(DunsNumber)){
		System.out.println("duns number text---------------"
				+ dunsinResults.getText());
		if (dunsinResults.isDisplayed()) {
			dunsinResults.click();
			System.out
					.println("value returned from this method--is ----TRUE------------------");
			return true;
		} else {
			System.out
					.println("value returned from this method--is ----FALSE------------------");
			return false;
		}

	}
	public boolean veriyEcfAddedToFolderForAccount(String companyname) {

		tableSnapshotFolder.waitUntilPresent();

		UIHelper.highlightElement(getDriver(), tableSnapshotFolder);
		WebElement companyinResults = getDriver()
				.findElement(
						By.xpath("//*[@id='main']/table[contains(@class,'results full_company')]/tbody/tr/td[3][contains(.,'"
								+ companyname.toString().trim() + "')]"));
		// if (folderResults.getText().contains(DunsNumber)){
		System.out.println("ccompany name text---------------"
				+ companyinResults.getText());
		if (companyinResults.isDisplayed()) {
			WebElement accountNoinResults = getDriver()
					.findElement(
							By.xpath("//*[@id='main']/table[contains(@class,'results full_company')]/tbody/tr/td[3][contains(.,'"
									+ companyname.toString().trim() + "')]//preceding-sibling::td[1]//span//a"));
			accountNoinResults.click();
			System.out
					.println("value returned from this method--is ----TRUE------------------");
			return true;
		} else {
			System.out
					.println("value returned from this method--is ----FALSE------------------");
			return false;
		}

	}
	public void click_CompanySummaryTab() {
		try {
			if (companySummaryLinkEle.isVisible()) {
				companySummaryLinkEle.click();
				/*
				 * UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
				 * ajaxLoadingEleXpath);
				 */
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						CSSectionHearder);

			}
		} catch (Exception e) {
			throw e;
		}
	}
	
	

	
	
	public boolean veriyCompanySummarySection() {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), CSSectionHearder);
		// companySummarySection.waitUntilPresent();
		System.out
				.println("company summary section has displayed------------------------------------");
		if (companySummarySection.isVisible()) {
			return true;
		} else {
			return false;
		}

	}

	public void click_Customize_Icon() {
		if (customizeicon.isVisible()) {
			customizeicon.click();
			companySummaryCustomizationPageheader.waitUntilVisible();
		}
	}

	public boolean veriyCompanySummaryCustomization() {

		UIHelper.highlightElement(getDriver(),
				companySummaryCustomizationPageheader);
		if (companySummaryCustomizationPageheader.isVisible()) {
			return true;
		} else {
			return false;
		}

	}

	public void uncheckAllVeriables() {

		for (WebElementFacade veriables : allVeriablesUncheck) {
			veriables.click();
		}
		UIHelper.highlightElement(getDriver(), rturnTonCompanySummarybtn);
		rturnTonCompanySummarybtn.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), CSSectionHearder);

	}

	public boolean widgetCountInCSSection() {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), allWidgets);
		widgetCount = widgetcontainercount.size();
		System.out.println("widget has displayed-----------------"
				+ widgetCount);
		for (WebElementFacade widget : widgetcontainercount) {
			System.out.println("widget name-------------------------------"
					+ widget.getText());
		}
		if (widgetCount == 1) {
			return true;
		} else {
			return false;
		}
	}

	public void selectRequiredVeriable(String veribaletext) {

		String[] veribaletextToSelect = veribaletext.split(",");
		for (String veriable : veribaletextToSelect) {
			veriableName = getDriver().findElement(
					By.xpath("//*[@id='com_cust_us']//tr//span[contains(.,'"
							+ veriable.toString().trim() + "')]"));
			if (veriableName.isDisplayed()) {
				veriableName1 = getDriver()
						.findElement(
								By.xpath("//*[@id='com_cust_us']//tr//span[contains(.,'"
										+ veriable.toString().trim()
										+ "')]//preceding-sibling::input[@type='checkbox']"));
				UIHelper.highlightElement(getDriver(), veriableName);
				veriableName1.click();
			}
		}
		UIHelper.highlightElement(getDriver(), rturnTonCompanySummarybtn);
		rturnTonCompanySummarybtn.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), CSSectionHearder);

	}

	public boolean widgetsDispayedInCSSection(String widgetname) {

		widgetCount = widgetcontainercount.size();
		System.out.println("widget has displayed-----------------"
				+ widgetCount);
		for (WebElementFacade widget : widgetcontainercount) {
			System.out.println("widget name-------------------------------"
					+ widget.getText());

			if (widgetname.contains(widget.getText().toString().trim())) {
				widgetavailable = "1";
			} else {
				widgetavailable = "2";
			}
		}
		System.out.println("widget available --------------------------"
				+ widgetavailable);
		if (widgetavailable.equals("1")) {
			return true;
		} else {
			return false;
		}
	}

	public void click_Customize_Score_Link() {
		if (cSScoreBarLink.isVisible()) {
			System.out
					.println("customize score bar widget has present--------------------------");
			cSScoreBarLink.click();
			editScorePageHearder.waitUntilVisible();
			System.out
					.println("edit score page has displayed----------------------------");
		}
	}

	public boolean veriyEditScoreBarHearder() {

		UIHelper.highlightElement(getDriver(), editScorePageHearder);
		if (editScorePageHearder.isVisible()) {
			return true;
		} else {
			return false;
		}

	}

	public void clickRemoveItemBtnAcrossAllPages() {

		int index = 10;
		for (WebElementFacade pagenumbers : pagecount) {
			
			pagenumbers.click();
			waitFor(500).milliseconds();
			
			List<WebElement> removebtncount = getDriver()
					.findElements(
							By.xpath("//*[@id='pge"
									+ index
									+ "']//*[@class='dash_container']//*[@class='dash_button']//input[@value='Remove Item'][not(contains(@disabled,'disabled'))]"));

			if (removebtncount.size() != 0) {

				for (WebElement rmbtn : removebtncount) {
					System.out
							.println("inside for loop button remove------------------");
					rmbtn.click();
					waitFor(2000).millisecond();
				}

			} else {
				System.out
						.println("no remove item button----------------------");
			}
			index += 10;

		}
		System.out
				.println("all remove buttons has disabled---------------------------");
		UIHelper.highlightElement(getDriver(), returnToScoreBtn);
		returnToScoreBtn.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), CSSectionHearder);

	}

	public boolean veriyScoreBarWidgetMessage() {

		configureTheScoreBarMessage.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), configureTheScoreBarMessage);
		if (configureTheScoreBarMessage.isVisible()) {
			return true;
		} else {
			return false;
		}

	}

	public void addRequiredItems(String Itemslist) {

		String[] ItemNameToSelect = Itemslist.split(",");
		int f = 0;
		for (String ItemName : ItemNameToSelect) {

			System.out.println("items given to add ------------------"
					+ ItemNameToSelect.length);
			for (WebElementFacade pagenumbers : pagecount) {
				pagenumbers.click();

				veriableName = getDriver()
						.findElement(
								By.xpath("//*[@id='itemsContainer']//*[contains(@class,'conentPage')]//*[contains(@class,'dash_content')]//span[contains(.,'"
										+ ItemName.toString().trim() + "')]"));
				if (veriableName.isDisplayed()) {
					
					veriableName1 = getDriver()
							.findElement(
									By.xpath("//*[@id='itemsContainer']//*[contains(@class,'conentPage')]//*[contains(@class,'dash_content')]//span[contains(.,'"
											+ ItemName.toString().trim()
											+ "')]//ancestor::div[2]//input[@value='Add Item']"));
					UIHelper.highlightElement(getDriver(), veriableName);
					veriableName1.click();
					waitFor(2000).millisecond();

					break;
				}

			}
			f += 1;
		}
		UIHelper.highlightElement(getDriver(), returnToScoreBtn);
		returnToScoreBtn.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), CSSectionHearder);

	}

	public boolean sectionsDispayedInScoreBarWidget(String SectionName) {

		widgetCount = sectionCount.size();
		System.out.println("widget has displayed-----------------"
				+ widgetCount);
		for (WebElementFacade widget : sectionCount) {
			System.out.println("widget name-------------------------------"
					+ widget.getText());

			if (SectionName.contains(widget.getText().toString().trim())) {
				widgetavailable = "1";
			} else {
				widgetavailable = "2";
			}
		}
		System.out.println("widget available --------------------------"
				+ widgetavailable);
		if (widgetavailable.equals("1")) {
			return true;
		} else {
			return false;
		}
	}

	public void click_Add_Note_Button() {
		if (addNoteBtn.isVisible()) {
			addNoteBtn.click();
			waitFor(3000).milliseconds();
			// iframemodal.waitUntilVisible();

		}
	}

	public void selectNoteAndEnterText(String notestext) {
		System.out.println("inside selecte note method---------------");
		iFrameEle.waitUntilPresent();
		getDriver().switchTo().frame(iFrameEle);
		System.out.println("switched to iframe-----------------");
		UIHelper.highlightElement(getDriver(),
				searchResultsnapShotAddFolderSubmit);
		System.out
				.println("submit butto is present in iframe------------------");
		selectType.selectByVisibleText("Everyone");
		enterText.type(notestext);
		searchResultsnapShotAddFolderSubmit.click();
		getDriver().switchTo().defaultContent();
		// addNoteBtn.waitUntilVisible();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), notestable);

	}

	public boolean verify_Saved_Notes(String notestext) {
		boolean valueadded;
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		String date1 = dateFormat.format(date);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		Date dateBefore30Days = cal.getTime();
		String date2 = dateFormat.format(dateBefore30Days);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), notestableResult);
		waitFor(1000).milliseconds();

		if (notesCreated.getText().contains(notestext)
				&& notesCreated.getText().contains(date1)) {
			
			valueadded = true;
		} else {
			
			valueadded = false;
		}

		if (valueadded == false) {
			if (notesCreated.getText().contains(notestext)
					&& notesCreated.getText().contains(date2)) {
				
				valueadded = true;
			} else {
				
				valueadded = false;
			}
		}
		return valueadded;

	}

	public void click_Add_Financial_Button() {
		if (FinancialStatementSection.isVisible()) {
			UIHelper.highlightElement(getDriver(), FinancialStatementSection);
			addFinancialBtn.click();
			waitFor(7000).milliseconds();
		}
	}

	public void provide_Financial_Information(String FinancialInformation) {
		// getDriver().switchTo().frame(FinancialIframe);
		getDriver().switchTo().frame(anotheriFrameEle);
		System.out.println("iframe switched----------------------");
		if (FinancialIframeDate.isVisible()) {
			System.out
					.println("date element not displayed---------------------");
			UIHelper.highlightElement(getDriver(), FinancialIframeDate);
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			Date date = new Date();
			String date1 = dateFormat.format(date);
			FinancialIframeDate.sendKeys(date1);
			FinancialIframePeriod.selectByVisibleText(FinancialInformation
					.toString().trim());
			UIHelper.highlightElement(getDriver(),
					searchResultsnapShotAddFolderSubmit);
			searchResultsnapShotAddFolderSubmit.click();
			waitFor(5000).milliseconds();
		}
		System.out.println("iframe switched out-----------------------------");
		getDriver().switchTo().defaultContent();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				financialTableHeader);
	}

	public boolean verify_Added_Financial_Data(String FinancialInformation) {

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		String date1 = dateFormat.format(date);
		if (verifyFinancialdata.getText().contains(FinancialInformation)
				&& verifyFinancialdata.getText().contains(date1)) {
			return true;
		} else {
			return false;
		}

	}

	public void click_Financial_delete_button() {
		if (delFinancialdata.isVisible()) {
			delFinancialdata.click();
			UIHelper.highlightElement(getDriver(), delFinancialdatabtn);
			delFinancialdatabtn.click();
			UIHelper.processalert(getDriver());
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					financialTableHeader);
		}

	}

	public boolean delete_Added_Financial_Data() {

		financialsLinkEle.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), financialsheader);
		waitFor(10000).milliseconds();
		UIHelper.highlightElement(getDriver(), FinancialStatementSection);
		if (verifydelFinancialdata.isVisible()) {
			return true;
		} else {
			return false;
		}
	}

	public void click_Spread_Financials_button() {
		financialsLinkEle.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), financialsheader);
		if (SpreadFinancialsBtn.isVisible()) {
			SpreadFinancialsBtn.click();
		}
	}

	public boolean verifyElementsInNewWindow() {
		String rtnvalue = "0";
		String parentWindowId = getDriver().getWindowHandle();
		Wait<WebDriver> wait = new WebDriverWait(getDriver(), 10000);
		Set<String> s = getDriver().getWindowHandles();
		System.out.println("before ite statement---------------------------");
		Iterator ite = s.iterator();
		System.out.println("after ite statement-----------------------------");
		while (ite.hasNext()) {
			String windowHandle = ite.next().toString();
			if (!windowHandle.contains(parentWindowId)) {
				getDriver().switchTo().window(windowHandle);
				System.out
						.println("window switched-----------------------------------------");
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						sfWindowhearder);
				System.out.println("waited for header-----------");
				UIHelper.highlightElement(getDriver(),
						SpreadFinancialswindowheader);
				System.out
						.println("highlited the header-----------------------");
				if (downloadElements.isVisible()) {
					rtnvalue = "1";
				} else {
					rtnvalue = "2";
				}
				System.out.println("return value----------------------------"
						+ rtnvalue);
				getDriver().close();
				getDriver().switchTo().window(parentWindowId);
				financialsLinkEle.click();
				System.out
						.println("fincancials element has clicked-----------------");
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						financialsheader);
			} else {
				System.out
						.println("window not switched--------------------------------");
			}
		}

		if (rtnvalue.equals("1")) {

			return true;

		} else {
			return false;
		}

	}

	public void click_CustomScoreTab() {

		if (CustomScoreLinkEle.isVisible()) {
			CustomScoreLinkEle.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), scoresscetion);

		}

	}

    public String verifyScoresCalculated(String scoreName){
		
		UIHelper.waitForPageToLoad(getDriver());
		String ScorePath = "//div[@id='scoreTrendWidget']//form[2]//tbody//tr//td//a[contains(.,'"+scoreName+"')]";
		WebElementFacade CalScore = find(By.xpath(ScorePath));
		UIHelper.highlightElement(getDriver(), CalScore);
		String calScoreName = CalScore.getText();
		if (calScoreName.contains(scoreName))
		{
			System.out.println("Custom Score is calculated--------------");
		}
					
		else
		{
			System.out.println("Custom Score is Not Calculated---------------");
		}
	   getDriver().switchTo().frame(ScoreTrendGraphIframeElement);
		
	   UIHelper.highlightElement(getDriver(), selectScore);
	   selectScore.selectByVisibleText(scoreName);
	   getDriver().switchTo().defaultContent();
	   return calScoreName;
	   	   
	}
    
    public void clickIndividualScore(String scoreName){
    	
    	UIHelper.waitForPageToLoad(getDriver());
		String ScorePath = "//div[@id='scoreTrendWidget']//form[2]//tbody//tr//td//a[contains(.,'"+scoreName+"')]";
		WebElementFacade clickScore = find(By.xpath(ScorePath));
		UIHelper.highlightElement(getDriver(), clickScore);
		clickScore.click();
    	
    }
    
    public void validateScoreDetails(String scoreName){
    	
    	switch_to_Required_Window();
    	UIHelper.waitForPageToLoad(getDriver());
    	UIHelper.highlightElement(getDriver(), ScoreTimeStamp);
    	close_the_Required_Window();
    }
    
	public boolean veriyScoreSummarySection() {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), scoresscetion);
		System.out
				.println("company summary section has displayed------------------------------------");
		if (scorestriggered.isVisible()) {
			return true;
		} else {
			return false;
		}

	}

	public void click_AuditTrailTab() {

		if (AuditTrailtab.isVisible()) {
			AuditTrailtab.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					auditTrailscetion);

		}

	}

	public void click_SendToCreditReview_Btn() {
		click_CompanySummaryTab();
		if (SendToCreditReviewBtn.isVisible()) {
			SendToCreditReviewBtn.click();
			System.out.println("Send To Credit Review button is clicked----------------------------");
			getDriver().switchTo().frame(anotheriFrameEle);
			System.out.println("iframe switched---------------------------------");
			/*nextBtnIframe.click();
			System.out.println("next btn in iframe is clicked");*/
			if (continueBtn1.isDisplayed()) {
				continueBtn1.click();
			}
			getDriver().switchTo().defaultContent();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					CSSectionHearder);

		}
	}
	
	public boolean verify_AuditTrails_Status(){
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),auditTrailscetion);
		String rtnvalue;
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		String date1 = dateFormat.format(date);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		Date dateBefore30Days = cal.getTime();
		String date2 = dateFormat.format(dateBefore30Days);
		if(AuditTrailtable1.getText().contains(date1) && AuditTrailtable12.getText().contains("Status Changed") && AuditTrailtable13.getText().contains("No Action Recommended' to 'Credit Review Required")){
			rtnvalue="1";
		}else{
			rtnvalue="1";
		}
		
		if(rtnvalue.equals("2")){
			if(AuditTrailtable1.getText().contains(date2) && AuditTrailtable12.getText().contains("Status Changed") && AuditTrailtable13.getText().contains("No Action Recommended' to 'On Credit Hold")){
				rtnvalue="1";
			}else{
				rtnvalue="2";
			}
		}
		if(rtnvalue.equals("1")){
			return true;
		}else{
			return false;
		}
	}
	public void click_Request_Financial_Button() {
		if (requestFinancialStatementSection.isVisible()) {
			UIHelper.highlightElement(getDriver(), requestFinancialStatementSection);
			requestFinancialBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), requestFinancialsHeader);
		}
	}

	public void provide_Details_For_Request(String companyname , String emailid) {
		
		if (requestFinancialsPageHeader.isVisible()) {
			UIHelper.highlightElement(getDriver(), requestFinancialsPageHeader);
			companyContactname.sendKeys(companyname);
			companyEmailAddress.sendKeys(emailid.toString().trim());
			UIHelper.highlightElement(getDriver(),
					requestFinancialsSubmitBtn);
			requestFinancialsSubmitBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					requestFinancialTableHeader);
		}

		
	}

	public boolean verify_requested_Financial_Data() {
		financialsLinkEle.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				requestFinancialTableHeader);
		UIHelper.highlightElement(getDriver(), requestFinancialStatementSection);
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		String date1 = dateFormat.format(date);
		if (verifyRequestFinancialdata.getText().contains(date1)) {
			return true;
		} else {
			return false;
		}

	}
	
	public void clickOnFirstRecordofLiveReport() {		
		// TODO Auto-generated method stub		
		WebElement checkBox=getDriver().findElement(By.xpath("//div[@id='main']//table[@class='results full']//tr[1]/td[1]/input[@type='checkbox']"));		
		checkBox.click();		
		waitFor(300).milliseconds();		
	}		
	/**		
	 * Added for the searchResultPage Add to Folder option		
	 * @param folderName		
	 */		
	public void clickAddToFolderButton(String folderName) {		
		// TODO Auto-generated method stub		
		getDriver().findElement(By.xpath("//div[@id='main']//input[@value='Add to Folder']")).click();		
				
//		waitFor(10000).milliseconds();		
		getDriver().switchTo().frame(iFrameEle);		
				
		frameModaladdToFolderFromEle.waitUntilPresent();		
		System.out.println("available folder list------------------"		
				+ frameModaladdToFolderFromEle.getText());		
		if (frameModaladdToFolderFromEle.getText().contains(folderName)) {		
			frameModaladdToFolderFromEle.selectByVisibleText(folderName		
					.toString().trim());		
			searchResultsnapShotAddFolderSubmit.click();		
		}		
		waitFor(3000).milliseconds();		
	}
public void click_Back_To_Report(){
	if (orderBtn.isDisplayed()) {
		orderBtn.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				backtoReportBtnxpath);
		backToReportBtnEle.click();
		UIHelper.waitForPageToLoad(getDriver());
		
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				CSSectionHearder);

	}
}
	public void getInvestigationValues(String FieldName) {
		String[] fieldnamelist = FieldName.split(":");
		for (String fname : fieldnamelist) {
			WebElement EnteredFieldName = getDriver()
					.findElement(
							By.xpath("//*[@class='widget_form']//*[contains(text(),'"
									+ fname.trim()
									+ "')] [@class='frmTitleF']//following-sibling::td[@class='frmField']//input"));
			String fieldValuesinInvestigation = (EnteredFieldName
					.getAttribute("value")).trim();
			System.out
					.println("fieldValuesinInvestigation----------------------"
							+ fieldValuesinInvestigation);
			// Adding values to array list
			Fieldvalues.add(fieldValuesinInvestigation);

		}
	}
public void click_More_Details_Link(String DunsNumber){
	DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	Date date = new Date();
	String date1 = dateFormat.format(date);
	for(int i=1 ; i<4 ; i++){
		WebElement resulttext1=getDriver().findElement(By.xpath("//*[@id='additionalHeaderForm']//table//tbody//tr["+i+"]"));
		System.out.println("text displayed in investigation------------------"+resulttext1.getText());
		if(resulttext1.getText().contains(DunsNumber) && resulttext1.getText().contains(date1)){
			System.out.println("result mathced in loop no-------- "+i);
			WebElement resulttext2=resulttext1.findElement(By.xpath("//td//a[contains(.,'More Details')]"));
			UIHelper.highlightElement(getDriver(), resulttext2);
			resulttext2.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), requestDetailsHeader);
			break ;
		}
	}
}
	 

	public boolean compareInvestigationsDetails(List<String> alldetails){
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), requestDetailsHeader);
		UIHelper.highlightElement(getDriver(), requestDetails);
		String requestDetails1=requestDetails.getText();
		System.out.println("request details----------------"+requestDetails1);
		for(String fieldname:alldetails){
			if(requestDetails1.contains(fieldname)){
				System.out.println("field name has displayed in the information---------"+fieldname);
				resultflag=1;
			}else{
				System.out.println("field name has not displayed in the information---------"+fieldname);
				resultflag=2;
			}
		}
		System.out.println("return falg---------------"+resultflag);
		Fieldvalues.clear();
	if(resultflag==1){
		return true;
	}else{
		return false;
	}
	
	}
	public boolean verify_Score_Bar_Widget_Has_Dispalyed(){
		try{
			scorebarWidget.isVisible();
			return true;
		}catch(Exception e){
			return false;
			
		}
	}
	
	
	public void select_Option_From_Available_list(String Optionname){
		int j=0;
		for(WebElementFacade option:selectedFieldsList){
			String itemName=option.getText().trim();
			if(itemName.equalsIgnoreCase(Optionname.trim())){
				UIHelper.highlightElement(getDriver(), iframecancelBtn);
				iframecancelBtn.click();
				j=1;
				break;
			}
		}
		if(j!=1){
			for(WebElementFacade field : availableFieldsList){
				String itemName1=field.getText().trim();
				
				if(itemName1.equalsIgnoreCase(Optionname.trim())){
					field.click();
					UIHelper.highlightElement(getDriver(), fieldsAddArrowBtn);
					fieldsAddArrowBtn.click();
					waitFor(5000).milliseconds();
					for(WebElementFacade option:selectedFieldsList){
						String itemName=option.getText().trim();
						if(itemName.equalsIgnoreCase(Optionname.trim())){
							break;
						}
					}
					UIHelper.highlightElement(getDriver(), updateListBtn);
					updateListBtn.click();
					break;
				}
			}
			
		}
		getDriver().switchTo().defaultContent();
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), folderTable);
		
	}
	
	
	public boolean verify_Option_Has_Added(String Optionname){
		int flag=0;
		for(WebElementFacade option:tableHeaderList){
			String itemName=option.getText().trim();
			if(itemName.contains(Optionname.trim())){
				UIHelper.highlightElement(getDriver(), option);
				flag=1;
				break;
			}
		}
		
		if(flag==1){
			return true;
		}else{
			return false;
		}
	}
	
	public boolean verify_Oob_popup_Message(String Message ){
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
		getDriver().switchTo().frame(iFrameElement);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), oobYesBtnXpath);
		String oobMessagetext=oobMessageElement.getText();
		if(oobMessagetext.contains(Message)){
			return true;
		}
		else{
			return false;
		}
		
	}
	public void oob_Select_Yes_Radio_Btn(){
		UIHelper.highlightElement(getDriver(), oobYesRadioBtn);
		oobYesRadioBtn.click();
		
	}
	
	public void oob_Click_Continue_Btn(){
		UIHelper.highlightElement(getDriver(), oobContinueBtn);
		oobContinueBtn.click();
		getDriver().switchTo().defaultContent();
		
	}
	
	 public boolean verify_Out_Of_Business_Message(){
		 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), CSSectionHearder);
	    	
	    		if(!outOFBusinessMessage.isVisible()){
	    			return true;
	    		
	    	}else{
	    		return false;
	    	}
	    }
	 
	 public boolean verify_Section_Has_Displayed(String fieldname) {
			try {
				getDriver().findElement(By.xpath("//*[@id='widget_container']//*[contains(@class,'ecfbox')]//h3[contains(.,'"
										+ fieldname + "')]"));
				
				return true;
			} catch (Exception e) {
				return false;
			}
		}
	 
	public boolean verify_Registrations_No_Has_Populated() {
		UIHelper.highlightElement(getDriver(), registrationNoelement);
			
			String fieldValuesinInvestigation = registrationNoelement.getAttribute("value").trim();
			System.out.println("fieldValuesinInvestigation---------------------- "+fieldValuesinInvestigation);
				if(!fieldValuesinInvestigation.equals("")){
					return true;
				}else{
				return false;
				}
			}
	public boolean verify_Registrations_No_Has_Not_Populated() {
		UIHelper.highlightElement(getDriver(), registrationNoelement);
		String fieldValuesinInvestigation = registrationNoelement.getAttribute("value").trim();
		System.out.println("fieldValuesinInvestigation---------------------- "+fieldValuesinInvestigation);
			if(fieldValuesinInvestigation.equals("")){
				return true;
			}else{
			return false;
			}
		}
	
	public boolean compare_Business_Phone_No(){
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), requestDetailsHeader);
		//requestDetails
		UIHelper.highlightElement(getDriver(), requestDetails);
		String requestDetails1=requestDetails.getText();
		System.out.println("request details----------------"+requestDetails1);
		String[] requestDetails2=requestDetails1.split("Business Phone :");
		String[] requestDetails3=requestDetails2[1].split("Registration Number:");
		System.out.println("Business Phone : ---------"+requestDetails3[0].trim());

		//requestedByDetails
		UIHelper.highlightElement(getDriver(), requestedByDetails);
		String requestedByDetails1=requestedByDetails.getText();
		System.out.println("request details----------------"+requestedByDetails1);
		String[] requestedByDetails2=requestedByDetails1.split("Phone:");
		System.out.println("Phone:-----------------  "+requestedByDetails2[1].trim());
		
	if(!requestDetails3[0].trim().equals(requestedByDetails2[1].trim())){
		return true;
	}else{
		return false;
	}
	
	}
	
	
	public void acc_Enter_Data_Into_Text_Field(String SectionName,String FieldName,String Value){
		String FieldNameElementXpath="//*[@id='createApplication']//h3[contains(.,'"+SectionName+"')]//following-sibling::div[@class='frmSecEdit']//td[contains(.,'"+FieldName+"')]//following-sibling::td[@class='frmField']//input";
	    WebElementFacade FieldNameElement=find(By.xpath(FieldNameElementXpath));
	    UIHelper.highlightElement(getDriver(), FieldNameElement);
	    FieldNameElement.sendKeys(Value);
		
		   
	}
	
	public void acc_Select_Option_From_List(String SectionName,String FieldName,String Value){
		String FieldNameElementXpath="//*[@id='createApplication']//h3[contains(.,'"+SectionName+"')]//following-sibling::div[@class='frmSecEdit']//td[contains(.,'"+FieldName+"')]//following-sibling::td[@class='frmField']//select";
	    WebElementFacade FieldNameElement=find(By.xpath(FieldNameElementXpath));
	    UIHelper.highlightElement(getDriver(), FieldNameElement);
	    FieldNameElement.selectByVisibleText(Value);
		  
		   
	}
	public void acc_Click_next_btn(){
		UIHelper.mouseOveranElement(getDriver(), acc_next_btn);
		 acc_next_btn.click();
		 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), searchResultsConatiner);
	}
public void click_On_Preview_Link(){

		previewLink.isVisible();
		UIHelper.highlightElement(getDriver(), previewLink);
		previewLink.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), modal_ContinueBtnXpath);
		modal_ContinueBtn.click();

}

public void getAccNoInEcfPage(){
	UIHelper.highlightElement(getDriver(), accNumberInEcfPage);
	accNumberECF=accNumberInEcfPage.getText().trim();
}

	public String validateCompanyNamePage(String companyName){
		UIHelper.highlightElement(getDriver(), companyNameLabel);
		String getCompanyName=companyNameLabel.getText().substring(14);
		System.out.println("Company Name is:**************"+getCompanyName);
		return getCompanyName;
		
	}
	
	public String validateDUNSnumberPage(){
		UIHelper.highlightElement(getDriver(), dunsNumberLabel);
		String getDUNSnumber=dunsNumberLabel.getText().substring(0, 11);
		System.out.println("DUNS Number is*************************" +getDUNSnumber);
		return getDUNSnumber;
		
	}
	
	public String validateTradeNamePage(){
		UIHelper.highlightElement(getDriver(), tradeNameLabel);
		String getTradeName=tradeNameLabel.getText().trim();
		System.out.println("Trade Name is******************"+getTradeName);
		return getTradeName;
		
	}
	
	public String validateAddressPage(){
		UIHelper.highlightElement(getDriver(), addressLabel);
		String getAddress=addressLabel.getText().trim();
		System.out.println("Address is ***********************"+getAddress);
		return getAddress;
	}
	
	public String validateCityPage(){
		UIHelper.highlightElement(getDriver(), cityStateZipLabel);
		String getCityStateZIP=cityStateZipLabel.getText().trim();
		String [] CityStateZIPvalues=getCityStateZIP.split(",");
		String city=CityStateZIPvalues[0];
		System.out.println("City is **************************"+city);
		return city;
	}
	
	public String validateStatePage(){
		UIHelper.highlightElement(getDriver(), cityStateZipLabel);
		String getCityStateZIP=cityStateZipLabel.getText().trim();
		String [] CityStateZIPvalues=getCityStateZIP.split(",");
		String state=CityStateZIPvalues[1].substring(1).trim();
		System.out.println("State is **************************"+state);
		return state;
	}
	
	public String validateCountryPage(){
		UIHelper.highlightElement(getDriver(), cityStateZipLabel);
		String getCityStateZIP=cityStateZipLabel.getText().trim();
		String [] CityStateZIPvalues=getCityStateZIP.split(",");
		String country=CityStateZIPvalues[2].substring(1,3).trim();
		System.out.println("Country is **************************"+country);
		return country;
	}
	
	public String validateZIPcodePage(){
		UIHelper.highlightElement(getDriver(), cityStateZipLabel);
		String getCityStateZIP=cityStateZipLabel.getText().trim();
		String [] CityStateZIPvalues=getCityStateZIP.split(",");
		String zip=CityStateZIPvalues[2].substring(6).trim();
		System.out.println("ZIP Code is **************************"+zip);
		return zip;
	}
	
	public String validatePhoneNumberPage(){
		UIHelper.highlightElement(getDriver(), phoneNumberLabel);
		String getPhoneNumber=phoneNumberLabel.getText().trim();
		System.out.println("Phone Number is:***********"+getPhoneNumber);
		return getPhoneNumber;
	}
	
	public String validateFaxPage(){
		UIHelper.highlightElement(getDriver(), faxLabel);
		String getFax=faxLabel.getText().trim();
		System.out.println("Fax Number is***************"+getFax);
		return getFax;
	}
	
	public String validateLocationTypePage(){
		UIHelper.highlightElement(getDriver(), locationType);
		String getLocationType=locationType.getText().trim();
		System.out.println("Fax Number is***************"+getLocationType);
		return getLocationType;
	}
	
	public boolean validateWebAddressField(){
		if(!webAddress.isDisplayed())
			return true;
		else 
			return false;
	}
	
	public boolean displayCanadianFlagPage(){
		UIHelper.highlightElement(getDriver(), canadaFlagDisplay);
		System.out.println("Canada Flag is highlighted**************"+canadaFlagDisplay);
		if(canadaFlagDisplay.isDisplayed())
			return true;
		else 
			return false;
	}
	
	public boolean validateToolTipPredictiveScores(){
		UIHelper.waitForPageToLoad(getDriver());
		String actualMessage="To more effectively mitigate risk, use D&B Predictive Scores to see a company's current state and future outlook. By calculating the likelihood of business success or failure, you'll make faster, more consistent decisions.";
		UIHelper.highlightElement(getDriver(), predictiveScoresToolTip);
		predictiveScoresToolTip.click();
		UIHelper.highlightElement(getDriver(), predictiveScoresToolTipMessage);
		String predictiveScoreHelpMessage=predictiveScoresToolTip.getText();
		clickPredictive.click();
		if(actualMessage.contains(predictiveScoreHelpMessage))
			return true;
		else
			return false;	
	}
	
	public boolean validateToolTipDBViabilitySummary(){
		UIHelper.waitForPageToLoad(getDriver());
		String actualMessage="The D&B Viability Rating uses D&B's proprietary analytics to compare the most predictive business risk indicators and deliver a highly reliable assessment of the probability that a company will go out of business, become dormant/ inactive, or file for bankruptcy/insolvency within the next 12 months. ";
		UIHelper.highlightElement(getDriver(), DBViabilitySummaryToolTip);
		DBViabilitySummaryToolTip.click();
		UIHelper.highlightElement(getDriver(), DBViabilitySummaryToolTipMessage);
		String predictiveScoreHelpMessage=DBViabilitySummaryToolTipMessage.getText();
		clickPredictive.click();
		if(predictiveScoreHelpMessage.contains(actualMessage))
			return true;
		else
			return false;	
	}
	
	public boolean validateToolTipViabilityScore(){
		UIHelper.waitForPageToLoad(getDriver());
		String actualMessage="Viability Score is a high-level risk indicator that assesses the probability that a company will no longer be in business within the next 12 months, compared to all Canadian businesses within the D&B database. A business is no longer viable when it goes out of business, becomes dormant/ inactive or files for bankruptcy/insolvency.";
		UIHelper.highlightElement(getDriver(), ViabilityScoreToolTip);
		ViabilityScoreToolTip.click();
		UIHelper.highlightElement(getDriver(), ViabilityScoreToolTipMessage);
		String expectedMessage=ViabilityScoreToolTipMessage.getText();
		clickPredictive.click();
		if(expectedMessage.contains(actualMessage))
			return true;
		else
			return false;	
	}
	
	public boolean validateToolTipPortfolioComparison(){
		UIHelper.waitForPageToLoad(getDriver());
		String actualMessage="Viability Score is a high-level risk indicator that assesses the probability that a company will no longer be in business within the next 12 months, compared to all Canadian businesses within the D&B database. A business is no longer viable when it goes out of business, becomes dormant/ inactive or files for bankruptcy/insolvency.";
		UIHelper.highlightElement(getDriver(), PortfolioComparisonToolTip);
		PortfolioComparisonToolTip.click();
		UIHelper.highlightElement(getDriver(), PortfolioComparisonToolTipMessage);
		String expectedMessage=PortfolioComparisonToolTipMessage.getText();
		if(expectedMessage.contains(actualMessage))
			return true;
		else
			return false;	
	}
	
	 
	
		public boolean validateToolTipDataIndicator(){
		UIHelper.waitForPageToLoad(getDriver());
		String actualMessage="The Depth of Data Indicator presents the level of data that is used to generate the Viability Score and Portfolio Comparison. Data depth assists in the assessment of whether a company will no longer be viable and includes the following:";
		UIHelper.highlightElement(getDriver(), DataDepthIndicatorToolTip);
		DataDepthIndicatorToolTip.click();
		UIHelper.highlightElement(getDriver(), DataDepthIndicatorToolTipMessage);
		String expectedMessage=DataDepthIndicatorToolTipMessage.getText();
		if(expectedMessage.contains(actualMessage))
			return true;
		else
			return false;	
	}
		

		public boolean validateToolTipCompanyProfile(){
			UIHelper.waitForPageToLoad(getDriver());
			String actualMessage="The Company Profile describes a company based on a combination of 4 categories:";
			UIHelper.highlightElement(getDriver(), CompanyProfileToolTip);
			CompanyProfileToolTip.click();
			UIHelper.highlightElement(getDriver(), CompanyProfileToolTipMessage);
			String expectedMessage=CompanyProfileToolTipMessage.getText();
			if(expectedMessage.contains(actualMessage))
				return true;
			else
				return false;	
		}
		
		public boolean validateToolTipCreditCapacity(){
			UIHelper.waitForPageToLoad(getDriver());
			String actualMessage="The D&B Rating is D&B's proprietary indicator that quickly assesses a company's size and composite credit appraisal. For example, a company rated 3A3 has a worth of $1,000,000 - $9,999,999 based on an interim or fiscal balance sheet, and has a composite credit appraisal of 'Fair'.";
			UIHelper.highlightElement(getDriver(), CreditCapacityToolTip);
			CreditCapacityToolTip.click();
			UIHelper.highlightElement(getDriver(), CreditCapacityToolTipMessage);
			String expectedMessage=CreditCapacityToolTipMessage.getText();
			if(expectedMessage.contains(actualMessage))
				return true;
			else
				return false;	
		}
		
		public boolean validateToolTipFinancialStress(){
			UIHelper.waitForPageToLoad(getDriver());
			String actualMessage="What is the Financial Stress Score and what does it mean? ";
			UIHelper.highlightElement(getDriver(), FinancialStressToolTip);
			FinancialStressToolTip.click();
			UIHelper.highlightElement(getDriver(), FinancialStressToolTipMessage);
			String expectedMessage=FinancialStressToolTipMessage.getText();
			if(expectedMessage.contains(actualMessage))
				return true;
			else
				return false;	
		}
		
		public boolean validateToolTipCreditScore(){
			UIHelper.waitForPageToLoad(getDriver());
			String actualMessage="What is the D&B Commercial Credit Score and what does it mean?";
			UIHelper.highlightElement(getDriver(), CreditScoreToolTip);
			CreditScoreToolTip.click();
			UIHelper.highlightElement(getDriver(), CreditScoreToolTipMessage);
			String expectedMessage=CreditScoreToolTipMessage.getText();
			if(expectedMessage.contains(actualMessage))
				return true;
			else
				return false;	
		}
		
		public boolean validateDBFinancialStatement(){
			String expectedDBFinancialHeading = "D&B Financial Statements";
			UIHelper.highlightElement(getDriver(), dbFinancialStatement);
			String actualDBFinancialHeading = dbFinancialStatement.getText();
			
			String expectedDBFinancialValue = "Total Assets";
			UIHelper.highlightElement(getDriver(), dbFinancialStatementField);
			String actualDBFinancialValue = dbFinancialStatementField.getText();
			if(expectedDBFinancialHeading.equalsIgnoreCase(actualDBFinancialHeading) && expectedDBFinancialValue.equalsIgnoreCase(actualDBFinancialValue)){
				return true;
			}
			else
				return false;	
		}
		
		public boolean validateKeyBusinessRatios(){
			String expectedKeyBusinessRatiosHeading = "Key Business Ratios";
			UIHelper.highlightElement(getDriver(), keyBusinessRatios);
			String actualKeyBusinessRatiosHeading = keyBusinessRatios.getText();
			
			String expectedKeyBusinessRatiosValue = "Profitability";
			UIHelper.highlightElement(getDriver(), keyBusinessRatiosFirstValue);
			String actualKeyBusinessRatiosValue = keyBusinessRatiosFirstValue.getText();
			if(expectedKeyBusinessRatiosHeading.equalsIgnoreCase(actualKeyBusinessRatiosHeading) && expectedKeyBusinessRatiosValue.equalsIgnoreCase(actualKeyBusinessRatiosValue)){
				return true;
			}
			else
				return false;	
		}
		
		public boolean validateRequestFinancial(){
			String expectedRequestFinancialHeading = "Request Financial Statements";
			UIHelper.highlightElement(getDriver(), requestFinancialsHeading);
			String actualRequestFinancialHeading = requestFinancialsHeading.getText();
			
			UIHelper.highlightElement(getDriver(), requestFinancialButton);
			if(expectedRequestFinancialHeading.equalsIgnoreCase(actualRequestFinancialHeading) && requestFinancialButton.isDisplayed()){
				return true;
			}
			else
				return false;	
		}
		
		public void click_Required_Tab_In_ECF_Page(String TabName){

				 String ecfTabXpth="//*[contains(@id,'ecf_toc')]//a[contains(.,'"+TabName+"')]";
				if(TabName.equals("Detailed Trade Risk Insight")){
					 String ecfTabHeaderXpth="//*[@id='widget_container']//h2[contains(.,'"+TabName+"')]";
					 WebElementFacade TabNameElement=find(By.xpath(ecfTabXpth));
					 UIHelper.highlightElement(getDriver(), TabNameElement);
					 TabNameElement.click();
					 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), ecfTabHeaderXpth);
					 WebElementFacade TabHeaderElement=find(By.xpath(ecfTabHeaderXpth));
					 UIHelper.highlightElement(getDriver(), TabHeaderElement);
				}else{
					 String ecfTabHeaderXpth="//*[@id='widget_container']//h3[contains(.,'"+TabName+"')]";
					 WebElementFacade TabNameElement=find(By.xpath(ecfTabXpth));
					 UIHelper.highlightElement(getDriver(), TabNameElement);
					 TabNameElement.click();
					 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), ecfTabHeaderXpth);
					 WebElementFacade TabHeaderElement=find(By.xpath(ecfTabHeaderXpth));
					 UIHelper.highlightElement(getDriver(), TabHeaderElement);
					
				}

		}
		
		public void verify_FRS_Details(){
			if(fRSInformationHeading.isVisible()){
				UIHelper.highlightElement(getDriver(), fRSInformationHeading);
				
			}else{
				generateFRSBtn.click();
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), fRSInformationHeadingXpath);
				UIHelper.highlightElement(getDriver(), fRSInformationHeading);
			}
		}
		
		public void verify_FRS_Details_In_New_Window(String FRSLinkName){

				 String FRSLinkNameXpth="//*[@id='searchHead']//strong[contains(.,'"+FRSLinkName+"')]";
				 WebElementFacade FRSLinkNameElement=find(By.xpath(FRSLinkNameXpth));
				 UIHelper.highlightElement(getDriver(), FRSLinkNameElement);
				 FRSLinkNameElement.click();
				 switch_to_Required_Window();
				 UIHelper.waitForVisibilityOfEleByXpath(getDriver(),fRSPageNewWindowHeader);
				 UIHelper.highlightElement(getDriver(), pageHeader);
				 close_the_Required_Window();

		}
		
		public void switch_to_Required_Window(){
			Set<String> AllWindowHandles = getDriver().getWindowHandles(); 
			System.out.println("window count------   "+AllWindowHandles.size());
			if(AllWindowHandles.size() > 0){
				String window1 = (String) AllWindowHandles.toArray()[1];
				getDriver().switchTo().window(window1);
				
			}
			
		   
		}
		
		public void close_the_Required_Window(){
			Set<String> AllWindowHandles = getDriver().getWindowHandles(); 
			System.out.println("window count------   "+AllWindowHandles.size());
			if(AllWindowHandles.size() > 0){
				String window1 = (String) AllWindowHandles.toArray()[0];
				getDriver().close();
				getDriver().switchTo().window(window1);
				
			}
			
		   
		}
		
		public void verify_DUNS_Right_Info_In_New_Window(String DunsRightLinkName){

				 String DunsRightLinkNameXpth="//*[@id='footer']//a[contains(.,'"+DunsRightLinkName+"')]";
				 WebElementFacade DunsRightLinkNameElement=find(By.xpath(DunsRightLinkNameXpth));
				 UIHelper.highlightElement(getDriver(), DunsRightLinkNameElement);
				 DunsRightLinkNameElement.click();
				 switch_to_Required_Window();
				 UIHelper.waitForVisibilityOfEleByXpath(getDriver(),dunsRightNewWindowHeader);
				 close_the_Required_Window();

		}
		
		public boolean verify_Top_TenCount(){
			System.out.println("table size ----------------"+topTenResultsTable.size());
			if(topTenResultsTable.size() ==10){
				return true;
			}else{
				return false;
			}
			
		}
		
		public String verify_CS_Summary_Widgets(String WidgetName){
			String csWidgetName="";
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), aDRHeaderXpath);
			//UIHelper.highlightElement(getDriver(), aDRHeaderElement);
			for(WebElementFacade widget : cSSummaryWidgets){
				if(widget.getText().contains(WidgetName)){
					UIHelper.highlightElement(getDriver(), widget);
					csWidgetName=WidgetName;
					log.log(Level.INFO,"widget name-------------"+widget.getText());
					break;
				}
				log.log(Level.INFO,"Expected widget name-------"+WidgetName+" is not matched With Apllication-------------"+widget.getText());
			}
			return csWidgetName;
		}
		
		public boolean verify_ADR_Links(String LinkName){
			
			try{
				if(LinkName.equals("View Reasons")){
					String LinkNameXpth=".//*[@id='widget_container']//li//a[contains(.,'"+LinkName+"') or contains(.,'Hide Reasons')]";
					 WebElementFacade LinkNameElement=find(By.xpath(LinkNameXpth));
					 UIHelper.highlightElement(getDriver(), LinkNameElement);
				}else{
					String LinkNameXpth=".//*[@id='widget_container']//li//a[contains(.,'"+LinkName+"')]";
					 WebElementFacade LinkNameElement=find(By.xpath(LinkNameXpth));
					 UIHelper.highlightElement(getDriver(), LinkNameElement);
				}
				 
				
				 return true;
			}catch(Exception e){
				return false;
			}
			
		}	
		public boolean verify_DTRI_Data(){
			if(sbriOrls.isVisible() || !dtriNoDataElement.isVisible()){
								
				log.log(Level.INFO,"no data message is displayed-----------------------");
				return true;
			}else{
				return false;
			}
		}
		
		public void click_Folder_Link(String FolderName){

				 String FolderNameXpth="//*[@id='main']//*[@id='tab1']//form//table//tbody//tr//a[contains(.,'"+FolderName+"')]";
				 WebElementFacade FolderNameElement=find(By.xpath(FolderNameXpth));
				 UIHelper.highlightElement(getDriver(), FolderNameElement);
				 FolderNameElement.click();
				 UIHelper.waitForVisibilityOfEleByXpath(getDriver(),folderTable);

		}
		public void click_Application_Link(){
			UIHelper.highlightElement(getDriver(), applicationFirstRowLink);
			applicationFirstRowLink.click();
			//((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", applicationFirstRowLink);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),requestDetailsHeader);
			
		}
		
		public void click_on_DM_Application_Link(){
			UIHelper.highlightElement(getDriver(), dmApplicationFirstrecordLink);
			dmApplicationFirstrecordLink.click();
			//((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", dmApplicationFirstrecordLink);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),requestDetailsHeader);
			
		}
		
		public boolean verifySectionDisplayed(String fieldname) {

				int headerflag=0;
				List <WebElement> Sectionheader = getDriver().findElements(By.xpath("//*[@id='widget_container']//*[contains(@class,'ecfbox')]//h3"));
						for(WebElement sheader:Sectionheader ){
							if(sheader.getText().contains(fieldname)){
								headerflag=1;
								break;
							}
							
						}
						if(headerflag==1){
							return true;
						}else{
							return false;
						}
		}
		
		public void clickCSSLink(){
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.highlightElement(getDriver(), ccsViewLink);
			ccsViewLink.click();
		}
		
		public void clickFssClassLink(){
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.highlightElement(getDriver(), fssClassViewLink);
			fssClassViewLink.click();
		}
		
		public boolean isPredictiveScoreTabDisplayed(){
			UIHelper.waitForPageToLoad(getDriver());
			String getText=tabHeaders.getText();
			if(getText.equalsIgnoreCase("Predictive Scores"))
				return true;
			else 
				return false;
		}
		
		public void clickCorporateLinkageLink(){
			UIHelper.waitForPageToLoad(getDriver());			
			UIHelper.highlightElement(getDriver(), corporateLinkageLink);
			corporateLinkageLink.click();
		}
		
		public boolean corpLinkagedataTreeDiaplyed(){
			boolean view = false;
			UIHelper.waitForPageToLoad(getDriver());
			getDriver().switchTo().frame(crpIframe);
			UIHelper.highlightElement(getDriver(), CorptreeIcon);
			CorptreeIcon.click();
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), CorpLinkageHQNameImg);
			UIHelper.highlightElement(getDriver(), CorpLinkageHQName);
			view = CorpLinkageListView.isPresent() ; 
			getDriver().switchTo().defaultContent();
			return view;
		}
		
		public void corpLinkClickPrint(){
			corporateLinkageLink.click();
			getDriver().switchTo().frame(crpIframe);
			UIHelper.highlightElement(getDriver(),CorpPrintIcon);
			//CorpPrintIcon.click();
			UIHelper.waitForPageToLoad(getDriver());
			getDriver().switchTo().defaultContent();
		}
		
		@FindBy(xpath = "//*[@class='ng-scope']//*[@class='cl-container']//*[@id='cflFilterForm']//*[@class='cl-tabs-filter']/div/a[contains(text(),'Refine')]")
		public WebElementFacade corpRefineButton;
		
		@FindBy(xpath = "//*[@class='cl-tabs-filter']//*[@id='refineTreeWrap']//*[@class='row-fluid risk-info']//*[@type='radio']/following-sibling::span[contains(., 'CCS Percentile')]")
		public WebElementFacade corpRiskCategry;
		
		@FindBy(xpath = "//*[@class='cl-tabs-filter']//*[@id='refineTreeWrap']//*[@class='row-fluid risk-info']/div[contains(., 'PAYDEX')]//*[@class='checkbox']/label[contains(., '70-79')]/input")
		public WebElementFacade corpRiskVariableRange;
		
		@FindBy(xpath = "//*[@class='cl-tabs-filter']//*[@id='refineTreeWrap']//*[@class='btn-div']//*[@type='submit']")
		public WebElementFacade corpTreeUpadateLsit;
		
		@FindBy(xpath = "//*[@class='cl-tabs-filter']//*[@id='refineTreeWrap']//*[@class='btn-div']//*[@value='Reset']")
		public WebElementFacade corpTreeResetBttn;
		
		@FindBy(xpath = "//*[@id='cflFilterForm']//*[@class='cl-tabs-filter']//*[@class='rt-ldiv']/a[contains(.,'Cancel')]")
		public WebElementFacade corpTreeCancelBttn;
		
		@FindBy(xpath = "//*[@id='cflFilterForm']//*[@class='cl-tabs-filter']//*[@class='risk-custom-div-inner']/span[contains(., 'CCS Percentile')]")
		public WebElementFacade corpVariableValidation;
		
		@FindBy(xpath = "//*[@class='cl-tabs-content']//*[@class='cl-tab-cnt']//*[@class='no_data_div']/div[2]")
		public WebElementFacade corpFamilyTreeDisplay;		
		
		public void corpLinkageRefSearch(String RiskCategry , String RiskVarRange){
			corporateLinkageLink.click();
			UIHelper.waitForPageToLoad(getDriver());
			getDriver().switchTo().frame(crpIframe);
			UIHelper.highlightElement(getDriver(), CorptreeIcon);
			CorptreeIcon.click();
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), CorpLinkageHQNameImg);
			UIHelper.highlightElement(getDriver(), CorpLinkageHQName);
			UIHelper.highlightElement(getDriver(), corpRefineButton);
			   if (corpRefineButton.isDisplayed()){
				corpRefineButton.click();		
				UIHelper.waitForPageToLoad(getDriver());
				String RiskCatXpath = "//*[@class='cl-tabs-filter']//*[@id='refineTreeWrap']//*[@class='row-fluid risk-info']//*[@type='radio']/following-sibling::span[contains(.,'"+RiskCategry+"')]";
				WebElementFacade selectRiskCategry=find(By.xpath(RiskCatXpath));
				UIHelper.highlightElement(getDriver(), selectRiskCategry);
				selectRiskCategry.click();
				String RiskVariableXpath = "//*[@class='cl-tabs-filter']//*[@id='refineTreeWrap']//*[@class='row-fluid risk-info']/div[contains(., '"+RiskCategry+"')]//*[@class='checkbox']/label[contains(., '"+RiskVarRange+"')]/input";
				System.out.println("------------------->>"+RiskVariableXpath);
				WebElementFacade selectRiskVariableCategry=find(By.xpath(RiskVariableXpath));
				UIHelper.highlightElement(getDriver(), selectRiskVariableCategry);
				selectRiskVariableCategry.click();					
				if(corpTreeUpadateLsit.isDisplayed()){
					UIHelper.highlightElement(getDriver(), corpTreeUpadateLsit);
					corpTreeUpadateLsit.click();
					getDriver().switchTo().defaultContent();
				}
			}
		}
		
		public boolean corpLinkageRefSearch(String RiskCategry){
			String RiskValidationXpath = "//*[@class='cl-container']/form[@id='cflFilterForm']/div[@class='cl-tabs-filter']//*[@class='row-fluid risk-info']/div//*[@class='risk-info-title'][contains(.,'"+RiskCategry+"')]";
			String RiskValXpath = "//*[@class='cl-container']/form[@id='cflFilterForm']/div[@class='cl-tabs-filter']//*[@class='row-fluid risk-info']/div//*[@class='risk-info-title']]";
			WebElementFacade riskDisplayedValidation=find(By.xpath(RiskValidationXpath));
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),RiskValXpath);
			UIHelper.highlightElement(getDriver(), riskDisplayedValidation);
			if(riskDisplayedValidation.isDisplayed())
				return true;
				else 
				return false;
			}
		
	    
		public boolean corpLinkaddedDataReset(){
			boolean view = false;
			corporateLinkageLink.click();
			UIHelper.waitForPageToLoad(getDriver());
			getDriver().switchTo().frame(crpIframe);
			corpRefineButton.isDisplayed();
			corpRefineButton.click();
			UIHelper.waitForPageToLoad(getDriver());
			corpTreeResetBttn.click();
			UIHelper.highlightElement(getDriver(), corpTreeCancelBttn);
			corpTreeCancelBttn.click();
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), CorpLinkageHQNameImg);
			UIHelper.highlightElement(getDriver(), CorpLinkageHQName);
			view = CorpLinkageHQName.isPresent() ; 
			getDriver().switchTo().defaultContent();
			return view;	
		}
		
		
		public boolean corpLinkagedataListDiaplyed(){	
			boolean view = false;
			corporateLinkageLink.click();
			getDriver().switchTo().frame(crpIframe);
			UIHelper.highlightElement(getDriver(), CorpListIcon);
			CorpListIcon.click();
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), CorpLinkageHQNameListView);
			UIHelper.highlightElement(getDriver(), CorpLinkageListView);
			view = CorpLinkageListView.isPresent() ; 
			getDriver().switchTo().defaultContent();
			return view;
		    }

		public boolean isCorporateLinkageTabDisplayed(){
			UIHelper.waitForPageToLoad(getDriver());
			String getText=tabHeaders.getText();
			if(getText.equalsIgnoreCase("Corporate Linkage"))
				return true;
			else 
				return false;
		}
		
		public void clickDetailedTradeRiskLink(){
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.highlightElement(getDriver(), detailedTradeRiskLink);
			detailedTradeRiskLink.click();
		}
		
		public boolean isDetailedTradeRiskTabDisplayed(){
			UIHelper.waitForPageToLoad(getDriver());
			String getText=tabHeaders.getText();
			String getText2=tabHeaders2.getText();
			System.out.println("Get Text value for Detailed Risk is*****" +getText);
			if(getText.contains("Detailed Trade Risk Insight")){
				
			}
			else if(getText2.contains("Detailed Trade Risk Insight")){
				
			}
				return true;
		}
		
		public void searchResultsAddtoFolder(String FolderName) {
			int optionFlag=0;
			if (addToFolderBtnInSearchResults.isVisible()) {
				addToFolderBtnInSearchResults.click();
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
				getDriver().switchTo().frame(iFrameEle);
				for(WebElementFacade options:folderOptions){
					if(options.getText().contains(FolderName)){
						folderOptionsList.selectByVisibleText(FolderName);
						searchResultsnapShotAddFolderSubmit.click();
						optionFlag=2;
						break;
					}else{
						optionFlag=1;
					}
					
				}
				if(optionFlag == 1){
					System.out
							.println("new folder need to create---------------------");
						UIHelper.highlightElement(getDriver(), ecfaddfolderCreateFolderasNew);
						ecfaddfolderCreateFolderasNew.click();
						getDriver().switchTo().defaultContent();
						UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
						getDriver().switchTo().frame(iFrameEle);
						if (newFolderName.isVisible()) {
							newFolderName.type(FolderName.toString().trim());
							newFolderNameAlertProfile
									.selectByVisibleText("Standard");
							searchResultsnapShotAddFolderSubmit.click();
							getDriver().switchTo().defaultContent();
						}
					}
				getDriver().switchTo().defaultContent();
				UIHelper.waitForPageToLoad(getDriver());
				 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), searchResultsConatiner);
			}
		}
		
		public String verify_Country_Name_In_InvestigationPage() {
			UIHelper.highlightElement(getDriver(), investigationPageHeader);
			UIHelper.highlightElement(getDriver(), countryelement);
			String fieldValuesinInvestigation = countryelementvalue.getAttribute("value").trim();
			System.out.println("fieldValuesinInvestigation---------------------- "+fieldValuesinInvestigation);
			return fieldValuesinInvestigation;
		}
		
		public void click_OI_Order_Btn(){
			if (orderBtn.isDisplayed()) {
				orderBtn.click();
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						OIConfirmPageHeader);
			}
		}
		
		public String verify_Country_Name_In_Confirm_InvestigationPage() {
			UIHelper.highlightElement(getDriver(), confirmationPageCountryelement);
			String fieldValuesinInvestigation = confirmationPageCountryelement.getText().trim();
			System.out.println("fieldValuesinInvestigation---------------------- "+fieldValuesinInvestigation);
			return fieldValuesinInvestigation;
		}
		

public boolean verify_CountryName_in_Investigation_Resutls(String CountryName){
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), investigationRequestDetailsTableXpath);
	int resultsFlag=0;
	System.out.println("Filter results list size======================="+investigationRequestDetailsTablerows.size());
	if(investigationRequestDetailsTablerows.size() > 0){
	for(WebElementFacade list: investigationRequestDetailsTablerows){
		UIHelper.mouseOveranElement(getDriver(), list);
		if (list.getText().contains(CountryName)){
			resultsFlag=1;
			break;
		}
	}
	}
	if(resultsFlag==1){
		return true;
	}else{
		return false;
	}

}
public void dontsaveduns(){
	if(dontsaved.isPresent()){
	dontsaved.click();
	waitFor(3000).milliseconds();
	}
}


public void anchorFinsLink() {
	if (financialsTab.isDisplayed()){
		financialsTab.click();
  		UIHelper.waitForPageToLoad(getDriver());
  }
}

public boolean accFinsSection() {
	// TODO Auto-generated method stub
	if (compFinAnchor.isDisplayed() && addFinDataAnchor.isDisplayed() && 
			addFinStatementAnchor.isDisplayed() && keyBusinessRatio.isDisplayed()){
		return true;
		}else{
			return false;
		}
}

public void docNotesLink() {
		if (notesDocTab.isDisplayed()){
			notesDocTab.click();
	  		UIHelper.waitForPageToLoad(getDriver());
	  }
   }

public boolean docElements() {
		// TODO Auto-generated method stub
		if (docExportlinl.isDisplayed() && docAddDoc.isDisplayed() && 
				docDelSelected.isDisplayed()){
				return true;
			}else{
				return false;
			}
	}
	
public void audutTrailTabLink() {
		if (auditTrailTab.isDisplayed()){
			auditTrailTab.click();
	  		UIHelper.waitForPageToLoad(getDriver());
	  }
   }
    
public boolean auditTextElementsDisplay() {
		// TODO Auto-generated method stub
		AtrialTextBttn.isDisplayed();
		      AtrialTextBttn.click();
		   UIHelper.waitForPageToLoad(getDriver());
		if ( AtrialTextElementsDisplayed.isDisplayed()){
				return true;
			}else{
				return false;
		}
}

public boolean auditTimeElementsDisplay() {
		// TODO Auto-generated method stub
		    AtrialTimeLineBttn.isDisplayed();
		    AtrialTimeLineBttn.click();
		   UIHelper.waitForPageToLoad(getDriver());
		if ( AtrialTimeLineElementsDisplayed.isDisplayed()){
				return true;
			}else{
				return false;
			}
	}
		
public void agingTabLink() {
		if (agingAccTab.isDisplayed()){
			agingAccTab.click();
	  		UIHelper.waitForPageToLoad(getDriver());
	  }
   }

public boolean accagingDropListDisplay( String dropValue) {
		// TODO Auto-generated method stub
	String DropdownValue = "//*[@id='widget_container']//*[@id='agingList']//*[@id='agingForm']/span//*[@id='agingOption']//option[contains(text(),'"+dropValue+"')]";
	WebElement dropDownList = getDriver().findElement(By.xpath(DropdownValue));
		if (dropDownList.isDisplayed()){
		//((WebElementFacade) dropDownList).selectByVisibleText(dropValue);
			    return true;
			}else{
				return false;
			}
	}

public void associationLink() {
	if (asscAccTab.isDisplayed()){
		asscAccTab.click();
  		UIHelper.waitForPageToLoad(getDriver());
  }
}

public boolean associationsLinkNames( String anchrLink) {
	// TODO Auto-generated method stub
String anchrLinkDisplayedValue = "//*[@id='widget_container']//*[@class='summary_links']//*[@id='containerAssociation']/ul/li/a[contains(text(),'"+anchrLink+"')]";
WebElement anchrLinkDisplayed = getDriver().findElement(By.xpath(anchrLinkDisplayedValue));
	if (anchrLinkDisplayed.isDisplayed()){
		    return true;
		}else{
			return false;
		}
}


public void customScoreLink() {
		if (customScoreTab.isDisplayed()){
			customScoreTab.click();
	  		UIHelper.waitForPageToLoad(getDriver());
	  }
   }

public boolean customScoreLinkName() {
			// TODO Auto-generated method stub
		if (customScoreNameDisplayed.isDisplayed()){
				    return true;
				}else{
					return false;
				}
		}
}
