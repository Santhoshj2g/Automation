/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.dnb.automation.dnbi.pages;

import java.util.List;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.apache.xalan.xsltc.compiler.util.ErrorMsg;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;
import com.dnb.automation.dnbi.pages.ECFPage;
/**********************************************************************************************
  * 
 * @author Vamsi Krishna NV
 * @version 1.0
 ***********************************************************************************************/

public class SearchAdvancedPage extends PageObject {
	ECFPage ecfPage;
	@FindBy(xpath = "//*[@id='dunsTab']//strong[contains(.,'Phone')]//following-sibling::span[1]")
    private WebElementFacade phoneNumberInEcfPage;
	
	@FindBy(xpath = "//*[@id='main']//*[@class='ecf_header']//*[@id='entNumber']")
    private WebElementFacade accNumberInEcfPage;
	
	@FindBy(xpath = "//div[@class='ecf_header']//*[@id='businessName']")
    private WebElementFacade accNameInEcfPage;
	
	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@class='moreOpt']//*[@id='quicksearch_more_options' and contains(text(),'More')]")
	private WebElementFacade companySearchmoreoptionsMore;
	
	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields_expanded']//*[@id='search_toc']//*[contains(text(),'Advanced Search')]")
	private WebElementFacade advancedSearcheTab;
	
	 @FindBy(xpath = "//*[@id='header_mainApp']//a[text()='Account Manager']")
	 private WebElementFacade accManagerHref;
	 
	 @FindBy(xpath = "//form[@id='quickSearchForm']//input[@id='quickSearchFld']")
	 private WebElementFacade accountSearchTxt;
	 
	 @FindBy(xpath = "//form[@id='quickSearchForm']//input[@value='Search']")
	 private WebElementFacade accountSearchBtn;
	 
	 @FindBy(xpath = "//table[@class='results full']//tbody//span[@class='lr_accts']//a[1]")
	 private WebElementFacade clickAccount;

	 @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@value,'Create Acc') and @type='button']")
	 private WebElementFacade accManagerCreateAccBTN;
	 
	 @FindBy(xpath = "//*[@id='main']//*[@id='page_title_links']//h2[contains(.,'Company Information')]")
	 private WebElementFacade createAccPageHeader;
	 
	 @FindBy(xpath = "//div[@class='widget']//div//table/tbody/tr[contains(.,'Update Application with Account Number')]/td/input[@type='checkbox']")
	 private WebElementFacade updateAccBtn;
	 
	 @FindBy(xpath = "//*[@class='outerDiv']//*[@id='backRight']//*[contains(@value,'Next')]")
	 private WebElementFacade accNextBtn;
	 
	 @FindBy(xpath = "//form[@id='createApplication']//*[@class='widget_form']//tbody//td[@class = 'errormsg']")
	 private WebElementFacade AccExist;
	 
	 @FindBy(xpath = "//*[@id='createApplication']//*[@class='frmSecEdit']//td[@class='frmField'][1]/a/img[contains(@src,'number_picker.gif')]")
	 private WebElementFacade ChgAccNumber;
	 
	 @FindBy(xpath = "//div[@class='reviewStatus']//input[@value='Create Account']")		
	 private WebElementFacade CreateAccount_Btn;
	 
	 @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//thead")
	  private WebElementFacade tabResultsEle;

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//tbody//tr[1]//td//*[contains(@name,'companyName')]")
	private WebElementFacade radioBTNCreatAccFromAccMGRTab;

	@FindBy(xpath = "//*[@id='main']//*[@class='entcommon_WarningBG']//b[contains(.,'We are unable to process')]")
	private WebElementFacade earningMsgEle;
	
	@FindBy(xpath = "//*[@id='main']//*[@class='entcommon_ListMargin'][contains(.,'The business is not listed, Please continue with the account')]")
    private WebElementFacade NotlistedMsgEle;
	
	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='option_name']//following-sibling::span[contains(.,'Please continue')]//preceding-sibling::input[1]")
	private WebElementFacade notListedRadioBtnEle;
	
	@FindBy(xpath = "//*[@id='main']//*[@class='entcommon_ListMargin'][contains(.,'The business is not listed, Please continue with the account')]//preceding-sibling::input[1]")
	private WebElementFacade notListedRadioElement;
	
	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='backRight']//*[contains(@value,'Next')]")
	private WebElementFacade nextButtonCreatAccFromAccMGRTab;

	@FindBy(xpath = "//*[@id='backRight']/input")
	private WebElementFacade orderInternationalNextBtnEle;
	
	@FindBy(xpath = "//*[@id='search_fields']//*[@id='entity_group_select']")
	private WebElementFacade adTypeEle;
	
	@FindBy(xpath = "//*[@id='search_fields']//*[@id='countryList']")
	private WebElementFacade adCountryEle;
	
	@FindBy(xpath = "//div[@id='search_options1']//div[@class='moreOpt']/a")
	private WebElementFacade moreOption;
	
	@FindBy(xpath = "//*[@id='search_fields']//*[@id='advanced_search_add_button'][@value='Add Search Field']")
	private WebElementFacade addSearchFieldBtn;
	
	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//select[@id='cat1']//option")
	private List <WebElementFacade> accVariabesList;
	
	
	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//select[@id='cat2']//option")
	private List <WebElementFacade> accOpotionsList;
	
	
	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//*[@class='modal_button']//input[@value='Select Field']")
	private WebElementFacade selectFieldBtn;
	
	@FindBy(xpath = "//*[@id='search_fields']//*[@id='advanced_search_submit_button']")
	private WebElementFacade adsSearchBtn;
	
	
	@FindBy(xpath = "//*[@id='advanced_search_criteria']//li//label[contains(.,'Business Name')]")
	private List <WebElementFacade> BusinessnameList;
	
	@FindBy(xpath = "//*[@id='advanced_search_criteria']//li//label[contains(.,'Account Number')]")
	private List <WebElementFacade> AccNoList;
	
	@FindBy(xpath = "//*[@id='main']//*[@class='results full']//tbody//tr//td/span/a[contains(.,'ACCOUNT')]")
	private WebElementFacade adsSearchResultsAccountnumbertext;
	
	@FindBy(xpath = "//*[@id='main']//table[@class='results full_company']//td[3]")
	private WebElementFacade adsSearchResultsCompNametext;
	
	@FindBy(xpath = "//*[@id='advanced_search_criteria']//li//span//a[contains(.,'Delete')]")
	private WebElementFacade searchFieldDeleteBtn;
	
	@FindBy(xpath="//div[@class='ecf_header']//ul[@id='pp_side_icon']//li[5]/a")
	private WebElementFacade printButton;
	
	@FindBy(xpath="//div[@class='ecf_header']//ul[@id='pp_side_icon']//li[4]/a")
	private WebElementFacade emailButton;
	
	@FindBy(xpath="//div[@class='ecf_header']//ul[@id='pp_side_icon']//li[@id='enablePdf']/a")
	private WebElementFacade PDFbutton;
	
	@FindBy(xpath="//div[@class='action_header']//input[@value='Match Company']")
	private WebElementFacade matchCompanyButton;
	
	@FindBy(xpath="//div[@class='action_header']//input[@value='Reassign']")
	private WebElementFacade reassignButton;
	
	@FindBy(xpath="//*[@id='ecf_toc1']/li/a[contains(.,'Corporate Linkage')]")
	private WebElementFacade corporateLinkageTab;
	
	@FindBy(xpath="//div[@class='summary_links']//tbody/tr/td/a")
	private WebElementFacade viewDynamicFamilyTreeLink;
	
	@FindBy(xpath="//*[@id='ecf_toc1']/li/a[contains(.,'Predictive Scores')]")
	private WebElementFacade predictiveScoresTab;
	
	@FindBy(xpath="//*[@id='ecf_toc1']/li/a[contains(.,'Aging')]")
	private WebElementFacade AgingTab;
	
	@FindBy(xpath="//*[@id='widget_container']/div[4]/div[1]/h3")
	private WebElementFacade dbViabilityRatingSummaryLabel;
	
	@FindBy(xpath="//*[@id='widget_container']/div[1]/ul/li[2]/a")
	private WebElementFacade creditCapacitySummary;
	
	@FindBy(xpath="//table[@class='viability_rating']/tbody/tr[1]/td[2]/p[1]/span")
	private WebElementFacade viabilityScoreLabel;
	
	@FindBy(xpath="//*[@id='widget_container']/div[5]/div[1]/h3")
	private WebElementFacade creditCapacitySummaryLabel;
	
	@FindBy(xpath="//*[@id='widget_container']/div[5]/table[1]/tbody/tr/td[1]/a")
	private WebElementFacade dbRatingLabel;
	
	@FindBy(xpath="//*[@id='widget_container']/div[6]/div[1]/h3")
	private WebElementFacade dbCreditLimitLabel;
	
	@FindBy(xpath="//*[@id='widget_container']/div[6]/table/tbody/tr/td[1]/table/tbody/tr[4]/td[1]")
	private WebElementFacade dbCreditLimitRiskCategoryLabel;
	
	@FindBy(xpath="//*[@id='widget_container']/div[7]/div[1]/h3")
	private WebElementFacade financialStressSummaryLabel;
	
	@FindBy(xpath="//*[@id='widget_container']/div[7]/strong")
	private WebElementFacade financialStressClassLabel;
	
	@FindBy(xpath="//*[@id='widget_container']/div[8]/div[1]/h3")
	private WebElementFacade creditScoreSummaryLabel;
	
	@FindBy(xpath="//*[@id='widget_container']/div[8]/table[1]/tbody/tr[1]/td/table/tbody/tr/td")
	private WebElementFacade creditScoreClassLabel;
	
	@FindBy(xpath="//*[@id='ecf_toc1']/li/a[contains(.,'Trade Payments')]")
	private WebElementFacade tradePaymentsTab;
	
	@FindBy(xpath="//*[@id='ecf_toc1']/li/a[contains(.,'Special Events')]")
	private WebElementFacade specialEventsTab;
	
	@FindBy(xpath="//*[@id='specialEvents']/div[1]/h3")
	private WebElementFacade specialEventHeading;
	
	@FindBy(xpath="//div[@id='ecf_toc_main']//li//a[contains(.,'History & Operations')]")
	private WebElementFacade HistoryOperations;
	
	
	 @FindBy(xpath="//div[@id='widget_container']//ul/li/a[contains(.,'SIC & NAICS')]")
     private WebElementFacade ChkSicNaics;
     
     @FindBy(xpath="//div[@id='widget_container']//ul/li/a[contains(.,'SIC & NAICS')]")
     private WebElementFacade SicNaicsIdentification;
     
     @FindBy(xpath="//div[@id='widget_container']//div//h3[contains(.,'SIC & NAICS')]")
     private WebElementFacade sicnaics;
     
     @FindBy(xpath="//div[@id='widget_container']/div[14]//p//b[contains(.,'SIC:')]")
     private WebElementFacade verifysic;
     
     @FindBy(xpath="//div[@id='widget_container']/div[14]/div[contains(.,'NAICS:')]")
     private WebElementFacade verifynaics;
	
	
	@FindBy(xpath="//*[@id='widget_container']/div[4]/div[1]/h3")
	private WebElementFacade dbPaydexSection;
	
	@FindBy(xpath="//*[@id='widget_container']/div[4]/div[3]/div[1]/img")
	private WebElementFacade paydexImage;
	
	@FindBy(xpath="//*[@id='widget_container']/div[5]/div[1]/h3")
	private WebElementFacade dbPaydexComparisonSection;
	
	@FindBy(xpath="//*[@id='widget_container']/div[5]/div[5]/div[1]/img")
	private WebElementFacade dbPaydexComparisonSectionImage;
	
	@FindBy(xpath="//*[@id='widget_container']/div[6]/div[1]/h3")
	private WebElementFacade dbPaymentHabits;
	
	@FindBy(xpath="//*[@id='widget_container']/div[6]/table/tbody/tr[2]/td[1]")
	private WebElementFacade dbPaymentHabitsTable;
	
	@FindBy(xpath="//*[@id='widget_container']/div[7]/div[1]/h3")
	private WebElementFacade paymentSummarySection;
	
	@FindBy(xpath="//*[@id='widget_container']/div[7]/table/tbody/tr[6]/td/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[2]/td[1]/b")
	private WebElementFacade paymentSummarySectionTable;
	
	@FindBy(xpath="//*[@id='widget_container']/div[8]/div[1]/h3")
	private WebElementFacade detailedPaymentHistory;
	
	@FindBy(xpath="//*[@id='widget_container']/div[8]/table/tbody/tr[1]/td/table/tbody/tr[1]/th[1]")
	private WebElementFacade detailedPaymentHistoryTable;
	
	@FindBy(xpath="//*[@id='ecf_toc1']/li/a[contains(.,'Public Filings')]")
	private WebElementFacade publicFillings;
	
	@FindBy(xpath="//*[@id='widget_container']/div[4]/div[1]/a/h3")
	private WebElementFacade publicFillingsSummaryLabel;
	
	@FindBy(xpath="//*[@id='widget_container']/div[4]/table/thead/tr/th[1]")
	private WebElementFacade publicFillingsSummaryTable;
	
	@FindBy(xpath="//*[@id='widget_container']/div[5]/h3")
	private WebElementFacade companyOverviewLabel;
	
	@FindBy(xpath="//*[@id='widget_container']/div[5]/table/tbody/tr[1]/td[1]")
	private WebElementFacade companyNameLabel;
	
	@FindBy(xpath="//div[@id='ecf_toc_main']//li//a[contains(.,'History & Operations')]")
	private WebElementFacade historyOperations;

	@FindBy(xpath="//*[@id='ecf_toc1']/li/a[contains(.,'Financials')]")
	private WebElementFacade financialTab;
	
	@FindBy(xpath="//*[@id='ecf_toc1']/li/a[contains(.,'Company Summary')]")
	private WebElementFacade companySummaryTab;
	
	@FindBy(xpath="//div[@id='compTitle']//ul[@id='pp_side_icon']//a")
	private WebElementFacade customizeButton;
	
	@FindBy(xpath="//div[@id='widget_container']//tbody/tr/td/fieldset[@id='Main_Left']//div/h3")
	private List<WebElementFacade> leftWidgetHeading;
	
	@FindBy(xpath="//div[@id='widget_container']//tbody/tr/td/fieldset[@id='Main_Right']//div/h3")
	private List<WebElementFacade> rightWidgetHeading;
	
	@FindBy(xpath="//tbody[@id='com_cust_us']/tr/td/span[contains(.,'Company Overview')]/preceding-sibling::input")
	private WebElementFacade selectCustomizeSections;
	
	@FindBy(xpath="//*[@id='widget_container']/div[4]/div[1]/h3")
	private WebElementFacade companyFinancialLabel;
	
	@FindBy(xpath="//div[@id='companyFinancialWidget']//input[@id='display_bus_financials']")
	private WebElementFacade spreadFinancialsButton;
	
	@FindBy(xpath="//*[@id='financeWidget']/div[1]/h3")
	private WebElementFacade additionalFinancialDataLabel;
	
	@FindBy(xpath="//div[@id='financeWidget']//tbody//tbody//tr//tr[contains(.,'Liabilities + Equity')]")
	private WebElementFacade currentAssetsLabel;
	
	@FindBy(xpath="//*[@id='financialsList1']/div[1]/h3")
	private WebElementFacade financialStatementLabel;
	
	@FindBy(xpath="//div[@id='financialsList']//input[@id='add_financial']")
	private WebElementFacade addFinancialBtn;
	
	@FindBy(xpath="//*[@id='keyBizRatiosWidget']/div[1]/h3")
	private WebElementFacade keyBusinessRatio;
	
	@FindBy(xpath="//div[@id='companyFinancialWidget']//select[@id='dataSourceType']")
	private WebElementFacade selectDBSource;
	
	@FindBy(xpath="//*[@id='keyBizRatiosWidget']/table[2]/tbody/tr[1]/td[1]/span")
	private WebElementFacade keyBusinessRatioTable;
	
	@FindBy(xpath="//*[@id='ecf_toc1']/li/a[contains(.,'Notes')]")
	private WebElementFacade NotesTab;
	
	@FindBy(xpath="//*[@id='noteForm']/div[1]/input")
	private WebElementFacade addNoteButton;
	
	@FindBy(xpath="//*[@id='expNoteData']/span")
	private WebElementFacade exportLink;
	
	@FindBy(xpath="//*[@id='Document_Widget']/div[1]/div[3]/input[1]")
	private WebElementFacade addDocument;
	
	@FindBy(xpath="//div[@id='Document_Widget']//input[@value='Delete Selected']")
	private WebElementFacade deleteSelected;
	
	@FindBy(xpath="//*[@id='ecf_toc1']/li/a[contains(.,'Account Information')]")
	private WebElementFacade accountInformationTab;
	
	@FindBy(xpath="//*[@id='widget_container']/div[1]/div[3]/input[1]")
	private WebElementFacade addTradeBankReference;
	
	@FindBy(xpath="//*[@id='widget_container']/div[1]/div[3]/input[2]")
	private WebElementFacade addGuarantor;
	
	@FindBy(xpath="//div[@class='frmSecEdit']//input[@id='Business' and @value='Edit']")
	private WebElementFacade editCompanyInformation;
	
	@FindBy(xpath="//div[@class='frmSecEdit']//input[@id='Contact Information' and @value='Edit']")
	private WebElementFacade editContactInformation;
	
	@FindBy(xpath="//div[@class='frmSecEdit']//input[@id='Profile' and @value='Edit']")
	private WebElementFacade editCompanyProfile;
	
	@FindBy(xpath="//div[@class='frmSecEdit']//input[@id='Business Identification' and @value='Edit']")
	private WebElementFacade editCompanyIdentification;
	
	@FindBy(xpath="//div[@class='frmSecEdit']//input[@id='Account' and @value='Edit']")
	private WebElementFacade editAccountInformation;
	
	@FindBy(xpath="//div[@class='frmSecEdit']//input[@id='Order Information' and @value='Edit']")
	private WebElementFacade editOrderInformation;
	
	@FindBy(xpath="//*[@id='ecf_toc1']/li/a[contains(.,'Custom Score')]")
	private WebElementFacade customScoreTab;
	
	@FindBy(xpath="//*[@id='scoreTrendWidget']/form[2]/table/tbody/tr[1]/td[1]/a")
	private WebElementFacade scoreLink;
	
	@FindBy(xpath="//*[@id='ecf_toc1']/li/a[contains(.,'Audit Trail')]")
	private WebElementFacade auditTrailTab;
	
	@FindBy(xpath="//div[@id='aud_tab1']/div/div/a[1]")
	private WebElementFacade viewByTextBtn;

	@FindBy(xpath="//div[@id='aud_tab1']/div/div/a[2]")
	private WebElementFacade viewByTextTimeLine;
	
	@FindBy(xpath="//div[@id='timeline']//select[@id='categoryName1']")
	private WebElementFacade viewAllEvents;
	
	@FindBy(xpath="//*[@id='ecf_toc1']/li/a[contains(.,'Trade Payments')]")
	private WebElementFacade tradePayments;
	
	@FindBy(xpath="//*[@id='widget_container']/div[4]/div[3]/div[1]/img")
	private WebElementFacade tradePaymentImage;
	
	@FindBy(xpath="//*[@id='widget_container']/div[1]/ul/li[1]/a")
	private WebElementFacade summaryLink;
	
	@FindBy(xpath="//div[@class='floatRight']//input[@value='Return to Company Summary']")
	private WebElementFacade returnCompanySummaryBtn;
	
	@FindBy(xpath="//table[@id='scorebar1']//span[contains(text(),'PAYDEX')]/ancestor::tr//img[@class='scorebar_img']")
	private WebElementFacade scoreBarImage;
	
	@FindBy(xpath="//*[@id='widget_container']/div[4]/div[2]/div[4]/a/strong")
	private WebElementFacade customizeScoreBar;
	
	@FindBy(xpath="//div[@id='main']//input[@value='Return to Score Bar']")
	private WebElementFacade scoreReturnSummary;
	
	@FindBy(xpath="//div[@class='widget_full']//tbody//a[contains(.,'D&B Rating')]")
	private WebElementFacade dbRatingLink;
	
	@FindBy(xpath="//*[@id='widget_container']/div[6]/div[1]/h3")
	private WebElementFacade creditLimitRecommend;
	
	@FindBy(xpath="//*[@id='widget_container']/div[8]/table[1]/tbody/tr[3]/td/img")
	private WebElementFacade scoreTrend;
	
	@FindBy(xpath="//div[@class='primaryNav_div']//li[a[contains(.,'Account Manager')]]")
	private WebElementFacade accountManagerTab;
	
	@FindBy(xpath="//div[@class='dd_inboxL']//span[contains(.,'Credit Hold Advised')]")
	private WebElementFacade creditHoldAdvised;
	
	@FindBy(xpath="//*[@id='tab1']/table/tbody/tr/td/form/table/tbody/tr/td[1]/a")
	private WebElementFacade agingRecord;
	
	@FindBy(xpath="//form[@id='agingForm']//select[@id='agingOption']")
	private WebElementFacade agingTrendDropDownValues;
	
	@FindBy(xpath="//*[@id='expAgingData']/span")
	private WebElementFacade agingExportLink;
	
	@FindBy(xpath="//*[@id='exposureRollup']/div[2]/input[1]")
	private WebElementFacade viewCorporateExposureReport;
	
	@FindBy(xpath="//*[@id='exposureRollup']/div[2]/input[2]")
	private WebElementFacade viewCustomizeReportButtons;
	
	@FindBy(xpath="//div[@id='widget_container']/div[2]//ul//li//a[contains(.,'Business Registration')]")
    private WebElementFacade BusReg;
    
    @FindBy(xpath="//div[@id='widget_container']//div[10]/table/tbody/tr[1]/td[2]")
    private WebElementFacade RegisteredName;
	
	@FindBy(xpath="//div[@id='entity_header']/h2")
	private WebElementFacade AccName;
	
	@FindBy(xpath="//div[@id='widget_container']/div[2]/div[1]/h3")
	private WebElementFacade ChkAssociate;
	
	@FindBy(xpath="//div[@id='ecf_toc_main']//li//a[contains(.,'Associations')]")
    private WebElementFacade ChkAssociations;
    
    @FindBy(xpath="//div[@id='widget_container']//li//a[contains(.,'All Accounts')]")
    private WebElementFacade AllAccount;
    
    @FindBy(xpath="//div[@id='widget_container']//li//a[contains(.,'All Applications')]")
    private WebElementFacade AllApplications;
	
	@FindBy(xpath="//div[@id='main']//input[@value='Export to File']")
	private WebElementFacade exportToFileBtn;
	
	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
	public WebElementFacade iFrameEle;
	
	@FindBy(xpath="//body[@class='iframe_modal']//div[@class='modal_inner_content']//div[@id='seld']//select[@id='selectedFields']")
	private WebElementFacade selectedFields;
	
	@FindBy(xpath="//body[@class='iframe_modal']//div[@class='modal_inner_content']//div[@id='vars']//select[@id='pool']")
	private WebElementFacade selectNewFields;
	
	@FindBy(xpath="//body[@class='iframe_modal']//div[@class='modal_inner_content']//div[@id='sel']//a[@id='add']")
	private WebElementFacade addButton;
	
	@FindBy(xpath="//body[@class='iframe_modal']//div[@class='modal_inner_content']//div[@id='sel']//a[@id='remove']")
	private WebElementFacade removeButton;
	
	@FindBy(xpath="//body[@class='iframe_modal']//div[@class='modal_buttons']//input[@value='Submit']")
	private WebElementFacade submitCustomizeButton;
	
	@FindBy(xpath="//div[@id='timeline']//select[@id='categoryName1']")
	private WebElementFacade viewLabelDropDown;
	
	
	@FindBy(xpath="//div[@class='review_box']//div[@class='review_buttons']//input[@value='Clear']")
	private WebElementFacade clearButton;
	
	@FindBy(xpath="//*[@id='quickSearchForm']//*[@id='quickSearchFld']")
	private WebElementFacade quicksearchfield;
	
	
	@FindBy(xpath="//body[@class='iframe_modal']//div[@class='modal_buttons']//input[@value='Continue']")
	private WebElementFacade clearContinueButton;
	
	@FindBy(xpath ="//*[@class='ecf_header']//*[@id='entity_header']//*[@id='businessName']")
	public WebElementFacade appEcf_Header;
	
	
	
	@FindBy(xpath="//*[@id='main']//table[@class='results full']//tbody//tr[1]//td//span[1][contains(.,'Create Account')]")
	private WebElementFacade searchResutlsCreateAccountLink;
	
	@FindBy(xpath="//*[@class='widget_container']//*[@id='backRight']/input[@value='Next']")
	private WebElementFacade createAcc_Int_Next;
	
	@FindBy(xpath="//*[@id='dunsTab']/li[contains(.,'Country')]/span")
	private WebElementFacade ecfPage_CountryName;
	
	 @FindBy(xpath = "//*[@id='primaryNav']//li//a[contains(.,'Companies')]")
	    private WebElementFacade companiesTab;
	 
	    private String loadingImageEleXpath = "//*[@id='loading']/span";
	    
	    @FindBy(xpath = "//form[@action='showAllFolderSummary']/table/tbody//tr//td/a[contains(text(),'All Credit Files')]")
	    private WebElementFacade AllCreditFilesFolder;
	    
	    @FindBy(xpath = "//form[@action='showAllFolderSummary']/table/tbody//tr//td/a[contains(text(),'Accounts')]")
	    private WebElementFacade AllAccountsFolder;
	    
	    @FindBy(xpath="//*[@class='alert_box include_filterBG']//*[@id='entityFilter']")
	    private WebElementFacade EntityFilter;
	    
	    @FindBy(xpath="//*[@class='alert_box include_filterBG']//*[@value='Apply']")
	    private WebElementFacade EntityFilterApplyBtn;
	    
	    @FindBy(xpath="//*[@name='pageForm']//*[@class='floatLeft']//*[@id='viewItems']")
	    private WebElementFacade ViewItemsSelect;
	    @FindBy(xpath="//*[@id='text']//*[@action='dispatchHistoryList']//*[@class='results full tab_border']")
	    private WebElementFacade testViewTable;
	private static String domesticPhoneNumberECF;
    
	public static String getDomesticPhoneNumberECF() {
		return domesticPhoneNumberECF;
	}
			
    private static String domesticAccNumberECF;
  
	public static String getDomesticAccNumberECF() {
		return domesticAccNumberECF;
	}
	private static String domesticAccNameECF;
	  
	public static String getDomesticAccNameECF() {
		return domesticAccNameECF;
	}
	private static String internationalAccNumberECF;

	public static String getInternationalAccNumberECF() {
		return internationalAccNumberECF;
	}

	 private static String accNumberECF;
	 
	public static String getAccNumberECF() {
		return accNumberECF;
	}
	
	 private static String appNumberECF;
	 
		public static String getAppNumberECF() {
			return appNumberECF;
		}

	String accManagerCreateAccBTNXpath="//*[@class='outerDiv']//*[contains(@value,'Create Acc') and @type='button']";
	String createAccPageHeaderXpath="//*[@id='main']//*[@id='page_title_links']//h2[contains(.,'Company Information')]";
	String moreOptionXpath="//*[@class='outerDiv']//*[@id='quicksearch_more_options' and contains(text(),'Fewer')] | //*[@class='outerDiv']//*[@id='search_box']//*[@class='moreOpt']//*[@id='quicksearch_more_options' and contains(text(),'More')]";
	String companySearchXpath="//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields_expanded']//*[@id='search_toc']//*[contains(text(),'Company')]";
	String tabresult="//*[@class='outerDiv']//*[contains(@class,'results')]//thead";
	String liveReportHeaderXpath="//*[@id='main']//*[@class='ecf_header']//*[@id='entity_header']//h2";
	String adTypeXpath="//*[@id='search_fields']//*[@id='entity_group_select']";
	String modelContentXpath="//*[@class='modal']//*[@class='modal_content']//select[@id='cat1']";
	String adSearchCriteriaXpath="//*[@id='advanced_search_criteria']";
	String adsSearchResultsXpath="//*[@id='main']//table[@class='results full_company']//thead";
	String accpageheader="//*[@id='page_title_links']/h2";
	
/*	***************************************************************************************************************
	 * @author Vamsi Krishna NV
	 * @version 1.0
	 ****************************************************************************************************************/
	
	public void getDomesticAccNoInEcfPage(){
		UIHelper.highlightElement(getDriver(), accNumberInEcfPage);
		domesticAccNumberECF=accNumberInEcfPage.getText().trim();
		System.out.println("acc number domestic------ "+domesticAccNumberECF);
	}
	
	public void getDomesticAccNameInEcfPage(){
		UIHelper.highlightElement(getDriver(), accNameInEcfPage);
		domesticAccNameECF=accNameInEcfPage.getText().trim();
		System.out.println("acc name domestic------ "+domesticAccNameECF);
	}
	public void getAccNoInEcfPage(){
		UIHelper.highlightElement(getDriver(), accNumberInEcfPage);
		accNumberECF=accNumberInEcfPage.getText().trim();
		System.out.println("acc number domestic------ "+accNumberECF);
	}
	
	public void getAppNoInEcfPage(){
		UIHelper.highlightElement(getDriver(), accNumberInEcfPage);
		appNumberECF=accNumberInEcfPage.getText().trim();
		System.out.println("acc number domestic------ "+appNumberECF);
	}

/*public void getDomesticPhoneNoInEcfPage(){
	UIHelper.highlightElement(getDriver(), phoneNumberInEcfPage);
	domesticPhoneNumberECF=phoneNumberInEcfPage.getText().trim();
	System.out.println("phone number domestic------ "+domesticPhoneNumberECF);
}
*/
	public void getInternationalAccNoInEcfPage(){
		UIHelper.highlightElement(getDriver(), accNumberInEcfPage);
		internationalAccNumberECF=accNumberInEcfPage.getText().trim();
		System.out.println("acc number international------ "+internationalAccNumberECF);
	}
	
	public boolean verifyAccNodisplayedinAllCreditFolder(){
		UIHelper.highlightElement(getDriver(), accNumberInEcfPage);
		internationalAccNumberECF=accNumberInEcfPage.getText().trim();
		System.out.println("acc number international------ "+internationalAccNumberECF);
		String accNumber = internationalAccNumberECF;
		//String accNumber = "654654654654654";
		System.out.println("internationalAccNumberECF Name----------------->>"+accNumber);
		   
		    UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//*[@id='primaryNav']//li//a[contains(.,'Companies')]");
			System.out.println("Moving towards companies tab");
			((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", companiesTab);
	        companiesTab.click();
	        
	        UIHelper.waitForPageToLoad(getDriver());
	        UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
	                loadingImageEleXpath);	
	        
	        AllCreditFilesFolder.isVisible();
	        UIHelper.highlightElement(getDriver(), AllCreditFilesFolder);
	        AllCreditFilesFolder.click();
	        UIHelper.waitForPageToLoad(getDriver());
	        
	        UIHelper.highlightElement(getDriver(), EntityFilter);
	        EntityFilter.selectByVisibleText("Accounts");
	        EntityFilterApplyBtn.click();
	        UIHelper.waitForPageToLoad(getDriver());
	        
	        UIHelper.highlightElement(getDriver(), ViewItemsSelect);
	        ViewItemsSelect.selectByVisibleText("500");
	        UIHelper.waitForPageToLoad(getDriver()); 
	        
	        if((getDriver()
					.findElement(
							By.xpath("//*[@class='results full_company']//tbody/tr/td[2]/span/a[contains(.,'"
									+ accNumber.trim()
									+ "')]"))).isDisplayed()){
							return true;				
	        		}else{
				   			return false;
	        		}
	   		}
	       
		public boolean verifyAccNodisplayedinAccountFolder(){
		UIHelper.highlightElement(getDriver(), accNumberInEcfPage);
		internationalAccNumberECF=accNumberInEcfPage.getText().trim();
		System.out.println("acc number international------ "+internationalAccNumberECF);
		String accNumber = internationalAccNumberECF;
		//String accNumber = "DNBi-FJVMQHJMJ5HY8";
		System.out.println("internationalAccNumberECF Name----------------->>"+accNumber);		   
		    UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//*[@id='primaryNav']//li//a[contains(.,'Companies')]");
			System.out.println("Moving towards companies tab");
			((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", companiesTab);
	        companiesTab.click();
	        
	        UIHelper.waitForPageToLoad(getDriver());
	        UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
	                loadingImageEleXpath);	
	        
	        AllAccountsFolder.isVisible();
	        UIHelper.highlightElement(getDriver(), AllAccountsFolder);
	        AllAccountsFolder.click();
	        UIHelper.waitForPageToLoad(getDriver());
	        	        
	        UIHelper.highlightElement(getDriver(), ViewItemsSelect);
	        ViewItemsSelect.selectByVisibleText("500");
	        UIHelper.waitForPageToLoad(getDriver()); 
	       
	        if((getDriver()
					.findElement(
							By.xpath("//*[@class='results full_company']//tbody/tr/td[2]/span/a[contains(.,'"
									+ accNumber.trim()
									+ "')]"))).isDisplayed()){
							return true;
	        		}else{
				   			return false;
				   			
	        		}
	   		}
	

	public void click_CreateBtn_AccManagerTab(){

		try {
			accManagerHref.isPresent();
			accManagerHref.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), accManagerCreateAccBTNXpath);
			accManagerCreateAccBTN.click();
        
        	} catch (Exception e) {

        	}

	}
	
	public void click_AccManagerTab(){

		try {
			accManagerHref.isPresent();
			accManagerHref.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), accManagerCreateAccBTNXpath);
			} catch (Exception e) {

        	}

	}
	
	public void searchAccNumberPage(String accNumber){
		try{
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), accountSearchTxt);
		accountSearchTxt.sendKeys(accNumber);
		UIHelper.highlightElement(getDriver(), accountSearchBtn);
		Thread.sleep(4000);
		accountSearchBtn.click();
		Thread.sleep(4000);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public boolean verify_Create_Acc_Page_Has_Displayed(){
		try{
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), createAccPageHeaderXpath);
			UIHelper.highlightElement(getDriver(), createAccPageHeader);
			return true;
		
		}catch (Exception e) {
			return false;

		}
	}
	
	public void clickAccountDisplayPage(){
		UIHelper.waitForPageToLoad(getDriver());
		clickAccount.click();
	}

public void acc_Enter_Input_Value(String SectionName, String FieldName, String Value){
	try{
	String fieldvalueXpath="//*[@id='createApplication']//h3[contains(.,'"+SectionName+"')]//following-sibling::div[@class='frmSecEdit']//tbody//td[contains(.,'"+FieldName+"')]//following-sibling::td[@class='frmField']//input";
	WebElementFacade fieldvalueelement=find(By.xpath(fieldvalueXpath));
	UIHelper.highlightElement(getDriver(), fieldvalueelement);
	fieldvalueelement.clear();
	fieldvalueelement.sendKeys(Value);
	}catch (Exception e) {
		e.printStackTrace();
    }
	
}

public void acc_Select_Input_Value(String SectionName, String FieldName, String Value){
	try{
	String fieldvalueXpath=".//*[@id='createApplication']//h3[contains(.,'"+SectionName+"')]//following-sibling::div[@class='frmSecEdit']//tbody//td[contains(.,'"+FieldName+"')]//following-sibling::td[@class='frmField']//select";
	WebElementFacade fieldvalueelement=find(By.xpath(fieldvalueXpath));
	UIHelper.highlightElement(getDriver(), fieldvalueelement);
	fieldvalueelement.selectByVisibleText(Value);
	}catch (Exception e) {

    }
	
}

public void Clk_Create_Account(){		
try{		
	UIHelper.highlightElement(getDriver(), CreateAccount_Btn);		
		CreateAccount_Btn.click();		
}catch (Exception e) {		
	e.printStackTrace();		
}		
		
}

public void unchk_update_Account(){
	try{
		UIHelper.highlightElement(getDriver(), updateAccBtn);
		if(updateAccBtn.isSelected()){
			updateAccBtn.click();
		}
		 //UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tabresult);//
	}catch (Exception e) {
		e.printStackTrace();
    }
	
}

public void click_Acc_Next_Btn(){
	try{
		accNextBtn.waitUntilClickable();
		UIHelper.mouseOveranElement(getDriver(), accNextBtn);
		accNextBtn.click();
		//UIHelper.waitForVisibilityOfEleByXpath(getDriver(), accpageheader);
		if(updateAccBtn.isSelected()){
			updateAccBtn.click();
		}
	
			 String err = "//form[@id='createApplication']//*[@class='widget_form']//tbody//td[contains(.,'This account number already exists')]";
			 WebElementFacade errelement= find(By.xpath(err));
			 if(errelement.isVisible()){
				 UIHelper.highlightElement(getDriver(), ChgAccNumber);
				 ((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", ChgAccNumber);
				 waitFor(4000).milliseconds();
				 ((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", accNextBtn);
			 }
			 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), liveReportHeaderXpath);
			 UIHelper.highlightElement(getDriver(), appEcf_Header);
		 
	}catch (Exception e) {
		e.printStackTrace();
    }
	
}

public void gotoECFFromAccResultsSearch(){

    try {

        if (tabResultsEle.isPresent()) {
        	UIHelper.highlightElement(getDriver(), tabResultsEle);
        	waitFor(5000).milliseconds();
            if (radioBTNCreatAccFromAccMGRTab.isPresent()) {
            	radioBTNCreatAccFromAccMGRTab.waitUntilClickable();
                radioBTNCreatAccFromAccMGRTab.click();
            }
        } else if (earningMsgEle.isPresent()) {
        	notListedRadioBtnEle.waitUntilClickable();
            notListedRadioBtnEle.click();
        } else if (NotlistedMsgEle.isPresent()) {
        	notListedRadioElement.waitUntilClickable();
        	notListedRadioElement.click();
        }
        nextButtonCreatAccFromAccMGRTab.click();
        UIHelper.waitForVisibilityOfEleByXpath(getDriver(), liveReportHeaderXpath);
        /*
        if (orderInternationalNextBtnEle.isPresent()) {

            orderInternationalNextBtnEle.click();
            
            UIHelper.waitForPageToLoad(getDriver());
        }*/

    } catch (Exception e) {
        e.printStackTrace();
    }
 
}

	public void click_Advanced_Search(){
	try{
		
		advancedSearcheTab.isVisible();
			UIHelper.highlightElement(getDriver(), advancedSearcheTab);
			advancedSearcheTab.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), adTypeXpath);
	}catch (Exception e) {
        e.printStackTrace();
	}

	}
	
	/*public void clk_advance_search(){
		try{
			moreOption.waitUntilClickable();
			UIHelper.highlightElement(getDriver(), moreOption);
			moreOption.click();
			if(advancedSearcheTab.isVisible()){
				UIHelper.highlightElement(getDriver(), advancedSearcheTab);
				advancedSearcheTab.click();
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), adTypeXpath);
			}
	}catch (Exception e) {
        e.printStackTrace();
	}
	}*/
	
	public void select_Type_And_Country(String Type, String Country){
		try{
			adTypeEle.selectByVisibleText(Type);
			adTypeEle.click();
			UIHelper.processalert(getDriver());
			adCountryEle.selectByVisibleText(Country);
			adCountryEle.click();
		}catch (Exception e) {
			e.printStackTrace();		
		}
	}
	public void delete_searchfield(String fname){
		try{
			String fieldname="//*[@id='advanced_search_criteria']//*[@id='fieldInfoBean1'][contains(.,'"+fname+"')]//*[@class='deleteArea']//a[@class='delete_criterion']";
			WebElementFacade getfielddelete=find(By.xpath(fieldname));
			if(getfielddelete.isPresent()){
			getfielddelete.click();
			}
		}catch (Exception e) {
			e.printStackTrace();		
		}
	}
	public void click_Add_Search_Field_Btn(){
			addSearchFieldBtn.waitUntilClickable();
			addSearchFieldBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), modelContentXpath);
	}
	public void acc_Select_Variable(String VariableName){
			System.out.println("value sent input----"+VariableName);
			Select accVariabesListele= new Select(getDriver().findElement(By.xpath("//*[@class='modal']//*[@class='modal_content']//select[@id='cat1']")));
			for(WebElementFacade Vname : accVariabesList){
				System.out.println("category Name-------"+Vname.getText().trim());
				if(Vname.getText().trim().toString().equals(VariableName.trim())){
					
					System.out.println("values matched inside if con----------");
					Vname.click();
					break;
					}
				System.out.println("values not mathced----------------");
				}
	}
	private List<WebElementFacade> thenFindAll(By xpath) {
		// TODO Auto-generated method stub
		return null;
	}

	public void acc_Select_Option(String OptionName){
			System.out.println("filed sent input----"+OptionName);
			Select accOpotionsListEle= new Select(getDriver().findElement(By.xpath("//*[@class='modal']//*[@class='modal_content']//select[@id='cat2']")));
			for(WebElementFacade Oname : accOpotionsList){
				System.out.println("Filed name-----"+Oname.getText().trim());
				if(Oname.getText().trim().equals(OptionName)){
					System.out.println("option matched---------------");
					Oname.click();
					break;
					}
				}
	}
	
	public void click_Add_Search_Btn(){
			selectFieldBtn.waitUntilClickable();
			UIHelper.highlightElement(getDriver(), selectFieldBtn);
			selectFieldBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), adSearchCriteriaXpath);
	}
	
	public boolean ads_Search_Field(String FieldName){
		int lnameFlage=0;
		for(WebElementFacade Lname : BusinessnameList){
			if(Lname.getText().trim().contains(FieldName)){
				lnameFlage=1;
				break;
				}
			else{
				lnameFlage=2;
			}
			}
		if(lnameFlage==1){
			return true;
			
		}else{
			return false;
		}
}
	public void acc_Search_Enter_Input_Values(String FieldName, String Option, String Value){
		String listFieldXpath="//*[@id='advanced_search_criteria']//li//label[contains(.,'"+FieldName+"')]//following-sibling::select[1]";
		String inputFieldXpath="//*[@id='advanced_search_criteria']//li//label[contains(.,'"+FieldName+"')]//following-sibling::span[1]//input";
		WebElementFacade listFieldElement=find(By.xpath(listFieldXpath));
		WebElementFacade inputFieldElement=find(By.xpath(inputFieldXpath));
		UIHelper.highlightElement(getDriver(), listFieldElement);
		listFieldElement.selectByVisibleText(Option);
		UIHelper.highlightElement(getDriver(), inputFieldElement);
		inputFieldElement.clear();
		inputFieldElement.sendKeys(Value);
	}
	public boolean acc_Input_Values_in_searchtextbox(String Value){
		UIHelper.highlightElement(getDriver(), quicksearchfield);
		quicksearchfield.sendKeys(Value);
		return true;
	}
	
	public void acc_Search_Select_Input_Values(String FieldName, String Option, String Value){
		try{
			
		String listFieldXpath="//*[@id='advanced_search_criteria']//li//label[contains(.,'"+FieldName+"')]//following-sibling::select[1]";
		String inputFieldXpath="//*[@id='advanced_search_criteria']//li//label[contains(.,'"+FieldName+"')]//following-sibling::span[1]//select";
		WebElementFacade listFieldElement=find(By.xpath(listFieldXpath));
		WebElementFacade inputFieldElement=find(By.xpath(inputFieldXpath));
		UIHelper.highlightElement(getDriver(), listFieldElement);
		listFieldElement.selectByVisibleText(Option);
		UIHelper.highlightElement(getDriver(), inputFieldElement);
		inputFieldElement.selectByVisibleText(Value);
		
		}catch (Exception e) {
			e.printStackTrace();		
		}
		
	}
	
	public void click_Ads_Search_Btn(){
		try{
			UIHelper.highlightElement(getDriver(), adsSearchBtn);
			adsSearchBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), adsSearchResultsXpath);
		}catch (Exception e) {
			e.printStackTrace();		
		}
	}
	public void click_quick_Search_Btn(){
		accountSearchBtn.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), accountSearchBtn);
		accountSearchBtn.click();
	}
	public boolean verify_Ac_No_In_Search_Results(String AccountNumber){
		try{
		String acctext=adsSearchResultsAccountnumbertext.getText();
		UIHelper.highlightElement(getDriver(), adsSearchResultsAccountnumbertext);
		System.out.println("ANumber in search results----------"+acctext);
		System.out.println("ANumber send as input----------"+AccountNumber);

		if(acctext.contains(AccountNumber)){
			return true;
		}
		}catch (Exception e) {
			e.printStackTrace();		
		}
			return false;
	}
	
	public boolean verify_Comp_Name_In_Search_Results(String CompanyName){
		String acctext=adsSearchResultsCompNametext.getText();
		System.out.println("company name in search results----------"+acctext);
		if(acctext.contains(CompanyName)){
			return true;
			
		}
		else{
			return false;
		}
		
	}
	public void delete_SearchFields(){
		try{
			searchFieldDeleteBtn.isVisible();
			searchFieldDeleteBtn.click();
		}catch (Exception e) {
		       
			}
	}
	
	public boolean validatePrintButton(){
		UIHelper.highlightElement(getDriver(), printButton);
		if(printButton.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean validateEmailButton(){
		UIHelper.highlightElement(getDriver(), emailButton);
		if(emailButton.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean validatePDFButton(){
		UIHelper.highlightElement(getDriver(), PDFbutton);
		if(PDFbutton.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean validateMatchCompanyButton(){
		UIHelper.highlightElement(getDriver(), matchCompanyButton);
		if(matchCompanyButton.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean validateReassignButton(){
		UIHelper.highlightElement(getDriver(), reassignButton);
		if(reassignButton.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean validateDynamicFamilyTreeLink(){
		UIHelper.highlightElement(getDriver(), corporateLinkageTab);
		corporateLinkageTab.click();
		UIHelper.highlightElement(getDriver(), viewDynamicFamilyTreeLink);
		if(viewDynamicFamilyTreeLink.isDisplayed()){
			return true;
		}
		return false;
	}
	
	public boolean validateDBViabilitySection(){
		UIHelper.highlightElement(getDriver(), predictiveScoresTab);
		predictiveScoresTab.click();
		UIHelper.highlightElement(getDriver(), dbViabilityRatingSummaryLabel);
		UIHelper.highlightElement(getDriver(), viabilityScoreLabel);
		if(dbViabilityRatingSummaryLabel.isDisplayed() && viabilityScoreLabel.isDisplayed()){
			return true;
		}
		return false;
	}
	
	public boolean validateCreditCapacitySummaryPage(){
		UIHelper.highlightElement(getDriver(), creditCapacitySummaryLabel);
		UIHelper.highlightElement(getDriver(), dbRatingLabel);
		if(creditCapacitySummaryLabel.isDisplayed() && dbRatingLabel.isDisplayed()){
			return true;
		}
		return false;
	}
	
	public boolean dbCreditLimitRecommendationPage(){
		UIHelper.highlightElement(getDriver(), dbCreditLimitLabel);
		//UIHelper.highlightElement(getDriver(), dbCreditLimitRiskCategoryLabel);
		//if(dbCreditLimitLabel.isDisplayed() && dbCreditLimitRiskCategoryLabel.isDisplayed()){
		if(dbCreditLimitLabel.isDisplayed()){
			return true;
		}
		return false;
	}
	
	public boolean financialStressClassPage(){
		UIHelper.highlightElement(getDriver(), financialStressSummaryLabel);
		UIHelper.highlightElement(getDriver(), financialStressClassLabel);
		if(financialStressSummaryLabel.isDisplayed() && financialStressClassLabel.isDisplayed()){
			return true;
		}
		return false;
	}
	
	public boolean CreditScoreSummaryPage(){
		UIHelper.highlightElement(getDriver(), creditScoreSummaryLabel);
		UIHelper.highlightElement(getDriver(), creditScoreClassLabel);
		if(creditScoreSummaryLabel.isDisplayed() && creditScoreClassLabel.isDisplayed()){
			return true;
		}
		return false;
	}
	
	public void tradePaymentsTab(){
		tradePaymentsTab.waitUntilClickable();
		tradePaymentsTab.click();
	}
	
	public boolean dbPaydexSection(){
		UIHelper.highlightElement(getDriver(), dbPaydexSection);
		UIHelper.highlightElement(getDriver(), paydexImage);
		if(dbPaydexSection.isDisplayed() && paydexImage.isDisplayed()){
			return true;
		}
		return false;
	}
	
	public boolean dbPaydexComparisonSection(){
		UIHelper.highlightElement(getDriver(), dbPaydexComparisonSection);
		UIHelper.highlightElement(getDriver(), dbPaydexComparisonSectionImage);
		if(dbPaydexComparisonSection.isDisplayed() && dbPaydexComparisonSectionImage.isDisplayed()){
			return true;
		}
		return false;
	}
	
	public boolean dbPaydexHabitsSection(){
		UIHelper.highlightElement(getDriver(), dbPaymentHabits);
		UIHelper.highlightElement(getDriver(), dbPaymentHabitsTable);
		if(dbPaymentHabits.isDisplayed() && dbPaymentHabitsTable.isDisplayed()){
			return true;
		}
		return false;
	}
	
	public boolean dbPaydexSummarySection(){
		UIHelper.highlightElement(getDriver(), paymentSummarySection);
		UIHelper.highlightElement(getDriver(), paymentSummarySectionTable);
		if(paymentSummarySection.isDisplayed() && paymentSummarySectionTable.isDisplayed()){
			return true;
		}
		return false;
	}
	
	public boolean detailedPaymentHistorySection(){
		UIHelper.highlightElement(getDriver(), detailedPaymentHistory);
		UIHelper.highlightElement(getDriver(), detailedPaymentHistoryTable);
		if(detailedPaymentHistory.isDisplayed() && detailedPaymentHistoryTable.isDisplayed()){
			return true;
		}
		return false;
	}
	
	
	
	public void publicFillingsTab(){
		UIHelper.highlightElement(getDriver(), publicFillings);
		publicFillings.waitUntilClickable();
		publicFillings.click();
	}
	
	public boolean publicFillingsSummarySection(){
		UIHelper.highlightElement(getDriver(), publicFillingsSummaryLabel);
		UIHelper.highlightElement(getDriver(), publicFillingsSummaryTable);
		if(publicFillingsSummaryLabel.isDisplayed() && publicFillingsSummaryTable.isDisplayed()){
			return true;
		}
		return false;
	}
	
	public void historyOperationsTab(){
		historyOperations.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), historyOperations);
		
		historyOperations.click();
	}
	
	public boolean companyOverviewSection(){
		UIHelper.highlightElement(getDriver(), companyOverviewLabel);
		UIHelper.highlightElement(getDriver(), companyNameLabel);
		if(companyOverviewLabel.isDisplayed() && companyNameLabel.isDisplayed()){
			return true;
		}
		return false;
	}
	
	public void FinancialsTab(){
		UIHelper.highlightElement(getDriver(), financialTab);
		financialTab.waitUntilClickable();
		financialTab.click();
	}
	
	public boolean companyFinancialLink(){
		UIHelper.highlightElement(getDriver(), companyFinancialLabel);
		UIHelper.highlightElement(getDriver(), spreadFinancialsButton);
		if(companyFinancialLabel.isDisplayed() && spreadFinancialsButton.isDisplayed()){
			return true;
		}
		return false;
	}
	
	public boolean financialStatementSection(){
		UIHelper.highlightElement(getDriver(), financialStatementLabel);
		UIHelper.highlightElement(getDriver(), addFinancialBtn);
		if(financialStatementLabel.isDisplayed() && addFinancialBtn.isDisplayed()){
			return true;
		}
		return false;	
	}
	
	public boolean additionalFinancialDataSection(){
		selectDBSource.selectByVisibleText("D&B");
		UIHelper.highlightElement(getDriver(), additionalFinancialDataLabel);

		if(additionalFinancialDataLabel.isDisplayed()){
			return true;
		}
		return false;	
	}
	
	public boolean keyBusinessRatioSection(){
		selectDBSource.selectByVisibleText("D&B");
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), keyBusinessRatio);
		//UIHelper.highlightElement(getDriver(), keyBusinessRatioTable);
		//if(keyBusinessRatio.isDisplayed() && keyBusinessRatioTable.isDisplayed()){
			if(keyBusinessRatio.isDisplayed()){
			return true;
		}
		return false;	
	}
	
	public void navigateNotesTabPage(){
		UIHelper.highlightElement(getDriver(), NotesTab);
		NotesTab.waitUntilClickable();
		NotesTab.click();
	}
	
	public boolean addNoteButton(){
		UIHelper.highlightElement(getDriver(), addNoteButton);
		if(addNoteButton.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean exportLinkPage(){
		UIHelper.highlightElement(getDriver(), exportLink);
		if(exportLink.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean addDocumentPage(){
		UIHelper.highlightElement(getDriver(), addDocument);
		if(addDocument.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean deleteSelectedPage(){
		UIHelper.highlightElement(getDriver(), deleteSelected);
		if(deleteSelected.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public void accountInformationTabPage(){
		UIHelper.highlightElement(getDriver(), accountInformationTab);
		accountInformationTab.waitUntilClickable();
		accountInformationTab.click();
	}
	
	public boolean tradeBankReferenceButtonPage(){
		UIHelper.highlightElement(getDriver(), addTradeBankReference);
		if(addTradeBankReference.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean addGuarantorButtonPage(){
		UIHelper.highlightElement(getDriver(), addGuarantor);
		if(addGuarantor.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean editCompanyInfo(){
		UIHelper.highlightElement(getDriver(), editCompanyInformation);
		if(editCompanyInformation.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean editContactInformation(){
		UIHelper.highlightElement(getDriver(), editContactInformation);
		if(editContactInformation.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean editCompanyProfile(){
		UIHelper.highlightElement(getDriver(), editCompanyProfile);
		if(editCompanyProfile.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean editCompanyIdentification(){
		UIHelper.highlightElement(getDriver(), editCompanyIdentification);
		if(editCompanyIdentification.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean editAccountInformation(){
		UIHelper.highlightElement(getDriver(), editAccountInformation);
		if(editAccountInformation.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean editOrderInformation(){
		UIHelper.highlightElement(getDriver(), editOrderInformation);
		if(editOrderInformation.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public void customScoresPage(){
		UIHelper.highlightElement(getDriver(), customScoreTab);
		customScoreTab.waitUntilClickable();
		customScoreTab.click();
	}
	
	public boolean validateScoreName(){
		
		UIHelper.highlightElement(getDriver(), scoreLink);
		if(scoreLink.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public void navigateAuditTrailTabPage(){
		UIHelper.highlightElement(getDriver(), auditTrailTab);
		auditTrailTab.waitUntilClickable();
		auditTrailTab.click();
	}
	
	
	public boolean viewByTextPage(){
		UIHelper.highlightElement(getDriver(), viewByTextBtn);
		if(viewByTextBtn.isDisplayed()){
			viewByTextBtn.click();
			testViewTable.waitUntilVisible();
			return true;
		}
		else 
			return false;
	}
	
	public boolean viewByTimeLinePage(){
		UIHelper.highlightElement(getDriver(), viewByTextTimeLine);
		if(viewByTextTimeLine.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean viewAllEventsPage(){
		UIHelper.highlightElement(getDriver(), viewAllEvents);
		if(viewAllEvents.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean auditTrailEventPage(){
		int a=0;
		List<WebElement> getAuditNames=getDriver().findElements(By.xpath("//*[@id='text']/table/tbody/tr/td/form/table/tbody/tr/td[contains(.,'Re Evaluate')]"));
		for(WebElement auditName:getAuditNames){
			String getAuditName=auditName.getText();
			if(getAuditName.contains("Re Evaluate"))
			{
				a=1;
			}
			
		}
		if(a==1)
		 return true;
		else
			return false;
	}
	
	public void clickClearButtonPage(){
		UIHelper.waitForPageToLoad(getDriver());
		clearButton.click();
		UIHelper.processalert(getDriver());
		UIHelper.waitForPageToLoad(getDriver());
		iFrameEle.waitUntilPresent();
		getDriver().switchTo().frame(iFrameEle);
		clearContinueButton.click();
	}
	
	public boolean validateDBMaximumSection(){
		predictiveScoresTab.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), predictiveScoresTab);
		predictiveScoresTab.click();
		UIHelper.highlightElement(getDriver(), creditCapacitySummary);
		UIHelper.highlightElement(getDriver(), viabilityScoreLabel);
		if(creditCapacitySummary.isDisplayed() && viabilityScoreLabel.isDisplayed()){
			return true;
		}
		return false;
	}
	
	public void navigateTradePayment(){
		UIHelper.highlightElement(getDriver(), tradePaymentsTab);
		tradePaymentsTab.waitUntilClickable();
		tradePaymentsTab.click();
	}
	
	public boolean validateTradePaymentPage(){
		
		UIHelper.highlightElement(getDriver(), tradePaymentImage);
		if(tradePaymentImage.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public boolean validateSummaryLink(){
		
		UIHelper.highlightElement(getDriver(), summaryLink);
		if(summaryLink.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	public void navigateHistoryOperations(){
		HistoryOperations.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), HistoryOperations);
		
		HistoryOperations.click();
	}
	
    public boolean ChkSicNaics(){
        UIHelper.highlightElement(getDriver(), ChkSicNaics);
        if(ChkSicNaics.isDisplayed()){
               return true;
        }
        else 
               return false;
 }
 public void SicNaicsIdentification(){
        UIHelper.highlightElement(getDriver(), SicNaicsIdentification);
        SicNaicsIdentification.waitUntilClickable();
        SicNaicsIdentification.click();
 }
 
 public boolean sicnaics(){
        UIHelper.highlightElement(getDriver(), sicnaics);
        if(sicnaics.isDisplayed()){
               return true;
        }
        else 
               return false;
 }
 
 public boolean verifysic(){
        UIHelper.highlightElement(getDriver(), verifysic);
        if(verifysic.isDisplayed()){
               return true;
        }
        else 
               return false;
 }
 
 public boolean verifynaics(){
        UIHelper.highlightElement(getDriver(), verifynaics);
        if(verifynaics.isDisplayed()){
               return true;
        }
        else 
               return false;
 }
	public void navigateSpecialEvent(){
		UIHelper.highlightElement(getDriver(), specialEventsTab);
		specialEventsTab.waitUntilClickable();
		specialEventsTab.click();
	}
	
	public boolean validateSpecialEvent(){
		
		UIHelper.highlightElement(getDriver(), specialEventHeading);
		if(specialEventHeading.isDisplayed()){
			return true;
		}
		else 
			return false;
	}
	
	public void navigateCompanySummary(){
		UIHelper.highlightElement(getDriver(), companySummaryTab);
		companySummaryTab.waitUntilClickable();
		companySummaryTab.click();
	}
	
	public void customizeButton(){
		UIHelper.highlightElement(getDriver(), customizeButton);
		customizeButton.waitUntilClickable();
		customizeButton.click();
	}
	
	public void chooseCustomizeSection(String selectSection){
		UIHelper.waitForPageToLoad(getDriver());
		WebElement chooseSectionEle=getDriver().findElement(By.xpath("//tbody[@id='com_cust_us']/tr/td/span[contains(.,'"+selectSection+"')]/preceding-sibling::input"));
		if(chooseSectionEle.isSelected()){
			System.out.println("Element already selected:");
		}
		else 
			chooseSectionEle.click();
	}
	
	public void returnCompanySummary(){
		UIHelper.highlightElement(getDriver(), returnCompanySummaryBtn);
		returnCompanySummaryBtn.waitUntilClickable();
		returnCompanySummaryBtn.click();
	}
	
	public void validateWidgetDisplay(String chooseValidateSection){
		int checkWidget=1;
		
		
		
		for(WebElementFacade rightSideWidget:rightWidgetHeading){
			UIHelper.highlightElement(getDriver(), rightSideWidget);
			String rightWidgetString=rightSideWidget.getText();
			if(rightWidgetString.contains(chooseValidateSection)){
				System.out.println("Added sucessfully");
			}
		}
		
		
		for(WebElementFacade leftSideWidget:leftWidgetHeading){
			UIHelper.highlightElement(getDriver(), leftSideWidget);
			String leftWidgetString=leftSideWidget.getText();
			if(leftWidgetString.contains(chooseValidateSection)){
				System.out.println("Added sucessfully");
			}

		}
		
			
		
		if(checkWidget==2||checkWidget==3){
			//return true;
		}
		
	}
	
	public boolean scoreBarImageValidate(){
		UIHelper.highlightElement(getDriver(), scoreBarImage);
		if(scoreBarImage.isDisplayed())
			return true;
		else 
			return false;
	}
	
	public void customizeScoreBar(){
		customizeScoreBar.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), customizeScoreBar);
		customizeScoreBar.click();
	}
	
	public void addScoreBar(String editscoreBar){
		WebElement addItem=getDriver().findElement(By.xpath("//div[@id='itemsContainer']//span[contains(.,'"+editscoreBar+"')]/ancestor::div[@class='dash_container']/div[@class='dash_button']/input[1]"));
		WebElement removeItem=getDriver().findElement(By.xpath("//div[@id='itemsContainer']//span[contains(.,'"+editscoreBar+"')]/ancestor::div[@class='dash_container']/div[@class='dash_button']/input[2]"));
		String attributeValue=addItem.getAttribute("class");
		if(attributeValue.equalsIgnoreCase("btn")){
			addItem.click();
		}
		else
		{
			removeItem.click();
			addItem.click();
		}
	
	}
	
	public void scoreReturnCompanySummary(){
		scoreReturnSummary.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), scoreReturnSummary);
		scoreReturnSummary.click();
		UIHelper.waitForPageToLoad(getDriver());
	}
	
	public void predictiveScoresTab(){
		predictiveScoresTab.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), predictiveScoresTab);
		predictiveScoresTab.click();
	}
	
	public boolean validateCreditLimitRecommend(){
		UIHelper.highlightElement(getDriver(), creditLimitRecommend);
		if(creditLimitRecommend.isDisplayed())
			return true;
		else 
			return false;
	}
	
	public void navigateAccountManager(){
		UIHelper.highlightElement(getDriver(), accountManagerTab);
		accountManagerTab.click();
		UIHelper.waitForPageToLoad(getDriver());
		creditHoldAdvised.click();
	}
	
	public boolean dbRating(){
		UIHelper.highlightElement(getDriver(), dbRatingLink);
		if(dbRatingLink.isDisplayed())
			return true;
		else 
			return false;
	}
	
	public boolean failureScoreTrend(){
		UIHelper.highlightElement(getDriver(), scoreTrend);
		if(scoreTrend.isDisplayed())
			return true;
		else 
			return false;
	}
	
	public void clickAccountManager(){
		UIHelper.waitForPageToLoad(getDriver());
		WebElement clickAccount=getDriver().findElement(By.xpath("//table[@class='results full_company']//tbody//tr/td[contains(.,'DNBI-230612931')]/a"));
		clickAccount.click();
	}
	
	public void navigateAgingTab(){
		UIHelper.highlightElement(getDriver(), AgingTab);
		AgingTab.click();
	}
	
	public boolean agingRecordAvailability(){
		UIHelper.highlightElement(getDriver(), agingRecord);
		if(agingRecord.isDisplayed())
			return true;
		else 
			return false;
	}
	
	public void checkAgingTrendGraph(){
		try{
		UIHelper.highlightElement(getDriver(), agingTrendDropDownValues);
		agingTrendDropDownValues.selectByVisibleText("Aging Trend Graph");
		Thread.sleep(5000);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void checkAgingTrendSummary(){
		try{
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), agingTrendDropDownValues);
		agingTrendDropDownValues.selectByVisibleText("Aging Trend Summary");
		Thread.sleep(5000);
	}catch(Exception e){
		e.printStackTrace();
	}
		
	}
	
	public void checkAgingRecords(){
		try{
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), agingTrendDropDownValues);
		agingTrendDropDownValues.selectByVisibleText("Aging Records");
		Thread.sleep(5000);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public boolean exportLink(){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), agingExportLink);
		if(agingExportLink.isDisplayed())
			return true;
		else 
			return false;
	}
	
	public boolean viewCorporateExposure(){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), viewCorporateExposureReport);
		if(viewCorporateExposureReport.isDisplayed())
			return true;
		else 
			return false;
	}
	
	public boolean customizeReportColumns(){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), viewCustomizeReportButtons);
		if(viewCustomizeReportButtons.isDisplayed())
			return true;
		else 
			return false;
	}
	
	public void exportToFilePage(){
		try{
			viewCorporateExposureReport.waitUntilClickable();
		viewCorporateExposureReport.click();
		waitFor(5000).milliseconds();
		ecfPage.switch_to_Required_Window();
		UIHelper.highlightElement(getDriver(), exportToFileBtn);
		ecfPage.close_the_Required_Window();
		}catch(Exception e){
			e.printStackTrace();
		}

	}
	
	
	public boolean BusReg(){
        UIHelper.highlightElement(getDriver(), BusReg);
        BusReg.waitUntilClickable();
        if(BusReg.isDisplayed()){
               BusReg.click();
               return true;
        }
        else 
               return false;
 }
 public boolean Chkaccname(){      
               String accname1=RegisteredName.getText();
               String accname2=AccName.getText();
               UIHelper.highlightElement(getDriver(), RegisteredName);
               UIHelper.highlightElement(getDriver(), AccName);
               if(accname1.equals(accname2)){
                     return true;
               }
               else
               {
                     return false;
               }
               
        }
 public boolean ChkAssociations(){
        UIHelper.highlightElement(getDriver(), ChkAssociations);
        ChkAssociations.waitUntilClickable();
        if(ChkAssociations.isDisplayed()){
        ChkAssociations.click();
        return true;
        
        }
        else{
               return false;
        }
 }
 public boolean AssociateAllAcc(){
        UIHelper.highlightElement(getDriver(), AllAccount);{
        if(AllAccount.isDisplayed()){
               AllAccount.click();
               return true;
        }
        else
               return false;
        }
        }
 public boolean AssociateAllApp(){
        UIHelper.highlightElement(getDriver(), AllApplications);{
        if(AllApplications.isDisplayed()){
               AllApplications.click();
               return true;
        }
        else
               return false;
        }
        }
	
	
	
	public void validateCustomizeReportPage(){
		try{
		viewCustomizeReportButtons.click();
		if(iFrameEle.isDisplayed()){
			getDriver().switchTo().frame(iFrameEle);
		}
		
		selectedFields.selectByVisibleText("Business Unit");
		selectedFields.selectByVisibleText("Country");
		UIHelper.highlightElement(getDriver(), removeButton);
		removeButton.click();
		selectNewFields.selectByVisibleText("Business Unit");
		selectNewFields.selectByVisibleText("Country");
		UIHelper.highlightElement(getDriver(), addButton);
		addButton.click();
		UIHelper.highlightElement(getDriver(), submitCustomizeButton);
		submitCustomizeButton.click();
		getDriver().switchTo().defaultContent();
		}catch(StaleElementReferenceException e){
			e.printStackTrace();
		}
		
	}
	
	public void dbReportEventsPage(){
		try{
		UIHelper.waitForPageToLoad(getDriver());
		viewLabelDropDown.selectByVisibleText("D&B Report Events");
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void creditBureauEventsPage(){
		try{
		UIHelper.waitForPageToLoad(getDriver());
		viewLabelDropDown.selectByVisibleText("Credit Bureau Events");
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void accountEventsPage(){
		try{
	
		UIHelper.waitForPageToLoad(getDriver());
		viewLabelDropDown.selectByVisibleText("Account Events");
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	public void allEventsPage(){
		try{
	
		UIHelper.waitForPageToLoad(getDriver());
		viewLabelDropDown.selectByVisibleText("All Events");
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void click_Sr_Ceate_Account_Link(){
		try{
			UIHelper.waitForPageToLoad(getDriver());
			waitFor(1000).milliseconds();
			searchResutlsCreateAccountLink.waitUntilClickable();
			UIHelper.highlightElement(getDriver(), searchResutlsCreateAccountLink);
			searchResutlsCreateAccountLink.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), createAccPageHeaderXpath);
		}catch(Exception e){
			throw e;
		}
	}
	
	public void click_Acc_Int_Next_Btn(){
		UIHelper.mouseOveranElement(getDriver(), accNextBtn);
		accNextBtn.click();
		 /*if(createAcc_Int_Next.isVisible()){
			 createAcc_Int_Next.click();
		}*/
		 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), liveReportHeaderXpath);
	}
	
	public String get_Country_Text_In_Ecf_Page(){
		
		UIHelper.highlightElement(getDriver(), ecfPage_CountryName);
		String countryNameText=ecfPage_CountryName.getText().toLowerCase().trim();
		return countryNameText;
	}
}
