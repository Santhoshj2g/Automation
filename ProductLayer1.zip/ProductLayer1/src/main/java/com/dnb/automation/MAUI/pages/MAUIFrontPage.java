package com.dnb.automation.MAUI.pages;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.core.pages.WebElementState;

public class MAUIFrontPage extends PageObject{

	@FindBy(xpath=".//*[@id='rightnavcolumn']/div[2]/table/tbody/tr/td/table/tbody/tr[2]/td/p/span/a/img")
	private WebElementFacade gobtn;
	
	@FindBy(xpath=".//*[@id='bodycolumn']/table/tbody/tr[1]/td/b/font")
	private WebElementFacade loginPageTitle;
	
	public void launchURL(String applicationURL) 
	{
		getDriver().manage().deleteAllCookies();
		getURLToLaunch(applicationURL);
		
	}
	
	private void getURLToLaunch(String applicationURL) 
	{
		getDriver().get(applicationURL);
		getDriver().manage().window().maximize();
		UIHelper.waitForPageToLoad(getDriver());
	}
	
	public void clickgobtn() 
	{
		try{
			UIHelper.highlightElement(getDriver(), gobtn);
			gobtn.click();
			UIHelper.waitForPageToLoad(getDriver());
			
		}catch(Exception e){
			
		}
		
	}

	public boolean verifyPageTitle() throws Exception
	{
		
		UIHelper.switchToChildWindow1(getDriver());
		UIHelper.waitForPageToLoad(getDriver());
		if (loginPageTitle.isPresent())
		{
			UIHelper.highlightElement(getDriver(), loginPageTitle);
			return true;
		}else {
			return false;
		}
		
	}

}
