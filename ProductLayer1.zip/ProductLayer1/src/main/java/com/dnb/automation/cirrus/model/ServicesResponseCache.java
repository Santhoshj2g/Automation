package com.dnb.automation.cirrus.model;

import com.jayway.restassured.path.json.JsonPath;

import java.util.HashMap;

import static com.jayway.restassured.RestAssured.given;

public class ServicesResponseCache {

	private static HashMap<String, String> servicesProductResponse;
	private static HashMap<String, String> servicesDUNSMatchResponse;
	private static HashMap<String, String> servicesEntityResponse;
	private static HashMap<String, String> servicesAlertProfileIDResponse;
	private static HashMap<String, String> servicesRegisteredDUNSResponse;
	private static HashMap<String, String> servicesRulesResponse;
	private static String serviceEndPoint;

	static String env = System.getProperty("env");
	static String repProdEnv = System.getProperty("repProdEnv");
	static String gmsUID = System.getProperty("gmsUID");
	static String gmsCUSID = System.getProperty("gmsCUSID");
	static String gmsCHILDUID = System.getProperty("gmsCHILDUID");

	public static String testAuthentication() throws Exception {
		String authKey = null;
		 if (env.contains("stg")) {
		authKey = given().header("Content-Type", "application/json")
				.header("x-dnb-user", "CirrusOBOTest@dnb.com")
				.header("x-dnb-pwd", "password123").when()
				.get("http://" + env + "/rest/Authentication")
				.header("Authorization");
		 }
		 else if (env.contains("qa")) {
				authKey = given().header("Content-Type", "application/json")
						.header("x-dnb-user", "CirrusOBOTest@dnb.com")
						.header("x-dnb-pwd", "password123").when()
						.get("http://" + env + "/rest/Authentication")
						.header("Authorization");
				 }
		 else {
		 authKey = given().header("Content-Type", "application/json")
		 .header("x-dnb-user", "CirrusOBOTest@dnb.com")
		 .header("x-dnb-pwd", "O&h0%r#$gi^F").when()
		 .get("http://" + env + "/rest/Authentication")
		 .header("Authorization");
		 }
		return authKey;
	}
	
	public static String testAuthenticationForEntityListService() throws Exception {
		System.out.println("Inside test authentication method ");
		String authKey = null;
		authKey = given().header("Content-Type", "application/json")
				.header("x-dnb-user", "cirrustest@dnb.com")
				.header("x-dnb-pwd", "password")
				.header("IsTrial" , "true")
				.header("SubscriberNumber" , "701000000")
				.header("ContractStartDate", "11-20-2015")
				.header("AlternateSystemUserID", "05")
				.header("SubscriberCountryISOAlpha2Code", "CA")
				.when()
				.get("http://" + env + "/rest/Authentication")
				.header("Authorization");
		System.out.println("Authentication key before i return : "+authKey);
		return authKey;
	}

	public static String testAuthenticationForProdCatelog() throws Exception {
		String authKey = given().header("Content-Type", "application/json")
				.header("x-dnb-user", "cirrustest@dnb.com")
				.header("x-dnb-pwd", "password").when()
				.get("http://" + env + "/rest/Authentication")
				.header("Authorization");
		return authKey;
	}

	public static String getProduct(String dunsNo, String prodCode) {
		String jsonResponse = "";
		String authKey;
		try {
			if (servicesProductResponse == null) {
				servicesProductResponse = new HashMap<>();
			}

			if (servicesProductResponse.containsKey(dunsNo)) {
				jsonResponse = servicesProductResponse.get(dunsNo);
				String jsonResponseResult = new JsonPath(jsonResponse)
						.getString("OrderProductResponse.TransactionResult.ResultText");
				if (!jsonResponseResult.equalsIgnoreCase("Success")) {
					authKey = testAuthentication();
					jsonResponse = given()
							.header("Content-Type", "application/json")
							.header("Authorization", authKey)
							.header("ApplicationId", "42")
							.header("IsTrial", "true")
							.header("SubscriberNumber", "490000035")
							.header("ContractStartDate", "12-31-2015")
							.header("AlternateSystemUserID", 05)
							.header("SubscriberCountryISOAlpha2Code", "US")
							.when()
							.get("http://" + env + "/V4.1/organizations/"
									+ dunsNo + "/products/" + prodCode)
							.asString();
					servicesProductResponse.put(dunsNo, jsonResponse);
				}
			} else {
				authKey = testAuthentication();
				jsonResponse = given()
						.header("Content-Type", "application/json")
						.header("Authorization", authKey)
						.header("ApplicationId", "42")
						.header("IsTrial", "true")
						.header("SubscriberNumber", "490000035")
						.header("ContractStartDate", "12-31-2015")
						.header("AlternateSystemUserID", 05)
						.header("SubscriberCountryISOAlpha2Code", "US")
						.when()
						.get("http://" + env + "/V4.1/organizations/" + dunsNo
								+ "/products/" + prodCode).asString();
				String jsonResponseResult = new JsonPath(jsonResponse)
						.getString("OrderProductResponse.TransactionResult.ResultText");
				if (!jsonResponseResult.equalsIgnoreCase("Success")) {
					authKey = testAuthentication();
					jsonResponse = given()
							.header("Content-Type", "application/json")
							.header("Authorization", authKey)
							.header("ApplicationId", "42")
							.header("IsTrial", "true")
							.header("SubscriberNumber", "490000035")
							.header("ContractStartDate", "12-31-2015")
							.header("AlternateSystemUserID", 05)
							.header("SubscriberCountryISOAlpha2Code", "US")
							.when()
							.get("http://" + env + "/V4.1/organizations/"
									+ dunsNo + "/products/" + prodCode)
							.asString();
				}
				servicesProductResponse.put(dunsNo, jsonResponse);
			}
		} catch (Exception e) {
		}
		return jsonResponse;
	}


	public static String getProductWithLangCodeForSplEvents(String dunsNo, String prodCode,String countryCode) {
		String jsonResponse = "";
		String authKey;
		String langCode="";
		if(countryCode.equalsIgnoreCase("CA"))
		{
			langCode="341";
		}
		else if(countryCode.equalsIgnoreCase("US"))
		{
			langCode="39";
		}
		
		try {
			if (servicesProductResponse == null) {
				servicesProductResponse = new HashMap();
			}

			if (servicesProductResponse.get(dunsNo) != null) {
				jsonResponse = (String) servicesProductResponse.get(dunsNo);
				String jsonResponseResult = new JsonPath(jsonResponse)
						.getString("OrderProductResponse.TransactionResult.ResultText");
				if (!jsonResponseResult.equalsIgnoreCase("Success")) {
					authKey = testAuthentication();
					jsonResponse = given()
							.header("Content-Type", "application/json")
							.header("Authorization", authKey)
							.header("ApplicationId", "42")
							.header("IsTrial", "true")
							.header("SubscriberNumber", "490000035")
							.header("ContractStartDate", "12-31-2015")
							.header("AlternateSystemUserID", 05)
							.header("SubscriberCountryISOAlpha2Code", "US")
							.when()
							.get("http://" + env + "/V4.1/organizations/"
									+ dunsNo + "/products/" + prodCode+"?LanguagePreferenceCode="+langCode)
							.asString();
					servicesProductResponse.put(dunsNo, jsonResponse);
				}
			} else {
				authKey = testAuthentication();
				jsonResponse = given()
						.header("Content-Type", "application/json")
						.header("Authorization", authKey)
						.header("ApplicationId", "42")
						.header("IsTrial", "true")
						.header("SubscriberNumber", "490000035")
						.header("ContractStartDate", "12-31-2015")
						.header("AlternateSystemUserID", 05)
						.header("SubscriberCountryISOAlpha2Code", "US")
						.when()
						.get("http://" + env + "/V4.1/organizations/" + dunsNo
								+ "/products/" + prodCode+"?LanguagePreferenceCode="+langCode).asString();
				String jsonResponseResult = new JsonPath(jsonResponse)
						.getString("OrderProductResponse.TransactionResult.ResultText");
				if (!jsonResponseResult.equalsIgnoreCase("Success")) {
					authKey = testAuthentication();
					jsonResponse = given()
							.header("Content-Type", "application/json")
							.header("Authorization", authKey)
							.header("ApplicationId", "42")
							.header("IsTrial", "true")
							.header("SubscriberNumber", "490000035")
							.header("ContractStartDate", "12-31-2015")
							.header("AlternateSystemUserID", 05)
							.header("SubscriberCountryISOAlpha2Code", "US")
							.when()
							.get("http://" + env + "/V4.1/organizations/"
									+ dunsNo + "/products/" + prodCode+"?LanguagePreferenceCode="+langCode)
							.asString();
				}
				servicesProductResponse.put(dunsNo, jsonResponse);
			}
		} catch (Exception e) {
		}
		return jsonResponse;
	}

	public static String performDUNSMatch(String dunsNo) {
		String jsonResponse = "";
		try {
			if (servicesDUNSMatchResponse == null) {
				servicesDUNSMatchResponse = new HashMap();
			}

			if (servicesDUNSMatchResponse.get(dunsNo) != null) {
				jsonResponse = (String) servicesDUNSMatchResponse.get(dunsNo);
			} else {
				String authKey = testAuthentication();
				jsonResponse = given()
						.header("Content-Type", "application/json")
						.header("Authorization", authKey)
						.header("ApplicationId", "42")
						.header("IsTrial", "true")
						.header("SubscriberNumber", "701000000")
						.header("ContractStartDate", "11-20-2015")
						.header("AlternateSystemUserID", "05")
						.header("SubscriberCountryISOAlpha2Code","CA")
						.when()
						.get("http://"
								+ env
								+ "/V4.0/organizations?"
								+ "match=true&findcompany&CandidatePerPageMaximumQuantity=25&CandidateMaximumQuantity=25"
								+ "&CandidateDisplayStartSequenceNumber=1&CountryISOAlpha2Codee=US&DUNSNumber="
								+ dunsNo).asString();

				servicesDUNSMatchResponse.put(dunsNo, jsonResponse);
			}
		} catch (Exception e) {
		}
		return jsonResponse;
	}

	public static String performEntity(String orgName, String country) {
		String jsonResponse = "";
		try {
			if (servicesEntityResponse == null) {
				servicesEntityResponse = new HashMap();
			}

			if (servicesEntityResponse.get(orgName) != null) {
				jsonResponse = (String) servicesEntityResponse.get(orgName);
				System.out.println("Json response *** "+jsonResponse);
			} else {
				System.out.println("Inside perform entity ");
				String authKey = testAuthenticationForEntityListService();
				jsonResponse = given()
						.header("Content-Type", "application/json")
						.header("Authorization", authKey)
						.header("ApplicationId", "42")
						.when()
						.get("http://"
								+ env
								+ "/V4.0/organizations?"
								+ "OrganizationName="
								+ orgName
								+ "&CandidatePerPageMaximumQuantity=10&CandidateMaximumQuantity=100"
								+ "&CandidateDisplayStartSequenceNumber=1&findcompany="
								+ orgName
								+ "&CountryISOAlpha2Code="
								+ country).asString();
				//http: // maxcvservice.dnb.com/V4.0/organizations?OrganizationName=google&CandidatePerPageMaximumQuantity=10&CandidateMaximumQuantity=100&CandidateDisplayStartSequenceNumber=1&findcompany&CountryISOAlpha2Code=US
				System.out.println("Json response in else condition*** "+jsonResponse);
				servicesEntityResponse.put(orgName, jsonResponse);			
				
			}
		} catch (Exception e) {
		}
		return jsonResponse;
	}
	
	public static String performEntityListService(String orgName, String country) {
		
		String jsonResponse = "";
		try {
			if (servicesEntityResponse == null) {
				servicesEntityResponse = new HashMap();
			}

			if (servicesEntityResponse.get(orgName) != null) {
				jsonResponse = (String) servicesEntityResponse.get(orgName);
			} else {
				String authKey = testAuthenticationForEntityListService();
				jsonResponse = given()
						.header("Content-Type", "application/json")
						.header("Authorization", authKey)
						.header("ApplicationId", "42")
						.when()
						.get("http://"
								+ env
								+ "/V4.0/organizations?"
								+ "OrganizationName="
								+ orgName
								+ "&CandidatePerPageMaximumQuantity=25&CandidateMaximumQuantity=25&SearchModeDescription=Advanced"
								+ "&CandidateDisplayStartSequenceNumber=1&findcompany&CountryISOAlpha2Code="
								+ country).asString();
				http: // maxcvservice.dnb.com/V4.0/organizations?OrganizationName=google&CandidatePerPageMaximumQuantity=10&CandidateMaximumQuantity=100&CandidateDisplayStartSequenceNumber=1&findcompany&CountryISOAlpha2Code=US
				servicesEntityResponse.put(orgName, jsonResponse);			}
		} catch (Exception e) {
		}
		return jsonResponse;
	}

	public static String getResultValue(String dunsNo, String prodCode) {
		String jsonResponse = "";
		String jsonResponseResult = "";
		String authKey;
		try {
			if (servicesProductResponse == null) {
				servicesProductResponse = new HashMap();
			}

			if (servicesProductResponse.get(dunsNo) != null) {
				jsonResponse = (String) servicesProductResponse.get(dunsNo);
				jsonResponseResult = new JsonPath(jsonResponse)
						.getString("OrderProductResponse.TransactionResult.ResultText");
				if (!jsonResponseResult.equalsIgnoreCase("Success")) {
					authKey = testAuthenticationForProdCatelog();
					jsonResponse = given()
							.header("Content-Type", "application/json")
							.header("Authorization", authKey)
							.header("ApplicationId", "42")
							.when()
							.get("http://" + env + "/V2/organizations/"
									+ dunsNo + "/products/" + prodCode)
							.asString();
					servicesProductResponse.put(dunsNo, jsonResponse);
				}
			} else {
				authKey = testAuthenticationForProdCatelog();
				jsonResponse = given()
						.header("Content-Type", "application/json")
						.header("Authorization", authKey)
						.header("ApplicationId", "42")
						.when()
						.get("http://" + env + "/V2/organizations/" + dunsNo
								+ "/products/" + prodCode).asString();
				jsonResponseResult = new JsonPath(jsonResponse)
						.getString("OrderProductResponse.TransactionResult.ResultText");
				if (!jsonResponseResult.equalsIgnoreCase("Success")) {
					authKey = testAuthenticationForProdCatelog();
					jsonResponse = given()
							.header("Content-Type", "application/json")
							.header("Authorization", authKey)
							.header("ApplicationId", "42")
							.when()
							.get("http://" + env + "/V2/organizations/"
									+ dunsNo + "/products/" + prodCode)
							.asString();
				}
				servicesProductResponse.put(dunsNo, jsonResponse);
			}
		} catch (Exception e) {
		}
		return jsonResponseResult;
	}

	public static String getJsonPathValueOfProdCatalog(String dunsNo,
			String countryCode) {
		String jsonResponse = "";
		String authKey;
		String jsonResponseResult = "";
		try {
			if (servicesProductResponse == null) {
				servicesProductResponse = new HashMap();
			}

			if (servicesProductResponse.get(dunsNo) != null) {
				jsonResponse = (String) servicesProductResponse.get(dunsNo);
				jsonResponseResult = new JsonPath(jsonResponse)
						.getString("ListAvailableProductResponse.TransactionResult.ResultText");
				if (!jsonResponseResult.equalsIgnoreCase("Success")) {
					authKey = testAuthenticationForProdCatelog();
					jsonResponse = given()
							.header("Content-Type", "application/json")
							.header("Authorization", authKey)
							.header("ApplicationId", "42")
							.when()
							.get("http://" + repProdEnv
									+ "/V2.1/organizations/" + dunsNo
									+ "/products?CountryISOAlpha2Code="
									+ countryCode).asString();
					servicesProductResponse.put(dunsNo, jsonResponse);
				}
			} else {
				authKey = testAuthenticationForProdCatelog();
				jsonResponse = given()
						.header("Content-Type", "application/json")
						.header("Authorization", authKey)
						.header("ApplicationId", "42")
						.when()
						.get("http://" + repProdEnv + "/V2.1/organizations/"
								+ dunsNo + "/products?CountryISOAlpha2Code="
								+ countryCode).asString();
				jsonResponseResult = new JsonPath(jsonResponse)
						.getString("ListAvailableProductResponse.TransactionResult.ResultText");
				if (!jsonResponseResult.equalsIgnoreCase("Success")) {
					authKey = testAuthenticationForProdCatelog();
					jsonResponse = given()
							.header("Content-Type", "application/json")
							.header("Authorization", authKey)
							.header("ApplicationId", "42")
							.when()
							.get("http://" + repProdEnv
									+ "/V2.1/organizations/" + dunsNo
									+ "/products?CountryISOAlpha2Code="
									+ countryCode).asString();
				}
				servicesProductResponse.put(dunsNo, jsonResponse);
			}
		} catch (Exception e) {
		}
		return jsonResponse;
	}

	public static String getResultValueOfProdCatalog(String dunsNo,
			String countryCode) {
		String jsonResponse = "";
		String authKey;
		String jsonResponseResult = "";
		try {
			if (servicesProductResponse == null) {
				servicesProductResponse = new HashMap();
			}
			if (servicesProductResponse.get(dunsNo) != null) {
				jsonResponse = (String) servicesProductResponse.get(dunsNo);
				jsonResponseResult = new JsonPath(jsonResponse)
						.getString("ListAvailableProductResponse.TransactionResult.ResultText");
				if (!jsonResponseResult.equalsIgnoreCase("Success")) {
					authKey = testAuthenticationForProdCatelog();
					jsonResponse = given()
							.header("Content-Type", "application/json")
							.header("Authorization", authKey)
							.header("ApplicationId", "42")
							.when()
							.get("http://" + repProdEnv
									+ "/V2.1/organizations/" + dunsNo
									+ "/products?CountryISOAlpha2Code="
									+ countryCode).asString();
					servicesProductResponse.put(dunsNo, jsonResponse);
				}
			} else {
				authKey = testAuthenticationForProdCatelog();
				jsonResponse = given()
						.header("Content-Type", "application/json")
						.header("Authorization", authKey)
						.header("ApplicationId", "42")
						.when()
						.get("http://" + repProdEnv + "/V2.1/organizations/"
								+ dunsNo + "/products?CountryISOAlpha2Code="
								+ countryCode).asString();
				jsonResponseResult = new JsonPath(jsonResponse)
						.getString("ListAvailableProductResponse.TransactionResult.ResultText");
				if (!jsonResponseResult.equalsIgnoreCase("Success")) {
					authKey = testAuthenticationForProdCatelog();
					jsonResponse = given()
							.header("Content-Type", "application/json")
							.header("Authorization", authKey)
							.header("ApplicationId", "42")
							.when()
							.get("http://" + repProdEnv
									+ "/V2.1/organizations/" + dunsNo
									+ "/products?CountryISOAlpha2Code="
									+ countryCode).asString();
				}
				servicesProductResponse.put(dunsNo, jsonResponse);
			}
		} catch (Exception e) {
		}
		return jsonResponseResult;
	}

	public static String getAlertProfileID() {
		String jsonResponse = "";
		try {
			String authKey = testAuthentication();
			jsonResponse = given()
					.header("Content-Type", "application/json")
					.header("Authorization", authKey)
					.header("ApplicationId", "42")
					.when()
					.proxy("bastion2.us.dnb.com", 8080)
					.get("https://"
							+ env
							+ "/V2.0/gmsmonitoring/monitoringprofiles?ServiceVersionNumber=1.0"
							+ "&ProfileStatusText=Active"
							+ "&ApplicationTransactionID=Test&ApplicationID=42"
							+ "&UserID=" + gmsUID + "&CustomerID=" + gmsCUSID)
					.asString();

			// http://services-ext-stg.dnb.com/V2.0/gmsmonitoring/monitoringprofiles?ServiceVersionNumber=1.0&ApplicationTransactionID=Test&ApplicationID=42&UserID=16757662&CustomerID=490000057

			servicesAlertProfileIDResponse.put(jsonResponse, authKey);

		} catch (Exception e) {
//			e.printStackTrace();
		}
		return jsonResponse;
	}

	public static String getAlertProfileIDForChild() {
		String jsonResponse = "";
		try {
			String authKey = testAuthentication();
			jsonResponse = given()
					.header("Content-Type", "application/json")
					.header("Authorization", authKey)
					.header("ApplicationId", "42")
					.when()
					.proxy("bastion2.us.dnb.com", 8080)
					.get("https://"
							+ env
							+ "/V2.0/gmsmonitoring/monitoringprofiles?ServiceVersionNumber=1.0"
							+ "&ProfileStatusText=Active"
							+ "&ApplicationTransactionID=Test&ApplicationID=42"
							+ "&UserID=" + gmsCHILDUID
							+ "&CustomerID= + gmsCUSID").asString();

			// http://services-ext-stg.dnb.com/V2.0/gmsmonitoring/monitoringprofiles?ServiceVersionNumber=1.0&ApplicationTransactionID=Test&ApplicationID=42&UserID=16757662&CustomerID=490000057

			servicesAlertProfileIDResponse.put(jsonResponse, authKey);

		} catch (Exception e) {
//			e.printStackTrace();
		}
		return jsonResponse;
	}

	public static String getRegisteredDuns() {
		String jsonResponse = "";
		try {
			
			String authKey = testAuthentication();
			jsonResponse = given()
					.header("Content-Type", "application/json")
					.header("Authorization", authKey)
					.header("ApplicationId", "42")
					.when()
					.proxy("bastion2.us.dnb.com", 8080)
					.get("https://"
							+ env
							+ "/V2.0/gmsmonitoring/registrations?ServiceVersionNumber=1.0"
							+ "&ApplicationTransactionID=Test&ApplicationID=42"
							+ "&UserID=" + gmsUID + "&CustomerID=" + gmsCUSID
							+ "&MonitoringProfileID="
							+ CirrusAlertData.getProfileId()).asString();
			// http://services-ext-stg.dnb.com/V2.0/gmsmonitoring/registrations?ServiceVersionNumber=1.0&ApplicationTransactionID=Test&ApplicationID=42&UserID=16757660&CustomerID=701999326&MonitoringProfileID=133641

			// http://services-ext-stg.dnb.com/V2.0/gmsmonitoring/registrations?ServiceVersionNumber=1.0&ApplicationTransactionID=Test&ApplicationID=42&UserID=16757478&CustomerID=490000039

			servicesRegisteredDUNSResponse.put(jsonResponse, authKey);

		} catch (Exception e) {
//			e.printStackTrace();
		}
		return jsonResponse;
	}
	public static String getRegisteredDunsForChild() {
		String jsonResponse = "";
		try {
			
			String authKey = testAuthentication();
			jsonResponse = given()
					.header("Content-Type", "application/json")
					.header("Authorization", authKey)
					.header("ApplicationId", "42")
					.when()
					.proxy("bastion2.us.dnb.com", 8080)
					.get("https://"
							+ env
							+ "/V2.0/gmsmonitoring/registrations?ServiceVersionNumber=1.0"
							+ "&ApplicationTransactionID=Test&ApplicationID=42"
							+ "&UserID=" + gmsCHILDUID + "&CustomerID=" + gmsCUSID
							+ "&MonitoringProfileID="
							+ CirrusAlertData.getProfileIdChild()).asString();
			// http://services-ext-stg.dnb.com/V2.0/gmsmonitoring/registrations?ServiceVersionNumber=1.0&ApplicationTransactionID=Test&ApplicationID=42&UserID=16757660&CustomerID=701999326&MonitoringProfileID=133641

			// http://services-ext-stg.dnb.com/V2.0/gmsmonitoring/registrations?ServiceVersionNumber=1.0&ApplicationTransactionID=Test&ApplicationID=42&UserID=16757478&CustomerID=490000039

			servicesRegisteredDUNSResponse.put(jsonResponse, authKey);

		} catch (Exception e) {
//			e.printStackTrace();
		}
		return jsonResponse;
	}

	public static String getParentUserRulesForAlert() {
		String jsonResponse = "";
		try {
			String authKey = testAuthentication();
			jsonResponse = given()
					.header("Content-Type", "application/json")
					.header("Authorization", authKey)
					.header("ApplicationId", "42")
					.when()
					.proxy("bastion2.us.dnb.com", 8080)
					.get("https://" + env
							+ "/V2.0/gmsmonitoring/monitoringprofiles/"
							+ CirrusAlertData.getProfileId()
							+ "?ServiceVersionNumber=1.0"
							+ "&ApplicationTransactionID=Test&ApplicationID=42"
							+ "&UserID=" + gmsUID + "&CustomerID=" + gmsCUSID)
					.asString();

			// https://services-ext-stg.dnb.com/V2.0/gmsmonitoring/monitoringprofiles/134345?ServiceVersionNumber=1.0&ApplicationTransactionID=Test&ApplicationID=42&UserID=16757622&CustomerID=490000048
			// https://services-ext-stg.dnb.com/V2.0/gmsmonitoring/monitoringprofiles/133943?ServiceVersionNumber=1.0&ApplicationTransactionID=Test&ApplicationID=42&UserID=16757624&CustomerID=490000049

			servicesRulesResponse.put(jsonResponse, authKey);

		} catch (Exception e) {
//			e.printStackTrace();
		}
		return jsonResponse;
	}
	public static String getChildRulesForAlert() {
		String jsonResponse = "";
		try {
			String authKey = testAuthentication();
			jsonResponse = given()
					.header("Content-Type", "application/json")
					.header("Authorization", authKey)
					.header("ApplicationId", "42")
					.when()
					.proxy("bastion2.us.dnb.com", 8080)
					.get("https://" + env
							+ "/V2.0/gmsmonitoring/monitoringprofiles/"
							+ CirrusAlertData.getProfileId()
							+ "?ServiceVersionNumber=1.0"
							+ "&ApplicationTransactionID=Test&ApplicationID=42"
							+ "&UserID=" + gmsCHILDUID + "&CustomerID=" + gmsCUSID)
					.asString();

			// https://services-ext-stg.dnb.com/V2.0/gmsmonitoring/monitoringprofiles/134345?ServiceVersionNumber=1.0&ApplicationTransactionID=Test&ApplicationID=42&UserID=16757622&CustomerID=490000048
			// https://services-ext-stg.dnb.com/V2.0/gmsmonitoring/monitoringprofiles/133943?ServiceVersionNumber=1.0&ApplicationTransactionID=Test&ApplicationID=42&UserID=16757624&CustomerID=490000049

			servicesRulesResponse.put(jsonResponse, authKey);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonResponse;
	}

	public static void main(String arg[]) throws Exception {

//		ServicesResponseCache src = new ServicesResponseCache();
		testAuthentication();
		String responseString = getProduct("989476148","CP_DTL").replaceAll("@", "");
		
		System.out.println(responseString);
//		System.out.println(ServicesResponseCache.getParentUserRulesForAlert());
	}
}