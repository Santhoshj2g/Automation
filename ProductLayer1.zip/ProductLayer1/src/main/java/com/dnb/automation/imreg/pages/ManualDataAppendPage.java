package com.dnb.automation.imreg.pages;

import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class ManualDataAppendPage extends PageObject  {

	@FindBy(xpath = "//select[@name='workflowProfileId']//option")
	private List<WebElement> workflowOptions;

	@FindBy(xpath = "//select[@name='workflowProfileId']//option[contains(text(),'Sample_Data_Append_Template [public]')]")
	private WebElement workflowOption;

	@FindBy(xpath = "//*[contains(text(),'Save As')]")
	private  WebElementFacade saveBtn;
	
	public void manualDataAppend() throws  Exception 
	{
		try
		{
			UIHelper.clickanElement(workflowOption);
			Thread.sleep(5000);
			saveBtn.click();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
