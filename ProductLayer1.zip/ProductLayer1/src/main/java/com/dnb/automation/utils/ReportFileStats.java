package com.dnb.automation.utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.io.IOUtils;
import org.apache.pdfbox.io.RandomAccessFile;
import org.apache.pdfbox.io.ScratchFile;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDStream;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.junit.Assert;

public class ReportFileStats {

	ArrayList<String> reportHeaders = new ArrayList<>();
	long recordCount = 0;

	public ReportFileStats(String fullFilePath) {
		if (fullFilePath.endsWith(".xlsx") || fullFilePath.endsWith(".xls")) {
			processXLS(fullFilePath);
		} else if (fullFilePath.endsWith(".pdf")) {
			processPDF(fullFilePath);
		}
	}


	private void processPDF(String fullFilePath) {
//		try {
//			File file = new File(fullFilePath);
//			PDFParser parser = new PDFParser(new RandomAccessFile(file,"r")); // update for PDFBox V 2.0
//		       
//		       parser.parse();
//		       COSDocument cosDoc = parser.getDocument();
//		       PDFTextStripper pdfStripper = new PDFTextStripper();
//		       PDDocument pdDoc = new PDDocument(cosDoc);
//		       pdDoc.getNumberOfPages();
//		       pdfStripper.setStartPage(1);
//		       pdfStripper.setEndPage(pdDoc.getNumberOfPages());
//		       
//		       System.out.println(pdfStripper.getText(pdDoc));
//			
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

	}

	private void setRecordCount(long recordCount) {
		this.recordCount = recordCount;
	}

	public long getRecordCount() {
		return recordCount;
	}

	public List<String> getReportHeaders() {
		return reportHeaders;
	}

	private void processXLS(String fileName) {
		InputStream fis = null;
		Workbook wb = null;
		try {
			fis = new FileInputStream(new File(fileName));
			wb = WorkbookFactory.create(fis);
			Sheet sheet = wb.getSheetAt(0);
			Row row = sheet.getRow(0);
			reportHeaders = new ArrayList<>();
			for (int x = 0; x < row.getLastCellNum(); x++) {
				reportHeaders.add(row.getCell(x).getStringCellValue());
			}
//			if (fileName.toUpperCase().endsWith(".XLSX")) {
				setRecordCount(sheet.getLastRowNum());
//			} else {
//				setRecordCount(sheet.getLastRowNum() - 1);
//			}

		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			e.printStackTrace();
			Assert.assertTrue("Exception in spreadsheet handling: " + e.toString(), false);
		} finally {
			try {
				if (wb != null) {
					wb.close();
				} else if (fis != null) {
					fis.close();
				}
			} catch (IOException e) {
			}
		}

	}

}
