package com.dnb.automation.bd.pages;

import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class NonAdminProfilePage extends PageObject {
    @FindBy(xpath = "//*[@id='imageClaim']")
    private WebElementFacade btnProfileClaim;

    @FindBy(xpath = "//*[@id='claimed1']/img")
    private WebElementFacade imgProfileClaimed;

    @FindBy(xpath = "//*[@id='claim_box']")
    private WebElementFacade msgClaimBox;

    @FindBy(xpath = "//*[@id='claim_box']/center/a")
    private WebElementFacade btnClaimBoxOk;

    @FindBy(xpath = "//*[@id='imageConnect']")
    private WebElementFacade btnProfileConnect;
        
    @FindBy(xpath = "//*[@id='connect_success_box']")
    private WebElementFacade msgConnectBox;

    @FindBy(xpath = "//*[@id='connect_success_box']/center/a")
    private WebElementFacade btnConnectBoxOk;
    
    @FindBy(xpath = "//*[@id='warning_2']/center/a")
    private WebElementFacade msgConnectWarning;
        
    /***********************************************************************************
     * Function: Click on Profile Claim button. 
     * Input : NA 
     * Action : Profile Claim 
     * Output : NA
     ***********************************************************************************/
    public boolean clickProfileClaimButton()
    {
    	if(btnProfileClaim.isPresent())
    	{
    		btnProfileClaim.click();
    		UIHelper.waitForPageToLoad(getDriver());
    		return true;
    	}else
    	{
    		return false;
    	}
    }

    /***********************************************************************************
     * Function: Verify ProfileClaim button in profile page. 
     * Input : NA 
     * Action : is present 
     * Output : NA
     ***********************************************************************************/
    public boolean getProfileClaimVisibility()
    {
    	UIHelper.waitForPageToLoad(getDriver());
//    	if(btnProfileClaim.isPresent())
//    	{
    		return btnProfileClaim.isPresent();
//    	}else
//    	{
//    		return false;
//    	}
    }
    
    /***********************************************************************************
     * Function: Verify ProfileClaimed button in profile page. 
     * Input : NA 
     * Action : is present 
     * Output : NA
     ***********************************************************************************/
    public boolean getProfileClaimedVisibility()
    {
    	UIHelper.waitForPageToLoad(getDriver());
//    	if(imgProfileClaimed.isPresent())
//    	{
    		return imgProfileClaimed.isPresent();
//    	}else
//    	{
//    		return false;
//    	}
    }

    /***********************************************************************************
     * Function: Verify Claim Thank you message is displayed 
     * Input : NA 
     * Action : is present 
     * Output : NA
     ***********************************************************************************/
    public boolean ClaimThankyouMessage()
    {
    	if(msgClaimBox.isPresent())
    	{
    		btnClaimBoxOk.click();
    		UIHelper.waitForPageToLoad(getDriver());
    		return true;
    	}else
    	{
    		return false;
    	}
    }

    /***********************************************************************************
     * Function: Verify Connect Thank you message is displayed 
     * Input : NA 
     * Action : is present 
     * Output : NA
     ***********************************************************************************/
    public boolean getConnectThankyouMessage()
    {
    	if(msgConnectBox.isPresent())
    	{
    		btnConnectBoxOk.click();
    		UIHelper.waitForPageToLoad(getDriver());
    		return true;
    	}else if(msgConnectWarning.isPresent())
    	{
    		msgConnectWarning.click();
    		return false;
    	}else
    	{
    		return false;
    	}
		
    }
    
    /***********************************************************************************
     * Function: Click on Profile Connect with me button. 
     * Input : NA 
     * Action : Profile Connect
     * Output : NA
     ***********************************************************************************/
    public boolean setProfileConnectWithMeButton()
    {
    	if(btnProfileConnect.isPresent())
    	{
    		btnProfileConnect.click();
    		msgConnectBox.waitUntilPresent();
    		UIHelper.waitForPageToLoad(getDriver());
    		return true;
    	}else
    	{
    		return false;
    	}
    }

    
    
}
