package com.dnb.automation.srm.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * Search.java - This program contains steps for 1. User selects D-U-N-S Number
 * from Drop-down list 2. User enters D-U-N-S Number in Dash-board Search text
 * box 3. User clicks button named as 'Search' for getting details
 *
 * @author Joseph Dennison
 ***********************************************************************************************/

public class Search extends PageObject {

	@FindBy(xpath = "//*[@class='dashboard-container']//*[@id='search_tab']//div//div//*[@id='dboardSearchType-button']/span[2]")
	private WebElementFacade dunsDropDown;

	@FindBy(xpath = "//*[@class='ui-selectmenu-menu ui-selectmenu-open']//ul/li[2]/a[contains(.,'D-U-N-S Number')]")
	private WebElementFacade dunsValue;

	@FindBy(xpath = "//*[@class='dashboard-container']//*[@id='search_tab']//*[@id='main_search']")
	private WebElementFacade searchBox;

	@FindBy(xpath = "//*[@id='tabs']//*[@id='searchbutton']")
	private WebElementFacade search;

	@FindBy(xpath = "//*[@id='example']//*[@id='search-results']/tr[1]/td[2]")
	private WebElementFacade searchResultsEle;
	
	@FindBy(xpath = "//*[@id='dboardSearchType-menu']/li[4]/a[contains('Amount deatils')]")
	private WebElementFacade searchResultsEleAmt;
	
	@FindBy(xpath = "//*[@id='dboardSearchType-button']/span[2][contains('Are You Certified')]")
	private WebElementFacade searchResultsEleCertified;
	
	@FindBy(xpath="//*/div[contains(@class,'screening-alerts')]/table/tbody/tr/td/h4/a")
	private WebElementFacade supplierIDEle;

	private String ajaxImgLoadingXpath = ".//*[@id='wrapper']//*[@class='searchResultloading']/img";

	@FindBy(xpath = ".//*[@id='search-results']/tr[1]")
	private WebElementFacade firstSearchResultRowEle;

	public WebElementFacade getFirstSearchResultRowEle() {
		return firstSearchResultRowEle;
	}

	boolean isdunsDropDown;
	boolean isdunsValue;
	boolean issearchBox;
	boolean issearch;
	boolean isexpand;
	boolean iscompanyname;
	boolean isupdaterecord;
	boolean ispredictivescorelink;

	// Click the Drop-down list in dash-board page

	public void dunsDropDown() throws Exception {
		try {
			dunsDropDown.waitUntilPresent();
			if (dunsDropDown.isPresent()) {
				isdunsDropDown = dunsDropDown.isPresent();
				UIHelper.highlightElement(getDriver(), dunsDropDown);
				dunsDropDown.click();
			}

			if (dunsValue.isPresent()) {
				isdunsValue = dunsValue.isPresent();
				UIHelper.highlightElement(getDriver(), dunsValue);
				dunsValue.click();
			}
		} catch (Exception e) {

		}
	}

	public boolean verifyDunsDropDown() throws Exception {
		if (dunsValue.isPresent()) {
			return true;
		} else {
			return false;
		}
	}

	// Enter the DUNS number in text box named as Search

	public void searchBox(String DUNSNO) throws Exception {
		try {
			searchBox.waitUntilPresent();
			if (searchBox.isPresent()) {
				UIHelper.highlightElement(getDriver(), searchBox);
				searchBox.type(DUNSNO);
			}
		} catch (Exception e) {

		}
	}
	//Enter the Amount details in Search text box
	public void searchBoxAmt(String AmountDeatils) throws Exception {
		try {
			searchBox.waitUntilPresent();
			if (searchBox.isPresent()) {
				UIHelper.highlightElement(getDriver(), searchBox);
				searchBox.type(AmountDeatils);
			}
		} catch (Exception e) {

		}
	}
	
	
    //Enter the Are you certified in text box as search
	
	public void searchBoxCertified(String AreyouCertified) throws Exception {
		try {
			searchBox.waitUntilPresent();
			if (searchBox.isPresent()) {
				UIHelper.highlightElement(getDriver(), searchBox);
				searchBox.type(AreyouCertified);
			}
		} catch (Exception e) {

		}
	}

	public void searchBoxDate(String dateStarted) throws Exception {
		try {
			searchBox.waitUntilPresent();
			if (searchBox.isPresent()) {
				UIHelper.highlightElement(getDriver(), searchBox);
				searchBox.type(dateStarted);
			}
		} catch (Exception e) {

		}
		
	}

	// Click the Search button in Dash-board page for getting details
	public void searchButton() throws Exception {
		try {
			search.waitUntilPresent();
			issearch = search.isPresent();
			UIHelper.highlightElement(getDriver(), search);
			search.click();
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxImgLoadingXpath);
		} catch (Exception e) {

		}
	}

	// Get the DUNS search results data
	public String getSearchResultsData() {
		searchResultsEle.waitUntilPresent();
		return searchResultsEle.getText();
	}
	// Get the Amount details search results data
		public String getSearchResultsDataAmount(String amountDetails) {
//			searchResultsEleAmt.waitUntilPresent();
			dunsDropDown.click();
			dunsDropDown.selectByVisibleText(amountDetails);
			return amountDetails;
			
		}
     //Get The Are you certified result Data
		public String getSearchResultsDataCertified(String areyouCerified) {
			
			dunsDropDown.click();
			dunsDropDown.selectByVisibleText(areyouCerified);
			return areyouCerified;
			
		}
	//Get the Date started result data
		public String getSearchResultsDate(String dateStarted){
			dunsDropDown.click();
			dunsDropDown.selectByVisibleText(dateStarted);
			return dateStarted;
		}
	//Get Public share result Data


		public void searchBoxPublicShare(String publicShare) throws Exception {
			try {
				searchBox.waitUntilPresent();
				if (searchBox.isPresent()) {
					UIHelper.highlightElement(getDriver(), searchBox);
					searchBox.type(publicShare);
				}
			} catch (Exception e) {

			}
		}
		
		public String searchBoxPublic(String publicShare) {
			dunsDropDown.click();
			dunsDropDown.selectByVisibleText(publicShare);
			return publicShare;
		}

		
	//Get Your share result Data
		
		public void searchBoxYourShare(String yourShare)throws Exception {
			try {
				searchBox.waitUntilPresent();
				if (searchBox.isPresent()) {
					UIHelper.highlightElement(getDriver(), searchBox);
					searchBox.type(yourShare);
				}
			} catch (Exception e) {

			} 
		}
		
		public String searchBoxYour(String yourShare) {
			dunsDropDown.click();
			dunsDropDown.selectByVisibleText(yourShare);
			return yourShare;
		}

		
	// Get the Supplier Id from search results
	public String verifySupplierID() {
		searchResultsEle.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), searchResultsEle);
		return searchResultsEle.getText();
	}

	public boolean isIsdunsDropDown() {
		return isdunsDropDown;
	}

	public boolean isIsdunsValue() {
		return isdunsValue;
	}

	public boolean isIssearchBox() {
		return issearchBox;
	}

	public boolean isIssearch() {
		return issearch;
	}

	public boolean isIsexpand() {
		return isexpand;
	}

	public boolean isIscompanyname() {
		return iscompanyname;
	}

	public boolean isIsupdaterecord() {
		return isupdaterecord;
	}

	public boolean isIspredictivescorelink() {
		return ispredictivescorelink;
	}


	
	
	
	
	
	}

