package com.dnb.automation.bd.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

/******************************************************************************************************
 * Description : AdminDashboardPage class contains locators and methods for Admin Dashboard page
 * 
 *******************************************************************************************************/

public class AdminDashboardPage extends PageObject {
	
	@FindBy(xpath = "//*[@id='adminDashboard']")
    private WebElementFacade tabMyDashboard;

	@FindBy(xpath = "//*[@id='flat-tabs']//li[@aria-labelledby='ui-id-2']")
    private WebElementFacade tabProfileClaim;

	@FindBy(xpath = "//div[@id='flat-tabs']//li[@aria-labelledby='ui-id-1']")
    private WebElementFacade tabUserRegistration;
	
	@FindBy(xpath = "//*[@id='ui-id-2']")
    private WebElementFacade tabProfileClaimTab;

	@FindBy(xpath = "//*[@id='ui-id-3']")
    private WebElementFacade tabProfileEditsTab;

	@FindBy(xpath = "//div[@id='flat-tabs']//li[@aria-labelledby='ui-id-3']")
    private WebElementFacade tabProfileEdits;
	
	@FindBy(xpath = ".//*[@id='firstDivId']/div/div[1]")
    private WebElementFacade sarchRegistrationFilter;

	@FindBy(xpath = "//div[@id='flat-tabs-3']//div[@class='FilterCatHeader expandable']")
    private WebElementFacade sarchProfileEditFilter;
		
//	@FindBy(xpath = "//*[@id='flat-tabs']//a[contains(text(),'User Registration')]")
//    private WebElementFacade tabUserRegistration;

//	@FindBy(xpath = "//*[@id='flat-tabs']//a[contains(text(),'Profile Claim')]")
//    private WebElementFacade tabProfileClaim;

	@FindBy(xpath = "//*[@id='adminUserRegEmail']")
    private WebElementFacade txtEmailId;

	@FindBy(xpath = "//div[@id='flat-tabs-3']//input[@id='companyNameProfileEdit']")
    private WebElementFacade txtEditCompanyName;
		
	@FindBy(xpath = "//*[@id='companyName']")
    private WebElementFacade txtCompanyName;

	@FindBy(xpath = "//*[@class='expandable FilterCatHeader']")
    private WebElementFacade SarchFilter;

	@FindBy(xpath = "//*[@class='expandable FilterCatHeaderOpen']")
    private WebElementFacade ProfileClaimSearchFilterBlock;	
	
	@FindBy(xpath = ".//*[@id='firstDivId']//a[@onclick='searchUserRegistration()']")	
	private WebElementFacade btnSearchUserReg;

	@FindBy(xpath = "//div[@id='flat-tabs-3']//a[@onclick='showPflEditSearchResult()']")	
	private WebElementFacade btnSearchProfileEdit;

	@FindBy(xpath = "//*[@id='flat-tabs-2']//a[@onclick='showDashResult()']")	
	private WebElementFacade btnSearchClaimedProfile;	
	
	@FindBy(xpath = "//div[@class='loadmask-msg']")	
	private WebElementFacade imgLoading;
	
	String loadicon="//div[@class='loadmask-msg']";

//	@FindBy(xpath = "//*[@id='profileClaimList']/div[@class='loadmask-msg']")	
//	private WebElementFacade imgLoading;
	
	@FindBy(xpath = "//*[@id='profileClaimList']/tr[1]/td")
    private WebElementFacade Claim1;

	@FindBy(xpath = "//*[@id='profileEditList']/tr[1]/td")
    private WebElementFacade Edit1;

	@FindBy(xpath = "//*[@id='profileClaimList']/tr[1]/td[1]/a")
    private WebElementFacade Claim1CompanyName;

	@FindBy(xpath = "//*[@id='profileClaimList']/tr[1]/td[@class='claimStatus']")
    private WebElementFacade Claim1Status;

	@FindBy(xpath = "//tbody[@id='profileEditList']/tr[1]/td[7]")
    private WebElementFacade Edit1Status;

	@FindBy(xpath = "//tbody[@id='profileEditList']/tr[1]/td[1]/a")
    private WebElementFacade Edit1CompName;

	@FindBy(xpath = "//*[@id='userRegistrationDashboardList']/tr[1]/td[6]")
    private WebElementFacade Registration1Status;
		
	@FindBy(xpath = "//*[@id='profileClaimList']/tr[1]//td/div[@class='enable']/a/img[@title='Approve']")
    private WebElementFacade Claim1Approve;

	@FindBy(xpath = "//*[@id='profileClaimList']/tr[1]//td/div[@class='enable']/a/img[@title='Reject']")
    private WebElementFacade Claim1Reject;

	@FindBy(xpath = "//*[@id='approveButton']/a")
    private WebElementFacade btnApproveOk;

	@FindBy(xpath = "//*[@id='rejectButton']/a")
    private WebElementFacade btnRejectOk;

	@FindBy(xpath = "//*[@id='confirmation_2']/center/a")
    private WebElementFacade btnApproveCancel;

	@FindBy(xpath = "//*[@id='confirmation_2']/center/a")
    private WebElementFacade btnRejectCancel;
	
	@FindBy(xpath = "//*[@id='cliamActionRefesh_1']/center/a")
    private WebElementFacade cliamApproveSuccessMessage;

	@FindBy(xpath = "//*[@id='cliamActionRefesh_1']/center/a")
    private WebElementFacade cliamRejectSuccessMessage;
	
	@FindBy(xpath = "//*[@id='adminClaimStatus']")
    private WebElementFacade ProfileStatus;

	@FindBy(xpath = "//div[@id='About-company']")	
	private WebElementFacade aboutCompany;

	@FindBy(xpath = "//*[@id='Left_Menu']")	
	private WebElementFacade prfl_LeftMenu;

	@FindBy(xpath = "//textarea[@id='about_the_company']")	
	private WebElementFacade aboutTheCompany;

	@FindBy(xpath = "//div[@id='edit_profile_approval']/div[2]/h3")	
	private WebElementFacade editApproveRejectCompName;

	@FindBy(xpath = "//div[@id='About-company']//img[@title='Reject']")	
	private WebElementFacade imgRejectAbtCompany;
	
	@FindBy(xpath = "//div[@id='About-company']//img[@title='Accept']")	
	private WebElementFacade imgAcceptAbtCompany;

	@FindBy(xpath = "//div[@id='phone-addresses']//img[@title='Reject']")	
	private WebElementFacade imgRejectPhoneNum;
	
	@FindBy(xpath = "//div[@id='phone-addresses']//img[@title='Accept']")	
	private WebElementFacade imgAcceptPhoneNum;

	@FindBy(xpath = "//div[@id='key-employee']//img[@title='Reject']")	
	private WebElementFacade imgRejectKeyEmployee;
	
	@FindBy(xpath = "//div[@id='key-employee']//img[@title='Accept']")	
	private WebElementFacade imgAcceptKeyEmployee;

	@FindBy(xpath = "//div[@id='linkage-results-container']//img[@title='Reject']")	
	private WebElementFacade imgRejectBusinessInfo;
	
	@FindBy(xpath = "//div[@id='linkage-results-container']//img[@title='Accept']")	
	private WebElementFacade imgAcceptBusinessInfo;
	
	@FindBy(xpath = "//h3[@id='ui-accordion-contact-address-header-2']")	
	private WebElementFacade phnNumExpand;
	
	@FindBy(xpath = "//select[@id='telephone-type']")	
	private WebElementFacade selPhoneType;

	@FindBy(xpath = "//div[@id='edit_profile_approval']//a[@id='adminApprovalSubmit']")	
	private WebElementFacade btnEditApproval;

		
//	WebElement element = getDriver().findElement(By.xpath(".//*[@id='flat-tabs-2']/div[2]/div/div[1]"));
	
		
    /***********************************************************************************
     * Function: Select Profile Claim tab 
     * Input : NA 
     * Action : NA 
     * Output : NA
     ***********************************************************************************/
	public boolean selectProfileClaimTab()
	{
		if(tabProfileClaim.isPresent())			
		{	
//			System.out.println("Test1" + tabProfileClaim.getAttribute("aria-selected"));
			if(tabProfileClaim.getAttribute("aria-selected").equals("false"))				
			{
//				System.out.println("InSide if");
				tabProfileClaim.waitUntilClickable();
				tabProfileClaimTab.click();
				imgLoading.waitUntilNotVisible();			
				Claim1.waitUntilEnabled();							
			}
		}
		if(tabProfileClaim.getAttribute("aria-selected").equals("true"))
		{
			return true;
		}else
		{
			return false;
		}
	}

    /***********************************************************************************
     * Function: Select User Registration tab 
     * Input : NA 
     * Action : NA 
     * Output : NA
     ***********************************************************************************/
	public void selectUserRegistrationTab()
	{
		if(tabUserRegistration.isPresent())			
		{	
//			System.out.println("Test1" + tabProfileClaim.getAttribute("aria-selected"));
			if(tabUserRegistration.getAttribute("aria-selected").equals("false"))				
			{				
				tabUserRegistration.waitUntilClickable();
				tabUserRegistration.click();
				imgLoading.waitUntilPresent();												
			}
		}
	}
	
    /***********************************************************************************
     * Function: Search the Claimed profile by Company name 
     * Input : Company name
     * Action : Search
     * Output : NA
     * @throws InterruptedException 
     * @throws Exception 
     ***********************************************************************************/
	
	public boolean searchClaimByCompany(String ProfileName) throws InterruptedException
	{		

// Due to issue in the Jbehve , we are using the Sarch filter xpath directly.
		
		WebElement element = getDriver().findElement(By.xpath(".//*[@id='companyName']"));
//		System.out.println(element.isDisplayed());
		
		if(! element.isDisplayed())
		{
			getDriver().findElement(By.xpath(".//*[@id='flat-tabs-2']/div[2]/div/div[1]")).click();		
//			System.out.println(element.isDisplayed());
		}
		
		txtCompanyName.clear();
		txtCompanyName.sendKeys(ProfileName);	
		Select selectThis = new Select(ProfileStatus);
		selectThis.selectByVisibleText("Pending");
		btnSearchClaimedProfile.click();
		imgLoading.waitUntilVisible();
		imgLoading.waitUntilNotVisible();
		Thread.sleep(2000);
		Claim1CompanyName.waitUntilEnabled();
		
		System.out.println(ProfileName);
//		System.out.println(Claim1CompanyName.getText().toString());
		if(ProfileName.toString().equalsIgnoreCase(Claim1CompanyName.getText().toString()))
		{
			return true;			
		}else
		{
			return false;
		}		
		
	}

    /***********************************************************************************
     * Function: Search the User registration by user emailid 
     * Input : emaild
     * Action : Search
     * Output : NA
     ***********************************************************************************/
	public void searchRegUserByEmail(String emailid)
	{
		if(! txtEmailId.isCurrentlyVisible())
		{			
			sarchRegistrationFilter.click();
			txtEmailId.waitUntilVisible();
		}
		txtEmailId.clear();
		txtEmailId.sendKeys(emailid);
		btnSearchUserReg.click();
		imgLoading.waitUntilVisible();
		imgLoading.waitUntilNotVisible();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    /***********************************************************************************
     * Function: Get the status of the Claimed profile 
     * Input : NA
     * Action : NA
     * Output : Status of the Claimed profile
     ***********************************************************************************/
	
	public String getClaimedProfileStatus()
	{
		Claim1Reject.waitUntilClickable();		
		return Claim1Status.getText();
	}
	

    /***********************************************************************************
     * Function: Get the status of the Claimed profile 
     * Input : NA
     * Action : NA
     * Output : Status of the Claimed profile
     ***********************************************************************************/
	
	public String getRegUserStatus()
	{
		Registration1Status.waitUntilVisible();
		if(Registration1Status.isCurrentlyVisible())
		{
			return Registration1Status.getText();	
		}else
		{
			System.out.println("There is no user registered with this email.");
			return null;
		}
		
		
	}
	
	
	/***********************************************************************************
     * Function: Rejecting the claimed profile
     * Input : NA
     * Action : Clicking on reject button
     * Output : NA
     ***********************************************************************************/
	
	public void clickClaimRejectButton()
	{
		Claim1Reject.waitUntilClickable();
		Claim1Reject.click();
		UIHelper.waitForPageToLoad(getDriver());
	}

	/***********************************************************************************
     * Function: Approving the claimed profile
     * Input : NA
     * Action : Clicking on reject button
     * Output : NA
     ***********************************************************************************/
	
	public void clickClaimApproveButton()
	{
		Claim1Approve.waitUntilClickable();
		Claim1Approve.click();
		UIHelper.waitForPageToLoad(getDriver());
	}

	/***********************************************************************************
     * Function: getRejectConfirmation
     * Input : NA
     * Action : To check the reject confirmation message is displayed
     * Output : Status of the Reject Confirmation message
     ***********************************************************************************/
	public boolean getApproveConfirmation()
	{
		return btnApproveOk.isPresent();
	}
	
	/***********************************************************************************
     * Function: getRejectConfirmation
     * Input : NA
     * Action : To check the reject confirmation message is displayed
     * Output : Status of the Reject Confirmation message
     ***********************************************************************************/
	public boolean getRejectConfirmation()
	{
		return btnRejectOk.isPresent();
	}


	/***********************************************************************************
     * Function: AcceptApproveConfirmation
     * Input : NA
     * Action : To click on ok button on the approve confirmation message
     * Output : NA
     ***********************************************************************************/
	public void acceptApproveConfirmation()
	{
		btnApproveOk.waitUntilClickable();
		btnApproveOk.click();
		UIHelper.waitForPageToLoad(getDriver());
	}
	
	/***********************************************************************************
     * Function: AcceptRejectConfirmation
     * Input : NA
     * Action : To click on ok button on the reject confirmation message
     * Output : NA
     ***********************************************************************************/
	public void acceptRejectConfirmation()
	{
		btnRejectOk.waitUntilClickable();
		btnRejectOk.click();
		UIHelper.waitForPageToLoad(getDriver());
	}

	/***********************************************************************************
     * Function: getApproveSucessMessage
     * Input : NA
     * Action : To check the approve success message is displayed
     * Output : NA
     ***********************************************************************************/
	public boolean getApproveSuccessMessage()
	{
		return cliamApproveSuccessMessage.isPresent();
	}
	
	/***********************************************************************************
     * Function: acceptApproveSucessMessage
     * Input : NA
     * Action : Click on ok button of the approve success message
     * Output : NA
     ***********************************************************************************/
	public boolean acceptApproveSuccessMessage()
	{
		if(cliamApproveSuccessMessage.isPresent())
		{
			cliamApproveSuccessMessage.click();
			UIHelper.waitForPageToLoad(getDriver());
			return true;
		}else
		{
			return false;
		}
	}
	
	/***********************************************************************************
     * Function: getRejectSucessMessage
     * Input : NA
     * Action : To check the reject success message is displayed
     * Output : NA
     ***********************************************************************************/
	public boolean getRejectSuccessMessage()
	{
		return cliamRejectSuccessMessage.isPresent();
	}

	/***********************************************************************************
     * Function: acceptRejectSucessMessage
     * Input : NA
     * Action : lick on ok button of the reject success message
     * Output : NA
     ***********************************************************************************/
	public boolean acceptRejectSuccessMessage()
	{
		if(cliamRejectSuccessMessage.isPresent())
		{
			cliamRejectSuccessMessage.click();
			UIHelper.waitForPageToLoad(getDriver());
			return true;
		}else
		{
			return false;
		}
	}

	
    /***********************************************************************************
     * Function: Select Profile edits tab 
     * Input : NA 
     * Action : NA 
     * Output : NA
     ***********************************************************************************/
	public boolean SelectProfileEditsTab()
	{
		if(tabProfileEdits.isPresent())			
		{	
//			System.out.println("Test1" + tabProfileClaim.getAttribute("aria-selected"));
			if(tabProfileEdits.getAttribute("aria-selected").equals("false"))				
			{
//				System.out.println("InSide if");
				tabProfileEdits.waitUntilClickable();
				tabProfileEditsTab.click();
				imgLoading.waitUntilNotVisible();			
				Edit1.waitUntilEnabled();							
			}
		}
		if(tabProfileEdits.getAttribute("aria-selected").equals("true"))
		{
			return true;
		}else
		{
			return false;
		}
	}

    /***********************************************************************************
     * Function: Is profile eidt list visible 
     * Input : NA 
     * Action : NA 
     * Output : NA
     ***********************************************************************************/
	
	public Object isProfileEditListDisplayed() {
		return Edit1.isVisible();
	}

    /***********************************************************************************
     * Function: Search the Profile edit request by profile name 
     * Input : Profile Name
     * Action : Search
     * Output : NA
     ***********************************************************************************/
	public void SearchProfileEditReq(String dbProfileName)
	{		
		if(! txtEditCompanyName.isCurrentlyVisible())
		{			
			sarchProfileEditFilter.click();
			txtEditCompanyName.waitUntilVisible();			
		}
		txtEditCompanyName.clear();
		txtEditCompanyName.sendKeys(dbProfileName);
		btnSearchProfileEdit.click();
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadicon);
	}
	
    /***********************************************************************************
     * Function: Get the status of the Edited profile 
     * Input : NA
     * Action : NA
     * Output : Status of the Edited profile
     ***********************************************************************************/
	
	public String getEditedProfileStatus()
	{		
		return Edit1Status.getText();
	}

    /***********************************************************************************
     * Function: Get the status of the Edited profile 
     * Input : NA
     * Action : NA
     * Output : Status of the Edited profile
     ***********************************************************************************/	
	public boolean selectTheProfileFromEditList() {
		Edit1CompName.click();	
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadicon);
		return aboutCompany.isVisible();
	}

	/***********************************************************************************
	* Function: verify the profile is opened in edit mode for approve or reject
	* Input : NA
	* Action : NA 
	* Output : ProfileName
	***********************************************************************************/
	
	public String isProfileEditModeForApproveReject() {
		if(aboutCompany.isVisible() && prfl_LeftMenu.isVisible() && aboutTheCompany.isVisible())
		{
			return editApproveRejectCompName.getText();	
		}
		else
		{
			return null;
		}
	}

	/***********************************************************************************
	* Function: Reject all the changes in Compnay info tab of Edited profile.
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
	public void rejectCompanyInfoChages() {
		if(imgRejectAbtCompany.isCurrentlyVisible())
		{
			imgRejectAbtCompany.waitUntilClickable();
			imgRejectAbtCompany.click();
		}		
	}

	/***********************************************************************************
	* Function: Approve all the changes in Compnay info tab of Edited profile.
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
	public void approveCompanyInfoChages() {
		if(imgAcceptAbtCompany.isCurrentlyVisible())
		{
			imgAcceptAbtCompany.waitUntilClickable();
			imgAcceptAbtCompany.click();			
		}
	}
	
	/***********************************************************************************
	* Function: Reject phone number changes in Corporate info tab of Edited profile.
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
	public void rejectCorporateInfoChanges() {
		if(phnNumExpand.getAttribute("aria-selected").equalsIgnoreCase("false"))
		{
			phnNumExpand.click();
			selPhoneType.waitUntilEnabled();
		}
		imgRejectPhoneNum.waitUntilClickable();
		imgRejectPhoneNum.click();
	}

	/***********************************************************************************
	* Function: Approve phone number changes in Corporate info tab of Edited profile.
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
	public void approveCorporateInfoChanges() {
		if(phnNumExpand.getAttribute("aria-selected").equalsIgnoreCase("false"))
		{
			phnNumExpand.click();
			selPhoneType.waitUntilEnabled();
		}
		imgAcceptPhoneNum.waitUntilClickable();
		imgAcceptPhoneNum.click();
	}
	
	/***********************************************************************************
	* Function: Reject key employee changes in Key Employees tab of Edited profile.
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void rejectKeyEmployeeChanges() {
		imgRejectKeyEmployee.waitUntilClickable();
		imgRejectKeyEmployee.click();		
	}

	/***********************************************************************************
	* Function: Approve key employee changes in Key Employees tab of Edited profile.
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void approveKeyEmployeeChanges() {
		imgAcceptKeyEmployee.waitUntilClickable();
		imgAcceptKeyEmployee.click();		
	}
	
	/***********************************************************************************
	* Function: Reject Linkage info changes in Business info tab of Edited profile.
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/	
	public void rejectBusinessInfoChanges() {
		imgRejectBusinessInfo.waitUntilClickable();
		imgRejectBusinessInfo.click();
	}


	/***********************************************************************************
	* Function: Approve Linkage info changes in Business info tab of Edited profile.
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/	
	public void approveBusinessInfoChanges() {
		imgAcceptBusinessInfo.waitUntilClickable();
		imgAcceptBusinessInfo.click();
	}
	
	/***********************************************************************************
	* Function: Submit the edit approvals or rejections
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/		
	public void clickSubmit() {
		btnEditApproval.click();	
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadicon);
		UIHelper.waitForPageToLoad(getDriver());
	}

	/***********************************************************************************
	* Function: Verify that user registration tab is selected
	* Input : NA
	* Action : NA 
	* Output : boolean
	***********************************************************************************/		

	public boolean isUserRegistrationTabSelected() {
		return tabUserRegistration.getAttribute("aria-selected").equals("true");
	}
	
	
	
}
