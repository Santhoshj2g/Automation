package com.dnb.automation.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;

/**********************************************************************************************
 * FileUtil.java - This program checks for empty diredtory, read data from file
 * and write data into file
 * 
 * @author Duvvuru Naveen
 * @version 1.0
 ***********************************************************************************************/

public class FileUtil {

    private String[] linesOfDataInTxtFile;
    private ArrayList<String> lines = new ArrayList<String>();
    private String dataInTxtFile;
    private ArrayList listDataInTxtFile = new ArrayList();

    /*
     * Comments by - Srinivasa Vegi Function - Required for Dir Verification
     * Purpose - Checks if a directory is empty
     */
    /**
     * .
     * 
     * @param folderName
     *            folderName
     * @return FIFA folderName
     */

    public static boolean checkforEmptyDirectory(final String folderName) {
        java.io.File file = new java.io.File(folderName);
        if (file.isDirectory()) {
            return file.list().length > 0;
        }
        return false;
    }

    public void deleteFile(String filePath) {
        try {
            File file = new File(filePath);
            FileUtils.cleanDirectory(file);
            //file.createNewFile();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Write text into file
    public void writeTextToFile(String mapDetails, String filePath) {
        try {
            File file = new File(filePath);
            file.delete();
            file.createNewFile();

            FileUtils.writeStringToFile(file, mapDetails);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Write list of text to given file
    public void writeListTextToFile(ArrayList mapDetails, String filePath) {
        try {
            File file = new File(filePath);
            file.delete();
            file.createNewFile();

            FileUtils.writeLines(file, mapDetails);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Read lines data from Text file by given line count and return data
    public ArrayList<String> readDataFromFileByLineCount(int noOfFilesToUpload,
            String filePath) {
        try {
            File file = new File(filePath);
            List<String> fileLinesData = FileUtils.readLines(file);

            int count = 0;

            for (String strLine : fileLinesData) {
                if (count < (noOfFilesToUpload)) {
                    lines.add(strLine);
                    count++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return lines;

    }

    // Read data from given file and return data
    public String readDataFromFile(String filePath) throws Exception {
        try {
            File file = new File(filePath);
            dataInTxtFile = FileUtils.readFileToString(file);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return dataInTxtFile;
    }

    // Read set of data from given file and return data
    public String[] readSetOFDataFromFile(String filePath) throws Exception {
        try {
            File file = new File(filePath);
            
            List<String> lines = FileUtils.readLines(file);

            linesOfDataInTxtFile = new String[lines.size()];

            for (int index = 0; index < lines.size(); index++) {
                linesOfDataInTxtFile[index] = lines.get(index);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return linesOfDataInTxtFile;
    }

    // Read list of data from given file and return data
    public ArrayList readListOFDataFromFile(String filePath) throws Exception {
        try {
            File file = new File(filePath);
            
            
            List<String> lines = FileUtils.readLines(file);

            listDataInTxtFile = new ArrayList(lines.size());

            for (String strLine : lines) {
                listDataInTxtFile.add(strLine);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return listDataInTxtFile;
    }
    
    public String getValueFromPropertyFile(String propertyName, String propertyPath) throws IOException
    {
    	
    	String propValue=null;
    	Properties prop = new Properties();
		InputStream file = null;
    	
    	try{
    		
    		
    		file = new FileInputStream(propertyPath);
    		
    		if(file!=null)
    		{
    			prop.load(file);
    		}
    		
    		propValue = prop.getProperty(propertyName);   	
    		
    		
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    	finally
    	{
    		file.close();
    	}
    	 
    	
		return propValue;
    	
    }

	public long getSizeofFile(String filePath, int list) throws Exception 
	{
		long size= 0;
	
		File directory = new File(filePath);
		File[] filelist = directory.listFiles();
		
		size = filelist[list].length();
		return size;
}

	public String getNameoftheFile(String filePath,int list) throws Exception
	{
		String filename = null;
		File directory = new File(filePath);
		File[] filelist = directory.listFiles();
		
		filename = filelist[list].getName().toString();
		return filename;

		}

	public int listDir(String filepath) throws Exception
	{
		int count =0;
		File directory = new File(filepath);
		File[] filelist = directory.listFiles();
		if(filelist!= null){
			for(int i=0;i<filelist.length;i++){
				count++;
					}
		}
		return count;
	}

	public int linesofFile(String filepath, int i) throws Exception
	{
		int nooflines =0;
		File directory = new File(filepath);
		File[] filelist = directory.listFiles();
		List<String> lines = FileUtils.readLines(filelist[i]);
		nooflines = lines.size();
		
		return nooflines;
	}
	
}
	
