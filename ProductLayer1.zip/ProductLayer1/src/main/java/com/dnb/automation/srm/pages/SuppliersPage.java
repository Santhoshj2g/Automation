package com.dnb.automation.srm.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.DateUtil;
import com.dnb.automation.utils.FileUtil;
import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

/********************************************************************************
 * SuppliersPage.java - The aim of this program is to validate, After clicking the Supplier Tab,
 * Admin,Public and personal folders in the page should load properly without any error 
 * @author Duvvuru Naveen 
 * @version 1.0 
 ********************************************************************************/

public class SuppliersPage extends PageObject {

	@FindBy(xpath=".//*[@id='wrapper_header']//*[@class='header-tabs-container clearFix']//ul//*[@id='supplierMenu']/a")
	private WebElementFacade suppliersTabEle;

	@FindBy(xpath = ".//*[@id='wrapper']//*[@class='container']//*[@class='supplier-container']//*[@class='supplier_page-heading-center']/ul[1]/li[1]/h1")
	private WebElementFacade suppliersTitleEle;

	@FindBy(css = "#supplierMenu a[Href*='suppliers']")
	private WebElementFacade supplierHeader;
	
	@FindBy(css = "#personalFolderData>h4]")
	private WebElementFacade supplierHeaderPrivate;
	
	@FindBy(xpath=".//*[@id='supplierMenu']/a")
	private WebElementFacade supplierTab;
	
	@FindBy(xpath = ".//*[@id='adminFolderData']/h4")
	private WebElementFacade adminFolder;

	@FindBy(xpath = ".//*[@id='createUserIcon']")
	private WebElementFacade searchUserIconEle;

	@FindBy(xpath = ".//*[@id='nwFldrAsgnUsrLgNme']")
	private WebElementFacade loginFieldEle;

	@FindBy(xpath = ".//*[@id='assignedUsersOnCreate']//tr[1]/td[1]/input")
	private WebElementFacade loginCheckboxEle;

	private String startxpathForProfile = "//*[@id='selectCreateProfile-menu']//li/a[contains(.,'SERENITY')]";

	@FindBy(xpath = ".//*[@id='selectCreateProfile-menu']/li[4]/a")
	private WebElementFacade dnbStandardAlertOptionForAssignProfile;

	@FindBy(xpath = ".//*[@id='selectCreateProfile-menu']/li[5]/a")
	private WebElementFacade dnbStandardAlertOptionForSSIInAssignProfile;

	@FindBy(xpath = ".//*[contains(@id,'bookmarkedFolder')]//*[@class='folder_content']/h3")
	private List<WebElement> folderNamesList;

	@FindBy(xpath = ".//*[@id='adminFolderData']/h4")
	private WebElementFacade mainAdminFolderEle;

	@FindBy(xpath = ".//*[@id='publicFolderData']/h4")
	private WebElementFacade mainPublicFolderEle;

	@FindBy(xpath = ".//*[@id='personalFolderData']/h4")
	private WebElementFacade mainPrivateFolderEle;

	@FindBy(xpath = ".//*[@id='toggleListId']")
	private WebElementFacade listViewOptionEleForFolders;

	private String ajaxLoadingImgInFolders = ".//*[@id='wrapper']//*[@class='container']//*[@class='folderviewloading']/img";

	@FindBy(xpath = ".//*[@id='tiletext']")
	private WebElementFacade bookmarksLinkEle;

	@FindBy(xpath = ".//*[@id='50']")
	private WebElementFacade itemsForPageEle;

	@FindBy(xpath = ".//*[@id='searchfolder']")
	private WebElementFacade searchFoldersInputEle;		

	@FindBy(xpath = ".//*[@id='searchFolders']")
	private WebElementFacade searchFoldersBtnEle;

	@FindBy(xpath = ".//*[@id='ListTableBlock']/tr[1]/td[1]/span")
	private WebElementFacade folderTableFirstEle;

	@FindBy(xpath = ".//*[@id='ListTableBlock']/tr[10]/td[1]/span")
	private WebElementFacade folderTableLastEle;

	@FindBy(xpath = ".//*[@id='ListTableBlock']/tr/td[1]/span")
	private List<WebElement> folderTableEle;

	@FindBy(xpath = ".//*[@id='listcntview']")
	private WebElementFacade foldersListCountEle;

	@FindBy(xpath = ".//*[@id='ListHolder']//a[@class='jp-next']")
	private WebElementFacade nextBtnEle;

	@FindBy(xpath = ".//*[@id='ListHolder']//a[contains(@class,'jp-next jp-disabled')]")
	private WebElementFacade disabledNextBtnEle;

	@FindBy(xpath = ".//*[@id='list_jump_val']")
	private WebElementFacade foldersListJumpEle;

	@FindBy(xpath = ".//*[@id='divisionalListTableBlock']/tr/td[1]/span")
	private List<WebElement> divisionFolderNamesEle;

	@FindBy(css = "#adminFolderData")
	private WebElementFacade adminFolderTab;
	
	@FindBy(xpath=".//*[@id='publicFolderData']")
	private WebElementFacade  publicFoldTab;
	
	@FindBy(xpath=".//*[@id='personalFolderData']")
	private WebElementFacade  privateFoldTab;

	@FindBy(xpath = ".//*[@id='list_viewTable']//*[@id='ListTableBlock']//tr[1]/td[1]/span")
	private WebElementFacade adminFolderData;

	@FindBy(css = "#divisionalListAdmin span")
	private WebElementFacade divisionalFolder;

	@FindBy(xpath = "//*[@id='divisionalListTableBlock']//tr[1]//td/img[contains(@class,'editFolder')]")
	private WebElementFacade editDivisionalFolder;

	@FindBy(css = "#editAddedSuppliers")
	private WebElementFacade enterDunsNumbertxtbox;

	@FindBy(css = "#editAddDuns")
	private WebElementFacade addDunsNumber;

	@FindBy(css = "#editRemoveDuns")
	private WebElementFacade removeDunsNumber;

	@FindBy(css = "#deleteEditSuppliersDiv span:nth-of-type(1)")
	private WebElementFacade confirmDeleteButton;
	
	@FindBy(css = ".comapny-row>h4>a")
	private WebElementFacade compnyNameList;
	

	@FindBy(css = "#confMsg span")
	private WebElementFacade adminFolderConfirmMsg;

	@FindBy(xpath = ".//*[@id='publicFolderData']/h4")
	private WebElementFacade publicFolder;

	@FindBy(xpath = ".//*[@id='list_viewTable']//*[@id='ListTableBlock']/tr[1]/td[6]/img[contains(@actiontype, 'remove')]")
	private WebElementFacade addedBookmarkItem;
	
	@FindBy(xpath = ".//*[@id='ListTableBlock']/tr/td[6]/img[contains(@actiontype, 'remove')]")
	private WebElementFacade removeBookmarkItem;
	
	@FindBy(xpath = ".//*[@id='listFolder57041']/img[contains(@class,'editFolderFromList')]")
	private WebElementFacade editOption;
	
	@FindBy(xpath = ".//*[@id='listFolder57041']/img[contains(@class,'deleteFolderOnList')]")
	private WebElementFacade deletOption;
	
	

	@FindBy(xpath = ".//*[@id='folder_placeholder']")
	private WebElementFacade adminFolders;

	public WebElementFacade getAddedBookmarkItem() {
		return addedBookmarkItem;
	}

	@FindBy(css = "#toggleListId")
	private WebElementFacade listTabForFolder;

	@FindBy(css = "#toggleFolderId")
	private WebElementFacade folderTabForAllFolders;	

	@FindBy(css = ".supplier-container .content #personalFolderData")
	private WebElementFacade personalFolder;

	@FindBy(xpath = "//*[@class='content']//*[@class='main_content']//*[@id='list_view']/table//*")
	private WebElementFacade folderContent;

	@FindBy(xpath = "//*[@class='main_content']//*[@id='list_view']/table/tbody/tr[1]/td[1]/span")
	private WebElementFacade adminFolderContentData;

	@FindBy(xpath = "//*[@class='main_content']//*[@class='supplier_list']//*[@id='supplier_viewTable_wrapper']//*[@id='supplier_viewTable']/tbody/tr[1]/td[2]/h4/a")
	private WebElementFacade supplierProfileContentData;

	@FindBy(xpath = "//*[@class='content']//*[@class='main_content']//*[@id='list_view']/table/tbody/tr[1]/td[1]//*[contains(@class,'cmpview')]")
	private WebElementFacade publicFolderContentData;

	@FindBy(xpath = "//*[@class='content']//*[@class='main_content']//*[@id='list_viewPersonal']/table/tbody/tr[1]/td[1]//*[contains(@class,'cmpview')]")
	private WebElementFacade personalFolderContentData;

	@FindBy(xpath = "//*[@id='list_view']//*[@id='list_viewTable']//*[@id='listViewSort']")
	private WebElementFacade contentTable;

	@FindBy(xpath = ".//*[contains(@id,'ListTable')]/tr[1]/td[1]/span")
	private WebElementFacade firstFolderItemFromTable;

	public WebElementFacade getFirstFolderItemFromTable() {
		return firstFolderItemFromTable;
	}

	@FindBy(css = "#pageHeading h1")
	private WebElementFacade supplierProfileHeader;	

	@FindBy(css = "#header-left-box")
	private WebElementFacade supplierProfileLocation;

	@FindBy(css = "#header-center-box")
	private WebElementFacade supplierProfileContact;

	@FindBy(css = "#profile_prescore")
	private WebElementFacade supplierProfilePredictiveScore;

	@FindBy(css = "#profile_cmpoverview")
	private WebElementFacade supplierProfileCompanyOverview;

	@FindBy(css = "#new-folder")
	private WebElementFacade createaNewFolder;

	@FindBy(xpath = ".//*[@id='new-folder']")
	private WebElementFacade newFolderBtn;

	@FindBy(css = "#folder_dialog-modal")
	private WebElementFacade createaNewFolderChildWindow;

	@FindBy(css = "#newFolderName")
	private WebElementFacade txtFolderName;

	@FindBy(css = "#editFolderName")
	private WebElementFacade txteditFolderName;

	@FindBy(css = ".folder_type.public")
	private WebElementFacade folderTypePublic;

	@FindBy(css = ".folder_type.private")
	private WebElementFacade folderTypePrivate;
	
	@FindBy(css = ".cmpview.multiple")
	private WebElementFacade allsupplVal;
	

	@FindBy(css = "#createUserIcon")
	private WebElementFacade assignUserSearchbutton;

	@FindBy(css = "#editUserIcon")
	private WebElementFacade assignUserSearchbuttonforEdit;

	@FindBy(css = "#checkuser")
	private WebElementFacade assignUserCheckAll;	

	@FindBy(css = "#assignedUsersTableCreate_wrapper #assignedUsersTableCreate thead .userSearch td:nth-of-type(2) input")
	private WebElementFacade loginNameForCreateAssignUser;

	@FindBy(css = "#assignedUsersTableCreate_wrapper #assignedUsersTableCreate thead .userSearch td:nth-of-type(3) input")
	private WebElementFacade lastNameForCreateAssignUser;

	@FindBy(css = "#assignedUsersTableCreate_wrapper #assignedUsersTableCreate thead .userSearch td:nth-of-type(4) input")
	private WebElementFacade emailForCreateAssignUser;

	@FindBy(css = ".EditAssignUser #assignedUsersTableEdit thead .userSearch td:nth-of-type(4) input")
	private WebElementFacade assignUserEmail;

	@FindBy(css = "#assignedUsersTableEdit_wrapper #assignedUsersTableEdit .userSearch td:nth-of-type(2) input")
	private WebElementFacade loginNameForEditAssignUser;

	@FindBy(css = "#assignedUsersOnCreate tr:nth-of-type(1) td:nth-of-type(1) input")
	private WebElementFacade assignUserEmailSelect;	

	@FindBy(css = "#assignUsersOnEdit tr:nth-of-type(1) td:nth-of-type(1) input")
	private WebElementFacade assignUserEmailSelectForEdit;
	
	@FindBy(css=".innercontent>div>h5")
	private WebElementFacade assignProfileText;

	@FindBy(css = "#selectEditProfile-button span:nth-of-type(2)")
	private WebElementFacade assignedProfileDropdownForEdit;
	
	@FindBy(xpath=".//*[@id='selectCreateProfile-button']/span[2]")
	private WebElementFacade assignedProfileDropDownForNewFolder;

	@FindBy(css = ".checkuserlist")
	private WebElementFacade assignedUserCheckbox;	

	@FindBy(css = "#checkedituser")
	private WebElementFacade assignedUserCheckboxforEdit;	

	@FindBy(css = "#newSuppliers")
	private WebElementFacade addSupplierTextBox;

	@FindBy(css = "#editAddedSuppliers")
	private WebElementFacade addSupplierTextBoxforEdit;	

	@FindBy(css = "#editAddDuns")
	private WebElementFacade addSupplierCheckBoxforEdit;

	@FindBy(css = "#editRemoveDuns")
	private WebElementFacade removeSupplierCheckBoxforEdit;	

	@FindBy(css = "#selectEditProfile-button span:nth-of-type(2)")
	private WebElementFacade assignedProfileDropdownforPublic;	

	@FindBy(css = "#selectCreateProfile-menu li a")
	private WebElementFacade proflieList;
	
	@FindBy(css = ".innerCol")
	private WebElementFacade compnydatils;
	

	@FindBy(css = "#selectCreateProfile-button")
	private WebElementFacade dropdownProfile;

	@FindBy(css = "#selectCreateProfile-button span:nth-of-type(2)")
	private WebElementFacade dropdownProfiledownarrow;

	@FindBy(xpath = ".//*[@id='selectEditProfile-button']/span[2]")
	private WebElementFacade editDropdownProfiledownArrow;
	
	
	@FindBy(xpath = ".//*[@id='selectEditProfile-menu']/li[9]/a")
	private WebElementFacade selectDPT;
	

	@FindBy(css = "#selectEditProfile-menu")
	private WebElementFacade dropdownProfilecontent;	

	@FindBy(css = "#createBookmarkFolder")
	private WebElementFacade chkboxBookmark;

	@FindBy(css = "#bookmark_edit_folder")
	private WebElementFacade chkboxBookmarkforEdit;	

	@FindBy(css = "#saveNewFolder")
	private WebElementFacade btnSave;

	@FindBy(css = "#editFolderSave")
	private WebElementFacade btnEditSave;	

	@FindBy(css = "#confMsg .messages")
	private WebElementFacade confirmMessageBox;

	@FindBy(css = "#toggleListId")
	private WebElementFacade listTab;

	@FindBy(css = "#navAlert")
	private WebElementFacade alertProfileTab;
	
	@FindBy(xpath = ".//*[@id='alertPflDetails']/div/div/span")
	private WebElementFacade alertProfilFld;
	
	@FindBy(xpath = ".//*[@id='watchListFolder_alert-button']/span")
	private WebElementFacade alertProfilFlder;
	
	
	@FindBy(xpath = ".//*[@id='listFolder56620']/img[4]")
	private WebElementFacade publDelt;
	

	@FindBy(css = ".new_prof_btn")
	private WebElementFacade btnNewProfile;

	@FindBy(css = ".Dirty_Check_profile.new_prof_name")
	private WebElementFacade txtProfileName;

	@FindBy(css = "#selectSSI_0")
	private WebElementFacade dropdownSSI;

	@FindBy(css = "#selectSER_0")
	private WebElementFacade dropdownSER;	

	@FindBy(css = "#selectPYD_0")
	private WebElementFacade dropdownPaydex;

	@FindBy(css = "#selectSCR_0")
	private WebElementFacade dropdownScoredcardRisk;

	@FindBy(css = "#event1_unsel")
	private WebElementFacade eventIndicatorsSuits;

	@FindBy(css = ".fw_bold.save_btn")
	private WebElementFacade btnSaveProfile;

	@FindBy(css = ".AP_edit_view_content")
	private WebElementFacade newProfileContent;

	@FindBy(css = "#rate_supplier")
	private WebElementFacade rateSupplierTab;
	
	@FindBy(css = ".folderTp")
	private WebElementFacade sortByFldType;
	
	@FindBy(css = ".folderNameVal")
	private WebElementFacade sortByFldNameVal;
	
	@FindBy(css = ".folder_head")
	private WebElementFacade sortByFldNoOfSuppl;
	
	@FindBy(css = ".alertProfileNameVal")
	private WebElementFacade sortByFldAlertprflName;
	
	@FindBy(css = ".folder_content>ul>li>div")
	private WebElementFacade sortByFldNoOfusers;
	
	@FindBy(css = "#survey_assign")
	private WebElementFacade assignSurveyTab;

	@FindBy(css = "#liveReport")
	private WebElementFacade liveReportDandB;

	@FindBy(css = ".delete-folder-popup.border-full-radius")
	private WebElementFacade popupwindowForDelete;

	@FindBy(css = "#deleteFolderDiv .delete-folder-yes")
	private WebElementFacade confirmbuttonForDelete;

	@FindBy(css = "#errMsg")
	private WebElementFacade sharedFolderErrmsg;	

	@FindBy(css = "#ListTableBlock .name-row")
	private WebElementFacade folderNameinTable;

	@FindBy(css = ".ListpageItem a:nth-of-type(1)")
	private WebElementFacade itemsperPageTen;

	@FindBy(css = ".ListpageItem a:nth-of-type(2)")
	private WebElementFacade itemsperPageTwenty;

	@FindBy(css = ".ListpageItem a:nth-of-type(3)")
	private WebElementFacade itemsperPageFifty;

	@FindBy(css = ".main_content")
	private WebElementFacade mainContentData;

	@FindBy(css = "#folder_view")
	private WebElementFacade folderContentData;

	@FindBy(css = "#sortValue-button span:nth-of-type(2)")
	private WebElementFacade sortingDropdown;
	
	@FindBy(css = "#ui-selectmenu-item-837")
	private WebElementFacade alertProfileInDropDown;
	
	
	@FindBy(css = "#ui-selectmenu-item-692")
	private WebElementFacade noOfUsersInDropDown;
	
	@FindBy(xpath = ".//*[@id='4059937Expand']")
	private WebElementFacade expansionCompanyName;
	

	@FindBy(xpath = ".//*[@id='sortValue-button']/span[2]")
	private WebElementFacade sortingDropdownEle;
	
	@FindBy(xpath=".//*[@id='FolderListNav']/li[3]/span[1]")
	private WebElementFacade sortByEle;

	@FindBy(css = "#sortValue-menu li:nth-of-type(1) a")
	private WebElementFacade sortingbyFoldername;

	@FindBy(xpath = ".//*[@id='sortValue-menu']/li/a[contains(.,'Folder Name')]")
	private WebElementFacade sortingbyFoldernameEle;

	@FindBy(xpath = ".//*[@id='itemContainer']//li[1]//*[@class='folder_content']/h3")
	public WebElementFacade firstfolderElementInFolderView; 

	public WebElementFacade getFirstfolderElementInFolderView() {
		return firstfolderElementInFolderView;
	}

	@FindBy(css = "#checkrmuser")
	private WebElementFacade removeUserchkbox;

	@FindBy(xpath = "//*[@id='ListHolder']//*[@class='JumpBox floatRight']/span[contains(@id,'listcntview')]")
	private WebElementFacade pageCount;

	@FindBy(xpath = "//*[@id='ListHolder']//*[@class='NumList floatRight']//*[@class='holder']/a[contains(@class,'jp-next')]")
	private WebElementFacade pageCountNextButton;

	@FindBy(xpath = "//*[@id='ListHolder']//*[@class='ListpageItem']/a[contains(@id,'50')]")
	private WebElementFacade itemsPerPage;
	
	@FindBy(xpath = "//*[@id='ListHolder']//*[@class='ListpageItem']/a[contains(@id,'20')]")
	private WebElementFacade itemsPerPage20;
	
	@FindBy(xpath = "//*[@id='ListHolder']//*[@class='ListpageItem']")
	private WebElementFacade itemsPerPageOption;

	@FindBy(xpath = ".//*[@id='ListTableBlock']/tr/td[1]/span")
	private List<WebElement> foldersTableRowsElement;

	@FindBy(xpath = ".//*[@id='supplier_viewTable-check']")
	private WebElementFacade selectAllChkboxEle;

	@FindBy(xpath = ".//*[@id='SupplierBlock']/tr[1]/td[2]//a")
	private WebElementFacade firstSelectedChkboxItem;

	public WebElementFacade getFirstSelectedChkboxItem() {
		return firstSelectedChkboxItem;
	}

	@FindBy(xpath = ".//*[@id='supplierExport']")
	private WebElementFacade exportButtonEle;

	public WebElementFacade getExportButtonEle() {
		return exportButtonEle;
	}

	@FindBy(xpath = ".//*[@id='ListTableBlock']")
	private WebElementFacade allFoldersTableEle;

	@FindBy(xpath = ".//*[@id='supplierExportCsv']")
	private WebElementFacade exportCSVOptionEle;

	@FindBy(xpath = ".//*[@id='divisionalListAdmin']/span")
	private WebElementFacade divisionFolderEle;

	@FindBy(xpath = ".//*[@id='divisionalListTableBlock']")
	private WebElementFacade divisionFolderTableEle;

	@FindBy(xpath = ".//*[@id='divisionalListTableBlock']/tr[1]/td[1]/span")
	private WebElementFacade divisionFolderTableFirstEle;

	@FindBy(xpath = ".//*[@id='divisionalListTableBlock']/tr/td[1]/span")
	public List<WebElement> divisionFolders;

	@FindBy(xpath = ".//*[@id='deleteSuppliers']")
	private WebElementFacade deleteFolderEle;

	@FindBy(xpath = ".//*[@id='wrapper']//*[@class='delete-supplier-popup border-full-radius']")
	private WebElementFacade deleteFolderPopupEle;

	@FindBy(xpath = ".//*[@id='deleteSupplierDiv']//span//input[contains(@value,'Confirm')]")
	private WebElementFacade confirmBtnEle;

	@FindBy(xpath = ".//*[@id='pagHolderAsgnNwFldr']")
	private WebElementFacade pageNavigationEle;

	@FindBy(xpath = ".//*[@id='5']")
	private WebElementFacade pageItemFiveLinkEle;

	@FindBy(xpath = ".//*[@id='selectCreateProfile-button']/span[2]")
	private WebElementFacade assignProfileDropdownListEle;

	// Added New Xpath_Sradha

	@FindBy(xpath=".//*[@id='adminFolderData']/div[2]/span[1]")
	private WebElementFacade numberOfAdminFolderVal;

	/*@FindBy(xpath=".//*[@id='adminFolderData']/div[2]/span/span[contains(@id,'adminFolder')]")
	private WebElementFacade numberOfAdminFolderVal;*/

	@FindBy(xpath=".//*[@id='adminFolder']")
	private WebElementFacade adminFoldersValue;

	@FindBy(xpath=".//*[@id='adminFolderData']/div[2]/span[2]/span[contains(@id,'adminSupplier')]")
	private WebElementFacade adminsupplierValue;

	@FindBy(xpath=".//*[@id='ListTableBlock']/tr/td[contains(@class,'supplier-row')]")
	private WebElementFacade sumOfSupplierVal;
	
	@FindBy(xpath=".//*[@id='ListTablePersonalBlock']/tr/td[contains(@class,'supplier-row')]")
	private WebElementFacade sumofSupplierinPrivate;

	@FindBy(xpath=".//*[@id='supplierListAdmin']")
	private WebElementFacade supplierListButton;

	@FindBy(xpath=".//*[@id='supplier_viewTable_wrapper']")
	private WebElementFacade displaySupplierAllDataVal;

	@FindBy(xpath=".//*[@id='supplier_viewTable-check']")
	private WebElementFacade checkdAllSupplier;

	@FindBy(xpath=".//*[@id='divisionalListTableBlock']/tr/td[contains(@class,'name-row')]")
	private WebElementFacade divisionalFolderList;

	@FindBy(xpath=".//*[@id='divisionalListTableBlock']/tr/td[contains(@class,'type-row')]")
	private WebElementFacade divisionalAdminList;
	
	@FindBy(xpath=".//*[@id='divisionalListTableBlock']/tr/td[1]/span")
	public WebElementFacade divListEle;
	
	@FindBy(xpath=".//*[@id='ListTableBlock']/tr[855]/td[2]")
	private WebElementFacade allsupilerIstEle;
	
	@FindBy(xpath=".//*[@id='ListTableBlock']/tr[1709]/td[2]")
	private WebElementFacade allsupiler2ndEle;

	@FindBy(xpath=".//*[@id='ListTableBlock']/tr[1710]/td[2]")
	private WebElementFacade allsupiler3rdEle;
	
	@FindBy(xpath=".//*[@id='ListTableBlock']/tr[1711]/td[2]")
	private WebElementFacade allsupiler4thEle;
	
	@FindBy(xpath=".//*[@id='ListTableBlock']/tr[1712]/td[2]")
	private WebElementFacade allsupiler5thEle;
	
	@FindBy(xpath="//*[@id='adminSupplier']")
	private WebElementFacade fldrCountAdminTile;
	
	@FindBy(xpath=".//*[@id='ListTableBlock']/tr[1]/td[1]/span")
	private WebElementFacade  adminIstAllSupplier;
	
	@FindBy(xpath=".//*[@id='ListTableBlock']/tr/td[contains(@class,'users-row')]")
	private WebElementFacade allSupplierUserVal;
	
	@FindBy(xpath=".//*[@id='listFolder77']/img[3]")
	private WebElementFacade allSupplierEditEle;
	
	@FindBy(xpath=".//*[@id='suppBlock']")
	private WebElementFacade editManagesupplier;
	
	@FindBy(xpath=".//*[@id='edit_folder_dialog-modal']")
	private WebElementFacade assignProfile;
	
	@FindBy(xpath=".//*[@id='editFolderSave']")
	private WebElementFacade saveOptionEditEle;
	
	@FindBy(xpath=".//*[@id='editFolderCancel']")
	private WebElementFacade canelOptionEdit;
	
	@FindBy(xpath=".//*[@id='listFolder77']/img[4]")
	private WebElementFacade deleteOption;
	
	@FindBy(xpath=".//*[@id='listFolder55050']/img[4]")
	private WebElementFacade publicDeleteOption;
	
	@FindBy(xpath=".//*[@id='listFolder55050']/img[3]")
	private WebElementFacade publicEditIotion;
	
	@FindBy(xpath=".//*[@id='listFolder57039']/img[3]")
	private WebElementFacade clickEditoptionPublic;
	
	@FindBy(xpath=".//*[@id='publicFolderData']/div[2]/span[2]")
	private WebElementFacade publicSupplierCount;
	
	@FindBy(xpath=".//*[@id='new-folder']")
	private WebElementFacade publicNewFolder;
	
	@FindBy(xpath=".//*[@id='ListTableBlock']/tr/td[contains(@class,'users-row')]")
	private WebElementFacade publicUserValue;
	
	
	@FindBy(xpath=".//*[@id='bookmarkedFolder55050']/div[3]/ul[1]/li[1]/div/span")
	private WebElementFacade folderUserValue;
	
	
	@FindBy(xpath=".//*[@id='selectCreateProfile-button']/span[1]")
	private WebElementFacade newFolderAssigneVal;
	
	@FindBy(xpath=".//*[@id='alertPflDetails']/div[3]/div/span[1]")
	private WebElementFacade alertProfileAssineVal;
	
	@FindBy(xpath=".//*[@id='toggleFolderId']")
	private WebElementFacade bookmarkFolder;
	
	@FindBy(xpath=".//*[@id='toggleFolderId']/span[2]")
	private WebElementFacade clickBookMarkFld;

	
	@FindBy(xpath=".//*[@id='ListTableBlock']/tr/td[contains(@class,'type-row')]")
	private WebElementFacade bookMarkType;
	
	@FindBy(xpath=".//*[@id='bookmarkedFolder57041']/div[3]/h3")
	private WebElementFacade selectOneBookMark;
	
	@FindBy(xpath=".//*[@id='toggleListId']")
	private WebElementFacade listViewEle;
	
	@FindBy(xpath=".//*[@id='AllSuppliers']/div[3]/h3")
	private WebElementFacade bookmarkAllSupplier;
	
	@FindBy(xpath=".//*[@id='signOut']")
	private WebElementFacade logOut;
	
	@FindBy(xpath="//*[@id='ownershipEditUser']")
	private WebElementFacade OwnerShipListEle;
	
	@FindBy(xpath=".//*[@id='ownerUser153403']")
	private WebElementFacade CheckboxInOwnerShipEle;
	
	@FindBy(xpath=".//*[@id='editFolderSave']")
	private WebElementFacade editFoldersave;
	
	@FindBy(xpath=".//*[@id='listFolder55050']/img[3]")
	private WebElementFacade clickPublicEditOption;
	
	@FindBy(xpath=".//*[@id='confMsg']/span]")
	private WebElementFacade saveConfMsg;
	
	@FindBy(xpath=".//*[@id='suppBlock']")
	private WebElementFacade manageSupplierEdit;
	
	@FindBy(xpath=".//*[@id='editAddedSuppliers']")
	private WebElementFacade EditAddSupplier;
	
	@FindBy(xpath=".//*[@id='selectEditProfile-button']/span[2]")
	private WebElementFacade editAssignedProfile;
	
	@FindBy(xpath=".//*[@id='selectEditProfile-button']")
	private WebElementFacade selectAssignedProfile;
	
	@FindBy(css = "#new-folder")
	private WebElementFacade newFolderTab;
	
	@FindBy(xpath=".//*[@id='folder_dialog-modal']/div[2]/div[contains(@class,'dialog_header')]")
	private WebElementFacade newFolderHeading;
	
	@FindBy(xpath=".//*[@id='folder_dialog-modal']/div[2]/div[2]/div[1]/h5")
	private WebElementFacade newFolderFolderName;
	
	@FindBy(xpath=".//*[@id='newFolderName']")
	private WebElementFacade folderNametextFiled;
	
	@FindBy(xpath=".//*[@id='folder_dialog-modal']/div[2]/div[2]/ul/li/div/ul/li[1]")
	private WebElementFacade newFolderPublic;
	
	@FindBy(xpath=".//*[@id='folder_dialog-modal']/div[2]/div[2]/ul/li/div/ul/li[2]")
	private WebElementFacade newFolderPrivate;
	
	@FindBy(xpath=".//*[@id='UserAssign']/h5")
	private WebElementFacade assignUser;
	
	@FindBy(xpath=".//*[@id='UserAssign']/div")
	private WebElementFacade tableAssignUser;
	
	@FindBy(xpath=".//*[@id='assignedUsersTableCreate']/thead")
	private WebElementFacade tableHeaderAssignUser;
	
	@FindBy(xpath=".//*[@id='assignedUsersOnCreate']")
	private WebElementFacade tabularData;
	
	@FindBy(xpath=".//*[@id='folder_dialog-modal']/div[2]/div[2]/div[7]/h5")
	private WebElementFacade addSupplierNewFolder;
	
	@FindBy(xpath=".//*[@id='folder_dialog-modal']/div[2]/div[2]/div[12]")
	private WebElementFacade bookMarkwithCheckBox;
	
	@FindBy(xpath=".//*[@id='saveNewCancel']")
	private WebElementFacade cancelNF;
	 
	@FindBy(xpath=".//*[@id='saveNewFolder']")
	private WebElementFacade saveNF;
	
	@FindBy(xpath=".//*[@id='folder_dialog-modal']/div[contains(@class,'close')]")
	private WebElementFacade colsecrossEle;
	
	@FindBy(xpath=".//*[@id='folder_view']")
	private WebElementFacade bookMarkFolderView;
	
	@FindBy(xpath=".//*[@id='wrapper']/div[6]/div[4]/div[6]/div[5]/div[13]/div[1]/ul[1]/li[2]/span/span[1]/img")
	private WebElementFacade deleteDisabledAllSuppliers;
	
	@FindBy(xpath=".//*[@id='1']/td[contains(@class,'cboxColumn')]/input")
	private WebElementFacade uncheckSupplierName;
	
	@FindBy(xpath=".//*[@id='ListTableBlock']/tr[1]/td[1]/span")
	private WebElementFacade clickAllSupplier;
	
	@FindBy(xpath=".//*[@id='deleteSuppliers']/img")
	private WebElementFacade deleteButton;
	
	@FindBy(xpath=".//*[@id='wrapper']/div[contains(@class,'delete-supplier-popup border-full-radius')]")
    private WebElementFacade deleteSupplierPopUpMsg;
	
	@FindBy(xpath=".//*[@id='deleteSupplierDiv']/span[2]/input")
	 private WebElementFacade popUpCancelButton;
	
	
	@FindBy(xpath=".//*[@id='deleteSupplierDiv']/span[1]/input")
	 private WebElementFacade popUpConformButton;
	
	@FindBy(xpath=".//*[@id='listFolder56620']/img[contains(@class,'deleteFolderOnList')]")
	private WebElementFacade deleteButnPublIstEle;
	
	@FindBy(xpath=".//*[@id='wrapper']/div[contains(@class,'container')]/div[contains(@class,'supplier-container')]/div[contains(@class,'supplier_page-heading-center')]/ul[contains(@class,'progressblock right')]")
	private WebElementFacade watchListFold;
	
	@FindBy(css=".domestic>p")
	private WebElementFacade domesticWF;
	
	@FindBy(css="#domestic_progressbar")
	private WebElementFacade domesticWFBar;
	
	@FindBy(css="#maxDomestic")
	private WebElementFacade domesticWFMaxLimit;
	
	@FindBy(xpath=".//*[@id='wrapper']/div[6]/div[4]/div[4]/ul[2]/li[5]/p")
	private WebElementFacade interWF;
	
	
	@FindBy(xpath=".//*[@id='alertInbox']/a")
	private WebElementFacade alertInbox;
	
	
	@FindBy(xpath=".//*[@id='listFolder56620']/img[3]")
	private WebElementFacade public07Edit;
	
	
	
	@FindBy(xpath=".//*[@id='international_progressbar']")
	private WebElementFacade interWFBar;
	
	
	@FindBy(xpath=".//*[@id='maxInter']")
	private WebElementFacade interWFMaxLimit;
	
	
	
	@FindBy(xpath=".//*[@id='wrapper']/div[6]/div[4]/div[6]/div[3]/ul[1]/li[1]/h4")
	private WebElementFacade bookMarkFld;
	
	@FindBy(xpath=".//*[@id='AllSuppliers']")
	private WebElementFacade allsupTileFormt;
	
	@FindBy(xpath=".//*[@id='bookmarkedFolder78']")
	private WebElementFacade certifidTileFormt;
	
	
	@FindBy(xpath=".//*[@id='bookmarkedFolder78']/div[3]/h3")
	private WebElementFacade certifidTileFormtFldNam;
	
	@FindBy(xpath="//*[@id='bookmarkedFolder29156']/div[3]/h3")
	private WebElementFacade unmatchedFldNam;
	
	
	@FindBy(xpath=".//*[@id='AllSuppliers']/div[3]/ul[1]/li[1]")
	private WebElementFacade allsupplierUser;
	
	@FindBy(xpath=".//*[@id='AllSuppliers']/div[3]/ul[1]/li[2]")
	private WebElementFacade allsupplFoldNma;
	
	
	@FindBy(xpath=".//*[@id='AllSuppliers']/div[3]/ul[2]")
	private WebElementFacade alertProfl;
	
	@FindBy(xpath=".//*[@id='AllSuppliers']/div[1]")
	private WebElementFacade editDelete;
	
	
	@FindBy(xpath=".//*[@id='FolderHolder']")
	private WebElementFacade pagination;
	
	@FindBy(xpath=".//*[@id='publicFolder']")
	private WebElementFacade publicFldValue;
	
	@FindBy(xpath=".//*[@id='ListTableBlock']/tr[1]/td[2]")
	private WebElementFacade istSupplierInPublic;
	
	@FindBy(xpath=".//*[@id='ListTableBlock']/tr[10]/td[2]")
	private WebElementFacade lastSupplierInPublic;
	
	@FindBy(xpath=".//*[@id='personalFolder']")
	private WebElementFacade privateFldValue;
	
	@FindBy(xpath=".//*[@id='ListTablePersonalBlock']/tr[1]/td[4]")
	private WebElementFacade foldTypeInPrivate;
	
	
	@FindBy(xpath=".//*[@id='ListTablePersonalBlock']/tr[1]/td[1]")
	private WebElementFacade privateIstFldVal;
	
	@FindBy(xpath=".//*[@id='ListTablePersonalBlock']/tr[1]/td[2]")
	private WebElementFacade privateIstSupplVal;
	
	@FindBy(xpath=".//*[@id='ListTablePersonalBlock']/tr[10]/td[1]")
	private WebElementFacade privateLastFldVal;
	
	@FindBy(xpath=".//*[@id='ListTablePersonalBlock']/tr[10]/td[2]")
	private WebElementFacade privateLastSupplVal;
	
	@FindBy(xpath=".//*[@id='ListTableBlock']/tr/td[contains(@class,'profile-row')]")
	private WebElementFacade alertProfileColumn;
	
	@FindBy(xpath=".//*[contains(@class,'actions-row')]")
	private WebElementFacade actionRows;
	
	@FindBy(xpath=".//*[@id='fup']")
	private WebElementFacade leftArrowAllSup;
	
	@FindBy(css="#fdown")
	private WebElementFacade leftArrowAllSupExpand;
	
	@FindBy(css="#dateWarning64-350-9888")
	private WebElementFacade warningSymbol;
	
	
	
	@FindBy(xpath=".//*[@id='listFolder77']/img[contains(@class,'inactive')]")
	private WebElementFacade allsupdelOptn;
	
	
	@FindBy(xpath=".//*[@id='supplierList']/th[contains(@sortby,'SUPP_NME')]")
	private WebElementFacade compName;
	
	@FindBy(xpath=".//*[@id='supplierList']/th[contains(@sortby,'SER_SCR')]")
	private WebElementFacade SERName;
	
	@FindBy(xpath=".//*[@id='supplierList']/th[contains(@sortby,'PYDX_SCR')]")
	private WebElementFacade paydexName;

	@FindBy(xpath=".//*[@id='supplierList']/th[contains(@sortby,'SUPP_STBL_INDC_SCR')]")
	private WebElementFacade SSIName;
	
	@FindBy(xpath=".//*[@id='supplierList']/th[contains(@sortby,'PCTL_FSS')]")
	private WebElementFacade failureScore;
	
	@FindBy(xpath=".//*[@id='supplierList']/th[contains(@class,'expand-header')]")
	private WebElementFacade expand;
	
	@FindBy(xpath=".//*[@id='listFolder48703']/img[contains(@class,'inactive')]")
	private WebElementFacade privateEditndDele;
	
	@FindBy(xpath=".//*[@id='ListTablePersonalBlock']/tr[1]/td[1]/span")
	private WebElementFacade privateIstFoldName;
	
	
	@FindBy(xpath=".//*[@id='wrapper']/div[6]/div[4]/div[6]/div[5]/div[13]/div[1]/ul[1]/li[2]/span/span[1]/img")
	private WebElementFacade deleteIcon;
	
	@FindBy(xpath=".//*[@id='wrapper']/div[6]/div[4]/div[6]/div[5]/div[13]/div[1]/ul[1]/li[2]/span/span[2]/img")
	private WebElementFacade moveToIcon;
	
	@FindBy(xpath=".//*[@id='moveToFolderSpan']/img")
	private WebElementFacade moveToButton;
	
	
	@FindBy(xpath=".//*[@id='wrapper']/div[6]/div[4]/div[6]/div[5]/div[13]/div[1]/ul[1]/li[1]/span/span[2]/a/img")
	private WebElementFacade printIcon;
	
	@FindBy(xpath=".//*[@id='supplierExport']/img")
	private WebElementFacade exportIcon;
	
	
	@FindBy(xpath=".supplier_viewTable-checkList")
	private WebElementFacade companyListCheckBox;
	
	
	@FindBy(xpath=".//*[@id='4059937Collapse']")
	private WebElementFacade companyListExpansionBlue;
	
	@FindBy(css=".innerCol1")
	private WebElementFacade compnydetai;
	
	@FindBy(css=".cmp-group3")
	private WebElementFacade compnyLastUpdatedate;
	
	@FindBy(css=".//*[@id='supplierList']/th/span/span[contains(@class,'sort-default')]")
	private WebElementFacade compnyListSortUpArrow;
	
	@FindBy(xpath=".//*[@id='supplierList']/th/span/span[contains(@class,'sort-asc')]")
	private WebElementFacade compnyListSortDownArrow;
	
	@FindBy(xpath=".//*[@id='0']/td[contains(@class,'slider_row')]")
	private WebElementFacade SERAsc;
	
	
	@FindBy(xpath=".//*[@id='confMsg']/span[contains(@class,'messages')]")
	private WebElementFacade csvWarningPopUp;
	
	
	@FindBy(xpath=".//*[@id='SERSlider0']/img[contains(@class,'smallpedricLine')]")
	private WebElementFacade indicatorColrImg;
	
	
	@FindBy(xpath=".//*[@id='SERSlider1']/div/div[contains(@class,'valueContainer')]")
	private WebElementFacade indicatorColrRed;
	
	
	@FindBy(xpath=".//*[@id='FSSSlider1']/div/div")
	private WebElementFacade indicatorColrOrange;
	
	@FindBy(xpath=".//*[@id='SERSlider0']/div/div[contains(@class,'valueContainer')]")
	private WebElementFacade indicatorColrGreen;
	
	@FindBy(xpath=".//*[@id='SupplierHolder']")
	private WebElementFacade CompnayprofilePagePagination;
	
	
	@FindBy(xpath=".//*[@id='SERSlider0']/ul/li[contains(@class,'left_value') or contains(@class,'right_value')]")
	private WebElementFacade scale9to1;
	
	@FindBy(xpath=".//*[@id='PaydexSlider0']/img[contains(@class,'smallpedricLine')]")
	private WebElementFacade paydexSlider;
	
	@FindBy(xpath=".//*[@id='PaydexSlider0']/ul/li[contains(@class,'left_value') or contains(@class,'right_value')]")
	private WebElementFacade scale0to100;
	
	@FindBy(xpath=".//*[@id='SSISlider0']/img")
	private WebElementFacade SSIslider;
	
	@FindBy(xpath=".//*[@id='FSSSlider0']/img")
	private WebElementFacade FallureScoreslider;
	
	
	@FindBy(xpath=".//*[@id='alertsMenu']/a")
	private WebElementFacade alertTab;
	
	@FindBy(xpath=".//*[@id='SSISlider0']/ul/li[contains(@class,'left_value') or contains(@class,'right_value')]")
	private WebElementFacade SSIscale10to0;
	
	
	@FindBy(xpath=".//*[@id='FSSSlider0']/ul/li[contains(@class,'left_value') or contains(@class,'right_value')]")
	private WebElementFacade FSSscale1to100;
	
	
	@FindBy(xpath=".//*[@id='0']/td[contains(@class,'cboxColumn')]/input")
	private WebElementFacade compnayPageSupplCheckBox;
	
	@FindBy(xpath=".//*[@id='ListTablePersonalBlock']/tr[2]/td[1]/span")
	private WebElementFacade Ajtestval;
	
	@FindBy(xpath=".//*[@id='moveToFolders']/li[195]/span")
	private WebElementFacade moveToPrivate;
	
	@FindBy(xpath=".//*[@id='ListTablePersonalBlock']/tr/td/span")
	private WebElementFacade privateFld;
	

	
	

	
	
	private ArrayList<String> folderNames = new ArrayList<String>();
	private ArrayList<String> divisionFolderNames = new ArrayList<String>();
	private String FolPrivateNameLinkXpath="//*[contains(@id,'ListTablePersonalBlock')]/tr//td//*[contains(.,'SERENITY')]//ancestor::td[1]//following-sibling::td[5]//img[3]";
	private String folderNameLinkXpath = "//*[contains(@id,'ListTable')]//tr//td//*[contains(.,'SERENITY')]//ancestor::td[1]//following-sibling::td[5]//img[3]";
	private String savebtnLoadingImg="//*[@id='newSaveLoading']/img[@src='static/images/ajaxLoader_small.gif']";
	private String loadingImage = "//*[@class='supplier-container']//*[@class='content']//*[@class='main_content']//*[@class='folderviewloading']/img";	
	private String loadingImageforEditSaveButton="//*[@id='editSaveLoading']//img[@src='static/images/ajaxLoader_small.gif']";	
	private String listLoadingImg = ".//*[@id='wrapper']//*[@class='listloading']/img";
	private String sortingarrowButton ="//*[@id='list_viewTable']//*[@id='listViewSort']/tr[1]/th[1]/span";
	private String loadingImageImageForbookmark="//*[@id='list_viewTable']//*[@id='ListTableBlock']/tr[1]/td[6]/img[2]";
	private String xpathForFirstBookmark="//*[@id='list_viewTable']//*[@id='ListTableBlock']/tr/td/span[contains(.,'SERENITY')]//ancestor::td[1]//following-sibling::td[5]/img[contains(@actiontype, 'update')]";
	private String xpathForBookmarkedFolder="//*[@id='list_viewTable']//*[@id='ListTableBlock']/tr/td/span[contains(.,'SERENITY')]//ancestor::td[1]//following-sibling::td[5]/img[contains(@actiontype, 'remove')]";
	private String xpathForFirstFolderEleInTable = ".//*[@id='ListTableBlock']/tr[1]/td[1]/span";
	private String loadingImgInDeletePopup = ".//*[@id='deleteSupplierLoad']/div/img";
	private String firstFolderNameInAdminFolders = "//*[@id='list_viewTable']//*[@id='ListTableBlock']/tr[1]/td/span[contains(.,'SERENITY')]";
	private String folderNameTextVal;
	private String currentDateAndTimeDetailsStoreLocation = "src/test/resources/AppTestData/SRM/currentTimeAndDate.txt";
	private String expectedValue="";

	public void clickSupplierHeader()
	{
		UIHelper.highlightElement(getDriver(),supplierHeader);
		UIHelper.mouseOverandclickanElement(getDriver(), supplierHeader);
		UIHelper.waitForPageToLoad(getDriver());
	}
	
	public void clickPrivateSupplHeader()
	{
		UIHelper.highlightElement(getDriver(),supplierHeaderPrivate);
		UIHelper.mouseOverandclickanElement(getDriver(), supplierHeaderPrivate);
		UIHelper.waitForPageToLoad(getDriver());
	}

	/***********************************************************************************************
	 *  Function:  Check whether the new folder have been created based on the given input
	 *  Input   :  Read Inputs from Story file.
	 *  Action  :  Passing all the inputs to the required fields and finally create a new folder with
	 *   a given input name
	 *  Output  :  New folder have been created and the folder name should update in the Folder table	   	                 
	 ***********************************************************************************************/
	public void createNewSupplierFolder(String folderName,String folderType,String assignUser,
			String addSupplier,String assignProfile,String addBookmark)	{
		try{
			if(!folderType.contains("admin"))
			{
				newFolderBtn.waitUntilPresent();
				if(newFolderBtn.isPresent())
				{
					String dateVal = new DateUtil().getCurrentDateAndTime();
					String finalDateVal = dateVal.replace(" ", "").replace("/", "").replace(":", "").trim();
					new FileUtil().writeTextToFile(finalDateVal, currentDateAndTimeDetailsStoreLocation);
					String finalFolderName = folderName + finalDateVal;
					newFolderBtn.click();
					txtFolderName.waitUntilPresent();	
					txtFolderName.type(finalFolderName);
					if(folderType.equalsIgnoreCase("public"))
					{				
						folderTypePublic.click();
					}
					else
					{
						folderTypePrivate.click();
					}
					pageNavigationEle.waitUntilPresent();
					if(assignUser!=null && !assignUser.isEmpty() &&!assignUser.equalsIgnoreCase("no"))
					{
						searchUserIconEle.click();
						loginFieldEle.waitUntilPresent();
						loginFieldEle.type(assignUser);
						waitFor(3000).milliseconds();
						loginCheckboxEle.waitUntilPresent();
						loginCheckboxEle.click();
					}
					if(addSupplier != null && !addSupplier.isEmpty() && !addSupplier.equalsIgnoreCase("no"))
					{
						if(addSupplier.contains(";"))		
						{
							ArrayList<String> selectedSuppliers = new ArrayList<String>(Arrays.asList(addSupplier.split(";")));
							for(int i=0; i<selectedSuppliers.size();i++)
							{
								addSupplierTextBox.sendKeys(selectedSuppliers.get(i).toString().trim());
								addSupplierTextBox.sendKeys(Keys.ENTER);
							}
						}
						else
						{
							addSupplierTextBox.type(addSupplier);
						}
					}

					if(assignProfile != null && !assignProfile.isEmpty() && !assignProfile.equalsIgnoreCase("no"))
					{
						waitFor(2000).milliseconds();
						assignProfileDropdownListEle.click();
						waitFor(2000).milliseconds();
						if(assignProfile.equalsIgnoreCase("D&B Standard Alert Profile"))
						{
							dnbStandardAlertOptionForAssignProfile.waitUntilPresent();
							dnbStandardAlertOptionForAssignProfile.click();
						}
						else if(assignProfile.equalsIgnoreCase("D&B Standard Alert Profile for SSI v2"))
						{
							dnbStandardAlertOptionForSSIInAssignProfile.waitUntilPresent();
							dnbStandardAlertOptionForSSIInAssignProfile.click();
						}
						else
						{
							String assignProfileValue= startxpathForProfile.replace("SERENITY", assignProfile);
							UIHelper.waitForVisibilityOfEleByXpath(getDriver(), assignProfileValue);
							WebElementFacade assignProfileValueEle = find(By.xpath(assignProfileValue));
							assignProfileValueEle.click();
						}
					}								

					if(addBookmark.equalsIgnoreCase("yes"))
					{
						chkboxBookmark.click();	
					}

					btnSave.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),savebtnLoadingImg);
					UIHelper.waitForPageToLoad(getDriver());
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImage);
					UIHelper.waitForPageToLoad(getDriver());
					UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[@id='publicFolderData']");
					UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[@id='adminFolderData']");
					UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[@id='personalFolderData']");	

					listViewOptionEleForFolders.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),ajaxLoadingImgInFolders);
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),listLoadingImg);
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImage);
				}

			}
		}
		catch (Exception e){
			e.printStackTrace();
		}

	}

	//Get Folder Names from Folder table
	public ArrayList<String> getFolderNames(String folderType)
	{
		try{
			navigateToFoldersPage(folderType);

			int foldersPagecount = Integer.parseInt(foldersListCountEle.getText());
			int foldersPagejump;
			if(foldersPagecount>1)
			{
				do{
					for(WebElement folderNameEle:folderTableEle)
					{
						folderNames.add(folderNameEle.getText());
					}

					if(!disabledNextBtnEle.isPresent())
					{
						nextBtnEle.click();
						UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),ajaxLoadingImgInFolders);
						UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),listLoadingImg);
						UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImage);
						searchFoldersInputEle.waitUntilPresent();
						itemsForPageEle.waitUntilPresent();
					}

					foldersPagejump = Integer.parseInt(foldersListJumpEle.getText());

					if(foldersPagejump==foldersPagecount)
					{
						for(WebElement folderNameEle:folderTableEle)
						{
							folderNames.add(folderNameEle.getText());
						}
					}

				}while(foldersPagejump!=foldersPagecount);
			}
			else
			{
				for(WebElement folderNameEle:folderTableEle)
				{
					folderNames.add(folderNameEle.getText());
				}
			}
		}
		catch(Exception e)
		{
		}
		return folderNames;
	}

	/***********************************************************************************************
	 *  Function:  Click on Sorting  arrow Button
	 *  Input   :  NA
	 *  Action  :  Click sorting button, data should be displayed based on sorting 
	 *  Output  :  Resultant data will displayed based on sorting order

	 ***********************************************************************************************/
	public void verifySorting(String folderType)
	{
		try
		{
			navigateToFoldersPage(folderType);
			WebElementFacade arrowButton = find(By.xpath(sortingarrowButton));
			arrowButton.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImage);
			UIHelper.waitForPageToLoad(getDriver());
			arrowButton.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImage);
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), xpathForFirstFolderEleInTable);
		}
		catch(Exception e)
		{
		}

	}

	//Click on Bookmark option in folder table
	public void verifyBookmark(String folderType, String folderName)
	{
		try
		{
			navigateToFoldersPage(folderType);
			String tempXpathForFirstBookmark = xpathForFirstBookmark.replace("SERENITY", folderName);

			WebElementFacade bookmarkbutton= find(By.xpath(tempXpathForFirstBookmark));
			if(bookmarkbutton.isDisplayed())
			{
				bookmarkbutton.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImageImageForbookmark);
				UIHelper.waitForPageToLoad(getDriver());
			}

		}
		catch(Exception e)
		{
		}
	}

	public boolean isFolderBookmarked(String folderName)
	{
		
		String tempXpathForBookmarkedFolder = xpathForBookmarkedFolder.replace("SERENITY", folderName);
		WebElementFacade bookmarkbutton= find(By.xpath(tempXpathForBookmarkedFolder));
		
		return bookmarkbutton.isPresent();
	}
		

	public void verifySortingOptionInFoldersView(String folderType)
	{
		try
		{
			navigateToFoldersPage(folderType);
			folderTabForAllFolders.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadingImage);
			sortingDropdownEle.waitUntilPresent();
			sortingDropdownEle.click();
			sortingbyFoldernameEle.waitUntilPresent();
			sortingbyFoldernameEle.click();
			firstfolderElementInFolderView.waitUntilPresent();
		}
		catch(Exception e)
		{
		}

	}

	/***********************************************************************************************
	 *  Function:  Verify the Edit link for Supplier's Folder
	 *  Input   :  Get Input from Story file
	 *  Action  :  Click edit folder link for the given folder name and passing all the input values
	 *  to the required fields.
	 *  Output  :  Folder should be saved with updated information	                 
	 ***********************************************************************************************/
	public void editSuppliersFolder(String folderType, String folderName, String newfolderName, String newAssignUser, String suppliersToAdd,
			String suppliersToRemove, String bookmarkTochange)	{
		try{
			clickSupplierHeader();

			navigateToFoldersPage(folderType);
			UIHelper.waitForPageToLoad(getDriver());

			String finalFolderName = folderName + new FileUtil().readDataFromFile(currentDateAndTimeDetailsStoreLocation);
			folderNameLinkXpath = folderNameLinkXpath.replace("SERENITY", finalFolderName);
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImage);
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), folderNameLinkXpath);
			WebElementFacade folderNameLinkEle = find(By.xpath(folderNameLinkXpath));
			folderNameLinkEle.click();
			String finalNewFolderName = newfolderName + new FileUtil().readDataFromFile(currentDateAndTimeDetailsStoreLocation);
			if(newfolderName!=null &&!newfolderName.isEmpty() && !newfolderName.equalsIgnoreCase("no"))
			{
				txteditFolderName.waitUntilPresent();
				txteditFolderName.type(finalNewFolderName);
			}
			if(newAssignUser!=null && !newAssignUser.isEmpty() && !newAssignUser.equalsIgnoreCase("no"))
			{
				assignUserSearchbuttonforEdit.click();
				loginNameForEditAssignUser.type(newAssignUser);
				assignUserEmailSelectForEdit.click();
			}
			if(suppliersToAdd != null && !suppliersToAdd.isEmpty() &&!suppliersToAdd.equalsIgnoreCase("no"))
			{
				addSupplierTextBoxforEdit.type(suppliersToAdd);
				removeSupplierCheckBoxforEdit.click();
				addSupplierCheckBoxforEdit.click();
			}
			if(suppliersToRemove != null && !suppliersToRemove.isEmpty() &&!suppliersToRemove.equalsIgnoreCase("no"))
			{
				addSupplierTextBoxforEdit.type(suppliersToRemove);
				removeSupplierCheckBoxforEdit.click();
			}
			if(bookmarkTochange.equalsIgnoreCase("yes")&& !bookmarkTochange.isEmpty() &&!bookmarkTochange.equalsIgnoreCase("no"))
			{
				chkboxBookmarkforEdit.click();
			}
			btnEditSave.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImageforEditSaveButton);
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[@id='publicFolderData']");
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[@id='adminFolderData']");
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[@id='personalFolderData']");

			listViewOptionEleForFolders.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImage);

		}
		catch (Exception e){
		}

	}

	/***********************************************************************************************
	 *  Function:  Validate the page to load all its content after clicking the Alert Profile tab
	 *  Input   :  NA
	 *  Action  :  Click Alert Profile Tab 
	 *  Output  :  Page should load all its content without any error

	 ***********************************************************************************************/
	public void deleteSupplierFolder(String folderName, String folderType)
	{
		try{
			navigateToFoldersPage(folderType);
			UIHelper.waitForPageToLoad(getDriver());
			listTabForFolder.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImage);
			itemsForPageEle.waitUntilPresent();
			itemsForPageEle.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImage);
			searchFoldersInputEle.waitUntilPresent();
			itemsForPageEle.waitUntilPresent();
			String finalFolderName =  folderName + new FileUtil().readDataFromFile(currentDateAndTimeDetailsStoreLocation);
			for(WebElement element:foldersTableRowsElement)
			{
				if(finalFolderName.equalsIgnoreCase(element.getText()))
				{
					UIHelper.mouseOverandclickanElement(getDriver(), element);
					selectAllChkboxEle.waitUntilPresent();
					selectAllChkboxEle.click();
					deleteFolderEle.waitUntilPresent();
					deleteFolderEle.click();
					deleteFolderPopupEle.waitUntilPresent();
					confirmBtnEle.waitUntilPresent();
					confirmBtnEle.click();
					UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadingImgInDeletePopup);
					selectAllChkboxEle.waitUntilPresent();
					break;
				}
			}

		}
		catch (Exception e){
			//e.printStackTrace();
		}
	}

	//Navigate to home page
	public void navigateToSuppliersPage()
	{
		
		UIHelper.highlightElement(getDriver(), suppliersTabEle);
		UIHelper.mouseOverandclickanElement(getDriver(), suppliersTabEle);
		//suppliersTabEle.click();
		//UIHelper.waitForPageToLoad(getDriver());
		//suppliersTitleEle.waitUntilPresent();
	}
	public String getSuppliersPageTitle()
	{
		return suppliersTitleEle.getText();
	}

	public void navigateToFoldersPage(String folderType)
	{
		try{
			if(folderType.equalsIgnoreCase("admin"))
			{		
				adminFolder.waitUntilPresent();
				adminFolder.click();
			}
			else if(folderType.equalsIgnoreCase("public"))
			{		
				publicFolder.waitUntilPresent();
				publicFolder.click();
			}
			else if(folderType.equalsIgnoreCase("private"))
			{
				mainPrivateFolderEle.waitUntilPresent();
				mainPrivateFolderEle.click();
			}
			listViewOptionEleForFolders.waitUntilPresent();
			listViewOptionEleForFolders.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),ajaxLoadingImgInFolders);
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),listLoadingImg);
			itemsForPageEle.waitUntilPresent();
			itemsForPageEle.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),ajaxLoadingImgInFolders);
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),listLoadingImg);
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImage);
			searchFoldersInputEle.waitUntilPresent();
			itemsForPageEle.waitUntilPresent();
			waitFor(2000).milliseconds();
		}
		catch(Exception e)
		{

		}
	}

	//Get Folder Names from Folder table
	public String getAllFolderNames()
	{
		try{
			folderNameTextVal = allFoldersTableEle.getText();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return folderNameTextVal;
	}

	public void exportSuppliers(String folderName, String folderType)
	{
		try{
			navigateToFoldersPage(folderType);
			if(folderType.equalsIgnoreCase("admin"))
			{			
				String tempFirstFolderNameInAdminFoldersXpath = firstFolderNameInAdminFolders.replace("SERENITY", folderName);
				WebElementFacade adminFirstFolderEle = find(By.xpath(tempFirstFolderNameInAdminFoldersXpath));
				adminFirstFolderEle.click();
			}
			else
			{
				int foldersPagecount = Integer.parseInt(foldersListCountEle.getText());
				int foldersPagejump = 0;
				if(foldersPagecount>1)
				{
					do{
						for(WebElement element:foldersTableRowsElement)
						{
							if(folderName.equalsIgnoreCase(element.getText()) || element.getText().contains(folderName))
							{
								expectedValue=folderName;
								UIHelper.mouseOverandclickanElement(getDriver(), element);
								break;
							}
						}

						if(folderName!=expectedValue)
						{
							if(!disabledNextBtnEle.isPresent())
							{
								nextBtnEle.click();
								UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),ajaxLoadingImgInFolders);
								UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),listLoadingImg);
								UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImage);
								searchFoldersInputEle.waitUntilPresent();
								itemsForPageEle.waitUntilPresent();
							}

							foldersPagejump = Integer.parseInt(foldersListJumpEle.getText());

							if(foldersPagejump==foldersPagecount)
							{
								for(WebElement element:foldersTableRowsElement)
								{
									if(folderName.equalsIgnoreCase(element.getText()) || element.getText().contains(folderName))
									{
										expectedValue=element.getText();
										UIHelper.mouseOverandclickanElement(getDriver(), element);
										break;
									}
								}
							}
						}

					}while(foldersPagejump!=foldersPagecount && folderName!=expectedValue);
				}
				else
				{
					for(WebElement element:foldersTableRowsElement)
					{
						if(folderName.equalsIgnoreCase(element.getText()) || element.getText().contains(folderName))
						{
							UIHelper.mouseOverandclickanElement(getDriver(), element);
							break;
						}
					}
				}


			}
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImage);
			exportButtonEle.waitUntilPresent();
			UIHelper.mouseOverandclickanElement(getDriver(), exportButtonEle);
			waitFor(3000).milliseconds();
			//exportCSVOptionEle.waitUntilPresent();
			UIHelper.mouseOverandclickanElement(getDriver(), exportCSVOptionEle);
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForPageToLoad(getDriver());
			waitFor(7000).milliseconds();
		}catch(Exception e){
		}
	}

	public void selectAllSuppliers()
	{
		try{
			UIHelper.mouseOverandclickanElement(getDriver(), selectAllChkboxEle);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void navigateToDivisionFolderSection()
	{
		try{
			UIHelper.mouseOverandElementdoubleClick(getDriver(), divisionFolderEle);
			divisionFolderTableEle.waitUntilPresent();
			divisionFolderTableFirstEle.waitUntilPresent();
			waitFor(2000).milliseconds();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	//Get Folder Names from Folder table
	public ArrayList<String> getDivisionFolderNames()
	{
		try{
			for(WebElement folderNameEle:divisionFolderNamesEle)
			{
				divisionFolderNames.add(folderNameEle.getText());
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return divisionFolderNames;
	}

	// Added New Supplier_sradha

	public void isDisplayedNumberOfFolderValue(String folderType) {
		try{
			UIHelper.mouseOveranElement(getDriver(), numberOfAdminFolderVal);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public String verifyInAdminFolderTitalOnTop() {
		String adminFolderval = null;
		try {
			adminFoldersValue.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), adminFoldersValue);
			adminFolderval = adminFoldersValue.getText().toString().trim();
			System.out.println("adminFoldersValue: "+adminFolderval);
		} catch (Exception e) {

		}
		return adminFolderval;
	}

	public String getAdminFoldersCount() {
		String adminFolderval = null;
		try {
			adminFolders.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), adminFolders);
			adminFolderval = adminFolders.getText().toString().trim();
			System.out.println("adminFolders: "+adminFolderval);
		} catch (Exception e) {

		}
		return adminFolderval;
	}

	public void verifyNumberOfSupplierInAdminValue() {

		try{
			UIHelper.mouseOveranElement(getDriver(), adminsupplierValue);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public int getFolderCountInAdminTile() {
	
		return Integer.parseInt(fldrCountAdminTile.getText().trim());
	}
	
	public int VerifySumOfSupplierInFolderName() {
		String s1,s2,s3,s4,s5;
		//String s2;
		int s6=0;
		try {
			sumOfSupplierVal.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), sumOfSupplierVal);
			//supplierFolderVal = adminFoldersValue.getText().toString().trim();
			s1=allsupilerIstEle.getText().toString().trim();
			s2=allsupiler2ndEle.getText().toString().trim();
			s3=allsupiler3rdEle.getText().toString().trim();
			s4=allsupiler4thEle.getText().toString().trim();
			s5=allsupiler5thEle.getText().toString().trim();
			s6=Integer.parseInt(s1)+Integer.parseInt(s2)+Integer.parseInt(s3)+Integer.parseInt(s4)+Integer.parseInt(s5);
			System.out.println("sumOfSupplierVal: "+s6);
		} catch (Exception e) {

		}
		return s6;
	}


	public void clickOnAdminFolderAllSuppliers(String folderName, String folderType) 

	{
		try{
			navigateToFoldersPage(folderType);
			if(folderType.equalsIgnoreCase("admin"))
			{			
				String tempFirstFolderNameInAdminFoldersXpath = firstFolderNameInAdminFolders.replace("SERENITY", folderName);
				WebElementFacade adminFirstFolderEle = find(By.xpath(tempFirstFolderNameInAdminFoldersXpath));
				adminFirstFolderEle.click();
			}
			else
			{
				int foldersPagecount = Integer.parseInt(foldersListCountEle.getText());
				int foldersPagejump = 0;
				if(foldersPagecount>1)
				{
					do{
						for(WebElement element:foldersTableRowsElement)
						{
							if(folderName.equalsIgnoreCase(element.getText()) || element.getText().contains(folderName))
							{
								expectedValue=folderName;
								UIHelper.mouseOverandclickanElement(getDriver(), element);
								break;
							}
						}

						if(folderName!=expectedValue)
						{
							if(!disabledNextBtnEle.isPresent())
							{
								nextBtnEle.click();
								UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),ajaxLoadingImgInFolders);
								UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),listLoadingImg);
								UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImage);
								searchFoldersInputEle.waitUntilPresent();
								itemsForPageEle.waitUntilPresent();
							}

							foldersPagejump = Integer.parseInt(foldersListJumpEle.getText());

							if(foldersPagejump==foldersPagecount)
							{
								for(WebElement element:foldersTableRowsElement)
								{
									if(folderName.equalsIgnoreCase(element.getText()) || element.getText().contains(folderName))
									{
										expectedValue=element.getText();
										UIHelper.mouseOverandclickanElement(getDriver(), element);
										break;
									}
								}
							}
						}

					}while(foldersPagejump!=foldersPagecount && folderName!=expectedValue);
				}
				else
				{
					for(WebElement element:foldersTableRowsElement)
					{
						if(folderName.equalsIgnoreCase(element.getText()) || element.getText().contains(folderName))
						{
							UIHelper.mouseOverandclickanElement(getDriver(), element);
							break;
						}
					}
				}
			}
		}
		catch(Exception e){
		}

	}

	public void ClickSupplierListButton() {
		try{
			UIHelper.mouseOverandclickanElement(getDriver(), supplierListButton);
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	public void IsDisplayedSupplierListAllDataValue() {
		try {			
			displaySupplierAllDataVal.isPresent();
			UIHelper.highlightElement(getDriver(),displaySupplierAllDataVal);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void checkedAllSupplierDataValue() {
		try{
			UIHelper.mouseOverandElementdoubleClick(getDriver(), checkdAllSupplier);
			UIHelper.highlightElement(getDriver(), checkdAllSupplier);
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	public void VerifyNoOfFolderInDivisionalFolderValue() {
		try {
			divisionalFolderList.waitUntilPresent();
			if (divisionalFolderList.isPresent()) {
				UIHelper.mouseOveranElement(getDriver(),divisionalFolderList);
				UIHelper.highlightElement(getDriver(), divisionalAdminList);
				divisionalAdminList.isCurrentlyVisible();					
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void IsDisplayedNoOfFolderInDivisionalFolder() {
		try {

		    List<WebElement> getArrayMembers = getDriver().findElements(By
		            .xpath(".//*[@id='divisionalListTableBlock']/tr/td[contains(@class,'name-row')]"));
		    
		    int count=getArrayMembers.size();
		/*
		    for (WebElement listData : getArrayMembers) {
		        someStringSet.add(listData.getText());
		    }*/
		} catch (Exception e) {

		
	}
	
	/*public String getDivisionalFoldersCount() {
		String divisFolderval = null;
		try {
			divListEle.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), divListEle);
			divisFolderval = divListEle.getText().toString().trim();
			System.out.println("divListEle: "+divisFolderval);
		} catch (Exception e) {

		}
		return divisFolderval;
	}
*/
/*try {

    List<WebElement> getArrayMembers = getDriver().findElements(By
            .xpath(".//*[@id='divisionalListTableBlock']/tr/td[contains(@class,'name-row')]"));
    
    int count=getArrayMembers.size();

    for (WebElement listData : getArrayMembers) {
        someStringSet.add(listData.getText());
    }
} catch (Exception e) {*/

}

	public void countNumberOfUserInAllSupplierValue(String folderName) {
		try {
		//adminIstAllSupplie.waitUntilPresent();
			if (adminIstAllSupplier.isPresent()) {
				UIHelper.mouseOveranElement(getDriver(),adminIstAllSupplier);
				UIHelper.highlightElement(getDriver(), allSupplierUserVal);
				allSupplierUserVal.isCurrentlyVisible();					
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ClickAllSupplierEditOption(String folderName) {
		try{
			UIHelper.mouseOverandclickanElement(getDriver(), allSupplierEditEle);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void IsDisplayedManageSupplierOption() {
		try{
		editManagesupplier.waitUntilPresent();
		if (editManagesupplier.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),editManagesupplier);
		
	}
		}
		catch (Exception e){
			
		}
	}

	public void IsNotDispalyedAssignProfile() {
		try{
			assignProfile.waitUntilPresent();
			if (assignProfile.isPresent()) {
				UIHelper.mouseOveranElement(getDriver(),assignProfile);
			
		}
			}
			catch (Exception e){
				
			}
}

	public void clickOnsaveOption() {
		try{
			UIHelper.mouseOverandclickanElement(getDriver(), saveOptionEditEle);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	public void clickOnCancelOption() {
		try {
			if (canelOptionEdit.isPresent()) {
				canelOptionEdit.click();
				UIHelper.waitForPageToLoad(getDriver());
				
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public void IsPresenceDeleteOptionEle() {
		try {
			if (deleteOption.isPresent()) {
				deleteOption.click();
				UIHelper.waitForPageToLoad(getDriver());
				UIHelper.highlightElement(getDriver(), deleteOption);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public void clickOnPublicFolder(String folderType1) {
		try{
			 if(folderType1.equalsIgnoreCase("public"))
			{		
				publicFolder.waitUntilPresent();
				publicFolder.click();
		}
	}
		catch(Exception e)
		{

		}
	}

	public void IsPresencePublicDeleteOption(String folderName1) {
		try {
			if (publicDeleteOption.isPresent()) {
				publicDeleteOption.click();
				UIHelper.waitForPageToLoad(getDriver());
				UIHelper.highlightElement(getDriver(), publicDeleteOption);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public void IsDiplayedEditButtonOption(String folderName1) {
		try {
			if (publicEditIotion.isPresent()) {
				publicEditIotion.click();
				UIHelper.waitForPageToLoad(getDriver());
				UIHelper.highlightElement(getDriver(), publicEditIotion);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickEditButtonInPublicFolder() {
		try {
			if (clickEditoptionPublic.isPresent()) {
				clickEditoptionPublic.click();
				clickEditoptionPublic.waitUntilPresent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public void clickSaveInEditPublicFolder() {
		try{
			UIHelper.mouseOverandclickanElement(getDriver(), saveOptionEditEle);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	public void verifyPublicSupplierCount(String folderType) {
		try {
			if
		(publicSupplierCount.isPresent()){
		publicSupplierCount.click();
		publicSupplierCount.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), publicEditIotion);
		//UIHelper.mouseOverandclickanElement(getDriver(), publicNewFolder);
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	
	public String verifyUserISDisplayedPublicFolder() {
		String userFolderVal=null;
		try{
			publicUserValue.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), publicUserValue);
			userFolderVal=publicUserValue.getText().toString().trim();
			System.out.println("userFoldersValue: "+userFolderVal);
		} catch (Exception e) {

		}
		return userFolderVal;
		}
	
	
public String getPublicFolderUserCount() {
	String FolderUser = null;
	try {
		folderUserValue.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), folderUserValue);
		FolderUser =folderUserValue.getText().toString().trim();
		System.out.println("folderUserValue: "+FolderUser);
	} catch (Exception e) {

	}
	return FolderUser;
}

public String verifyAlertAssignProfile() {
	String newFolderVal=null;
	try{
		newFolderAssigneVal.waitUntilPresent();
		UIHelper.highlightElement(getDriver(),newFolderAssigneVal);
		newFolderVal=newFolderAssigneVal.getText().toString().trim();
		System.out.println("newFolderAssigneVal:" +newFolderVal);
	}
	catch( Exception e){
		
	}
	return newFolderVal;
}

public String getAlertAssignProfileVal() {
	String FolderUser = null;
	try {
		alertProfileAssineVal.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), alertProfileAssineVal);
		FolderUser =alertProfileAssineVal.getText().toString().trim();
		System.out.println("alertProfileAssineVal: "+FolderUser);
	} catch (Exception e) {

	}
	return FolderUser;
}

public void clickBookMarkLinkOption() {
	try{
		UIHelper.mouseOverandclickanElement(getDriver(), saveOptionEditEle);
	}catch(Exception e){
		e.printStackTrace();
	}
}

public void VerifyFolderNamePresent(String folderName1) {
	try {
		if (selectOneBookMark.isPresent()) {
	
			selectOneBookMark.waitUntilPresent();
			selectOneBookMark.isCurrentlyVisible();
			UIHelper.highlightElement(getDriver(), selectOneBookMark);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
}

public void clickListViewData() {
	try{
		UIHelper.mouseOverandclickanElement(getDriver(), listViewEle);
	}catch(Exception e){
		e.printStackTrace();
	}
	
}

public void clickBookMarkFolder() {
	try{
		UIHelper.mouseOverandclickanElement(getDriver(), bookmarkFolder);
	}catch(Exception e){
		e.printStackTrace();
	}
	
}

public void verifyBookFolderType() {
	try {
		if (bookMarkType.isPresent()) {
			bookMarkType.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), bookMarkType);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

public void ClickBoomMark() {
	try{
		UIHelper.mouseOverandclickanElement(getDriver(), bookmarkFolder);
	}catch(Exception e){
		e.printStackTrace();
	}
	
}

public void IsDisplayedAllsupplier() {
	try {
		if (bookmarkAllSupplier.isPresent()) {
			bookmarkAllSupplier.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), bookmarkAllSupplier);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

public void selectFolderAndClickBookMark() {
	try {
		if (bookmarkAllSupplier.isPresent()) {
			bookmarkAllSupplier.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), bookmarkAllSupplier);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
}

public void logoutsupplierPage() {
	try{
		UIHelper.mouseOverandclickanElement(getDriver(), logOut);
	}catch(Exception e){
		e.printStackTrace();
	}
	
}

public void VerifyViewFolder() {
	try {
		if (folderNameinTable.isPresent()) {
			folderNameinTable.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), folderNameinTable);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}


public void IsDisplayedDelete() {
	try{
		UIHelper.mouseOveranElement(getDriver(), deleteFolderEle);
	}catch(Exception e){
		e.printStackTrace();
	}
	
	
}
// 25 th July :After sever off

public boolean VerifyOwnerShipListOption() {

	if(OwnerShipListEle.isPresent())
	{
		UIHelper.mouseOveranElement(getDriver(), OwnerShipListEle);
		UIHelper.highlightElement(getDriver(), OwnerShipListEle);
		return true;
	}
	else
	{
		return false;
	}
}

public void CheckCheckBoxInOwnerShipList() {
	
	try {
		if (CheckboxInOwnerShipEle.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(), CheckboxInOwnerShipEle);
			UIHelper.highlightElement(getDriver(), CheckboxInOwnerShipEle);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
}

public void ClickOnSaveOption() {
	try{
		UIHelper.mouseOverandclickanElement(getDriver(), editFoldersave);
		/*UIHelper.highlightElement(getDriver(), saveConfMsg);
		saveConfMsg.isCurrentlyVisible();		*/			
	

}catch(Exception e){
		e.printStackTrace();
	}
	
}

public void clickPublicFolderEditOption(String folderName) {
	try{
		UIHelper.mouseOverandclickanElement(getDriver(), clickPublicEditOption);
	}catch(Exception e){
		e.printStackTrace();
	}
	
}

public void IsDiplayedManageSupplier() {
	try {
		manageSupplierEdit.waitUntilPresent();
		if (manageSupplierEdit.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),manageSupplierEdit);
			UIHelper.highlightElement(getDriver(), manageSupplierEdit);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//Enter Duns Number:Manage User
public void enterDunsNumber(String enterDunsNumber) {
	try {
		EditAddSupplier.waitUntilPresent();
		if (EditAddSupplier.isPresent() && enterDunsNumber != null && !enterDunsNumber.isEmpty()) {
			EditAddSupplier.type(enterDunsNumber);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//Edit manage supplier Save option:Alert message
public String IsdisplayedAletMsg() {
	if(saveConfMsg.isPresent())
	{			
		UIHelper.highlightElement(getDriver(), saveConfMsg);
		return saveConfMsg.getText();
	}
	else
	{
		return null;
	}
	
}

public void editPrivateFolderName(String folderType, String folderName, String newFolderName, String assignedProfile,
		String addSuppliers, String bookmark) {
	try{
		clickPrivateSupplHeader();

		navigateToFoldersPage(folderType);
		UIHelper.waitForPageToLoad(getDriver());

		String finalFolderName = folderName + new FileUtil().readDataFromFile(currentDateAndTimeDetailsStoreLocation);
		FolPrivateNameLinkXpath = FolPrivateNameLinkXpath.replace("SERENITY", finalFolderName);
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImage);
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), FolPrivateNameLinkXpath);
		WebElementFacade folderNameLinkEle = find(By.xpath(FolPrivateNameLinkXpath));
		folderNameLinkEle.click();
		String finalNewFolderName = newFolderName + new FileUtil().readDataFromFile(currentDateAndTimeDetailsStoreLocation);
		if(newFolderName!=null &&!newFolderName.isEmpty() && !newFolderName.equalsIgnoreCase("no"))
		{
			txteditFolderName.waitUntilPresent();
			txteditFolderName.type(finalNewFolderName);
		}
		if(assignedProfile!=null && !assignedProfile.isEmpty() && !assignedProfile.equalsIgnoreCase("no"))
		{
			selectAssignedProfile.type(assignedProfile);
			editAssignedProfile.click();
			/*assignUserSearchbuttonforEdit.click();
			loginNameForEditAssignUser.type(assignedProfile);
			assignUserEmailSelectForEdit.click();*/
		}
		if(addSuppliers != null && !addSuppliers.isEmpty() &&!addSuppliers.equalsIgnoreCase("no"))
		{
			addSupplierTextBoxforEdit.type(addSuppliers);
			//removeSupplierCheckBoxforEdit.click();
			addSupplierCheckBoxforEdit.click();
		}
		/*if(suppliersToRemove != null && !suppliersToRemove.isEmpty() &&!suppliersToRemove.equalsIgnoreCase("no"))
		{
			addSupplierTextBoxforEdit.type(suppliersToRemove);
			removeSupplierCheckBoxforEdit.click();
		}*/
		if(bookmark.equalsIgnoreCase("yes")&& !bookmark.isEmpty() &&!bookmark.equalsIgnoreCase("no"))
		{
			chkboxBookmarkforEdit.click();
		}
		btnEditSave.click();
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImageforEditSaveButton);
		UIHelper.waitForPageToLoad(getDriver());
		//UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[@id='publicFolderData']");
		//UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[@id='adminFolderData']");
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[@id='personalFolderData']");

		listViewOptionEleForFolders.click();
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImage);

	}
	catch (Exception e){
	}

}
//  Click New Folder Icon

public void ClickNewFolderIcon() {
	
	try{
		UIHelper.highlightElement(getDriver(), newFolderTab);
		UIHelper.mouseOverandclickanElement(getDriver(), newFolderTab);
		
	}catch(Exception e){
		e.printStackTrace();
	}
}

//Displayed New Folder Heading

public String VerifyHeadingNewFolder() {
	
	
	if(newFolderHeading.isPresent())
	{			
		UIHelper.highlightElement(getDriver(), newFolderHeading);
		return newFolderHeading.getText();
	}
	else
	{
		return null;
	}
	
}

//Displayed One Line Under Create New Folder 

public void IsDispalyedOneLineUnderCreateNewFolder() {
	try {
		newFolderHeading.waitUntilPresent();
		if (newFolderHeading.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),newFolderHeading);
			UIHelper.highlightElement(getDriver(), newFolderHeading);
			newFolderHeading.isCurrentlyVisible();					
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
  //Displayed Folder Name and Text Field in New Folder
public void verifyFolderWithTextName() {
	try {
		newFolderFolderName.waitUntilPresent();
		if (newFolderFolderName.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),newFolderFolderName);
			UIHelper.highlightElement(getDriver(), folderNametextFiled);
			folderNametextFiled.isCurrentlyVisible();					
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
// Displayed Public Private Option
public void IsDiplayedPublicPrivateOption() {
	try{
		UIHelper.mouseOveranElement(getDriver(), newFolderPublic);
		UIHelper.highlightElement(getDriver(), newFolderPublic);
		UIHelper.mouseOveranElement(getDriver(), newFolderPrivate);
		UIHelper.highlightElement(getDriver(), newFolderPrivate);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}
// Displayed Assign User in New Folder

public String IsDisplayedAssignUser() {
	if(assignUser.isPresent())
	{			
		UIHelper.highlightElement(getDriver(), assignUser);
		return assignUser.getText();
	}
	else
	{
		return null;
	}
	
}
//Displayed Tabular assign User
public void IsDipalyedTabularFormAssignUser() {
	try {
		tableAssignUser.waitUntilPresent();
		if (tableAssignUser.isPresent()) {
			UIHelper.highlightElement(getDriver(), tableAssignUser);
								
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
}

//Verify Assign User Header Name
public void VerifyHeaderInAssignUser() {
	try {
		tableHeaderAssignUser.waitUntilPresent();
		if (tableHeaderAssignUser.isPresent()) {
			UIHelper.highlightElement(getDriver(), tableHeaderAssignUser);
								
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//Verify tabular data
public void verfiyTabularColum() {
	try {
		tabularData.waitUntilPresent();
		if (tabularData.isPresent()) {
			UIHelper.highlightElement(getDriver(), tabularData);
								
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//Verify Add supplier
public String verifyAddSupplier() {
	if(addSupplierNewFolder.isPresent())
	{			
		UIHelper.highlightElement(getDriver(), addSupplierNewFolder);
		return addSupplierNewFolder.getText();
	}
	else
	{
		return null;
	}
}
//Verify ADD supplier Text Box
public void verifyTextBox() {
	try {
		addSupplierTextBox.waitUntilPresent();
		if (addSupplierTextBox.isPresent()) {
			UIHelper.highlightElement(getDriver(), addSupplierTextBox);
								
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//verify assign text profile
public void verifytextAssignProfile() {
	try {
		assignProfileText.waitUntilPresent();
		if (assignProfileText.isPresent()) {
			UIHelper.highlightElement(getDriver(), assignProfileText);
								
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
}
//verify assign profile drop down
public void veriyDropDownassingProfile() {
	try{
		UIHelper.highlightElement(getDriver(), assignedProfileDropDownForNewFolder);
		UIHelper.mouseOverandElementdoubleClick(getDriver(), assignedProfileDropDownForNewFolder);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}
//verify Book Mark New Folder
public void verifyBookMark() {
	try {
		bookMarkwithCheckBox.waitUntilPresent();
		if (bookMarkwithCheckBox.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(), bookMarkwithCheckBox);
			
								
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//
public void verfySaveandCancelOption() {
	try{
		UIHelper.mouseOveranElement(getDriver(),cancelNF);
		UIHelper.highlightElement(getDriver(), cancelNF);
		UIHelper.mouseOveranElement(getDriver(), saveNF);
		UIHelper.highlightElement(getDriver(),saveNF);
		
	}catch(Exception e){
		e.printStackTrace();
	}
}

//Click On Private Button IN New Folder
public void clickOnPrivateButton() {
	try{
		newFolderPrivate.waitUntilPresent();
		if (newFolderPrivate.isPresent()) {
		UIHelper.mouseOverandclickanElement(getDriver(), newFolderPrivate);
		UIHelper.highlightElement(getDriver(), newFolderPrivate);
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//Enter Folder Name In New Folder
public void enterFolderName(String folderName) {
	try {
		txteditFolderName.waitUntilPresent();
		if (txteditFolderName.isPresent() && folderName != null && !folderName.isEmpty()) {
			txteditFolderName.type(folderName);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

// Verify DefaultType public

public void verifyDefaultTypePublic() {
	newFolderPublic.waitUntilVisible();
	UIHelper.mouseOveranElement(getDriver(), newFolderPublic);
	UIHelper.highlightElement(getDriver(), newFolderPublic);
	newFolderPublic.isCurrentlyVisible();
	
}
//Verify Assign User is not available
public boolean verifyAssignUserNotAvailable() {
	/*try {


		String AssignUserNotVis =  assignUser
				.verifyAssignUserNotAvailable().toString().trim();
		System.out.println("lowriskTestDelinq: " + AssignUserNotVis);
		Assert.assertEquals(assignUser2, AssignUserNotVis);

	} catch (Exception e) {
		e.printStackTrace();
	}
	*/
	
	 assignUser.waitUntilVisible();
//	ownershipDetailedPg.waitUntilVisible();
//	if(ownershipDetailedPg.isPresent())
	if( assignUser.isPresent() || tableAssignUser.isPresent())
	{
		return true;
	}
	else
	{
		return false;
	}
	
}
//Open and Close new Folder
public void openAndCloseNewFld() {
	
	try{
		UIHelper.highlightElement(getDriver(), newFolderTab);
		UIHelper.mouseOverandclickanElement(getDriver(), newFolderTab);
		UIHelper.mouseOverandclickanElement(getDriver(), colsecrossEle);
		
	}catch(Exception e){
		e.printStackTrace();
	}
}
//Verify Company list Tabular Column
public void verifyCompanyListColumn() {
	try{
		listTabForFolder.waitUntilVisible();
		UIHelper.mouseOverandclickanElement(getDriver(), listTabForFolder);

		UIHelper.highlightElement(getDriver(), listTabForFolder);
		}
	
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//verify Company List in 
public void IsDisplayedListOFCompany() {
	try{
		bookMarkFolderView.waitUntilPresent();
		if (bookMarkFolderView.isPresent()) {
		UIHelper.highlightElement(getDriver(), bookMarkFolderView);
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//Disabled delete Button
public void IsDisabledDeleteButton() {
	try{
		deleteDisabledAllSuppliers.waitUntilPresent();
		if (deleteDisabledAllSuppliers.isPresent()) {
		UIHelper.mouseOveranElement(getDriver(), deleteDisabledAllSuppliers);	
		UIHelper.highlightElement(getDriver(), uncheckSupplierName);
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Click On AllSupplier
public void clickonAllSupplier() {
	try{
		clickAllSupplier.waitUntilVisible();
		UIHelper.mouseOverandclickanElement(getDriver(), clickAllSupplier);
        UIHelper.highlightElement(getDriver(), clickAllSupplier);
		}
	
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//click on CheckBox
public void checkSupplierCheckBox() {
	try{
		uncheckSupplierName.waitUntilPresent();
		if (uncheckSupplierName.isPresent()) {
		UIHelper.mouseOverandElementdoubleClick(getDriver(), uncheckSupplierName);	
		UIHelper.highlightElement(getDriver(), uncheckSupplierName);
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//click on Delete Button
public void clickOndeleteButton() {
	
	try{
		deleteButton.waitUntilPresent();
		if (deleteButton.isPresent()) {
		UIHelper.mouseOverandclickanElement(getDriver(), deleteButton);	
		
		}
	}
	
	catch(Exception e){
		e.printStackTrace();
	}
	
	
	
}
//Delete Conformation pop up
public void confmMsg() {
	try{
		deleteSupplierPopUpMsg.waitUntilPresent();
		if (deleteSupplierPopUpMsg.isPresent()) {
			String p = deleteSupplierPopUpMsg.getText().toString().trim();
			System.out.println("popup message: " + p);
			UIHelper.isDisplayedAlertMessage(getDriver());
			UIHelper.highlightElement(getDriver(), deleteSupplierPopUpMsg);
			//getDriver().switchTo().defaultContent();
			
		
		
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Click On cancel Button
public void ClickOnCancelButton()
{
	
	try{
		popUpCancelButton.waitUntilPresent();
		if (popUpCancelButton.isPresent()) {
			String p = popUpCancelButton.getText().toString().trim();
			System.out.println("popup message: " + p);
			UIHelper.highlightElement(getDriver(), popUpCancelButton);
			Alert alert=getDriver().switchTo().alert();
			 alert.dismiss();
			getDriver().switchTo().defaultContent();
			//UIHelper.processalert(getDriver());
			
		//UIHelper.mouseOverandclickanElement(getDriver(), popUpCancelButton);	
		
		}
	}
	
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//click on conform button
public void clickOnConformButton(){

	try{
		popUpConformButton.waitUntilPresent();
		if (popUpConformButton.isPresent()) {
			String p = popUpConformButton.getText().toString().trim();
			System.out.println("popup message: " + p);
			Alert alert=getDriver().switchTo().alert();
			 alert.accept();
			UIHelper.highlightElement(getDriver(), deleteSupplierPopUpMsg);
			// popUpConformButton.click();
			 getDriver().switchTo().defaultContent();
			//UIHelper.processalert(getDriver());
			
		//UIHelper.mouseOverandclickanElement(getDriver(), popUpConformButton);	
		
		}
	}
	
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Click On BOOKMark Link
public void ClickOnBookMarkLink() {
	try{
		bookmarksLinkEle.waitUntilPresent();
		if (bookmarksLinkEle.isPresent()) {
		UIHelper.mouseOverandclickanElement(getDriver(), bookmarksLinkEle);	
		UIHelper.highlightElement(getDriver(), bookmarksLinkEle);
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//Click On Supplier tab
public void clickOnSupplierTab() {
	try{
		supplierTab.waitUntilPresent();
		if (supplierTab.isPresent()) {
		UIHelper.mouseOverandElementdoubleClick(getDriver(), supplierTab);	
		
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Mouse Over Delete Button in Public
public void mouseOverDeleteButton() {
	try{
		folderTableFirstEle.waitUntilPresent();
		if (folderTableFirstEle.isPresent()) {
		UIHelper.mouseOveranElement(getDriver(),folderTableFirstEle);	
		UIHelper.mouseOveranElement(getDriver(), deleteButnPublIstEle);
		
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Click delete Icon in public folder
public void clikDeleteIconPublicFolder() {
	try{
		
		deleteButnPublIstEle.waitUntilPresent();
	if (deleteButnPublIstEle.isPresent()) {
	UIHelper.mouseOverandclickanElement(getDriver(),folderTableFirstEle);	
	}
}
	
catch(Exception e){
	e.printStackTrace();
}
	
}
//Main page should be Displayed
public void IsDisplayedMainPage() {
try{
		
	mainPublicFolderEle.waitUntilPresent();
	if (mainPublicFolderEle.isPresent()) {
	}
}
	
catch(Exception e){
	e.printStackTrace();
}
	
}
//Message Displayed
public void messageDisplayed() {
	try{
		sharedFolderErrmsg.waitUntilPresent();
		if (sharedFolderErrmsg.isPresent()) {
		UIHelper.mouseOveranElement(getDriver(),sharedFolderErrmsg);	
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Supplier Folder Left Side
public void IsDisplayedSupplierFolderLeftSide() {
	try {
		if (suppliersTitleEle.isDisplayed()
				&& suppliersTitleEle.isEnabled()) {
			UIHelper.highlightElement(getDriver(), suppliersTitleEle);
			String getName = suppliersTitleEle.getText().toString().trim();
			System.out.println("supplier folder" +getName);
		}
	} catch (Exception E) {
		throw E;
	}

	
}
//Displayed WatchList Folder
public void IsDisplayedwatchListFolder() {
	try {
		if (watchListFold.isDisplayed()) {
			UIHelper.highlightElement(getDriver(), watchListFold);
			String getName = watchListFold.getText().toString().trim();
			System.out.println("WatchList folder" +getName);
		}
	} catch (Exception E) {
		throw E;
	}
	
}
//Displayed Admin,Public,Private Folder
public void IsDisplayedAllFold() {
	try{
		UIHelper.mouseOveranElement(getDriver(), adminFolderTab);
		UIHelper.highlightElement(getDriver(), adminFolderTab);
		UIHelper.mouseOveranElement(getDriver(), publicFoldTab);
		UIHelper.highlightElement(getDriver(), publicFoldTab);
		UIHelper.mouseOveranElement(getDriver(), privateFoldTab);
		UIHelper.highlightElement(getDriver(), privateFoldTab);
		
		waitFor(2000).milliseconds();
	}catch(Exception e){
		e.printStackTrace();
	}
	
}
//Displayed Tile Folder
public void IsDisplayedTileFold() {
	try{
		UIHelper.mouseOveranElement(getDriver(), adminFolder);
		UIHelper.highlightElement(getDriver(), adminFolder);
		UIHelper.mouseOveranElement(getDriver(), mainPublicFolderEle);
		UIHelper.highlightElement(getDriver(), mainPublicFolderEle);
		UIHelper.mouseOveranElement(getDriver(), mainPrivateFolderEle);
		UIHelper.highlightElement(getDriver(), mainPrivateFolderEle);
		
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}
//Displayed BookMark Header Link
public void IsDisplayedBookMarkFld() {
	try {
		if (bookmarkFolder.isDisplayed()) {
			UIHelper.highlightElement(getDriver(), bookmarkFolder);
			UIHelper.mouseOverandclickanElement(getDriver(), bookmarkFolder);
		
		}
	} catch (Exception E) {
		throw E;
	}
	
}
//Displayed New Folder
public void IsDisplayedNewFold() {
	try {
		if (newFolderTab.isDisplayed()) {
			UIHelper.highlightElement(getDriver(), newFolderTab);
			String getName = newFolderTab.getText().toString().trim();
			System.out.println("New folder" +getName);
		}
	} catch (Exception E) {
		throw E;
	}
	
}

public void IsDisplayedalertProfile() {
	try{
		alertProfileTab.waitUntilPresent();
		if (alertProfileTab.isPresent()) {
	  UIHelper.mouseOveranElement(getDriver(), createaNewFolder);
		UIHelper.highlightElement(getDriver(), alertProfileTab);	
		
		}
	}
	
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Displayed List Icon
public void IsDisplayedListIcon() {
	try{
		listViewEle.waitUntilPresent();
		if (listViewEle.isPresent()) {
			UIHelper.highlightElement(getDriver(), listViewEle);
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Displayed Sort By
public void IsDisplayedsortBy() {
	try{
		 sortingDropdownEle.waitUntilPresent();
		if (sortingDropdownEle.isPresent()) {
			UIHelper.highlightElement(getDriver(),  sortingDropdownEle);
			UIHelper.mouseOveranElement(getDriver(), sortByEle);
			String sb=sortByEle.getText().toString().trim();
			System.out.println("sort By"+sb);
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Click drop Down In sort By
public void clickDropDownSortLis() {
	try{
		sortingDropdownEle.waitUntilPresent();
		if (sortingDropdownEle.isPresent()) {
			UIHelper.highlightElement(getDriver(), sortingDropdownEle);
			sortingDropdownEle.click();
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//BookMark Folder are Tile Format
public void IsDisplayedTileForm() {
	try{
		UIHelper.mouseOveranElement(getDriver(), allsupTileFormt);
		UIHelper.highlightElement(getDriver(), allsupTileFormt);
		UIHelper.mouseOveranElement(getDriver(), certifidTileFormt);
		UIHelper.highlightElement(getDriver(), certifidTileFormt);
		
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//Displayed Tile Format Folder name
public void IsDisplayedSomeFold() {
	try{
		UIHelper.mouseOveranElement(getDriver(), bookmarkAllSupplier);
		UIHelper.highlightElement(getDriver(), bookmarkAllSupplier);
		UIHelper.mouseOveranElement(getDriver(), certifidTileFormtFldNam);
		UIHelper.highlightElement(getDriver(), certifidTileFormtFldNam);
		UIHelper.mouseOveranElement(getDriver(), unmatchedFldNam);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}
//Displayed All Information In All supplier
public void IsDisplayedAllInformation() {
	try{
		allsupTileFormt.waitUntilPresent();
		if (allsupTileFormt.isPresent()) {
			UIHelper.highlightElement(getDriver(), allsupTileFormt);
			UIHelper.mouseOveranElement(getDriver(), allsupplierUser);
			UIHelper.mouseOveranElement(getDriver(), allsupplFoldNma);
			UIHelper.mouseOveranElement(getDriver(), alertProfl);
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
}
//Displayed Edit and Delete
public void IsDisplayedEditDelete() {
	try{
		allsupTileFormt.waitUntilPresent();
		if (allsupTileFormt.isPresent()) {
			
			UIHelper.mouseOveranElement(getDriver(), allsupplierUser);
			UIHelper.highlightElement(getDriver(), editDelete);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Displayed Pagination
public void IsDisplayedPagination() {
	try{
		allsupTileFormt.waitUntilPresent();
		if (allsupTileFormt.isPresent()) {
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Display BookMark HyperLink
public void bookMarkHyperLink() {
	try{
		bookmarksLinkEle.waitUntilPresent();
		if (bookmarksLinkEle.isPresent()) {
			UIHelper.highlightElement(getDriver(), bookmarksLinkEle);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Folder displayed Tile Format in public
public void countFoldDisplayed() {
	try{
		adminFolders.waitUntilPresent();
		if (adminFolders.isPresent()) {
			UIHelper.highlightElement(getDriver(), adminFolders);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Comapring Folder In Public 
public String comparingFoldInPublic() {
	String publicFolderval = null;
	try {
		publicFldValue.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), publicFldValue);
		publicFolderval = publicFldValue.getText().toString().trim();
		System.out.println("publicFldValue: "+publicFolderval);
	} catch (Exception e) {

	}
	return publicFolderval;
}

public String getPublicFoldersCount() {
	String publicFolderval = null;
	try {
		adminFolders.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), adminFolders);
		publicFolderval = adminFolders.getText().toString().trim();
		System.out.println("adminFolders: "+publicFolderval);
	} catch (Exception e) {

	}
	return publicFolderval;
	
}
//Supplier Count In Each folder Name
public void supplierCountInFolderName() {
	try{
		UIHelper.mouseOveranElement(getDriver(), folderTableFirstEle);
			UIHelper.highlightElement(getDriver(), folderTableFirstEle);
			UIHelper.mouseOveranElement(getDriver(), istSupplierInPublic);
			UIHelper.mouseOveranElement(getDriver(), folderTableLastEle);
			UIHelper.highlightElement(getDriver(), folderTableLastEle);
			UIHelper.mouseOveranElement(getDriver(), lastSupplierInPublic);
					
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Add Supplier Total Count 
public void addSupplierTotalcount() {
	try{
	List<WebElement> rows = getDriver().findElements(By.xpath("sumOfSupplierVal"));
	System.out.println("Total number of rows :"+ rows.size());
	}
	catch(Exception e){
		e.printStackTrace();
	}
}
//Comparing Folder In private
public String comparingFoldInPrivate() {
	String privateFolderval = null;
	try {
		privateFldValue.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), privateFldValue);
		privateFolderval = privateFldValue.getText().toString().trim();
		System.out.println("privateFldValue: "+privateFolderval);
	} catch (Exception e) {

	}
	return privateFolderval;
}

public String  getPrivateFoldersCount() {
	String privateFolderval = null;
	try {
		adminFolders.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), adminFolders);
		privateFolderval = adminFolders.getText().toString().trim();
		System.out.println("adminFolders: "+privateFolderval);
	} catch (Exception e) {

	}
	return privateFolderval;
	

	
}
//verify Supplier Count
public void verifySupplierCount() {
	try{
		UIHelper.mouseOveranElement(getDriver(), privateIstFldVal);
			UIHelper.highlightElement(getDriver(), privateIstFldVal);
			UIHelper.mouseOveranElement(getDriver(), privateIstSupplVal);
			UIHelper.mouseOveranElement(getDriver(), privateLastFldVal);
			UIHelper.highlightElement(getDriver(), privateLastFldVal);
			UIHelper.mouseOveranElement(getDriver(), privateLastSupplVal);
					
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}

public void addSuppliercountprivate() {
	try{
		UIHelper.highlightElement(getDriver(), sumofSupplierinPrivate);
		List<WebElement> rows = getDriver().findElements(By.xpath("sumofSupplierinPrivate"));
		System.out.println("Total number of rows :"+ rows.size());
		}
		catch(Exception e){
			e.printStackTrace();
		}
	
}
//Verify Alert profile Tab
public void verifyAlertprofileTab() {
	try{
		alertProfileTab.waitUntilPresent();
		if (alertProfileTab.isPresent()) {
			UIHelper.highlightElement(getDriver(), alertProfileTab);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Click on Alert Profile
public void clickAlertProfile() {
	try{
		alertProfileTab.waitUntilPresent();
		if (alertProfileTab.isPresent()) {
			UIHelper.highlightElement(getDriver(), alertProfileTab);
			UIHelper.mouseOverandclickanElement(getDriver(), alertProfileTab);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Verify Bread Crumb
public void verifyBreadCrumb() {
	try{
		bookmarksLinkEle.waitUntilPresent();
		if (bookmarksLinkEle.isPresent()) {
			UIHelper.highlightElement(getDriver(),bookmarksLinkEle);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//click On Bread Crumb
public void clickBreadCrumb() {
	try{
		bookmarksLinkEle.waitUntilPresent();
		if (bookmarksLinkEle.isPresent()) {
			UIHelper.highlightElement(getDriver(),bookmarksLinkEle);
			UIHelper.mouseOverandclickanElement(getDriver(), bookmarksLinkEle);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//verify Folder Loaded By Default
public void verifyFolderLoadedByDefault() {
	
	try{
		bookMarkFld.waitUntilPresent();
		if (bookMarkFld.isPresent()) {
			UIHelper.highlightElement(getDriver(),bookMarkFld);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//Verify BookMark Folder Is Displayed
public void verifyFolderIsDisplayed() {
	try{
		adminFolders.waitUntilPresent();
		if (adminFolders.isPresent()) {
			UIHelper.highlightElement(getDriver(),adminFolders);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//verify Item per Page
public void verifyItemPerPage() {
	
	try{
		itemsPerPageOption.waitUntilPresent();
		if (itemsPerPageOption.isPresent()) {
			UIHelper.highlightElement(getDriver(),itemsPerPageOption);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
}
//verify pagination
public void verifyIPagination() {
	try{
		itemsPerPage.waitUntilPresent();
		if (itemsPerPage.isPresent()) {
			UIHelper.highlightElement(getDriver(),itemsPerPage);
			UIHelper.mouseOverandclickanElement(getDriver(), itemsPerPage);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Click 50 Item Per Page
public void click50ItemPerPage() {
	try{
		itemsPerPageOption.waitUntilPresent();
		if (itemsPerPageOption.isPresent()) {
			UIHelper.highlightElement(getDriver(),itemsPerPageOption);
			UIHelper.mouseOverandclickanElement(getDriver(), itemsPerPage);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//verify Total Number Page
public void verifyTotalNumberPage() {
	try{
		UIHelper.highlightElement(getDriver(), pageCount);
		List<WebElement> pages = getDriver().findElements(By.xpath("pageCount"));
		System.out.println("Total number of page :"+ pages.size());
		}
		catch(Exception e){
			e.printStackTrace();
		}
	
	
}
//Click 20 Item Per Page
public void click20ItemPerPage() {
	try{
		itemsPerPageOption.waitUntilPresent();
		if (itemsPerPageOption.isPresent()) {
			UIHelper.highlightElement(getDriver(),itemsPerPageOption);
			UIHelper.mouseOverandclickanElement(getDriver(), itemsPerPage20);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//verify List Structure Displayed
public void verifyListStrIsDisplayed() {
	try{
		folderNameinTable.waitUntilPresent();
		if (folderNameinTable.isPresent()) {
			UIHelper.highlightElement(getDriver(),folderNameinTable);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
}
		

//List View FolderName,FolderType
public void verifyListStrIsDisplayedTabularColumn() {
	try{
		
			UIHelper.highlightElement(getDriver(),folderNameinTable);
			UIHelper.mouseOveranElement(getDriver(), bookMarkType);
			UIHelper.highlightElement(getDriver(), alertProfileColumn);
			UIHelper.mouseOveranElement(getDriver(), sumOfSupplierVal);
			UIHelper.highlightElement(getDriver(), allSupplierUserVal);
			UIHelper.mouseOveranElement(getDriver(), actionRows);
			
		
		
		
}catch(Exception e){
		e.printStackTrace();
	}
}



//Displayed Edit Bookmark,Edit,Delete
public void verifyBkmarkEditDeltIsDisplayed() {
	
	try{
		actionRows.waitUntilPresent();
		if (actionRows.isPresent()) {
UIHelper.mouseOveranElement(getDriver(), actionRows);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
		}


//Verify Mouse Over Remove BOOkmark,Edit,Delete
public void verifymouseOverIsDisplayed() {
	try{
		UIHelper.highlightElement(getDriver(), removeBookmarkItem);
		UIHelper.mouseOveranElement(getDriver(), removeBookmarkItem);
		UIHelper.highlightElement(getDriver(), editOption);
		UIHelper.mouseOveranElement(getDriver(),editOption);
		UIHelper.highlightElement(getDriver(), deletOption);
		UIHelper.mouseOveranElement(getDriver(), deletOption);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	
}
//Verify Admin Column
public void verifyAdminColumn() {
	try{
		bookMarkType.waitUntilPresent();
		if (bookMarkType.isPresent()) {
UIHelper.mouseOveranElement(getDriver(), bookMarkType);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Click Left Arrow All supplier
public void ClickLeftArroeAllSupplier() {
	try{
		leftArrowAllSup.waitUntilPresent();
		if (leftArrowAllSup.isPresent()) {
        UIHelper.mouseOverandclickanElement(getDriver(),leftArrowAllSup);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
		}
//Mouse Over Edit Button
public void hoverOverEditButton() {
	try{
		allSupplierEditEle.waitUntilPresent();
		if (allSupplierEditEle.isPresent()) {
UIHelper.mouseOveranElement(getDriver(),allSupplierEditEle);
UIHelper.highlightElement(getDriver(),allSupplierEditEle);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
}
//Hover Over Delete Button
public void hoverOverDeltButton() {
	
	try{
		allsupdelOptn.waitUntilPresent();
		if (allsupdelOptn.isPresent()) {
UIHelper.mouseOveranElement(getDriver(),allsupdelOptn);
UIHelper.highlightElement(getDriver(),allsupdelOptn);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Click On All Supplier
public void clickOnHyperlinkFoldName() {
	try{
		clickAllSupplier.waitUntilVisible();
		UIHelper.mouseOverandclickanElement(getDriver(), clickAllSupplier);
        UIHelper.highlightElement(getDriver(), clickAllSupplier);
		}
	
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//Displayed List Details
public void IsDisplayedListDeatils() {
	try{
	
       UIHelper.mouseOveranElement(getDriver(), compName);
       UIHelper.mouseOveranElement(getDriver(), SERName);

       UIHelper.mouseOveranElement(getDriver(), paydexName);
       UIHelper.mouseOveranElement(getDriver(), SSIName);
       UIHelper.mouseOveranElement(getDriver(), failureScore);
       UIHelper.mouseOveranElement(getDriver(), expand);
       
     
		}
	
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//verify Private Type Column
public void verifyPrivateTypeColumn() {
	try{
		foldTypeInPrivate.waitUntilPresent();
		if (foldTypeInPrivate.isPresent()) {
UIHelper.mouseOveranElement(getDriver(), foldTypeInPrivate);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
}
//Mouse Over In Private Edit Button
public void HoverPrivateEditButton() {
	try{
		privateEditndDele.waitUntilPresent();
		if (privateEditndDele.isPresent()) {
UIHelper.mouseOveranElement(getDriver(),privateEditndDele);
UIHelper.highlightElement(getDriver(),privateEditndDele);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Click Private Folder Name
public void clickprivateFoldName() {
	try{
		privateIstFoldName.waitUntilVisible();
		UIHelper.mouseOverandclickanElement(getDriver(), privateIstFoldName);
        UIHelper.highlightElement(getDriver(), privateIstFoldName);
		}
	
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//Click Public Folder and Sort By Option
public void clickPublicndSortOption() {
	try{
		UIHelper.highlightElement(getDriver(), mainPublicFolderEle);
	       UIHelper.mouseOverandclickanElement(getDriver(), mainPublicFolderEle);
	       UIHelper.mouseOverandclickanElement(getDriver(), clickBookMarkFld);
	       UIHelper.mouseOverandElementdoubleClick(getDriver(), sortingDropdown);
	       UIHelper.highlightElement(getDriver(),sortingDropdown);
	           		
}

catch(Exception e){
	e.printStackTrace();
}
}
//Select No Of Alert In public Folder
public void selectNoOfAlert() {
	try{
		sortingDropdown.waitUntilPresent();
		if (sortingDropdown.isPresent()) {
UIHelper.mouseOveranElement(getDriver(),alertProfileInDropDown);
UIHelper.highlightElement(getDriver(),alertProfileInDropDown);
alertProfileInDropDown.click();
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Sort By:List Of Filter option Is Displayed
public void listOfFilterOptionDisplayed() {
	try{
		UIHelper.highlightElement(getDriver(), sortByFldType);
		UIHelper.mouseOveranElement(getDriver(), sortByFldNameVal);
	     UIHelper.mouseOveranElement(getDriver(), sortByFldNoOfSuppl);
	     UIHelper.mouseOveranElement(getDriver(), sortByFldAlertprflName);
	      UIHelper.mouseOveranElement(getDriver(), sortByFldNoOfusers);
	      
}

catch(Exception e){
	e.printStackTrace();
}
	
}
//Verify Folder Name Order In ascending
public void VerifyFldNameOrderAscending() {
	try{
		sortByFldAlertprflName.waitUntilPresent();
		if (sortByFldAlertprflName.isPresent()) {
UIHelper.mouseOveranElement(getDriver(),sortByFldAlertprflName);
UIHelper.highlightElement(getDriver(),sortByFldAlertprflName);

			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Click On private Folder and sort by Alert Name
public void clickPersonalSortByAlertName() {
	try{
		UIHelper.highlightElement(getDriver(), mainPrivateFolderEle);
	       UIHelper.mouseOverandclickanElement(getDriver(), mainPrivateFolderEle);
	       UIHelper.mouseOverandclickanElement(getDriver(), clickBookMarkFld);
	       UIHelper.mouseOverandElementdoubleClick(getDriver(), sortingDropdown);
	       UIHelper.highlightElement(getDriver(),sortingDropdown);
	           		
}

catch(Exception e){
	e.printStackTrace();
}
}
//Displayed List Icon Blue and Folder Icon gray
public void IsDisplayedListIconBlueAndFolderGray() {
	try{
		   UIHelper.mouseOveranElement(getDriver(), listTabForFolder);
		   UIHelper.highlightElement(getDriver(),listTabForFolder);
	       UIHelper.mouseOveranElement(getDriver(), folderTabForAllFolders);
	       UIHelper.highlightElement(getDriver(),folderTabForAllFolders);           		
}

catch(Exception e){
	e.printStackTrace();
}
	
}
//Expand All Supplier Parent Node
public void expandParantAllsupll() {
	try{
		leftArrowAllSupExpand.waitUntilPresent();
		if (leftArrowAllSupExpand.isPresent()) {
        UIHelper.mouseOverandclickanElement(getDriver(),leftArrowAllSupExpand);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Displayed Sub folder same As Parent In All supplier
public void IsDisplayedSubFldSameAsParent() {
	try{
		allsupplVal.waitUntilVisible();
		UIHelper.mouseOveranElement(getDriver(), allsupplVal);
        UIHelper.highlightElement(getDriver(), allsupplVal);
		}
	
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//Click Public Folder and Click Sort By Option
public void clickPublicAndSortByOption() {
	try{
		UIHelper.highlightElement(getDriver(), mainPublicFolderEle);
	       UIHelper.mouseOverandclickanElement(getDriver(), mainPublicFolderEle);
	       UIHelper.mouseOverandclickanElement(getDriver(), clickBookMarkFld);
	       UIHelper.mouseOverandElementdoubleClick(getDriver(), sortingDropdown);
	       UIHelper.highlightElement(getDriver(),sortingDropdown);
	           		
}

catch(Exception e){
	e.printStackTrace();
}
	
}
//Click Private Folder and Sort By No of Users
public void clicksortBySelectNoOfUser() {
	try{
		UIHelper.highlightElement(getDriver(), mainPrivateFolderEle);
	       UIHelper.mouseOverandclickanElement(getDriver(), mainPrivateFolderEle);
	       UIHelper.mouseOverandclickanElement(getDriver(), clickBookMarkFld);
	       UIHelper.mouseOverandElementdoubleClick(getDriver(), sortingDropdown);
	       UIHelper.highlightElement(getDriver(),sortingDropdown);
	       UIHelper.mouseOverandclickanElement(getDriver(), noOfUsersInDropDown);
	           		
}

catch(Exception e){
	e.printStackTrace();
}
}
//Verify Listed Tabular column
public void verifyDiaplayedTabularColumn() {
	try{
	       UIHelper.mouseOveranElement(getDriver(), compName);
	       UIHelper.mouseOveranElement(getDriver(), SERName);
	       UIHelper.mouseOveranElement(getDriver(), paydexName);
	       UIHelper.mouseOveranElement(getDriver(), SSIName);
	       UIHelper.mouseOveranElement(getDriver(), failureScore);
	       UIHelper.mouseOveranElement(getDriver(), expand);
	      
			}	
		catch(Exception e){
			e.printStackTrace();
		}
	
}
//Verify Folder name All Supplier And No Of Ueser Displayed
public void verifyFldNmaeNoOfFolders() {
	try{
		bookMarkFld.waitUntilPresent();
		if (bookMarkFld.isPresent()) {
        UIHelper.mouseOveranElement(getDriver(),adminFolders);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Displayed Move to delete Icon 
public void IsDisplayedMoveToDeleteIcon() {
	try{
		UIHelper.mouseOveranElement(getDriver(), moveToIcon);
		UIHelper.highlightElement(getDriver(),moveToIcon);
		UIHelper.mouseOveranElement(getDriver(), deleteIcon);
		UIHelper.highlightElement(getDriver(),deleteIcon);
	}catch(Exception e){
		e.printStackTrace();
	}
	
}
//Displayed Print And Export Icon
public void IsDisplayedPrintAndExportIcon() {
	try{
		UIHelper.mouseOveranElement(getDriver(), printIcon);
		UIHelper.highlightElement(getDriver(),printIcon);
		UIHelper.mouseOveranElement(getDriver(), exportIcon);
		UIHelper.highlightElement(getDriver(),exportIcon);
	}catch(Exception e){
		e.printStackTrace();
	}
	
}
//Displayed Company List CheckBox
public void IsDisplayedCompanyListCheckBox() {
	try{
		companyListCheckBox.waitUntilPresent();
		if (companyListCheckBox.isPresent()) {
        UIHelper.mouseOveranElement(getDriver(),companyListCheckBox);
        UIHelper.highlightElement(getDriver(),companyListCheckBox);
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Verify Company List Tabular Column
public void verifycompntListTabColum() {
	try{
		compnyNameList.waitUntilPresent();
		if (compnyNameList.isPresent()) 
        UIHelper.highlightElement(getDriver(),compnyNameList);
			
		
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Click expansion Company name
public void clickExpanssionComapnyName() {
	if(expansionCompanyName.isPresent())
	{
		expansionCompanyName.click();
		UIHelper.waitForPageToLoad(getDriver());
		
	}
	
}
//Displayed Expansion Is Blue
public boolean IsDisplayedExpansionBlue() {
	 if (companyListExpansionBlue.isPresent()) {
         return true;
     } else {
         return false;
     }
	
}
//verify expand section
public String verifyExpandScection() {
	if (compnydatils.isPresent()) {
		
		UIHelper.highlightElement(getDriver(),compnydetai);
        return compnydatils.getText();
      
    }
    return null;
	
	
}
//Verify last updated
public void verifyLastUpdated() {
	try{
		 compnyLastUpdatedate.waitUntilPresent();
		if ( compnyLastUpdatedate.isPresent()) 
        UIHelper.highlightElement(getDriver(), compnyLastUpdatedate);
			
		
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//Verify warning symbol
public boolean verifyWarningSymble() {
	if (warningSymbol.isPresent()) {
        return true;
    } else {
        return false;
    }
	
}
//Click Expansion Button Again
public void clickExpansionAgain() {
	
	try{
		companyListExpansionBlue.waitUntilPresent();
		if (companyListExpansionBlue.isPresent()) {
        UIHelper.mouseOverandclickanElement(getDriver(),companyListExpansionBlue);	
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
}
//Click Company name Sorting Option
public void clickCompnayNameSortingOption() {
	
	if(compnyListSortUpArrow.isPresent())
	{
		compnyListSortUpArrow.click();
		UIHelper.waitForPageToLoad(getDriver());

	}

}

//Displayed Company Name Descending Order
public void IsDisplayedDescendingOrderCompanyName() {
	try
	{
	if(compnyNameList.isPresent())
	{
		
		UIHelper.highlightElement(getDriver(), compnyNameList);
	}
	}
		catch(Exception e){
			e.printStackTrace();
		}

}
//Click Down Arrow Company Name Sorting
public void clickCompnayNameSortingDownArrow() {
	if(compnyListSortDownArrow.isPresent())
	{
		compnyListSortDownArrow.click();
		UIHelper.waitForPageToLoad(getDriver());

	}

	
}
//Displayed Company name List Descending Order
public void IsDisplayedDescendingOrderCompanyNameList() {
	try
	{
	if(compnyNameList.isPresent())
	{
		
		UIHelper.highlightElement(getDriver(), compnyNameList);
	}
	}
		catch(Exception e){
			e.printStackTrace();
		}
	
}
//Click SER Up Arrow
public void clickSERUpArrow() {
	if(compnyListSortUpArrow.isPresent())
	{
		compnyListSortUpArrow.click();
		UIHelper.waitForPageToLoad(getDriver());

	}
	
	
}
//SER should be Descending order
public void SERdescendingOrder() {
	try
	{
	if(SERAsc.isPresent())
	{
		
		UIHelper.highlightElement(getDriver(), SERAsc);
	}
	}
		catch(Exception e){
			e.printStackTrace();
		}
	
	
}
//Click SER Down Arrow
public void ClickSERdownArrow() {
	if(compnyListSortDownArrow.isPresent())
	{
		compnyListSortDownArrow.click();
		UIHelper.waitForPageToLoad(getDriver());

	}

	
}
//Diplayed SER Asc Order
public void IsDisplayedSERAscOrder() {
	try
	{
	if(SERAsc.isPresent())
	{
		
		UIHelper.highlightElement(getDriver(), SERAsc);
	}
	}
		catch(Exception e){
			e.printStackTrace();
		}
	
}
//Click paydex Up Arrow
public void clickPaydexUpArrow() {
	try{
		compnyListSortUpArrow.waitUntilPresent();
		if ( compnyListSortUpArrow.isPresent()) 
       UIHelper.mouseOverandclickanElement(getDriver(),compnyListSortUpArrow);
			
		
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Paydex Desc Order
public void paydexDescOrder() {
	try
	{
	if(SERAsc.isPresent())
	{
		
		UIHelper.highlightElement(getDriver(), SERAsc);
	}
	}
		catch(Exception e){
			e.printStackTrace();
		}
	
}
//click paydex Down Arrow
public void clickpaydexDownArrow() {
	try{
		compnyListSortDownArrow.waitUntilPresent();
		if (compnyListSortDownArrow.isPresent()) 
       UIHelper.mouseOverandclickanElement(getDriver(),compnyListSortDownArrow);	
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//Display paydex asc Order 
public void paydexAscOrder() {
	try
	{
	if(SERAsc.isPresent())
	{
		
		UIHelper.highlightElement(getDriver(), SERAsc);
	}
	}
		catch(Exception e){
			e.printStackTrace();
		}
	
}
//Click on SSI UP Arrow
public void clickOnSSIUpArrow() {
	try{
		compnyListSortUpArrow.waitUntilPresent();
		if ( compnyListSortUpArrow.isPresent()) 
       UIHelper.mouseOverandclickanElement(getDriver(),compnyListSortUpArrow);
			
		
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Display SSI Asc Order
public void SSIdescOrder() {
	try
	{
	if(SERAsc.isPresent())
	{
		
		UIHelper.highlightElement(getDriver(), SERAsc);
	}
	}
		catch(Exception e){
			e.printStackTrace();
		}
	
}
//Click SSI Down Arrow
public void clickSSIdownArrow() {
	try{
		compnyListSortDownArrow.waitUntilPresent();
		if (compnyListSortDownArrow.isPresent()) 
       UIHelper.mouseOverandclickanElement(getDriver(),compnyListSortDownArrow);	
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//Displayed SSI Desc Order
public void SSIAscOrder() {
	try
	{
	if(SERAsc.isPresent())
	{
		
		UIHelper.mouseOveranElement(getDriver(), SERAsc);
	}
	}
		catch(Exception e){
			e.printStackTrace();
		}
	
}
//Click Fallure Score Up arrow
public void clickFallureScoreUParrow() {
	try{
		compnyListSortUpArrow.waitUntilPresent();
		if ( compnyListSortUpArrow.isPresent()) 
       UIHelper.mouseOverandclickanElement(getDriver(),compnyListSortUpArrow);
			
		
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Fallure Score Desc order
public void FallureScoreDescOrder() {
	try
	{
	if(SERAsc.isPresent())
	{
		
		UIHelper.mouseOveranElement(getDriver(), SERAsc);
	}
	}
		catch(Exception e){
			e.printStackTrace();
		}
	
	
}
//Click Fallure Score Down Arrow
public void clickFallureScoreDownArrow() {
	try{
		compnyListSortDownArrow.waitUntilPresent();
		if (compnyListSortDownArrow.isPresent()) 
       UIHelper.mouseOverandclickanElement(getDriver(),compnyListSortDownArrow);	
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Displays Falure Score Asc Order
public void FallureScoreAscOrder() {
	try
	{
	if(SERAsc.isPresent())
	{
		
		UIHelper.highlightElement(getDriver(), SERAsc);
	}
	}
		catch(Exception e){
			e.printStackTrace();
		}
	
}
//Click On Print In Company list page
public void ClickOnPrint() {
	try{
		printIcon.waitUntilPresent();
		if (printIcon.isPresent()) 
       UIHelper.mouseOverandclickanElement(getDriver(),printIcon);
		UIHelper.waitForPageToLoad(getDriver());
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Click oN CSV format
public void ClickOnCSV() {
	try{
		 exportCSVOptionEle.waitUntilPresent();
		if ( exportCSVOptionEle.isPresent()) {
			UIHelper.highlightElement(getDriver(), exportCSVOptionEle);
			 exportCSVOptionEle.click();
			 UIHelper.waitForPageToLoad(getDriver());
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//displayed warning PopUp
public void IsDispalyedWarningPopUP() {
	try{
		csvWarningPopUp.waitUntilPresent();
		if ( csvWarningPopUp.isPresent()) {
			UIHelper.highlightElement(getDriver(),csvWarningPopUp);	
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}

public void varifyUserGotWarningPopUP() {
	try{
		csvWarningPopUp.waitUntilPresent();
		if ( csvWarningPopUp.isPresent()) {
			UIHelper.highlightElement(getDriver(),csvWarningPopUp);	
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//verify slider Color 
public void verifySliderColr() {
	try{
		indicatorColrImg.waitUntilPresent();
		if (indicatorColrImg.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),indicatorColrImg);
			UIHelper.highlightElement(getDriver(),indicatorColrImg);	
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//REd Color Slider bar in left hand side
public void displayedRedColrSlider() {
	try{
		indicatorColrRed.waitUntilPresent();
		if (indicatorColrRed.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),indicatorColrRed);
			UIHelper.highlightElement(getDriver(),indicatorColrRed);	
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Displayed Orange Clor slider
public void displayedOrangeColrSlider() {
	try{
		indicatorColrOrange.waitUntilPresent();
		if (indicatorColrOrange.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),indicatorColrOrange);
			UIHelper.highlightElement(getDriver(),indicatorColrOrange);	
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Displayed Green colr Slider
public void displayedGreenColrSlider() {
	
	try{
		indicatorColrGreen.waitUntilPresent();
		if (indicatorColrGreen.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),indicatorColrGreen);
			UIHelper.highlightElement(getDriver(),indicatorColrGreen);	
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Verify scale Shade
public void verifyScaleShade() {
	try{
		indicatorColrImg.waitUntilPresent();
		if (indicatorColrImg.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),indicatorColrImg);
			UIHelper.highlightElement(getDriver(),indicatorColrImg);	
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//verify scale Red Orange Green
public void verifyScaleShadeRedOrangeGreen() {
	try{
		indicatorColrImg.waitUntilPresent();
		if (indicatorColrImg.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),indicatorColrImg);
			UIHelper.highlightElement(getDriver(),indicatorColrImg);
			UIHelper.mouseOveranElement(getDriver(),indicatorColrRed);
			UIHelper.highlightElement(getDriver(),indicatorColrRed);
			UIHelper.mouseOveranElement(getDriver(),indicatorColrOrange);
			UIHelper.highlightElement(getDriver(),indicatorColrOrange);
			UIHelper.mouseOveranElement(getDriver(),indicatorColrGreen);
			UIHelper.highlightElement(getDriver(),indicatorColrGreen);	
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//Verify Company profile page pagination
public void verifyCompanyprofilePagePagination() {
	try{
		CompnayprofilePagePagination.waitUntilPresent();
		if (CompnayprofilePagePagination.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),CompnayprofilePagePagination);
			UIHelper.highlightElement(getDriver(),CompnayprofilePagePagination);	
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//verify indicator slider Of Ser
public void verifyIndicatorSliderOfSer() {
	try{
		indicatorColrImg.waitUntilPresent();
		if (indicatorColrImg.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),indicatorColrImg);
			
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Verify scale 9 to 1
public void verifyScale9to1() {
	try{
		scale9to1.waitUntilPresent();
		if (scale9to1.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),scale9to1);
		
	}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//verify Inside circle Displayed
public void verifyScaleDispalyedInsideCircle() {
	try{
		
			UIHelper.mouseOveranElement(getDriver(),indicatorColrImg);
			UIHelper.highlightElement(getDriver(),indicatorColrImg);
			UIHelper.mouseOveranElement(getDriver(),indicatorColrGreen);
			UIHelper.highlightElement(getDriver(),indicatorColrGreen);	
	
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Verify Indicator slider of paydex
public void verifyIndicatorSliderOfPaydex() {
	try{
		paydexSlider.waitUntilPresent();
		if (paydexSlider.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),paydexSlider);
			
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
	
}
//scale start form 0 to 100
public void scale0to100() {
	try{
		scale0to100.waitUntilPresent();
		if (scale0to100.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),scale0to100);
		
	}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Verify SSI slider
public void verifySSislider() {
	try{
		SSIslider.waitUntilPresent();
		if (SSIslider.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),SSIslider);
			
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//verify SSI 10 to 0
public void verifyScale10to0() {
	try{
		SSIscale10to0.waitUntilPresent();
		if (SSIscale10to0.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),SSIscale10to0);
		
	}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//verify Indicator slider Fallure score
public void verifysliderFallureScore() {
	try{
		FallureScoreslider.waitUntilPresent();
		if (FallureScoreslider.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),FallureScoreslider);
			
			
		}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Verify FSS 0 to 100
public void scale0to100FSS() {
	try{
		FSSscale1to100.waitUntilPresent();
		if (FSSscale1to100.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),FSSscale1to100);
		
	}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//Verify Move to Option Is Disabled
public void verifyMoveToOptionDisabled() {
	try{
		moveToIcon.waitUntilPresent();
		if (moveToIcon.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),moveToIcon);
			UIHelper.highlightElement(getDriver(),moveToIcon);	
	}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//select supplier Check Box
public void selectSupplierCheckBox() {
	
	try{
		compnayPageSupplCheckBox.waitUntilPresent();
		if (compnayPageSupplCheckBox.isPresent()) {
			UIHelper.mouseOverandclickanElement(getDriver(),compnayPageSupplCheckBox);
			UIHelper.highlightElement(getDriver(),compnayPageSupplCheckBox);	
	}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//Click on Move To Icon
public void ClicOnMoveToIcon() {
	
	try{
		moveToButton.waitUntilPresent();
		if (moveToButton.isPresent()) {
			UIHelper.mouseOverandclickanElement(getDriver(),moveToButton);
			UIHelper.highlightElement(getDriver(),moveToButton);	
	}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//compare the folder name to private fld name
public String compareListOFFldRightAccess() throws Exception {
	String folderVal= null;
	try {
		Ajtestval.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), Ajtestval);
		folderVal = Ajtestval.getText().toString().trim();
		System.out.println("yourShareValue: "+folderVal);
	} catch (Exception e) {

	}
	return folderVal; 
	
	
}
//select company name move to private folder
public void selectmovetoOptionFolder2(String folder2) {
	try{
		moveToButton.waitUntilPresent();
		if (moveToButton.isPresent()) {
			UIHelper.mouseOverandclickanElement(getDriver(),moveToButton);
			UIHelper.highlightElement(getDriver(),moveToButton);
			String fld=moveToPrivate.getText().trim();
			System.out.println("privateFldValue: "+fld);
	}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//click on move to folder
public void clickMoveToOptionFolder2(String folder2) {
	try{
		moveToPrivate.waitUntilPresent();
		if (moveToPrivate.isPresent()) {
			UIHelper.mouseOverandclickanElement(getDriver(),moveToPrivate);
			
	}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//Click Private Folder Name
public void clickPrivateFldName(String foldername) {
	try{
		privateFld.waitUntilPresent();
		if (privateFld.isPresent()) {
			UIHelper.mouseOverandclickanElement(getDriver(),privateFld);
			UIHelper.highlightElement(getDriver(),privateFld);
			
	}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//select Fld Private Type
public void selectFldPrivateType() {
	try{
		newFolderPrivate.waitUntilPresent();
		if (newFolderPrivate.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),newFolderPrivate);
			UIHelper.highlightElement(getDriver(),newFolderPrivate);
			
	}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
	
	
}
//Enter Fld name and click on Save
public void enterFoldNmae(String foldername) {
	try {
		folderNametextFiled.waitUntilPresent();
		if (folderNametextFiled.isPresent() && foldername != null && !foldername.isEmpty()) {
			folderNametextFiled.type(foldername);
			UIHelper.highlightElement(getDriver(), folderNametextFiled);
			UIHelper.mouseOverandclickanElement(getDriver(), saveNF);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//Display error msg
public void errorMsgDisplayed() {
	try {
		sharedFolderErrmsg.waitUntilPresent();
		if (sharedFolderErrmsg.isPresent() ) {
			
			UIHelper.highlightElement(getDriver(), sharedFolderErrmsg);
			UIHelper.mouseOveranElement(getDriver(), sharedFolderErrmsg);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//Enter Fold name in public and click on save
public void enterFoldNmaeInPublic(String foldername1) {
	try {
	folderNametextFiled.waitUntilPresent();
	if (folderNametextFiled.isPresent() && foldername1 != null && !foldername1.isEmpty()) {
		folderNametextFiled.type(foldername1);
		UIHelper.highlightElement(getDriver(), folderNametextFiled);
			UIHelper.mouseOverandclickanElement(getDriver(), saveNF);
			UIHelper.waitForPageToLoad(getDriver());
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//Enter Fld Name and click on save
public void enterFoldNmaeInAdmin(String foldername2) {
	try {
	folderNametextFiled.waitUntilPresent();
	if (folderNametextFiled.isPresent() && foldername2 != null && !foldername2.isEmpty()) {
		folderNametextFiled.type(foldername2);
		UIHelper.highlightElement(getDriver(), folderNametextFiled);
			UIHelper.mouseOverandclickanElement(getDriver(), saveNF);
			UIHelper.waitForPageToLoad(getDriver());
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	
}
//select public folder in new folder
public void selectFldPublicType() {
	try{
		newFolderPublic.waitUntilPresent();
		if (newFolderPublic.isPresent()) {
			UIHelper.mouseOveranElement(getDriver(),newFolderPublic);
			UIHelper.highlightElement(getDriver(),newFolderPublic);
			
	}
	}
		
	catch(Exception e){
		e.printStackTrace();
	}
	
	
}
//Enter Folder name in New Folder
public void enterFldNameNewFld(String foldername) {
	try {
		folderNametextFiled.waitUntilPresent();
		if (folderNametextFiled.isPresent() && foldername != null && !foldername.isEmpty()) {
			folderNametextFiled.type(foldername);
			UIHelper.highlightElement(getDriver(), folderNametextFiled);
			
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//Add supplier Enter Duns Number
public void enterDunsNumberAddSupplier(String enterDunsNumber) {
	try {
		addSupplierTextBox.waitUntilPresent();
		if (addSupplierTextBox.isPresent() && enterDunsNumber != null && !enterDunsNumber.isEmpty()) {
			addSupplierTextBox.type(enterDunsNumber);
			UIHelper.mouseOverandclickanElement(getDriver(), btnSave);
			UIHelper.waitForPageToLoad(getDriver());
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//error msg displayed Invalid Duns
public void errorMsgDisplayedInvalidDuns() {
	try {
		sharedFolderErrmsg.waitUntilPresent();
		if (sharedFolderErrmsg.isPresent() ) {
			
			UIHelper.highlightElement(getDriver(), sharedFolderErrmsg);
			UIHelper.mouseOveranElement(getDriver(), sharedFolderErrmsg);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//Add supplier some special char duns
public void enterDunsNumberAddSuppl(String enterDunsNumber1) {
	try {
		addSupplierTextBox.waitUntilPresent();
		if (addSupplierTextBox.isPresent() && enterDunsNumber1 != null && !enterDunsNumber1.isEmpty()) {
			addSupplierTextBox.type(enterDunsNumber1);
			UIHelper.mouseOverandclickanElement(getDriver(), btnSave);
			UIHelper.waitForPageToLoad(getDriver());
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//verify watchilist in domestic
public void verifyDomesticWatchList() {
	try {
		domesticWF.waitUntilPresent();
		if (domesticWF.isPresent() ) {
			
			UIHelper.highlightElement(getDriver(), domesticWF);
			UIHelper.mouseOveranElement(getDriver(), domesticWF);
			UIHelper.mouseOveranElement(getDriver(), domesticWFBar);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//verify domestic max limit
public void verifyDomesticWatchListMaxLimit() {
	try {
		domesticWF.waitUntilPresent();
		if (domesticWF.isPresent() ) {
			
			UIHelper.highlightElement(getDriver(), domesticWFMaxLimit);
			UIHelper.mouseOveranElement(getDriver(), domesticWFMaxLimit);
		
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//verify inter watchList Folder
public void verifyInternationalWatchList() {
	try {
		interWF.waitUntilPresent();
		if (interWF.isPresent() ) {
			
			UIHelper.highlightElement(getDriver(), interWF);
			UIHelper.mouseOveranElement(getDriver(), interWFBar);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//verify Inter Max Limit
public void verifyInterWatchListMaxLimit() {
	try {
		interWF.waitUntilPresent();
		if (interWF.isPresent() ) {
			
			UIHelper.highlightElement(getDriver(), interWFMaxLimit);
			UIHelper.mouseOveranElement(getDriver(), interWFMaxLimit);
		
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//Enter Duns Number In Wf Alert Profile
public void enterDunsNumberAddSuppWF(String enterDunsNumber) {
	try {
		EditAddSupplier.waitUntilPresent();
		if (EditAddSupplier.isPresent() && enterDunsNumber != null && !enterDunsNumber.isEmpty()) {
			EditAddSupplier.type(enterDunsNumber);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//Assign alert profile Watchlist folder
public void asignAlertWatchlist() {
	try{
		alertProfileTab.waitUntilPresent();
		if (alertProfileTab.isPresent()) {
			UIHelper.highlightElement(getDriver(), alertProfileTab);
	    UIHelper.mouseOverandclickanElement(getDriver(), alertProfileTab);
	    UIHelper.waitForPageToLoad(getDriver());
	    UIHelper.mouseOveranElement(getDriver(), alertProfilFld);
	    UIHelper.mouseOveranElement(getDriver(), alertProfilFlder);
		
		}
	}
	
	catch(Exception e){
		e.printStackTrace();
	}
	
}
//click Alert Inbox
public void clickAlertInbox() {
	try {
		alertInbox.waitUntilPresent();
		if (alertInbox.isPresent() ) {
			
			UIHelper.highlightElement(getDriver(), alertInbox);
			UIHelper.mouseOverandclickanElement(getDriver(), alertInbox);
			UIHelper.waitForPageToLoad(getDriver());
		
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//Click Folder Name and asiign profile
public void selectFldAssignPrfl(String foldername) {
	
	try {
		UIHelper.highlightElement(getDriver(), public07Edit);
			UIHelper.mouseOverandclickanElement(getDriver(), public07Edit);
			UIHelper.highlightElement(getDriver(), public07Edit);
			UIHelper.mouseOverandclickanElement(getDriver(), editDropdownProfiledownArrow);
			UIHelper.mouseOverandclickanElement(getDriver(), selectDPT);
			
		
		
		
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//click private folder
public void clickpublFld() {
	try {
		UIHelper.highlightElement(getDriver(),  mainPublicFolderEle);
			UIHelper.mouseOverandclickanElement(getDriver(), mainPublicFolderEle);
			
			
		
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
//displayed delete button
public void IDisplayedDeletpublFld() {
	try {
		UIHelper.highlightElement(getDriver(),  publDelt);
			UIHelper.mouseOverandclickanElement(getDriver(),publDelt);
			
			
		
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	
}
//click on alert Tab
public void ClickOnalertTab() {
	try {
		UIHelper.highlightElement(getDriver(),  alertTab);
			UIHelper.mouseOverandclickanElement(getDriver(),alertTab);
			
			
		
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
}

























