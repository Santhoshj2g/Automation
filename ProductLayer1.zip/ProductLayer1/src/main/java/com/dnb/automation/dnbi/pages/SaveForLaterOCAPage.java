package com.dnb.automation.dnbi.pages;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * AdminPage.java - This class contains all functionalities of Admin Tab
 * 
 * @author Vamsi Krishna NV
 * @version 1.0
 ***********************************************************************************************/
public class SaveForLaterOCAPage extends PageObject {

    

	

	@FindBy(xpath = "//*[@class='tab_cnt']//li/a[contains(.,'All Applications')]")
    private WebElementFacade allApplicationsTab;
	
	@FindBy(xpath = "//*[@class='dd_inboxL']//li/span[contains(.,'Saved Applications')]")
    private WebElementFacade savedApplicationsLabel;
	
	@FindBy(xpath = "//*[@class='dd_inboxL']//li/span[contains(.,'Saved Applications')]//following-sibling::div[@class='node_image']//span[@class='circle_bg_middle']")
    private WebElementFacade savedApplicationsCount;
	
	@FindBy(xpath = "//*[@class='outerDiv']/p/input[@value='Save for Later']")
    private WebElementFacade saveForLaterButton;
	
	@FindBy(xpath = "//*[@id='contentarea']//table//*[@class='comcopy']//b")
    private WebElementFacade SaveApplicationID;
	
	@FindBy(xpath = "//*[@id='page_title']//h2[contains(.,'Confirm Save Application')]")
    private WebElementFacade confirmSaveApplicationHeader;
	
	@FindBy(xpath = "//body//*[@class='container']//li//input[@value='Save For later']")
    private WebElementFacade externalSaveForLater;
	
	@FindBy(xpath = "//*[@id='page_titleNew']//strong[contains(.,'Application ID')]//ancestor::div[1]")
    private WebElementFacade externalAppID;
	
	@FindBy(xpath = "//*[@id='page_titleNew']//strong[contains(.,'E-Mail ID')]//ancestor::div[1]")
    private WebElementFacade externalEmailAddress;
	
	@FindBy(xpath = "//*[@id='page_titleNew']//strong[contains(.,'Application ID')]//ancestor::div[1]")
    private WebElementFacade externalAppIDLabel;
	
	@FindBy(xpath = "//*[@id='page_titleNew']//strong[contains(.,'E-Mail ID')]//ancestor::div[1]")
    private WebElementFacade externalEmailAddressLabel;
	
	@FindBy(xpath = "//*[@id='guestLogin']//*[@class='cw_ul_login']//*[contains(.,'Application ID')]//following-sibling::td[1]//input[@type='text']")
    private WebElementFacade externalAppIDinput;
	
	@FindBy(xpath = "//*[@id='guestLogin']//*[@class='cw_ul_login']//*[contains(.,'Email Address')]//following-sibling::td[1]//input[@type='text']")
    private WebElementFacade externalEmailAddressinput;
	
	@FindBy(xpath = "//*[@id='guestLogin']//*[@class='cw_ul_login']//input[@value='Continue Application']")
    private WebElementFacade externalContinueApplicationBtn;
	
	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='clear']//table//tbody//tr//a[contains(@href,'javascript:show')]")
    private WebElementFacade searchResultsappidEle;
	
	
	
	
	
	String internalTextField;
	String internalListField;
	String textvalue;
	String listvalue;
	static long savedAppCountBefore;
	
	
	public static long getSavedAppCountBefore() {
		return savedAppCountBefore;
	}

	long savedAppCountAfter;
	
	public long getSavedAppCountAfter() {
		return savedAppCountAfter;
	}
	
	
	String savedApplicationsLabelxpath="//*[@class='dd_inboxL']//li/span[contains(.,'Saved Applications')]";
	String confirmSaveApplicationHeaderXpath="//*[@id='page_title']//h2[contains(.,'Confirm Save Application')]";
    String appidXpath="//*[@id='page_titleNew']//strong[contains(.,'Application ID')]//ancestor::div[1]";
    String applHeader="//*[@class='container']//*[@class='cfa-report-content']//h3";
    public static boolean verifyObjectPresent(WebDriver driver,String elementxpath) {

	    try {

	    	driver.findElement(By.xpath(elementxpath));

	    	return true;

	    } catch (Exception e) { 

	    	return false;

	    }

	}
	public void click_All_Application_Tab(){
		try{
			if(allApplicationsTab.isVisible()){
				UIHelper.highlightElement(getDriver(), allApplicationsTab);
				allApplicationsTab.click();
				
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void get_Saved_Applications_Count_Before(){
		try{
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), savedApplicationsLabelxpath);
			UIHelper.waitForPageToLoad(getDriver());
			if(savedApplicationsLabel.isVisible()){
				UIHelper.mouseOveranElement(getDriver(), savedApplicationsLabel);
				UIHelper.highlightElement(getDriver(), savedApplicationsLabel);
				 savedAppCountBefore=Long.parseLong(savedApplicationsCount.getText().trim());
				System.out.println("saved Applicatin count before-----------  "+getSavedAppCountBefore());
				
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void get_Saved_Applications_Count_After(){
		try{
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), savedApplicationsLabelxpath);
			UIHelper.waitForPageToLoad(getDriver());
			if(savedApplicationsLabel.isVisible()){
				UIHelper.mouseOveranElement(getDriver(), savedApplicationsLabel);
				UIHelper.highlightElement(getDriver(), savedApplicationsLabel);
				savedAppCountAfter=Long.parseLong(savedApplicationsCount.getText().trim());
				System.out.println("saved Applicatin count after-----------  "+savedAppCountAfter);
				
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void click_Save_For_Later_Btn(){
		try{
			
				UIHelper.highlightElement(getDriver(), saveForLaterButton);
				saveForLaterButton.click();
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), confirmSaveApplicationHeaderXpath);
			
		
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public boolean verify_Confirmation_page_Has_Displayed(){
		
			if(confirmSaveApplicationHeader.isVisible()){
				UIHelper.highlightElement(getDriver(), confirmSaveApplicationHeader);
				return true;
				}else{
					return false;
					
				}
			}
		public void Save_Application_ID(String FileName) throws Exception{
			try{
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), confirmSaveApplicationHeaderXpath);
			
				if(confirmSaveApplicationHeader.isVisible()){
					
					UIHelper.highlightElement(getDriver(), SaveApplicationID);
					String sApplicationID=SaveApplicationID.getText().trim();
					
						String filePath1 = System.getProperty("user.dir");
						String mypath=filePath1.replace(":", ":\\");
						String filePath = mypath+FileName;
						
						 // String filePath = System.getProperty("user.dir")+"\\src\\test\\resources\\OCA\\applicationID.txt";
					       // FileWriter fstreamWrite = new FileWriter(filePath, true); //-- it will not over write
					         FileWriter fstreamWrite = new FileWriter(filePath, false); //-- it will  over write
					         BufferedWriter out = new BufferedWriter(fstreamWrite);
					         out.write(sApplicationID);
					         out.write("\r\n");
					         out.close();
					         fstreamWrite.close();}
			
			}catch(Exception e){
				e.printStackTrace();
			}
	}
		public String internal_Verify_Data_in_Text_Fields(String xlSectionName,
				String xlFieldName) {
			
		try{
			String internalFieldName="//*[@class='outerDiv']//*[@class='frmSecEdit']//h3[contains(.,'"
					+ xlSectionName
					+ "')]//ancestor::div[1]//tbody//tr//td[contains(.,'"
					+ xlFieldName
					+ "')]//following-sibling::td[contains(@class, 'frmField')]//input[contains(@class, 'regular')]";

			if (verifyObjectPresent(getDriver(),internalFieldName)) {

				WebElementFacade textfield = find(By.xpath(internalFieldName));
				internalTextField=textfield.getAttribute("value").trim();
				
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return internalTextField;
		}
		public String internal_Verify_Data_in_List_Fields(String xlSectionName, String xlFieldName) {
			
			
		try{
			String internalFieldName="//*[@class='outerDiv']//*[@class='frmSecEdit']//h3[contains(.,'"
									+ xlSectionName
									+ "')]//ancestor::div[1]//tbody//tr//td[contains(.,'"
									+ xlFieldName
									+ "')]//following-sibling::td[contains(@class, 'frmField')]//select";

			if (verifyObjectPresent(getDriver(),internalFieldName)) {

				WebElementFacade listfield = find(By.xpath(internalFieldName));
				internalListField=listfield.getSelectedVisibleTextValue().toString().trim();
				
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return internalListField;
		}

		public void external_Save_For_Later_Btn(){
			try{
				
				String findsave = "//body//*[@class='container']//li//input[@value='Save For later']";
				WebElement element = getDriver().findElement(By.xpath(findsave));
				waitFor(2000).milliseconds();
				((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
				waitFor(1000).milliseconds();	
				externalSaveForLater.click();
					UIHelper.waitForVisibilityOfEleByXpath(getDriver(), appidXpath);
				
			
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		public boolean verify_AppID_page_Has_Displayed(){
			
				if(externalAppIDLabel.isVisible()){
					UIHelper.highlightElement(getDriver(), externalAppIDLabel);
					return true;
					}else{
						return false;
						
					}
		}
		
		public void external_Save_Application_ID(String FileName) throws Exception{
			try{
				
			
				if(externalAppIDLabel.isVisible()){
					String sApplicationID1=externalAppID.getText().trim();
					String [] sApplicationID2=sApplicationID1.split(":");
					String sApplicationID=(sApplicationID2[1].replace("E-Mail ID", "")).trim();
					
						String filePath1 = System.getProperty("user.dir");
						String mypath=filePath1.replace(":", ":\\");
						String filePath = mypath+FileName;
						
						 // String filePath = System.getProperty("user.dir")+"\\src\\test\\resources\\OCA\\applicationID.txt";
					       // FileWriter fstreamWrite = new FileWriter(filePath, true); //-- it will not over write
					         FileWriter fstreamWrite = new FileWriter(filePath, false); //-- it will  over write
					         BufferedWriter out = new BufferedWriter(fstreamWrite);
					         out.write(sApplicationID);
					         out.write("\r\n");
					         out.close();
					         fstreamWrite.close();}
			
			}catch(Exception e){
				e.printStackTrace();
			}
	}
		public void external_Save_Email_ID(String FileName) throws Exception{
			try{
				
			
				if(externalEmailAddressLabel.isVisible()){
					UIHelper.highlightElement(getDriver(), externalEmailAddressLabel);
					String sApplicationID1=externalEmailAddress.getText().trim();
					String sApplicationID=(sApplicationID1.replace("E-Mail ID:", "")).trim();
					
						String filePath1 = System.getProperty("user.dir");
						String mypath=filePath1.replace(":", ":\\");
						String filePath = mypath+FileName;
						
						 // String filePath = System.getProperty("user.dir")+"\\src\\test\\resources\\OCA\\applicationID.txt";
					       // FileWriter fstreamWrite = new FileWriter(filePath, true); //-- it will not over write
					         FileWriter fstreamWrite = new FileWriter(filePath, false); //-- it will  over write
					         BufferedWriter out = new BufferedWriter(fstreamWrite);
					         out.write(sApplicationID);
					         out.write("\r\n");
					         out.close();
					         fstreamWrite.close();}
			
			}catch(Exception e){
				e.printStackTrace();
			}
	}
		public void external_Enter_Application_ID(String FileName) throws Exception{
			try{
				String filePath1 = System.getProperty("user.dir");
				String mypath=filePath1.replace(":", ":\\");
				String filePath = mypath+FileName;
				
				
				BufferedReader br = new BufferedReader(new FileReader(filePath));
				    String line = br.readLine();
				    br.close();
				    
				if(externalAppIDinput.isVisible()){
					UIHelper.highlightElement(getDriver(), externalAppIDinput);
					externalAppIDinput.sendKeys(line);
					}
			
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		public void external_Enter_Email_Address(String FileName) throws Exception{
			try{
				String filePath1 = System.getProperty("user.dir");
				String mypath=filePath1.replace(":", ":\\");
				String filePath = mypath+FileName;
				
				
				BufferedReader br = new BufferedReader(new FileReader(filePath));
				    String line = br.readLine();
				    br.close();
				    
				if(externalEmailAddressinput.isVisible()){
					UIHelper.highlightElement(getDriver(), externalEmailAddressinput);
					externalEmailAddressinput.sendKeys(line);
					}
			
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		public void external_Continue_Application_Btn(){
			try{
				if(externalContinueApplicationBtn.isVisible()){
					UIHelper.highlightElement(getDriver(), externalContinueApplicationBtn);
					externalContinueApplicationBtn.click();
					UIHelper.waitForVisibilityOfEleByXpath(getDriver(), applHeader);
					
					}
			
			}catch(Exception e){
				
				e.printStackTrace();
			}
		}
		public String external_Verify_Data_in_Text_Fields(String xlSectionName,
				String xlFieldName) {
			
		try{
			String internalFieldName="//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
									+ xlSectionName
									+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
									+ xlFieldName + "')]//following-sibling::td[contains(@class, 'frmField')]//input[contains(@class, 'regular')]";

			if (verifyObjectPresent(getDriver(),internalFieldName)) {

				WebElementFacade textfield = find(By.xpath(internalFieldName));
				UIHelper.highlightElement(getDriver(), textfield);
				textvalue=textfield.getAttribute("value").trim();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("field value%%%%%%%%%%%%%%%%%%%%%   "+textvalue);
		return textvalue;
		}
		public String external_Verify_Data_in_List_Fields(String xlSectionName, String xlFieldName) {
			
		try{
			String internalFieldName="//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
									+ xlSectionName
									+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
									+ xlFieldName + "')]//following-sibling::td[contains(@class, 'frmField')]//select";

			if (verifyObjectPresent(getDriver(),internalFieldName)) {

				WebElementFacade listfield = find(By.xpath(internalFieldName));
				UIHelper.highlightElement(getDriver(), listfield);
				listvalue=listfield.getSelectedVisibleTextValue().toString().trim();
				
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("List value**********************   "+listvalue);
		return listvalue;
		}
		
		public void pullSavedApplicationsFromSearchResults() {
		try{
			if (searchResultsappidEle.isPresent()) {
				
				searchResultsappidEle.click();
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}

		}
	
	
}