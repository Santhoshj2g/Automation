package com.dnb.automation.dnbcom.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

/********************************************************************************************************************************
 * ReportPage.java - Program consists of the following actions 1. Verifying D&B
 * Risk Indicator in the Identification & Summary section of the report with
 * Expected D&B Risk Indicator 2. Verifying D&B Failure Score in the
 * Identification & Summary section of the report with Expected D&B Failure
 * Score 3. Verifying D&B Credit Limit in the Identification & Summary section
 * of the report with Expected D&B Credit Limit 4. Verifying D&B Rating in the
 * D&B Risk Assessment section of the report with Expected D&B Rating 5.
 * Verifying D&B Financial Strength in the D&B Risk Assessment section of the
 * report with Expected D&B Financial Strength 6. Verifying D&B Risk Indicator
 * (1-4) in the D&B Risk Assessment section of the report with Expected D&B Risk
 * Indicator (1-4) 7. Verifying D&B Credit Limit in the D&B Risk Assessment
 * section of the report with Expected D&B Credit Limit 8. Verifying D&B Failure
 * Score in the D&B Risk Assessment section of the report with Expected D&B
 * Failure Score
 *
 * @author Kumaran Balasubramaniam
 ********************************************************************************************************************************/

public class ReportPage extends PageObject {
    // Locator for report, New Search button and Search page element

    @FindBy(xpath = "html/body/pre")
    private WebElementFacade Report;

    // To check report availability

    public boolean hasReport() {
        if (Report.isPresent()) {
            return true;
        } else {
            return false;
        }
    }

    // To check report has section Identification & Summary and D&B Risk
    // Assessment

    public boolean hasIdentificationSummary() {
        try {
            getIdentificationSummary();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean hasRiskAssesment() {
        try {
            getRiskAssesment();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // To Verify the that actual value is equal to the expected value for each
    // element

    public boolean verifyIdSummary_RiskIndicator(String IdSummary_RiskIndicator) {
        if (hasIdentificationSummary()) {
            String Actual = getIdentificationSummary();
            if (Actual
                    .toLowerCase()
                    .replaceAll("\\s", "")
                    .contains(
                            ("D&B Risk Indicator        " + IdSummary_RiskIndicator)
                                    .toLowerCase().replaceAll("\\s", ""))) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public boolean verifyIdSummary_FailureScore(String IdSummary_FailureScore) {
        if (hasIdentificationSummary()) {
            String Actual = getIdentificationSummary();
            if (Actual
                    .toLowerCase()
                    .replaceAll("\\s", "")
                    .contains(
                            ("D&B Failure Score         " + IdSummary_FailureScore)
                                    .toLowerCase().replaceAll("\\s", ""))) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public boolean verifyIdSummary_CreditLimit(String IdSummary_CreditLimit) {
        if (hasIdentificationSummary()) {
            String Actual = getIdentificationSummary();
            if (Actual
                    .toLowerCase()
                    .replaceAll("\\s", "")
                    .contains(
                            ("D&B Credit Limit          " + IdSummary_CreditLimit)
                                    .toLowerCase().replaceAll("\\s", ""))) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public boolean verifyRiskAssesment_Rating(String RiskAssesment_Rating) {
        if (hasRiskAssesment()) {
            String Actual = getRiskAssesment();
            if (Actual
                    .toLowerCase()
                    .replaceAll("\\s", "")
                    .contains(
                            ("D&B Rating                     " + RiskAssesment_Rating)
                                    .toLowerCase().replaceAll("\\s", ""))) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public boolean verifyRiskAssesment_FinancialStrength(
            String RiskAssesment_FinancialStrength) {
        if (hasRiskAssesment()) {
            String Actual = getRiskAssesment();
            if (Actual
                    .toLowerCase()
                    .replaceAll("\\s", "")
                    .contains(
                            ("D&B Financial Strength         " + RiskAssesment_FinancialStrength)
                                    .toLowerCase().replaceAll("\\s", ""))) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public boolean verifyRiskAssesment_RiskIndicator(
            String RiskAssesment_RiskIndicator) {
        if (hasRiskAssesment()) {
            String Actual = getRiskAssesment();
            if (Actual
                    .toLowerCase()
                    .replaceAll("\\s", "")
                    .contains(
                            ("D&B Risk Indicator (1-4)       " + RiskAssesment_RiskIndicator)
                                    .toLowerCase().replaceAll("\\s", ""))) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public boolean verifyRiskAssesment_CreditLimit(
            String RiskAssesment_CreditLimit) {
        if (hasRiskAssesment()) {
            String Actual = getRiskAssesment();
            if (Actual
                    .toLowerCase()
                    .replaceAll("\\s", "")
                    .contains(
                            ("D&B Credit Limit               " + RiskAssesment_CreditLimit)
                                    .toLowerCase().replaceAll("\\s", ""))) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public boolean verifyRiskAssesment_FailureScore(
            String RiskAssesment_FailureScore) {
        if (hasRiskAssesment()) {
            String Actual = getRiskAssesment();
            if (Actual
                    .toLowerCase()
                    .replaceAll("\\s", "")
                    .contains(
                            ("D&B Failure Score              " + RiskAssesment_FailureScore)
                                    .toLowerCase().replaceAll("\\s", ""))) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    // To obtain value of each element by extracting from the report

    private String getIdentificationSummary() {
        return extractBetween("Identification & Summary",
                "D&B Risk Assessment", getReport());
    }

    private String getRiskAssesment() {
        return extractBetween("D&B Risk Assessment", "D&B Rating & Score",
                getReport());
    }

    // To Obtain the report as string

    private String getReport() {
        String textReport;
        textReport = Report.getText().toString().trim();
        return textReport;
    }

    // To Extract a String between to strings

    private String extractBetween(String str1, String str2, String mainString) {
        String ExtractedValue;
        ExtractedValue = mainString.substring(
                mainString.indexOf(str1) + str1.length(),
                mainString.lastIndexOf(str2));
        return ExtractedValue;
    }

}
