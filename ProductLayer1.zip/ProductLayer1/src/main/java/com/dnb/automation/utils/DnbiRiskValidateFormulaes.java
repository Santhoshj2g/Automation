package com.dnb.automation.utils;


import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.openqa.selenium.WebDriver;

import net.serenitybdd.core.pages.PageObject;
	public class DnbiRiskValidateFormulaes {
		
		public static String replaceByValue(String input,String ...args){
			int arrayLength=args.length;
			String replacedFormula=null;
			for(int counter=0;counter<arrayLength;counter=counter+2){
				String value=args[counter+1];
				String key=args[counter];
				replacedFormula = input.replaceAll(key,value);
			}
			return replacedFormula;
		}
		
		public static String evaluate(String exprSting, String dataType)
				throws ScriptException {
			
			String formulaProefix = "Case when";
			String formulaPostfix = "THEN";
			String formula = null;
			if (exprSting.contains(formulaPostfix)) {
				formula = exprSting.substring(exprSting.indexOf(formulaProefix)
						+ formulaProefix.length(),
						exprSting.indexOf(formulaPostfix));
			} else
				formula = exprSting;
			String conditionPostfix = "END";
			String elseExprString = "ELSE ";
			String trueExpr = null;
			String falseExpr = null;
			if (exprSting.contains(elseExprString)) {
				trueExpr = exprSting.substring(exprSting.indexOf(formulaPostfix)
						+ formulaPostfix.length(),
						exprSting.indexOf(elseExprString));
				falseExpr = exprSting.substring(exprSting.indexOf(elseExprString)
						+ elseExprString.length(),
						exprSting.indexOf(conditionPostfix));
			} else if (exprSting.contains(conditionPostfix))
				trueExpr = exprSting.substring(exprSting.indexOf(formulaPostfix)
						+ formulaPostfix.length(),
						exprSting.indexOf(conditionPostfix));
			ScriptEngineManager mgr = new ScriptEngineManager();
			ScriptEngine engine = mgr.getEngineByName("JavaScript");
			boolean eval = false;
			switch (dataType.toLowerCase()) {
			case "true/false":
				eval = (boolean) engine.eval(formula);
				if (eval)
				{
//					System.out.println(trueExpr);
					return trueExpr;
				}
				else
				{
//					System.out.println(falseExpr);
					return falseExpr;
				}				
			case "date":
				eval = (boolean) engine.eval(formula);
				String startDate = "('";
				String startDateFormat = "','";
				String date = null;
				if (eval)
					date = trueExpr
							.substring(
									trueExpr.indexOf(startDate)
											+ startDate.length(),
									trueExpr.indexOf(startDateFormat));				
				else
					eval = (boolean) engine.eval(formula);
				date = falseExpr.substring(
						falseExpr.indexOf(startDate) + startDate.length(),
						falseExpr.indexOf(startDateFormat));
//				System.out.println(date);
				return date;				
			case "percentage":
				eval = (boolean) engine.eval(formula);
				if (eval)
				{
//					System.out.println(engine.eval(trueExpr));
					return (String) engine.eval(trueExpr);
				}
				else
				{
//					System.out.println("Can you please provide another expression in ELSE part");
					return "Can you please provide another expression in ELSE part";
				}
			case "currency":
				eval = (boolean) engine.eval(formula);
				if (eval)
				{
//					System.out.println(engine.eval(trueExpr));
					return engine.eval(trueExpr).toString();
				}
				else
				{
//					System.out.println("Can you please provide another expression in ELSE part");
					return "Can you please provide another expression in ELSE part";
				}
			case "number":
				eval = (boolean) engine.eval(formula);
				if (eval)
				{
//					System.out.println(engine.eval(trueExpr));
					return engine.eval(trueExpr).toString();
				}
				else
				{
//					System.out.println("Can you please provide another expression in ELSE part");
				    return "Can you please provide another expression in ELSE part";
				}
			case "text":
//				System.out.println(engine.eval(formula));
				return engine.eval(formula).toString();				
			default:
				System.out.println("None of the cases executed");
				break;
			}
			return falseExpr;
		}
	}
