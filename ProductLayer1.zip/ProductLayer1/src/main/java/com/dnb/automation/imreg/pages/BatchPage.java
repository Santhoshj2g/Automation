package com.dnb.automation.imreg.pages;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;

public class BatchPage extends PageObject {

	@FindBy(xpath = "//a[@title='Batch']")
	private WebElementFacade batchIcon;
	
	@FindBy(xpath="//*[@id='holder']")
	private WebElementFacade batchPg;

	@FindBy(xpath = "//select[@name='workflowProfileId']//option")
	private List<WebElement> workflowOptions;

	@FindBy(xpath = "//select[@name='workflowProfileId']//option[contains(text(),'Sample_Manual_Batch_Template [public]')]")
	private WebElementFacade workflowOption;

	@FindBy(xpath = "//*[contains(text(),'Save As')]")
	private WebElementFacade saveBtn;

	@FindBy(xpath = "//input[@id='newProfileNameAlias']")
	private WebElementFacade textField;

	@FindBy(xpath = "//*[contains(text(),'OK')]")
	private WebElementFacade okBtn;

	@FindBy(xpath = "//*[@id='diagramHolder']//span[contains(text(),'Mapping')]")
	private WebElementFacade mappingView;
	
	@FindBy(xpath= "//*[@id='tab_con']//*[contains(text(),'Mapping')]")
	private WebElementFacade mappingPg;

	@FindBy(xpath = "//*[@id='diagramHolder']//span[contains(text(),'Quality')]")
	private WebElementFacade quality;
	
	@FindBy(xpath = "//*[@id='con_div']//*[contains(text(),'Conf Code Threshold')]")
	private WebElementFacade qualityPg;
	
	String frameset = "//*[@id='tbfrm']//*[@id='tst']//frame[@name='Main']";

	@FindBy(xpath = "//*[@name='tablesCombo']")
	private WebElement createdTable;

	@FindBy(xpath = "//select[@name='CompanyName_refInpt_One']//option")
	private List<WebElement> cmpyName;

	@FindBy(xpath = "//select[@name='Address_refInpt_One']//option")
	private List<WebElement> cmpyAddrs;

	@FindBy(xpath = "//select[@name='City_refInpt_One']//option")
	private List<WebElement> city;

	@FindBy(xpath = "//select[@name='State/Province_refInpt_One']//option")
	private List<WebElement> state;

	@FindBy(xpath = "//select[@name='Zip/PostalCode_refInpt_One']//option")
	private List<WebElement> zipPostal;

	@FindBy(xpath = "//select[@name='Telephone_refInpt_One']//option")
	private List<WebElement> telephone;

	@FindBy(xpath = "//select[@name='POBox_refInpt_One']//option")
	private List<WebElement> postBox;

	@FindBy(xpath = "//select[@name='Country_refInpt_One']//option")
	private List<WebElement> country;

	@FindBy(xpath = "//*[@id='inpt_div']//*[@id='btnSave']")
	private WebElement applyBtn;

	@FindBy(xpath = "//*[@id='conEdit1']")
	private WebElementFacade sendValue;

	@FindBy(xpath = "//*[@id='confThresholdPage']//*[@id='btnSave']")
	private WebElementFacade saveBtn2;

	@FindBy(xpath = "//*[@id='diagramHolder']//*[contains(text(),'Matched Data View')]")
	private WebElement matchedDataView;

	@FindBy(xpath = "//*[@id='diagramHolder']//*[contains(text(),'Allrecords Data View')]")
	private WebElement allrecordDataView;

	@FindBy(xpath = "//*[@id='diagramHolder']//*[contains(text(),'Unmatched Data View')]")
	private WebElement unMatchedDataView;

	@FindBy(xpath = "//*[@id='diagramHolder']//*[contains(text(),'Matched Export')]")
	private WebElementFacade matchedExport;

	@FindBy(xpath = "//*[@id='diagramHolder']//*[contains(text(),'Allrecords Export')]")
	private WebElementFacade allrecordExport;

	@FindBy(xpath = "//*[@id='diagramHolder']")
	private WebElement clickHereTogo;

	@FindBy(xpath = "//*[@id='diagramHolder']//*[contains(text(),'Unmatched Export')]")
	private WebElementFacade unmatchedExport;

	@FindBy(xpath = "//*[contains(text(),'click here')]")
	private WebElementFacade clickhereForMatchedRecords;

	@FindBy(xpath = "//input[@name='profileName']")
	private WebElementFacade matchedProfileName;
	
	@FindBy(xpath = "//select[@name='accessType']")
	private WebElement selectAccess;

	@FindBy(xpath = "//select[@name='category']")
	private WebElement selectcategory;
	
	@FindBy(xpath = "//select[@name='category']//option")
	private List<WebElement> customerInput;
	
	@FindBy(xpath = "//select[@name='selectableField']//option")
	private List<WebElement> selectOutValue;

	@FindBy(xpath = "//input[@name='add']")
	private WebElementFacade addBtn;

	@FindBy(xpath = "//*[@id='btnSave']")
	private WebElementFacade saveBtnForMatchedRecords;

	@FindBy(xpath = "//input[@name='Directory']")
	private WebElementFacade exportDirectory;

	@FindBy(xpath = ".//input[@name='FileName']")
	private WebElementFacade exportFileName;

	@FindBy(xpath = "//input[@name='ExportOption']")
	private WebElementFacade exportOption;

	@FindBy(xpath = "//*[@id='btnSave']")
	private WebElementFacade applyBtn2;

	@FindBy(xpath = "//*[@id='module_Head']")
	private WebElementFacade matchePg;
	
	@FindBy(xpath = "//*[@id='pageSheet']//input[@name='Directory']")
	private WebElementFacade exportDir;

	@FindBy(xpath = "//input[@name='FileName']")
	private WebElementFacade fileName;

	@FindBy(xpath = "//input[@value='MatchQualifier']")
	private WebElementFacade chckbox;

	@FindBy(xpath = "//*[@title='Run']")
	private WebElementFacade run;

	@FindBy(xpath = "//a[@title='Job Status']")
	private WebElementFacade jobStatus;

	@FindBy(xpath = "//*[@id='pageSheet']//table[@id='grid']//tr[2]//td[9]")
	private WebElementFacade processed;

	@FindBy(xpath = "//*[@id='pageSheet']//table[@id='grid']//tr[2]//td[10]")
	private WebElementFacade matched;

	@FindBy(xpath = "//*[@id='pageSheet']//table[@id='grid']//tr[2]//td[11]")
	private WebElementFacade unmatched;

	@FindBy(xpath = "//*[@id='pageSheet']//table[@id='grid']//tr[2]//td[12]")
	private WebElementFacade rejected;

	@FindBy(xpath = "//*[@id='pageSheet']//table[@id='grid']//tr[2]//td[14]")
	private WebElementFacade total;

	@FindBy(xpath = "//*[@id='pageSheet']//table[@id='grid']//tr[2]//td[3]")
	private WebElementFacade jobId;

	@FindBy(xpath = "//*[@id='pageSheet']//table[@id='grid']//tr[2]//*[@alt='Job finished']")
	private WebElement finished;

	@FindBy(xpath = "//*[@id='div_tab1']//select[@name='selectableField']//option[@value='16']")
	private WebElementFacade confidentCode;

	@FindBy(xpath = "//*[@id='div_tab1']//select[@name='selectableField']//option[contains(text(),'match_grade')]")
	private WebElementFacade matchedGrade;

	@FindBy(xpath = "//*[@id='div_tab1']//select[@name='selectableField']//option[contains(text(),'Reason')]")
	private WebElementFacade reason;

	@FindBy(xpath = "//*[@id='div_tab1']//select[@name='selectableField']//option[contains(text(),'MatchType')]")
	private WebElementFacade matchedType;

	@FindBy(xpath = "//*[@id='banner_top_part']//*[@id='tblNav']//*/a[contains(.,'Home')]")
	private WebElementFacade homeLink;

	public static int rowCountFile = 0;
	public static String processCount;
	public static int proCount = 0;
	public static int totaCount = 0;
	public static String totalCount;
	public static String matchCount;
	public static String unMatchedCount;
	public static String rejectCount;
	public static String jobIds;
	public boolean pro;
	public boolean tot;

	public void clckBatch() throws Exception
	{
		try {
			getDriver().switchTo().frame("menuHeaders");
			batchIcon.waitUntilClickable();
			batchIcon.click();
			getDriver().switchTo().defaultContent();
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("topFrame");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean verifyBatchPageDisplayed() throws Exception
	{
		batchPg.waitUntilVisible();
		if(batchPg.isDisplayed())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void sampleManualBatch() throws Exception
	{
		try {
			UIHelper.clickanElement(workflowOption);
			Thread.sleep(5000);
			saveBtn.click();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void createWorkFlow(String manualWkflow) throws Exception
	{
		try {
			long flow = System.currentTimeMillis();
			textField.type(manualWkflow+flow);
			okBtn.click();
			UIHelper.waitForPageToLoad(getDriver());
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void configureMapping() throws Exception
	{
		try {
			Actions action = new Actions(getDriver());
			action.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
			mappingView.waitUntilClickable();
			mappingView.click();
			getDriver().switchTo().defaultContent();
			Thread.sleep(1000);
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("bottomFrame");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean verifyMappingPageDisplayed() throws Exception
	{
		mappingPg.waitUntilVisible();
		if(mappingPg.isDisplayed())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void configureTable(String value) throws Exception
	{
		try {
			Select sel = new Select(createdTable);
			sel.selectByValue(value);
			Thread.sleep(5000);
		} catch (Exception e)  {
			throw e;
		}
	}
	
	
	public void configureCmpy() throws Exception {
		try {
			for (WebElement element : cmpyName) {
				if (element.getText().trim().contains("CO_NAME")) {
					UIHelper.clickanElement(element);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void configureAddress() throws Exception {
		try {
			for (WebElement element : cmpyAddrs) {
				 if (element.getText().trim().contains("CO_ADDRESS1")) {
					UIHelper.clickanElement(element);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void configureCity() throws Exception {
		try {
				 for (WebElement element : city) {
				 if (element.getText().trim().contains("CO_CITY")) {
					 UIHelper.clickanElement(element);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void configureState() throws Exception {
		try {
			for (WebElement element : state) {
				if (element.getText().trim().contains("CO_STATE_PROVINCE")) {
					UIHelper.clickanElement(element);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void configureZip() throws Exception {
		try {
			for (WebElement element : zipPostal) {
				if (element.getText().trim().contains("ZIP_CODE")) {
					UIHelper.clickanElement(element);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void configurePhone() throws Exception {
		try {
			for (WebElement element : telephone) {
				if (element.getText().trim().contains("CO_PHONE_NBR")) {
					UIHelper.clickanElement(element);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void configureCountry() throws Exception {
		try {
			for (WebElement element : country) {
				if (element.getText().trim().contains("CO_COUNTRY_NAME")) {
					UIHelper.clickanElement(element);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void configurePoBox() throws Exception {
		try {
			for (WebElement element : postBox) {
				if (element.getText().trim().contains("Select column")) {
					UIHelper.clickanElement(element);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void apply() throws Exception {
		try {
			UIHelper.clickanElement(applyBtn);
			getDriver().switchTo().defaultContent();
			Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void quality() throws Exception
	{
		try
		{
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("topFrame");
			quality.waitUntilClickable();
			quality.click();
			Thread.sleep(8000);
			JavascriptExecutor jse = (JavascriptExecutor) getDriver();
			jse.executeScript("window.scrollBy(0,250)", "");
			getDriver().switchTo().defaultContent();
			Thread.sleep(1000);
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("bottomFrame");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean verifyQualityPageDisplayed() throws Exception
	{
		qualityPg.waitUntilVisible();
		if(qualityPg.isDisplayed())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void setRange() throws Exception
	{
		try {
			sendValue.waitUntilClickable();
			sendValue.type("5");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void applyBtn() throws Exception
	{
		try { 
			saveBtn2.waitUntilClickable();
			saveBtn2.click();
			Thread.sleep(6000);
			getDriver().switchTo().defaultContent();
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void matchedDataView() throws Exception
	{
		try {
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("topFrame");
			Thread.sleep(6000);
			UIHelper.scrollToAnElement(matchedDataView);
			JavascriptExecutor executor = (JavascriptExecutor)getDriver();
			executor.executeScript("arguments[0].click();", matchedDataView);
			Thread.sleep(6000);
			getDriver().switchTo().defaultContent();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void createNewMatchedData() throws Exception
	{
		try {
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("bottomFrame");
			clickhereForMatchedRecords.waitUntilClickable();
			clickhereForMatchedRecords.click();
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
	  }
	}
	
	public void matchedAccessType(String name) throws Exception
	{
		try {
			long flow = System.currentTimeMillis();
			matchedProfileName.type(name+flow);
			Select sel = new Select(selectAccess);
			sel.selectByVisibleText("public");
			try {

				for (int i = 0; i < customerInput.size(); i++) {
					if (customerInput.get(i).getText()
							.contains("Customer Input Record")) {
						UIHelper.clickanElement(customerInput.get(i));
						Thread.sleep(5000);
					} 
				}				
				for (int j = 0; j < selectOutValue.size(); j++)
				{
					UIHelper.clickanElement(selectOutValue.get(j));
					Thread.sleep(5000);
				}
				addBtn.click();
				
				for (int i = 0; i < customerInput.size(); i++) {
					if (customerInput.get(i).getText()
							.contains("D&B Basic Data")) {
						UIHelper.clickanElement(customerInput.get(i));
						Thread.sleep(5000);
					}
				}
				UIHelper.clickanElement(confidentCode);
				UIHelper.clickanElement(matchedGrade);
				addBtn.click();
				Thread.sleep(5000);
			} catch (StaleElementReferenceException e) {
				e.printStackTrace();
			}

		} catch (Exception e) {
			throw e;
		}
	}
	
	public void clckSave() throws Exception
	{
		try {
			applyBtn2.waitUntilClickable();
			applyBtn2.click();
		} catch (Exception e) {
			throw e;
		}
	}
	
	public boolean verifyMatchedPageDisplayed() throws Exception
	{
		matchePg.waitUntilVisible();
		if(matchePg.isDisplayed())
		{
			getDriver().switchTo().defaultContent();
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void unMatchedDataView() throws Exception
	{
		try {
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("topFrame");
			Thread.sleep(5000);
			UIHelper.scrollToAnElement(unMatchedDataView);
			JavascriptExecutor executor = (JavascriptExecutor)getDriver();
			executor.executeScript("arguments[0].click();", unMatchedDataView);
			Thread.sleep(6000);
			getDriver().switchTo().defaultContent();	
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void createUnmatchedData() throws Exception
	{
		try {
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("bottomFrame");
			clickhereForMatchedRecords.waitUntilClickable();
			clickhereForMatchedRecords.click();
			Thread.sleep(2000);			
		} catch (Exception e) {
			throw e;
		}
	}

	public void unMatchedAccessType(String name) throws Exception
	{
		try {
			long flow = System.currentTimeMillis();
			matchedProfileName.type(name+flow);
			Select sel = new Select(selectAccess);
			sel.selectByVisibleText("public");
			try {

				for (int i = 0; i < customerInput.size(); i++) {
					if (customerInput.get(i).getText()
							.contains("Customer Input Record")) {
						UIHelper.clickanElement(customerInput.get(i));
						Thread.sleep(5000);
					}
				}

				for (int j = 0; j < selectOutValue.size(); j++) {
					UIHelper.clickanElement(selectOutValue.get(j));
				}
				addBtn.click();

				for (int i = 0; i < customerInput.size(); i++) {
					if (customerInput.get(i).getText()
							.contains("Unmatched Indicators")) {
						UIHelper.clickanElement(customerInput.get(i));
						Thread.sleep(5000);
					}
				}
				UIHelper.clickanElement(reason);
				addBtn.click();
			} catch (StaleElementReferenceException e) {
				e.printStackTrace();
			}		
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void allRecordsDataView() throws Exception
	{
		try {
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("topFrame");
			Thread.sleep(2000);
			UIHelper.scrollToAnElement(allrecordDataView);
			JavascriptExecutor executor = (JavascriptExecutor)getDriver();
			executor.executeScript("arguments[0].click();", allrecordDataView);
			Thread.sleep(6000);
			getDriver().switchTo().defaultContent();
			
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void createAllrecordsData() throws Exception
	{
		try {
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("bottomFrame");
			Thread.sleep(2000);
			UIHelper.clickanElement(clickhereForMatchedRecords);
			Thread.sleep(2000);
		} catch (Exception e) {
			throw e;	
		}
	}
	
	public void allRecordsAccessType(String name) throws Exception
	{
		try {
			long flow = System.currentTimeMillis();
			matchedProfileName.type(name+flow);
			Select sel = new Select(selectAccess);
			sel.selectByVisibleText("public");
			try {

				for (int i = 1; i < customerInput.size(); i++) {
					if (customerInput.get(i).getText()
							.contains("Customer Input Record")) {
						UIHelper.clickanElement(customerInput.get(i));
						Thread.sleep(5000);
					}
				}

				for (int j = 0; j < selectOutValue.size(); j++) {
					UIHelper.clickanElement(selectOutValue.get(j));
				}
				addBtn.click();

				for (int i = 0; i < customerInput.size(); i++) {
					if (customerInput.get(i).getText()
							.contains("D&B Basic Data")) {
						UIHelper.clickanElement(customerInput.get(i));
						Thread.sleep(5000);
					}
				}

				UIHelper.clickanElement(confidentCode);
				UIHelper.clickanElement(matchedGrade);
				addBtn.click();

				for (int i = 0; i < customerInput.size(); i++) {
					if (customerInput.get(i).getText()
							.contains("Matched Indicators")) {
						UIHelper.clickanElement(customerInput.get(i));
						Thread.sleep(5000);
					}
				}
				UIHelper.clickanElement(matchedType);
				addBtn.click();

			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void matchedExport() throws Exception
	{
		try {
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("topFrame");
			Thread.sleep(2000);
			UIHelper.scrollToAnElement(matchedExport);
			JavascriptExecutor executor = (JavascriptExecutor)getDriver();
			executor.executeScript("arguments[0].click();", matchedExport);
			Thread.sleep(6000);
			getDriver().switchTo().defaultContent();
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("bottomFrame");
			String name = "D:" + "\\" + "IM" + "\\" + "Export";
			exportDir.type(name);
			exportFileName.type("test1Matched.txt");
			chckbox.waitUntilClickable();
			chckbox.click();
			applyBtn2.click();
			Thread.sleep(6000);
			getDriver().switchTo().defaultContent();	
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void unMatchedExport() throws Exception
	{
		try {
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("topFrame");
			Thread.sleep(2000);
			UIHelper.scrollToAnElement(unmatchedExport);
			JavascriptExecutor executor = (JavascriptExecutor)getDriver();
			executor.executeScript("arguments[0].click();", unmatchedExport);
			Thread.sleep(6000);
			getDriver().switchTo().defaultContent();
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("bottomFrame");
			String name = "D:" + "\\" + "IM" + "\\" + "Export";
			exportDir.type(name);
			exportFileName.type("test1Unmatched.txt");
			chckbox.waitUntilClickable();
			chckbox.click();
			applyBtn2.click();
			Thread.sleep(6000);
			getDriver().switchTo().defaultContent();
		} catch (Exception e) {
			throw e;
		}
	}
	
	
	public void allExport() throws Exception
	{
		try {
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("topFrame");
			Thread.sleep(2000);
			UIHelper.scrollToAnElement(allrecordExport);
			JavascriptExecutor executor = (JavascriptExecutor)getDriver();
			executor.executeScript("arguments[0].click();", allrecordExport);
			Thread.sleep(6000);
			getDriver().switchTo().defaultContent();
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("bottomFrame");
			String name = "D:" + "\\" + "IM" + "\\" + "Export";
			exportDir.type(name);
			exportFileName.type("test1Allrecord.txt");
			chckbox.waitUntilClickable();
			chckbox.click();
			applyBtn2.click();
			Thread.sleep(6000);
			getDriver().switchTo().defaultContent();
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void run() throws Exception {
		try {
			getDriver().switchTo().frame("Main");
			getDriver().switchTo().frame("topFrame");
			UIHelper.clickanElement(run);
			Thread.sleep(18000);
			getDriver().switchTo().defaultContent();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void jobStatus() throws Exception {
		try {
			getDriver().switchTo().frame("menuHeaders");
			UIHelper.clickanElement(jobStatus);
			getDriver().switchTo().defaultContent();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void validations() throws Exception {
		try {
			getDriver().switchTo().frame("Main");
			jobIds = jobId.getText().trim();
			System.out.println(jobIds);
			processCount = processed.getText().trim();

			System.out.println(processCount);
			totalCount = total.getText().trim();
			System.out.println(totalCount);
			if (processCount.contains(totalCount)) {
				pro = true;
			}
			matchCount = matched.getText().trim();
			System.out.println(matchCount);
			unMatchedCount = unmatched.getText().trim();
			System.out.println(unMatchedCount);
			rejectCount = rejected.getText().trim();
			System.out.println(rejectCount);
/*			UIHelper.waitforElement(getDriver(), finished);
			getDriver().switchTo().defaultContent();
			getDriver().switchTo().frame("menuHeaders");
			UIHelper.clickanElement(importIcon);
			getDriver().switchTo().defaultContent();
*/
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
