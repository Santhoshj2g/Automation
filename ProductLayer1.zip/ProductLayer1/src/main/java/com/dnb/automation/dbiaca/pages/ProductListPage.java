package com.dnb.automation.dbiaca.pages;

import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**********************************************************************************************
 * ProductListPage.java - This program contains steps for 
 * 1. User checks ProductList Page navigation
 *
 * @author   Sendhilkumar.R
***********************************************************************************************/
public class ProductListPage extends PageObject {
		
	@FindBy(xpath="//*[@id='ProductResult']/tbody/tr/td[1]/a")
	private List<WebElementFacade> element;
	@FindBy(xpath="//*[@name='Investigation']//*[@value='Order Report']")
	private WebElementFacade orderProductBtn;
	String temp ="//*[@id='ProductResult']/tbody/tr/td[1]/a";
	String xpathStart = "//*[@id='ProductResult']/tbody/tr[";
	String xpathEnd = "]/td[1]/a";
			
	int count = 0;
	boolean flag = true;
			
	public boolean checkReport(String reportname) throws Exception{
		boolean isSpecificReport = false;
		
		try{
			
			for(int i=1;i<=element.size();i++)
						{
				
				WebElementFacade elementLink=findBy(xpathStart+i+xpathEnd);
				if(elementLink.getText().toString().trim().contains(reportname)){
					isSpecificReport = true;
					break;
				}
			}	
		}catch(Exception e){
			e.getStackTrace();
		}	
		return isSpecificReport;
		
	}
	
	public void selectReport(String reportname) throws Exception{
		try{
			
			for(int i=1;i<element.size();i++){
				WebElementFacade elementLink=findBy(xpathStart+i+xpathEnd);
				if(elementLink.isPresent()==true && elementLink.getText().toString().trim().contains(reportname)){
						UIHelper.highlightElement(getDriver(), elementLink);
						elementLink.click();
						UIHelper.waitForPageToLoad(getDriver());
						while(orderProductBtn.isPresent())
						{
							orderProductBtn.click();
							UIHelper.waitForPageToLoad(getDriver());
						}
						break;
				}
			}
		 }catch(Exception e){
			 e.getStackTrace();
		}	
	}
	
	public boolean isProductAvailable() throws Exception{
		boolean flag = false;
		try{
			for(int i=0;i<element.size();i++)
			{
				i=i+1;
				WebElementFacade elementLink=findBy(xpathStart+i+xpathEnd);
				if(elementLink.getText().trim().equalsIgnoreCase("European Business Report")
						||elementLink.getText().trim().equalsIgnoreCase("Comprehensive Report")
						||elementLink.getText().trim().equalsIgnoreCase("Business Information Report")){
					flag = true;
					break;
				}
			}
			
		}catch(Exception e){
			e.getStackTrace();
		}
		return flag;
	}
		
	public void clickOnReports(WebElementFacade elementLink ){
		elementLink.click();
		UIHelper.waitForPageToLoad(getDriver());
		getDriver().navigate().back();
		UIHelper.waitForPageToLoad(getDriver());
	}
	

}
