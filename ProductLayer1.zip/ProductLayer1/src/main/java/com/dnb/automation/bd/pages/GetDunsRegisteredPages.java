package com.dnb.automation.bd.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class GetDunsRegisteredPages extends PageObject {

	@FindBy(xpath = "//select[@id='registerNamePfx']")
	private WebElementFacade selPrefix;

	@FindBy(xpath = "//input[@id='registerFirstName']")
	private WebElementFacade txtFirstName;

	@FindBy(xpath = "//input[@id='registerLastName']")
	private WebElementFacade txtLastName;

	@FindBy(xpath = "//input[@id='registerBussinesName']")
	private WebElementFacade txtBusinessName;

	@FindBy(xpath = "//input[@id='registerEmail']")
	private WebElementFacade txtEmail;

	@FindBy(xpath = "//input[@id='editCountryCode']")
	private WebElementFacade txtCountryCode;

	@FindBy(xpath = "//input[@id='editAreaCode']")
	private WebElementFacade txtAreaCode;

	@FindBy(xpath = "//input[@id='editPhonNum']")
	private WebElementFacade txtPhonNum;

	@FindBy(xpath = "//input[@id='editPhoneExt']")
	private WebElementFacade txtExtPhonNum;

	@FindBy(xpath = "//textarea[@id='registerBusinessAddr']")
	private WebElementFacade txtBusinessAddr;

	@FindBy(xpath = "//select[@id='registerCountry']")
	private WebElementFacade txtregisterCountry;

	@FindBy(xpath = "//input[@id='registerUrl']")
	private WebElementFacade txtregisterUrl;

	@FindBy(xpath = "//a[@id='dunsRegisterBtn']")
	private WebElementFacade SubmitButton;

	@FindBy(xpath = "//div[@id='dunsRegisterSuccess']/h3")
	private WebElementFacade Successmessage;

	@FindBy(xpath = "//*[@id='dunsRegisterSuccess']/p[2]/a[@class='backLink']")
	private WebElementFacade BacktoHomeLink;

	
	
	/***********************************************************************************
	 * Function: Select the prefix option on GetDUNSRegister Tab
	 *  Input : String
	 * Action: NA Output : NA
	 ***********************************************************************************/
	public void selectPrefix(String Prefix) {

		selPrefix.selectByVisibleText(Prefix);
	}

	/***********************************************************************************
	 * Function: Input the FirstName on GetDUNSRegister Tab
	 *  Input : String
	 * Action: NA Output : NA
	 ***********************************************************************************/
	public void giveFirstName(String firstName) {

		txtFirstName.sendKeys(firstName);
		getDriver().manage().timeouts().implicitlyWait(600, TimeUnit.SECONDS);
	}
	/***********************************************************************************
	 * Function: Input the LastName on GetDUNSRegister Tab
	 *  Input :String
	 * Action: NA Output : NA
	 ***********************************************************************************/
	public void giveLastName(String lastName) {

		txtLastName.waitUntilVisible();
		txtLastName.sendKeys(lastName);
	}
	/***********************************************************************************
	 * Function: Input the businessname on GetDUNSRegister Tab
	 *  Input :String
	 * Action: NA Output : NA
	 ***********************************************************************************/

	public void giveBusinessName(String businessName) {

		txtBusinessName.waitUntilVisible();
		txtBusinessName.sendKeys(businessName);
	}
	/***********************************************************************************
	 * Function: Input the email address on GetDUNSRegister Tab
	 *  Input : String
	 * Action: NA Output : NA
	 ***********************************************************************************/
	public void giveEmail(String email) {

		txtEmail.sendKeys(email);
	}
	/***********************************************************************************
	 * Function: Input the country code on GetDUNSRegister Tab
	 *  Input :String
	 * Action: NA Output : NA
	 ***********************************************************************************/

	public void giveCountryCode(String countryCode) {

		txtCountryCode.sendKeys(countryCode);
	}
	/***********************************************************************************
	 * Function: input the AREACODE  GetDUNSRegister Tab
	 *  Input :String
	 * Action: NA Output : NA
	 ***********************************************************************************/
	public void giveAreaCode(String areaCode) {

		txtAreaCode.sendKeys(areaCode);
	}
	/***********************************************************************************
	 * Function: input the Phonenumber on GetDUNSRegister Tab
	 *  Input : String
	 * Action: NA Output : NA
	 ***********************************************************************************/
	public void givePhoneNumber(String phoneNumber) {

		txtPhonNum.sendKeys(phoneNumber);
	}
	/***********************************************************************************
	 * Function: input the telephone extension on GetDUNSRegister Tab
	 *  Input :String
	 * Action: NA Output : NA
	 ***********************************************************************************/
	public void givetelExt(String ext) {

		txtExtPhonNum.sendKeys(ext);
	}
	/***********************************************************************************
	 * Function:input the  businessAddress GetDUNSRegister Tab
	 *  Input :String
	 * Action: NA Output : NA
	 ***********************************************************************************/
	public void giveBusinessAddress(String businessAddress) {

		txtBusinessAddr.sendKeys(businessAddress);
	}
	/***********************************************************************************
	 * Function: input the country  GetDUNSRegister Tab
	 *  Input :String
	 * Action: NA Output : NA
	 ***********************************************************************************/
	public void giveCountry(String country) {

		txtregisterCountry.sendKeys(country);
	}
	/***********************************************************************************
	 * Function: input the website url GetDUNSRegister page
	 *  Input :String
	 * Action: NA Output : NA
	 ***********************************************************************************/
	public void giveWebsiteURL(String websiteURL) {

		txtregisterUrl.sendKeys(websiteURL);
	}
	/***********************************************************************************
	 * Function: click on submit button
	 *  Input :na
	 * Action: NA Output : NA
	 ***********************************************************************************/
	public void clickSubmitButton() {

		SubmitButton.click();
	}
	/***********************************************************************************
	 * Function: verify the success Message
	 *  Input :NA
	 * Action: NA Output : NA
	 ***********************************************************************************/
	public boolean successMessage() {

		return Successmessage.isPresent();
	}
	/***********************************************************************************
	 * Function: verify  the backtoHomeLink
	 * 	   Input : NA
	 * Action: NA Output : NA
	 ***********************************************************************************/
	public boolean backtoHomeLink() {

		return BacktoHomeLink.isPresent();
	}

}
