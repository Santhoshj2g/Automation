package com.dnb.automation.srm.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * QuickSearch.java - This program contains steps for 1. User clicks the Expand
 * button for getting DUNS number details 2. User Checks SER-Rating Value in
 * QuickSearch page 3. User Checks SSI-Rating Value in QuickSearch page
 *
 * @author Joseph Dennison
 ***********************************************************************************************/

public class QuickSearch extends PageObject {

    @FindBy(xpath = "//*[@class='screening-alerts-detail clearFix']//*[@id='search-results']//tr[1]//td[5]//img[contains(@src,'static/images/expandClose.png')]")
    private WebElementFacade expand;

    @FindBy(xpath = "//*/table/tbody/tr[2]/td[1]/div/div[2]/div[1]/div[1]/ul//*[@id='SERSlider0']//div//*[@class='valueContainer'] | //*[@class='screening-alerts-detail clearFix']//*[@id='search-results']//tr[2]//td//div//*[@class='company_ratings']//div[1]//*[@id='SERSlider0'][contains(.,'Not Available')] | //*[@class='screening-alerts-detail clearFix']//*[@id='search-results']//tr[2]//td//div//*[@class='company_ratings']//div[1]//*[@id='SERSlider0'][contains(.,'Out of Business')]")
    private WebElementFacade serRating;

    @FindBy(xpath = "//*[@id='PaydexSlider0']/div/div")
    private WebElementFacade paydexRating;
    
    @FindBy(xpath = "//*[@id='viabilityScore0']/ul/li[2]/span[1]")
    private WebElementFacade viabScore;
    
    @FindBy(xpath = "//*[@id='viabilityScore0']/ul/li[2]/span[2]")
    private WebElementFacade portfolioScr;
    
    @FindBy(xpath = "//*[@id='viabilityScore0']/ul/li[2]/span[3]")
    private WebElementFacade datadepthind;
    
    @FindBy(xpath = "//*[@id='viabilityScore0']/ul/li[2]/span[4]")
    private WebElementFacade companyprof;
    
    
    @FindBy(xpath = "//*/table/tbody/tr[2]/td[1]/div/div[2]/div[2]/div[1]/ul//*[@id='SSISlider0']//div//*[@class='valueContainer'] | //*[@class='screening-alerts-detail clearFix']//*[@id='search-results']//tr[2]//td//div//*[@class='company_ratings']//div[1]//*[@id='SSISlider0'][contains(.,'Not Available')] | //*[@class='screening-alerts-detail clearFix']//*[@id='search-results']//tr[2]//td//div//*[@class='company_ratings']//div[1]//*[@id='SSISlider0'][contains(.,'Out of Business')]")
    private WebElementFacade ssiRating;

    @FindBy(xpath = "//*[@id='wrapper_header']//*[@class='header-tabs-container clearFix']//ul//*[@id='desktopMenu']/a")
    private WebElementFacade dashBoard;

    @FindBy(xpath = ".//*[@id='wrapper']//*[@class='container']//*[@class='dashboard-container']//*[@class='page-heading']/h1")
    private WebElementFacade dashboardTitleEle;

    private String ajaxImgLoadingXpathInExpandSearchResults = "//*[@class='screening-alerts-detail clearFix']//*[@id='search-results']//tr[1]//td[5]//img[contains(@src,'static/images/ajaxLoader_small.gif')]";
    boolean isexpand;
    private String serValue;
    private String ssiValue;
   	private String paydexValue;
	private String viabScoreval;
	private String portfolioScoreVal;
    private String datadepthindicator;
    private String compnayprofileVal;
    
    

    // Click the Expand button in dash-board page

    public void expandButton() throws Exception {
        try {
            expand.waitUntilPresent();
            UIHelper.highlightElement(getDriver(), expand);
            expand.click();
            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxImgLoadingXpathInExpandSearchResults);
            serRating.waitUntilPresent();
        } catch (Exception e) {

        }
    }

    
    // Verify SER-Rating value in QuickSearch page

    public String serValue() throws Exception {
        try {
            if (serRating.isPresent()) {
                // UIHelper.waitForPageToLoad(getDriver());
                UIHelper.highlightElement(getDriver(), serRating);
                serValue = serRating.getText().toString().trim();
                ssiRating.waitUntilPresent();
            }
        } catch (Exception e) {

        }
        return serValue;
    }
    
 
    
 // Verify Paydex value in QuickSearch page

    public String verifyPaydexValue() throws Exception {
        try {
        	if (paydexRating.isCurrentlyVisible()){
                UIHelper.highlightElement(getDriver(), paydexRating);
                paydexValue = paydexRating.getText().toString().trim();
            }
        } catch (Exception e) {

        }
        return paydexValue;
    }

    
 // Verify Viability Score value in QuickSearch page

    public String verifyPredictivepageViabilityscoreVal() throws Exception {
        try {
        	viabScore.waitUntilPresent();
            if (element(viabScore).isPresent()) {
            	viabScoreval = viabScore.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), viabScore);
            }
        } catch (Exception e) {

        }

        return viabScoreval;
    }
    
    
 // Verify Portfolio Comparison score in QuickSearch page

    public String PredictivePortfolioComparisonValue() throws Exception {
        try {
        	portfolioScr.waitUntilPresent();
            if (element(portfolioScr).isPresent()) {
            	portfolioScoreVal = portfolioScr.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), portfolioScr);
            }
        } catch (Exception e) {

        }

        return portfolioScoreVal;
    }
    
    
    
 // Verify Data Depth Indicator value in QuickSearch page

    public String verifyPredictivepageDataDepthIndiScore() throws Exception {
        try {
        	datadepthind.waitUntilPresent();
            if (element(datadepthind).isPresent()) {
            	datadepthindicator = datadepthind.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), datadepthind);
            }
        } catch (Exception e) {

        }

        return datadepthindicator;
    }
    
    
    
    
 // Verify Company Profile value in QuickSearch page

    public String PredictiveCompanyProfileValue() throws Exception {
        try {
        	companyprof.waitUntilPresent();
            if (element(companyprof).isPresent()) {
            	compnayprofileVal = companyprof.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), companyprof);
            }
        } catch (Exception e) {

        }

        return compnayprofileVal;
        
    }
    
    
    
    // Verify SSI-Rating value in QuickSearch page

    public String ssiValue() throws Exception {
        try {
            ssiRating.waitUntilPresent();
            if (ssiRating.isPresent()) {
                UIHelper.highlightElement(getDriver(), ssiRating);
                ssiValue = ssiRating.getText().toString().trim();
            }
        } catch (Exception e) {

        }
        return ssiValue;
    }

    public boolean isIsexpand() {
        return isexpand;
    }

    // Verify Dash-board navigation for next DUNS number

    public void dashBoardPage() throws Exception {
        try {
            if (element(dashBoard).isPresent()) {
                UIHelper.highlightElement(getDriver(), dashBoard);
                dashBoard.wait(8000);
                dashBoard.click();
                dashboardTitleEle.waitUntilPresent();
            }
        } catch (Exception e) {

        }
    }

}
