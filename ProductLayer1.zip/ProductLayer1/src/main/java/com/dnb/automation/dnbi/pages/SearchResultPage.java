/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.dnb.automation.dnbi.pages;

import java.util.List;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * SearchResultPage.java - This class contains pull live report, order
 * investigation and GoTo ECF page functionalities
 * 
 * @author Vamsi Krishna NV
 * @version 1.0
 ***********************************************************************************************/

public class SearchResultPage extends PageObject {

	@FindBy(xpath = ".//*[@id='main']//table//*")
	private WebElementFacade searchGrid;

	@FindBy(xpath = "//*[@id='main']//table//*[@class='tabText' and contains(text(),'There were no matching companies')]")
	private WebElementFacade errorCell;

	@FindBy(xpath = "//*[@id='main']//*[@class='clear']//table[@class='results full']//*[contains(text(),'We are unable to process your request')]")
	private WebElementFacade errorCell2;

	@FindBy(xpath = "//*[@id='main']//*[@class='clear']//table[@class='results full']")
	private WebElementFacade searchTable;

	@FindBy(xpath = "//*[@id='main']//*[@class='results full']//*[text()='We are unable to process your request at this time. Please try again later.']")
	private WebElementFacade errorCellprocessLater;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='page_title']//*[text()='Search Results']")
	private WebElementFacade searchResults;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='page_title']//*[contains(text(),'Search')]")
	private WebElementFacade searchResultscompText;

	// Results Table

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='errorMessage']/div//*[contains(text(),'We are unable to process your request at this time')]")
	private WebElementFacade searchResultsTableunabletoprocessyourrequest;

	@FindBy(xpath = "//*[@class='outerDiv']//*//table[@class='results full']//*//tr//a")
	private WebElementFacade searchResultsTable;

	@FindBy(xpath = "//*[@class='outerDiv']//table")
	private WebElementFacade searchResultsTableOuter;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='clear']//table[@class='results full']//*//*[contains(text(),'D&B')]")
	private WebElementFacade searchResultsTablewithResult;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='clear']//table[@class='results full']//*//*[contains(text(),'Create')]")
	private WebElementFacade searchResultsTablewithResultCreateAcc;

	@FindBy(xpath = "//*[@id='main']//*[@class='clear']//table[@class='results full']//*//*[contains(text(),'D&B')]")
	private List<WebElementFacade> resultsinTableElements;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='floatLeft']//*[contains(@id,'criteria')]//*[contains(@class,'criteria')]")
	private WebElementFacade searchCriteriainResultsPage;

	public synchronized WebElementFacade getSearchCriteriainResultsPage() {
		return searchCriteriainResultsPage;
	}

	public synchronized void setSearchCriteriainResultsPage(
			WebElementFacade searchCriteriainResultsPage) {
		this.searchCriteriainResultsPage = searchCriteriainResultsPage;
	}

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(@id,'folder_bar')]")
	private WebElementFacade searchResultFolderBar;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='folder_bar']//*[@class='match_row']//*[text()='Search Now']")
	private WebElementFacade searchResultFoldersearchtext;

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(@value,'Folder')]")
	private WebElementFacade searchResultBTNAddToFolder;

	@FindBy(xpath = ".//*[@id='main']//*[@class='tools floatLeft']//*[@value='Delete']")
	private WebElementFacade searchResultBTNDelete;

	@FindBy(xpath = "//*[@id='main']//*[@class='results full']//tbody//tr")
	private WebElementFacade searchResultTable;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@class='Search_Criteria search_searchCriteria']//*[@id='Company']")
	private WebElementFacade searchResultTablecompName;

	@FindBy(xpath = "//*[@id='main']//*[@class='Search_Criteria search_searchCriteria']//*[contains(text(),'Folders')]//following-sibling::div//*[@class='matchDigit']")
	private WebElementFacade searchResultdataFromFolder;

	@FindBy(xpath = "//*[@id='main']//*[@class='Search_Criteria search_searchCriteria']//*[contains(text(),'D&')]//following-sibling::div//*[@class='matchDigit']")
	private WebElementFacade searchResultdataFromDnB;

	@FindBy(xpath = "//*[@class='outerDiv']//*//table[@class='results full']//tbody//tr//a[contains(@href,'javascript:createAccount')]")
	private WebElementFacade searchResultApplyforCredit;

	@FindBy(xpath = "//*[@class='outerDiv']//*//table[@class='results full']//tbody//tr")
	private List<WebElementFacade> searchResultfullinTable;

	@FindBy(xpath = "//*[@id='main']//*//table[@class='results full']//tbody//tr//a[contains(@href,'javascript:showCompany')]")
	private WebElementFacade searchResultshowCompany;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='clear']//table//tbody//tr//a[contains(@href,'javascript:showCompany')]")
	private WebElementFacade searchResultliveReport;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='clear']//table//tbody//tr//a[contains(@href,'javascript:showCompany')]")
	private WebElementFacade searchResultEle;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='clear']//table//tbody//tr//a[contains(@href,'javascript:show')]")
	private WebElementFacade searchResultsappidEle;

	@FindBy(xpath = "/*[@class='outerDiv']//*[@class='clear']//table//tbody//tr[1]")
	private WebElementFacade searchResultsthead;

	@FindBy(xpath = "//*[@id='main']//*[@name='searchOrderForm']//*[@type='button' and @value='Submit Order']")
	private WebElementFacade searchInternationslSbmtOrder;

	@FindBy(xpath = "//*[@id='main']//*[@class='Search_Criteria search_searchCriteria']//*[@id='folder_bar']//*[@class='match_row']//*[contains(text(),'D&B')]//following-sibling::*[@class='searchNowBtn']/a")
	private WebElementFacade searchNowBtn;

	@FindBy(xpath = "//*[@id='asdf']//*[contains(@class,'btn') and @value='Continue']")
	private WebElementFacade reportOutofBusinessDunsContinue;

	String reportOutofBusinessDunsContinueXpath = "//*[@id='asdf']//*[contains(@class,'btn') and @value='Continue']";

	@FindBy(xpath = "//*[@id='asdf']//*[@class='btn' and @value='Cancel']")
	private WebElementFacade reportOutofBusinessDunsCancel;

	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_title']")
	private WebElementFacade searchFramemodaltitle;

	@FindBy(xpath = "//*[@class='outerDiv']//table[@class='results full']//tbody//tr//a[contains(@href,'javascript:createAccount')]")
	private WebElementFacade createAccount;

	@FindBy(xpath = "//*[@class='outerDiv']//table[@class='results full']//tbody//tr//a[contains(@href,'javascript:createApp')]")
	private WebElementFacade createApplication;

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'Inter') and contains(@value,'Subm')]")
	private WebElementFacade internationalOrder;

	@FindBy(xpath = "//*[@id='entity_header']/h2")
	private WebElementFacade companyNameEle;

	@FindBy(xpath = "//*[@id='alert_bubble']//input[contains(@value,'View Report')]")
	private WebElementFacade internationalOrderViewReport;

	@FindBy(xpath = "//*[@id='alert_bubble']//input[contains(@value,'Order Investigation')]")
	private WebElementFacade orderInvestigationBtn;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@class='modal_buttons']//*[@id='asdf']//input[@value='Investigate']")
	private WebElementFacade furtherInvestigationBtn;

	@FindBy(xpath = "//*[@id='main']//input[@id='CompanyName']")
	private WebElementFacade companyNameFieldEle;

	@FindBy(xpath = "//*[@id='main']//input[@id='BizInfo-City']")
	private WebElementFacade cityOrTownEle;

	@FindBy(xpath = "//*[@id='main']//*[@class='frmField']//textarea")
	private WebElementFacade additionalInfoTextArea;

	@FindBy(xpath = "//*[@id='main']//input[contains(@value,'6347')]")
	private WebElementFacade standardRadioBtnEle;

	@FindBy(xpath = "//*[@id='main']//input[contains(@name,'emailRequestedIndicator')]")
	private WebElementFacade emailInvestReportChkboxEle;

	@FindBy(xpath = "//*[@id='page_title_links']/h2")
	private WebElementFacade compInvestReqConfirmEle;

	@FindBy(xpath = "//*[@id='main']//input[contains(@value,'6347')]")
	private WebElementFacade priorityRadioBtnEle;

	@FindBy(xpath = "//*[@id='main']//input[@value='Back To Search Results']")
	private WebElementFacade backToSearchResultsBtn;

	@FindBy(xpath = "//*[@id='header_mainApp']//a[text()='Dashboard']")
	private WebElementFacade dashBoardTabEle;

	@FindBy(xpath = "//*[@id='main']//input[contains(@value,'Order') or contains(@value,'Submit')]")
	private WebElementFacade orderBtn;

	@FindBy(xpath = "//*[@id='main']//input[contains(@value,'Submit')]")
	private WebElementFacade submitBtn;

	@FindBy(xpath = "//*[@id='alert_bubble']//input[contains(@value,'Cancel')]")
	private WebElementFacade orderInvestigationCancelBtn;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='option_name']//following-sibling::span[contains(.,'Please continue')]//preceding-sibling::input[1]")
	private WebElementFacade notListedRadioBtnEle;

	@FindBy(xpath = "//*[@class='outerDiv']")
	private WebElementFacade outerDivElement;

	private List<String> allText;

	// SearchResultPO Validation
	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='backRight']//*[contains(@value,'Nex')]")
	private WebElementFacade nextButtonCreatAccFromAccMGRTab;

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//tbody//tr[1]//td//*[contains(@name,'companyName')]")
	private WebElementFacade radioBTNCreatAccFromAccMGRTab;

	@FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]")
	private WebElementFacade tabResultsEle;

	// Add to Folder

	@FindBy(xpath = "//*[@class='outerDiv']//*//table[@class='results full']//tbody//tr//td[contains(.,'D&B')]//following-sibling::td[4]//a[contains(.,'Create Account')]")
	private List<WebElementFacade> searchResultCreateAcntfullinTable;

	@FindBy(xpath = "//*[@class='outerDiv']//*//table[@class='results full']//tbody//tr//td[contains(.,'D&B')]//following-sibling::td[4]//a[contains(.,'Apply for Credit')]")
	private List<WebElementFacade> searchResultApplyCreditfullinTable;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='clear']//table[@class='results full']//*//*[contains(text(),'Callreport')]")
	private WebElementFacade searchResultsTablewithcallReportResult;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@class='results full_company']//thead//tr")
	private WebElementFacade searchResultsHeaderEle;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@class='modal_buttons']//*[@value='Cancel']")
	private WebElementFacade orderInvestigationCancelIFrameEle;

	@FindBy(xpath = "//*[@id='backRight']/input")
	private WebElementFacade orderInternationalNextBtnEle;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='ecf_header']")
	private WebElementFacade ecfHeaderEle;

	@FindBy(xpath = "//*[@class='outerDiv']//*//table[@id='sort3']//*//td[2]")
	private List<WebElementFacade> getdataFromTable;

	@FindBy(xpath = "//*[contains(@href,'Dashboard')]")
	private WebElementFacade dashboardTabEle;

	@FindBy(xpath = "//*[@id='main']//*[@id='SearchResultsForm']//*[contains(@id,'orderInvestigationLnkCss') or contains(@value,'Order investigation from D&B')]")
	private WebElementFacade orderInvestigationLink;

	@FindBy(xpath = "//*[@id='main']//*[@id='SearchResultsForm']//a[contains(.,'Additional Products')]")
	private WebElementFacade additionalProductLinkEle;

	@FindBy(xpath = "//*[@id='main']//*[@id='SearchResultsForm']//*[@class='additional_products_action']//*[contains(@class,'additional_products_content')]")
	private WebElementFacade additionalProductInfoBoxEle;

	@FindBy(xpath = "//*[@id='main']//*[@id='SearchResultsForm']//a[contains(.,'Additional Products')]//a[contains(.,'Global Family Tree')]")
	private WebElementFacade gftLinkEle;

	@FindBy(xpath = "//*[@id='main']//*[@id='SearchResultsForm']//a[contains(.,'Additional Products')]//a[contains(.,'Company Documents')]")
	private WebElementFacade compDocsEle;

	@FindBy(xpath = "//*[@id='main']//*[@class='entcommon_WarningBG']//b[contains(.,'We are unable to process')]")
	private WebElementFacade earningMsgEle;

	String orderInvestigationCancelIFrameXpath = "//*[@class='iframe_modal']//*[@class='modal_buttons']//*[@value='Cancel']";
	private String ajaxLoadingEleXpath = "//*[@class='ecf_page']//*[@id='widget_container']//span[contains(.,'Loading')]";
	private String loadingJavaScriptPageXpath = "//*[@id='contentarea']/div";
	private String imageLoadingXpath = "//*[@id='loading']//img";

	@FindBy(xpath = "//*[@id='compTitle']//h3[contains(.,'Global Family Tree')]")
	private WebElementFacade gftSubHeadingEle;

	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_title']//a")
	private WebElementFacade closeFrameEle;

	@FindBy(xpath = "//*[@id='asdf']//*[@class='modal_inner_content']//p//strong")
	private WebElementFacade dnbiPricingScreenTextEle;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@class='modal_buttons']//*[@id='asdf']//*[@id='ok']")
	private WebElementFacade okButtonEleInDNBiPricingScreen;

	@FindBy(xpath = "//*[@id='tree_div']//table[@class='comp_doc']//tbody//tr[1]//td[1]//input")
	private WebElementFacade chBoxOptionEleForSelectCompDocs;

	@FindBy(xpath = "//*[@id='tree_div']//table[@class='comp_doc']//tbody//tr[1]//td[3]//div[1]")
	private WebElementFacade documnetDescEle;

	@FindBy(xpath = "//*[@id='tree_div']//*[@class='itm_filter']//input[contains(@value,'Download Selected')]")
	private WebElementFacade downloadSelectBtnEleInCompDocs;

	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//*[contains(@name,'iframe')]")
	private WebElementFacade iFrameEle;

	@FindBy(xpath = "//*[@id='asdf']/input[contains(@value,'Continue')]")
	private WebElementFacade continueBtnEleInOutOfBusinessFrame;

	@FindBy(xpath = "//div[@class='Search_Criteria search_searchCriteria']//div[@class='searchNowBtn']/a")
	private WebElementFacade searchNowBtnClick;

	private String documnetDescription;

	private String dnbiPricingScreenText;

	private String gftTitleTxt;

	private String searchResultsType;

	private String compInvestConfirmPgTitle;

	// Decision Maker Screen Web Elements
	@FindBy(xpath = "//*[@id='main']//table[@class='results full']//tbody//tr//td//a[contains(.,'Apply for Credit')]")
	private WebElementFacade applyForCreditLinkEle;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='dmForm1']/h3")
	private WebElementFacade compIdentPgTitleEle;

	private String compIdentPageTitleVal;

	@FindBy(xpath = "//*[@class='outerDiv']//input[contains(@value,'Submit')]")
	private WebElementFacade submitButtonEle;

	@FindBy(xpath = "//*[@id='backRight']//input[contains(@value,'Next')]")
	private WebElementFacade nextButtonEle;

	@FindBy(xpath = "//*[@id='SearchResultsForm']//table[@class='results full']//tbody/tr//td[2]")
	private WebElementFacade compNameEleFromSearchResults;

	@FindBy(xpath = ".//*[@class='outerDiv']//*[@id='backRight']//*[contains(@value,'ext')]")
	private WebElementFacade nextBtnCreateAccPage;

	@FindBy(xpath = "//*[@class='clear']//table//tbody//tr[1]//a[contains(@href,'javascript:showCompany')]")
	private WebElementFacade phoneSearchResultliveReport;

	@FindBy(xpath = "//*[@class='modal_content']//*[@id='modal_buttons']//input[@type='button'][@value='Yes']")
	private WebElementFacade modalYesBtn;

	@FindBy(xpath = "//*[@id='duns']//li[contains(@class,'first')]")
	private WebElementFacade liveReportPageElement;

	@FindBy(xpath = "//*[@id='main']//*[contains(@class,'results full')]//thead")
	private WebElementFacade phoneNoSearchResultsThead;

	@FindBy(xpath = "//*[@id='serachContainer1']//*[@id='serachResult12Div']//iframe[@name='showLocationSearch']")
	private WebElementFacade locationSearchIframe;

	@FindBy(xpath = "//*[contains(@class,'Search_Criteria')]//*[contains(@class,'search_orderInvestPosition')]//a[@id='orderInvestigationLnkCss']//strong")
	private WebElementFacade orderInvestigationLinkeleemnt;

	@FindBy(xpath = "//*[@id='main']//table[@class='results full_company']//tbody//tr//td[3]")
	private List<WebElementFacade> countryNamesInAdvSearchResultsList;
	@FindBy(xpath = "//*[@id='main']//table[@class='results full']//tbody//tr//td[2]")
	private List<WebElementFacade> countryNamesInSearchResultsList;

	@FindBy(xpath = "//div[@class='action_header']//div[@id='parentActionDetails']//span//a")
	private WebElementFacade orderCountryRiskReports;

	@FindBy(xpath = "//body[@class='iframe_modal']//div[@class='modal_inner_content']//div[@class='entcommon']//tr[1]//input[@value='Order']")
	private WebElementFacade firstOrderButton;

	@FindBy(xpath = "//body[@class='iframe_modal']//div[@class='modal_inner_content']//div[@class='entcommon']//tr[2]//input[@value='Order']")
	private WebElementFacade secondOrderButton;
	
	@FindBy(xpath = "//*[@id='main']//*[@id='SearchResultsForm']//table/tbody/tr/td/a/strong[contains(text(),'Order investigation from D&B')]")
	private WebElementFacade orderInvLink;
	
	@FindBy(xpath = "//*[@id='main']//*[@class='widget_form']/div//*[@value='Order']")
	private WebElementFacade orderBttn;
	
	@FindBy(xpath = "//*[@id='main']//*[@class='widget_form']/table/tbody//*[@id='state']")
	private WebElementFacade stateDrop;

	String investigationHeaderXpath = "//*[@id='main']//h3[contains(.,'Investigation Information')]";
	String locationSearchIframeXpath = "//*[@id='serachContainer1']//*[@id='serachResult12Div']//iframe[@name='showLocationSearch']";
	String phoneNoSearchResultsTheadXpath = "//*[@id='main']//*[contains(@class,'results full')]//thead";

	private String companyNameVal;
	String modalYesBtnXpath = "//*[@class='modal_content']//*[@id='modal_buttons']//input[@type='button'][@value='Yes']";
	private String liveReportPage = "//*[@id='duns']//li[contains(@class,'first')]";
	private String liveReportPageapplicationID = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Online Credit Application')]";
	String accountecfpagHeader = "//*[@id='main']//h2";
	String searchResultsTableXpath = "//*[@id='main']//table[@class='results full']//tbody";

	// Get the search result type
	public String getSearchResultType() {

		searchResultsType = searchResultEle.getText();

		return searchResultsType;
	}

	public String getSearchResultsAppid() {
		// if (searchResultEle.isPresent()) {
		searchResultsType = searchResultsappidEle.getText();
		// }

		return searchResultsType;
	}

	public void clickSearchNowBtn() {
		if (searchNowBtnClick.isPresent()) {
			searchNowBtnClick.waitUntilClickable();
			UIHelper.highlightElement(getDriver(), searchNowBtnClick);
			searchNowBtnClick.click();
		} else {
			System.out.println("Search Now button not available");
		}
	}

	
    public void OrderinvestDisplayedSearchResultsS() {     	
    	if (orderInvLink.isPresent()) {
    		orderInvLink.waitUntilClickable();
    		UIHelper.highlightElement(getDriver(), orderInvLink);
    		orderInvLink.click();
    	} 
	}

    public void OrdInvSubmitted() {
    	UIHelper.waitForPageToLoad(getDriver());
    	if (stateDrop.isPresent()) {
    		stateDrop.selectByVisibleText("California");
    		orderBttn.waitUntilClickable();
    		UIHelper.highlightElement(getDriver(), orderBttn);
    		orderBttn.click();
    	}
    }


	// Get the Company Name
	public String getCompName() {
		if (compNameEleFromSearchResults.isPresent()) {
			companyNameVal = compNameEleFromSearchResults.getText();
		}

		return companyNameVal;
	}

	// The selected companies have been added
	public void selectCompanyFromSearchResultsAndGotoECFPage() throws Exception {

		try {

			if (tabResultsEle.isPresent()) {

				if (radioBTNCreatAccFromAccMGRTab.isPresent()) {

					radioBTNCreatAccFromAccMGRTab.click();
				}

			} else if (earningMsgEle.isPresent()) {

				notListedRadioBtnEle.click();

			}

			if (nextButtonCreatAccFromAccMGRTab.isPresent()) {

				nextButtonCreatAccFromAccMGRTab.click();
				outerDivElement.waitUntilPresent();
				UIHelper.waitForPageToLoad(getDriver());
			}

			if (orderInternationalNextBtnEle.isPresent()) {

				orderInternationalNextBtnEle.click();
				outerDivElement.waitUntilPresent();
				UIHelper.waitForPageToLoad(getDriver());
			}

		} catch (Exception e) {

		}

	}

	public void getSearchText() {

		try {
			if (resultsinTableElements.size() > 0) {

				for (WebElementFacade findText : resultsinTableElements) {
					allText.add(findText.getText());
				}

			} else {

			}
		} catch (NoSuchElementException E) {

		} catch (NullPointerException E) {

		}

	}

	public void performSearch() {

		searchNowBtn.click();
		searchResultscompText.waitUntilPresent();
	}

	/**********************************************************************************************
	 * Function: pullLiveReportAndGotoECFPage Method Description: 1. Pull The
	 * Live Report by clicking the search results and navigate to ECF Page
	 * 
	 ***********************************************************************************************/
	public void pullLiveReportAndGotoECFPage() throws Exception {
		if (searchResultliveReport.isPresent()) {

			searchResultliveReport.click();
			// UIHelper.waitForPageToLoad(getDriver());

			/*
			 * if (iFrameEle.isPresent()) {
			 * getDriver().switchTo().frame(iFrameEle); if
			 * (continueBtnEleInOutOfBusinessFrame.isDisplayed()) {
			 * continueBtnEleInOutOfBusinessFrame.click(); }
			 * getDriver().switchTo().defaultContent();
			 * UIHelper.waitForPageToLoad(getDriver()); }
			 */

			/*
			 * if (iFrameEle.isPresent()) {
			 * getDriver().switchTo().frame(iFrameEle);
			 * 
			 * 
			 * getDriver().switchTo().defaultContent();
			 * UIHelper.waitForPageToLoad(getDriver());
			 * 
			 * }
			 * 
			 * UIHelper.waitForPageToLoad(getDriver());
			 * UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
			 * loadingJavaScriptPageXpath);
			 */

		}

		if (internationalOrderViewReport.isPresent()) {
			internationalOrderViewReport.click();
			/*
			 * UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
			 * loadingJavaScriptPageXpath);
			 * UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
			 * ajaxLoadingEleXpath);
			 */
		}

		/*
		 * UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
		 * ajaxLoadingEleXpath); UIHelper.waitForPageToLoad(getDriver())
		 */;
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), liveReportPage);
	}

	public void pullLiveReportSearchResults() {

		if (searchResultliveReport.isPresent()) {

			searchResultliveReport.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), liveReportPage);
		}

	}

	public void pullAppIDReportSearchResults() {

		if (searchResultsappidEle.isPresent()) {

			searchResultsappidEle.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					liveReportPageapplicationID);
		}

	}

	public void clickOrderInvestigationInSearchResultsPage() {
		if (orderInvestigationLink.isPresent()) {
			orderInvestigationLink.click();
			UIHelper.waitForPageToLoad(getDriver());
		}
	}

	public void performOrderInvestigationFromSearchResults(String companyName,
			String stateOrProvince, String cityOrTown,
			String additionalInformation, String levelOfInvestigation,
			String emailTheInvestReport) throws Exception {

		try {
			if (orderBtn.isPresent()) {
				companyNameFieldEle.type(companyName);
				cityOrTownEle.type(cityOrTown);
				additionalInfoTextArea.type(additionalInformation);

				if (levelOfInvestigation.equalsIgnoreCase("Standard")) {
					standardRadioBtnEle.click();
				} else if (levelOfInvestigation.equalsIgnoreCase("Priority")) {
					priorityRadioBtnEle.click();
				}

				if (emailTheInvestReport.equalsIgnoreCase("Yes")) {
					emailInvestReportChkboxEle.click();
				}

				orderBtn.waitUntilClickable();
				orderBtn.click();
				backToSearchResultsBtn.waitUntilClickable();
				UIHelper.waitForPageToLoad(getDriver());
			}

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public boolean clickCountryRiskReportPage() {
		UIHelper.highlightElement(getDriver(), orderCountryRiskReports);
		orderCountryRiskReports.click();
		getDriver().switchTo().frame("__modal_iframe_target");
		UIHelper.highlightElement(getDriver(), firstOrderButton);
		UIHelper.highlightElement(getDriver(), secondOrderButton);
		if (firstOrderButton.isDisplayed() && secondOrderButton.isDisplayed()) {
			return true;
		} else
			return false;
	}

	public String getCompanyInvestReqConfirmPgTitle() {
		if (compInvestReqConfirmEle.isPresent()) {
			compInvestConfirmPgTitle = compInvestReqConfirmEle.getText();
		}

		return compInvestConfirmPgTitle;
	}

	public void clickBackToSearchResults() {
		backToSearchResultsBtn.click();
		dashBoardTabEle.waitUntilPresent();
		UIHelper.waitForPageToLoad(getDriver());
	}

	public void createAccountFromSearchResults(String dunsNumber)
			throws Exception {

		try {

			String searchResultCreateAcntLinkXpath = "//*[@id='main']//*[@class='results full']//tbody//tr//td[contains(.,'"
					+ dunsNumber
					+ "')]//following-sibling::td//a[contains(.,'Create Account')]";

			WebElementFacade searchResultCreateAcntLinkEle = find(By
					.xpath(searchResultCreateAcntLinkXpath));

			if (searchResultCreateAcntLinkEle.isPresent()) {

				searchResultCreateAcntLinkEle.click();
				outerDivElement.click();
				UIHelper.waitForPageToLoad(getDriver());

				if (orderInternationalNextBtnEle.isPresent()) {

					orderInternationalNextBtnEle.click();
					UIHelper.waitForPageToLoad(getDriver());
				}

			}

		} catch (Exception E) {

		}
	}

	/**********************************************************************************************
	 * Function: validateGFTFromSearchResults Method Description: 1. Click the
	 * GFT Link in Search Results 2. Get the DNBi Pricing Screen alert message
	 * description
	 * 
	 ***********************************************************************************************/
	public String validateGFTFromSearchResults() {
		if (additionalProductLinkEle.isPresent()) {
			additionalProductLinkEle.click();
			additionalProductInfoBoxEle.waitUntilPresent();

			if (gftLinkEle.isPresent()) {
				gftLinkEle.click();
				UIHelper.waitForPageToLoad(getDriver());

				iFrameEle.waitUntilPresent();

				if (iFrameEle.isPresent()) {
					getDriver().switchTo().frame(iFrameEle);

					if (okButtonEleInDNBiPricingScreen.isPresent()) {
						okButtonEleInDNBiPricingScreen.click();
						getDriver().switchTo().defaultContent();
						UIHelper.waitForPageToLoad(getDriver());
						UIHelper.waitForInvisibilityOfAjaxImgByXpath(
								getDriver(), imageLoadingXpath);
					} else {
						dnbiPricingScreenText = dnbiPricingScreenTextEle
								.getText();
						closeFrameEle.click();
						getDriver().switchTo().defaultContent();
					}
				}
			}
		}

		return dnbiPricingScreenText;
	}

	/**********************************************************************************************
	 * Function: getGFTTitle Method Desctription: Get the GFT Title
	 * 
	 * 
	 ***********************************************************************************************/
	public String getGFTTitle() {
		if (gftSubHeadingEle.isPresent()) {
			gftTitleTxt = gftSubHeadingEle.getText();
		}

		return gftTitleTxt;
	}

	/**********************************************************************************************
	 * Function: getCompanyDescriptionFromSearchResults Method Desctription: 1.
	 * Click the Company Documents Link in Search Results 2. Select the first
	 * document and Download 3. Get Company Document Description
	 * 
	 * 
	 ***********************************************************************************************/
	public String getCompanyDescriptionFromSearchResults() {
		if (additionalProductLinkEle.isPresent()) {
			additionalProductLinkEle.click();
			additionalProductInfoBoxEle.waitUntilPresent();

			if (compDocsEle.isPresent()) {
				compDocsEle.click();
				UIHelper.waitForPageToLoad(getDriver());

				iFrameEle.waitUntilPresent();

				if (iFrameEle.isPresent()) {
					getDriver().switchTo().frame(iFrameEle);

					if (chBoxOptionEleForSelectCompDocs.isPresent()) {
						chBoxOptionEleForSelectCompDocs.click();
						documnetDescEle.waitUntilPresent();

						documnetDescription = documnetDescEle.getText();

						downloadSelectBtnEleInCompDocs.click();
						UIHelper.waitForPageToLoad(getDriver());
						closeFrameEle.click();
						getDriver().switchTo().defaultContent();
						UIHelper.waitForPageToLoad(getDriver());
					} else {
						closeFrameEle.click();
						getDriver().switchTo().defaultContent();
					}

				}
			}
		}

		return documnetDescription;
	}

	/****************************************************************************************
	 * Function: Verify the placing of application by clicking Apply For Credit
	 * link in Search.
	 * 
	 * 
	 ****************************************************************************************/
	public void clickApplyForCreditLinkInSearchResults() throws Exception {
		try {
			applyForCreditLinkEle.waitUntilPresent();
			if (applyForCreditLinkEle.isPresent()) {
				applyForCreditLinkEle.click();
				UIHelper.waitForPageToLoad(getDriver());
				submitButtonEle.waitUntilPresent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/****************************************************************************************
	 * Function: Get the Company Identification Page title.
	 * 
	 * 
	 ****************************************************************************************/
	public String getCompIdentPageTitle() {
		if (compIdentPgTitleEle.isPresent()) {
			compIdentPageTitleVal = compIdentPgTitleEle.getText();
		}

		return compIdentPageTitleVal;
	}

	/****************************************************************************************
	 * Function: Click the Submit button and verify the application submission
	 * in application. Input : NA Action : Click Output : Submit button should
	 * be click.
	 ****************************************************************************************/
	public void submitApplication() throws Exception {
		try {
			// Submitting Application Details
			submitButtonEle.click();
			UIHelper.waitForPageToLoad(getDriver());
			nextButtonEle.waitUntilClickable();
			if (nextButtonEle.isPresent()) {
				nextButtonEle.click();
				UIHelper.waitForPageToLoad(getDriver());
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						ajaxLoadingEleXpath);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Click Create Account Link in Search Results and navigate to ECF Page
	public void clickCreateAcntLinkAndgotoECFpage(String dunsNumber)
			throws Exception {

		try {

			String searchResultCreateAcntLinkXpath = "//*[@id='main']//*[@class='results full']//tbody//tr//td[contains(.,'"
					+ dunsNumber
					+ "')]//following-sibling::td//a[contains(.,'Create Account')]";

			WebElementFacade searchResultCreateAcntLinkEle = find(By
					.xpath(searchResultCreateAcntLinkXpath));

			if (searchResultCreateAcntLinkEle.isPresent()) {

				searchResultCreateAcntLinkEle.click();
				outerDivElement.waitUntilPresent();
				UIHelper.waitForPageToLoad(getDriver());

				if (orderInternationalNextBtnEle.isPresent()) {

					orderInternationalNextBtnEle.click();
					UIHelper.waitForPageToLoad(getDriver());
					ecfHeaderEle.waitUntilPresent();
					if (ecfHeaderEle.isPresent()) {
						UIHelper.highlightElement(getDriver(), ecfHeaderEle);
					}
				}

				// nextBtnCreateAccPage.waitUntilClickable();

			}

		} catch (Exception E) {

		}
	}

	public void gotoECFFromAccManagerSearch() throws Exception {

		try {

			if (tabResultsEle.isPresent()) {

				if (radioBTNCreatAccFromAccMGRTab.isPresent()) {

					radioBTNCreatAccFromAccMGRTab.click();
				}
			} else if (earningMsgEle.isPresent()) {

				notListedRadioBtnEle.click();
			}

			if (nextButtonCreatAccFromAccMGRTab.isPresent()) {

				nextButtonCreatAccFromAccMGRTab.click();
				outerDivElement.waitUntilPresent();
				UIHelper.waitForPageToLoad(getDriver());
			}

			// waitFor(2000).milliseconds();
			if (orderInternationalNextBtnEle.isPresent()) {

				orderInternationalNextBtnEle.click();
				outerDivElement.waitUntilPresent();
				UIHelper.waitForPageToLoad(getDriver());
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void pullLiveReportforOobDuns() {

		if (searchResultliveReport.isPresent()) {

			searchResultliveReport.click();

		}

	}

	public boolean verify_PhoneNoSearch_Results_has_Displayed() {
		try {
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					locationSearchIframeXpath);
			getDriver().switchTo().frame(locationSearchIframe);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					phoneNoSearchResultsTheadXpath);
			return true;

		} catch (Exception e) {
			return false;
		}
	}

	public void pullLiveReportfromPhoneNoSearch() {

		if (phoneSearchResultliveReport.isPresent()) {
			phoneSearchResultliveReport.click();
			getDriver().switchTo().defaultContent();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					modalYesBtnXpath);

		}

	}

	public boolean verify_Branch_Location_Popup() {
		try {
			modalYesBtn.isVisible();
			UIHelper.highlightElement(getDriver(), modalYesBtn);
			return true;

		} catch (Exception e) {
			return false;
		}
	}

	public void click_yes_Btn_In_Branch_Popup() {

		if (modalYesBtn.isPresent()) {

			modalYesBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), liveReportPage);

		}

	}

	public boolean verify_Live_Report_Has_Displayed() {
		try {
			liveReportPageElement.isVisible();
			UIHelper.highlightElement(getDriver(), liveReportPageElement);
			return true;

		} catch (Exception e) {
			return false;
		}
	}

	public void click_orderInvestigationLinkeleemnt() {

		if (orderInvestigationLinkeleemnt.isPresent()) {
			UIHelper.highlightElement(getDriver(),
					orderInvestigationLinkeleemnt);
			orderInvestigationLinkeleemnt.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					investigationHeaderXpath);

		}

	}

	public void pullAccnoReportSearchResults() {

		if (searchResultsappidEle.isPresent()) {

			searchResultsappidEle.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					accountecfpagHeader);
		}

	}

	public boolean verify_CountryName_In_AdvanceResults(String CountryName) {
		System.out.println("Filter results list size======================="
				+ countryNamesInAdvSearchResultsList.size());
		if (countryNamesInAdvSearchResultsList.size() > 0) {
			for (WebElementFacade list : countryNamesInAdvSearchResultsList) {
				UIHelper.mouseOveranElement(getDriver(), list);
				if (list.getText().contains(CountryName)) {
					break;
				}
			}
			return true;
		} else {
			return false;
		}
	}
	public boolean verify_CountryName_In_Results(String CountryName) {
		System.out.println("Filter results list size======================="
				+ countryNamesInSearchResultsList.size());
		if (countryNamesInSearchResultsList.size() > 0) {
			for (WebElementFacade list : countryNamesInSearchResultsList) {
				UIHelper.mouseOveranElement(getDriver(), list);
				if (list.getText().contains(CountryName)) {
					break;
				}
			}
			return true;
		} else {
			return false;
		}
	}
}
