package com.dnb.automation.dnbcom.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;
import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * OrderCompletedPage.java - Program consists of the following actions 1.
 * Clicking on the button View Report 2. Verifying navigation to the Report page
 *
 * @author Kumaran Balasubramaniam
 ***********************************************************************************************/

public class OrderCompletedPage extends PageObject {
    // Locators for elements View Report, Report Page element(next page element)

    @FindBy(xpath = ".//*[@id='submitViewReport3']")
    private WebElementFacade viewReportButton;

    @FindBy(xpath = "html/body/pre")
    private WebElementFacade reportPage;

    @FindBy(xpath = "//p[1]/a[contains(.,img[@alt='Company Reports'])]")
    private WebElementFacade CompanyReports;

    // To check report availability

    public boolean hasViewReportButton() {
        if (viewReportButton.isPresent()) {
            return true;
        } else {
            return false;
        }
    }

    // To click the button View Report

    public void clickViewReportButton() throws Exception {
        try {
            if (viewReportButton.isPresent()) {
                UIHelper.highlightElement(getDriver(), viewReportButton);
                viewReportButton.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    // To Click the link CompanyReports

    public void clickCompanyReports() throws Exception {
        try {
            if (CompanyReports.isPresent()) {
                UIHelper.highlightElement(getDriver(), CompanyReports);
                CompanyReports.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    // To wait for navigation to the Report page

    public void waitForReportPage() throws Exception {
        try {
            reportPage.waitUntilPresent();
        } catch (Exception e) {
            throw e;
        }
    }
}
