package com.dnb.automation.dnbcom.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;
import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * DomesticSearchCompanyPage.java - Program consists of the following actions 1.
 * Passing the Duns number and to click on the button Search 2. Verifying
 * navigation to the Search Results page
 *
 * @author Kumaran Balasubramaniam
 ***********************************************************************************************/

public class SearchPage extends PageObject {
    // Locators for the elements Duns number, Search button, International
    // search link, Search results page element, International search page
    // element and Search failed page element

    @FindBy(xpath = "//input[@name='INPUTDUNS']")
    private WebElementFacade dunsnumber;

    @FindBy(xpath = "//table[2]/tbody/tr/td/form/table/tbody[contains(.,input[@name='INPUTDUNS'])]/tr/td/font/select[@name='COUNTRYCODEALPHA']")
    private WebElementFacade countryname;

    @FindBy(xpath = "//input[@name='INPUTDUNS']/../../td/b/input[@value=' Search ']")
    private WebElementFacade domesticsearchbutton;

    @FindBy(xpath = "//table[2]/tbody/tr/td/form/table/tbody[contains(.,input[@name='INPUTDUNS'])]/tr/td/font/b/input[@value=' Search ']")
    private WebElementFacade internationalsearchbutton;

    @FindBy(xpath = "//a[contains(.,'Domestic (US) searches')]")
    private WebElementFacade domesticsearchlink;

    @FindBy(xpath = "//a[contains(.,'International searches')]")
    private WebElementFacade internationalsearchlink;

    @FindBy(xpath = "//input[@value='New Search']")
    private WebElementFacade NewSearch;

    // To check we are in search page having domestic search

    public boolean hasDomesticSearch() {
        if (domesticsearchbutton.isPresent()) {
            return true;
        } else {
            return false;
        }
    }

    // To check we are in search page having international search

    public boolean hasInternationalSearch() {
        if (internationalsearchbutton.isPresent()) {
            return true;
        } else {
            return false;
        }
    }

    // To pass duns number and click Search button for domestic search

    public void domesticSearchforDuns(String Duns) throws Exception {
        enterDuns(Duns);
        clickDomesticSearchButton();
    }

    // To pass duns number and country and click Search button for international
    // search

    public void internationalSearchforDuns(String Duns, String Country)
            throws Exception {
        enterDuns(Duns);
        selectCountry(Country);
        clickInternationalSearchButton();
    }

    // To pass duns number

    public void enterDuns(String Duns) throws Exception {
        try {
            UIHelper.highlightElement(getDriver(), dunsnumber);
            dunsnumber.type(Duns);
        } catch (Exception e) {
            throw e;
        }
    }

    // To pass country name

    public void selectCountry(String Country) throws Exception {
        try {
            UIHelper.highlightElement(getDriver(), countryname);
            countryname.selectByVisibleText(Country);
        } catch (Exception e) {
            throw e;
        }
    }

    // To click Search button for domestic search

    public void clickDomesticSearchButton() throws Exception {
        try {
            if (domesticsearchbutton.isPresent()) {
                UIHelper.highlightElement(getDriver(), domesticsearchbutton);
                domesticsearchbutton.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    // To click Search button for international search

    public void clickInternationalSearchButton() throws Exception {
        try {
            if (internationalsearchbutton.isPresent()) {
                UIHelper.highlightElement(getDriver(),
                        internationalsearchbutton);
                internationalsearchbutton.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    // To Check is this Page has domestic search link in the sense it is in
    // international search

    public boolean hasDomesticSearchLink() {
        if (domesticsearchlink.isPresent()) {
            return true;
        } else {
            return false;
        }
    }

    // To click the domestic search link

    public void clickDomesticSearchLink() throws Exception {
        try {
            if (domesticsearchlink.isPresent()) {
                UIHelper.highlightElement(getDriver(), domesticsearchlink);
                domesticsearchlink.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // To Check is this Page has international search link in the sense it is in
    // domestic search

    public boolean hasInternationlSearchLink() {
        if (internationalsearchlink.isPresent()) {
            return true;
        } else {
            return false;
        }
    }

    // To click International Search link

    public void clickInternationalSearchLink() throws Exception {
        try {
            if (internationalsearchlink.isPresent()) {
                UIHelper.highlightElement(getDriver(), internationalsearchlink);
                internationalsearchlink.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    // To Check is this Report Page

    public boolean hasReportPage() {
        if (NewSearch.isPresent()) {
            return true;
        } else {
            return false;
        }
    }

    // To click the button New Search

    public void clickNewSearchButton() throws Exception {
        try {
            if (NewSearch.isPresent()) {
                UIHelper.highlightElement(getDriver(), NewSearch);
                NewSearch.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
