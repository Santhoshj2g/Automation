package com.dnb.automation.DBAI.pages;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 630239 on 5/9/2017.
 */
public class ReportPage extends PageObject{

    String Title ="//table/tbody/tr/td[contains(text(),'SERENITY')]";
    String Dunsno =".//*[@id='ID_SPContent']//table/tbody/tr/td[@class='data' AND text()='DUNS']";

    @FindBy(xpath = ".//*[@id='RSKASMT_SPContent']//td[contains(text(),'Risk Indicator')]/parent::tr/td[4]")
    private WebElementFacade dnbRat;

    @FindBy(xpath = ".//*[@id='RSKASMT_SPContent']//table/tbody/tr/td[contains(text(),'Failure Score')]/parent::tr/td[4]")
    private WebElementFacade failScore1;

    @FindBy(xpath = ".//*[@id='ID_SPContent']//table/tbody/tr/td[contains(text(),'Failure Score')]/following-sibling::td/a")
    private WebElementFacade failScore2;

    @FindBy(xpath = ".//*[@id='RSKASMT_SPContent']//table/tbody/tr/td[contains(text(),'Maximum Credit')]/following-sibling::td[1]")
    private WebElementFacade maxCredit1;

    @FindBy(xpath = ".//*[@id='RSKASMT_SPContent']//table/tbody/tr/td[contains(text(),'Maximum Credit')]/parent::tr/td[3]")
    private WebElementFacade maxCredit2;

    @FindBy(xpath = ".//table[@id='RSKASMT_SPContent']//table[@class='databox']/tbody/tr/td/ul")
    private List<WebElementFacade> commentryText;

    @FindBy(xpath = ".//*[@id='RSKASMT_SPContent']//td[contains(text(),'Financial Strength')]/parent::tr/td[4]")
    private WebElementFacade finStrength;
    
    @FindBy(xpath = ".//*[@id='IDContent']//table/tbody/tr/td[contains(text(),'Delinquency Score')]/following-sibling::td[1]/a")
    private WebElementFacade delinquencyScore;
    
    @FindBy(xpath = ".//*[@id='RSKASMTContent']//table/tbody/tr[7]/td[2][contains(text(), 'Incidence of delinquency')]/following-sibling::td[1]/b")
    private WebElementFacade probOfDelinquency;
    
    @FindBy(xpath = ".//*[@id='RSKASMTContent']//table/tbody/tr[7]/td[2][contains(text(), 'Incidence of delinquency')]/following-sibling::td[1]")
    private WebElementFacade incOfDelinquency;
    
    @FindBy(id="REPORT_TITLE")
    private WebElementFacade euroReportTitle;
    
    @FindBy(xpath="//*[@id='riskEvaluationTable']/tbody/tr[3]/td[2]/a")
    private WebElementFacade failureScoreEuroRep;
    
    String commentryTextpath= ".//table[@id='RSKASMT_SPContent']//table[@class='databox']/tbody/tr[num]/td/ul";

    public boolean verifyTitle(String reportTitle) throws Exception {

        UIHelper.switchToChildWindow1(getDriver());
    	UIHelper.waitForPageToLoad(getDriver());
        try {
            Alert alert = getDriver().switchTo().alert();
            alert.accept();
        } catch (Exception e) {

        } finally {

            System.out.println("No alert is present");
            getDriver().manage().window().maximize();
            UIHelper.waitForPageToLoad(getDriver());

            String actualTitleXpath = Title.replace("SERENITY", reportTitle);
            WebElementFacade actualTitle = find(By.xpath(actualTitleXpath));
            if (actualTitle.getText().contains(reportTitle))
                return true;
            else
                return false;
        }
    }
    
    public boolean verifyEuroReportTitle(String reportTitle) throws Exception  {
    	
        UIHelper.switchToChildWindow1(getDriver());
        Thread.sleep(20000);
    	UIHelper.waitForPageToLoad(getDriver());
        
         System.out.println(reportTitle);
         String actualReportTitle = getDriver().getTitle();
         System.out.println(actualReportTitle);
         if (actualReportTitle.contains(reportTitle))
             return true;
         else
             return false;
     
    }

    public boolean verifyDunsno(String duns) {
        String actualDunsnoXpath = Dunsno.replace("DUNS",duns.substring(2,'-').substring(5,'-'));
        WebElementFacade actualDunsno = find(By.xpath(actualDunsnoXpath));
        duns = duns.substring(2,'-').substring(5,'-');
        if(actualDunsno.getText().equalsIgnoreCase(duns))
        return true;
        else
            return false;
    }

    public String verifyDnbRat() {
       UIHelper.highlightElement(getDriver(),dnbRat);
        String dnbRattext =dnbRat.getText();
        return dnbRattext.trim();
    }

    public void closeReportWindow() {
        UIHelper.closeCurrentWindow(getDriver());

    }
    
    public void closeDBAI(){
    	getDriver().quit();
    }

    public String verifyFailScore() {
        UIHelper.highlightElement(getDriver(),failScore1);
        UIHelper.highlightElement(getDriver(),failScore2);
        if(failScore1.isPresent()) {
            String failScoretext1 = failScore1.getText().replace("out of 100", "").trim();
            return failScoretext1;
        }else
            return null;
    }
    
    public String verifyFailScoreEuroReport() {
        UIHelper.highlightElement(getDriver(),failureScoreEuroRep);
        if(failureScoreEuroRep.isPresent()) {
            String failScoretext1 = failureScoreEuroRep.getText();
            return failScoretext1;
        }else
            return null;
    }

    public String verifyMaxCredit() {
        UIHelper.highlightElement(getDriver(),maxCredit2);
        String maxCredittext1 =maxCredit1.getText().substring(2, Integer.parseInt(",")).replace(" € ","");
        String maxCredittext2 =maxCredit2.getText().trim();
        if(maxCredittext2.contains("€"))
      return maxCredittext2.substring(0,maxCredittext2.length()-1).replace(",","");
        else
            return maxCredittext2.trim();
    }

    public List<String> verifyCommentry() throws Exception {

        List<String> actual = new ArrayList<>();
        if (!commentryText.isEmpty()) {
            for (int i = 0; i < commentryText.size(); i++) {
                WebElementFacade actualCommentry = find(By.xpath(commentryTextpath.replace("num",String.valueOf(i+2))));
                UIHelper.highlightElement(getDriver(), actualCommentry);
                actual.add(actualCommentry.getText().toString());
            }
        }
            return actual;
        }


    public String verifyFinStrength() {
        UIHelper.highlightElement(getDriver(),finStrength);
        return finStrength.getText().trim();
    }
    
    public String verifyDelinquencyScore() {
        UIHelper.highlightElement(getDriver(),delinquencyScore);
        return delinquencyScore.getText().trim();
    }
    
    public String verifyProbOfDelinquency() {
        String result="";
        UIHelper.waitForPageToLoad(getDriver());
        if(probOfDelinquency.isPresent()){
        	UIHelper.scrollToAnElement(probOfDelinquency);
            UIHelper.highlightElement(getDriver(),probOfDelinquency);
            result= probOfDelinquency.getText().trim();
        }
        return result;
        
    }
    public String verifyIncOfDelinquency() {
        String result="";
        UIHelper.waitForPageToLoad(getDriver());
        if(incOfDelinquency.isPresent()){
        	UIHelper.scrollToAnElement(incOfDelinquency);
            UIHelper.highlightElement(getDriver(),incOfDelinquency);
            result= incOfDelinquency.getText().trim();
        }
        return result;
    }
}