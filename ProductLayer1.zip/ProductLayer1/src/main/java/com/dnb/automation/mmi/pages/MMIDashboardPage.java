package com.dnb.automation.mmi.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.FileUtil;
import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

/**********************************************************************************************
 * MMIDashboardPage.java - This program contains methods for MMI - Dash-board page validations
 *
 * @author Duvvuru Naveen
 ***********************************************************************************************/
public class MMIDashboardPage extends PageObject {
	
	@FindBy(xpath = ".//*[@id='main']//*[@id='navbar']//*[@class='nav navbar-nav navbar-right']")
    private WebElementFacade gViewheaderEle;
	
	@FindBy(xpath = ".//*[@id='main']//*[@id='UserDropdown']")
	private WebElementFacade gViewloginas;

    @FindBy(xpath = ".//*[@id='main']//*[@id='navbar']/ul")
    private WebElementFacade dashBoardMenu;
    
    @FindBy(xpath = ".//*[@id='main']//*[@id='navbar']/ul/li[1]/a")
    private WebElementFacade dashBoard;
     
    @FindBy(xpath = ".//*[@id='main']//*[@id='dataExBit']//*[@id='dataExplorer']")
    private WebElementFacade dashboarddataexplorer;
    
    @FindBy(xpath = ".//*[@id='main']//*[@id='chartBit']//*[@id='chartTabs']")
    private WebElementFacade dashboardmaptab;
    
    @FindBy(xpath = ".//*[@id='main']//*[@id='tabBit']//*[@id='tabs']")
    private WebElementFacade dashboarddatatab;
    
    @FindBy(xpath = ".//*[@id='main']//*[@id='mapBit']//*[@id='mapTabs']")
    private WebElementFacade dashboardcharttab;
    
    @FindBy(xpath = ".//*[@id='main']//*[@id='layerBit']//*[@id='mapInfoTabs']")
    private WebElementFacade dashboardmapinfotab;
    
    @FindBy(xpath = ".//*[@id='NavigatorButtonContainer']//*[@id='OpenDataExplorerButton']")
    private WebElementFacade openDataExplorerEle;
    
    @FindBy(xpath = ".//*[@id='DataExplorerArea']/ul")
    private WebElementFacade datasetsEle;
    
    public WebElementFacade getDatasetsEle() {
        return datasetsEle;
    }
    
    @FindBy(xpath = ".//*[@id='dataxSearch']//*[@id='dataxSearchbox']")
    private WebElementFacade datasetsSearchFieldEle;
    
    @FindBy(xpath = ".//*[@id='dataxSearch']//*[@id='dataExplorerSearchButton']")
    private WebElementFacade datasetsSearchBtnEle;

    @FindBy(xpath = ".//*[@id='DataExplorerArea']/ul/li/span/a")
    private WebElementFacade searchResultEleForDataset;
    
    public WebElementFacade getSearchResultEleForDataset() {
        return searchResultEleForDataset;
    }
    
    @FindBy(xpath = ".//*[@id='DataExplorerArea']/ul/li/ul/li[1]/span/a")
    private WebElementFacade firstChildFirstElement;
    
    @FindBy(xpath = ".//*[@id='DataExplorerArea']/ul/li/ul/li/span/a")
    private List<WebElement> firstChildListElements;
    
    @FindBy(xpath = ".//*[@id='DataExplorerArea']/ul/li/ul/li/ul/li[1]/span/a")
    private WebElementFacade secondChildFirstElement;
    
    @FindBy(xpath = ".//*[@id='DataExplorerArea']/ul/li/ul/li/ul/li/span/a")
    private List<WebElement> secondChildListElements;
    
    @FindBy(xpath = ".//*[@id='chart1_svg']//*[@class='yaxislabel']")
    private WebElementFacade datsetEleInChartArea;
    
    @FindBy(xpath = ".//*[@id='chartTabsSettingsButton']")
    private WebElementFacade mapSettingsBtnEle;
    
    @FindBy(xpath = ".//*[@id='mapTabsSettingsButton']")
    private WebElementFacade chartSettingsBtnEle;
    
    @FindBy(xpath = ".//*[@class='ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix ui-draggable-handle']/span[contains(.,'Map Settings')]")
    private WebElementFacade mapSettingsPopupEle;

    public WebElementFacade getMapSettingsPopupEle() {
        return mapSettingsPopupEle;
    }
    
    @FindBy(xpath = ".//*[@id='AdvancedMapSearchInput']")
    private WebElementFacade advSearchFieldEle;
    
    @FindBy(xpath = ".//*[@id='AdvancedMapSearchButton']")
    private WebElementFacade advSearchBtnEle;
    
    @FindBy(xpath = ".//*[@id='AdvanceMapSearchResults']/p[1]/span[1]")
    private WebElementFacade firstSearchResultEleInAdvSearchResults;
    
    @FindBy(xpath = ".//*[@id='chartarea']//*[@id='chart1_svg']//*[@class='legend']//*[@class='textLine0']")
    private WebElementFacade countryEleInChartArea;
    
    @FindBy(xpath = ".//*[@id='AdvanceMapSearchResults']/p/span[2]")
    private List<WebElement> advSearchResultsListEle;
    
    @FindBy(xpath = "//*[@class='ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix ui-draggable-handle']/button/span[contains (., 'Close')]")
    private WebElementFacade mapSettingsPopupClose;
    
    @FindBy(xpath = ".//*[@id='chart1_NoChartMessage_MessageBox']//*[@id='NoChartMessage_Header']")
    private WebElementFacade noChartMsgEle;
    
    @FindBy(xpath = ".//*[@id='mdaContainer']//*[@id='MdaBackButton']")
    private WebElementFacade mdaCloseButton;
    
    @FindBy(xpath = ".//*[@id='mapTabs']//*[@id='chart1tab']/a")
    private WebElementFacade chartTabEle;

    public WebElementFacade getChartTabEle() {
        return chartTabEle;
    }
    
    @FindBy(xpath = ".//*[@id='OpenReportButton']")
    private WebElementFacade OpenReportTab;
    
    @FindBy(xpath = ".//*[@id='ReportBit']")
    private WebElementFacade reportWindowEle;
    
    public WebElementFacade getReportWindowEle() {
		return reportWindowEle;
	}

	@FindBy(xpath = ".//*[@id='ReportBit']//*[@id='ReportExpandButton']")
    private WebElementFacade expandReportTab;
    
    @FindBy(xpath = ".//*[@id='File']")
    private WebElementFacade fileIconEle;   
   
    @FindBy(xpath = ".//*[@id='unitlist']/input")
    private WebElementFacade searchFieldEleInFileMenu;
    
    @FindBy(xpath = ".//*[@id='fileMenu']")
    private WebElementFacade fileMenuEle;
    
    public WebElementFacade getFileMenuEle() {
        return fileMenuEle;
    }
    
    @FindBy(xpath = ".//*[@id='topBar']//*[@id='reportTitle']/p")
    private WebElementFacade contentElementHeader;
    
    @FindBy(xpath = ".//*[@id='fileMenuTable']/thead/tr")
    private WebElementFacade tableHeaderEleInFileMenu;
    
    @FindBy(xpath = ".//*[@id='fileMenuTable']/tbody/tr")
    private List<WebElement> productContentElements;
    
    @FindBy(xpath = ".//*[@id='fileMenuTable']/tbody/tr/td[6]")
    private List<WebElement> loadBtnElementsForProductContents;
    
    /*@FindBy(xpath = ".//*[@id='fileMenuTable']/tbody/tr")
    private List<WebElement> statusElementsForProductContents;*/
    
    @FindBy(xpath = ".//*[@id='reportTitle']")
    private WebElementFacade reportTitleEle;
    
    @FindBy(xpath = ".//*[@id='elementList']")
    private WebElementFacade mirCreditConditionsListMenuEle;
    
    @FindBy(xpath = ".//*[@id='elementList']//*[@id='elementLink']/a")
    private List<WebElement> contentElementsList;
    
    @FindBy(xpath = ".//*[@id='Complete']")
    private WebElementFacade completeBtnEle;
    
    @FindBy(xpath = ".//*[@id='Cancel']")
    private WebElementFacade cancelBtnEle;
    
    @FindBy(xpath = ".//*[@id='SignOff']")
    private WebElementFacade signOffEle;
    
    @FindBy(xpath = ".//*[@id='signOffMenu']")
    private WebElementFacade signOffPopupMenuEle;
    
    @FindBy(xpath = ".//*[@id='signOffMenu']/ul/li[1]/a")
    private WebElementFacade firstLinkEleInSignOffPopupMenu;
    
    @FindBy(xpath = ".//*[@id='signOffMenu']/ul/li/a")
    private List<WebElement> statusLinkEleInSignOffPopup;
    
    @FindBy(xpath = ".//*[@class='ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix ui-draggable-handle']/button/span[contains(.,'Close')]")
    private WebElementFacade signOffWindowCloseEle;
    
    /*@FindBy(xpath = ".//*[@id='fileMenuTable']/tbody/tr/td[4]/abbr")
    private List<WebElement> productContentsStatusElementsList;
    
    @FindBy(xpath = ".//*[@id='fileMenuTable']/tbody/tr/td[2][contains (., 'Zam')]/following::td[1]")
    private WebElementFacade firstProductContentFromFileMenu;*/
    
    @FindBy(xpath = ".//*[@id='main']//*[@id='topContainer']")
    private WebElementFacade editorConsoleele;
    
    @FindBy(xpath = ".//*[@id='ProductOperationsColumn']//*[@class='fieldSets']//*[@id='code']")
    private WebElementFacade countryField;
    
    @FindBy(xpath = ".//*[@id='ProductOperationsColumn']//*[@class='fieldSets']//*[@id='code']/option")
    private List<WebElement> countryListItems;
    
    @FindBy(xpath = ".//*[@id='ProductOperationsColumn']/div[2]/fieldset/form/input[contains (@value, 'Manage Country')]")
    private WebElementFacade manageCountryButton;
    
    @FindBy(xpath = ".//*[@class='page']//*[@id='main']")
    private WebElementFacade geographyPanel;
    
    @FindBy(xpath = ".//*[@class='page']//*[@id='main']/div[2]/h2")
    private WebElementFacade countryNameele;
    
    @FindBy(xpath = ".//*[@id='main']//*[@id='productTable']/tbody/tr")
    private WebElementFacade countryProductTableRows;
    
    @FindBy(xpath = ".//*[@id='main']//*[@id='productTable']/tbody/tr/td")
    private WebElementFacade countryProductTableData;
    
    @FindBy(xpath = ".//*[@id='main']//*[@id='productTable']/tbody/tr/td[1]")
    private List<WebElement> templateNameTableDataItems;
    
    @FindBy(xpath = ".//*[@id='main']//*[@id='productTable']/tbody/tr/td[3]")
    private List<WebElement> statusNameTableDataItems;
    
    @FindBy(xpath = ".//*[@id='main']/div[2]/form/input[2][contains (@value, Save)]")
    private WebElementFacade geographySaveButton;
    
    @FindBy(xpath = ".//*[@id='main']/div[2]/div/a[contains (text(),'Back to Overview')]")
    private WebElementFacade geographyBackButton;
    
    @FindBy(xpath= ".//*[@id='main']//*[@class='ui-layout-north headerPane ui-layout-pane ui-layout-pane-north']//*[@id='navbar']/ul/li[3]/a[contains(@href,'/Product')]")
    private WebElementFacade editorConsoleLink;
    
    @FindBy(xpath= ".//*[@id='main']/div[2]//*[@id='topContainer']")
    private WebElementFacade editorConsolePageEle;
    
    @FindBy(xpath= ".//*[@id='main']/div[2]//*[@id='topContainer']/h2[contains(text(),'Products Home')]")
    private WebElementFacade productsHomeEle;
    
    @FindBy(xpath= ".//*[@id='main']//*[@id='topContainer']/div[2]/div[2]/fieldset/form")
    private WebElementFacade templateEle;
    
    @FindBy(xpath= ".//*[@id='main']/div[2]//*[@id='ProductOperationsColumn']//*[@class='fieldSets']//*[@class='form-inline']//*[@id='id']")
    private WebElementFacade templateNameSelection;
    
    @FindBy(xpath= ".//*[@id='ProductOperationsColumn']/div[3]/fieldset/form/input[contains (@value, 'Manage Template')]")
    private WebElementFacade manageTemplateButton;
    
    @FindBy(xpath= ".//*[@id='main']/div[2]/h2")
    private WebElementFacade editTemplatePageele;
    
    @FindBy(xpath = ".//*[@id='ownershipFS']//*[@id='author']")
    private WebElementFacade geographyAuthorList;
    
    @FindBy(xpath = ".//*[@id='ownershipFS']//*[@id='analyticalEditor']")
    private WebElementFacade geographyAnalyticalEditorList;
    
    @FindBy(xpath = ".//*[@id='ownershipFS']//*[@id='productionEditor']")
    private WebElementFacade geographyProductionEditorList;
    
    @FindBy(xpath = ".//*[@id='ownershipFS']//*[@id='finalCheckEditor']")
    private WebElementFacade geographyFinalCheckEditorList;
    
    @FindBy(xpath= ".//*[@id='main']//*[@class='form-group']//*[@id='Name']")
    private WebElementFacade templateName;
    
    @FindBy(xpath= ".//*[@id='main']//*[@class='form-group']//*[@id='ProductTitle']")
    private WebElementFacade productTitle;
    
    @FindBy(xpath= ".//*[@id='main']//*[@class='editor-label checkbox']//*[@id='activeBox']")
    private WebElementFacade activeInactiveCheckbox;
    
    @FindBy(xpath= ".//*[@id='main']//*[@id='templateControls']//*[@id='brandingSelector']")
    private WebElementFacade productType;
    
    @FindBy(xpath= ".//*[@id='contentUnitSelectionContainer']//*[@class='listWrapper']//*[@id='availableContentUnits']")
    private WebElementFacade contentAvailablePanel;
    
    @FindBy(xpath= ".//*[@id='contentUnitSelectionContainer']//*[@class='listWrapper']//*[@id='selectedContentUnits']")
    private WebElementFacade contentAssignedPanel;
    
    @FindBy(xpath= ".//*[@id='main']//*[@class='listWrapper']//*[@id='availableGeographies']")
    private WebElementFacade productionCountriesAvailablePanel;
    
    @FindBy(xpath= ".//*[@id='main']//*[@class='listWrapper']//*[@id='availableGeographies']/li")
    private WebElementFacade productionCountriesAvailable;
    
    @FindBy(xpath= ".//*[@id='main']//*[@class='listWrapper']//*[@id='availableGeographies']/li[contains (@id, '')]")
    private WebElementFacade countriesAvailable;
    
    @FindBy(xpath= ".//*[@id='main']//*[@class='listWrapper']//*[@id='selectedGeographies']")
    private WebElementFacade productionCountriesAssignedPanel;
    
    @FindBy(xpath= ".//*[@id='main']//*[@class='listWrapper']//*[@id='selectedGeographies']/li")
    private WebElementFacade productionCountriesAssigned;
    
    @FindBy(xpath= ".//*[@id='main']//*[@id='save'][contains (@value, 'Save')]")
    private WebElementFacade templateSaveButton;
    
    @FindBy(xpath= ".//*[@id='main']//*[@id='CoverDate']")
    private WebElementFacade coverDate;
    
    @FindBy(xpath= ".//*[@id='main']//*[@id='WrittenDate']")
    private WebElementFacade writtenDate;
    
    @FindBy(xpath= ".//*[@id='main']//*[@id='create'][contains (@value, 'Save and Create Instances')]")
    private WebElementFacade productCreateButton;
    
    @FindBy(xpath= ".//*[@id='main']/div[2]/div/a[contains (text(), 'Back to Overview')]")
    private WebElementFacade backButton;
    
    @FindBy(xpath= ".//*[@id='UserDropdown']/span[2]")
    private WebElementFacade userMenuEle;
    
    @FindBy(xpath= ".//*[@id='navbar']/ul/li[5]//ul[@class='dropdown-menu']")
    private WebElementFacade logOffPanel;

    @FindBy(xpath = ".//*[@id='navbar']//*[@class='dropdown-menu']/li[2]//*[@href[contains('Logoff', '')]]")
    private WebElementFacade logOffEle;		
    
    @FindBy(xpath= ".//*[@id='UserName']")
    private WebElementFacade userNameFieldEle;
    
    @FindBy(xpath = ".//*[@id='PublishContainer']//*[@id='bottomDiv']//*[@id='PublishProductBtn']")
    private WebElementFacade publishNowButton;
    
    public WebElementFacade getPublishNowButton() {
        return publishNowButton;
    }
    
  /*******************************************************
   * Added by SendhilKumar
   ******************************************************/
    
    @FindBy(xpath ="//*[@id='headingContainer'] | //*[@id='elementContent']/img | //*[@id='elementContent']/iframe | //*[@id='table'] | //*[@id='scoreIcon'] | //*[@id='elementContent']//*[contains(text(),'Note')]")
    private WebElementFacade iFramePanel; 
    
    @FindBy(xpath =".//*[@id='selectedContentElement']//*[@id='Refresh']")
    private WebElementFacade refreshButton;
   
    @FindBy(xpath=".//*[@id='elementContent']//*[@id='textEditorToolbar']")
    private WebElementFacade toolBar;    
  
    @FindBy(xpath ="//*[@id='headingContainer']")
    private WebElementFacade heading;
    
    @FindBy(xpath ="//*[@id='loadingOverlay']")
    private WebElementFacade LoadingImg;
    
  /*******************************************************/  
    
    @FindBy(xpath = ".//*[@id='UnpublishProductBtn']")
    private WebElementFacade unPublishNowButtonEle;

    public WebElementFacade getUnPublishNowButtonEle() {
        return unPublishNowButtonEle;
    }

    
    private String firstAdvSearchResultXpath = ".//*[@id='AdvanceMapSearchResults']/p[1]/span[1]";
    private String reportTitleXpath = ".//*[@id='reportTitle']";
    private String editTemplatePageEleXpath = ".//*[@id='main']/div[2]/h2";    
    private String reportWindowXpath=".//*[@id='ReportBit']";
    private String fileMenuXpath = ".//*[@id='fileMenu']";
    private String fileOptionXpath = ".//*[@id='File']";
    private String editorCjoiceXpath = ".//*[@id='navbar']/li/a[contains(.,'Editor Console')]";
    private String firstLinkEleXpathInSignOffWindow = ".//*[@id='signOffMenu']/ul/li[1]/a";
    private String loadOverLayXpath = ".//*[@id='loadingOverlay']";
    private String countryEleXpath = ".//*[@id='chartarea']//*[@id='chart1_svg']//*[@class='legend']//*[@class='textLine0']";
    private String datasetSearchResultsXpath = ".//*[@id='DataExplorerArea']/ul/li/span/a[contains(.,'SERENITY')]";
    private String firstChildDatasetXpath = ".//*[@id='DataExplorerArea']/ul/li/ul/li[1]/span/a[contains(.,'SERENITY')]";
    private String secondChildDatasetXpath = ".//*[@id='DataExplorerArea']/ul/li/ul/li/ul/li/span/a[contains(.,'SERENITY')]";
    private String loadOptionXpathForAdvSearchResult = ".//*[@id='AdvanceMapSearchResults']//p/span[contains(.,'Country: SERENITY')]//ancestor::p[1]//following-sibling::button[1][contains(@class,'advancedMapSearchResultLoad')]";
    private String dashboardTitleEleXpath = ".//*[@id='main']/div[3]";
    private String logOffEleXpath = ".//*[@id='navbar']//*[@class='dropdown-menu']/li[2]//*[@href[contains('Logoff', '')]]";
    private ArrayList<String> firstChildDatasetNamesList = new ArrayList<String>();
    private ArrayList<String> secondChildDatasetNamesList = new ArrayList<String>();
    private ArrayList<String> advSearchResultsList = new ArrayList<String>();
    private String storeNoChartInfo;
    private String countryValFromChart;
    private String countryListXpath = ".//*[@id='ProductOperationsColumn']//*[@class='fieldSets']//*[@id='code']/option[contains(.,'SERENITY')]";
    private String templateStatusXpath  = ".//*[@id='main']//*[@id='productTable']/tbody/tr/td/a[contains(.,'SERENITY')]//ancestor::td[1]//following-sibling::td[2]";
    private String tempStatus="Published";
    private ArrayList<String> countryList = new  ArrayList<String>();
    private ArrayList<String> countryTemplates = new  ArrayList<String>();
    
    
    private String statusElementsForProductContentsXpath=".//*[@id='fileMenuTable']/tbody/tr[contains (., 'SERENITYCOUNTRY')][contains (., 'SERENITYTEMPLATE')]";
    		
    private String statusElementsForProductContentsXpath1=".//*[@id='fileMenuTable']/tbody/tr/td[2][contains (., 'SERENITYCOUNTRY')]//following::td[1][contains (., 'SERENITYTEMPLATE')]//ancestor::tr[1]";
    private String templateListXpath = ".//*[@id='ProductOperationsColumn']//*[@class='fieldSets']//*[@class='form-inline']//*[@id='id']/option[contains (., 'SERENITY')]";
    private String countryAvailableXpath = ".//*[@id='main']//*[@class='listWrapper']//*[@id='availableGeographies']/li[contains (., 'SERENITY')]";
    private String countryAssignedXpath = ".//*[@id='main']//*[@class='listWrapper']//*[@id='selectedGeographies']/li[contains (., 'SERENITY')]";
    
    private ArrayList<String> templatenamelist = new ArrayList<String>();
    private ArrayList<String> createdTemplateStatusList = new ArrayList<String>();
        
    private String productContentsStatusElementsListXpath=".//*[@id='fileMenuTable']/tbody/tr/td[2][contains (., 'SERENITYCOUNTRY')]/following::td[1][contains (., 'SERENITYTEMPLATE')]/following::td[1]/abbr";    
    private String createdTemplateStatusXpath = ".//*[@id='productTable']/tbody/tr/td/a[contains(.,'SERENITY')]//ancestor::td[1]//following-sibling::td[2]";
    private String firstProductContentFromFileMenuXpath = ".//*[@id='fileMenuTable']/tbody/tr/td[2][contains (., 'SERENITYCOUNTRY')]/following::td[1][contains (., 'SERENITYTEMPLATE')]";
    private String publishedFileXpath = ".//*[@id='bottomDiv']/div/fieldset/p/a[contains(.,'SERENITY')]";
    private String templateWithReadyForPublishXpath = ".//*[@id='productTable']/tbody/tr/td/a[contains(.,'SERENITYTEMPLATE')]//ancestor::td[1]//following-sibling::td[2][contains(.,'SERENITYSTATUS')]//ancestor::tr[1]/td[1]/a";
    
    // User login in verify
    public void loginverify() {
    	gViewheaderEle.waitUntilPresent();
    	UIHelper.highlightElement(getDriver(), gViewloginas);
    }
    
    // Navigate to home page
    public void navigateToDashboardTab() {
        try{
            if(!dashboarddataexplorer.isPresent())
            {
            	System.out.println("-------- DASHBOARD PAGE IN -------------");
            	dashBoard.click();            	
                UIHelper.waitForPageToLoad(getDriver());
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(),dashboardTitleEleXpath);
                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadOverLayXpath);
                gViewheaderEle.waitUntilPresent();
            	mapSettingsBtnEle.waitUntilPresent();
            	dashboarddataexplorer.waitUntilClickable();
                System.out.println("-------- DASHBOARD PAGE PASSED -------------");
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public String getGViewDashboardPageDetails() {
    	gViewheaderEle.waitUntilPresent();        
        return gViewheaderEle.getText();
    }
    
    //Open Data Explorer
    public void clickTheDataExplorer()
    {
        try{
            if(!openDataExplorerEle.isPresent())
            {
            	waitFor(3000).milliseconds();
            	openDataExplorerEle.isCurrentlyVisible();
            	openDataExplorerEle.waitUntilClickable();
            	openDataExplorerEle.click();
                datasetsSearchFieldEle.waitUntilPresent();
                datasetsSearchBtnEle.waitUntilPresent();
                datasetsEle.waitUntilPresent();
            }
            else
            {
                datasetsSearchFieldEle.waitUntilPresent();
                datasetsSearchBtnEle.waitUntilPresent();
                datasetsEle.waitUntilPresent();
            }
        }
        catch(Exception e)
        {
        }
    }
    
    //Enter Dataset
    public void enterDataset(String datasetName)
    {
        try{
            if(datasetsSearchFieldEle.isPresent())
            {
                datasetsSearchFieldEle.type(datasetName);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Click on Search
    public void clickOnSearch()
    {
        try{
            if(datasetsSearchBtnEle.isPresent())
            {
                datasetsSearchBtnEle.click();
                searchResultEleForDataset.waitUntilPresent();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Click on Dataset
    public void clickOnDataset(String datasetName)
    {
        try{
            String tempDatasetSearchResultsXpath = datasetSearchResultsXpath.replace("SERENITY", datasetName);
            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempDatasetSearchResultsXpath);
            WebElementFacade datasetSearchResultsEle = find(By.xpath(tempDatasetSearchResultsXpath));
            if(!firstChildFirstElement.isPresent())
            {
                if(datasetSearchResultsEle.isPresent())
                {
                    datasetSearchResultsEle.click();
                }
            }
        }
        catch(Exception e)
        {
            
        }
    }
    
    //Get First Child Datasets
    public ArrayList<String> getFirstChildDatasets()
    {
        try{
            firstChildFirstElement.waitUntilPresent();
            for(WebElement ele:firstChildListElements)
            {
                firstChildDatasetNamesList.add(ele.getText().trim());
            }
        }
        catch(Exception e)
        {
            
        }
        return firstChildDatasetNamesList;
    }
    
    //Click on First Child Dataset
    public void clickOnFirstChildDataset(String childDataset)
    {
        try{
            String tempFirstChildDatasetXpath = firstChildDatasetXpath.replace("SERENITY", childDataset);
            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempFirstChildDatasetXpath);
            WebElementFacade firstChildDatasetEle = find(By.xpath(tempFirstChildDatasetXpath));
            if(firstChildDatasetEle.isPresent())
            {
                firstChildDatasetEle.click();
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), loadOverLayXpath);
                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadOverLayXpath);
            }
        }
        catch(Exception e)
        {
            
        }
    }
    
    //Get Second Child Datasets
    public ArrayList<String> getSecondChildDatasets()
    {
        try{
            secondChildFirstElement.waitUntilPresent();
            for(WebElement ele:secondChildListElements)
            {
                secondChildDatasetNamesList.add(ele.getText().trim());
            }
        }
        catch(Exception e)
        {
            
        }
        return secondChildDatasetNamesList;
    }
    
    //Click on Second Child Dataset
    public void clickOnSecondChildDataset(String childDataset)
    {
        try{
            String tempSecondChildDatasetXpath = secondChildDatasetXpath.replace("SERENITY", childDataset);
            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempSecondChildDatasetXpath);
            WebElementFacade secondChildDatasetEle = find(By.xpath(tempSecondChildDatasetXpath));
            if(secondChildDatasetEle.isPresent())
            {
                secondChildDatasetEle.click();
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), loadOverLayXpath);
                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadOverLayXpath);
            }
        }
        catch(Exception e)
        {
            
        }
    }
    
    //Get Chart Tab Name
    public String getChartTabName()
    {
        chartTabEle.waitUntilPresent();
        String Chartname = chartTabEle.getText().trim();
        if (Chartname.contains("Chart")) 
        {
        	chartTabEle.click();
        	chartTabEle.waitUntilPresent();        	
        }
        	
        return chartTabEle.getText().trim();
    }
    
    //Check chart for dataset
    public String getLoadedDatasetFromChart()
    {
        datsetEleInChartArea.waitUntilPresent();
        return datsetEleInChartArea.getText().trim();
    }
    
    //Check 'No Message' in chart area
    public String getNoChartMessage()
    {
        try{
            chartTabEle.waitUntilPresent();
            noChartMsgEle.waitUntilPresent();
            if(noChartMsgEle.isPresent())
            {
                storeNoChartInfo = noChartMsgEle.getText().trim();                
            }
        }
        catch(Exception e)
        {
        }
        return storeNoChartInfo;
    }
    
    //Click on Settings in Map Section
    public void clickOnSettingsInMapSection()
    {
        try{        	
        	if(mdaCloseButton.isPresent())
        	{
        		mdaCloseButton.click();
        	}
        	mapSettingsBtnEle.waitUntilPresent();
        	mapSettingsBtnEle.waitUntilClickable();
        	System.out.println("----> After mapSettingsBtnEle Wait ----> ");
            if(mapSettingsBtnEle.isPresent())
            {
            	System.out.println("----> Inside mapSettingsBtnEle IF ----> ");
                mapSettingsBtnEle.click();
                System.out.println("----> mapSettingsBtnEle CLICKED ----> ");
                mapSettingsPopupEle.waitUntilPresent();
                System.out.println("----> After mapSettingsPopupEle Element ----> ");
            }
            System.out.println("----> EXIT IF ----> ");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Perform location search
    public void performLocationSearch(String country)
    {
        try{        	
            advSearchFieldEle.waitUntilPresent();
            if(advSearchFieldEle.isPresent())
            {
            	advSearchFieldEle.type(country);
                advSearchBtnEle.click();
                System.out.println("----> Entered Country Name and Search button Clicked ----> ");
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), loadOverLayXpath);
                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadOverLayXpath);
            }
        }
        catch(Exception e)
        {
        }
    }
    
    //Get Advanced search results
    public ArrayList<String> getAdvSearchResults()
    {
        try{
            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), firstAdvSearchResultXpath);
            firstSearchResultEleInAdvSearchResults.waitUntilPresent();
            for(WebElement ele:advSearchResultsListEle)
            {
                advSearchResultsList.add(ele.getText().trim());
            }
        }
        catch(Exception e)
        {
            
        }
        return advSearchResultsList;
    }
    
    //Click on Load Option
    public void clickOnLoadOption(String country)
    {
        try{
            String tempLoadOptionXpathForAdvSearchResult = loadOptionXpathForAdvSearchResult.replace("SERENITY", country);
            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempLoadOptionXpathForAdvSearchResult);
            WebElementFacade loadOptionEleForAdvSearchResult = find(By.xpath(tempLoadOptionXpathForAdvSearchResult));
            if(loadOptionEleForAdvSearchResult.isPresent())
            {
                loadOptionEleForAdvSearchResult.click();
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), loadOverLayXpath);
                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadOverLayXpath);
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), fileOptionXpath);
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), editorCjoiceXpath);
            }
            
            if(mapSettingsPopupClose.isPresent())
            {
            	mapSettingsPopupClose.click();
            }
        }
        catch(Exception e)
        {
            
        }
    }
    
    //Get country from chart area
    public String getLoadedCountryFromChartArea()
    {
        try{
            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), countryEleXpath);
            countryEleInChartArea.waitUntilPresent();
            countryValFromChart = countryEleInChartArea.getText();            
        }
        catch(Exception e)
        {
        }
        return countryValFromChart;
    }
  
   //Click on Open Report icon in dashboard page
    public void clickOnOpenReportIcon()
    {
    	try{
    		if(OpenReportTab.isPresent())
        	{
        		OpenReportTab.click();
            	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), reportWindowXpath);
            	
            	if(expandReportTab.isPresent())
            	{
            		expandReportTab.click();
            	}
        	}
    		else
    		{
    			OpenReportTab.waitUntilPresent();    			
    		}
    	}
    	catch(Exception e)
    	{
    		
    	}
    }
  
    //Click on File icon in Report
    public void clickOnFileIcon()
    {
        try{            
            if(fileIconEle.isPresent())
            {
                fileIconEle.click();
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), fileMenuXpath);
                searchFieldEleInFileMenu.waitUntilPresent();
                fileMenuEle.waitUntilPresent();
                tableHeaderEleInFileMenu.waitUntilPresent();
            }
        }
        catch(Exception e)
        {
        	
        }
    }
    
    //Enter Search Key In Product Contents Popup
    public void enterSearchKey(String searchKey)
    {
        try{
            if(searchFieldEleInFileMenu.isPresent()) 
            {
                searchFieldEleInFileMenu.type(searchKey);
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), fileMenuXpath);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Change Product Contents status to expected status
    public void changeProductContentsStatusToExpectedStatus(String currentStatusVal, String expectedStatus, String searchKey, String templateName)
    {
    	String statusElementsForProductContentstemp = statusElementsForProductContentsXpath.replace("SERENITYCOUNTRY", searchKey).replace("SERENITYTEMPLATE", templateName);
    	System.out.println("---> statusElementsForProductContentstemp ="+statusElementsForProductContentstemp);
    	List<WebElement> statusElementsForProductContents = getDriver().findElements(By.xpath(statusElementsForProductContentstemp));
    	System.out.println("---> statusElementsForProductContents ="+statusElementsForProductContents);
    	String statusElementsForProductContentstemp1 = null;
    	
        try{
            if(!currentStatusVal.equalsIgnoreCase("Final Check"))            
            {             	
            	waitFor(2000).milliseconds();            	
                for(int index = 0; index < statusElementsForProductContents.size(); index++)
                {                 	
                	System.out.println(" --------> Total Content Elements = "+statusElementsForProductContents.size());
                	System.out.println(" --------> Index Size = "+index);               	
                	
                	statusElementsForProductContentstemp1 = statusElementsForProductContentsXpath1.replace("SERENITYCOUNTRY", searchKey).replace("SERENITYTEMPLATE", templateName);
                	System.out.println("---> statusElementsForProductContentstemp ="+statusElementsForProductContentstemp1);
                	List<WebElement> statusElementsForProductContents1 = getDriver().findElements(By.xpath(statusElementsForProductContentstemp));
                	               	
                	System.out.println(" --------> Content Elements in Draft/Production Edit = "+statusElementsForProductContents1.size());
                	System.out.println("---> statusElementsForProductContentstemp ="+statusElementsForProductContentstemp1);
                	System.out.println(" --------> statusElementsForProductContents Index Size = "+index);
                	System.out.println("--> TemplateName = "+templateName+"Status = "+currentStatusVal+" -->statusElementsForProductContents = "+statusElementsForProductContents1.get(index));
                	String Output = statusElementsForProductContents1.get(index).getText().trim();
                	System.out.println("--> Output ="+Output);
                	
                    if(statusElementsForProductContents1.get(index).getText().trim().contains(currentStatusVal) 
                            || statusElementsForProductContents1.get(index).getText().trim().equalsIgnoreCase(currentStatusVal)) {
                    	System.out.println(" ---> Search Key ="+templateName);
                    	/******* Added By Mathi ************/
                    	if(templateName.contains("MIR")||templateName.contains("CIR")){
                    		System.out.println(" ---> Search Key = INSIDE IF");
                    		String loadBtnXpath = ".//*[@id='fileMenuTable']/tbody/tr["+(index+1)+"]/td[3][contains (., 'SENERITY')]/following::td[3]/button";
                    		String loadBtnXpathtemp = loadBtnXpath.replace("SENERITY", templateName);
                    		System.out.println(" ---> loadBtnXpathtemp = "+loadBtnXpathtemp);
                    		WebElement loadBtnEle = getDriver().findElement(By.xpath(loadBtnXpathtemp));
                    		UIHelper.highlightElement(getDriver(), loadBtnEle);
                            UIHelper.mouseOverandclickanElement(getDriver(), loadBtnEle);
                    	} else {
                    		System.out.println(" ---> Template Name is not Matched ----|");                    		
                    	}
                    	/******* Commented By Mathi ************/
                    	//WebElement loadBtnEle = getDriver().findElement(By.xpath(loadBtnXpathtemp));
                    	
                        /******* Added By Sendhil ************/
                        UIHelper.waitForPageToLoad(getDriver());
                        
                        if(LoadingImg.isVisible()){                      	  
                      	  UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadOverLayXpath);
                        }
                        
                        /******* Commented By Sendhil ************/
                        /*UIHelper.waitForVisibilityOfEleByXpath(getDriver(), loadOverLayXpath);
                        */
                        
                        changProductContentsStatus(expectedStatus);
                        navigateToProductContentsPopupScreen(searchKey,expectedStatus,index,templateName);
                     System.out.println(" --------> Completed Content Elements = "+(index+1));   
                    }
                }   
            }
            else
            {
                for(int index = (statusElementsForProductContents.size()-1); index >= 0 ; index--)
                {
                	statusElementsForProductContentstemp1 = statusElementsForProductContentsXpath1.replace("SERENITYCOUNTRY", searchKey).replace("SERENITYTEMPLATE", templateName);
                	System.out.println("---> statusElementsForProductContentstemp ="+statusElementsForProductContentstemp1);
                	List<WebElement> statusElementsForProductContents1 = getDriver().findElements(By.xpath(statusElementsForProductContentstemp));
                	
                	System.out.println(" --------> Content Elements in Final check = "+statusElementsForProductContents1.size());
                	System.out.println("---> statusElementsForProductContentstemp ="+statusElementsForProductContentstemp1);
                	System.out.println(" --------> statusElementsForProductContents Index Size = "+index);
                	System.out.println("--> TemplateName = "+templateName+"Status = "+currentStatusVal+" -->statusElementsForProductContents = "+statusElementsForProductContents1.get(index));
                	String Output1 = statusElementsForProductContents1.get(index).getText().trim(); 
                	System.out.println("--> After Output 1 --->");
                	System.out.println("--> Output 1="+Output1);
                    if(statusElementsForProductContents1.get(index).getText().trim().contains(currentStatusVal) 
                            || statusElementsForProductContents1.get(index).getText().trim().equalsIgnoreCase(currentStatusVal)) {
                    	System.out.println("--> templateName and index= INSIDE IF");
                        List<WebElement> noOfProductContents = getDriver().findElements(By.xpath(".//*[@id='fileMenuTable']/tbody/tr"));
                        if(noOfProductContents.size()>0)
                        {
                        	/******* Added By Mathi ************/                        	
                        	System.out.println("----> templateName and index="+templateName+" index="+index);
                        	if(templateName.contains("MIR")||templateName.contains("CIR")){
                        		System.out.println(" ---> Search Key = INSIDE IF");
                        		String loadBtnXpath = ".//*[@id='fileMenuTable']/tbody/tr["+(index+1)+"]/td[3][contains (., 'SENERITY')]/following::td[3]/button";
                        		String loadBtnXpathtemp = loadBtnXpath.replace("SENERITY", templateName);
                        		System.out.println(" ---> loadBtnXpathtemp = "+loadBtnXpathtemp);
                        		WebElement loadBtnEle = getDriver().findElement(By.xpath(loadBtnXpathtemp));
                        		UIHelper.highlightElement(getDriver(), loadBtnEle);
                                UIHelper.mouseOverandclickanElement(getDriver(), loadBtnEle);
                        	} else {
                        		System.out.println(" ---> Template Name is not Matched ----|");                    		
                        	}
                        	/******* Commented By Mathi ************/
                        	/*WebElement loadBtnEle = getDriver().findElement(By.xpath(".//*[@id='fileMenuTable']/tbody/tr[1]/td[6]/button"));
                            UIHelper.mouseOverandclickanElement(getDriver(), loadBtnEle);*/
                            /******* Added By Sendhil ************/
                            UIHelper.waitForPageToLoad(getDriver());
                            
                            if(LoadingImg.isVisible()){                          	  
                          	  UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadOverLayXpath);
                            }
                            
                            /******* Commented By Sendhil ************/
                            /*UIHelper.waitForVisibilityOfEleByXpath(getDriver(), loadOverLayXpath);
                            */
                            
                            changProductContentsStatus(expectedStatus);
                            navigateToProductContentsPopupScreen(searchKey,expectedStatus,index,templateName);
                        }
                    }
                }
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public void navigateToProductContentsPopupScreen(String searchKeyVal,String expectedStatus, int index, String templateName)
    {
        try{
            clickOnFileIcon();
            enterSearchKey(searchKeyVal);
            /******* Added By Mathi ************/
            System.out.println("----> navigateToProduct searchKeyVal =" +searchKeyVal);
            System.out.println("----> navigateToProduct expectedStatus =" +expectedStatus);
            System.out.println("----> navigateToProduct index =" +index);
            System.out.println("----> navigateToProduct templateName =" +templateName);
            
            System.out.println("---> Before Xpath");
            /*String currentStatusXpath =".//*[@id='fileMenuTable']/tbody/tr["+(index)+"]/td[3][contains (., 'SENERITY')]//following-sibling::td[1]/abbr";            		
        	String currentStatusEle = currentStatusXpath.replace("SERENITY", templateName);
        	WebElementFacade currentStatusEleName = find(By.xpath(currentStatusEle));
        	System.out.println("---> currentStatusEleName ="+currentStatusEleName);
        	String StatusName = currentStatusEleName.getTextValue().trim();
        	System.out.println("---> StatusName ="+StatusName);
        	if (!StatusName.contains(expectedStatus))
        	{
        		System.out.println("---> StatusName ="+StatusName.contains(expectedStatus));
        		System.out.println("----> StatusName.contains(expectedStatus) = InSIDE IF");
        		String loadBtnXpath = ".//*[@id='fileMenuTable']/tbody/tr["+(index+1)+"]/td[3][contains (., 'Template: SERENITY')]//following-sibling::td[1][contains (., 'Status: SERENITY')]//following::td[2]/button";
        		String loadBtnXpathtemp = loadBtnXpath.replace("Template: SERENITY", templateName).replace("Status: SERENITY", StatusName);
            	System.out.println("---> navigateToProductContentsPopupScreen loadBtnXpathtemp ="+loadBtnXpathtemp);
        		WebElementFacade loadBtnEle = find(By.xpath(loadBtnXpathtemp));
        		UIHelper.highlightElement(getDriver(), loadBtnEle);
        		UIHelper.mouseOverandclickanElement(getDriver(), loadBtnEle);
                UIHelper.waitForPageToLoad(getDriver());                 
                if(LoadingImg.isVisible()){                      	  
               	  UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadOverLayXpath);
                 }
                 System.out.println("----> StatusName.contains(expectedStatus) = Entering Content Element"  );
                 changProductContentsStatus(expectedStatus);
                 System.out.println("----> StatusName.contains(expectedStatus) = Completed Content Element"  );
        	}*/
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public void changProductContentsStatus(String expectedStatus) {
        try {
            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), reportTitleXpath);
            reportTitleEle.waitUntilPresent();
            mirCreditConditionsListMenuEle.waitUntilPresent();
            if(signOffEle.isPresent())
            {
                performSignoff(expectedStatus);
            }
            else
            {
            	waitFor(3000).milliseconds();
            	String contentname = contentElementHeader.getText();
            	System.out.println("-----> Content Element Name = "+contentname);
                for (int index = 0; index < contentElementsList.size(); index++) {                	
                	System.out.println("-------->  Total Content Units in Draft State --------> = " +contentElementsList.size());                    
                    WebElement elementLink = contentElementsList.get(index);
                    UIHelper.mouseOverandclickanElement(getDriver(), elementLink);
                    waitFor(10000).milliseconds();                    
                                                           
                    if(completeBtnEle.isPresent())
                    {
                    	/********** Added By Mathi *************/
                    	/*if(refreshButton.isPresent())
                    	{
                    		refreshButton.click();
                    		if(LoadingImg.isVisible()){                          	  
                             	  UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadOverLayXpath);
                             	  System.out.println("-----> Updating Data -----> ");
                             	 waitFor(4000).milliseconds();
                             	if(LoadingImg.isVisible()){
                             		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadOverLayXpath);
                             		System.out.println("-----> Updated Data -----> ");
                             	}                         		
                               }                    		
                    	}*/
                    	/********** Added By Sendhil *************/
                        if(toolBar.isPresent())
                        {
                        	iFramePanel.waitUntilPresent();
                        	 System.out.println(" ------> Inside Iframe -------|");
                        }
                    	
                        completeBtnEle.click();
                        reportTitleEle.waitUntilPresent();
                        waitFor(2000).milliseconds();
                    }
                    System.out.println(" -----> Completed Content Unit = "+index);
                }
                performSignoff(expectedStatus);
            }

        } catch (Exception e) {
          
        }
    }
    
    public void performSignoff(String expectedStatus)
    {
        try{
            if(signOffEle.isPresent())
            {
                signOffEle.click();
                signOffPopupMenuEle.waitUntilPresent();
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), firstLinkEleXpathInSignOffWindow);
                firstLinkEleInSignOffPopupMenu.waitUntilPresent();
                for(WebElement signOffStatusLinkEle:statusLinkEleInSignOffPopup)
                {
                    if(signOffStatusLinkEle.getText().trim().contains(expectedStatus) 
                            || signOffStatusLinkEle.getText().trim().equalsIgnoreCase(expectedStatus)){
                        
                        signOffStatusLinkEle.click();
                        System.out.println("  --------> Content Element Status Changed to " +expectedStatus);
                        break;
                    }
                }
                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), firstLinkEleXpathInSignOffWindow);
                
                if(signOffWindowCloseEle.isPresent())
                {
                    signOffWindowCloseEle.click();
                }
                fileIconEle.waitUntilPresent();
            }
        } catch (Exception e) {
            
        }
    }
    
    //Check product status is changed or not
    public ArrayList<String> getProductContentstatus(String geography,String templateName)
    {
    	String productContentsStatusElementsListtemp = productContentsStatusElementsListXpath.replace("SERENITYCOUNTRY", geography).replace("SERENITYTEMPLATE", templateName);
    	System.out.println("-----> productContentsStatusElementsListtemp ="+productContentsStatusElementsListtemp);
    	List<WebElement> productContentsStatusElementsList = getDriver().findElements(By.xpath(productContentsStatusElementsListtemp));
    	System.out.println("-----> productContentsStatusElementsList ="+productContentsStatusElementsList);
        ArrayList<String> productContentsList = new ArrayList<String>();
        try{
            for(WebElement ele:productContentsStatusElementsList)
            {
                productContentsList.add(ele.getText().trim());
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("----> productContentsList ="+productContentsList);
        return productContentsList;
    }
    
    // Get Country List 
    public ArrayList<String> getCountryList() {
        try {
            editorConsoleele.waitUntilPresent();
            
            for(WebElement ele : countryListItems) {
                
                countryList.add(ele.getText().trim());
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return countryList;
        
    }
    
    //Select Country name in Geography field
    public void selectCountry(String CountryName) throws Exception {
        try {
            
            String tempCountryListXpath = countryListXpath.replace("SERENITY", CountryName);
            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempCountryListXpath);
            WebElementFacade CountryEle = find(By.xpath(tempCountryListXpath));
            
            if (CountryEle.isPresent()) {
                
                CountryEle.click();
            }
        } catch (Exception e) {
            
            e.printStackTrace();
        }
    }
    
    
    //Click Manage Country Button
    public void clickManageCountry() throws Exception {
        try {
            manageCountryButton.waitUntilPresent();
            if(manageCountryButton.isPresent())
            {
                manageCountryButton.click();
                UIHelper.waitForPageToLoad(getDriver());
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), editTemplatePageEleXpath);
                editTemplatePageele.waitUntilPresent();
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    // Get Product Ownership detail for Geography 
    public String getProductOwnership(String username) {
    	try {
    		System.out.println("USER NAME ="+username);
    		editTemplatePageele.waitUntilPresent();    		
        	String Author = geographyAuthorList.getSelectedVisibleTextValue().trim();
        	String AnalyticalEditor = geographyAnalyticalEditorList.getSelectedVisibleTextValue().trim();
        	String ProductionEditor = geographyProductionEditorList.getSelectedVisibleTextValue().trim();
        	String FinalCheckEditor = geographyFinalCheckEditorList.getSelectedVisibleTextValue().trim();
    		
    		/*System.out.println("Author ="+Author);
        	System.out.println("AnalyticalEditor ="+AnalyticalEditor);
        	System.out.println("ProductionEditor ="+ProductionEditor);
        	System.out.println("FinalCheckEditor ="+FinalCheckEditor);*/
        	
        	if (!Author.matches(username)) {        		        		
        		System.out.println("Author Name-----> NOT MATCHED -----> " +Author);        		
        		return Author;
        	}
        	if (!AnalyticalEditor.matches(username)){
        		System.out.println("AnalyticalEditor-----> NOT MATCHED -----> "+AnalyticalEditor);
        		return AnalyticalEditor;
        	}
            if (!ProductionEditor.matches(username)) {
             	System.out.println("ProductionEditor-----> NOT MATCHED -----> "+ProductionEditor);
             	return ProductionEditor;
            }
            if (!FinalCheckEditor.matches(username)) {
            	System.out.println("FinalCheckEditor-----> NOT MATCHED -----> "+FinalCheckEditor);
                return FinalCheckEditor;
            }           
        	
        	
    	} catch (Exception e){
    		
    	}		
		
		return username;    	
    	
    }
    
    // Get Template Status 
    public ArrayList<String> getProductTemplateName(String Templatename,String filePath) throws Exception {
        try {
            String finalTemplateStatusXpath = templateStatusXpath.replace("SERENITY", Templatename);         

            List<WebElement> finalTemplateStatusElementsList = getDriver().findElements(By.xpath(finalTemplateStatusXpath));
            
            for(WebElement ele:finalTemplateStatusElementsList)
            {
                
                 if(ele.getText().contains("Draft") || ele.getText().contains("Ready For Publication"))
                 {
                	 UIHelper.highlightElement(getDriver(), ele);
                     tempStatus = ele.getText();
                 }
            }
            
            new FileUtil().writeTextToFile(tempStatus, filePath);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return countryTemplates;
        
    }
    
    // Get Assigned Product Status in Dashboard
    public ArrayList<String> getFirstProductContentFromFileMenu(String geography, String templateName) {    	
    	ArrayList<String> templateList = new  ArrayList<String>();
    	try{
    		System.out.println("---> Entering getFirstProductContentFromFileMenu ---|");
        	String productContentsFromFileMenutemp = firstProductContentFromFileMenuXpath.replace("SERENITYCOUNTRY", geography).replace("SERENITYTEMPLATE", templateName); 
        	System.out.println("---> productContentsFromFileMenutemp ---|="+productContentsFromFileMenutemp);
        	List<WebElement> TemplateFromFileMenuList = getDriver().findElements(By.xpath(productContentsFromFileMenutemp));    	
        	System.out.println("--------> TemplateFromFileMenuList ="+TemplateFromFileMenuList);
        	 for(WebElement ele : TemplateFromFileMenuList) {
                 
        		 templateList.add(ele.getText().trim());
             }
        	    		
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    	 
        return templateList;  
    }
    
    // User navigate to Country Insight Editor Console page 
    public void navigateeditorconsole() throws Exception {
        try{
            if(editorConsoleLink.isPresent()){
            	System.out.println("-----> FROM Master file page ----|");
            	editorConsoleLink.click();
                editorConsolePageEle.waitUntilPresent();
                UIHelper.highlightElement(getDriver(), editorConsolePageEle);
                System.out.println("-------- EDITOR CONSOLE PAGE PASSED -------------");
            }
            else{
                editorConsoleLink.waitUntilPresent();
            }           
                        
        } catch (Exception e){
        }
                
    }
    
    // Verification of Editor console page title
    public String getGvieweditorconsoletitle(){
        editorConsolePageEle.waitUntilPresent();
        return editorConsolePageEle.getText();
    }
    
    //Get Template List Items   
    public ArrayList<String> getTemplateList()
    {
        try{
            templateEle.waitUntilPresent();
            Select optionSection = new Select(templateNameSelection);
            List<WebElement> viewSection = optionSection.getOptions();
            for(WebElement ele : viewSection)
            {
                templatenamelist.add(ele.getText().trim());             
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return templatenamelist;
    }
    
    //Select Template name
    public void selectTemplateName (String templateName)
    {
        try{
            String tempTemplateListItemXpath = templateListXpath.replace("SERENITY", templateName);
            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempTemplateListItemXpath);
            WebElementFacade TempListItemEle = find(By.xpath(tempTemplateListItemXpath));
            if(TempListItemEle.isPresent())
            {
                TempListItemEle.click();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    
    // Click Manage Template button
    public void clickManageButton() throws Exception {
        try {
            if (manageTemplateButton.isPresent()) {
                manageTemplateButton.isEnabled();
                manageTemplateButton.click();
                UIHelper.waitForPageToLoad(getDriver());
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), editTemplatePageEleXpath);
                editTemplatePageele.waitUntilPresent();
                productTitle.waitUntilPresent();
            }
            else {
                manageTemplateButton.waitUntilClickable();
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    
    // Verify edit Template page
    public void verifyTemplatePage() {
        editTemplatePageele.waitUntilPresent();
        
    }
    
        
    // Assign Country
    
    public void countrydraganddrop() throws Exception {
        try {   
           // Script for dragging an element and dropping it in another place
        	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), editTemplatePageEleXpath);
            editTemplatePageele.waitUntilPresent();
            templateName.waitUntilPresent();            
            if(productionCountriesAssigned.isPresent())
            {       
            	UIHelper.highlightElement(getDriver(), productionCountriesAssigned);
            	waitFor(3000).milliseconds();  
            	String AssignedCountry = productionCountriesAssigned.getTextValue();          	
            	String AssignedCountryXpath = countryAssignedXpath.replace("SERENITY", AssignedCountry);            	
            	WebElementFacade finalAssignedCountryXpath = find(By.xpath(AssignedCountryXpath)); 
            	System.out.println("finalAssignedCountryXpath =" +finalAssignedCountryXpath);
            	// (new Actions(getDriver())).dragAndDrop(finalAssignedCountryXpath, productionCountriesAvailablePanel).perform(); 
            	   
            	 System.out.println("----> Initialize Element --> ");
            	 WebElementFacade dragElement = find(By.xpath(AssignedCountryXpath));
            	 System.out.println("finalAssignedCountryXpath =" +dragElement);
            	 //WebElement dropElement = getDriver().findElement(By.xpath(".//*[@id='main']//*[@class='listWrapper']//*[@id='availableGeographies']"));
            	 Actions builder = new Actions(getDriver());            	 
            	 builder.clickAndHold(dragElement);
            	 System.out.println("----> clickAndHold ----|");
            	 builder.moveToElement(productionCountriesAvailablePanel);
            	 System.out.println("----> moveToElement ----|");
            	 builder.release(productionCountriesAvailablePanel).build().perform();            	 
            	 waitFor(5000).milliseconds();
            	 System.out.println("----> After drop option --> ");
            }            
            
        } catch(Exception e) {
        	e.printStackTrace();
        }
    }
    
    
    public void countryassign(String Countryname) throws Exception {
        try {
        	if(!productionCountriesAssigned.isPresent()){
        		System.out.println(" ----> Country is Not available ---| ");        		
        		String tempCountryAvailableXpath = countryAvailableXpath.replace("SERENITY", Countryname);  
        		System.out.println(" ----> tempCountryAvailableXpath ---| ="+tempCountryAvailableXpath);
                WebElementFacade AvailableCountry = find(By.xpath(tempCountryAvailableXpath));
                (new Actions(getDriver())).dragAndDrop(AvailableCountry, productionCountriesAssignedPanel).perform();
                waitFor(5000).milliseconds();
        		
        	} else {        		
        		System.out.println(" ----> Country is Present ---| ");
        	}        	
                        
        } catch (Exception e) {
        }
        
    }
    
    // Verify Assigned Countries
    public String getAssignedCountry() throws Exception {
        return productionCountriesAssigned.getText();
    }
    
    // Enter Cover Date
    public void entercoverdate(String CoverDate) {
    	try {
    		System.out.println("------> CoverDate ="+CoverDate);
    		if(coverDate.isPresent()) {
    			coverDate.clear();    			
    			coverDate.sendKeys(CoverDate);
    			waitFor(2000).milliseconds();
    		}
    	} catch (Exception e) {
    		
    	}
    }
    
    // Enter Written Date
    public void enterwrittendate(String WrittenDate) {
    	try {
    		System.out.println("------> WrittenDate ="+WrittenDate);
    		if(writtenDate.isPresent()) {
    			writtenDate.clear();    			
    			writtenDate.sendKeys(WrittenDate);
    			waitFor(2000).milliseconds();
    		}
    	} catch (Exception e) {
    		
    	}
    }
    
    // Click Save and Create Instance Button
    public void saveAndCreate() throws Exception {
        try {
            productCreateButton.waitUntilPresent();
            if(productCreateButton.isPresent())
            {
                UIHelper.highlightElement(getDriver(), productCreateButton);
                productCreateButton.click();
                UIHelper.waitForPageToLoad(getDriver());
                editorConsolePageEle.waitUntilPresent();
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }   
    
     }
    
    //Perform Logout
    public void performMMIAppLogout() 
    {
    	try{
        if(userMenuEle.isPresent())
        {
            userMenuEle.click(); 
            UIHelper.highlightElement(getDriver(), logOffEle);            
            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), logOffEleXpath);
            logOffEle.waitUntilPresent();
            logOffEle.waitUntilClickable();
            logOffEle.click();                      
            UIHelper.waitForPageToLoad(getDriver());
            userNameFieldEle.waitUntilPresent();
        }
    	} catch (Exception e){
    		
    	}
    }
    
    //Get the created template status
    public ArrayList<String> getTemplateStatus(String templateName)
    {
        try{
            String tempCreatedTemplateStatusXpath = createdTemplateStatusXpath.replace("SERENITY", templateName);
            List<WebElement> templateStatusList = getDriver().findElements(By.xpath(tempCreatedTemplateStatusXpath));
            
            for(WebElement ele:templateStatusList)
            {
            	UIHelper.highlightElement(getDriver(), ele);
                createdTemplateStatusList.add(ele.getText().trim());
            }
        }
        catch(Exception e)
        {
            
        }
        return createdTemplateStatusList;
    }
    
    //Get Edit Template Page Title
    public String getEditTemplatePageTitle()
    {
        UIHelper.waitForVisibilityOfEleByXpath(getDriver(), editTemplatePageEleXpath);
        editTemplatePageele.waitUntilPresent();        
        return editTemplatePageele.getText().trim();
    }
    
    public void clickOnTemplateWithReadyForPublish(String templateName, String status)
    {
        try{
            
            String tempTemplateWithReadyForPublishXpath = templateWithReadyForPublishXpath.replace("SERENITYTEMPLATE", templateName).replace("SERENITYSTATUS", status);
            WebElementFacade templateWithReadyForPublishEle = find(By.xpath(tempTemplateWithReadyForPublishXpath));
            if(templateWithReadyForPublishEle.isPresent())
            {
                templateWithReadyForPublishEle.click();
                UIHelper.waitForPageToLoad(getDriver());
                publishNowButton.waitUntilPresent();
            }
        }
        catch(Exception e)
        {
            
        }
    }
        
    //Click Publish Now
    public void clickPublishNow() {
        try {
            publishNowButton.waitUntilPresent();
            if(publishNowButton.isPresent())
            {
                UIHelper.highlightElement(getDriver(), publishNowButton);
                publishNowButton.click();
                UIHelper.waitForPageToLoad(getDriver());
                editTemplatePageele.waitUntilPresent();
                unPublishNowButtonEle.waitUntilPresent();
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }   
    
    }
    
    //Download Published Product Report 
    public void downloadProductReport (String fileName) {
        try 
        {
            String tempPublishedFileXpath = publishedFileXpath.replace("SERENITY", fileName);
            WebElementFacade downloadLink = find(By.xpath(tempPublishedFileXpath));
            downloadLink.waitUntilPresent();
            if(downloadLink.isPresent()) {
                UIHelper.mouseOverandclickanElement(getDriver(), downloadLink);
                UIHelper.waitForPageToLoad(getDriver());
                waitFor(15000).milliseconds();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
