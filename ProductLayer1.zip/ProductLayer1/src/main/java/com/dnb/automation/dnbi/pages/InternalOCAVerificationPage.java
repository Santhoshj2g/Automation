package com.dnb.automation.dnbi.pages;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;
import com.google.common.base.Predicate;

/**********************************************************************************************
 * 
 * 
 * @author Vamsi Krishna NV
 * @version 1.0
 ***********************************************************************************************/
public class InternalOCAVerificationPage extends PageObject {
	
	@FindBy(xpath = "//*[@id='header_mainApp']//*[@id='primaryNav']//a[text()='Decision Maker']")
	private WebElementFacade decisionMaker;
	

	@FindBy(xpath ="//*[@class='outerDiv']//*[@id='main']//*[@id='createAppButton']")
	public WebElementFacade startNewApplicationBtn;
	
	@FindBy(xpath ="//*[@id='dmForm1']/h3[contains(.,'Company Identification')]")
	public WebElementFacade newAppliationPageHeadding;
	
	@FindBy(xpath ="//*[@class='outerDiv']//span//*[@class='loadnextbtn'][@type='button']")
	public WebElementFacade loadNextBtn;
	@FindBy(xpath ="//input[@class='loadnextbtn1'][contains(@value,'Load Next')]")
	public WebElementFacade loadNextBtnInSearch;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@id='fqForm1']//table//thead//th[contains(.,'Company  Name')]")
	private WebElementFacade dbSearchTitleEle;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@id='fqForm1']//table//tbody//tr[1]//td[1]//*[@id='searchResList']")
	private WebElementFacade dbSearchResults;
	
	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@id='not_listed'][@type='radio']")
	private WebElementFacade dbSearchResultsNotListed;
	
	@FindBy(xpath ="//*[@class='outerDiv']//span//*[@class='Submitbtn'][@type='button']")
	public WebElementFacade submitBtn;
	
	@FindBy(xpath ="//*[@class='outerDiv']//*[@class='btn entcommon_buttonMargin'][@type='button']")
	public WebElementFacade saveForLaterBtn;	
	
	@FindBy(xpath ="//*[@class='ecf_header']//*[@id='entity_header']//*[@id='businessName']")
	public WebElementFacade appEcf_Header;
	
	@FindBy(xpath ="//*[contains(@id,'ecf_toc')]//a[contains(.,'Credit Application')]")
	public WebElementFacade credit_Application_Btn;
	
	@FindBy(xpath ="//*[@id='widget_container']//*[@class='review_details']//span[2]")
	public WebElementFacade status_Msg;
	
	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Company Summary')]")
	private WebElementFacade companySummaryLinkEle;
	
	@FindBy(xpath = "//*[@class='outerDiv']//*[@class='clear']//table//tbody//tr//a//span[contains(.,'Apply for Credit')]")
	private WebElementFacade applyCreditLink;
	
	@FindBy(xpath = "//*[@id='main']//*[@class='actionButtons']//input[@value='Create Application']")
	private WebElementFacade createApplicationBtn;
	
	@FindBy(xpath = "//*[@id='main']//*[@class='DnBAddressAcc']//li[contains(@class, 'unmatchAcc')]//input[contains(@value, 'Match Company')]")
	private WebElementFacade matchcompanybtn;
	@FindBy(xpath = ".//*[@id='companyMatch']//table//tbody//tr[1]//input[@type='radio']")
	private WebElementFacade selectmatchcompany;
	
	@FindBy(xpath = "//*[@class='iframe_modal']//*[@class='modal_buttons']//input[contains(@value, 'Submit')]")
	private WebElementFacade submitmatchcompany;
	
	@FindBy(xpath = "//*[@id='page_title']/h2")
	private WebElementFacade dmtabledata;
	@FindBy(xpath="//*[@id='viewRecommendedAction']")
	private WebElementFacade clickViewRecommendedCreditTerms;
	@FindBy(xpath="//*[@id='intOrderForm']//input[@class='loadnextbtn1']")
	private WebElementFacade intloadnextinternal;
	
	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
	private WebElementFacade iFrameEle;
    @FindBy(xpath = "//*[@id='backRight']/input")
    private WebElementFacade orderInternationalNextBtnEle;
    String SubmitButton ="//*[@class='outerDiv']//span//*[@class='Submitbtn'][@type='button']";
	String internalloadnextinternational="//*[@id='intOrderForm']";
	String framexpath="//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']";
	String applinamewidget="//*[@id='main']//*[@id='srcRecordList']/tbody";
    String Ecf_Section_Header=".//*[@id='widget_container']//h3[contains(.,'Company Identification')]";
    String startNewBtnXPath="//*[@class='outerDiv']//*[@id='main']//*[@id='createAppButton']";
    String newAppliationPageHeader="//*[@id='breadcrumb']";
    String dbSearchTitleXpath="//*[@class='outerDiv']//*[@id='main']//*[@id='not_listed'][@type='radio']";
    String loadnextbtnxpath="//*[@class='outerDiv']//span//*[@class='loadnextbtn'][@type='button']";
    String applicationECfHeader="//*[@class='ecf_header']//*[@id='entity_header']//*[@id='businessName']";
    String CSSectionHearder = "//*[@id='compTitle']//*[contains(.,'Company Summary')]";
    String submitbtnxpath="//*[@class='outerDiv']//span//*[@class='Submitbtn'][@type='button']";
    String sectionHeader="//*[@id='dm_form_cnt']//h3";
    String matchcompanypopup="//*[@class='iframe_modal']//*[@id='companyMatch']";
    String waitmatchedecf="//*[@id='main']";
    String saveLaterForApplication = "//*[@id='main']//*[@id='pageHead']//*[@id='page_title']/h2";
    String waitmatchbutton="//*[@id='main']//*[@class='DnBAddressAcc']//li[contains(@class, 'unmatchAcc')]//input[contains(@value, 'Match Company')]";
    
    private static long allApprovedCountBefore;
    public static long getAllApprovedCountBefore() {
		return allApprovedCountBefore;
	}
    private static long allSubmittedApplicationCountBefore;
	public static long getAllSubmittedApplicationCountBefore() {
		return allSubmittedApplicationCountBefore;
	}
    private static long allApprovedCountAfter;
    public static long getAllApprovedCountAfter() {
		return allApprovedCountAfter;
	}
	 private static long allSubmittedApplicationCountAfter;
		public static long getAllSubmittedApplicationCountAfter() {
			return allSubmittedApplicationCountAfter;
		}

	private static long myApprovedCountBefore;
    public static long getMyApprovedCountBefore() {
		return myApprovedCountBefore;
	}
    private static long myAllSubmittedApplicationCountBefore;
	public static long getMyAllSubmittedApplicationCountBefore() {
		return myAllSubmittedApplicationCountBefore;
	}
	private static long myApprovedCountAfter;
    public static long getMyApprovedCountAfter() {
		return myApprovedCountAfter;
	}
	    private static long myAllSubmittedApplicationCountAfter;
		public static long getMyAllSubmittedApplicationCountAfter() {
			return myAllSubmittedApplicationCountAfter;
		}
		private static long onlineApprovedCountBefore;
	    public static long getOnlineApprovedCountBefore() {
			return onlineApprovedCountBefore;
		}

	    private static long onlineAllSubmittedApplicationCountBefore;
		public static long getOnlineAllSubmittedApplicationCountBefore() {
			return onlineAllSubmittedApplicationCountBefore;
		}
		private static long onlineApprovedCountAfter;
	    public static long getOnlineApprovedCountAfter() {
			return onlineApprovedCountAfter;
		}
	    private static long onlineAllSubmittedApplicationCountAfter;
		public static long getOnlineAllSubmittedApplicationCountAfter() {
			return onlineAllSubmittedApplicationCountAfter;
		}


	public void click_Internal_OCA_RadioBtn(String FileName) throws Exception{
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), applinamewidget);
		String filePath1 = System.getProperty("user.dir");
		String mypath=filePath1.replace(":", ":\\");
		String filePath = mypath+FileName;
		System.out.println("File Path============"+filePath);
		
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		try {
		    String line = br.readLine();
		    br.close();
		    System.out.println("application Name-----------------"+line);
		    if((getDriver()
					.findElement(
							By.xpath("//*[@id='srcRecordList']/tbody/*[@class='odd-row' or @class='even-row']/td[1][contains(text(),'"
									+ line.trim()
									+ "')]"))).isDisplayed()){
		    	
		    	 WebElement oCAName = (getDriver()
							.findElement(
									By.xpath("//*[@id='srcRecordList']/tbody/*[@class='odd-row' or @class='even-row']/td[1][contains(text(),'"
											+ line.trim()
											+ "')]")));
		    	 WebElement oCARadioBtn = (getDriver()
							.findElement(
									By.xpath("//*[@id='srcRecordList']/tbody/*[@class='odd-row' or @class='even-row']/td[1][contains(text(),'"
											+ line.trim()
											+ "')]//following-sibling::td[@class='centerAlign']//input[@type='radio']")));
			
			UIHelper.highlightElement(getDriver(), oCAName);
			
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", oCARadioBtn);
		    	
		    }
		   
		    
		} finally {
		    
		}
	}
	
	public void click_Internal_OCA_EditBtn(String FileName) throws Exception{
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), applinamewidget);
		String filePath1 = System.getProperty("user.dir");
		String mypath=filePath1.replace(":", ":\\");
		String filePath = mypath+FileName;
		System.out.println("File Path============"+filePath);
		
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		try {
		    String line = br.readLine();
		    br.close();
		    System.out.println("application Name-----------------"+line);
		    if((getDriver()
					.findElement(
							By.xpath("//*[@id='srcRecordList']/tbody/*[@class='odd-row' or @class='even-row']/td[1][contains(text(),'"
									+ line.trim()
									+ "')]"))).isDisplayed()){
		    	
		    	 WebElement oCAName = (getDriver()
							.findElement(
									By.xpath("//*[@id='srcRecordList']/tbody/*[@class='odd-row' or @class='even-row']/td[1][contains(text(),'"
											+ line.trim()
											+ "')]")));
		    	 WebElement oCAEditBtn = (getDriver()
							.findElement(
									By.xpath("//*[@id='srcRecordList']/tbody/*[@class='odd-row' or @class='even-row']/td[1][contains(text(),'"+line.trim()+"')]//following-sibling::td[@class='leftAlign']//a[contains(.,'Edit')]")));
			
			UIHelper.highlightElement(getDriver(), oCAName);
			
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", oCAEditBtn);
		    	
		    }
		   
		    
		} finally {
		    
		}
	}

	public void click_Start_New_Application_Btn() {
		if(startNewApplicationBtn.isPresent()){
		UIHelper.highlightElement(getDriver(), startNewApplicationBtn);
		startNewApplicationBtn.click();
		
		}
	}
	public boolean verify_Decession_Maker_Page(){
		if(dmtabledata.isVisible()){

			return true;
		}else{
			return false;
		}
		
	}
	public boolean verify_Internal_Application_Page(){
		UIHelper.waitForPageToLoad(getDriver());
		if(newAppliationPageHeadding.isVisible()){
			return true;
		}else{
			return false;
		}
	}
	public boolean findHeaderSectionName(String xlSectionName) {
		
		if ((getDriver()
				.findElement(
						By.xpath("//*[@id='dm_form_cnt']//h3[contains(.,'"
								+ xlSectionName + "')]")).isDisplayed())) {

			WebElement sectionHeadTitle = getDriver()
					.findElement(
							By.xpath("//*[@id='dm_form_cnt']//h3[contains(.,'"
									+ xlSectionName + "')]"));

			UIHelper.highlightElement(getDriver(), sectionHeadTitle);
			return true;
		} else {
			return false;
		}
	}

	public boolean Internal_verifyFieldName(String xlSectionName, String xlFieldName) {
		if ((getDriver()
				.findElement(
						By.xpath("//*[@class='outerDiv']//*[@class='dm_form_container']//*[@id='dm_form_cnt']//*[@class='frmSecEdit']//h3[contains(.,'"
								+ xlSectionName
								+ "')]//following-sibling::table//tbody//td[contains(.,'"
								+ xlFieldName
								+ "')]"))).isDisplayed()) {

			WebElement fieldname = getDriver()
					.findElement(
							By.xpath("//*[@class='outerDiv']//*[@class='dm_form_container']//*[@id='dm_form_cnt']//*[@class='frmSecEdit']//h3[contains(.,'"
									+ xlSectionName
									+ "')]//following-sibling::table//tbody//td[contains(.,'"
									+ xlFieldName
									+ "')]"));
			
			UIHelper.highlightElement(getDriver(), fieldname);
			return true;
		} else {
			return false;
		}

	}
	public boolean verifyFieldName(String xlSectionName, String xlFieldName) {
		if ((getDriver()
				.findElement(
						By.xpath("//*[@class='outerDiv']//*[@class='dm_form_container']//*[@id='dm_form_cnt']//*[@class='frmSecEdit']//h3[contains(.,'"
								+ xlSectionName
								+ "')]//following-sibling::table//tbody//td[contains(.,'"
								+ xlFieldName
								+ "')]"))).isDisplayed()) {

			WebElement fieldname = getDriver()
					.findElement(
							By.xpath("//*[@class='outerDiv']//*[@class='dm_form_container']//*[@id='dm_form_cnt']//*[@class='frmSecEdit']//h3[contains(.,'"
									+ xlSectionName
									+ "')]//following-sibling::table//tbody//td[contains(.,'"
									+ xlFieldName
									+ "')]"));
			
			UIHelper.highlightElement(getDriver(), fieldname);
			return true;
		} else {
			return false;
		}

	}
	

	public boolean findMandatoryField(String xlSectionName, String xlFieldName) {

		if ((getDriver()
				.findElement(By
						.xpath("//*[@class='outerDiv']//*[@class='frmSecEdit']//h3[contains(.,'"
								+ xlSectionName
								+ "')]//ancestor::div[1]//tbody//tr//td[contains(.,'"
								+ xlFieldName
								+ "')]//following-sibling::b[contains(@class, 'required')]")))
				.isDisplayed()) {

			WebElement mandatoryfield = getDriver()
					.findElement(
							By.xpath("//*[@class='outerDiv']//*[@class='frmSecEdit']//h3[contains(.,'"
								+ xlSectionName
								+ "')]//ancestor::div[1]//tbody//tr//td[contains(.,'"
								+ xlFieldName
								+ "')]"));
			UIHelper.highlightElement(getDriver(), mandatoryfield);
			return true;
		} else {
			return false;
		}

	}

	public void internal_Enter_Data_Into_Text_Fields(String Value, String xlFieldName, String xlSectionName) {

		if ((getDriver()
				.findElement(By
						.xpath("//*[@class='outerDiv']//*[@class='frmSecEdit']//h3[contains(.,'"
								+ xlSectionName
								+ "')]//ancestor::div[1]//tbody//tr//td[contains(.,'"
								+ xlFieldName
								+ "')]//following-sibling::td[contains(@class, 'frmField')]//input[contains(@class, 'regular')]")))
				.isDisplayed()) {

			WebElement textfield = getDriver()
					.findElement(
							By.xpath("//*[@class='outerDiv']//*[@class='frmSecEdit']//h3[contains(.,'"
								+ xlSectionName
								+ "')]//ancestor::div[1]//tbody//tr//td[contains(.,'"
								+ xlFieldName
								+ "')]//following-sibling::td[contains(@class, 'frmField')]//input[contains(@class, 'regular')]"));
			
			textfield.sendKeys(Value.trim());
		}
	}
	
	public void internal_Enter_Data_Into_Text_FieldsEmail(String EMailid) {

		if ((getDriver()
				.findElement(By
						.xpath("//*[@class='outerDiv']//*[@class='frmSecEdit']//h3[contains(.,'Contact Information')]//ancestor::div[1]//tbody//tr//td[contains(.,'Contact E-mail Address')]//following-sibling::td[contains(@class, 'frmField')]//input")))
				.isDisplayed()) {

			WebElement textfield = getDriver()
					.findElement(
							By.xpath("//*[@class='outerDiv']//*[@class='frmSecEdit']//h3[contains(.,'Contact Information')]//ancestor::div[1]//tbody//tr//td[contains(.,'Contact E-mail Address')]//following-sibling::td[contains(@class, 'frmField')]//input"));
			textfield.sendKeys(EMailid.trim());
		}
	}
	
	
	public void internal_Enter_Data_Into_Text_FieldAppCre(String FieldValue, String xlFieldName, String xlSectionName) {

		if ((getDriver()
				.findElement(By
						.xpath("//*[@class='outerDiv']//*[@class='frmSecEdit']//h3[contains(.,'"
								+ xlSectionName
								+ "')]//ancestor::div[1]//tbody//tr//td[contains(.,'"
								+ xlFieldName
								+ "')]//following-sibling::td[contains(@class, 'frmField')]//input[contains(@class, 'regular')]")))
				.isDisplayed()) {

			WebElement textfield = getDriver()
					.findElement(
							By.xpath("//*[@class='outerDiv']//*[@class='frmSecEdit']//h3[contains(.,'"
								+ xlSectionName
								+ "')]//ancestor::div[1]//tbody//tr//td[contains(.,'"
								+ xlFieldName
								+ "')]//following-sibling::td[contains(@class, 'frmField')]//input[contains(@class, 'regular')]"));
			
			textfield.sendKeys(FieldValue.trim());
		}
	}
	public void internal_Select_Data_For_List_Fields(String xlSectionName, String xlFieldName,String Value) {

		if ((getDriver()
				.findElement(By
						.xpath("//*[@class='outerDiv']//*[@class='frmSecEdit']//h3[contains(.,'"
								+ xlSectionName
								+ "')]//ancestor::div[1]//tbody//tr//td[contains(.,'"
								+ xlFieldName
								+ "')]")))
				.isDisplayed()) {

			WebElement selectField = getDriver()
					.findElement(
							By.xpath("//*[@class='outerDiv']//*[@class='frmSecEdit']//h3[contains(.,'"
								+ xlSectionName
								+ "')]//ancestor::div[1]//tbody//tr//td[contains(.,'"
								+ xlFieldName
								+ "')]//following-sibling::td[contains(@class, 'frmField')]//select"));
			Select selectElement = new Select(selectField);
			selectElement.selectByVisibleText(Value.trim());
		} 
	}

	public void internal_Click_Load_Next_Btn() {

		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", loadNextBtn);
		loadNextBtn.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), loadNextBtn);
		loadNextBtn.click();
	}
	
	public void internal_CInfo_Click_Load_Next_Btn() {
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", loadNextBtn);
		loadNextBtn.waitUntilClickable();
		//loadNextBtn.waitUntilVisible();
		UIHelper.highlightElement(getDriver(), loadNextBtn);
		loadNextBtn.click();
		if(loadNextBtn.isVisible()){
			loadNextBtn.click();
			UIHelper.waitForPageToLoad(getDriver());
				if(loadNextBtn.isVisible()){
					loadNextBtn.click();	
					UIHelper.waitForPageToLoad(getDriver());
						if(loadNextBtn.isVisible()){
							loadNextBtn.click();	
							UIHelper.waitForPageToLoad(getDriver());
								if(loadNextBtn.isVisible()){
								   loadNextBtn.click();	
								   UIHelper.waitForPageToLoad(getDriver());
								}
						}
				}
		}		
		if(intloadnextinternal.isPresent()){
			intloadnextinternal.click();
		}
	}
	
	public boolean is_Next_Section_Displayed(String xlSectionName){
		String sectionHeader="//*[@id='dm_form_cnt']//h3[contains(.,'"+ xlSectionName + "')]";
		waitFor(9000).milliseconds();
		WebElementFacade xPathEle = (find(By.xpath("//h3[normalize-space(text())='"+xlSectionName+"']")));
		/*WebElement sectionHeadTitle = getDriver()
				.findElement(
						By.xpath("//h3[normalize-space(text())='"+xlSectionName+"']"));*/
		xPathEle.waitUntilVisible();
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", xPathEle);
		UIHelper.highlightElement(getDriver(), xPathEle);
		return true;
	}
	public boolean is_D_And_B_Search_Results_Displayed(){
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), dbSearchTitleXpath);
		if(dbSearchResults.isVisible() || dbSearchResultsNotListed.isVisible()){
			return true;
		}else{
			return false;
		}
	}
	public void select_A_Match_From_Results(){
		if(dbSearchResults.isVisible()){
			dbSearchResults.click();
		}else{
			dbSearchResultsNotListed.click();
		}
		
	}
	public void select_A_Match_From_Results_LoadNext(){
		if(dbSearchResults.isVisible()){
			dbSearchResults.click();
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", loadNextBtn);
			UIHelper.highlightElement(getDriver(), loadNextBtn);
			loadNextBtn.click();
			try{
				((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", loadNextBtnInSearch);
				loadNextBtnInSearch.click();	
			} catch (Exception e) {
				
			}
		}else{
			dbSearchResultsNotListed.click();
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", loadNextBtn);
			UIHelper.highlightElement(getDriver(), loadNextBtn);
			loadNextBtn.click();
			
		}
		
	}
	
	public void submitbtnclick() {
		
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), SubmitButton);
		if(submitBtn.isPresent()){
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", submitBtn);
			submitBtn.click();
		System.out.println("submit button has clicked-------------------------------");
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), applicationECfHeader);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), CSSectionHearder);
		if (orderInternationalNextBtnEle.isPresent()) {
            orderInternationalNextBtnEle.click();
            UIHelper.waitForPageToLoad(getDriver());
        }
		}
	}
	
	public void saveLaterbtnclick() {		
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), SubmitButton);
		if(saveForLaterBtn.isPresent()){			
			saveForLaterBtn.click();
		System.out.println("saveForLaterBtn button has clicked-------------------------------");
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), saveLaterForApplication);
		}	
	}


	public boolean is_Application_Ecf_Page_Displayed(){
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), applicationECfHeader);
		UIHelper.highlightElement(getDriver(), appEcf_Header);
		if(appEcf_Header.isVisible()){
			return true;
		}else{
			return false;
		}
	}
	public void credit_Appliation_Btnclick() {
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", credit_Application_Btn);
		credit_Application_Btn.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), credit_Application_Btn);
		credit_Application_Btn.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), Ecf_Section_Header);
		
		

	}
	
	public boolean verify_Internal_App_Status(String Status){
		String [] applicationStatus=Status.split("OR");
		System.out.println("given values----------------"+applicationStatus[0]+" --- "+applicationStatus[1]+" --- "+applicationStatus[2]);
		String statusMessage=status_Msg.getText();
		System.out.println("statusMessage------"+statusMessage);
		if(statusMessage.contains(applicationStatus[0].trim()) || statusMessage.contains(applicationStatus[1].trim()) || statusMessage.contains(applicationStatus[2].trim())){
			return true;
		}else{
			return false;
		}
		
	}
	public void matchCompany(){
		try
		{
			
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), waitmatchbutton);
		matchcompanybtn.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), matchcompanybtn);
		matchcompanybtn.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
		getDriver().switchTo().frame(iFrameEle);
		/*UIHelper.waitForVisibilityOfEleByXpath(getDriver(), matchcompanypopup);*/
		
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", selectmatchcompany);
		waitFor(2000).milliseconds();
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", selectmatchcompany);
		submitmatchcompany.click();
		getDriver().switchTo().defaultContent();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), applicationECfHeader);
} catch (Exception e) {
			
		}
	}
	public void click_Company_Summary_Tab() {
		try {
			if (companySummaryLinkEle.isPresent()) {
				companySummaryLinkEle.click();
				
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						CSSectionHearder);

			}
		} catch (Exception e) {
			
		}
	}
	public void click_Apply_Credit_Link(){
		if(applyCreditLink.isVisible()){
			UIHelper.highlightElement(getDriver(), applyCreditLink);
			applyCreditLink.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), newAppliationPageHeader);
			
		}
	}
	
	public void click_Create_Application(){
		if(createApplicationBtn.isVisible()){
			UIHelper.highlightElement(getDriver(), createApplicationBtn);
			createApplicationBtn.click();
		}
	}
	public void clickViewRecommendedCreditTermsECF(){
		clickViewRecommendedCreditTerms.waitUntilClickable();
		clickViewRecommendedCreditTerms.click();	
		
	}
	
	public String validateCreditMethod(String creditMethod) {
		UIHelper.waitForPageToLoad(getDriver());
		String fixedXpath="//div[@id='reviewOutcome']//div[@id='credit_hold_rec_action']//table[3]//tbody//tr//td[contains(.,'"+creditMethod+"')]";
		WebElementFacade fixedElement=find(By.xpath(fixedXpath));
//		creditLimitMethod.waitUntilVisible();
		UIHelper.highlightElement(getDriver(), fixedElement);
		String creditMethodECF=fixedElement.getText();
		String creditLimitValueECF=getDriver().findElement(By.xpath("//div[@id='reviewOutcome']/div[@id='credit_hold_rec_action']/table[3]/tbody/tr/td[contains(.,'"+creditMethodECF+"')]/following-sibling::td")).getText();
		if (creditMethodECF.contains(creditMethod)){
			System.out.println("Credit Method is :" +creditMethodECF   +" Limit Value is :" +creditLimitValueECF);
		}
		else
		{
			System.out.println("Credit Method validation Failed");
	}
		return creditMethodECF;
	 }
	
	public void getAllApplicationCountBefore(String accountName){

		String accNameXpth="//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[normalize-space(text())='"+accountName+"']//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']";
		 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), accNameXpth);
		 WebElement accNameElement = getDriver()
					.findElement(
							By.xpath("//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[normalize-space(text())='"+accountName+"']//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']"));
		 UIHelper.highlightElement(getDriver(), accNameElement);
		 
		 if(accountName.equals("Approved")){
			 waitFor(1000).milliseconds();
			 allApprovedCountBefore=Long.parseLong(accNameElement.getText().trim());
			 System.out.println("All Application Before- "+accountName+"------"+allApprovedCountBefore);
		 }
		 else if(accountName.equals("Submitted Applications")){
			 waitFor(1000).milliseconds();
			 allSubmittedApplicationCountBefore=Long.parseLong(accNameElement.getText().trim());
			 System.out.println("All Application Before - "+accountName+"------"+allSubmittedApplicationCountBefore);
		 }
		 
	 }
	public void getAllApplicationCountAfter(String accountName){
		 
		 String accNameXpth="//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[normalize-space(text())='"+accountName+"']//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']";
		 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), accNameXpth);
		 WebElement accNameElement = getDriver()
					.findElement(
							By.xpath("//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[normalize-space(text())='"+accountName+"']//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']"));
		 UIHelper.highlightElement(getDriver(), accNameElement);
		 if(accountName.equals("Approved")){
			 waitFor(1000).milliseconds();
			 allApprovedCountAfter=Long.parseLong(accNameElement.getText().trim());
			 System.out.println("All Application After- "+accountName+"------"+allApprovedCountAfter);
			 	 
		 }
		 else if(accountName.equals("Submitted Applications")){
			 waitFor(1000).milliseconds();
			 allSubmittedApplicationCountAfter=Long.parseLong(accNameElement.getText().trim());
			 System.out.println("All Application Ater- "+accountName+"------"+allSubmittedApplicationCountAfter);
			 
		 }
		 
	 }
	 
	 public void getMyApplicationCountBefore(String accountName){
		 String accNameXpth="//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[normalize-space(text())='"+accountName+"']//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']";
		 
		 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), accNameXpth);
		 WebElement accNameElement = getDriver()
					.findElement(
							By.xpath("//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[normalize-space(text())='"+accountName+"']//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']"));
		 UIHelper.highlightElement(getDriver(), accNameElement);
		 if(accountName.equals("Approved")){
			 waitFor(1000).milliseconds();
			 myApprovedCountBefore=Long.parseLong(accNameElement.getText().trim());
			 System.out.println("My Application Before- "+accountName+"------"+myApprovedCountBefore);
			 
		 }
		 else if(accountName.equals("Submitted Applications")){
			 waitFor(1000).milliseconds();
			 myAllSubmittedApplicationCountBefore=Long.parseLong(accNameElement.getText().trim());
			 System.out.println("My Application Before- "+accountName+"------"+myAllSubmittedApplicationCountBefore);
			 
		 }
		 
	 }
	 
	 public void getMyApplicationCountAfter(String accountName){
		 String accNameXpth="//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[normalize-space(text())='"+accountName+"']//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']";
		 
		 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), accNameXpth);
		 WebElement accNameElement = getDriver()
					.findElement(
							By.xpath("//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[normalize-space(text())='"+accountName+"']//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']"));
		 UIHelper.highlightElement(getDriver(), accNameElement);
		 if(accountName.equals("Approved")){
			 waitFor(1000).milliseconds();
			 myApprovedCountAfter=Long.parseLong(accNameElement.getText().trim());
			 System.out.println("My Application After- "+accountName+"------"+myApprovedCountAfter);
			 			 
		 }
		 else if(accountName.equals("Submitted Applications")){
			 waitFor(1000).milliseconds();
			 myAllSubmittedApplicationCountAfter=Long.parseLong(accNameElement.getText().trim());
			 System.out.println("My Application AFter- "+accountName+"------"+myAllSubmittedApplicationCountAfter);
			 
		 }
		 
	 }
	 public void getOnlineApplicationCountBefore(String accountName){
		 String accNameXpth="//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[normalize-space(text())='"+accountName+"']//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']";
		 
		 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), accNameXpth);
		 WebElement accNameElement = getDriver()
					.findElement(
							By.xpath("//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[normalize-space(text())='"+accountName+"']//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']"));
		 UIHelper.highlightElement(getDriver(), accNameElement);
		 if(accountName.equals("Approved")){
			 waitFor(1000).milliseconds();
			 onlineApprovedCountBefore=Long.parseLong(accNameElement.getText().trim());
			 System.out.println("Online Application Before- "+accountName+"------"+onlineApprovedCountBefore);
			 
		 }
		 else if(accountName.equals("Submitted Applications")){
			 waitFor(1000).milliseconds();
			 onlineAllSubmittedApplicationCountBefore=Long.parseLong(accNameElement.getText().trim());
			 System.out.println("Online Application Before- "+accountName+"------"+onlineAllSubmittedApplicationCountBefore);
			 
		 }
		 
	 }
	 public void getOnlineApplicationCountAfter(String accountName){
		 String accNameXpth="//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[normalize-space(text())='"+accountName+"']//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']";
		 
		 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), accNameXpth);
		 WebElement accNameElement = getDriver()
					.findElement(
							By.xpath("//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[normalize-space(text())='"+accountName+"']//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']"));
		 UIHelper.highlightElement(getDriver(), accNameElement);
		 if(accountName.equals("Approved")){
			 waitFor(1000).milliseconds();
			 onlineApprovedCountAfter=Long.parseLong(accNameElement.getText().trim());
			 System.out.println("Online Application Ater- "+accountName+"------"+onlineApprovedCountAfter);
			 
		 }
		 else if(accountName.equals("Submitted Applications")){
			 waitFor(1000).milliseconds();
			 onlineAllSubmittedApplicationCountAfter=Long.parseLong(accNameElement.getText().trim());
			 System.out.println("Online Application After- "+accountName+"------"+onlineAllSubmittedApplicationCountAfter);
			 
		 }
		 
	 }

}