package com.dnb.automation.dnbi.pages;

import java.util.List;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.dnb.automation.utils.UIHelper;

public class CreateOCARulePage extends PageObject {
	
	@FindBy(xpath="//div[@id='header_mainApp']//li[contains(.,'Admin')]")
	private WebElementFacade adminTab;
	
	@FindBy(xpath="//div[@id='main']//div[@class='ecf_toc']//a[contains(.,'Credit Applications Admin')]")
	private WebElementFacade creditApplicationsAdmin;
	
	@FindBy(xpath="//div[@id='main']//div[@class='ecf_page']//a[contains(.,'Set Decision Maker Rules')]")
	private WebElementFacade decisionMakerRulesLink;
	
	@FindBy(xpath="//div[@id='main']//div[@class='ecf_toc']//a[contains(.,'Account Manager Admin')]")
	private WebElementFacade creditAccountAdmin;
	
	@FindBy(xpath="//div[@id='main']//a[contains(.,'Set Account Review Rules')]")
	private WebElementFacade accountMakerRulesLink;
	
	@FindBy(xpath="//div[@id='main']//tbody//tr//input[@value='Create New Rule']")
	private WebElementFacade createNewRuleBtn;
	
	@FindBy(xpath="//div[@id='main']//tbody//tr//input[@value='Create New RuleSet']")
	private WebElementFacade createNewRuleSetBtn;
	
	@FindBy(xpath="//input[@value='Next']")
	 private WebElementFacade rulesPageNext;
	
	@FindBy(xpath="//div[@class='widget_form']//div[@class='adminContent']//input[@id='radio1']")
	private WebElementFacade createRuleFromScratch;
	
	@FindBy(xpath="//*[@id='adminLayout']/div/form/div[3]/input[@type='radio']")
	private WebElementFacade copyExistingRule;
	
	@FindBy(xpath="//div[@class='widget_form']//div[@class='adminContent']//input[@id='rad1']")
	private WebElementFacade selectCountryUS;
	
	@FindBy(xpath="//div[@class='widget_form']//div[@class='adminContent']//input[@id='rad2']")
	private WebElementFacade selectAllOtherCountries;
	
	@FindBy(xpath="//div[@class='widget_form']//div[@class='adminContent']//form[@name='ruleForm']")
	private WebElementFacade selectRuleCountry;
	
	@FindBy(xpath="//div[@id='main']//div[@class='widget_form']//table//input[@value='Pending']")
	private WebElementFacade decisionRulePending;
	
	@FindBy(xpath="//div[@id='main']//div[@class='widget_form']//table//input[@value='Declined']")
	private WebElementFacade decisionRuleDeclined;
	
	@FindBy(xpath="//div[@id='main']//div[@class='widget_form']//table//input[@value='Approved']")
	private WebElementFacade decisionRuleApproved;
	
	@FindBy(xpath="//div[@id='main']//div[@id='cats']//select[@id='categoryPool']")
	private WebElementFacade categoryDrpDwn;
	
	@FindBy(xpath="//div[@id='main']//div[@id='vars']//select[@id='pool']")
	private WebElementFacade selectAvailableVariables;
	
	@FindBy(xpath="//div[@id='main']//div[@id='fields']//div[@id='sel']//a[1]")
	private WebElementFacade addVariables;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[2]//td/div/table/tbody/tr[2]/td/select")
	private WebElementFacade firstDropDown;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[2]//td/div/table/tbody/tr[2]/td/input[1]")
	private WebElementFacade firstTextBox;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[4]//td/div/table/tbody/tr[2]/td/select")
	private WebElementFacade secondDropDown;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[4]//td/div/table/tbody/tr[2]/td/input[1]")
	private WebElementFacade secondTextBox;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[6]//td/div/table/tbody/tr[2]/td/select")
	private WebElementFacade thirdDropDown;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[6]//td/div/table/tbody/tr[2]/td/input[1]")
	private WebElementFacade thirdTextBox;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[8]//td/div/table/tbody/tr[2]/td/select")
	private WebElementFacade forthDropDown;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[8]//td/div/table/tbody/tr[2]/td/input[1]")
	private WebElementFacade forthTextBox;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[10]//td/div/table/tbody/tr[2]/td/select")
	private WebElementFacade fifthDropDown;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[10]//td/div/table/tbody/tr[2]/td/input[1]")
	private WebElementFacade fifthTextBox;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[12]//td/div/table/tbody/tr[2]/td/select")
	private WebElementFacade sixthDropDown;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[12]//td/div/table/tbody/tr[2]/td/input[1]")
	private WebElementFacade sixthTextBox;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[14]//td/div/table/tbody/tr[2]/td/select")
	private WebElementFacade seventhDropDown;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[14]//td/div/table/tbody/tr[2]/td/input[1]")
	private WebElementFacade seventhTextBox;
	
	//table[@class='results']//tbody//tr[14]//tbody//td//select
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[14]//td/div/table/tbody/tr[2]/td/select")
	private WebElementFacade seventhDropDownSingle;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[14]//td/div/table/tbody/tr[2]/td/input[1]")
	private WebElementFacade seventhTextBoxSingle;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[16]//td/div/table/tbody/tr[2]/td/select")
	private WebElementFacade eighthDropDown;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[16]//td/div/table/tbody/tr[2]/td/input[1]")
	private WebElementFacade eighthTextBox;
	
	
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[18]//td/div/table/tbody/tr[2]/td/select")
	private WebElementFacade ninthDropDown;
	
	@FindBy(xpath="//table[@class='results']//tbody//tr//td//table//tbody//tr[18]//td/div/table/tbody/tr[2]/td/input[1]")
	private WebElementFacade ninthTextBox;
	
	@FindBy(xpath="//form[@name='ruleForm']//select[@name='clmSelected']")
	private WebElementFacade selectCreditLimit;
	
	@FindBy(xpath="//form[@name='ruleForm']//textarea[@name='analystInstruction']")
	private WebElementFacade enterAnalaystInstructionsTxt;
	
	@FindBy(xpath="//form[@name='ruleForm']//input[@name='ruleName']")
	private WebElementFacade decisionRuleName;
	
	@FindBy(xpath="//div[@id='backRight']//input[@value='Save']")
	private WebElementFacade saveDecisionRule;
	
	@FindBy(xpath="//div[@id='terr_viewItems']//select[@id='viewItems']")
	private WebElementFacade selectViewDrpDwn;
	
	@FindBy(xpath="//*[@id='main']//*[@id='tab1']")
	private List<WebElementFacade> decisionRuleNameList;
	
	@FindBy(xpath="//div[@id='adminLayout']//input[@name='groupName']")
	private WebElementFacade enterRuleName;
	
	@FindBy(xpath="//div[@class='ruleSetContainer']//input[@value='D']")
	private WebElementFacade ruleSetSelectUS;
	
	@FindBy(xpath="//div[@class='ruleSetContainer']//input[@value='I']")
	private WebElementFacade ruleSetSelectOtherCountry;
	
	@FindBy(xpath="//div[@class='ruleSetContainer']//select[@id='categoryPool']")
	private WebElementFacade ruleSetSelectCategory;
	
	@FindBy(xpath="//div[@class='ruleSetContainer']//select[@id='selVariable']")
	private WebElementFacade ruleSetVariableName;
	
	@FindBy(xpath="//div[@class='ruleSetContainer']//div//table//tr//select")
	private WebElementFacade ruleSetVariableDrpDwn;
	
	@FindBy(xpath="//div[@class='ruleSetContainer']//div//table//tr//input")
	private WebElementFacade ruleSetVariableValue;
	
	@FindBy(xpath="//div[@id='adminLayout']//input[@value='Submit']")
	private WebElementFacade ruleSetSubmit;
	
	@FindBy(xpath="//div[@id='main']//div[@id='tabs1']//a[@id='ruleTab']")
	private WebElementFacade clickRuleSetTab;
	
	
	private WebElement delRuleName;
	private String tableResFull1 ="//*[@class='outerDiv']//*[contains(@class,'results full')]";
	String rulesTableExpath="//*[@id='tab1']//thead";
	String andConditionPageXpath="//div[@id='main']//div[@id='cats']//select[@id='categoryPool']";
	String ruletable="//*[@id='tab1']//table//tbody//tr";
	
	public void navigateToConfigureRuleAccountPage(){

		UIHelper.highlightElement(getDriver(), adminTab);
		adminTab.click();
		UIHelper.highlightElement(getDriver(), creditAccountAdmin);
		creditAccountAdmin.click();
		UIHelper.highlightElement(getDriver(), accountMakerRulesLink);
		accountMakerRulesLink.click();

	}
	
	
	public void createNewRulePage(){

		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), createNewRuleBtn);
		createNewRuleBtn.click();

	}
	
	public void clickDecisionRulesNextPage(){

		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), rulesPageNext);
		rulesPageNext.click();

	}
	
	
	
	public void selectCountryPage(String ruleOption, String selectCountry){
		try{
		UIHelper.waitForPageToLoad(getDriver());
		System.out.println("Rule Option is:*************" +ruleOption );
		System.out.println("Country is:*************" +selectCountry );
		
		if(ruleOption.contains("Create Rule from Scratch"))
		{
			System.out.println("rules oiption mathced------------------");
			waitFor(2000).milliseconds();
			UIHelper.highlightElement(getDriver(), createRuleFromScratch);
			if(!createRuleFromScratch.isSelected()){
				createRuleFromScratch.click();
				waitFor(2000).milliseconds();
			}
			
		}
		else{
			UIHelper.highlightElement(getDriver(), copyExistingRule);
			copyExistingRule.click();
		}
		
		if(selectCountry.contains("United States & Canada")){
			if(!selectCountryUS.isSelected()){
				waitFor(2000).milliseconds();
				UIHelper.highlightElement(getDriver(), selectCountryUS);
				selectCountryUS.click();
			}
			
		}
		else if(selectCountry.contains("All Other Countries")){
			Thread.sleep(2000);
			UIHelper.highlightElement(getDriver(), selectAllOtherCountries);
			selectAllOtherCountries.click();	
		}
		UIHelper.highlightElement(getDriver(), rulesPageNext);
		rulesPageNext.click();
		}catch(Exception e){
			e.printStackTrace();
		}
			
	}
	
	public void clickRuleOverviewNextPage(){

		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), rulesPageNext);
		rulesPageNext.click();

	}
	
	public void selectDecisionRulePage(String decisionRule){

		UIHelper.waitForPageToLoad(getDriver());
		String ruleoption="//div[@id='main']//div[@class='widget_form']//tbody//tbody//tbody//td[contains(.,'"+decisionRule+"')]";
		WebElementFacade decisionoption=find(By.xpath(ruleoption));
		if(decisionoption.getText().contains(decisionRule)){
			
			String ruleoption2="//div[@id='main']//div[@class='widget_form']//tbody//tbody//tbody//input[@value='"+decisionRule+"']";
			WebElementFacade selectdecisionoption=find(By.xpath(ruleoption2));
			selectdecisionoption.click();
		}
		UIHelper.highlightElement(getDriver(), rulesPageNext);
		rulesPageNext.click();

	}
	
	public void selectAvailableVariablesPage(String businessVariables, String availableVariables){

		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), categoryDrpDwn);
		categoryDrpDwn.selectByVisibleText(businessVariables);
		
		String availableVariable[] = availableVariables.split(",");
		for(String selectAvailableVariable:availableVariable){
			System.out.println("Variable names are:********+++++++++++++" +selectAvailableVariable);
			selectAvailableVariables.selectByVisibleText(selectAvailableVariable);
		}
		
		addVariables.click();
		UIHelper.highlightElement(getDriver(), rulesPageNext);
		//rulesPageNext.click();

	}
	
	public void selectRuleVariables(String businessVariables, String availableVariables){

		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), andConditionPageXpath);
		UIHelper.highlightElement(getDriver(), categoryDrpDwn);
		categoryDrpDwn.selectByVisibleText(businessVariables);
		waitFor(500).milliseconds();
		if(availableVariables.contains(",")){
			String availableVariable[] = availableVariables.split(",");
			for(String selectAvailableVariable:availableVariable){
				System.out.println("Variable names are:********+++++++++++++" +selectAvailableVariable);
				String variablesXpath="//div[@id='main']//div[@id='vars']//select[@id='pool']//option[.='"+selectAvailableVariable.trim()+"']";
				WebElementFacade variablesEle=find(By.xpath(variablesXpath));
				variablesEle.click();
				addVariables.click();
				waitFor(500).milliseconds();
			}
		}else{
			System.out.println("Variable names are:********+++++++++++++" +availableVariables);
			String variablesXpath="//div[@id='main']//div[@id='vars']//select[@id='pool']//option[.='"+availableVariables.trim()+"']";
			WebElementFacade variablesEle=find(By.xpath(variablesXpath));
			variablesEle.click();
			addVariables.click();
			waitFor(500).milliseconds();
			
		}
		
		UIHelper.highlightElement(getDriver(), rulesPageNext);
	}
	
	
	public void enterFirstVariablePage(String availableVariables,String selectDropDown1, String valueforDropdown1){

		UIHelper.waitForPageToLoad(getDriver());
		String[] selectDropDownArray=selectDropDown1.split(",");
		UIHelper.highlightElement(getDriver(), firstDropDown);
		firstDropDown.selectByVisibleText(selectDropDownArray[0]);
		UIHelper.highlightElement(getDriver(), secondDropDown);
		secondDropDown.selectByVisibleText(selectDropDownArray[1]);
		UIHelper.highlightElement(getDriver(), thirdDropDown);
		thirdDropDown.selectByVisibleText(selectDropDownArray[2]);
		
		String values[]=valueforDropdown1.split(",");
		UIHelper.highlightElement(getDriver(), firstTextBox);
		firstTextBox.sendKeys(values[0]);
		UIHelper.highlightElement(getDriver(), secondTextBox);
		secondTextBox.sendKeys(values[1]);
		UIHelper.highlightElement(getDriver(), thirdTextBox);
		thirdTextBox.sendKeys(values[2]);

	}
	
	
	public void enterSecondVariablePage(String availableVariables,String selectDropDown1, String valueforDropdown1){

		UIHelper.waitForPageToLoad(getDriver());
		String[] selectDropDownArray=selectDropDown1.split(",");
		UIHelper.highlightElement(getDriver(), forthDropDown);
		forthDropDown.selectByVisibleText(selectDropDownArray[0]);
		UIHelper.highlightElement(getDriver(), fifthDropDown);
		fifthDropDown.selectByVisibleText(selectDropDownArray[1]);
		UIHelper.highlightElement(getDriver(), sixthDropDown);
		sixthDropDown.selectByVisibleText(selectDropDownArray[2]);
		
		String values[]=valueforDropdown1.split(",");
		UIHelper.highlightElement(getDriver(), forthTextBox);
		forthTextBox.sendKeys(values[0]);
		UIHelper.highlightElement(getDriver(), fifthTextBox);
		fifthTextBox.sendKeys(values[1]);
		UIHelper.highlightElement(getDriver(), sixthTextBox);
		sixthTextBox.sendKeys(values[2]);

	}
	
	public void enterThirdVariablePage(String availableVariables,String selectDropDown1, String valueforDropdown1){

		UIHelper.waitForPageToLoad(getDriver());
		String[] selectDropDownArray=selectDropDown1.split(",");
		//String selectDropDownArray=selectDropDown1;
		/*UIHelper.highlightElement(getDriver(), seventhDropDown);
		seventhDropDown.selectByVisibleText(selectDropDownArray);*/
		for(String drop1:selectDropDownArray){
			
		}
		UIHelper.highlightElement(getDriver(), eighthDropDown);
		eighthDropDown.selectByVisibleText(selectDropDownArray[1]);
		UIHelper.highlightElement(getDriver(), ninthDropDown);
		ninthDropDown.selectByVisibleText(selectDropDownArray[2]);
		
		String values[]=valueforDropdown1.split(",");
		/*String values=valueforDropdown1;
		UIHelper.highlightElement(getDriver(), seventhTextBox);
		seventhTextBox.clear();
		seventhTextBox.sendKeys(values);*/
		UIHelper.highlightElement(getDriver(), eighthTextBox);
		eighthTextBox.clear();
		eighthTextBox.sendKeys(values[1]);
		UIHelper.highlightElement(getDriver(), ninthTextBox);
		ninthTextBox.clear();
		ninthTextBox.sendKeys(values[2]);

	}
	
	
	public void enterThirdVariablePageSingleScore(String availableVariables,String selectDropDown1, String valueforDropdown1){

		
			UIHelper.highlightElement(getDriver(), seventhDropDown);
			seventhDropDown.selectByVisibleText(selectDropDown1);
			seventhTextBox.clear();
			seventhTextBox.sendKeys(valueforDropdown1);

	}
	
	public void enter_Values_For_Conditions(String FiledName, String Condition, String Valeu1,String Value2){

		waitFor(2000).milliseconds();
		String conditionXpath="//*[@id='criteriaFm']//table//tbody//table//tbody//tr[contains(.,'"+FiledName+"')]//following-sibling::tr[1]//table//tbody//select";
		String valueoneXpath="//*[@id='criteriaFm']//table//tbody//table//tbody//tr[contains(.,'"+FiledName+"')]//following-sibling::tr[1]//table//tbody//input[1]";
		String valuetwoXpath="//*[@id='criteriaFm']//table//tbody//table//tbody//tr[contains(.,'"+FiledName+"')]//following-sibling::tr[1]//table//tbody//input[2]";
		
		if(Condition.equals("Is Blank") || Condition.equals("Is Not Blank") || Condition.equals("Is True") || Condition.equals("Is False")){
			WebElementFacade conditionElement=find(By.xpath(conditionXpath));
			conditionElement.selectByVisibleText(Condition);
		}
		else if (Condition.equals("Is Within Range")){
			WebElementFacade conditionElement=find(By.xpath(conditionXpath));
			conditionElement.selectByVisibleText(Condition);
			WebElementFacade valueOneElement=find(By.xpath(valueoneXpath));
			valueOneElement.clear();
			valueOneElement.sendKeys(Valeu1);
			WebElementFacade valueTwoElement=find(By.xpath(valuetwoXpath));
			valueTwoElement.clear();
			valueTwoElement.sendKeys(Value2);
		}
		else{
			WebElementFacade conditionElement=find(By.xpath(conditionXpath));
			conditionElement.selectByVisibleText(Condition);
			WebElementFacade valueOneElement=find(By.xpath(valueoneXpath));
			valueOneElement.clear();
			if(FiledName.contains("Country")){
				String[] countryvalue=Valeu1.split(",");
				for(int i=1; i<countryvalue.length; i++)
				{
					String addCondition="//*[@id='criteriaFm']//table//tbody//table//tbody//tr[contains(.,'Country')]//td//span/a[contains(.,'Add Condition')]";
					WebElementFacade addconditionelement=find(By.xpath(addCondition));
				String variablexpath="//*[@id='criteriaFm']//table//tbody//table//tbody//tr[contains(.,'Country')]//following-sibling::tr/td//table/tbody/tr[contains(@id,'tr_"+i+"')]//input[1]";
				WebElementFacade entervalueforvariable=find(By.xpath(variablexpath));
				entervalueforvariable.sendKeys(countryvalue[i-1]);
				addconditionelement.click();
				}
				String variablexpath2="//*[@id='criteriaFm']//table//tbody//table//tbody//tr[contains(.,'Country')]//following-sibling::tr/td//table/tbody/tr[contains(@id,'tr_10')]//input[1]";
				WebElementFacade entervalueforvariable2=find(By.xpath(variablexpath2));
				entervalueforvariable2.sendKeys(countryvalue[9]);
			}
			else
			{
				valueOneElement.sendKeys(Valeu1);
			}
		}

	}
	
	
	public void selectCreditLimitPage(String creditLimitName){

		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), selectCreditLimit);
		selectCreditLimit.selectByVisibleText(creditLimitName.trim());

	}
	
	public void enterAnalaystInstructionsPage(String analystInstructions){

		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), enterAnalaystInstructionsTxt);
		enterAnalaystInstructionsTxt.sendKeys(analystInstructions);

	}
	
	public void saveDecisionRule(String ruleName){

		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), decisionRuleName);
		decisionRuleName.sendKeys(ruleName);
		UIHelper.highlightElement(getDriver(), saveDecisionRule);
		saveDecisionRule.click();

	}
	
	public void viewDecisionRulesPage(String decisionRuleNames){

		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), selectViewDrpDwn);
		selectViewDrpDwn.selectByVisibleText(decisionRuleNames);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), rulesTableExpath);

	}
	
	public void viewDecisionRuleSetPage(String decisionRuleNames){

		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), clickRuleSetTab);
		clickRuleSetTab.click();
		UIHelper.highlightElement(getDriver(), selectViewDrpDwn);
		selectViewDrpDwn.selectByVisibleText(decisionRuleNames);

	}
	
	public void deleteRulePage(String Rulename){
		try{
			UIHelper.waitForPageToLoad(getDriver());
				WebElementFacade deleteRuleName=find(By.xpath("//*[@id='tab1']//table//tbody//tr//td[normalize-space(text())='"+Rulename+"']//ancestor::td//following-sibling::td//a[contains(.,'Delete')]"));
				((JavascriptExecutor) getDriver()).executeScript(
						"arguments[0].scrollIntoView(true);", deleteRuleName);
				deleteRuleName.click();
			waitFor(1000).milliseconds();
			UIHelper.processalert(getDriver());
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), ruletable);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	public void deleteRuleSetPage(String RuleSetname){
		UIHelper.waitForPageToLoad(getDriver());
		try{
		if((find(By.xpath("//*[@id='terr_valueTable']/tbody/tr/td[contains(.,'"+RuleSetname+"')]//following-sibling::td/a[contains(.,'Delete')]"))).isPresent()){
			
		WebElementFacade deleteRuleSetName=find(By.xpath("//*[@id='terr_valueTable']/tbody/tr/td[contains(.,'"+RuleSetname+"')]//following-sibling::td/a[contains(.,'Delete')]"));
	
		deleteRuleSetName.click();
		System.out.println("Clicked on Delete link*************************");
		waitFor(5000).milliseconds();
		getDriver().switchTo().alert().accept();
		}
		}catch(Exception e){
			e.printStackTrace();
		}
}
	
	public void createNewRuleSetPage(){

		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), createNewRuleSetBtn);
		createNewRuleSetBtn.click();

	}
	
	public void enterRuleNamePage(String ruleName){

		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), enterRuleName);
		enterRuleName.sendKeys(ruleName);

	}
	
	public void ruleSetSelectCountry(String countryName){

		if(countryName.contains("United States & Canada")){
			if(!ruleSetSelectUS.isSelected()){
				ruleSetSelectUS.click();
			}
		}
		else
			ruleSetSelectOtherCountry.click();

	}
	
	public void selectCategoryVariablePage(String categoryName,String variableName,String variableDropDown,String variableValue){

			ruleSetSelectCategory.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), ruleSetSelectCategory);
		ruleSetSelectCategory.selectByVisibleText(categoryName);
		UIHelper.highlightElement(getDriver(), ruleSetVariableName);
		ruleSetVariableName.selectByVisibleText(variableName);
		UIHelper.highlightElement(getDriver(), ruleSetVariableDrpDwn);
		ruleSetVariableDrpDwn.selectByVisibleText(variableDropDown);
		UIHelper.highlightElement(getDriver(), ruleSetVariableValue);
		ruleSetVariableValue.sendKeys(variableValue);

	}
	public void submitRuleSetPage(){

			ruleSetSubmit.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), ruleSetSubmit);
		ruleSetSubmit.click();

	}
}
