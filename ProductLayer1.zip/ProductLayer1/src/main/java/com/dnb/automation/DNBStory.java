package com.dnb.automation;

import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.io.LoadFromClasspath;
import org.jbehave.core.model.ExamplesTableFactory;
import org.jbehave.core.parsers.RegexStoryParser;
import org.jbehave.core.parsers.StoryTransformer;
import org.jbehave.core.parsers.TransformingStoryParser;

import net.serenitybdd.jbehave.SerenityStory;


public class DNBStory extends SerenityStory {
	LoadFromClasspath classpathLoader=null;
	
	@Override
	public Configuration configuration() {
		//DNBLoadFromClasspath - the below code does variable substitution for a filename in the examples.
		/*The below story transformer removes "{" and "}" from the stories.  
		 * This will allow us to code variables with {} to make stories clearer to what
		 * is a variable, and what is not, while also not having to code the below
		 * replaceAll everywhere in the code. 
		 */
		StoryTransformer st=new StoryTransformer() {
			@Override
			public String transform(String storyAsText) {
				return storyAsText.replaceAll("\\{", "").replaceAll("\\}", "");
			}
			
		};
		
		ExamplesTableFactory examplesTableFactory = new ExamplesTableFactory(getLoadFromClasspath());
		return super.configuration().useStoryParser(new TransformingStoryParser(new RegexStoryParser(examplesTableFactory),st));
	}
	
	public LoadFromClasspath instantiateLoadFromClasspath() {
		return new DNBLoadFromClasspath();
	}
	
	public LoadFromClasspath getLoadFromClasspath() {
		if (classpathLoader==null) {
			classpathLoader=instantiateLoadFromClasspath();
		}
		return classpathLoader;
	}

}
