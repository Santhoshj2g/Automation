package com.dnb.automation.dbiaca.pages;

import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

/**********************************************************************************************
 * HomePage.java - This program contains steps for
 * 1. User launch the URL and application
 * 2. User enters  Login details (userid and password)
 *
 * @author   Sendhilkumar.R
***********************************************************************************************/

public class LoginPage extends PageObject
{
	@FindBy(xpath = "//*[@id='yes' and @name ='userId']")
	private WebElementFacade userId;

	@FindBy(xpath = "//*[@id='yes' and @name ='password']")
	private WebElementFacade passWord;

	@FindBy(xpath = "//*[@id='yes' and @name ='endorsement']")
	private WebElementFacade yourName;
	
	@FindBy(xpath = "//*[@type='submit']")
	private WebElementFacade continueBtn;
	
		
	//User checks the URL and application launching
	
		public void launchApplication(String appURL) {
			getDriver().manage().deleteAllCookies();
			getURLtoLaunch(appURL);

		}
			
		
		public void login(String username, String pwd,String yourname) throws Exception {
			enterLogin(username);
			enterpassword(pwd);
			enteryourname(yourname);
			loginButton();
		}
	

		public void getURLtoLaunch(String appURL) {
			getDriver().get(appURL);
			getDriver().manage().window().maximize();
			UIHelper.waitForPageToLoad(getDriver());
		}
		
			
		//User enters the Login details
		
		public void enterLogin(String username) throws Exception {
			try {
				UIHelper.highlightElement(getDriver(), userId);
				userId.type(username);
			} catch(AssertionError e)
			{
				e.printStackTrace();
			}
		}

		
		public void enterpassword(String pwd) throws Exception {
			try {
				UIHelper.highlightElement(getDriver(), passWord);
				passWord.type(pwd);
			} catch(AssertionError e)
			{
				e.printStackTrace();
			}
		}
		
		public void enteryourname(String yourname) throws Exception {
			try {
				UIHelper.highlightElement(getDriver(), yourName);
				yourName.type(yourname);
			} catch(AssertionError e)
			{
				e.printStackTrace();
			}
		}

		
		public void loginButton() throws Exception {
			try {
				if (continueBtn.isPresent()){
					UIHelper.highlightElement(getDriver(), continueBtn);
					continueBtn.click();
					UIHelper.waitForPageToLoad(getDriver());
					

				}
			} catch(AssertionError e)
			{
				e.printStackTrace();
			}
		}


	
}
