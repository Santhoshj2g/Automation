package com.dnb.automation.srm.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.DateUtil;
import com.dnb.automation.utils.FileUtil;
import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

/**********************************************************************************************
 * SRMAlertsPage.java - This program contains steps for 1. Alerts page navigation
 * 2. Alerts Page validations
 *
 * @author Duvvuru Naveen
 ***********************************************************************************************/
public class SRMAlertsPage extends PageObject {

    @FindBy(xpath = ".//*[@id='alertsMenu']/a")
    private WebElementFacade alertsMenuEle;

    @FindBy(xpath = ".//*[@id='wrapper']//*[@class='page-heading_alert']/h1")
    private WebElementFacade alertsTitleEle;
    
    @FindBy(xpath = ".//*[@id='NewFolder']")
    private WebElementFacade newFolderBtnEle;
    
    @FindBy(xpath = ".//*[@id='New_Folder_text']")
    private WebElementFacade txtFieldEleInPopupForNewFolder;
    
    @FindBy(xpath = ".//*[@id='newfolder_save']")
    private WebElementFacade saveBtnEleInPopupForNewFolder;
    
    @FindBy(xpath = ".//*[@class='folder_tree']//li/span/a[contains(.,'Inbox')]")
    private WebElementFacade inboxFolderEle;
    
    @FindBy(xpath = ".//*[@id='Alerttabs']/ul//a/span[contains(.,'Inbox')]")
    private WebElementFacade inboxTabEle;
    
    @FindBy(xpath = ".//*[@id='confMsg']/span")
    private WebElementFacade alertFolderConfirmMessageEle;
    
    public WebElementFacade getAlertFolderConfirmMessageEle() {
        return alertFolderConfirmMessageEle;
    }

    @FindBy(xpath = ".//*[@id='confCloseBtn']")
    private WebElementFacade confirmMessageCloseEle;
    
    public WebElementFacade getInboxTabEle() {
        return inboxTabEle;
    }

    @FindBy(xpath = ".//*[@class='folder_tree']//li/span/a")
    private List<WebElement> folderElementsInAlerts;
    
    @FindBy(xpath = ".//*[@id='wrapper']//*[@class='dashboard-container']/div[5]//input[contains(@value,'Confirm')]")
    private WebElementFacade confirmButtonEleForDeleteAlertFolder;
    
    @FindBy(xpath = ".//*[@class='supplierProfTabs']//*[@class='folder_tree']//li/span/a[contains(.,'Inbox')]")
    private WebElementFacade alertInboxFolderEle;
    
    @FindBy(xpath = ".//*[@id='Inbox']//*[@id='inbox_table']/tbody/tr[1]")
    private WebElementFacade firstRowAlertItemEle;
    
    public WebElementFacade getFirstRowAlertItemEle() {
        return firstRowAlertItemEle;
    }

    @FindBy(xpath = ".//*[@id='Inbox']//*[@id='inbox_table']/tbody/tr[1]/td[1]/input")
    private WebElementFacade firstAlertItemCheckboxEle;
    
    @FindBy(xpath = ".//*[@id='Inbox']//*[@id='inbox_table']/tbody/tr[1]/td[3]/h2/a")
    private WebElementFacade firstAlertItemLinkEle;
    
    @FindBy(xpath = ".//*[@id='Inbox']//*[@id='sort-list']/li[2]/span/span[2]")
    private WebElementFacade moveOptionEleForAlertItem;
    
    @FindBy(xpath = ".//*[@id='inboxPrint']")
    private WebElementFacade printBtnEleForAlretItem;
    
    @FindBy(xpath = ".//*[@id='inboxExport']")
    private WebElementFacade exportOptionEleForAlretItem;
    
    @FindBy(xpath = ".//*[@id='inboxExportCsv']")
    private WebElementFacade exportOptionCSVEleForAlretItem;
    
    @FindBy(xpath = ".//*[@id='inboxExportPdf']")
    private WebElementFacade exportOptionPDFEleForAlretItem;
    
    @FindBy(xpath = ".//*[@id='Inbox-Detailed-Alert-View']/div[2]/ul/li[1]/a")
    private WebElementFacade supplierEle;
    
    public WebElementFacade getSupplierEle() {
        return supplierEle;
    }

    @FindBy(xpath = ".//*[@id='profile']/span/a")
    private WebElementFacade profileTabEle;
    
    public WebElementFacade getProfileTabEle() {
        return profileTabEle;
    }
    
    @FindBy(xpath = ".//*[@id='alertProfile']/a")
    private WebElementFacade alertConfigSubTabEle;
    
    @FindBy(xpath = ".//*[@id='wrapper']//*[@class='container']//*[@class='dashboard-container']//*[contains(@class,'page-heading')]/h1")
    private WebElementFacade alertProfilePageTitleEle;
    
    @FindBy(xpath = ".//*[@id='wrapper']//*[@class='container']//*[@class='dashboard-container']//*[contains(@class,'alert_profile')]//*[@class='new_prof']//*[@class='new_prof_btn']")
    private WebElementFacade newProfileBtnEle;
    
    @FindBy(xpath = ".//*[@id='SupplierRate']//*[@class='prf_name_head']/input")
    private WebElementFacade profileNameFieldEle;
    
    public WebElementFacade getProfileNameFieldEle() {
        return profileNameFieldEle;
    }

    @FindBy(xpath = ".//*[@id='SupplierRate']//ul/li/span[contains(.,'Public')]")
    private WebElementFacade publicTypeEle;
    
    @FindBy(xpath = ".//*[@id='SupplierRate']//ul/li/span[contains(.,'Private')]")
    private WebElementFacade privateTypeEle;
    
    @FindBy(xpath = ".//*[@id='watchListFolder_alert-button']/span[2]")
    private WebElementFacade profileFolderDropdownListEle;
    
    @FindBy(xpath = ".//*[@id='selectSSI_0']")
    private WebElementFacade firstSSIDropdownEle;
    
    @FindBy(xpath = ".//*[@id='textSSI_0']")
    private WebElementFacade firstTextBoxFieldEleForSSI;
    
    @FindBy(xpath = ".//*[@id='SSI_rule']/li[2]/span/img")
    private WebElementFacade addNewConditionBtnEleForSSI;
    
    @FindBy(xpath = ".//*[@id='selectSSI_1']")
    private WebElementFacade secondSSIDropdownEle;
    
    @FindBy(xpath = ".//*[@id='selectSSI_2']")
    private WebElementFacade thirdSSIDropdownEle;
    
    @FindBy(xpath = ".//*[@id='selectSSI_3']")
    private WebElementFacade fourthSSIDropdownEle;
    
    @FindBy(xpath = ".//*[@id='textSSI_1']")
    private WebElementFacade secondTextBoxFieldEleForSSI;
    
    @FindBy(xpath = ".//*[@id='textSSI_2']")
    private WebElementFacade thirdTextBoxFieldEleForSSI;
    
    @FindBy(xpath = ".//*[@id='textSSI_3']")
    private WebElementFacade fourthTextBoxFieldEleForSSI;
    
    @FindBy(xpath = ".//*[@id='selectSER_0']")
    private WebElementFacade firstSERDropdownEle;
    
    @FindBy(xpath = ".//*[@id='textSER_0']")
    private WebElementFacade firstTextBoxFieldEleForSER;
    
    @FindBy(xpath = ".//*[@id='SER_rule']/li[2]/span/img")
    private WebElementFacade addNewConditionBtnEleForSER;
    
    @FindBy(xpath = ".//*[@id='selectSER_1']")
    private WebElementFacade secondSERDropdownEle;
    
    @FindBy(xpath = ".//*[@id='selectSER_2']")
    private WebElementFacade thirdSERDropdownEle;
    
    @FindBy(xpath = ".//*[@id='selectSER_3']")
    private WebElementFacade fourthSERDropdownEle;
    
    @FindBy(xpath = ".//*[@id='textSER_1']")
    private WebElementFacade secondTextBoxFieldEleForSER;
    
    @FindBy(xpath = ".//*[@id='textSER_2']")
    private WebElementFacade thirdTextBoxFieldEleForSER;
    
    @FindBy(xpath = ".//*[@id='textSER_3']")
    private WebElementFacade fourthTextBoxFieldEleForSER;
    
    @FindBy(xpath = ".//*[@id='selectPYD_0']")
    private WebElementFacade firstPaydexDropdownEle;
    
    @FindBy(xpath = ".//*[@id='textPYD_0']")
    private WebElementFacade firstTextBoxFieldEleForPaydex;
    
    @FindBy(xpath = ".//*[@id='PYD_rule']/li[2]/span/img")
    private WebElementFacade addNewConditionBtnEleForPaydex;
    
    @FindBy(xpath = ".//*[@id='selectPYD_1']")
    private WebElementFacade secondPaydexDropdownEle;
    
    @FindBy(xpath = ".//*[@id='selectPYD_2']")
    private WebElementFacade thirdPaydexDropdownEle;
    
    @FindBy(xpath = ".//*[@id='selectPYD_3']")
    private WebElementFacade fourthPaydexDropdownEle;
    
    @FindBy(xpath = ".//*[@id='textPYD_1']")
    private WebElementFacade secondTextBoxFieldEleForPaydex;
    
    @FindBy(xpath = ".//*[@id='textPYD_2']")
    private WebElementFacade thirdTextBoxFieldEleForPaydex;
    
    @FindBy(xpath = ".//*[@id='textPYD_3']")
    private WebElementFacade fourthTextBoxFieldEleForPaydex;
    
    @FindBy(xpath = ".//*[@id='selectORP_0']")
    private WebElementFacade firstSRDropdownEle;
    
    @FindBy(xpath = ".//*[@id='rateit-range-2']")
    private WebElementFacade disabledRatingStarEleForSR;
    
    @FindBy(xpath = ".//*[@id='ORP_rule']/li[2]/span/img")
    private WebElementFacade addNewConditionBtnEleForSR;
    
    @FindBy(xpath = ".//*[@id='selectORP_1']")
    private WebElementFacade secondSRDropdownEle;
    
    @FindBy(xpath = ".//*[@id='selectORP_2']")
    private WebElementFacade thirdSRDropdownEle;
    
    @FindBy(xpath = ".//*[@id='selectORP_3']")
    private WebElementFacade fourthSRDropdownEle;
    
    @FindBy(xpath = ".//*[@id='rateit-range-2']/div[2]")
    private WebElementFacade enabledRatingStarEleForSR;
    
    @FindBy(xpath = ".//*[@id='selectFSSP_0']")
    private WebElementFacade firstFSDropdownEle;
    
    @FindBy(xpath = ".//*[@id='textFSSP_0']")
    private WebElementFacade firstTextBoxFieldEleForFS;
    
    @FindBy(xpath = ".//*[@id='FSSP_rule']/li[2]/span/img")
    private WebElementFacade addNewConditionBtnEleForFS;
    
    @FindBy(xpath = ".//*[@id='selectFSSP_1']")
    private WebElementFacade secondFSDropdownEle;
    
    @FindBy(xpath = ".//*[@id='selectFSSP_2']")
    private WebElementFacade thirdFSDropdownEle;
    
    @FindBy(xpath = ".//*[@id='selectFSSP_3']")
    private WebElementFacade fourthFSDropdownEle;
    
    @FindBy(xpath = ".//*[@id='textFSSP_1']")
    private WebElementFacade secondTextBoxFieldEleForFS;
    
    @FindBy(xpath = ".//*[@id='textFSSP_2']")
    private WebElementFacade thirdTextBoxFieldEleForFS;
    
    @FindBy(xpath = ".//*[@id='textFSSP_3']")
    private WebElementFacade fourthTextBoxFieldEleForFS;
    
    @FindBy(xpath = ".//*[@id='SupplierRate']//*[@class='edit_save_btn']/input[contains(@value,'Save')]")
    private WebElementFacade saveProfileBtnEle;
    
    @FindBy(xpath = ".//*[@id='alertPflDetails']//*[@class='AP_details sel_alert_prof']//*[@class='prof_name1']/span[1]")
    private WebElementFacade createdProfileResultEle;
    
    @FindBy(xpath = ".//*[@id='SupplierRate']//*[@class='edit_del_img']/img[2]")
    private WebElementFacade deleteProfileBtnEle;
    
    @FindBy(xpath = ".//*[@id='wrapper']//*[@class='dashboard-container']//span/input[contains(@value,'Delete')]")
    private WebElementFacade deleteBtnInConfirmPromptEle;
    
    @FindBy(xpath = ".//*[@id='15']")
    private WebElementFacade pageNationEle;
    
    @FindBy(xpath = ".//*[@id='alertPflDetails']//*[contains(@class,'AP_details')]//*[contains(@class,'prof_name1')]/span[1]")
    private List<WebElement> alertProfileElementsList;
    
    @FindBy(xpath = ".//*[@id='alertPflDetails']/div[1][contains(@class,'AP_details')]/*[contains(@class,'prof_name1')]/span[1]")
    private WebElementFacade firstAlertProfileEle;
    
    private String tempCreatedAlertProfXpath = ".//*[@id='alertPflDetails']//*[contains(@class,'AP_details')]//*[contains(@class,'prof_name1')]//span[contains(.,'SERENITY')]";
    private String tempAlertFolderNameXpath = ".//*[@class='supplierProfTabs']//*[@class='folder_tree']//li/span/a[contains(.,'SERENITY')]";
    private String ajaxImgLoadingXpathInInboxSection = ".//*[@id='Inbox']//*[@class='inboxLoading']/img";
    //private String ajaxImgLoadingXpathInPrintWindow = ".//*[@id='wrapper']/*[@class='container']/*[@class='printLoading']/img";
    private String ajaxImgLoadingXpathInNewProfilePg = ".//*[@id='SupplierRate']//*[@class='newAlertsPflLoading']/img";
    private String alertProfileCreatedConfirmMsgXpath = ".//*[@id='confMsg']/span";
    private String tempEventIndicatorXpath = ".//*[@class='evt_indicator_content']/div/span[contains(.,'SERENITY')]";
    private String tempFolderValueXpath = ".//*[@id='watchListFolder_alert-menu']/li/a[contains(.,'SERENITY')]";
    private String tempMoveFolderXpath = ".//*[@id='Inbox']//*[@id='sort-list']/li[2]/span/span[2]/ul/li/span[contains(.,'SERENITY')]";
    private String inboxXpath=".//*[@class='folder_tree']//li/span/a[contains(.,'Inbox')]";
    private ArrayList<String> alertFoldersList = new ArrayList<String>();
    private String currentDateAndTimeDetailsStoreLocation = "src/test/resources/AppTestData/SRM/StoreDateDetailsForAlertFolder.txt";
    private String tempAlertFolderXpath = ".//*[@class='folder_tree']/li/span/a[contains(.,'SERENITY')]";
    private String tempDeleteAlertFolderXpath = ".//*[@class='folder_tree']/li/span/a[contains(.,'SERENITY')]//ancestor::span//following-sibling::img[2]";
    private ArrayList<String> alertProfileNamesList = new ArrayList<String>();
    
    //Navigate to Alerts page
    public void navigatToAlertsPage()
    {
        try{
            
            if(alertsMenuEle.isPresent())
            {
                alertsMenuEle.click();
                UIHelper.waitForPageToLoad(getDriver());
                alertsTitleEle.waitUntilPresent();
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    //Click on Inbox link in Alerts Page
    public void clickOnInbox()
    {
        try{
            
            if(inboxFolderEle.isPresent())
            {
                inboxFolderEle.click();
                UIHelper.waitForPageToLoad(getDriver());
                inboxTabEle.waitUntilPresent();
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    //Click on New Folder
    public void clickOnNewFolder()
    {
        try{
            if(newFolderBtnEle.isPresent())
            {
                newFolderBtnEle.click();
                txtFieldEleInPopupForNewFolder.waitUntilPresent();
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    //Enter Folder Name and save
    public void enterFolderNameAndSave(String folderName)
    {
        try{
            String dateVal = new DateUtil().getCurrentDateAndTime();
            String finalDateVal = dateVal.replace(" ", "").replace("/", "").replace(":", "").trim();
            new FileUtil().writeTextToFile(finalDateVal, currentDateAndTimeDetailsStoreLocation);
            String finalFolderName = folderName + finalDateVal;
            String upToNineCharacters = finalFolderName.substring(0, Math.min(finalFolderName.length(), 9));
            if(txtFieldEleInPopupForNewFolder.isPresent())
            {
                txtFieldEleInPopupForNewFolder.type(finalFolderName);
                saveBtnEleInPopupForNewFolder.waitUntilPresent();
                saveBtnEleInPopupForNewFolder.waitUntilVisible();
                saveBtnEleInPopupForNewFolder.click();
                inboxFolderEle.waitUntilPresent();
                String alertFolderXpath = tempAlertFolderXpath.replace("SERENITY", upToNineCharacters);
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), alertFolderXpath);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    //Check Created Folder
    public ArrayList<String> getAlertsFolderDetails()
    {
        try{
            alertFolderConfirmMessageEle.waitUntilPresent();
            for(WebElement ele:folderElementsInAlerts)
            {
                alertFoldersList.add(ele.getText().trim());
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return alertFoldersList;
    }
    
    public void deleteAlertFolder(String folderName) throws Exception
    {
        String finalFolderName = folderName + new FileUtil().readDataFromFile(currentDateAndTimeDetailsStoreLocation);
        String upToNineCharacters = finalFolderName.substring(0, Math.min(finalFolderName.length(), 9));
        String alertFolderXpathForDelete = tempDeleteAlertFolderXpath.replace("SERENITY", upToNineCharacters);
        WebElementFacade alertFolderEle = find(By.xpath(alertFolderXpathForDelete));
        if(alertFolderEle.isPresent())
        {
            alertFolderEle.click();
            confirmButtonEleForDeleteAlertFolder.waitUntilPresent();
            confirmButtonEleForDeleteAlertFolder.click();
            alertFolderConfirmMessageEle.waitUntilPresent();
            confirmMessageCloseEle.waitUntilPresent();
            confirmMessageCloseEle.click();
            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), inboxXpath);
            inboxFolderEle.waitUntilPresent();
        }
    }
    
    //Click On Alert Inbox folder
    public void clickOnAlertFolder(String alertFolderName)
    {
        try
        {
            String upToNineCharacters;
            if(alertFolderName.length()>8)
            {
                upToNineCharacters = alertFolderName.substring(0, Math.min(alertFolderName.length(), 9));
            }
            else
            {
                upToNineCharacters = alertFolderName;
            }
            String alertFolderNameXpath = tempAlertFolderNameXpath.replace("SERENITY", upToNineCharacters);
            WebElementFacade alertFolderNameEle = find(By.xpath(alertFolderNameXpath));
            if(alertFolderNameEle.isPresent())
            {
                alertFolderNameEle.click();
                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxImgLoadingXpathInInboxSection);
                firstRowAlertItemEle.waitUntilPresent();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Select Alert Item From Inbox items
    public void selectAlertItem()
    {
        try
        {
            if(firstAlertItemCheckboxEle.isPresent())
            {
                firstAlertItemCheckboxEle.click();
                waitFor(2000).milliseconds();
            }
        }
        catch(Exception e)
        {
        }
    }
    
    //Choose Alert folder for move alert items
    public void chooseAlertFolder(String alertFolderName)
    {
        try
        {
            UIHelper.waitForPageToLoad(getDriver());
            moveOptionEleForAlertItem.waitUntilPresent();
            if(moveOptionEleForAlertItem.isPresent())
            {
                String moveToTargetFolderXpath = tempMoveFolderXpath.replace("SERENITY", alertFolderName);
                WebElementFacade moveToTargetFolderEle = find(By.xpath(moveToTargetFolderXpath));
                UIHelper.mouseOverandElementdoubleClick(getDriver(), moveOptionEleForAlertItem);
                if(moveToTargetFolderEle.isPresent())
                {
                    JavascriptExecutor js = (JavascriptExecutor)getDriver();
                    js.executeScript("arguments[0].click();", moveToTargetFolderEle);
                    UIHelper.waitForPageToLoad(getDriver());
                }
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Get Alert Move Confirmation Message
    public String getAlertMoveConfirmMsg()
    {
        UIHelper.waitForVisibilityOfEleByXpath(getDriver(), alertProfileCreatedConfirmMsgXpath);
        alertFolderConfirmMessageEle.waitUntilPresent();
        return alertFolderConfirmMessageEle.getText();
    }
    
    //Click On Alert Item Hper link
    public void clickOnAlertItem()
    {
        try
        {
            firstAlertItemLinkEle.waitUntilPresent();
            if(firstAlertItemLinkEle.isPresent())
            {
                firstAlertItemLinkEle.click();
                supplierEle.waitUntilPresent();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Click on Supplier
    public void clickOnSupplier()
    {
        try
        {
            if(supplierEle.isPresent())
            {
                supplierEle.click();
                UIHelper.waitForPageToLoad(getDriver());
                profileTabEle.waitUntilPresent();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Click on Alert Print button
    public void clickOnAlertPrint()
    {
        try
        {
            printBtnEleForAlretItem.waitUntilPresent();
            if(printBtnEleForAlretItem.isPresent())
            {
                String parentWindow = getDriver().getWindowHandle();
                printBtnEleForAlretItem.click();
                waitFor(3000).milliseconds();
                for(String childWindow:getDriver().getWindowHandles())
                {
                    if(!childWindow.equals(parentWindow)) 
                    {
                        getDriver().switchTo().window(childWindow);
                        getDriver().close(); 
                    } 
                }
                getDriver().switchTo().window(parentWindow);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Click on Export button and choose export option as CSV/PDF
    public void clickOnExportAndChooseExportOption(String exportOption)
    {
        try
        {
            exportOptionEleForAlretItem.waitUntilPresent();
            if(exportOptionEleForAlretItem.isPresent())
            {
                exportOptionEleForAlretItem.click();
                waitFor(3000).milliseconds();
                if(exportOption.equalsIgnoreCase("CSV"))
                {
                    UIHelper.mouseOverandclickanElement(getDriver(), exportOptionCSVEleForAlretItem);
                }
                else if(exportOption.equalsIgnoreCase("PDF"))
                {
                    UIHelper.mouseOverandclickanElement(getDriver(), exportOptionPDFEleForAlretItem);
                }
                UIHelper.waitForPageToLoad(getDriver());
                waitFor(5000).milliseconds();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Click on Alert Configuration sub tab
    public void clickOnAlertConfigSubTab()
    {
        try
        {
            if(alertConfigSubTabEle.isPresent())
            {
                alertConfigSubTabEle.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Get Alert Profile Page Title
    public String getAlertProfilePageTitle()
    {
        alertProfilePageTitleEle.waitUntilPresent();
        return alertProfilePageTitleEle.getText().trim();
    }
    
    //Click on 'New Profile' button
    public void clickOnNewProfile()
    {
        try
        {
            if(newProfileBtnEle.isPresent())
            {
                newProfileBtnEle.click();
                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxImgLoadingXpathInNewProfilePg);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Enter Profile fields with data
    public void enterProfileFieldsWithData(String profileName, String type, String profileFolder)
    {
        try
        {
            String dateVal = new DateUtil().getCurrentDateAndTime();
            String finalDateVal = dateVal.replace(" ", "").replace("/", "").replace(":", "").trim();
            profileNameFieldEle.waitUntilPresent();
            if(profileNameFieldEle.isPresent())
            {
                profileNameFieldEle.type(profileName+finalDateVal);
            }
            
            if(type.equalsIgnoreCase("Public"))
            {
                publicTypeEle.click();
            }
            else
            {
                privateTypeEle.click();
            }
            
            if(profileFolderDropdownListEle.isPresent())
            {
                profileFolderDropdownListEle.click();
                
                String profileFolderValueXpath = tempFolderValueXpath.replace("SERENITY", profileFolder);
                WebElementFacade profileFolderValueEle = find(By.xpath(profileFolderValueXpath));
                if(profileFolderValueEle.isPresent())
                {
                    profileFolderValueEle.click();
                }
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Select SSI Dropdown value
    public void selectSSIDropdownVal(String dropdownNum, String ssiDropdownVal)
    {
        try
        {
            switch(dropdownNum)
            {
                case "first":
                    firstSSIDropdownEle.waitUntilPresent();
                    firstSSIDropdownEle.selectByVisibleText(ssiDropdownVal);
                    break;
                case "second":   
                    secondSSIDropdownEle.waitUntilPresent();
                    secondSSIDropdownEle.selectByVisibleText(ssiDropdownVal);
                    break;
                case "third":
                    thirdSSIDropdownEle.waitUntilPresent();
                    thirdSSIDropdownEle.selectByVisibleText(ssiDropdownVal);
                    break;
                case "fourth":
                    fourthSSIDropdownEle.waitUntilPresent();
                    fourthSSIDropdownEle.selectByVisibleText(ssiDropdownVal);
                    break;   
                default:
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Click on 'Add New Conditions' button in SSI Section
    public void clickOnAddNewConditionInSSI()
    {
        try
        {
            if(addNewConditionBtnEleForSSI.isPresent())
            {
                addNewConditionBtnEleForSSI.click();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Select SSI Dropdown value with score
    public void selectSSIDropdownValAndEnterScore(String dropdownNum, String ssiDropdownVal, String scoreVal)
    {
        try
        {
            switch(dropdownNum)
            {
                case "first":
                    firstSSIDropdownEle.waitUntilPresent();
                    firstSSIDropdownEle.selectByVisibleText(ssiDropdownVal);
                    firstTextBoxFieldEleForSSI.waitUntilPresent();
                    firstTextBoxFieldEleForSSI.type(scoreVal);
                    break;
                case "second":   
                    secondSSIDropdownEle.waitUntilPresent();
                    secondSSIDropdownEle.selectByVisibleText(ssiDropdownVal);
                    secondTextBoxFieldEleForSSI.waitUntilPresent();
                    secondTextBoxFieldEleForSSI.type(scoreVal);
                    break;
                case "third":
                    thirdSSIDropdownEle.waitUntilPresent();
                    thirdSSIDropdownEle.selectByVisibleText(ssiDropdownVal);
                    thirdTextBoxFieldEleForSSI.waitUntilPresent();
                    thirdTextBoxFieldEleForSSI.type(scoreVal);
                    break;
                case "fourth":
                    fourthSSIDropdownEle.waitUntilPresent();
                    fourthSSIDropdownEle.selectByVisibleText(ssiDropdownVal);
                    fourthTextBoxFieldEleForSSI.waitUntilPresent();
                    fourthTextBoxFieldEleForSSI.type(scoreVal);
                    break;   
                default:
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Select SER Dropdown value
    public void selectSERDropdownVal(String dropdownNum, String serDropdownVal)
    {
        try
        {
            switch(dropdownNum)
            {
                case "first":
                    firstSERDropdownEle.waitUntilPresent();
                    firstSERDropdownEle.selectByVisibleText(serDropdownVal);
                    break;
                case "second":   
                    secondSERDropdownEle.waitUntilPresent();
                    secondSERDropdownEle.selectByVisibleText(serDropdownVal);
                    break;
                case "third":
                    thirdSERDropdownEle.waitUntilPresent();
                    thirdSERDropdownEle.selectByVisibleText(serDropdownVal);
                    break;
                case "fourth":
                    fourthSERDropdownEle.waitUntilPresent();
                    fourthSERDropdownEle.selectByVisibleText(serDropdownVal);
                    break;   
                default:
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Click on 'Add New Conditions' button in SER Section
    public void clickOnAddNewConditionInSER()
    {
        try
        {
            if(addNewConditionBtnEleForSER.isPresent())
            {
                addNewConditionBtnEleForSER.click();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Select SER Dropdown value with score
    public void selectSERDropdownValAndEnterScore(String dropdownNum, String serDropdownVal, String scoreVal)
    {
        try
        {
            switch(dropdownNum)
            {
                case "first":
                    firstSERDropdownEle.waitUntilPresent();
                    firstSERDropdownEle.selectByVisibleText(serDropdownVal);
                    firstTextBoxFieldEleForSER.waitUntilPresent();
                    firstTextBoxFieldEleForSER.type(scoreVal);
                    break;
                case "second":   
                    secondSERDropdownEle.waitUntilPresent();
                    secondSERDropdownEle.selectByVisibleText(serDropdownVal);
                    secondTextBoxFieldEleForSER.waitUntilPresent();
                    secondTextBoxFieldEleForSER.type(scoreVal);
                    break;
                case "third":
                    thirdSERDropdownEle.waitUntilPresent();
                    thirdSERDropdownEle.selectByVisibleText(serDropdownVal);
                    thirdTextBoxFieldEleForSER.waitUntilPresent();
                    thirdTextBoxFieldEleForSER.type(scoreVal);
                    break;
                case "fourth":
                    fourthSERDropdownEle.waitUntilPresent();
                    fourthSERDropdownEle.selectByVisibleText(serDropdownVal);
                    fourthTextBoxFieldEleForSER.waitUntilPresent();
                    fourthTextBoxFieldEleForSER.type(scoreVal);
                    break;   
                default:
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Select Paydex Dropdown value with score
    public void selectPaydexDropdownVal(String dropdownNum, String paydexDropdownVal, String scoreVal)
    {
        try
        {
            switch(dropdownNum)
            {
                case "first":
                    firstPaydexDropdownEle.waitUntilPresent();
                    firstPaydexDropdownEle.selectByVisibleText(paydexDropdownVal);
                    firstTextBoxFieldEleForPaydex.waitUntilPresent();
                    firstTextBoxFieldEleForPaydex.type(scoreVal);
                    break;
                case "second":   
                    secondPaydexDropdownEle.waitUntilPresent();
                    secondPaydexDropdownEle.selectByVisibleText(paydexDropdownVal);
                    secondTextBoxFieldEleForPaydex.waitUntilPresent();
                    secondTextBoxFieldEleForPaydex.type(scoreVal);
                    break;
                case "third":
                    thirdPaydexDropdownEle.waitUntilPresent();
                    thirdPaydexDropdownEle.selectByVisibleText(paydexDropdownVal);
                    thirdTextBoxFieldEleForPaydex.waitUntilPresent();
                    thirdTextBoxFieldEleForPaydex.type(scoreVal);
                    break;
                case "fourth":
                    fourthPaydexDropdownEle.waitUntilPresent();
                    fourthPaydexDropdownEle.selectByVisibleText(paydexDropdownVal);
                    fourthTextBoxFieldEleForPaydex.waitUntilPresent();
                    fourthTextBoxFieldEleForPaydex.type(scoreVal);
                    break;   
                default:
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Click on 'Add New Conditions' button in Paydex Section
    public void clickOnAddNewConditionInPaydex()
    {
        try
        {
            if(addNewConditionBtnEleForPaydex.isPresent())
            {
                addNewConditionBtnEleForPaydex.click();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
        
    //Select Supplier Rating Dropdown value for enable Rating stars
    public void selectSRDropdownVal(String dropdownNum, String supRatingDropdownVal)
    {
        try
        {
            switch(dropdownNum)
            {
                case "first":
                    firstSRDropdownEle.waitUntilPresent();
                    firstSRDropdownEle.selectByVisibleText(supRatingDropdownVal);
                    break;
                case "second":   
                    secondSRDropdownEle.waitUntilPresent();
                    secondSRDropdownEle.selectByVisibleText(supRatingDropdownVal);
                    break;
                case "third":
                    thirdSRDropdownEle.waitUntilPresent();
                    thirdSRDropdownEle.selectByVisibleText(supRatingDropdownVal);
                    break;
                case "fourth":
                    fourthSRDropdownEle.waitUntilPresent();
                    fourthSRDropdownEle.selectByVisibleText(supRatingDropdownVal);
                    break;   
                default:
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Click on 'Add New Conditions' button in Supplier Rating Section
    public void clickOnAddNewConditionInSupplierRating()
    {
        try
        {
            if(addNewConditionBtnEleForSR.isPresent())
            {
                addNewConditionBtnEleForSR.click();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Select Failure Score Dropdown value with score
    public void selectFSDropdownVal(String dropdownNum, String failureScoreDropdownVal, String scoreVal)
    {
        try{
            switch(dropdownNum)
            {
                case "first":
                    firstFSDropdownEle.waitUntilPresent();
                    firstFSDropdownEle.selectByVisibleText(failureScoreDropdownVal);
                    firstTextBoxFieldEleForFS.waitUntilPresent();
                    firstTextBoxFieldEleForFS.type(scoreVal);
                    break;
                case "second":   
                    secondFSDropdownEle.waitUntilPresent();
                    secondFSDropdownEle.selectByVisibleText(failureScoreDropdownVal);
                    secondTextBoxFieldEleForFS.waitUntilPresent();
                    secondTextBoxFieldEleForFS.type(scoreVal);
                    break;
                case "third":
                    thirdFSDropdownEle.waitUntilPresent();
                    thirdFSDropdownEle.selectByVisibleText(failureScoreDropdownVal);
                    thirdTextBoxFieldEleForFS.waitUntilPresent();
                    thirdTextBoxFieldEleForFS.type(scoreVal);
                    break;
                case "fourth":
                    fourthFSDropdownEle.waitUntilPresent();
                    fourthFSDropdownEle.selectByVisibleText(failureScoreDropdownVal);
                    fourthTextBoxFieldEleForFS.waitUntilPresent();
                    fourthTextBoxFieldEleForFS.type(scoreVal);
                    break;   
                default:
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Click on 'Add New Conditions' button in Failure Score Section
    public void clickOnAddNewConditionInFailureScore()
    {
        try{
            if(addNewConditionBtnEleForFS.isPresent())
            {
                addNewConditionBtnEleForFS.click();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Select Event Indicator
    public void selectEventIndicator(String eventIndicator)
    {
        try{
            String eventIndicatorXpath = tempEventIndicatorXpath.replace("SERENITY", eventIndicator);
            WebElementFacade eventIndicatorEle = find(By.xpath(eventIndicatorXpath));
            if(eventIndicatorEle.isPresent())
            {
                eventIndicatorEle.click();
            }
            
            if(saveProfileBtnEle.isPresent())
            {
                saveProfileBtnEle.click();
                UIHelper.waitForPageToLoad(getDriver());
                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxImgLoadingXpathInNewProfilePg);
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), alertProfileCreatedConfirmMsgXpath);
                createdProfileResultEle.waitUntilPresent();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    //Get Created Profile Name
    public String getCreatedProfileName()
    {
        return createdProfileResultEle.getText();
    }
    
    //Delete Created Alert Profile
    public void deleteAlertProfile(String profileName)
    {
        try{
            String createdAlertProfXpath = tempCreatedAlertProfXpath.replace("SERENITY", profileName);
            WebElementFacade createdAlertProfEle = find(By.xpath(createdAlertProfXpath));
            if(createdAlertProfEle.isPresent());
            {
                createdAlertProfEle.click();
                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxImgLoadingXpathInNewProfilePg);
                deleteProfileBtnEle.waitUntilPresent();
                deleteProfileBtnEle.click();
                deleteBtnInConfirmPromptEle.waitUntilPresent();
                deleteBtnInConfirmPromptEle.click();
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(), alertProfileCreatedConfirmMsgXpath);
                createdProfileResultEle.waitUntilPresent();
                firstAlertProfileEle.waitUntilPresent();
            }
        }
        catch(Exception e)
        {
        }
    }
    
    //Get the Alert Profile Names
    public ArrayList<String> getTheAlertProfileNames()
    {
        try{
            pageNationEle.waitUntilPresent();
            if(pageNationEle.isPresent())
            {
                pageNationEle.click();
                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxImgLoadingXpathInNewProfilePg);
                createdProfileResultEle.waitUntilPresent();
                pageNationEle.waitUntilPresent();
                firstAlertProfileEle.waitUntilPresent();
                waitFor(2000).milliseconds();
            }
            for(WebElement ele:alertProfileElementsList)
            {
                alertProfileNamesList.add(ele.getText().trim());
            }
        }
        catch(Exception e)
        {
        }
        return alertProfileNamesList;
    }
}
