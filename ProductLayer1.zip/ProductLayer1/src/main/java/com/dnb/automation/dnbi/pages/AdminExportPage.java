package com.dnb.automation.dnbi.pages;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import jxl.Workbook;
import jxl.read.biff.BiffException;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.jbehave.core.annotations.Named;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;



/**********************************************************************************************
 * HomePage.java - This class contains login functionality
 * 
 * @author Duvvuru Naveen
 * @version 1.0
 ***********************************************************************************************/
public class AdminExportPage extends PageObject
{
	@FindBy(xpath = "//*[@id='header_toolbar']/li[2]/a")
	private WebElementFacade homeprofile;
	@FindBy(xpath = "//*[@id='primaryNav']/li[7]/a")
	private WebElementFacade navigatetoadminpageobj;
	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@id='pageHead']")
	private WebElementFacade checkadmintextpageobj;
	@FindBy(xpath = "//*[@id='main']//*[@class='ecf_toc']//*[@class='last']//*[@class='subNav']")
	private WebElementFacade admdatamngmnttab;
	@FindBy(xpath = "//*[@id='main']//*[@class='ecf_page ad_wid750']//*[@class='widget adminbasic']//*[@class='basicMenu']//*[@href='/dnbi/dataAdmin/showExportConsoleAction']//strong")
	private WebElementFacade expdataobj;
	@FindBy(xpath = "//*[@id='page_title']/h2")
	private WebElementFacade checkexportdatapgtitle;
	@FindBy(xpath = "//*[@id='main']//input[contains(@value,'Export Data')]")
	private WebElementFacade expdatabtn;
	@FindBy(xpath = "//*[@id='page_title_links']/h2")
	private WebElementFacade checksetexportpagetitle;
	@FindBy(xpath = "//*[@id='entity_group_select']")
	private WebElementFacade selecttypetestpageobj;
	@FindBy(xpath = "//*[@id='entity_category_select']")
	private WebElementFacade selctcategorytestpageobj;
	@FindBy(xpath = "//*[@id='selectedFields']//option")
	private List<WebElementFacade> clearavailable;
	@FindBy(xpath = "//*[@id='remove']/img")
	private WebElementFacade leftarrow;
	@FindBy(xpath = "//*[@id='export_available']")
	private WebElementFacade selavailablevariablespageobj;
	@FindBy(xpath = "//*[@id='add']/img")
	private WebElementFacade clickonrightarrowpageobj;
	@FindBy(xpath = "//*[@id='filterContainer']//*[@class='floatLeft']//*[@id='filterName']")
	private WebElementFacade exportFilter;
	@FindBy(xpath = "//*[@id='filterContainer']//*[@id='preCountHomeBtn']")
	private WebElementFacade preCountHomeBtn;
	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
    private WebElementFacade iFrameEle;
	@FindBy(xpath = "//*[@class='iframe_modal']//*[@class='modal_inner_content']//*[@id='widget_container1']/Strong")
	private WebElementFacade getPreCount;
	@FindBy(xpath = "//*[@class='iframe_modal']//*[@class='modal_inner_content']//*[@id='widget_container1']")
	private WebElementFacade getPreCount1;
	@FindBy(xpath = "//*[@class='iframe_modal']//*[@class='modal_buttons clear']//*[@id='preCountResultBtn']")
	private WebElementFacade preCountResultBtn;
	@FindBy(xpath = "//*[@class='floatLeft']//*[@id='export_file_type_outer']")
	private WebElementFacade expExt;
	@FindBy(xpath = "//*[@id='advanced_search_submit_button']")
	private WebElementFacade clickonexportbuttonpageobj;
	@FindBy(xpath = "//*[@id='page_title']/h2")
	private WebElementFacade checkredirecttestpageobj;
	@FindBy(xpath = "//*[@id='main']//*[@class='ad_borE8']//*[@class='results full']/tbody/tr[1]/td[1]/a")
	private WebElementFacade checkstatuschangetestpageobj;
	@FindBy(xpath = "//*[@id='main']//*[@class='ad_borE8']//*[@class='results full']/tbody//*[@class='tablelight']/td[5]/a")
	private WebElementFacade clickondownloadtestpageobj;
	
    

String framexpath="//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']";

private String prcount= "//*[@class='iframe_modal']//*[@class='modal_inner_content']";
String datamtab="//*[@id='main']//*[@class='ecf_toc']//*[@class='last']//*[@class='subNav']";
String expPageTitle = "//*[@id='page_title_links']/h2";
String selT = "//*[@id='entity_group_select']";
String selC = "//*[@id='entity_category_select']";
String Ext;
public String getExt()
{
	return Ext;
}
int pCount;
public int getpCount() {
	return pCount;
}

	@FindBy(linkText = "Admin")
    private WebElementFacade tabAdmin;

    public WebElementFacade getTabAdmin() {
        return tabAdmin;
    }
		


	
	public void navExportDataPage()
	{
		UIHelper.highlightElement(getDriver(), homeprofile);
		homeprofile.click();
		UIHelper.highlightElement(getDriver(), tabAdmin);
		
		tabAdmin.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), datamtab);
		UIHelper.highlightElement(getDriver(), admdatamngmnttab);
		
		admdatamngmnttab.click();
		UIHelper.highlightElement(getDriver(), expdataobj);
		expdataobj.waitUntilPresent();
		expdataobj.click();
		
	}
	
	public void checkexportdatahomepage(String exportHome)
	{
		String exportTitle = checkexportdatapgtitle.getText();
				
		exportHome.equals(exportTitle);
		
	}
	public void navigatetoexportdatasetpage()
	{
		UIHelper.highlightElement(getDriver(),expdatabtn);
		expdatabtn.click();
		
	}
	public void checksetexportpage(String setExportOptions)
	{
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), expPageTitle);
				String setExptitle1 = checksetexportpagetitle.getText();
		
				setExportOptions.equals(setExptitle1);
				
	}
	public void selecttypetestpage(String expType, String expCategory, String variableNames, String selectFilter)
	{
		
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), selT);
		UIHelper.highlightElement(getDriver(),selecttypetestpageobj);
		 selecttypetestpageobj.selectByVisibleText(expType);
		 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), selC);
		 UIHelper.highlightElement(getDriver(),selctcategorytestpageobj);
		 selctcategorytestpageobj.selectByVisibleText(expCategory);
		
		int optionCount=clearavailable.size();
		if(optionCount!= 0){
		int s=1;
		for(WebElementFacade options : clearavailable){
			
		if(s!=optionCount){
		
			options.click();
			
			leftarrow.click();
			}
			s++;
		}
		String[] variables = variableNames.split(":");
		 for(int j=0; j<variables.length;j++){
			 
			 selavailablevariablespageobj.selectByVisibleText(variables[j]);
			 clickonrightarrowpageobj.click();
		
		}
		}
		else{
			
		
			String[] variables = variableNames.split(":");
			 for(int j=0; j<variables.length;j++){
				 
				 selavailablevariablespageobj.selectByVisibleText(variables[j]);
				 clickonrightarrowpageobj.click();
				 
		}
		}
		
		
			 waitFor(2000).milliseconds();
			 if(exportFilter.isEnabled())
			 {
			 if (selectFilter!="")
			 {
			 exportFilter.selectByVisibleText(selectFilter);
			 waitFor(3000).milliseconds();
			 
			preCountHomeBtn.click();
			waitFor(2000).milliseconds();
			getDriver().switchTo().frame(iFrameEle);
			//UIHelper.waitForVisibilityOfEleByXpath(getDriver(), prcount);
			 if(getPreCount.isPresent()){
			 
			 String precount = getPreCount.getText();	 
					 pCount = Integer.parseInt(precount);
			 preCountResultBtn.click();
			
			 }else {
				
				 String precount1 = getPreCount1.getText().trim();	
				 System.out.println("PreCount"+precount1);
				 pCount = Integer.parseInt(precount1);
				 
				 preCountResultBtn.click();
				 
			 }
			 getDriver().switchTo().defaultContent();
			 }
			 }
			 
		}
	public void clickonexportbuttonpage(String Ext)
	{
		
		if(Ext!="")
		{
			UIHelper.highlightElement(getDriver(),expExt);
			expExt.selectByVisibleText(Ext);
		UIHelper.highlightElement(getDriver(),clickonexportbuttonpageobj);
		clickonexportbuttonpageobj.click();
		}
		else{
			UIHelper.highlightElement(getDriver(),clickonexportbuttonpageobj);
			clickonexportbuttonpageobj.click();
		}
	}
	public void checkredirecttestpage(String exportHome)
	{
		String ReexportPgTitle1 = checkredirecttestpageobj.getText();
		exportHome.equals(ReexportPgTitle1);
		
	
	}
	
	public void expStatusObj(String expStatus)
	{

		waitFor(10000).milliseconds();
		getDriver().navigate().refresh();
		String expStatusChange = checkstatuschangetestpageobj.getText();
		
		if(expStatusChange.equals(expStatus))
		{
			System.out.println("Application moved to Completed Status:"+expStatusChange);
				clickondownloadtestpageobj.click();
				waitFor(5000).milliseconds();
		}

	}
	
	public void expRecCountAfterChangeStatus(String Ext, String selectFilter) throws Exception
	{
		if(Ext!="")
		{
		if(selectFilter!="")
		{
		
		waitFor(2000).milliseconds();
		String filePath = "C:\\Users\\nanjappank\\Downloads";
		
		
		File dir = new File(filePath);
		    File[] files = dir.listFiles();
			
	    File lastModifiedFile = files[0];
	    	
		for (int i = 1; i < files.length; i++) {
		       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
		           lastModifiedFile = files[i];
		       }
		    }
		String LMFile = filePath+"\\"+lastModifiedFile.getName();
		System.out.println("lmfile name"+LMFile);
		FileInputStream fs = new FileInputStream(LMFile);    
		/*Workbook wb = Workbook.getWorkbook(fs);
		jxl.Sheet sh = wb.getSheet(0);*/
		if(Ext.contains("Excel"))
		{
		HSSFWorkbook wb = new HSSFWorkbook(fs);
        HSSFSheet sh = wb.getSheetAt(0);
		int totalNoOfRows = sh.getPhysicalNumberOfRows();
	/*	 HSSFWorkbook wrk = new HSSFWorkbook(fis);
	HSSFSheet ws = wrk.getSheetAt(0);
        int totalRows=ws.getPhysicalNumberOfRows();	*/
		waitFor(2000).milliseconds();
			
			if(getpCount()	== totalNoOfRows)
			{
				System.out.println("Success");
			}
			else {
				System.out.println("Failed, due to space issue in application server");
			}
		}else
		{
			try
			{
			byte[] c = new byte[1024];
	        int count = 0;
	        int readChars = 0;
	        boolean empty = true;
	        while ((readChars = fs.read(c)) != -1) {
	            empty = false;
	            for (int i = 0; i < readChars; ++i) {
	                if (c[i] == '\n') {
	                    ++count;
	                }
	            }
	        }
	        if(getpCount()	== count)
			{
				System.out.println("Success");
			}
			else {
				System.out.println("Failed, due to space issue in application server");
			}
		}finally {
			fs.close();
	}
		
		}	
	}
	}
	}
	}

		


