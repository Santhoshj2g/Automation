package com.dnb.automation.imreg.pages;

import org.openqa.selenium.support.FindBy;
import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
/**********************************************************************************************
* IMLoginPage.java - This class contains login functionality
*
* @author Iyyappan K
***********************************************************************************************/
public class IMLoginPage extends PageObject {
	
	@FindBy(name = "userName")
	private WebElementFacade userNameEdt;
	
	@FindBy(name = "password")
	private WebElementFacade passwordEdt;

	@FindBy(name = "imageField")
	private WebElementFacade loginBtn;
	
	public void getURLAndLaunchApplication(String IMAppURL) throws Exception
	{
		getDriver().manage().deleteAllCookies();
		getDriver().manage().window().maximize();
		getURLtoTest(IMAppURL);
	}

	public void login(String userName, String password) throws Exception
	{
		enterUserName(userName);
		enterPassword(password);
		clickLoginButton(userName, password);
	}
	
	public void getURLtoTest(String IMAppURL) throws Exception 
	{
		getDriver().get(IMAppURL);
		UIHelper.waitForPageToLoad(getDriver());
	}
	
	public void enterUserName(String userName) throws Exception
	{
		try {
			userNameEdt.waitUntilVisible();
			userNameEdt.type(userName);
			} catch (Exception e) {
				e.printStackTrace();
		}
	}

	public void enterPassword(String password) throws Exception
	{	
		try {
			passwordEdt.waitUntilVisible();
			passwordEdt.type(password);	
			} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickLoginButton(String Usname, String Psword) throws Exception
	{	
		if(loginBtn.isPresent())
		{
			loginBtn.click();
			UIHelper.waitForPageToLoad(getDriver());
		}		
	}

}
