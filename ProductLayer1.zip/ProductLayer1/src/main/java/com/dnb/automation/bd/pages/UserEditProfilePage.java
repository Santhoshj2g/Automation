package com.dnb.automation.bd.pages;

import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class UserEditProfilePage extends PageObject {
	
	@FindBy(xpath = "//div[@id='About-company']")	
	private WebElementFacade aboutCompany;

	@FindBy(xpath = "//*[@id='Left_Menu']")	
	private WebElementFacade prfl_LeftMenu;

	@FindBy(xpath = "//textarea[@id='about_the_company']")	
	private WebElementFacade aboutTheCompany;
	
	@FindBy(xpath = "//*[@id='Edit_Profile']/div[2]/h3")	
	private WebElementFacade editCompName;

	@FindBy(xpath = "//div[@id='Left_Menu']/a[contains(text(),'Company-info')]")	
	private WebElementFacade tabCompanyInfo;

	@FindBy(xpath = "//div[@id='Left_Menu']/a[contains(text(),'Corporate Information')]")	
	private WebElementFacade tabCorporateInfo;

	@FindBy(xpath = "//div[@id='Left_Menu']/a[contains(text(),'Key Employees')]")	
	private WebElementFacade tabKeyEmployee;

	@FindBy(xpath = "//div[@id='Left_Menu']/a[contains(text(),'Products & Brands')]")	
	private WebElementFacade tabProductsAndBrands;

	@FindBy(xpath = "//div[@id='Left_Menu']/a[contains(text(),'Registration Information/Line of Business')]")	
	private WebElementFacade tabRegInfoLineOfBusi;

	@FindBy(xpath = "//div[@id='Left_Menu']/a[contains(text(),'Business Information')]")	
	private WebElementFacade tabBusinessInfo;

	@FindBy(xpath = "//div[@id='company-info']")	
	private WebElementFacade sectionCorporateInfo;
	
	@FindBy(xpath = "//div[@id='Registration_Info']")	
	private WebElementFacade sectionRegistrationInfo;		

	@FindBy(xpath = "//div[@id='key-emp']")	
	private WebElementFacade sectionKeyEmpInfo;		
	
	@FindBy(xpath = "//div[@id='products_and_brands']")	
	private WebElementFacade sectionProdAndBrands;		

	@FindBy(xpath = "//div[@id='business-info-section']")	
	private WebElementFacade sectionBusinessInfo;		

	@FindBy(xpath = "//h3[@id='ui-accordion-contact-address-header-2']")	
	private WebElementFacade phnNumExpand;

	@FindBy(xpath = "//div[@id='product-brands']//h3[@id='ui-accordion-product-brands-header-0']")	
	private WebElementFacade productsExpand;
	
	@FindBy(xpath = "//select[@id='telephone-type']")	
	private WebElementFacade selPhoneType;
		
	@FindBy(xpath = "//input[@id='telephone-isd']")	
	private WebElementFacade txtISOCode;

	@FindBy(xpath = "//input[@id='telephone-phone']")	
	private WebElementFacade txtPhoneNum;

	@FindBy(xpath = "//a[@id='telephone-add']")	
	private WebElementFacade btnTelephoneAdd;

	@FindBy(xpath = "//a[@id='product-add']")	
	private WebElementFacade btnProductAdd;

	@FindBy(xpath = "//div[@id='sic-options']//input[@id='sic-input']")	
	private WebElementFacade inpSicCode;

	@FindBy(xpath = "//div/input[@id='unspsc-input']")	
	private WebElementFacade inpUNSPSC;
		
	@FindBy(xpath = "//div[@class='buttons']/a[@id='sic-add']")	
	private WebElementFacade btnSicCodeAdd;

	@FindBy(xpath = "//div[@class='loadmask-msg']")	
	private WebElementFacade imgLoading;
	
	String loadicon="//div[@class='loadmask-msg']";

	@FindBy(xpath = "//div[@id='key-emp']//select[@id='keemp-title']")	
	private WebElementFacade selKeyEmpTitle;

	@FindBy(xpath = "//div[@id='key-emp']//input[@id='keemp-firstName']")	
	private WebElementFacade txtKeyEmpFirstName;

	@FindBy(xpath = "//div[@id='key-emp']//input[@id='keemp-middleName']")	
	private WebElementFacade txtKeyEmpMiddleName;
	
	@FindBy(xpath = "//div[@id='key-emp']//input[@id='keemp-lastName']")	
	private WebElementFacade txtKeyEmpLastName;
		
	@FindBy(xpath = "//div[@id='key-emp']//select[@id='keemp-jobtitle']")	
	private WebElementFacade selKeyEmpJobTitleName;

	@FindBy(xpath = "//div[@id='key-emp']//input[@id='keemp-mail']")	
	private WebElementFacade txtKeyEmpEmail;

	@FindBy(xpath = "//div[@id='key-emp']//a[@id='save-main-keyemployee']")	
	private WebElementFacade btnKeyEmpAdd;

	@FindBy(xpath = "//div[@id='linkageInfoAdd']//select[@id='linkageType']")	
	private WebElementFacade selLinkageType;

	@FindBy(xpath = "//div[@id='linkageInfoAdd']//input[@id='linkageDescription']")	
	private WebElementFacade txtLinkageDesc;
	
	@FindBy(xpath = "//div[@id='linkageInfoAdd']//a[@id='addLinkage']")	
	private WebElementFacade btnAddLinkage;

	@FindBy(xpath = "//div[@id='Edit_Profile']//a[@id='edit-submit']")	
	private WebElementFacade btnSubmitForapproval;
	
	@FindBy(xpath = "//span[@id='edit-success']")	
	private WebElementFacade msgEditSucess;
	

	/***********************************************************************************
	* Function: verify the profile is opened in edit mode. 
	* Input : NA
	* Action : NA 
	* Output : ProfileName
	***********************************************************************************/
	
	public String isProfileEditMode() {
	
		if(aboutCompany.isVisible() && prfl_LeftMenu.isVisible() && aboutTheCompany.isVisible())
		{
			return editCompName.getText();	
		}
		else
		{
			return null;
		}
	}

	/***********************************************************************************
	* Function: select the company info tab in profile edit page 
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public boolean selectCompanyInfoTab() {
		tabCompanyInfo.click();
		return aboutTheCompany.isVisible();		
	}

	/***********************************************************************************
	* Function: update the company info tab in profile edit page 
	* Input : company information
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void setCompanyInfo(String companyInfo) {
		aboutTheCompany.waitUntilEnabled();
		aboutTheCompany.clear();
		aboutTheCompany.sendKeys(companyInfo);		
	}

	/***********************************************************************************
	* Function: select the Corporate info tab in profile edit page 
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
	public boolean selectCorporateInfoTab() {
		tabCorporateInfo.click();
		return sectionCorporateInfo.isVisible();
	}

	/***********************************************************************************
	* Function: update the company info tab in profile edit page 
	* Input : company information
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void setCorporateInfoWithPhoneNum(String phoneType, String iSDCode,String phoneNum) {
		if(phnNumExpand.getAttribute("aria-selected").equalsIgnoreCase("false"))
		{
			phnNumExpand.click();
			selPhoneType.waitUntilEnabled();
		}
		selPhoneType.selectByVisibleText(phoneType);
		txtISOCode.sendKeys(iSDCode);
		txtPhoneNum.sendKeys(phoneNum);	
		btnTelephoneAdd.click();		
	}

	/***********************************************************************************
	* Function: select the Registration info / line of business tab in profile edit page 
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
	public boolean selectRegInfoTab() {
		tabRegInfoLineOfBusi.click();
		return sectionRegistrationInfo.isVisible();
	}


	/***********************************************************************************
	* Function: select the Registration info / line of business tab in profile edit page 
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
	public void setSicCode(String sicCode) {
		inpSicCode.sendKeys(sicCode);
		btnSicCodeAdd.click();	
		imgLoading.waitUntilNotVisible();
		
	}

	/***********************************************************************************
	* Function: select the Key Employee tab in profile edit page 
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public boolean selectKeyEmpTab() {
		tabKeyEmployee.click();
		return sectionKeyEmpInfo.isVisible();
	}

	/***********************************************************************************
	* Function: Add the employee details in Key employee section 
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/	
	public void setEmpDetails(String EmpTitle,String empFirstName, String empMiddleName,
			String empLastName, String empJobTitle) {
		selKeyEmpTitle.selectByVisibleText(EmpTitle);
		txtKeyEmpFirstName.sendKeys(empFirstName);
		txtKeyEmpMiddleName.sendKeys(empMiddleName);
		txtKeyEmpLastName.sendKeys(empLastName);
		selKeyEmpJobTitleName.selectByVisibleText(empJobTitle);		
		btnKeyEmpAdd.click();
	   	UIHelper.waitForPageToLoad(getDriver());
	   	UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadicon);		
	}

	/***********************************************************************************
	* Function: select the Business information tab in profile edit page 
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
	public boolean selectBusinessInfoTab() {
		tabBusinessInfo.click();
		return sectionBusinessInfo.isVisible();
	}

	/***********************************************************************************
	* Function: Add the linkage information in business information section 
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/	
	
	public void setLinkageInfo(String linkageType, String linkageDes) {
		selLinkageType.selectByVisibleText(linkageType);
		txtLinkageDesc.sendKeys(linkageDes);		
		btnAddLinkage.click();	   	
	   	UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadicon);
	   	UIHelper.waitForPageToLoad(getDriver());
		}

	/***********************************************************************************
	* Function: select the products and Brands tab in profile edit page 
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/	
	public Object selectProductsAndBrandsTab() {
		 tabProductsAndBrands.click();
		return sectionProdAndBrands.isVisible();
	}

	/***********************************************************************************
	* Function: Add the UNSPSC in Products and Brands section 
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/	
	
	public void setUNSPSCCode(String uNSPSC) {
		if(productsExpand.getAttribute("aria-selected").equalsIgnoreCase("false"))
		{
			productsExpand.click();
			inpUNSPSC.waitUntilEnabled();
		}		
		inpUNSPSC.sendKeys(uNSPSC);	
		btnProductAdd.click();
	   	UIHelper.waitForPageToLoad(getDriver());
	   	UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadicon);		
	}

	/***********************************************************************************
	* Function: Click on Submit for Approval button
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/		
	public void clickSubmitApproval() {
		UIHelper.waitForPageToLoad(getDriver());
		btnSubmitForapproval.click();		
	}

	/***********************************************************************************
	* Function: verify the edit profile submitted sucessfully
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/			
	public void isSubmitConfirmationDisp() {
		msgEditSucess.isVisible();		
	}

	

}
