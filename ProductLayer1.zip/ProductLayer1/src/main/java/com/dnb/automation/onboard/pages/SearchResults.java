package com.dnb.automation.onboard.pages;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.hamcrest.Matchers;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;

//import static org.hamcrest.MatcherAssert.assertThat;
//import static org.junit.Assert.*;

import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * SearchResults.java - This program contains steps for 1. Verify the search
 * results 2. Navigation to Compliance report
 *
 * ********************************************************************************************/
public class SearchResults extends PageObject {
    @FindBy(xpath = "//*[@id='resultDiv']")
    private WebElementFacade searchresultsframe;
    @FindBy(xpath = "//*[@id='searchResults']/tbody/tr[1]/td[5]/ul/li/a/b[@class='caret']")
    private WebElementFacade selectproduct;
    @FindBy(xpath = "//*[@id='resultDiv']//*[@id='searchResults']/tbody/tr/td[5]/ul/li/ul/li[1]/a[contains(.,'Compliance Report')]")
    private WebElementFacade compliancereport;
    @FindBy(xpath = "//*[@id='reportTabHolder']")
    private WebElementFacade reportForm;
    @FindBy(xpath = "//*[@id='errorMsgContainer']")
    private WebElementFacade popupForErrorMessage;
    @FindBy(xpath = "//*[@class='btnContainer']//*[@id='errorOKBtn']")
    private WebElementFacade okButtonInErrorMsgPopup;
    @FindBy(xpath="//*[@id='companySearchInvestigationLinkWithResults']")
	private WebElementFacade investigationLink;
	/*@FindBy(id ="errorMsgContainer")
	private WebElementFacade errormsg;*/
	/*@FindBy(xpath ="html/body/div[17]/div[2]/div[2]/button")
	private WebElementFacade okbutton;	*/
	@FindBy(xpath ="html/body/div[1]/div[10]/div[2]/div/div[1]/div[1]/ul/li/button")
	private WebElementFacade reportActionsmenu;
	@FindBy(id ="ecfAddToFolderLink")
	private WebElementFacade addtosnapshot;
	@FindBy(id ="informationMsgText")
	private WebElementFacade popupmsg;
	@FindBy(id ="ecfLiveReportTitleValue")
	private WebElementFacade compliancereportfrm;
	@FindBy(xpath ="html/body/div[1]/div[3]/div[1]/div/form/div/table/tbody/tr")
	private List<WebElementFacade> selectproductfrm;
	@FindBy(xpath ="html/body/div[1]/div[3]/div[2]/form/div/table/tbody/tr")
	private List<WebElementFacade> dnbGlobalnameresultsframe;
	@FindBy(xpath ="html/body/div[1]/div[3]/div[3]/div[5]/table/tbody/tr")
	private List<WebElementFacade> snapshotresultsframe;
	@FindBy(id ="informationBtn")
	private WebElementFacade snapshotBtn;
	@FindBy(id ="advancedSearchLnk")
	private WebElementFacade Advancedsearch;
	@FindBy(id ="advancedCompanySearchBtn")
	private WebElementFacade advancedsearchbtn;
	@FindBy(id ="companyName")
	private WebElementFacade BusinessName;
	@FindBy(id ="standardSearchLnk")
	private WebElementFacade Standardsearch;
	@FindBy(id ="dunsNumber")
	private WebElementFacade Dunsnumber;
	@FindBy(xpath ="html/body/div[17]/div[2]/div[2]/button")
	private WebElementFacade okbutton;
	@FindBy(xpath = ".//*[@id='reportViewerLoading']/img")
	private WebElementFacade ajaxRunningImg;
	@FindBy(id ="germanReasonCode")
	private WebElementFacade reasoncode;
	@FindBy(id ="cancelGermanBtn")
	private WebElementFacade cancelbtn;
	/*@FindBy(xpath ="html/body/div[1]/div[10]/div[2]/div/div[1]/div[1]/ul/li/button")
	private WebElementFacade reportActionsmenu;*/
	@FindBy(xpath ="//*[contains(@id,'ui-id-')][@title='D&B Results']")
	private WebElementFacade searchresult;

	@FindBy(id="searchLink")
	private WebElementFacade searchMenu;

	@FindBy(id ="companyName")
	private WebElementFacade businessName;

	@FindBy(xpath ="//*[@class='actionItems']/a[contains(@id,'standardSearchLnk')]")
	private WebElementFacade standardSearchLinkEle;

	/*@FindBy(id ="ecfAddToFolderLink")
	private WebElementFacade addtosnapshot;*/

	/*@FindBy(id ="informationMsgText")
	private WebElementFacade popupmsg;*/
	@FindBy(xpath ="//*[@id='advancedCompanySearchBtn']")
	private WebElementFacade resetbutton;

@FindBy(id ="errorMsgContainer")
	private WebElementFacade errormsg;
	@FindBy(xpath ="html/body/div[1]/div[3]/ul/li[1]/a/span")
	private WebElementFacade searchresultno;
	@FindBy(xpath ="//*[@id='ecfDunsNumberValue']")
	private WebElementFacade dunsnoFrame;	
	@FindBy(xpath ="//*[@id='ecfRegistrationNumberValue']")
	private WebElementFacade registrationFrame;		
	@FindBy(xpath ="//*[@id='ecfCompanySessionValue']")
	private WebElementFacade caseRefNameframe;

    private String productNameXpath = "//*[@id='resultDiv']//*[@id='searchResults']/tbody/tr/td[5]/ul/li/ul/li/a[contains(.,'SERENITY')]";
    private String ajaxLoadingImage = ".//*[@id='reportViewerLoading']/img";
    private String additionalOrErrorMsgEleXpath = ".//*[contains(@id,'additionalProducts') or contains(@id,'errorMsgContainer')]";
	private String onboardLoad ="//*[@id='reportViewerLoading']/img[contains(@src,'/onboard/resources/images/ajax-loader.gif')]";
	private String snapshotpage ="//*/div[@class='saving hidden hover']/img[@class='loader']";
	private String advancedsearchpage ="//*/div[@id='companySearchResultsLoading']/img[@class='loader']";
	private String snapshotload = "//*[@title='Snapshot Results']/img[contains(@src='./resources/images/ajax-loader-header.gif')]";

List<String> exp_options=Arrays.asList(new String[]{"Compliance Report","Identification Report","Ownership Structure","Global Family Tree","Company Documents","Business Audit Report"});

@FindBy(xpath = "//div[1]/ul/li/button[@id='reportActions'][@class='reportActions dropdown-toggle']")
private WebElementFacade reportActions;

@FindBy(xpath = "//*[@id='showAssociateDUNSWithCaseLink']")
private WebElementFacade showAssociateDUNSWithCaseLink;

private String associateLoad  ="//div[1]/div[10]/div[2]/div/div[3]/div[3]/div/div[2]/div[1][@class='dataTables_processing'][@style='visibility: visible;']/div[2]/img";

    // User is on Search results page

    public void resultsFrameCheck() {
    	searchresultsframe.waitUntilPresent();
    }

	public boolean resultFrameCheck()
	{
		navigateToSearchResults();
		if(searchresultsframe.isPresent())
			{
			return true;
		}
		else
		{
			return false;
		}

	}


	public void advancedFrame(String DunsNum,String BusinessName)
	{
		System.out.println("enterd advancedframe");
		System.out.println(BusinessName);
		System.out.println(DunsNum);
		searchMenu.click();
		UIHelper.waitForPageToLoad(getDriver());

		if(Advancedsearch.isEnabled())
		{
			Advancedsearch.click();
			standardSearchLinkEle.waitUntilPresent();
		}
		if(BusinessName!=null && !BusinessName.isEmpty())
		{
			businessName.click();
			businessName.type(BusinessName);

		}
		else
		{
			System.out.println(DunsNum);
			System.out.println("Businessname value is null");
			Dunsnumber.click();
			Dunsnumber.type(DunsNum);
		}

		UIHelper.waitForPageToLoad(getDriver());
		System.out.println("after clicking advanced search");
		advancedsearchbtn.click();
        UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), advancedsearchpage);
        UIHelper.waitForPageToLoad(getDriver());
        System.out.println("search results for advanced search");
		/*else
		{
		System.out.println("enterd else of advancedframe");
		ResetButton.click();
		resetbutton.waitUntilPresent();
		//UIHelper.waitForVisibilityOfEleByXpath(getDriver(), resetbutton);
		UIHelper.waitForPageToLoad(getDriver());
		System.out.println("after clicking reset button");
		}

        UIHelper.highlightElement(getDriver(), businessName);
        System.out.println(businessName.getTextValue());
        Dunsnumber.click();
        System.out.println(Dunsnumber.getTextValue());
        advancedsearchbtn.click();
        UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), advancedsearchpage);
        UIHelper.waitForPageToLoad(getDriver());
        System.out.println("search results for advanced search");*/
	}

	public void navigateToSearchResults()
	{
		searchresultsframe.waitUntilPresent();

	}
	public boolean selectproductchk() throws Exception
	{
		if(selectproduct.isPresent())
		{
			selectproduct();
			return true;
		}
		else
		{
			return false;
		}
	}


    // User Clicks the Compliance Report

    public void selectproduct(String reportName) throws Exception {
        try {
        	while(investigationLink.isPresent()){
				selectproduct.waitUntilPresent();
			if (selectproduct.isPresent()) {
				selectproduct.click();
				String tempProductNameXpath = productNameXpath.replace("SERENITY", reportName);
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempProductNameXpath);
				WebElementFacade productNameEle = find(By.xpath(tempProductNameXpath));
				UIHelper.highlightElement(getDriver(), productNameEle);
				UIHelper.mouseOverandclickanElement(getDriver(), productNameEle);
				UIHelper.waitForPageToLoad(getDriver());
				if(!ajaxRunningImg.isPresent()){

				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						ajaxLoadingImage);
				}
			
				if(ajaxRunningImg.isPresent()){

				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						ajaxLoadingImage);
				}
				UIHelper.waitForPageToLoad(getDriver());
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), additionalOrErrorMsgEleXpath);

				if(popupForErrorMessage.isPresent() && popupForErrorMessage.isVisible())
				{
					okButtonInErrorMsgPopup.waitUntilPresent();
					okButtonInErrorMsgPopup.click();
				}
			}
        	}

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // User checks the Compliance report

    public boolean reportFrame() {
        if (reportForm.isPresent()) {
            return true;
        }

        else {
            return false;
        }
    }
	public void selectproduct()throws Exception
	{

		try
		{
			if (selectproduct.isPresent())
			{
				selectproduct.waitUntilPresent();
				UIHelper.highlightElement(getDriver(), selectproduct);
				selectproduct.click();
			}
			System.out.println("product is selected");
		}
		catch(Exception E)
		{
			E.printStackTrace();
		}
	}
	public void checkcomplink() throws Exception
	{
		if(compliancereport.isPresent())
		{
			System.out.println("entered selectproduct");
			compliancereport.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), compliancereport);
			compliancereport.click();
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), onboardLoad);
			if (errormsg.isEnabled())
			{
				okbutton.click();
			}
		}
		System.out.println("Compliance report is selected");
	}

	public boolean compliancereportchk() throws Exception
	{
		if(compliancereport.isPresent())
		{
			checkcomplink();
			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean compliancereportframe()
	{
		if(compliancereportfrm.isPresent())
		{
			System.out.println(compliancereportfrm.getText());
			return true;
		}
		else
		{
			return false;
		}

	}
	public boolean addtoSnapshot()
		{
		if (reportActionsmenu.isPresent())
		{

			reportActionsmenu.click();
			addtosnapshot.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), snapshotpage);
			popupmsg.waitUntilPresent();
			System.out.println(popupmsg.getText());
			return true;
		}
	else
	{
		return false;
	}

	}

	public boolean snapshotMsg()
	{
			String snapshot=popupmsg.getText();
			System.out.println("entered If loop");
			if (snapshot.contains("Report(s) added to your Snapshot"))
			{
				System.out.println("Snapshot added successfully");
				snapshotBtn.click();
				return true;
			}
			else
			{
				System.out.println("Snapshot is not added properly");
				return false;
			}

	}
	public boolean checkReports()
	{
	    if(searchresultsframe.isPresent())
	    {
	    System.out.println("looking for searchresultsframe");
        /*Dunsnumber_Businessname.click();
        System.out.println(Dunsnumber_Businessname.getTextValue());    */
            getDriver().findElement(By.xpath("html/body/div[1]/div[3]/ul/li[1]/a")).click();
            WebElement resulttab=getDriver().findElement(By.xpath("html/body/div[1]/div[3]/ul/li[1]/a/span"));
            resulttab.click();
            UIHelper.waitForPageToLoad(getDriver());
            System.out.println(resulttab.getText());
            System.out.println(selectproductfrm.size());
            if(resulttab.getText().equalsIgnoreCase("0"))
            {
                    System.out.println("No results displayed in this tab");
					return false;
            }
            else
            {
                    for (int i=0; i< selectproductfrm.size(); i++)
                    {
                        i=i+1;
                        WebElement frame=getDriver().findElement(By.xpath("html/body/div[1]/div[3]/div[1]/div/form/div/table/tbody/tr["+i+"]/td[5]/ul/li/a/b"));
                        UIHelper.highlightElement(getDriver(), frame);
                        frame.click();
                        UIHelper.waitForPageToLoad(getDriver());
              /*          WebElement selectproductframe=getDriver().findElement(By.xpath("html/body/div[1]/div[3]/div[1]/div/form/div/table/tbody/tr["+i+"]/td[5]/ul/li/a"));
                        selectproductframe.click();
             */
                        //String output=selectproductframe.getText();
                        //System.out.println(selectproductframe.getText());
                        List<WebElement> options=getDriver().findElements(By.xpath("html/body/div[1]/div[3]/div[1]/div/form/div/table/tbody/tr["+i+"]/td[5]/ul/li/ul/li/a"));
                        System.out.println(options.size());
                        System.out.println(options.get(0));
                        System.out.println(options.get(0).getText());


                   //     List act_options=new ArrayList();
                       ArrayList <String>array1=new ArrayList();
                        System.out.println("Before for loop");
                        for (int j=0;j< options.size(); j++)
                        {
                        	System.out.println("entering for loop");
                      //  	String actual = options.get(j).getText();
                        	//act_options.add(actual);
                        	//System.out.println(actual);

                        	array1.add(options.get(j).getText());
                        	System.out.println(array1.toString());
                        	System.out.println(options.get(j).getText());
                        }

                        Collections.sort(array1);
                        System.out.println(array1);
                        Collections.sort(exp_options);
                        System.out.println(exp_options);
                        //assertThat(array1.equals(exp_options),Matchers.equalTo(true));
                        //assertArrayEquals(exp_options.toArray(),act_options.toArray());
                        /*Select output1=new Select(selectproductframe);
                        List<WebElement> var1=output1.getOptions();
                        System.out.println(var1.size());
                        for(int j=0; j<var1.size(); j++)
                        {
                        System.out.println(var1.get(j).getText());
                        }  */

                        /*if(output.contains(reports))
                        {
                        	System.out.println("All the six reports are displayed");
                        }
                        else
                        {
                        	return false;
                        }*/
                        frame.click();
                        UIHelper.waitForPageToLoad(getDriver());
                        i=i-1;
                        System.out.println(i);
                    }

                }
            return true;
	    }
	    else
	    {
	    	return false;
	    }
	}
	//End of Tab1//

            //Tab 2//
	    public boolean checkDBGlobalResultsReports()
	    {
	    	if(searchresultsframe.isPresent())
	    	{
            System.out.println("Entering tab 2 validation");
            WebElement resulttab2=getDriver().findElement(By.xpath("html/body/div[1]/div[3]/ul/li[2]/a/span"));
            resulttab2.click();
            UIHelper.waitForPageToLoad(getDriver());
            System.out.println(resulttab2.getText());
            UIHelper.waitForPageToLoad(getDriver());

            if(resulttab2.getText().equalsIgnoreCase("0"))
            {

               //int cnt=dnbGlobalnameresultsframe.size();
                		System.out.println("No results displayed in D&B Global Name results tab");
                		return false;
            }
            else
            {
            	 System.out.println(dnbGlobalnameresultsframe.size());
            	 System.out.println("enter else loop");
                resulttab2.click();
                for (int j=0; j< dnbGlobalnameresultsframe.size(); j++)
                    {
                        //int lastno=10;
                        j=j+1;
                        WebElement frame2=getDriver().findElement(By.xpath("html/body/div[1]/div[3]/div[2]/form/div/table/tbody/tr["+j+"]/td[4]/ul/li/a"));
                        UIHelper.highlightElement(getDriver(), frame2);
                        frame2.click();
                        UIHelper.waitForPageToLoad(getDriver());
                        System.out.println("after frame2");
                        List<WebElement> options=getDriver().findElements(By.xpath("html/body/div[1]/div[3]/div[2]/form/div/table/tbody/tr["+j+"]/td[4]/ul/li/ul/li"));
                        //WebElement selectproductframe2=getDriver().findElement(By.xpath("html/body/div[1]/div[3]/div[2]/form/div/table/tbody/tr["+j+"]/td[4]/ul/li/ul"));
                       // UIHelper.highlightElement(getDriver(), selectproductframe2);
                        System.out.println("after selectproductframe");
                        System.out.println(options.size());
                       // System.out.println(selectproductframe2.getText());
                        ArrayList <String>array2=new ArrayList();
                        for (int k=0;k< options.size(); k++)
                        {
                        	System.out.println("entering for loop");
                        	array2.add(options.get(k).getText());
                        	System.out.println(array2.toString());
                        	System.out.println(options.get(k).getText());
                        }
                        Collections.sort(array2);
                        System.out.println(array2);
                        Collections.sort(exp_options);
                        System.out.println(exp_options);
                        //assertThat(array2.equals(exp_options),Matchers.equalTo(true));
                        frame2.click();
                        UIHelper.waitForPageToLoad(getDriver());
                        j=j-1;
                        System.out.println(j);
                    }
                }
            return true;
	    	}
	    	else
	    	{
	    		return false;
	    	}
	    }
		public boolean checkSnapshotResultReports()
	    {
	    	  UIHelper.waitForPageToLoad(getDriver());
	    	if(searchresultsframe.isPresent())
	    	{
	            System.out.println("Entering tab 3 validation");
	            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), snapshotload);
	            WebElement resulttab3=getDriver().findElement(By.xpath("html/body/div[1]/div[3]/ul/li[3]/a/span"));
	            resulttab3.click();
	            UIHelper.waitForPageToLoad(getDriver());
	            System.out.println(resulttab3.getText());
	            UIHelper.waitForPageToLoad(getDriver());
	            System.out.println(snapshotresultsframe.size());
	            if(resulttab3.getText().equalsIgnoreCase("0"))
	            {

	                System.out.println("No results displayed in Snapshot results tab");
	                return false;
	            }
	            else
	            {
	                System.out.println("enter else loop");
	                resulttab3.click();
	                for (int j=0; j< snapshotresultsframe.size(); j++)
	                    {
	                		j=j+1;
	                        WebElement frame3=getDriver().findElement(By.xpath("html/body/div[1]/div[3]/div[3]/div[5]/table/tbody/tr["+j+"]/td[6]/ul/li/a/b"));
	                        UIHelper.highlightElement(getDriver(), frame3);
	                        frame3.click();
	                        UIHelper.waitForPageToLoad(getDriver());
	                        System.out.println("after frame3");
	                        List<WebElement> options=getDriver().findElements(By.xpath("html/body/div[1]/div[3]/div[3]/div[5]/table/tbody/tr["+j+"]/td[6]/ul/li/ul"));
	                        //WebElement selectproductframe3=getDriver().findElement(By.xpath("html/body/div[1]/div[3]/div[3]/div[5]/table/tbody/tr["+j+"]/td[6]/ul/li/ul"));
	                        //UIHelper.highlightElement(getDriver(), selectproductframe3);
	                        //System.out.println("after selectproductframe3");
	                        //System.out.println(selectproductframe3.getText());
	                        /*Select output1=new Select(selectproductframe3);
	                        List<WebElement> var1=output1.getOptions();
	                        for(int i=0; i<var1.size(); i++)
	                        {
	                        System.out.println(var1.get(i).getText());
	                        }        */
	                        ArrayList <String>array3=new ArrayList();
	                        System.out.println("Before for loop");
	                        for (int l=0;l< options.size(); l++)
	                        {
	                        	System.out.println("entering for loop");
	                           	array3.add(options.get(l).getText());
	                        	System.out.println(array3.toString());
	                        	System.out.println(options.get(l).getText());
	                        }
	                        Collections.sort(array3);
	                        System.out.println(array3);
	                        Collections.sort(exp_options);
	                        System.out.println(exp_options);
	                        //assertThat(array3.equals(exp_options),Matchers.equalTo(true));
	                        frame3.click();
	                        UIHelper.waitForPageToLoad(getDriver());
	                        j=j-1;
	                        System.out.println(j);
	                    }
	                }
	            	return true;
	    			}
	    			else
				    {
				    return false;
				    }
}

		
	public boolean clickReportActions()
	{
				if (reportActions.isPresent())
				{
					reportActions.click();
					UIHelper.waitForPageToLoad(getDriver());
					return true;
				}
					
				else 
					return false;
			}

	public boolean associateCase(){
		
		if(showAssociateDUNSWithCaseLink.isPresent())
		{
			showAssociateDUNSWithCaseLink.click();						
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), associateLoad);
			UIHelper.waitForPageToLoad(getDriver());
			System.out.println("waiting until message disappear");						
			return true;
		}
		else
			
			return false;
	}

public boolean DunsNO(String DUNSNO)
{
	dunsnoFrame.click();
	String dunsno = dunsnoFrame.getTextValue();	
	System.out.println(dunsno);
	System.out.println(DUNSNO);
	if(dunsno.equals(DUNSNO))
		{
			return true;			
			
		}
		else
		{
			return false;
		}
}
/*public void dunsverify(String DunsNum)
{
	String dunsno = dunsnoFrame.getTextValue();	
	if (DunsNum==dunsno)
	{
		System.out.println("Given DUNS is displayed in Compliance Report page");
	}
	else
	{
		System.out.println("Given DUNS is not displayed in Compliance Report page");
	}
}*/
	public boolean registrationNO()
	{
		if(registrationFrame.isPresent())
		{
			System.out.println(registrationFrame.getTextValue());
			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean caseRefName()
	{
		if(caseRefNameframe.isPresent())
		{
			System.out.println(caseRefNameframe.getTextValue());
			return true;
		}
		else
		{
			return false;
		}
	}





	}

	