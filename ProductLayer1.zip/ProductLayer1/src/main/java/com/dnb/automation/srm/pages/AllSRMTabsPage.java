package com.dnb.automation.srm.pages;

import java.util.ArrayList;
import java.util.List;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * AllSRMTabsPage.java - This program contains steps for 1. User clicks the
 * all tabs 2. User checks the all tabs navigation
 *
 * @author Duvvuru Naveen
 ***********************************************************************************************/

public class AllSRMTabsPage extends PageObject {

    @FindBy(xpath = ".//*[@id='Predictive_Scores']/span/a")
    private WebElementFacade predictivescorelink;
    
    @FindBy(xpath = ".//*[@id='Alerts']/span/a")
    private WebElementFacade alertsTabEle;
    
    @FindBy(xpath = ".//*[@id='AlertHolder']")
    private WebElementFacade alertsHolderEle;
    
    @FindBy(xpath = ".//*[@id='Notes']/span/a")
    private WebElementFacade notesTabEle;
    
    @FindBy(xpath = ".//*[@id='Documents']/span/a")
    private WebElementFacade documentsTabEle;
    
    @FindBy(xpath = ".//*[@id='History']/span/a")
    private WebElementFacade historyTabEle;
    
    @FindBy(xpath = ".//*[@id='assessments']/span/a")
    private WebElementFacade assessmentsTabEle;
    
    @FindBy(xpath = ".//*[@id='Contacts']/span/a")
    private WebElementFacade contactsTabEle;
    
    @FindBy(xpath = ".//*[@id='SupplierProvidedData']/span/a")
    private WebElementFacade providedDataTabEle;
    
    @FindBy(xpath = ".//*[@id='CoporateLinkage']/span/a")
    private WebElementFacade corporateLinkageTabEle;
    
    @FindBy(xpath = ".//*[@id='Competitors']/span/a")
    private WebElementFacade competitorsTabEle;
    
    @FindBy(xpath = ".//*[@id='Country_Risk_Summary']/span/a")
    private WebElementFacade countryRiskSummaryTabEle;
    
    @FindBy(xpath = ".//*[@id='tier2supp']/span/a")
    private WebElementFacade tierTwoSupplierTabEle;
    
    @FindBy(xpath = ".//*[@id='Country_Risk_Summary_section']/div[2]/div[2]/div[1]/div")
    private WebElementFacade countryRiskIndicatorSecEle;
    
    @FindBy(xpath = ".//*[@id='Predictive_Scores_section']/div[1]/h3")
    private WebElementFacade predictiveScoreSecEle;
    
    @FindBy(xpath = ".//*[@id='Predictive_Scores_section']/div[8]/span|.//*[@id='Predictive_Scores_section']/div/h3")
    private List<WebElement> predictiveScoreSectionEle;
    
    @FindBy(xpath = ".//*[@id='profile_section']//*[@class='rich-panel-header panelheader']")
    private List<WebElement> profileSections;
    
    @FindBy(xpath = ".//*[@id='alertSort']/th[2] | .//*[@id='alertSort']/th[3] | .//*[@id='alertSort']/th[4] | .//*[@id='alertSort']/th[5]")
    private List<WebElement> alertSections;
    
    @FindBy(xpath = ".//*[@id='Notes_section']/div/h3")
    private List<WebElement> notesSections;
    
    @FindBy(xpath = ".//*[@id='Documents_section']/div/div/h3")
    private List<WebElement> documentsSections;
    
    @FindBy(xpath = ".//*[@id='notes_txt']")
    private WebElementFacade notesTxtAreaEle;
    
    @FindBy(xpath = ".//*[@id='Documents_section']/div/div[1]/h3")
    private WebElementFacade documnetSecHeadingEle;
    
    @FindBy(xpath = ".//*[@id='HistoryHolder']")
    private WebElementFacade historyHolderEle;
    
    @FindBy(xpath = ".//*[@id='PostNote']")
    private WebElementFacade postNotesEle;
    
    @FindBy(xpath = ".//*[@id='errMsg']/span")
    private WebElementFacade errorMsgEleInPosting;
    
    @FindBy(xpath = ".//*[@id='company_notes_detail_notes']//*[@class='posted-content']")
    private List<WebElement> postedContentEle;
    
    @FindBy(xpath = ".//*[@id='historyTable']/thead/tr/th")
    private List<WebElement> historySectionNamesEle;
    
    @FindBy(xpath = ".//*[@id='company_history_detail_content']/div[1]/h3")
    private List<WebElement> contactsSectionNamesEle;
    
    @FindBy(xpath = ".//*[@id='MainAssesment']/div/h3")
    private List<WebElement> assessmentsSectionNamesEle;
    
    @FindBy(xpath = ".//*[@id='SupplierProvidedData_section']/div[1]/h3 | .//*[@id='SupplierProvidedData_section']/div[2]/div[2]/div[1]/div | .//*[@id='SupplierProvidedData_section']/div[2]/div[3]/div[1]/div")
    private List<WebElement> providedDataSectionNamesEle;
    
    @FindBy(xpath = ".//*[@id='Competitors_section']/div[3]/h3")
    private List<WebElement> competitorsSectionNamesEle;
    
    @FindBy(xpath = ".//*[@id='Competitors_section']/div[3]/h3")
    private WebElementFacade topCompetitorsEle;
    
    @FindBy(xpath = ".//*[@id='keyFacts'] | //*[@id='Country_Risk_Summary_section']/div[2]/div[2]/div[1]/div")
    private List<WebElement> countrySummaryRiskSectionNamesEle;
    
    @FindBy(xpath = ".//*[@id='tier2supp_section']/div/div[1]/h3")
    private List<WebElement> tierTwoSupplierSectionNamesEle;
    
    @FindBy(xpath = ".//*[@id='Add_supplier_contact']")
    private WebElementFacade addContactBtnEle;
    
    public WebElementFacade getAddContactBtnEle() {
        return addContactBtnEle;
    }

    @FindBy(xpath = ".//*[@id='Assesment_button']")
    private WebElementFacade initiateAssessmentBtnEle;
    
    public WebElementFacade getInitiateAssessmentBtnEle() {
        return initiateAssessmentBtnEle;
    }

    @FindBy(xpath = ".//*[@id='SupplierProvidedData_section']/div[1]/h3")
    private WebElementFacade supplierProvidedDataEle;
    
    @FindBy(xpath = ".//*[@id='familyTree_Container']/div")
    private WebElementFacade notAvailableEle;

    public WebElementFacade getNotAvailableEle() {
        return notAvailableEle;
    }

    public WebElementFacade getErrorMsgEleInPosting() {
        return errorMsgEleInPosting;
    }

    private String loadingImgXpathInAlerts = ".//*[@id='Alerts_section']/div/div[2]/div[3]/div[1]/img";
    private String loadingImgXpathInNotes = ".//*[@id='company_notes_detail_content']/div[3]/img";
    private String loadingImgXpathInHistory = ".//*[@id='company_history_detail_content']/div[2]/div[1]/img";
    private String loadingImgXpathInCorpLinkage = ".//*[@id='CoporateLinkage_section_loading']/img";
    private String loadingImgXpathInCompetitors = ".//*[@id='maptableview']/div/img";
    private String loadingImgXpathInTierTwoSupplier = ".//*[@class='tier2Loading']/img";
    private ArrayList<String> sectionNamesInProfileTab = new ArrayList<String>();
    private ArrayList<String> predictiveScoreSectionNames = new ArrayList<String>();
    private ArrayList<String> alertSectionNames = new ArrayList<String>();
    private ArrayList<String> notesSectionNames = new ArrayList<String>();
    private ArrayList<String> documentsSectionNames = new ArrayList<String>();
    private ArrayList<String> historySectionNames = new ArrayList<String>();
    private ArrayList<String> contactsSectionNames = new ArrayList<String>();
    private ArrayList<String> assessmentsSectionNames = new ArrayList<String>();
    private ArrayList<String> providedDataSectionNames = new ArrayList<String>();
    private ArrayList<String> competitorsSectionNames = new ArrayList<String>();
    private ArrayList<String> countrySummaryRiskSectionNames = new ArrayList<String>();
    private ArrayList<String> tierTwoSupplierSectionNames = new ArrayList<String>();
    private ArrayList<String> sectionNames = new ArrayList<String>();
    private ArrayList<String> postedContents = new ArrayList<String>();

    public void clickOnTabLink(String tabName)
    {
        switch (tabName) {
            case "Predictive Scores":
                clickPredictiveScoreTab(tabName);
                break;
            case "Alerts":
                clickOnAlertsTab(tabName);
                break;
            case "Notes":
                clickOnNotesTab(tabName);
                break;
            case "Documents":
                clickOnDocumentsTab(tabName);
                break;
            case "History":
                clickOnHistoryTab(tabName);
                break;
            case "Contacts":
                clickOnContactsTab(tabName);
                break;
            case "Assessments":
                clickOnAssessmentsTab(tabName);
                break;
            case "Provided Data":
                clickOnProvidedDataTab(tabName);
                break;
            case "Corporate Linkage":
                clickOnCorporateLinkageTab(tabName);
                break;
            case "Competitors":
                clickOnCompetitorsTab(tabName);
                break;
            case "Country Risk Summary":
                clickOnCountryRiskSummaryTab(tabName);
                break;
            case "Tier 2 Suppliers":
                clickOnTierTwoSuppliersTab(tabName);
                break;
            default:
        }
    }
    
    //Click Predictive score tab
    public void clickPredictiveScoreTab(String tabName)
    {
        try{
            predictivescorelink.click();
            predictiveScoreSecEle.waitUntilPresent();
        }catch(Exception e){
            
        }
    }
    
    //Click On Alerts tab
    public void clickOnAlertsTab(String tabName)
    {
        try{
            alertsTabEle.click();
            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadingImgXpathInAlerts);
            alertsHolderEle.waitUntilPresent();
        }catch(Exception e){
            
        }
    }
    
    //Click on Notes tab
    public void clickOnNotesTab(String tabName)
    {
        try{
            notesTabEle.click();
            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadingImgXpathInNotes);
            notesTxtAreaEle.waitUntilPresent();
        }catch(Exception e){
            
        }
    }
    
    //Click on Documents tab
    public void clickOnDocumentsTab(String tabName)
    {
        try{
            documentsTabEle.click();
            documnetSecHeadingEle.waitUntilPresent();
        }catch(Exception e){
            
        }
    }
    
    //Click on History tab
    public void clickOnHistoryTab(String tabName)
    {
        try{
            historyTabEle.click();
            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadingImgXpathInHistory);
            historyHolderEle.waitUntilPresent();
        }catch(Exception e){
            
        }
    }
    
    //Click on Contacts tab
    public void clickOnContactsTab(String tabName)
    {
        try{
            contactsTabEle.click();
            addContactBtnEle.waitUntilPresent();
        }catch(Exception e){
            
        }
    }
    
    //Click on Assessments tab
    public void clickOnAssessmentsTab(String tabName)
    {
        try{
            assessmentsTabEle.click();
            initiateAssessmentBtnEle.waitUntilPresent();
        }catch(Exception e){
            
        }
    }
    
    //Click on Provided Data tab
    public void clickOnProvidedDataTab(String tabName)
    {
        try{
            providedDataTabEle.click();
            supplierProvidedDataEle.waitUntilPresent();
        }catch(Exception e){
            
        }
    }
    
    //Click on Corporate Linkage tab
    public void clickOnCorporateLinkageTab(String tabName)
    {
        try{
            corporateLinkageTabEle.click();
            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadingImgXpathInCorpLinkage);
            waitFor(2000).milliseconds();
        }catch(Exception e){
            
        }
    }
    
    //Click on Competitors tab
    public void clickOnCompetitorsTab(String tabName)
    {
        try{
            competitorsTabEle.click();
            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadingImgXpathInCompetitors);
        }catch(Exception e){
            
        }
    }
    
    //Click on Country Risk Summary tab
    public void clickOnCountryRiskSummaryTab(String tabName)
    {
        try{
            countryRiskSummaryTabEle.click();
            countryRiskIndicatorSecEle.waitUntilPresent();
        }catch(Exception e){
            
        }
    }
    
    //Click on Tier 2 Supplier Summary tab
    public void clickOnTierTwoSuppliersTab(String tabName)
    {
        try{
            tierTwoSupplierTabEle.click();
            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadingImgXpathInTierTwoSupplier);
        }catch(Exception e){
            
        }
    }
    
    //Get Section Names
    public ArrayList<String> getSectionNames(String tabName)
    {
        switch (tabName) {
            case "Profile":
                sectionNames = getSectionNamesFromProfileTab();
                break;
            case "Predictive Scores":
                sectionNames = getPredectiveScoresSectionName();
                break;
            case "Alerts":
                sectionNames = getAlertSectionName();
                break;
            case "Notes":
                sectionNames = getNotesSectionName();
                break;
            case "Documents":
                sectionNames = getDocumentsSectionName();
                break;
            case "History":
                sectionNames = getHistorySectionName();
                break;
            case "Contacts":
                sectionNames = getContactsSectionName();
                break;
            case "Assessments":
                sectionNames = getAssessmentsSectionName();
                break;
            case "Provided Data":
                sectionNames = getProvidedDataSectionName();
                break;
            case "Competitors":
                sectionNames = getCompetitorsSectionName();
                break;
            case "Country Risk Summary":
                sectionNames = getCountryRiskSummarySectionNames();
                break;
            case "Tier 2 Suppliers":
                sectionNames = getTierTwoSuppliersSectionNames();
                break;
            default:
        }
        
        return sectionNames;
    }
    
    //Get the section names from Profile tab
    public ArrayList<String> getSectionNamesFromProfileTab()
    {
        try{
            for(WebElement element:profileSections)
            {
                sectionNamesInProfileTab.add(element.getText());
            }
        }catch(Exception e){
        }
        return sectionNamesInProfileTab;
    }
    
    //Get Predictive scores section name
    public ArrayList<String> getPredectiveScoresSectionName()
    {
        try{
            for(WebElement element:predictiveScoreSectionEle)
            {
                predictiveScoreSectionNames.add(element.getText());
            }
        }catch(Exception e){
         }
        return predictiveScoreSectionNames;
    }
    
    //Get Alert section name
    public ArrayList<String> getAlertSectionName()
    {
        try{
            for(WebElement element:alertSections)
            {
                alertSectionNames.add(element.getText());
            }
        }catch(Exception e){
         }
        return alertSectionNames;
    }
    
    //Get Notes section name
    public ArrayList<String> getNotesSectionName()
    {
        try{
            for(WebElement element:notesSections)
            {
                notesSectionNames.add(element.getText());
            }
        }catch(Exception e){
         }
        return notesSectionNames;
    }
    
    //Post notes
    public void postNotes(String notes)
    {
        try{
            notesTxtAreaEle.type(notes);
            waitFor(2000).milliseconds();
            postNotesEle.waitUntilPresent();
            postNotesEle.click();
            waitFor(5000).milliseconds();
        }catch(Exception e){
         }
    }
    
    //Get Posted Contents
    public ArrayList<String> getPostedContent()
    {
        try{
            for(WebElement element:postedContentEle)
            {
                postedContents.add(element.getText());
            }
        }catch(Exception e){
         }
        return postedContents;
    }
    
    //Get Documents section name
    public ArrayList<String> getDocumentsSectionName()
    {
        try{
            for(WebElement element:documentsSections)
            {
                documentsSectionNames.add(element.getText());
            }
        }catch(Exception e){
         }
        return documentsSectionNames;
    }
    
    //Get History section name
    public ArrayList<String> getHistorySectionName()
    {
        try{
            for(WebElement element:historySectionNamesEle)
            {
                historySectionNames.add(element.getText());
            }
        }catch(Exception e){
         }
        return historySectionNames;
    }
    
    //Get Contacts section name
    public ArrayList<String> getContactsSectionName()
    {
        try{
            for(WebElement element:contactsSectionNamesEle)
            {
                contactsSectionNames.add(element.getText());
            }
        }catch(Exception e){
         }
        return contactsSectionNames;
    }
    
    //Get Assessment section name
    public ArrayList<String> getAssessmentsSectionName()
    {
        try{
            for(WebElement element:assessmentsSectionNamesEle)
            {
                assessmentsSectionNames.add(element.getText());
            }
        }catch(Exception e){
         }
        return assessmentsSectionNames;
    }
    
    public String getButtonNameFromContactsTab()
    {
        addContactBtnEle.waitUntilPresent();
        return addContactBtnEle.getText();
    }
    
    public String getButtonNameFromAssessmentTab()
    {
        return initiateAssessmentBtnEle.getText();
    }
    
    //Get Provided Data section name
    public ArrayList<String> getProvidedDataSectionName()
    {
        try{
            for(WebElement element:providedDataSectionNamesEle)
            {
                providedDataSectionNames.add(element.getText());
            }
        }catch(Exception e){
         }
        return providedDataSectionNames;
    }
    
    //Get Competitors section name
    public ArrayList<String> getCompetitorsSectionName()
    {
        try{
            topCompetitorsEle.waitUntilPresent();
            for(WebElement element:competitorsSectionNamesEle)
            {
                competitorsSectionNames.add(element.getText());
            }
        }catch(Exception e){
         }
        return competitorsSectionNames;
    }
    
    //Get Country Risk Summary section name
    public ArrayList<String> getCountryRiskSummarySectionNames()
    {
        try{
            for(WebElement element:countrySummaryRiskSectionNamesEle)
            {
                countrySummaryRiskSectionNames.add(element.getText());
            }
        }catch(Exception e){
         }
        return countrySummaryRiskSectionNames;
    }
    
    //Get Tier 2 Supplier section name
    public ArrayList<String> getTierTwoSuppliersSectionNames()
    {
        try{
            for(WebElement element:tierTwoSupplierSectionNamesEle)
            {
                tierTwoSupplierSectionNames.add(element.getText());
            }
        }catch(Exception e){
         }
        return tierTwoSupplierSectionNames;
    }
}
