package com.dnb.automation.mmi.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * LoginPage.java - This program contains steps for 1. User launch the URL and
 * application 2. User enters Login details (user-name and password)
 *
 * @author Mathivanan Chinnakutti
 ***********************************************************************************************/


public class MMILoginPage extends PageObject {

	@FindBy(xpath=".//*[@id='loginBox']//*[@id='loginBoxBody']//input[@id='UserName']")
	private WebElementFacade userName;
	
	@FindBy(xpath=".//*[@id='loginBox']//*[@id='loginBoxBody']//input[@id='Password']")
	private WebElementFacade password;
	
	@FindBy(xpath=".//*[@id='loginBox']//*[@id='loginBoxBody']//*[@id='logon']")
	private WebElementFacade loginbutton;
	
	@FindBy(xpath=".//*[@id='LoadStatePanel']/div")
	private WebElementFacade sessionResumeOption;
	
	@FindBy(xpath=".//*[@class='btn-group']//*[@id='LoadState_No']")
	private WebElementFacade sessionResumeNo;
	
	@FindBy(xpath=".//*[@id='loginBox']//*[@id='loginBoxBody']//*[@id='checkBoxContainer']/input[contains(@name, 'termsAndConditions')]")
	private WebElementFacade chktermsandcondition;
	
	@FindBy(xpath = ".//*[@id='main']//*[@class='navbar-header']")
	private WebElementFacade dashboardTitleEle;

	private String dashboardTitleEleXpath = ".//*[@id='main']//*[@class='navbar-header']";
	
	@FindBy(xpath = ".//*[@id='main']//*[@id='dataExBit']//*[@id='dataExplorer']")
    private WebElementFacade dashboarddataexplorer;
	

	@FindBy(xpath = ".//*[@id='navbar']/ul/li[1]/a")
	private WebElementFacade dashBoard;
	
	private String sessionResumeXpath = ".//*[@class='btn-group']";
	private String pageTitleXpath = ".//head/title[contains (.,'Gavurin G-View')]";
	private String fileOptionXpath = ".//*[@id='OpenDataExplorerButton']";
	private String loadOverLayXpath = ".//*[@id='loadingOverlay']";
	
	// User checks the URL and application launching
	
	public void launchApplication(String appURL){
		getDriver().manage().deleteAllCookies();
		getURLtoLaunch(appURL);
	}
	
	public void login(String username,String pwd) throws Exception {		
		enterLogin(username);		
		enterPassword(pwd);
		checktermsandcondition();
		loginButton();
	}
		
	public void getURLtoLaunch(String appURL) {
		getDriver().manage().window().maximize();
		getDriver().get(appURL);
		
	}
	
	// User enters the Login details
	private void enterLogin(String username) throws Exception{
		try{
			/*System.out.println("-----> Before Wait");
			waitFor(30000).milliseconds();
			System.out.println("-----> After Wait");
			//userName.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), userName);	
			System.out.println("-----> Element Found");*/
			if(userName.isPresent()){
				System.out.println("User name = "+username);
				userName.type(username);
			} else {
				System.out.println("FALSE----->");
			}
											
		} catch (Exception e){
			e.printStackTrace();
			
		}
		
	}
	
	private void enterPassword(String pwd) {
		try{
			UIHelper.highlightElement(getDriver(), password);
			password.type(pwd);
		} catch (Exception e){
			
		}
		
	}

	private void checktermsandcondition() throws Exception {
		try{
			
			if (chktermsandcondition.isPresent()){
				UIHelper.highlightElement(getDriver(), chktermsandcondition);
				chktermsandcondition.click();		
			}
		} catch (Exception e){
			
		}
	}
	
	// Click Login Button
	private void loginButton() throws Exception {
		try{
			
			if (loginbutton.isPresent()){
				UIHelper.highlightElement(getDriver(), loginbutton);
				loginbutton.waitUntilPresent();
				loginbutton.waitUntilClickable();
				loginbutton.click();
				waitFor(2000).milliseconds();
				if (loginbutton.isPresent()){					
					loginbutton.click();
				}
				System.out.println("sessionResumeAction -----> IN");
				UIHelper.waitForPageToLoad(getDriver());
				waitFor(2000).milliseconds();
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), sessionResumeXpath);
				if (sessionResumeOption.isPresent()){
					System.out.println("sessionResumeAction ----->PRESENT");
					sessionResumeNo.isPresent();
					sessionResumeNo.click();
				}
				System.out.println("sessionResumeAction -----> OUT");
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), loadOverLayXpath);
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadOverLayXpath);
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), fileOptionXpath);
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), 
                        dashboardTitleEleXpath);
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), 
						dashboardTitleEleXpath);			
				dashboardTitleEle.waitUntilPresent();
				dashboarddataexplorer.waitUntilClickable();
			}
		} catch (Exception e){
			
		}
	}
}