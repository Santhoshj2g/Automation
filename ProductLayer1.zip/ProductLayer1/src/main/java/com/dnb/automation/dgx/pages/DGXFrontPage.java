package com.dnb.automation.dgx.pages;

import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class DGXFrontPage extends PageObject
{

	@FindBy(xpath=".//td/input[@name='UserId']")
	private WebElementFacade userName;
	
	@FindBy(xpath=".//td/input[@name='Password']")
	private WebElementFacade passWord;
	
	@FindBy(xpath=".//*[@id='f1']/table/tbody/tr[1]/td[2]/input")
	private WebElementFacade Language;
	
	@FindBy(xpath=".//*[@id='f1']/table/tbody/tr[2]/td[2]/input")
	private WebElementFacade countryCode;
	
	@FindBy(xpath=".//*[@id='f1']/table/tbody/tr[1]/td[4]/input")
	private WebElementFacade Duns;
	
	@FindBy(xpath=".//*[@id='f1']/table/tbody/tr[3]/td[2]/input")
	private WebElementFacade ProductName;
	
	@FindBy(xpath=".//*[@id='f1']/table/tbody/tr[3]/td[4]/input")
	private WebElementFacade ProductType;
	
	@FindBy(xpath=".//td/input[@name='ForPost']")
	private WebElementFacade formatandPost;




	
	public void launchURL(String applicationURL)throws Exception 
	{

		getURLToLaunch(applicationURL);

		
	}

	private void getURLToLaunch(String applicationURL)
	{

		getDriver().get(applicationURL);
		getDriver().manage().window().maximize();
		UIHelper.waitForPageToLoad(getDriver());
	}

	public void loginApp(String username, String password)throws Exception
	{
		enteruser(username);
		enterpassword(password);
		
	}

	private void enterpassword(String password) 
	{
		try{
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.highlightElement(getDriver(), passWord);
			passWord.type(password);
		}catch(Exception e)
		{
			
		}
		
	}

	private void enteruser(String username) 
	{
		try{
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.highlightElement(getDriver(), userName);
			userName.type(username);
		}catch(Exception e)
		{
			
		}
		
	}

	public void getOrderDetails(String language, String countrycode,
			String duns, String productname, String productType) throws Exception
	{
		enterLanguage(language);
		enterCountryCode(countrycode);
		enterDuns(duns);
		enterProductName(productname);
		enterProcuctType(productType);
	}

	private void enterProcuctType(String productType) 
	{
		try{
			UIHelper.highlightElement(getDriver(), ProductType);
			ProductType.type(productType);
		}catch(Exception e){
			
		}
		
	}

	private void enterProductName(String productname) 
	{
		try{
			UIHelper.highlightElement(getDriver(), ProductName);
			ProductName.type(productname);
		}catch(Exception e){
			
		}
		
	}

	private void enterDuns(String duns) 
	{
		try{
			UIHelper.highlightElement(getDriver(), Duns);
			Duns.type(duns);
		}catch(Exception e){
			
		}
		
	}

	private void enterCountryCode(String countrycode) 
	{
		try{
			UIHelper.highlightElement(getDriver(), countryCode);
			countryCode.type(countrycode);
		}catch(Exception e){
			
		}
		
	}

	private void enterLanguage(String language) 
	{
		try{
			UIHelper.highlightElement(getDriver(), Language);
			Language.type(language);
		}catch(Exception e){
			
		}
		
	}

	public void clickFormatPost()throws Exception
	{
		try{
			UIHelper.highlightElement(getDriver(), formatandPost);
			formatandPost.click();
			UIHelper.waitForPageToLoad(getDriver());
			
		}catch(Exception e){
			
		}

		
	}
	
	
}