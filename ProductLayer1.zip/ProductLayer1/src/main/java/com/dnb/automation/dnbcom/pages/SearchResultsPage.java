package com.dnb.automation.dnbcom.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;
import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * SearchResultsPage.java - Program consists of the following actions 1.
 * Clicking on the button Search 2. Verifying navigation to the Order Completed
 * page
 *
 * @author Kumaran Balasubramaniam
 ***********************************************************************************************/

public class SearchResultsPage extends PageObject {
    // Locators for Quick buy button and Order Completed page element(next page
    // element)

    @FindBy(xpath = "//img[@alt='Quick Buy European Comprehensive Report']/..")
    private WebElementFacade quickBuyECR;

    @FindBy(xpath = "//p[1]/a[contains(.,img[@alt='Company Reports'])]")
    private WebElementFacade CompanyReports;

    @FindBy(xpath = ".//*[@id='submitViewReport3']")
    private WebElementFacade orderCompletedPage;

    // To Accept Alerts

    public void acceptAlert() throws Exception {
        try {
            getDriver().switchTo().alert().accept();
            getDriver().switchTo().alert().accept();
        } catch (Exception e) {
            throw e;
        }
    }

    // To Click the button Quick Buy

    public void clickQuickBuyButton() throws Exception {
        try {
            UIHelper.highlightElement(getDriver(), quickBuyECR);
            quickBuyECR.waitUntilClickable();
            if (quickBuyECR.isPresent()) {
                quickBuyECR.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    // To Click the link CompanyReports

    public void clickCompanyReports() throws Exception {
        try {
            if (CompanyReports.isPresent()) {
                UIHelper.highlightElement(getDriver(), CompanyReports);
                CompanyReports.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    // To wait for the navigation of Order completed page

    public void waitForOrderCompletedPage() throws Exception {
        try {
            orderCompletedPage.waitUntilPresent();
        } catch (Exception e) {
            throw e;
        }
    }
}
