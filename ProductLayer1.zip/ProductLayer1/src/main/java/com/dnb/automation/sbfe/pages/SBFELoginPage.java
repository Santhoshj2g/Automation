package com.dnb.automation.sbfe.pages;

import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

public class SBFELoginPage extends PageObject {
	@FindBy(xpath = "html/body/div[1]/div[2]//div/div[3]/.//*[@id='userForm']/.//*[@id='email']")
	private WebElementFacade UserId;

	@FindBy(xpath = "html/body/div[1]/div[2]//div/div[3]/.//*[@id='userForm']/.//*[@id='pwd']")
	private WebElementFacade Password;

	@FindBy(xpath = "html/body/div[1]/div[2]//div/div[3]/.//*[@id='userForm']/.//*[@id='submitBtn']")
	private WebElementFacade LoginBtn;

	public void launchapplication(String appURL) throws Exception {
		getDriver().manage().deleteAllCookies();
		getURLtoLaunch(appURL);
		getDriver().manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

	}

	public void applicationLogin(String username, String password)
			throws Exception {

		enteruser(username);
		enterpassword(password);
		loginbutton();
	}

	public void getURLtoLaunch(String appURL) throws Exception {
		try {
			getDriver().get(appURL);
			getDriver().manage().window().maximize();
			UIHelper.waitForPageToLoad(getDriver());
		} catch (AssertionError e) {
			e.printStackTrace();
		}

	}

	public void enteruser(String username) {
		UserId.waitUntilEnabled();
		UIHelper.highlightElement(getDriver(), UserId);
		UserId.type(username);

	}

	public void enterpassword(String password) throws Exception {
		try {
			UIHelper.highlightElement(getDriver(), Password);
			Password.type(password);
		} catch (AssertionError e) {
			e.printStackTrace();
		}
	}

	public void loginbutton() throws Exception {
		try {
			if (LoginBtn.isPresent())
				UIHelper.highlightElement(getDriver(), LoginBtn);
			LoginBtn.click();
			UIHelper.waitForPageToLoad(getDriver());
		} catch (AssertionError e) {
			e.printStackTrace();
		}
	}

}