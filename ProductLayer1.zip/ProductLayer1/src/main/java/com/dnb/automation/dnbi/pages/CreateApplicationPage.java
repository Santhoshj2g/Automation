package com.dnb.automation.dnbi.pages;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;
import com.google.common.base.Predicate;
import com.dnb.automation.dnbi.pages.ECFPage;

/**********************************************************************************************
 * CreateApplicationPage.java - This class contains all functionalities of
 * credit limit application Tab
 * 
 * @author Karthick Selvaraj
 * @version 1.0
 ***********************************************************************************************/
public class CreateApplicationPage extends PageObject {
	ECFPage ecfpagemethods;

	@FindBy(xpath = "//div[@id='main']//input[@id='btn_createNewCL']")
	private WebElementFacade createNewCreditLimit;

	@FindBy(xpath = "//*[@id='header_mainApp']//*[@id='primaryNav']//*[contains(text(),'Admin')]")
	private WebElementFacade tabAdmin;

	@FindBy(xpath = "//div[@id='backRight']//input[@value='Done']")
	private WebElementFacade creditLimitDone;

	@FindBy(xpath = "//*[@class='outerDiv']//a[contains(.,'Credit Applications Admin')]")
	private WebElementFacade creditAppLinkEle;

	@FindBy(xpath = "//div[@class='ecf_page']//*[contains(text(),'Define Credit Limit & Terms')]")
	private WebElementFacade defineCreditLimitTerms;

	String adminTab = "//*[@id='header_mainApp']//*[@id='primaryNav']//*[contains(text(),'Admin')]";

	@FindBy(xpath = "//div[@class='widget_crediterms']//input[@name='clmName']")
	private WebElementFacade enterCreditLimitName;

	@FindBy(xpath = "//div[@class='creditterms_box']//input[@id='usa']")
	private WebElementFacade selectCountryUSA;

	@FindBy(xpath = "//div[@class='creditterms_box']//input[@id='allcountries']")
	private WebElementFacade selectAllCountries;

	@FindBy(xpath = "//div[@class='creditterms_box']//select[@id='paymentSelect']")
	private WebElementFacade selectPaymentTermsValue;

	@FindBy(xpath = "//div[@class='creditterms_box']//input[@value='NONE']")
	private WebElementFacade selectCreditLimitMethodNone;

	@FindBy(xpath = "//div[@class='creditterms_box']//input[@value='FIXED']")
	private WebElementFacade selectCreditLimitFixedLimit;

	@FindBy(xpath = "//div[@class='creditterms_box']//input[@value='PERCENTAGE']")
	private WebElementFacade selectCreditLimitPercentage;

	@FindBy(xpath = "//div[@class='creditterms_box']//input[@value='EXPRESSION']")
	private WebElementFacade selectCreditLimitExpression;

	@FindBy(xpath = "//div[@class='widget_crediterms']//div[@class='creditterms_box']//input[@id='CreditLimitM']")
	private WebElementFacade selectCreditLimitMethodologyTable;

	@FindBy(xpath = "//div[@id='main']//div[@id='backRight']//input[@class='btn bold btnPrimary']")
	private WebElementFacade clickDone;

	@FindBy(xpath = "//div[@id='main']//select[@id='viewItems']//option")
	private WebElementFacade viewItems;
	@FindBy(xpath = "//*[@id='pagingBottomContainer']//div[@class='tools']//ul/li/strong[2]")
	private WebElementFacade totalitemcount;

	@FindBy(xpath = "//div[@id='main']//div[@id='pageHead']/div[2]")
	private WebElementFacade CLMTdeleteAssociate;

	@FindBy(xpath = "//div[@id='main']//div[@id='backRight']//input")
	private WebElementFacade CLMTdeleteAssociateDone;

	@FindBy(xpath = "//*[@id='div_viewRulesByGroups']/table/tbody//tr")
	private WebElementFacade deleteCreditList;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='ruleForm']//*[@class='modal_inner_content modal_clm']//*[@id='expressionBox']")
	private WebElementFacade textArea;

	@FindBy(xpath = "//*[@id='div_viewRulesByGroups']//table")
	private WebElementFacade deleteCreditListTable;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@id='ruleForm']//*[@class='modal_buttons']//input[@value='Submit']")
	private WebElementFacade CalsubmitButton;

	@FindBy(xpath = "//*[@id='div_viewRulesByGroups']//table//tbody//tr//td[2]")
	private List<WebElement> deleteCreditList1;

	@FindBy(xpath = "//div[@class='creditterms_box']//input[@id='fixedCredit']")
	private WebElementFacade chooseLimitTxt;

	@FindBy(xpath = "//div[@class='creditterms_box']//input[@class='percernt']")
	private WebElementFacade enterPercent;

	@FindBy(xpath = "//div[@class='creditterms_box']//select[@name='percentageCLMInfoBean.nameAndEntity']")
	private WebElementFacade percentDropDownSelect;

	@FindBy(xpath = "//div[@class='creditterms_box']//div[@class='btnexpression btnexpressionWd']//input[@class='btn']")
	private WebElementFacade buildExpressionBtn;

	@FindBy(xpath = "//body[@class='iframe_modal']//div[@class='modal_buttons']//input[@value='Submit']")
	private WebElementFacade submitExpression;

	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
	private WebElementFacade iFrameEle;

	@FindBy(xpath = "//div[@id='tabs1']//a[@id='ruleTab']")
	private WebElementFacade clickCLMTtable;

	@FindBy(xpath = "//div[@id='terr_viewItems']//select[@id='viewItems']")
	private WebElementFacade CLMTpagination;

	@FindBy(xpath = "//*[@id='div_clm']/table/tbody")
	private WebElementFacade CMLTContent;

	@FindBy(xpath = "//div[@class='modal']//div[@class='modal_content']//div[@class='modal_buttons']//input[@value='Yes']")
	private WebElementFacade CLMTYesButton;

	@FindBy(xpath = "//div[@id='main']//input[@id='btn_createNewCLMT']")
	private WebElementFacade createNewCLMTbtn;

	@FindBy(xpath = "//form[@id='tableForm']//input[@id='tableName']")
	private WebElementFacade CLMTtableName;

	@FindBy(xpath = "//form[@id='tableForm']//input[@id='usa']")
	private WebElementFacade selectCLMTcountryUS;

	@FindBy(xpath = "//form[@id='tableForm']//input[@id='allcountries']")
	private WebElementFacade selectCLMTcountryOther;

	@FindBy(xpath = "//form[@id='tableForm']//select[@id='selectX']")
	private WebElementFacade selectXvariable;

	@FindBy(xpath = "//form[@id='tableForm']//select[@id='selectY']")
	private WebElementFacade selectYvariable;

	@FindBy(xpath = "//form[@id='tableForm']//input[@class='btn chkChild']")
	private WebElementFacade updateTableCLMT;

	@FindBy(xpath = "//form[@id='tableForm']//div[@class='xVariable margin10topBottom']//div[@id='myLayer']//input[contains(@name,'beginRange')]")
	private List<WebElementFacade> xVariableValues;

	@FindBy(xpath = "//form[@id='tableForm']//div[@class='xVariable margin10topBottom']//div[@class='yVariable']//div[@id='clm_custRanges']//div[@id='yourlayer']//input[contains(@name,'beginRange')]")
	private List<WebElementFacade> yVariableValues;

	@FindBy(xpath = "//form[@id='tableForm']//input[@value='Save']")
	private WebElementFacade saveCLMTbtn;
	@FindBy(xpath = "//*[@id='tableAns']//input[@class='clmName'][contains(@name,'min')]")
	private WebElementFacade clm_minlimit;
	@FindBy(xpath = "//*[@id='tableAns']//input[@class='clmName'][contains(@name,'max')]")
	private WebElementFacade clm_maxlimit;
	@FindBy(xpath = "//*[@id='expressionAns']//input[@class='clmName'][contains(@name,'min')]")
	private WebElementFacade clmexp_minlimit;
	@FindBy(xpath = "//*[@id='percentAns']//input[@class='clmName'][contains(@name,'min')]")
	private WebElementFacade percent_min;
	@FindBy(xpath = "//*[@id='percentAns']//input[@class='clmName'][contains(@name,'max')]")
	private WebElementFacade percent_max;
	@FindBy(xpath = "//*[@id='expressionAns']//input[@class='clmName'][contains(@name,'max')]")
	private WebElementFacade clmexp_maxlimit;

	@FindBy(xpath = "//*[@id='page_title']/h2")
	private WebElementFacade pageHeader;
	String percenttype = "//div[@class='creditterms_box']//select[@name='percentageCLMInfoBean.nameAndEntity']";
	String percentvalue = "//div[@class='creditterms_box']//input[@class='percernt']";
	String nameField = "//div[@class='widget_crediterms']//input[@name='clmName']";
	String adminTab1 = "//*[@id='header_mainApp']//*[@id='primaryNav']//*[contains(text(),'Admin')]";
	String creditAppLinkXPath = "//*[@class='outerDiv']//a[contains(.,'Credit Applications Admin')]";
	String defineCredit = "//div[@class='ecf_page']//*[contains(text(),'Define Credit Limit & Terms')]";
	String cLTabelXpath = "//*[@id='div_viewRulesByGroups']//thead";
	String framexpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']";
	String CLMTHeader = "//*[@id='main']//table[@class='results full']//thead";
	String clmmin = "//*[@id='tableAns']//input[@class='clmName'][contains(@name,'min')]";
	String clmmax = "//*[@id='tableAns']//input[@class='clmName'][contains(@name,'max')]";
	String percentmin = "//*[@id='percentAns']//input[@class='clmName'][contains(@name,'min')]";
	String percentmax = "//*[@id='percentAns']//input[@class='clmName'][contains(@name,'max')]";
	private static String clmtTimeStamp;

	private static String creditLimitNameTimeStamp;

	public static String getCreditLimitNameTimeStamp() {
		return creditLimitNameTimeStamp;
	}

	int clDeleteFlag = 0;

	public void clickCreateNewCreditLimitBtn() {

		UIHelper.waitForPageToLoad(getDriver());
		createNewCreditLimit.waitUntilClickable();
		createNewCreditLimit.click();

	}

	public void entertablimit(String maxlimit, String minlimit) {

		clm_minlimit.waitUntilPresent();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), clmmin);
		UIHelper.highlightElement(getDriver(), clm_maxlimit);
		clm_minlimit.sendKeys(minlimit);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), clmmax);
		UIHelper.highlightElement(getDriver(), clm_maxlimit);
		clm_maxlimit.sendKeys(maxlimit);

	}

	public void enterexplimit(String maxlimit, String minlimit) {

		clmexp_minlimit.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), clmexp_maxlimit);
		clmexp_minlimit.sendKeys(minlimit);
		UIHelper.highlightElement(getDriver(), clmexp_maxlimit);
		clmexp_maxlimit.sendKeys(maxlimit);

	}

	public void selectCountry(String creditLimitName, String chooseCountry) {

		UIHelper.waitForPageToLoad(getDriver());
		/*
		 * DateFormat dateFormat = new SimpleDateFormat("MMddHHmmssms"); Date
		 * date = new Date(); creditLimitNameTimeStamp = creditLimitName +
		 * dateFormat.format(date);
		 * enterCreditLimitName.sendKeys(creditLimitNameTimeStamp);
		 */
		enterCreditLimitName.sendKeys(creditLimitName);
		if (chooseCountry.trim().contains("United States & Canada")) {
			selectCountryUSA.click();
		} else {
			selectAllCountries.click();
			// Thread.sleep(5000);
		}

	}

	public void submitCreditLimitApplication(String creditLimitName,
			String chooseCountry, String selectPaymentTerms,
			String selectCreditLimitMethod) {
		try {
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), nameField);
			/*
			 * DateFormat dateFormat = new SimpleDateFormat("MMddHHmmssms");
			 * Date date = new Date(); creditLimitNameTimeStamp =
			 * creditLimitName + dateFormat.format(date);
			 * enterCreditLimitName.sendKeys(creditLimitNameTimeStamp);
			 */
			enterCreditLimitName.sendKeys(creditLimitName);

			// Choose countries
			if (chooseCountry.contains("United States & Canada")) {
				UIHelper.highlightElement(getDriver(), selectCountryUSA);
				selectCountryUSA.click();
			} else {
				UIHelper.highlightElement(getDriver(), selectAllCountries);
				selectAllCountries.click();
			}

			// Select Payment Terms
			UIHelper.highlightElement(getDriver(), selectPaymentTermsValue);
			selectPaymentTermsValue.selectByVisibleText(selectPaymentTerms);

			// Select the method for determining the recommended credit limit
			if (selectCreditLimitMethod
					.contains("Do not set a recommended credit limit")) {
				UIHelper.highlightElement(getDriver(),
						selectCreditLimitMethodNone);
				selectCreditLimitMethodNone.click();
				Thread.sleep(3000);
			} else if (selectCreditLimitMethod.contains("Fixed Limit")) {
				UIHelper.highlightElement(getDriver(),
						selectCreditLimitFixedLimit);
				selectCreditLimitFixedLimit.click();
				Thread.sleep(3000);
			} else if (selectCreditLimitMethod
					.contains("Percentage Calculation")) {
				UIHelper.highlightElement(getDriver(),
						selectCreditLimitPercentage);
				selectCreditLimitPercentage.click();
				Thread.sleep(3000);
			} else if (selectCreditLimitMethod.contains("Create an Expression")) {
				UIHelper.highlightElement(getDriver(),
						selectCreditLimitExpression);
				selectCreditLimitExpression.click();
				Thread.sleep(3000);
			} else {
				UIHelper.highlightElement(getDriver(),
						selectCreditLimitMethodologyTable);
				selectCreditLimitMethodologyTable.click();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void chooseLimit(String chooseLimitValue) {

		chooseLimitTxt.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), chooseLimitTxt);
		chooseLimitTxt.sendKeys(chooseLimitValue);

	}

	public void percentageCalc(String percentage, String percentageDropDown) {

		enterPercent.waitUntilPresent();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), percentvalue);
		enterPercent.sendKeys(percentage);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), percenttype);
		percentDropDownSelect.selectByVisibleText(percentageDropDown);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), percentmax);
		percent_max.sendKeys("20000");
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), percentmin);
		percent_max.sendKeys("200");

	}

	public void clickBuildExpression() {

		buildExpressionBtn.waitUntilClickable();
		buildExpressionBtn.click();
		waitFor(2000).milliseconds();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
		getDriver().switchTo().frame(iFrameEle);

	}

	public void submitExpression(String expression) {
		textArea.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), textArea);
		textArea.clear();
		textArea.sendKeys(expression);
		UIHelper.highlightElement(getDriver(), CalsubmitButton);
		CalsubmitButton.click();
		getDriver().switchTo().defaultContent();

	}

	public void viewitempage() {
		try{
		totalitemcount.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), totalitemcount);
		String tcost = totalitemcount.getText();
		int totalitem = Integer.parseInt(tcost);
		if (totalitem > 20) {
			UIHelper.highlightElement(getDriver(), viewItems);

			viewItems.selectByVisibleText("50");
		} else if (totalitem > 50) {
			UIHelper.highlightElement(getDriver(), viewItems);

			viewItems.selectByVisibleText("100");
		} else if (totalitem > 100) {
			UIHelper.highlightElement(getDriver(), viewItems);

			viewItems.selectByVisibleText("250");
			waitFor(5000).milliseconds();
		} else if (totalitem > 250){
			UIHelper.highlightElement(getDriver(), viewItems);
		viewItems.selectByVisibleText("500");
		waitFor(5000).milliseconds();
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deleteCreditLimitName(String creditLimitName) {
		try {
			waitFor(5000).milliseconds();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), cLTabelXpath);
			List<WebElement> getCreditNamesList = getDriver()
					.findElements(
							By.xpath("//*[@id='div_viewRulesByGroups']//table//tbody//tr//td[2]//span"));
			for (WebElement creditlimitelement : getCreditNamesList) {
				if (creditlimitelement.getText().equals(creditLimitName)) {
					UIHelper.highlightElement(getDriver(), creditlimitelement);
					String creditNameDeleteBtnXpath = "//*[@id='div_viewRulesByGroups']//table//tbody//tr//td[2]//span[normalize-space(text())='"
							+ creditLimitName
							+ "']//ancestor::td[1]//following-sibling::td//a[contains(.,'Delete')]";
					WebElementFacade deleteCredit = find(By
							.xpath(creditNameDeleteBtnXpath));
					deleteCredit.click();
					waitFor(1000).milliseconds();
					UIHelper.processalert(getDriver());
					waitFor(3000).milliseconds();
					UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
							CLMTHeader);
					/*
					 * if(CLMTdeleteAssociateDone.isPresent()) {
					 * CLMTdeleteAssociateDone.click(); clDeleteFlag=2;
					 * UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					 * cLTabelXpath); }
					 */
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		/* return clDeleteFlag; */
	}

	public void deleteCreditLimitMethodologyPage(
			String creditLimitMethodologyTable) {
		try {
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.highlightElement(getDriver(), clickCLMTtable);
			clickCLMTtable.click();
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.highlightElement(getDriver(), CLMTpagination);
			CLMTpagination.selectByVisibleText("100");
			// UIHelper.waitForVisibilityOfEleByXpath(getDriver(), CLMTHeader);
			Thread.sleep(3000);
			UIHelper.highlightElement(getDriver(), CMLTContent);
			String deleteXpath = "//*[@id='div_clm']/table/tbody/tr[contains(.,'"
					+ creditLimitMethodologyTable
					+ "')]//following-sibling::td//a[contains(.,'Delete')]";
			List<WebElement> tableNames = getDriver().findElements(
					By.xpath("//*[@id='div_clm']/table/tbody/tr/td[1]"));
			for (WebElement tableName : tableNames) {
				if (tableName.getText().contains(creditLimitMethodologyTable)) {
					Thread.sleep(3000);
					WebElement deleteCLMT = getDriver().findElement(
							By.xpath(deleteXpath));
					UIHelper.highlightElement(getDriver(), deleteCLMT);
					Thread.sleep(3000);
					deleteCLMT.click();
					CLMTYesButton.click();
					UIHelper.waitForPageToLoad(getDriver());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void createNewCLMT(String creditLimitMethodologyTable,
			String chooseCountries, String xVariable, String yVariable) {
		try {
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.highlightElement(getDriver(), createNewCLMTbtn);
			createNewCLMTbtn.click();
			UIHelper.waitForPageToLoad(getDriver());

			UIHelper.highlightElement(getDriver(), CLMTtableName);
			CLMTtableName.sendKeys(creditLimitMethodologyTable);
			Thread.sleep(3000);

			if (chooseCountries.contains("United States & Canada")) {
				selectCLMTcountryUS.click();
				Thread.sleep(3000);

			} else
				selectCLMTcountryOther.click();
			Thread.sleep(3000);
			DateFormat dateFormat = new SimpleDateFormat("MMddHHmmssms");
			Date date = new Date();
			clmtTimeStamp = creditLimitMethodologyTable
					+ dateFormat.format(date);
			UIHelper.highlightElement(getDriver(), CLMTtableName);
			CLMTtableName.sendKeys(clmtTimeStamp);

			Thread.sleep(3000);

			UIHelper.highlightElement(getDriver(), selectXvariable);
			selectXvariable.selectByVisibleText(xVariable);
			Thread.sleep(3000);
			int xVariableSize = xVariableValues.size();
			System.out.println("Size of x-Variable is:****************"
					+ xVariableSize);

			UIHelper.highlightElement(getDriver(), selectYvariable);
			selectYvariable.selectByVisibleText(yVariable);
			Thread.sleep(3000);
			int yVariableSize = yVariableValues.size();
			System.out.println("Size of y-Variable is:****************"
					+ yVariableSize);

			Thread.sleep(3000);
			UIHelper.highlightElement(getDriver(), updateTableCLMT);
			updateTableCLMT.click();
			Thread.sleep(4000);

			for (int i = 0; i < xVariableSize; i++) {
				for (int j = 0; j < yVariableSize; j++) {
					String a = "//form[@id='tableForm']//div[@class='xVariable margin10topBottom']//div[@class='clmresults']//table[@id='CLM_maintable']//tbody//tr//td//input[@id='creditLimit*"
							+ i + "|" + j + "']";

					getDriver()
							.findElement(
									By.xpath("//form[@id='tableForm']//div[@class='xVariable margin10topBottom']//div[@class='clmresults']//table[@id='CLM_maintable']//tbody//tr//td//input[@id='creditLimit*"
											+ i + "|" + j + "']")).sendKeys(
									"2000" + i + j);

				}
			}

			UIHelper.highlightElement(getDriver(), saveCLMTbtn);
			saveCLMTbtn.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickDone() {
		try {
			System.out
					.println("Into done method:****************************************");
			Thread.sleep(5000);
			clickDone.waitUntilClickable();
			clickDone.click();
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void edit_CreditLimit_Name(String creditLimitName) throws Exception {
		try {
			waitFor(5000).milliseconds();
			UIHelper.highlightElement(getDriver(), viewItems);
			viewItems.selectByVisibleText("50");
			waitFor(10000).milliseconds();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), cLTabelXpath);
			Actions action = new Actions(getDriver());
			String creditNameXpath = "//*[@id='div_viewRulesByGroups']//table//tbody//tr//td[2]//span[contains(.,'"
					+ creditLimitName + "')]";
			String creditNameEditBtnXpath = "//*[@id='div_viewRulesByGroups']//table//tbody//tr//td[2]//span[contains(.,'"
					+ creditLimitName
					+ "')]//ancestor::td[1]//following-sibling::td//a[contains(.,'Edit')]";
			List<WebElement> getCreditNamesList = getDriver()
					.findElements(
							By.xpath("//*[@id='div_viewRulesByGroups']//table//tbody//tr//td[2]//span"));
			for (WebElement CLName : getCreditNamesList) {
				action.moveToElement(CLName).build().perform();
				waitFor(500).milliseconds();
				if (CLName.getText().contains(creditLimitName)) {
					UIHelper.highlightElement(getDriver(), CLName);
					System.out
							.println("inside if condition -------------------");
					WebElementFacade creditName = find(By
							.xpath(creditNameXpath));
					UIHelper.highlightElement(getDriver(), creditName);
					WebElementFacade EditCredit = find(By
							.xpath(creditNameEditBtnXpath));
					EditCredit.click();
					UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
							nameField);
					break;

				}
			}
		} catch (StaleElementReferenceException e) {
			e.printStackTrace();
		}

	}

	public void change_Payment_Terms(String pterms) {
		selectPaymentTermsValue.isVisible();
		UIHelper.highlightElement(getDriver(), selectPaymentTermsValue);
		selectPaymentTermsValue.selectByVisibleText(pterms);
	}

	public void view_CreditLimit_Name(String creditLimitName) throws Exception {
		try {
			waitFor(5000).milliseconds();
			UIHelper.highlightElement(getDriver(), viewItems);
			viewItems.selectByVisibleText("50");
			waitFor(10000).milliseconds();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), cLTabelXpath);
			Actions action = new Actions(getDriver());
			String creditNameXpath = "//*[@id='div_viewRulesByGroups']//table//tbody//tr//td[2]//span[contains(.,'"
					+ creditLimitName + "')]";
			String creditNameViewBtnXpath = "//*[@id='div_viewRulesByGroups']//table//tbody//tr//td[2]//span[contains(.,'"
					+ creditLimitName
					+ "')]//ancestor::td[1]//following-sibling::td//a[contains(.,'View')]";
			List<WebElement> getCreditNamesList = getDriver()
					.findElements(
							By.xpath("//*[@id='div_viewRulesByGroups']//table//tbody//tr//td[2]//span"));
			for (WebElement CLName : getCreditNamesList) {

				action.moveToElement(CLName).build().perform();
				waitFor(500).milliseconds();
				if (CLName.getText().contains(creditLimitName)) {
					UIHelper.highlightElement(getDriver(), CLName);
					System.out
							.println("inside if condition -------------------");
					WebElementFacade creditName = find(By
							.xpath(creditNameXpath));
					UIHelper.highlightElement(getDriver(), creditName);
					WebElementFacade ViewCredit = find(By
							.xpath(creditNameViewBtnXpath));
					ViewCredit.click();
					waitFor(3000).milliseconds();
					ecfpagemethods.switch_to_Required_Window();
					break;

				}
			}
		} catch (StaleElementReferenceException e) {
			e.printStackTrace();
		}

	}

	public boolean verify_new_Widnow() {
		try {
			pageHeader.isVisible();
			UIHelper.highlightElement(getDriver(), pageHeader);
			ecfpagemethods.close_the_Required_Window();
			return true;
		} catch (StaleElementReferenceException e) {
			return false;
		}
	}

}