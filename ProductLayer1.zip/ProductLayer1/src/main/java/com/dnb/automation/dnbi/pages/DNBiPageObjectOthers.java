package com.dnb.automation.dnbi.pages;

import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;


public class DNBiPageObjectOthers extends PageObject {
	
	@FindBy(xpath = "//*[@id='main']//*[@class='customize_block']//a[contains(.,'Customize')]")
	private WebElementFacade customizeLink;
	@FindBy(xpath = "//*[@id='main']//*[@id='pp_side_icon']//li//a")
	private WebElementFacade customizeLink1;
	@FindBy(xpath = "//*[@class='customize_popup']//p//span//select[@class='customize_sel']")
	private WebElementFacade sortTheTableByList;
	@FindBy(xpath = "//*[@class='customize_popup']//p//span//select[@class='select_order']")
	private WebElementFacade sortOrderList;
	@FindBy(xpath = "//*[@class='customize_popup']//input[@value='Submit'][@type='Button']")
	private WebElementFacade cSubmitBtn;
	@FindBy(xpath = "//*[@id='dd_inboxR']//table//thead")
	private WebElementFacade resultList;
	@FindBy(xpath = "//*[@id='main']//input[@value='Show Filter Options'][@type='button']")
	private WebElementFacade showFilterOptionsBtn;
	@FindBy(xpath = "//*[@id='filter_cover']//*[@value='Select Filter']")
	private WebElementFacade selectFilterElement;
	@FindBy(xpath = "//*[@id='filter_cover']//input[@value='Apply Filter']")
	private WebElementFacade applyFilterBtn;
	@FindBy(xpath = "//*[@id='dd_inboxR']//table//tbody//tr//td[2]")
	private List<WebElementFacade> accountResutlsList;
	@FindBy(xpath = "//*[@id='main']//*[@class='viewMoreBtn']//*[@value='View Details' or 'View More'][@type='button']")
	private WebElementFacade viewMoreBtn;
	@FindBy(xpath = "//iframe[@name='__modal_iframe_target']")
    private WebElementFacade iFrameElement;
	@FindBy(xpath = "//*[@id='seld_cus']//select//option")
	private List <WebElementFacade> selectedFieldsList;
	@FindBy(xpath = "//*[@class='modal_buttons']//input[@value='Cancel']")
	private WebElementFacade iframecancelBtn;
	@FindBy(xpath = "//*[@id='fields_cus']//*[@id='pool']//option")
	private List <WebElementFacade> availableFieldsList;
	@FindBy(xpath = "//*[@id='sel_cus']//a[contains(@href,'copySelectedOptions')]//img")
	private WebElementFacade fieldsAddArrowBtn;
	@FindBy(xpath = "//*[@class='modal_buttons']//input[@value='Update List']")
	private WebElementFacade updateListBtn;
	@FindBy(xpath = "//*[@id='main']//table//thead//th")
	private List <WebElementFacade> tableHeaderList;
	@FindBy(xpath = "//*[@id='main']//table//tbody//tr[1]//td[1]//input[@type='checkbox']")
	private WebElementFacade firstRowAccNoRecord;
	@FindBy(xpath = "//*[@id='main']//table//tbody//tr[1]//td[2]//a")
	private WebElementFacade firstRowAccNo;
	@FindBy(xpath = "//*[@id='main']//*[@value='Add to Folder']")
	private WebElementFacade addToFolderBtn;
	@FindBy(xpath = "//*[@id='ecfaddfolder']//*[@id='to_folder_id']")
	private WebElementFacade selectFolder;
	@FindBy(xpath = "//*[@id='addToFolderForm']//*[@id='submit_ecf']")
	private WebElementFacade cFSubmitButton;
	@FindBy(xpath = "//*[@id='main']//*[@value='Delete']")
	private WebElementFacade deleteBtn;
	@FindBy(xpath = "//*[@class='modal_buttons']//*[@value='Delete']")
	private WebElementFacade modelDeleteBtn;
	@FindBy(xpath = "//*[@id='main']//table//tbody//tr[1]//td[2]//a")
	private List<WebElementFacade> accountListinFolder;
	@FindBy(xpath = "//*[@id='viewItems']")
	private WebElementFacade viewItemsList;
	@FindBy(xpath = "//*[@id='main']//table//thead")
	private WebElementFacade accTablethead;
	@FindBy(xpath = "//div[@id='agingArea']/div[@class='widget']/div[@class='clear']/table[@class='clear']/tbody/tr/td[1]")
	private WebElementFacade agingSummaryList;
	@FindBy(xpath = "//*[@id='agingArea']//*[@class='clear']//input[@value='View Trend Summary']")
	 private WebElementFacade clickviewtrendbtn;
	@FindBy(xpath = "//*[@id='main']//*[@class='ageing_graphposition']//tbody//form[@name='agingTrendForm']//select")
	 private WebElementFacade viewtrendselectoption;
	@FindBy(xpath = "//*[@class='ageing_graphposition']//*[@id='per']//table[@class='tableborder']")
	 private WebElementFacade trendpercenttable;
	@FindBy(xpath ="//div[@id='agingArea']/div[@class='widget']/div[@class='clear']/table[@class='clear']/tbody/tr/td[2]")
	private WebElementFacade agingGraph;
	@FindBy(xpath = "//div[@id='agingArea']//div[@class='clear']/table//input[@value='View Trend Summary']")
	private WebElementFacade trendSummaryButton;
	@FindBy(xpath = "//div[@id='dol']/table[@class='tableborder' ]//tr//td[contains(text(),'Total Outstanding')]")
	private WebElementFacade totaloutstanding;
	@FindBy(xpath = "//div[@id='dol']/table[@class='tableborder' ]//tr//td[contains(text(),'Past Due Amount')]")
	private WebElementFacade pastDueAmount;
	@FindBy(xpath = ".//*[@id='Document_Widget']//input[@value='Add Document']")
	private WebElementFacade addDocumentBtn;
	@FindBy(xpath = "//*[@id='page_title']/h2")
	private WebElementFacade documentsPageHeader;
	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
	private WebElementFacade iFrameEle;
	@FindBy(xpath = "//*[@id='modalCont']//a[contains(.,'Custom Documents')]")
	private WebElementFacade coustomDocumentsTab;
	@FindBy(xpath = "//*[@id='modalCont']//*[@id='visibilityCustom']")
	private WebElementFacade visibilityCombobox;
	@FindBy(xpath = "//*[@class='modal_buttons']//*[@value='Submit']")
	private WebElementFacade modalSubmitBtn;
	@FindBy(xpath = "//*[@class='modal_inner_content']//*[@id='pdf']")
	private WebElementFacade modalPdfRadioBtn;
	@FindBy(xpath = "//*[@class='modal_buttons']//*[@value='View']")
	private WebElementFacade modalViewBtn;
	@FindBy(xpath = "//*[@class='modal_buttons']//*[@value='Cancel']")
	private WebElementFacade modalCancelBtn;
	@FindBy(xpath = "//*[@id='main']//table//tbody/tr//td[1]")
	private List<WebElementFacade> dTemplateList;
	@FindBy(xpath = ".//*[@id='main']/p/input[@value='Create Template']")
	private WebElementFacade createTempalteBtn;
	@FindBy(xpath = "//*[@id='main']//p[contains(.,'Template Name')]/input")
	private WebElementFacade templateNameTextBox;
	@FindBy(xpath = ".//*[@id='main']//input[@value='Create']")
	private WebElementFacade templateCreateBtn;
	@FindBy(xpath = "//*[contains(@class,'mce-tinymce')]//*[contains(@class,'mce-container-body')]//*[contains(@class,'mce-edit-area')]//iframe[@id='elm1_ifr']")
	private WebElementFacade templateVeriableAreaIframe;
	@FindBy(xpath = ".//*[@id='submitbtn' and @value='Save']")
	private WebElementFacade templateSaveBtn;
	@FindBy(xpath = "//form[@name='AEWSRequestForm']//select")
	private List<WebElementFacade> aewsReq;
	@FindBy(xpath ="//*[@class='outerDiv']//span//*[@class='Submitbtn'][@type='button']")
	public WebElementFacade submitBtn;
	@FindBy(xpath = "//*[@id='backRight']/input")
    private WebElementFacade orderInternationalNextBtnEle;
	String sortTheTableByListXpath = "//*[@class='customize_popup']//p//span//select[@class='customize_sel']";
	String accountResultsTableXpath = "//*[@id='dd_inboxR']//table//thead";
	String selectFilterXpath = "//*[@id='filter_cover']//*[@value='Select Filter']";
	String allAccPageHeaderXpath = "//*[@id='page_title_links']//h2";
	String framexpath="//iframe[@name='__modal_iframe_target']";
	private String folderTable = "//*[@id='main']//table//thead";
	String accountViewMoreResultsTableXpath = "//*[@id='main']//table//tbody//tr//td[3]";
	String pageTitle = "//*[@class='outerDiv']//*[@id='pageHead' or 'page_title']//h2";
	String foldersTableXpath = "//*[@id='main']//*[@id='tab1']//form//table//tbody";
	String agingpopupmain = "//*[@id='main']";
	String TemplateTableXpath="//*[@id='main']//table//tbody";
	String TemplateTableXpath1="//*[@id='main']//table//tbody/tr";
	String pageHeaderXpath="//*[@id='page_title_links']/h2";
	String documentpageHeaderXpath="//*[@id='page_title']/h2";
	String templateVeriableAreaIframeXpath="//*[contains(@class,'mce-tinymce')]//*[contains(@class,'mce-container-body')]//*[contains(@class,'mce-edit-area')]//iframe[@id='elm1_ifr']";
	String ecfSubHeader="//*[@id='NoteList']//h3";
	String ecfDocumentTableXpath="//*[@id='Document_Widget']//table[@class='results full tab_border']/tbody";
	String applicationECfHeader="//*[@class='ecf_header']//*[@id='entity_header']//*[@id='businessName']";
	String CSSectionHearder = "//*[@id='compTitle']//*[contains(.,'Company Summary')]";
	private static String numberText;
	public static String  parentWindow;
	public static String  handle;
	WebElementFacade txtArea;
	private static String countrypdfContent="";
	public static String getCountrypdfContent() {
		return countrypdfContent;
	}
	public static String getNumberText() {
		return numberText;
	}
	public void click_Customize_Icon() {
		try {
			customizeLink.waitUntilClickable();
			customizeLink.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					sortTheTableByListXpath);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void select_Sort_Options(String Option, String Order) {

		try {
			sortTheTableByList.isVisible();
			sortTheTableByList.selectByVisibleText(Option);
			sortOrderList.selectByVisibleText(Order);
			cSubmitBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					accountResultsTableXpath);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public boolean verify_Results_has_Sorted_As_Per_Date() {
		try {
			resultList.isVisible();
			return true;
		} catch (Exception e) {
			return false;
		}
		
	}
	public void select_Filter_For_Sort(String FilterName) {
		try {
			showFilterOptionsBtn.waitUntilClickable();
			showFilterOptionsBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					selectFilterXpath);
			selectFilterElement.click();
			waitFor(1000).milliseconds();
			String filterNameExpath = "//*[@id='filter_sel_options']//li[.='"
					+ FilterName + "']";
			WebElementFacade filterNameEle = find(By.xpath(filterNameExpath));
			filterNameEle.click();
			waitFor(1000).milliseconds();
			applyFilterBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					accountResultsTableXpath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public boolean verify_Results_Has_Filtered(String BusinessName,
			String Country, String State) {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				accountResultsTableXpath);
		int resultsFlag = 0;
		for (WebElementFacade list : accountResutlsList) {
			UIHelper.highlightElement(getDriver(), list);
			if (list.getText().contains(BusinessName)
					&& list.getText().contains(Country)
					&& list.getText().contains(State)) {
				resultsFlag = 1;
				break;
			} else {
				resultsFlag = 2;
			}
		}
		return true;

	}
	public void click_View_More_Btn() {

		try {
			viewMoreBtn.isVisible();
			viewMoreBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					allAccPageHeaderXpath);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void click_Cusomize_Link(){

		UIHelper.highlightElement(getDriver(), customizeLink1);
		customizeLink1.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
		getDriver().switchTo().frame(iFrameElement);

}
	public void select_Option_From_Available_list(String Optionname){
		int j=0;
		for(WebElementFacade option:selectedFieldsList){
			String itemName=option.getText().trim();
			if(itemName.equalsIgnoreCase(Optionname.trim())){
				UIHelper.highlightElement(getDriver(), iframecancelBtn);
				iframecancelBtn.click();
				j=1;
				break;
			}
		}
		if(j!=1){
			for(WebElementFacade field : availableFieldsList){
				String itemName1=field.getText().trim();
				
				if(itemName1.equalsIgnoreCase(Optionname.trim())){
					field.click();
					UIHelper.highlightElement(getDriver(), fieldsAddArrowBtn);
					fieldsAddArrowBtn.click();
					waitFor(5000).milliseconds();
					for(WebElementFacade option:selectedFieldsList){
						String itemName=option.getText().trim();
						if(itemName.equalsIgnoreCase(Optionname.trim())){
							break;
						}
					}
					UIHelper.highlightElement(getDriver(), updateListBtn);
					updateListBtn.click();
					break;
				}
			}
			
		}
		getDriver().switchTo().defaultContent();
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), folderTable);
		
	}
	
	
	public boolean verify_Option_Has_Added(String Optionname){
		int flag=0;
		for(WebElementFacade option:tableHeaderList){
			String itemName=option.getText().trim();
			if(itemName.contains(Optionname.trim())){
				UIHelper.highlightElement(getDriver(), option);
				flag=1;
				break;
			}
		}
		
		if(flag==1){
			return true;
		}else{
			return false;
		}
	}
	public void select_First_Acc_Recod() {

		firstRowAccNoRecord.isVisible();
		numberText = firstRowAccNo.getText().trim();
		// String[] accFlag1=firstRowAccNo.getText().split("#DNBi-");

		// numberText=accFlag1[1].trim();
		firstRowAccNoRecord.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				accountViewMoreResultsTableXpath);
	}
	public void click_Add_To_Folder_Btn() {

		addToFolderBtn.isVisible();
		addToFolderBtn.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
		getDriver().switchTo().frame(iFrameElement);

	}
	public void select_A_Folder_And_click_Submit_Btn(String FolderName) {
		try {
			UIHelper.highlightElement(getDriver(), selectFolder);
			selectFolder.isVisible();
			selectFolder.selectByVisibleText(FolderName);
			cFSubmitButton.click();
			getDriver().switchTo().defaultContent();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					accountViewMoreResultsTableXpath);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void click_Delete_Btn_In_Frame() {
		try {
			deleteBtn.isVisible();
			deleteBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
			getDriver().switchTo().frame(iFrameElement);
			modelDeleteBtn.click();
			waitFor(2000).milliseconds();
			UIHelper.processalert(getDriver());
			waitFor(5000).milliseconds();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void click_Delete_Btn() {

		deleteBtn.isVisible();
		deleteBtn.click();
		UIHelper.processalert(getDriver());
		waitFor(8000).milliseconds();
		UIHelper.processalert(getDriver());
		waitFor(5000).milliseconds();
	}
	public String verify_Record_Under_Folder(String FolderName, String Number) {
		String accFlag = "";
		UIHelper.waitForPageToLoad(getDriver());
		String folderNameXpath = "//*[@id='main']//*[@id='tab1']//form//table//tbody//tr//td[2]//a[contains(.,'"
				+ FolderName + "')]";
		List<WebElement> foldername = getDriver()
				.findElements(
						By.xpath("//*[@id='main']//*[@id='tab1']//form//table//tbody//tr//td[2]"));
		for (WebElement option : foldername) {
			UIHelper.mouseOveranElement(getDriver(), option);
			waitFor(300).milliseconds();
			if (option.getText().contains(FolderName)) {
				WebElementFacade foldersName = find(By.xpath(folderNameXpath));
				foldersName.click();
				waitFor(1000).milliseconds();
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						accountViewMoreResultsTableXpath);
				for (WebElementFacade accountNo : accountListinFolder) {
					UIHelper.mouseOveranElement(getDriver(), accountNo);
					waitFor(1000).milliseconds();
					// String[] accFlag1=accountNo.getText().split("#DNBi-");
					accFlag = accountNo.getText();
					break;

				}
				break;
			}
		}
		return accFlag;
	}
	public void click_Header_Tab(String headerName) {

		String headerXpath = "//*[@id='header_mainApp']//*[@id='primaryNav']//*[contains(text(),'"+headerName+"')]";
		WebElementFacade headerElement = find(By.xpath(headerXpath));
		UIHelper.highlightElement(getDriver(), headerElement);
		headerElement.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), pageTitle);

	}
	public void click_Folders_Tab(String tab) {
		String tabXpath = "//*[@id='main']//*[contains(text(),'"+tab+"')]";
		WebElementFacade tabElement = find(By.xpath(tabXpath));
		UIHelper.highlightElement(getDriver(), tabElement);
		tabElement.click();
		waitFor(5000).milliseconds();
	}
	public void select_ItemsCount(String ItemsCount) {
		try {
			viewItemsList.isVisible();
			viewItemsList.selectByVisibleText(ItemsCount);
			waitFor(15000).milliseconds();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					foldersTableXpath);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public boolean verify_Acc_has_Deleted() {
		try {
			accTablethead.isVisible();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	public boolean isAgingSummaryListDisplayed() {
		// TODO Auto-generated method stub
		UIHelper.highlightElement(getDriver(), agingSummaryList);
		if(agingSummaryList.isDisplayed()){
	    return true;
	    
		}
		return false;
	}
	public boolean agingdataverifypage(String agingintable, String aginginviewtrend){
		try{
			int a=1;
		WebElement agingvariable = (getDriver().findElement(By.xpath("//*[@id='agingArea']//*[@class='results ']//td[normalize-space(text())='"+agingintable+"']")));
		((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", agingvariable);
		String valueofvariable=getDriver().findElement(By.xpath("//*[@id='agingArea']//*[@class='results ']//td[normalize-space(text())='"+agingintable+"']//following-sibling::td[1]")).getText().trim();
		String percentofvariable=getDriver().findElement(By.xpath("//*[@id='agingArea']//*[@class='results ']//td[normalize-space(text())='"+agingintable+"']//following-sibling::td[2]")).getText().trim();
		UIHelper.highlightElement(getDriver(), clickviewtrendbtn);
		clickviewtrendbtn.click();
		switch_to_Required_Window();
        UIHelper.waitForVisibilityOfEleByXpath(getDriver(),agingpopupmain);
		String valueintrendview=getDriver().findElement(By.xpath("//*[@class='ageing_graphposition']//*[@class='tableborder']//td[normalize-space(text())='"+aginginviewtrend+"']//following-sibling::td[1]")).getText().trim();
		UIHelper.highlightElement(getDriver(), viewtrendselectoption);
		viewtrendselectoption.selectByVisibleText("Percent");
		waitFor(trendpercenttable);
		String percentintrendview=getDriver().findElement(By.xpath("//*[@class='ageing_graphposition']//*[@class='tableborder']//td[normalize-space(text())='"+aginginviewtrend+"']//following-sibling::td[1]")).getText().trim();
			if(valueofvariable.contains(valueintrendview) && percentofvariable.contains(percentintrendview)){
				a=2;
			}
			close_the_Required_Window();
		if(a==2)
			{
			return true;	
			}
		
		}
		
		catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	public void switch_to_Required_Window(){
		Set<String> AllWindowHandles = getDriver().getWindowHandles(); 
		System.out.println("window count------   "+AllWindowHandles.size());
		if(AllWindowHandles.size() > 0){
			String window1 = (String) AllWindowHandles.toArray()[1];
			getDriver().switchTo().window(window1);
			
		}
		
	   
	}
	
	public void close_the_Required_Window(){
		Set<String> AllWindowHandles = getDriver().getWindowHandles(); 
		System.out.println("window count------   "+AllWindowHandles.size());
		if(AllWindowHandles.size() > 0){
			String window1 = (String) AllWindowHandles.toArray()[0];
			getDriver().close();
			getDriver().switchTo().window(window1);
			
		}
		}
	public void ModifyUserPassword(String appURL, String aewsText) throws Exception {
		switch_to_Required_Window();
			getDriver().manage().window().maximize();
	        getDriver().manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	        getDriver().get(appURL);
	        /*handle = getDriver().getWindowHandle();
			 if(handle!=parentWindow){*/
				  for (WebElementFacade listVariable : aewsReq) {
			listVariable.selectByVisibleText("Modify password (MODIFYUSERPSWDTRNRQ)");
        WebElementFacade aewsReqText = (find(By.xpath("//*[@id='txtAewsRequest']")));
        aewsReqText.clear();
        aewsReqText.sendKeys(aewsText);
        WebElementFacade aewsReqSubmit = (find(By.xpath("//input[contains(@value,'Send Request')]")));
        aewsReqSubmit.click();
        close_the_Required_Window();
			 }
			 getDriver().switchTo().window(parentWindow);
    }
	public boolean isAgingGraphDisplayed() {
		// TODO Auto-generated method stub
		
		UIHelper.highlightElement(getDriver(), agingGraph);
		if(agingGraph.isDisplayed()){
	    return true;
	    
		}
		return false;
	}
	public void clickonAgingTrendSummaryButton() {
		parentWindow= getDriver().getWindowHandle();//Return a string of alphanumeric window handle
		
		UIHelper.highlightElement(getDriver(), trendSummaryButton);
		trendSummaryButton.click();
		UIHelper.waitForPageToLoad(getDriver());
		for (String handle : getDriver().getWindowHandles()) {
			 if(handle!=parentWindow){
				  getDriver().switchTo().window(handle);
				  try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 }
		}
	}
	public boolean isAgingtotaloutstandingDisplayed() {
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), totaloutstanding);
		if(totaloutstanding.isDisplayed()){
//			getDriver().close();
//			getDriver().switchTo().window(parentWindow);
		    return true;
		    
			}
			return false;
	}
	public boolean isAgingPastDueAmountDisplayed() {
		// TODO Auto-generated method stub
//		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), pastDueAmount);	
		if(pastDueAmount.isDisplayed()){
//			getDriver().close();
			getDriver().switchTo().window(parentWindow);
		    return true;
		    
			}
			return false;
			
			
	}
	public boolean verifyDcoumentPageIsDispalyed(){
		try{
			documentsPageHeader.isVisible();
			UIHelper.highlightElement(getDriver(), documentsPageHeader);
			return true;
		}catch(Exception e){
			return false;
		}
	}
public void click_On_Create_Template_Button(String TemplateName){
		
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), TemplateTableXpath);
		String templateDeleteXath="//*[@id='main']//table//tbody/tr//td[contains(.,'"+TemplateName+"')]//following-sibling::td/a[contains(.,'Delete')]";
		for(WebElementFacade Template :dTemplateList){
			UIHelper.mouseOveranElement(getDriver(), Template);
			if(Template.getText().contains(TemplateName)){
				WebElementFacade templateDeleteBtn=find(By.xpath(templateDeleteXath));
				UIHelper.highlightElement(getDriver(), templateDeleteBtn);
				templateDeleteBtn.click();
				waitFor(1000).milliseconds();
				UIHelper.processalert(getDriver());
				waitFor(2000).milliseconds();
				UIHelper.waitForPageToLoad(getDriver());
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), TemplateTableXpath1);
				break;
			}
			
		}
		UIHelper.highlightElement(getDriver(), createTempalteBtn);
		createTempalteBtn.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), pageHeaderXpath);
		
	}
public void enterTemplateName(String TemplateName, String EntityType){
	String entityTypeXpath="//*[@id='main']//p/input[@value='"+EntityType+"']";
	templateNameTextBox.type(TemplateName);
	WebElementFacade entityType=find(By.xpath(entityTypeXpath));
	entityType.click();
	UIHelper.mouseOveranElement(getDriver(), templateCreateBtn);
	templateCreateBtn.click();
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), pageHeaderXpath);
	
}
public void template_Veriables(String TemplateVeriables){
	
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), templateVeriableAreaIframeXpath);
	getDriver().switchTo().frame(templateVeriableAreaIframe);
	//UIHelper.highlightElement(getDriver(), templateVeriableAreaIframe);
	txtArea = find(By.id("tinymce"));
	txtArea.clear();
	if(TemplateVeriables.contains(",")){
		String[] veriables=TemplateVeriables.split(",");
		for(String name:veriables ){
			txtArea.sendKeys(name);
			txtArea.sendKeys(Keys.ENTER);
		}
	}else{
		txtArea.type(TemplateVeriables);
	}
	
	getDriver().switchTo().defaultContent();
}

public void click_Temp_Save_Btn(){
	UIHelper.highlightElement(getDriver(), templateSaveBtn);
	templateSaveBtn.click();
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), documentpageHeaderXpath);
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), TemplateTableXpath);
}

public boolean verify_Template_Has_Created(String TemplateName){
	int templateFlag=0;
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), TemplateTableXpath);
	for(WebElementFacade Template :dTemplateList){

		if(Template.getText().contains(TemplateName)){
			UIHelper.mouseOveranElement(getDriver(), Template);
			templateFlag=1;
			break;
		}
		
	}
	if(templateFlag==1){
		return true;
	}else{
		return false;
	}
	
}
public void click_On_Existing_Template_Button (String TemplateName){
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), TemplateTableXpath);
	String xpEle = ".//*[@id='main']//table[@class='results full']//a[@class='navlinktable'][contains(text(),'"+TemplateName+"')]";
	WebElementFacade webEle = findBy(xpEle);
	webEle.click();
			UIHelper.waitForPageToLoad(getDriver());
		}

public void click_Ecf_Left_SideTab(){
	String TabNameXpath=".//*[@id='ecf_toc_main']//li/a[contains(.,'Notes & Documents')]";
	WebElementFacade tabNameElement=find(By.xpath(TabNameXpath));
	waitFor(3000).milliseconds();
	tabNameElement.waitUntilClickable();
	tabNameElement.click();
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), ecfSubHeader);
	waitFor(2000).milliseconds();
	
}

public void select_required_Document(String TemplateName,String VisibilityOption){
	String accountTemplateXpath="//*[@id='modalCont']//ul/li[contains(.,'"+TemplateName+"')]//input";
	UIHelper.mouseOveranElement(getDriver(), addDocumentBtn);
	addDocumentBtn.click();
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
	getDriver().switchTo().frame(iFrameEle);
	UIHelper.mouseOveranElement(getDriver(), coustomDocumentsTab);
	coustomDocumentsTab.click();
	waitFor(1000).milliseconds();
	WebElementFacade accountTemplateEle=find(By.xpath(accountTemplateXpath));
	accountTemplateEle.click();
	UIHelper.mouseOveranElement(getDriver(), visibilityCombobox);
	waitFor(1500).milliseconds();
	System.out.println("visibility opton name-------------------"+VisibilityOption);
	visibilityCombobox.selectByVisibleText(VisibilityOption.trim());
	modalSubmitBtn.click();
	waitFor(3000).milliseconds();
	getDriver().switchTo().defaultContent();
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), ecfDocumentTableXpath);
}

public void click_View_Link_For_Document(String DocumentName){
	
	String docViewLinkXpath="//*[@id='Document_Widget']//table//tbody//td[contains(.,'"+DocumentName+"')]//following-sibling::td/a[contains(.,'View')]";
	WebElementFacade docViewLinkEle=find(By.xpath(docViewLinkXpath));
	docViewLinkEle.click();
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
	getDriver().switchTo().frame(iFrameEle);
	UIHelper.mouseOveranElement(getDriver(), modalPdfRadioBtn);
	modalPdfRadioBtn.click();
	waitFor(2000).milliseconds();
	UIHelper.mouseOveranElement(getDriver(), modalViewBtn);
	modalViewBtn.click();
	waitFor(1500).milliseconds();
	getDriver().switchTo().defaultContent();
	switch_to_Required_Window();
	waitFor(12000).milliseconds();
	UIHelper.waitForPageToLoad(getDriver());
	close_the_Required_Window();
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), ecfSubHeader);
	if(iFrameEle.isVisible()){
		getDriver().switchTo().frame(iFrameEle);
		UIHelper.mouseOveranElement(getDriver(), modalCancelBtn);
		modalCancelBtn.click();
		waitFor(1000).milliseconds();
		getDriver().switchTo().defaultContent();
	}
	
}
public void submitbtnclick() {
	if(submitBtn.isPresent()){			
		submitBtn.click();
	System.out.println("submit button has clicked-------------------------------");
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), applicationECfHeader);
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), CSSectionHearder);
	if (orderInternationalNextBtnEle.isPresent()) {
        orderInternationalNextBtnEle.click();
        UIHelper.waitForPageToLoad(getDriver());
    }
	}
}
}
