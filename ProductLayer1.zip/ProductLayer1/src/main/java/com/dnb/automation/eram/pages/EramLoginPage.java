package com.dnb.automation.eram.pages;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import com.google.common.base.Predicate;
import com.dnb.automation.eram.pages.AccountPage;


public class EramLoginPage extends PageObject {
	 public static final int HIGHLIGHTERINT = 5;
	 
	 public static final int MINPOLLINGTIME = 100;

	  @FindBy(xpath = "//*/div[contains(@class,'x-form-item-body')]//*/div/input[@name='username']")
	  private WebElementFacade unameBox;
	
	  @FindBy(xpath = "//*/div[contains(@class,'x-form-item-body')]//*/div/input[@name='pwd']")
	  private WebElementFacade pwordBox;
	  
	  @FindBy(xpath = "//*[contains(@class,'x-form-item-body')]//*/div/input[@name='database']")
	  private WebElementFacade dataBaseBox;
	  
	  @FindBy(xpath = "//a[@id='sign']//span[@id='sign-btnWrap']")
	  private WebElementFacade loginButton;
	  
	  @FindBy(xpath = "//span[contains(@id,'DASHBOARD-btnInnerEl')]//div[1]")
	  private WebElementFacade homePage;
	  
	  @FindBy(xpath = "//*[@id='iagreeid']")
	  private WebElementFacade iAgreeBtn;
	  
	  String loginBtnXpath="//a[@id='sign']//span[@id='sign-btnWrap']";
	  String eRamHomePageXpath="//span[contains(@id,'DASHBOARD-btnInnerEl')]";
	 	 
	  
	public void eRAMloginURL(String appURL) throws Exception {
	  getDriver().manage().deleteAllCookies();
	  getDriver().manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	  getURLtoTEst(appURL);
	}

	public void getURLtoTEst(String appURL) throws Exception {
	        getDriver().get(appURL);
	}  
		  
    
	public void eRAMloginFields(String userName, String password) {
		
		 try {
			 AccountPage.waitForVisibilityOfeRAMElements(getDriver(), loginBtnXpath);
	        	unameBox.type(userName.toString().trim());
	        	pwordBox.type(password.toString().trim());
	        	
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	     }	
		
	
	public void eRAMloginDBField(String databaseType) {

		 try {
			 	String databaseNameXpath="//*[@id='boundlist-1013-listWrap']//li[contains(.,'"+databaseType+"')]";
			 	AccountPage.highlightElement(getDriver(), dataBaseBox);
	        	dataBaseBox.click();
	        	waitFor(500).milliseconds();
	        	WebElementFacade databaseName=find(By.xpath(databaseNameXpath));
	        	databaseName.click();
	        	AccountPage.highlightElement(getDriver(), loginButton);
	        	loginButton.click();
	        	getDriver().manage().window().maximize();
	        	AccountPage.waitForVisibilityOfeRAMElements(getDriver(), eRamHomePageXpath);
	        } catch (Exception E) {
	           
	        }
	    }
	
   

	public String dashBoardPage() {
		String homePageValue=null;
		
			AccountPage.highlightElement(getDriver(), homePage);
              homePageValue = homePage.getText().trim();
              if(iAgreeBtn.isVisible()){
            	  AccountPage.highlightElement(getDriver(), iAgreeBtn);
            	  iAgreeBtn.click();
            	  AccountPage.waitForVisibilityOfeRAMElements(getDriver(), eRamHomePageXpath);
              }
              System.out.println("Home page diaplyed=======================================" + homePageValue );
       
       return homePageValue;
   }

		
}