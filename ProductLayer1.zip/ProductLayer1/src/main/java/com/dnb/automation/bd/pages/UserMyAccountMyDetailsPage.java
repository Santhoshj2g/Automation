package com.dnb.automation.bd.pages;

import java.util.Calendar;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

/******************************************************************************************************
 * Description : AdminDashboardPage class contains locators and methods for Admin Dashboard page
 * 
 *******************************************************************************************************/

public class UserMyAccountMyDetailsPage extends PageObject {
	
	@FindBy(xpath = "//*/form[@id='update-userdetails-form']/div/p/select[@name='strPrefix']")
    private WebElementFacade prefixDrpdwn;	
	
	@FindBy(xpath = "//*[@name='firstName']")
	 private WebElementFacade firstName1;	
	
	@FindBy(xpath = "//*[@name='lastName']")
	 private WebElementFacade lastName1;	

	 @FindBy(xpath = "//*[@name='countryCode']")
	 private WebElementFacade countryCode1;	
	 
	 @FindBy(xpath = "//*[@name='areaCode']")
	 private WebElementFacade areaCode1;	 
	 
	 @FindBy(xpath = "//*[@name='phoneNumber']")
	 private WebElementFacade phoneNo1;	
	 
	 @FindBy(xpath = "//*[@name='extension']")
	 private WebElementFacade phoneExtn1;	
	 
	 @FindBy(xpath = "//*[@name='country']")
	 private WebElementFacade country;
	 
	 @FindBy(xpath = "//*[@name='websiteUrl']")
	 private WebElementFacade websiteUrl;	
	 
	 @FindBy(xpath = "//*/div/a/span[contains(text(),'Save')]")
	 private WebElementFacade saveBtn;	 
	 
	 @FindBy(xpath = "//*/div[@id='interactive']/div/div/p[contains(text(),'Your Information has been saved successfully')]")
	 private WebElementFacade msg;	
	
	String loadicon="//*/div[@class='loadmask-msg']";	 
	
	@FindBy(xpath = "//*[@id='adminDashboard']")
    private WebElementFacade tabMyDashboard;
	
	@FindBy(xpath = "//*/a[@id='mydetails']")
    private WebElementFacade myDetailsTab;	
	
	@FindBy(xpath = "//tbody[@id='connectionPflist']/div[@class='loadmask-msg']/div")	
	private WebElementFacade imgLoading;
	

	
	 /***********************************************************************************
     * Function: Select a value from Prefix dropdown
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/  
	public void PrefixDropdown(String Prefix)
	{
		if (prefixDrpdwn.isPresent())
		{
			prefixDrpdwn.selectByVisibleText(Prefix);			
		}
	}	
	 /***********************************************************************************
     * Function: Update a value in FirstName field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/  
	public void updateFirstName(String Firstname)
	{
		firstName1.click();			
		firstName1.type(Firstname);
	}	
	/***********************************************************************************
     * Function: Update a value in LastName field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public void updateLastName(String Lastname)
	{
		lastName1.click();		
		lastName1.type(Lastname);
	}
	/***********************************************************************************
     * Function: Update a value in CountryCode field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public void updateCountryCode(String Countrycode)
	{
		countryCode1.click();		
		countryCode1.type(Countrycode);
	}
	/***********************************************************************************
     * Function: Update a value in Areacode field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public void updateAreaCode(String Areacode)
	{
		areaCode1.click();
		areaCode1.type(Areacode);		
	}	
	/***********************************************************************************
     * Function: Update a value in Phone Number field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public void updatePhoneNumber(String Phoneno)
	{
		phoneNo1.click();		
		phoneNo1.type(Phoneno);		
	}
	/***********************************************************************************
     * Function: Update a value in Extension field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public void updateExtension(String Extension)
	{
		phoneExtn1.click();
		phoneExtn1.type(Extension);
	}
	/***********************************************************************************
     * Function: Update a value in CountryDDL field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public void updateCountryDDL(String CountryDdl)
	{
		country.click();
		country.selectByVisibleText(CountryDdl);
	}	
	/***********************************************************************************
     * Function: Update a value in Company Website field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public void updateWebsiteUrl(String CompanyWebsite)
	{
		websiteUrl.click();
		websiteUrl.type(CompanyWebsite);
	}
	/***********************************************************************************
     * Function: To click the Save button
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public void clickSaveBtn()
	{
		saveBtn.click();
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadicon);
	}
	/***********************************************************************************
     * Function: To capture the success Message
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public void clickMsg()
	{		
		msg.click();
		UIHelper.waitForPageToLoad(getDriver());		
		String msg1=msg.getText();
		System.out.println(msg1);
		if (msg1.contains("Your Information has been saved successfully"))
		{
			System.out.println("msg dispalyed successfully");
		}
	}
	/***********************************************************************************
     * Function: Verify the updated value in Prefix field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyPrefix(String Prefix)
	{		
		String uprefix=prefixDrpdwn.getSelectedVisibleTextValue();
		System.out.println(uprefix);
		System.out.println(Prefix);
		if (uprefix.equals(Prefix))
		{
			return true;
		}else
		{
			return false;
		}		
	}	
	/***********************************************************************************
     * Function: Verify the updated value in Firstname in field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyFirstName(String FirstName)
	{
		firstName1.click();
		String ufirstname=firstName1.getTextValue();
		System.out.println(FirstName);
		System.out.println(ufirstname);
		if (ufirstname.equals(FirstName))
		{
			return true;
		}else
		{
			return false;
		}		
	}
	/***********************************************************************************
     * Function: Verify the updated value in Last Name field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyLastName(String LastName)
	{
		lastName1.click();
		String ulastname=lastName1.getTextValue();
		System.out.println(ulastname);
		System.out.println(LastName);
		if (ulastname.equals(LastName))
		{
			return true;
		}else
		{
			return false;
		}		
	}
	/***********************************************************************************
     * Function: Verify the updated value in Country Code field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyCountryCode(String CountryCode)
	{
		countryCode1.click();
		String ucountrycode=countryCode1.getTextValue();
		System.out.println(ucountrycode);
		System.out.println(CountryCode);
		if (ucountrycode.equals(CountryCode))
		{
			return true;
		}else
		{
			return false;
		}				
	}
	/***********************************************************************************
     * Function: Verify the updated value in AreaCode field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyAreaCode(String AreaCode)
	{
		areaCode1.click();
		String uareacode=areaCode1.getTextValue();
		System.out.println(uareacode);
		System.out.println(AreaCode);
		if (uareacode.equals(AreaCode))
		{
			return true;
		}else
		{
			return false;
		}			
	}
	/***********************************************************************************
     * Function: Verify the updated value in Phone Number field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyPhoneNo(String PhoneNo)
	{
		phoneNo1.click();
		String uphoneno=phoneNo1.getTextValue();
		System.out.println(uphoneno);
		System.out.println(PhoneNo);
		if (uphoneno.equals(PhoneNo))
		{
			return true;
		}else
		{
			return false;
		}	
	}	
	/***********************************************************************************
     * Function: Verify the updated value in Extension field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyExtension(String Extension)
		{
			String uextension=phoneExtn1.getAttribute("value");
			System.out.println(uextension);
			System.out.println(Extension);
			if (uextension.equals(Extension))
			{
				return true;
			}else
			{
				return false;
			}			
		}
	/***********************************************************************************
     * Function: Verify the updated value in CountryDDL field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifycountryddl(String CountryDdl)
		{
			String ucountryddl=country.getSelectedVisibleTextValue();
			System.out.println(ucountryddl);
			System.out.println(CountryDdl);
			if (ucountryddl.equals(CountryDdl))
			{
				return true;
			}else
			{
				return false;
			}			
		}
	/***********************************************************************************
     * Function: Verify the updated value in Company Website field
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifycompanywebsiteurl(String Companywebsite)
		{
			String ucmpnywebsiteurl=websiteUrl.getTextValue();
			System.out.println(ucmpnywebsiteurl);
			System.out.println(Companywebsite);
			if (ucmpnywebsiteurl.equals(Companywebsite))
			{
				return true;
			}else
			{
				return false;
			}
		}	
	/***********************************************************************************
     * Function: To get the value of Firstname field in Profile edit page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public String getFirstName()
	{
		if(firstName1.isPresent())
		{
			return firstName1.getTextValue().trim();
		}else
		{
			return null;
		}
	}
	/***********************************************************************************
     * Function: To get the value of Prefix field in Profile edit page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public String getPrefix()
	{
		if(prefixDrpdwn.isPresent())
		{
			return prefixDrpdwn.getSelectedValue();
		}else
		{
			return null;
		}
	}
	/***********************************************************************************
     * Function: To get the value of Lastname field in Profile edit page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	
	public String getLastName()
	{
		if(lastName1.isPresent())
		{
			return lastName1.getTextValue();
		}else
		{
			return null;
		}
	}
	/***********************************************************************************
     * Function: To get the value of CountryCode field in Profile edit page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public String getCountryCode()
	{
		if(countryCode1.isPresent())
		{
			return countryCode1.getTextValue();
		}else
		{
			return null;
		}
	}
	/***********************************************************************************
     * Function: To get the value of AreaCode field in Profile edit page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public String getAreaCode()
	{
		if(areaCode1.isPresent())
		{
			return areaCode1.getTextValue();
		}else
		{
			return null;
		}
	}
	/***********************************************************************************
     * Function: To get the value of PhoneNumber field in Profile edit page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public String getPhoneNum()
	{
		if(phoneNo1.isPresent())
		{
			return phoneNo1.getTextValue();
		}else
		{
			return null;
		}
	}
	/***********************************************************************************
     * Function: To get the value of Extension field in Profile edit page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public String getExtension()
	{
		if(phoneExtn1.isPresent())
		{
			return phoneExtn1.getTextValue();
		}else
		{
			return null;
		}
	}
	/***********************************************************************************
     * Function: To get the value of CountryDDL field in Profile edit page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public String getCountryDDL()
	{
		if(country.isPresent())
		{
			return country.getValue();
		}else
		{
			return null;
		}
	}
	/***********************************************************************************
     * Function: To get the value of Company Website field in Profile edit page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public String getCompanyWebsite()
	{
		if(websiteUrl.isPresent())
		{
			return websiteUrl.getTextValue();
		}else
		{
			return null;
		}
	}

/***********************************************************************************
	* Function: Select My Details tab 
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public boolean selectMyDetailsTab()
	   {    	
	   	UIHelper.waitForPageToLoad(getDriver());
	   	myDetailsTab.click();
	   	UIHelper.waitForPageToLoad(getDriver());
	   	UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadicon);
	   	return myDetailsTab.getAttribute("class") != null;
	  	}  	
}
