package com.dnb.automation.DBAI.model;


import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class LoadPropertiesSpain {
    @SuppressWarnings("resource")
    public Properties LoadPropertiesSpain() {
        Properties commentryprop = new Properties();
        InputStream is = null;

        // First try loading from the current directory
        try {
            File f = new File("C:\\Users\\418415\\Test\\ProductLayer1\\src\\test\\resources\\AppTestData\\DBAI\\CommentryMappingSpain.properties");
            is = new FileInputStream(f);
        } catch (Exception e) {
            e.printStackTrace();
            is = null;
        }

        try {
            if (is == null) {
                // Try loading from classpath
                is = getClass().getResourceAsStream("C:\\Users\\418415\\Test\\ProductLayer1\\src\\test\\resources\\AppTestData\\DBAI\\CommentryMappingSpain.properties");
//		            ClassLoader classLoader = getClass().getClassLoader();
//		            File configurationFile = new File(classLoader.getResource(CONFIGURATION_FILE_NAME).getFile());
            }

            // Try loading properties from the file (if found)
            commentryprop.load(is);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return commentryprop;
    }

}


