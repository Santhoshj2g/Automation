package com.dnb.automation.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;

/**********************************************************************************************
 * ExcelParser.java - This class Parse Excel file into Java Objects.
 * 
 * @author Duvvuru Naveen
 * @version 1.0
 ***********************************************************************************************/

public class ExcelUtil {

    // Write data into Excel sheet
    public void writeDataIntoExcelSheet(String filePath, int sheetPosition,
            int rowVal, int columnVal, String cellValue) throws Exception {
        FileInputStream fsIP = new FileInputStream(new File(filePath)); // Read
                                                                        // the
                                                                        // spreadsheet
                                                                        // that
                                                                        // needs
                                                                        // to be
                                                                        // updated
        HSSFWorkbook wb = new HSSFWorkbook(fsIP); // Access the workbook

        HSSFSheet worksheet = wb.getSheetAt(sheetPosition); // Access the
                                                            // worksheet, so
                                                            // that we can
                                                            // update / modify
                                                            // it.
        Cell cell = null; // declare a Cell object
        cell = worksheet.getRow(rowVal).getCell(columnVal); // Access the second
                                                            // cell in second
                                                            // row to update the
                                                            // value
        cell.setCellValue(cellValue); // Get current cell value value and
                                      // overwrite the value

        fsIP.close(); // Close the InputStream
        FileOutputStream output_file = new FileOutputStream(new File(filePath)); // Open
                                                                                 // FileOutputStream
                                                                                 // to
                                                                                 // write
                                                                                 // updates
        wb.write(output_file); // write changes
        output_file.close();
    }
}
