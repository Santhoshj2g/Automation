package com.dnb.automation.sba.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.support.FindBy;



/**********************************************************************************************
 * LoginPage.java - This program contains steps for 1. User launch the URL and
 * application 2. User enters Login details (user-name and password)
 *
 * @author Joseph Dennison
 ***********************************************************************************************/

public class SRMLoginPage extends PageObject {
    @FindBy(xpath = "//*[@id='loginForm']/ul/li[3]/input[contains(@class,'uname border-full-radius')]")
    private WebElementFacade userName;

    @FindBy(xpath = "//*[@id='loginForm']/ul/li[5]/input[contains(@class,'uname border-full-radius')]")
    private WebElementFacade password;

    @FindBy(xpath = "//*[@id='loginForm']/ul/li[6]/input[contains(@class,'login new-custom-report border-full-radius')]")
    private WebElementFacade loginbutton;

    @FindBy(xpath = ".//*[@id='wrapper']//*[@class='container']//*[@class='dashboard-container']//*[@class='page-heading']/h1")
    private WebElementFacade dashboardTitleEle;

    //private String dashboardTitleEleXpath = ".//*[@id='wrapper']//*[@class='container']//*[@class='dashboard-container']//*[@class='page-heading']/h1";

    @FindBy(xpath = "//*[@id='wrapper_header']//*[@class='header-tabs-container clearFix']//ul//*[@id='desktopMenu']/a")
    private WebElementFacade dashBoard;

    // User checks the URL and application launching

    public void launchApplication(String appURL) {
        getDriver().manage().deleteAllCookies();
        getURLtoLaunch(appURL);

    }

    public void login(String username, String pwd) throws Exception {
        enterLogin(username);
        enterpassword(pwd);
        loginButton();
    }

    public void getURLtoLaunch(String appURL) {
        getDriver().manage().window().maximize();
        getDriver().get(appURL);
    }

    // User enters the Login details
    public void enterLogin(String username) throws Exception {
        try {
            /*UIHelper.highlightElement(getDriver(), userName);*/
            userName.type(username);
        } catch (AssertionError e) {
            // e.printStackTrace();
        }
    }

    public void enterpassword(String pwd) throws Exception {
        try {
           /* UIHelper.highlightElement(getDriver(), password);*/
            password.type(pwd);
        } catch (AssertionError e) {
            // e.printStackTrace();
        }
    }

    public void loginButton() throws Exception {
        try {

            if (loginbutton.isPresent()) {
              /*  UIHelper.highlightElement(getDriver(), loginbutton);*/
                loginbutton.click();
          /*      UIHelper.waitForPageToLoad(getDriver());
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
                        dashboardTitleEleXpath);
                dashboardTitleEle.waitUntilPresent();*/
            }
        } catch (AssertionError e) {
             e.printStackTrace();
        }
    }
    
    public String getSRMDashboardPageTitle() {
        //dashBoard.waitUntilPresent();
        return dashboardTitleEle.getText();
    }

}
