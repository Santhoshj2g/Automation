package com.dnb.automation.sba.pages;

import java.util.Map;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.sba.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class SuppFamilyWithCommoditiesPage extends PageObject{

	int totalDuns;
	/*Supplier Family WebElements*/
	
	@FindBy(xpath = "//*[@id='supplierFamily']/a")
	private WebElementFacade supplierFamily;
	
	@FindBy(xpath ="//*[@id='ui-id-7']")
	private WebElementFacade analysisSubTab;
	
	@FindBy(xpath ="//*[@id='analysisFilter-button']/span[2]")
	private WebElementFacade filter;
	
	@FindBy(xpath ="//ul[@id='analysisFilter-menu']/li[3]/a")
	private WebElementFacade SourcingCategory;
	
	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[2]/span/span[1]")
	private WebElementFacade parentItem;
	
	@FindBy(xpath ="//*[@id='SfAnalysisTotalCount']")
	private WebElementFacade totalRecords;
	
	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[2]")
	private WebElementFacade dunsNumber;
	
	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[3]")
	private WebElementFacade spend;
	
	@FindBy(xpath ="//*[@id='supplierAnalysis-ManageBtn']")
	private WebElementFacade manageCols;
	
	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[1]/span/a")
	private WebElementFacade cmpnyProfile_AF;
	
	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[2]/span/a")
	private WebElementFacade corpLinkage_AF;
	
	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[6]/span/a")
	private WebElementFacade socialResp_AF;
	
	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[7]/span/a")
	private WebElementFacade spend_AF;
	
	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[5]/span/a")
	private WebElementFacade risk_AF;
	
	@FindBy(xpath ="//*[@id='manageColumn-addbtnAnalysis']")
	private WebElementFacade manageColAddBtn;
	
	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[1]/ul/li[1]/span/a")
	private WebElementFacade childItem;
	
	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[1]/ul/li[2]/span/a")
	private WebElementFacade agriculturalSupplies;
	
	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[1]/span/span[1]")
	private WebElementFacade parentNode;
	
	@FindBy(xpath ="//*[@id='100']")
	private WebElementFacade itemsPerPage;
	
	@FindBy(xpath ="//*[@id='dynaPagHolder']/div[1]/div/a[2]")
	private WebElementFacade nextPage;
	
	@FindBy(xpath ="//*[@id='block_jump_valSF']")
	private WebElementFacade pageNum;
	
	@FindBy(xpath ="//*[@id='supplierAnalysis-DownloadListBtn']")
	private WebElementFacade export;

	@FindBy(xpath ="//*[@id='gridExcel']")
	private WebElementFacade exportToExcel;

	public String gridTableLoading ="//*[@class='analysisRightTab']//*[@class='innercontainer']//*[@class='gridViewTableLoading']/img[@src='static/images/ajax-loader.gif']";
	
	/*Commodities WebElements*/
	
	int totalDunsOfCommodities;
	
	@FindBy(xpath ="//*[@id='commodities']/a")
	private WebElementFacade CommoditiesTab;
	
	@FindBy(xpath ="//*[@id='ui-id-8']")
	private WebElementFacade analysisTabOfCommodities;
	
	@FindBy(xpath ="//*[@id='analysisFilter-button']/span[2]")
	private WebElementFacade filterOfCommodities;
	
	@FindBy(xpath ="//a[contains(text(),'Sourcing Category')]")
	private WebElementFacade SourcingCategoryOfCo;
	
	@FindBy(xpath ="//a[contains(text(),'AGRICULTURE')]")
	private WebElementFacade agricultureOfCommodities;
	
	@FindBy(xpath ="//*[@id='CoAnalysisTotalCount']")
	private WebElementFacade totalRecordsOfCommodities;
	
	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[2]")
	private WebElementFacade dunsOfCommodities;
	
	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[3]")
	private WebElementFacade spendOfCommodities;
	
	@FindBy(xpath ="//img[@id='manageColumn-addBtn']")
	private WebElementFacade manageColAddBtnCommodities;
	
	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[1]/span/span[1]")
	private WebElementFacade parentNodeOfCo;
	
	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[1]/ul/li[1]/span/a")
	private WebElementFacade agriculturalServicesOfCo;
	
	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[1]/ul/li[2]/span/a")
	private WebElementFacade agriculturalSuppliesOfCo;
	
	@FindBy(xpath ="//*[@id='manageColumn-applyBtn']")
	private WebElementFacade applyBtn;
	
	@FindBy(xpath ="//*[@id='dynaPagHoldercom']/div[1]/div/a[2]")
	private WebElementFacade nextPageOfCom;
	
	@FindBy(xpath ="//*[@id='block_jump_valCOM']")
	private WebElementFacade pageNumCommodities;
	
	@FindBy(xpath ="(//a[@id='100'])[2]")
	private WebElementFacade itemsPerPageOfCom;
	
	@FindBy(xpath ="//*[@id='block_jumpCOM']")
	private WebElementFacade goButtonOfCommodities;
	
	@FindBy(xpath ="//a[@href='analysisDashboard']")
	private WebElementFacade analysisTab;

	public boolean isInSBADashboardPage()
	{
		return UIHelper.isElementDisplayed(analysisTab);
	}
	
	public void chooseSourcingCategory(){
		UIHelper.highlightElement(getDriver(), filter);
		UIHelper.clickAnElement(filter);
		UIHelper.highlightElement(getDriver(), SourcingCategory);
		UIHelper.clickAnElement(SourcingCategory);
	}

	public int clickOnParentItem(){
		UIHelper.switchToTab(getDriver(),"supplierFamily");
		String pNodeSF="(//*[@id='analysisTreeView']//*[@class='dynatree-container']//*[@class='dynatree-expander'])[1]";
		int i=1;
		UIHelper.clickAnElement(getDriver(), pNodeSF);
		return i;
	}
	
	public boolean isTotalRecDisplayed()
	{
		return UIHelper.isElementDisplayed(totalRecords);
	}
	
	public int getTotalRecords(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDuns=UIHelper.getTotalRecords(totalRecords);
		System.out.println("getTotalRecords :"+totalDuns);
		return UIHelper.getTotalRecords(totalRecords);
	}

	public Map<String,String> getSpendValue(){
		UIHelper.switchToTab(getDriver(),"supplierFamily");
		String preXpath="//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.clickAnElement(itemsPerPage);
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDuns, nextPage);
	}
	
	public Map<String, String> getSpendValueOfChild(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDuns=UIHelper.getTotalRecords(totalRecords);
		UIHelper.clickAnElement(itemsPerPage);
		return getSpendAfterAddcols();
	}

	public Map<String,String> getSpendAfterAddcols(){
		String preXpath="//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDuns, nextPage);
	}

	/*Commodities page*/

	public void clickOnCommodities(){
		String URL=getDriver().getCurrentUrl();
		UIHelper.openInNewTab(getDriver(),URL);
		UIHelper.clickAnElement(CommoditiesTab);
	}

	public void clickOnAnalysisTabOfCommodities(){
		UIHelper.clickAnElement(analysisTabOfCommodities);
	}

	public void chooseSourcingCategoryInCo(){
		UIHelper.clickAnElement(filterOfCommodities);
		UIHelper.clickAnElement(SourcingCategoryOfCo);
	}

	public void clickOnParentItemInCommodities(int pNodeNum){
		UIHelper.switchToTab(getDriver(),"notSF");
		String pNode="(//*[@id='analysisTreeView']//*[@class='dynatree-container']//*[@class='dynatree-expander'])[1]";
		UIHelper.clickAnElement(getDriver(), pNode);
	}

	public int getTotalRecordsOfCommodities(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDunsOfCommodities=UIHelper.getTotalRecords(totalRecordsOfCommodities);
		System.out.println("getTotalRecordsOfBU :"+totalDunsOfCommodities);
		return UIHelper.getTotalRecords(totalRecordsOfCommodities);
	}
	
	public Map<String,String> getSpendValueOfCommodities(){
		UIHelper.switchToTab(getDriver(),"notSF");
		String preXpath="//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.clickAnElement(itemsPerPageOfCom);
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDunsOfCommodities, nextPageOfCom);
	}

	public Map<String, String> getSpendValueOfChildInCommodities(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDunsOfCommodities=UIHelper.getTotalRecords(totalRecordsOfCommodities);
		UIHelper.clickAnElement(itemsPerPageOfCom);
		return getSpendAfterAddColsOfCommodities();
	}

	public void clickOnManageColsOfCommodities(){
		UIHelper.switchToTab(getDriver(),"notSF");
		UIHelper.gotoFirstPage(pageNumCommodities,goButtonOfCommodities);
		UIHelper.clickAnElement(manageCols);
	}

	public void addColsAndClickApplyOfCommodities(){
		if(cmpnyProfile_AF.isPresent())
		{
			UIHelper.clickAnElement(cmpnyProfile_AF);
			UIHelper.clickAnElement(manageColAddBtnCommodities);
		}
		if(corpLinkage_AF.isPresent())
		{
			UIHelper.clickAnElement(corpLinkage_AF);
			UIHelper.clickAnElement(manageColAddBtnCommodities);
		}
		if(socialResp_AF.isPresent())
		{
			UIHelper.clickAnElement(socialResp_AF);
			UIHelper.clickAnElement(manageColAddBtnCommodities);
		}
		if(spend_AF.isPresent())
		{
			UIHelper.clickAnElement(spend_AF);
			UIHelper.clickAnElement(manageColAddBtnCommodities);
		}
		if(risk_AF.isPresent())
		{
			UIHelper.clickAnElement(risk_AF);
			UIHelper.clickAnElement(manageColAddBtnCommodities);
		}
		/*		if(Commodities_AF.isPresent())
		{
			Commodities_AF.click();
			manageColAddBtnCommodities.click();
		}*/
		UIHelper.clickAnElement(applyBtn);
	}

	public Map<String, String> getSpendAfterAddColsOfCommodities(){
		String preXpath="//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDunsOfCommodities, nextPageOfCom);
	}
	
	public void clickOnExportToExcelInCommodities(){
		UIHelper.switchToTab(getDriver(), "notSF");
		UIHelper.mouseOveranElement(getDriver(),export);
	}

	public boolean isDataExportedInCommodities(){
		return exportToExcel.isPresent();
	}
}
