/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dnb.automation.dnbi.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**********************************************************************************************
 * QuickSearchPage.java - This class performs Quick Search
 * 
 * @author Vamsi Krishna NV
 * @version 1.0
 ***********************************************************************************************/
public class QuickSearchPage extends PageObject {

	
	@FindBy(xpath = "//*[@id='main']//*[@class='compHome_newFolder']//input[@value='Create New Folder']")
    private WebElementFacade createNewFolderBtn;
	@FindBy(xpath = "//iframe[@name='__modal_iframe_target']")
   	private WebElementFacade iFrameEle;
	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='quickSearchFld']")
    private WebElementFacade searchCompBox;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='companyCity']")
    private WebElementFacade searchCityFieldEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='companyQSState']")
    private WebElementFacade searchStateDropdown;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='quickSearchForm']//*[@id='companyCity']")
    private WebElementFacade searchCity;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='quickSearchForm']//*[@value='Search']")
    private WebElementFacade searchBtn;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']")
    private WebElementFacade searchBox;

    @FindBy(xpath = "//*[@id='header_mainApp']//a[text()='Dashboard']")
    private WebElementFacade disHref;

    String dashBoardTabXPath = "//*[@id='header_mainApp']//a[text()='Dashboard']";

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='quicksearch_more_options' and contains(text(),'Fewer')]")
    private WebElementFacade searchBoxFewerOptions;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='quicksearch_more_options' and contains(text(),'Fewer')] | //*[@class='outerDiv']//*[@id='search_box']//*[@class='moreOpt']//*[@id='quicksearch_more_options' and contains(text(),'More')]")
    private WebElementFacade fewerORMoreOptionsEle;

    @FindBy(xpath = "//*[@id='folder_bar']//a[contains(.,'Search Now')]")
    private WebElementFacade searchNowBtnEle;

    @FindBy(xpath = "//*[@id='quicksearch_more_options']")
    private WebElementFacade qSearchMoreOptEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@class='moreOpt']//*[@id='quicksearch_more_options' and contains(text(),'More')]")
    private WebElementFacade searchMoreOptionsEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='page_title']//*[text()='Search Results']")
    private WebElementFacade searchResultsConatinerEle;
    
    @FindBy(xpath="//*[@id='main']/div/table[1]/tbody/tr[1]/td[9]/a[2]/span")
    private WebElementFacade createAccountLink;
    
    @FindBy(xpath="//*[@id='main']/div/table[1]/tbody/tr/td[5]/a[2][contains(.,'» Create Account')]")
    private WebElementFacade createAccountLinkint;
    
    @FindBy(xpath="//div[@class='action_header']//div[@class='actionButtons']//input[@value='Create Account']")
    private WebElementFacade createAccountECFclick;
    
    @FindBy(xpath="//div[@id='backRight']/input[@value='Next']")
    private WebElementFacade createAccountNextclick;
    
    @FindBy(xpath="//*[@id='modal_buttons']/input[1]")
    private WebElementFacade saveASnapshotEle;
    
    @FindBy(xpath="//div[@class='action_header']//div[@class='actionButtons']//input[@value='Refresh D&B Data']")
    private WebElementFacade refreshDBdata;
    
    
    @FindBy(xpath="//div[@class='ecf_header']//h2")
    private WebElementFacade getAccountCountryName;
  
    @FindBy(xpath="//form[@id='plNoteForm']//div[@class='ecf_header']/div/h2")
    private WebElementFacade getSnapAccountCountryName;
    
    @FindBy(xpath="//form[@id='plNoteForm']//div[@class='ecf_header']/div/h2")
    private WebElementFacade getSnapshotCountryName;
    
    private String searchResultsConatiner="//*[@class='outerDiv']//*[@id='main']//*[contains(@class,'results full')]//thead";

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[contains(@class,'results full')]//thead")
    private WebElementFacade firstSearchItemEle;
    
    @FindBy(xpath = "//*[@id='header_mainApp']//li//a[contains(.,'Companies')]")
    private WebElementFacade CompaniesTabEle;

    @FindBy(xpath = "//*[@id='page_title']/h2")
    private WebElementFacade CompaniesTitleEle;
    
    @FindBy(xpath = "//*[@id='header_mainApp']//li//a[contains(.,'Account Manager')]")
    private WebElementFacade accountManagerTabEle;
    
    @FindBy(xpath = "//*[@id='main']//*[@id='createAcctButton_pm']")
    private WebElementFacade createAccountBtn;
    
    @FindBy(xpath = "//*[@id='page_title_links']//h2[contains(.,'Company Information')]")
    private WebElementFacade accountpageheaderelement;
    
    String accountpageheaderXpath="//*[@id='page_title_links']//h2[contains(.,'Company Information')]";
    String createAccountBtnXpath="//*[@id='main']//*[@id='createAcctButton_pm']";
    String cnfBtnxpath="//*[@id='main']//*[@class='compHome_newFolder']//input[@value='Create New Folder']";
  
    public void performQuickSearch(String quickSearchVal, String city,
            String getCurrentState) throws InterruptedException, IOException {

        try {

            disHref.click();
            fewerORMoreOptionsEle.waitUntilPresent();

            String qSearchMoreOptText = qSearchMoreOptEle.getText();

            if (qSearchMoreOptText.contains("Fewer")) {
                if (searchBoxFewerOptions.isPresent()) {
                    searchBoxFewerOptions.click();
                    searchMoreOptionsEle.waitUntilPresent();
                    searchCompBox.waitUntilPresent();
                }
            } else {
                searchCompBox.waitUntilPresent();
            }

            if (searchCompBox.isPresent()) {
                searchCompBox.click();
                searchCompBox.type(quickSearchVal.toString().trim());

            }

            if (city != null && !city.isEmpty()) {
                if (searchCityFieldEle.isPresent()) {
                    searchCityFieldEle.click();
                    searchCityFieldEle.type(city.toString().trim());
                }
            }

            if (getCurrentState != null && !getCurrentState.isEmpty()) {
                if (searchStateDropdown.isPresent()) {
                    searchStateDropdown.selectByVisibleText(getCurrentState);
                }
            }

            if (searchBtn.isPresent()) {
                searchBtn.click();

                searchResultsConatinerEle.waitUntilPresent();
                disHref.waitUntilPresent();
                if (searchNowBtnEle.isPresent()) {
                    searchNowBtnEle.click();
                    firstSearchItemEle.waitUntilPresent();
                    disHref.waitUntilPresent();
                }
                
                //firstSearchItemEle.waitUntilPresent();
                
            }

        } catch (Exception E) {
            // throw E;
        }
    }
        public void quickSearchWithDunsAndCountry(String quickSearchDuns,String getCurrentState){
        	
    		searchCompBox.waitUntilPresent();
            searchCompBox.click();
            UIHelper.waitForPageToLoad(getDriver());
      	   try{
      		 getDriver().switchTo().frame(iFrameEle);
            	 ((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", saveASnapshotEle);
            	 getDriver().switchTo().defaultContent();
         	}catch(Exception e){
          	  
            }
            searchCompBox.click();
            searchCompBox.type(quickSearchDuns.toString().trim());
            searchStateDropdown.waitUntilEnabled();
	        if (getCurrentState != null && !getCurrentState.isEmpty()) {
	                searchStateDropdown.selectByVisibleText(getCurrentState);
	        }

			searchBtn.waitUntilClickable();        
			searchBtn.click();
			//searchBtn.submit();
			UIHelper.waitForPageToLoad(getDriver());
			firstSearchItemEle.waitUntilVisible();

        }
		public void quickSearchWithDunsAndCountryForUSCA(String quickSearchDuns,
                String getCurrentState) throws InterruptedException, IOException {

            try {

            	CompaniesTabEle.click();
            	UIHelper.waitForPageToLoad(getDriver());
         	   try{
         		 getDriver().switchTo().frame(iFrameEle);
               	 ((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", saveASnapshotEle);
               	 getDriver().switchTo().defaultContent();
            	}catch(Exception e){
             	  
               }
                if (searchCompBox.isPresent()) {
                    searchCompBox.click();
                    searchCompBox.type(quickSearchDuns.toString().trim());

                }

               

                if (getCurrentState != null && !getCurrentState.isEmpty()) {
                    if (searchStateDropdown.isPresent()) {
                        searchStateDropdown.selectByVisibleText(getCurrentState);
                    }
                }

                if (searchBtn.isPresent()) {
                	UIHelper.highlightElement(getDriver(), searchBtn);
                	((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", searchBtn);
                	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), searchResultsConatiner);
                    if (searchNowBtnEle.isPresent()) {
                        searchNowBtnEle.click();
                        UIHelper.waitForVisibilityOfEleByXpath(getDriver(), searchResultsConatiner);

                    }

                    
                }

            } catch (Exception E) {
                // throw E;
            }

    }
		
	public void createAccountLink(){
		UIHelper.waitForPageToLoad(getDriver());
		createAccountLink.click();
	}
	
	public void createAccountLinkint(){
		UIHelper.waitForPageToLoad(getDriver());
		createAccountLinkint.click();
	}
	
	
	public void createAccountECF(){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), createAccountECFclick);
		createAccountECFclick.click();
	}
	
	public boolean accountNameValidate(String validateCountryName){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), createAccountNextclick);
		createAccountNextclick.click();
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), getAccountCountryName);
		String countryName = getAccountCountryName.getText();
		if(validateCountryName.contains(countryName)){
			return false;
		}
		else 
			return true;
	}
	
	public void refreshBtnPage(){
		
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), refreshDBdata);
		refreshDBdata.click();
    }
	
	
	public boolean applnNameValidate(String validateCountryName){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), getAccountCountryName);
		String countryName = getAccountCountryName.getText();
		if(validateCountryName.contains(countryName)){
			return false;
		}
		else 
			return true;
	}
	
	public boolean snapNameValidate(String validateCountryName){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), getSnapAccountCountryName);
		String countryName = getSnapAccountCountryName.getText();
		if(validateCountryName.contains(countryName)){
			return false;
		}
		else 
			return true;
	}

	public void quickSearchWithAppliactionID(String FileName) throws Exception {
		try {
		String filePath1 = System.getProperty("user.dir");
		String mypath=filePath1.replace(":", ":\\");
		String filePath = mypath+FileName;
		System.out.println("File Path============"+filePath);
		
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		
		    String AppID = br.readLine();
		    br.close();
		    System.out.println("application ID-----------------"+AppID);

		CompaniesTabEle.click();
		createNewFolderBtn.waitUntilPresent();
		searchCompBox.waitUntilPresent();
		if (searchCompBox.isPresent()) {
			searchCompBox.click();
			searchCompBox.type(AppID.toString().trim());

		}

		if (searchBtn.isPresent()) {
			UIHelper.highlightElement(getDriver(), searchBtn);
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].click();", searchBtn);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					searchResultsConatiner);
		}

	
	 } catch (Exception E) {
         // throw E;
     }
	}
	
	public void quickSearchWithDunsOnly(String quickSearchDuns)  {

        try {
        	CompaniesTabEle.click();
        	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), cnfBtnxpath);
        	
            if (searchCompBox.isPresent()) {
                searchCompBox.click();
                searchCompBox.type(quickSearchDuns.toString().trim());
                UIHelper.highlightElement(getDriver(), searchBtn);
            	((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", searchBtn);
            	 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), searchResultsConatiner);
            	 if (searchNowBtnEle.isPresent()) {
                     searchNowBtnEle.click();
                     UIHelper.waitForVisibilityOfEleByXpath(getDriver(), searchResultsConatiner);

                 }
             }

        } catch (Exception E) {
            
        }

}
	public void navigateTo_Create_Acc_Page(){
		accountManagerTabEle.click();
    	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), createAccountBtnXpath);
    	 UIHelper.highlightElement(getDriver(), createAccountBtn);
    	createAccountBtn.click();
    	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), accountpageheaderXpath);
	}
	
	public boolean create_Acc_Page_has_Displayed(){
		try{
			accountpageheaderelement.isVisible();
			UIHelper.highlightElement(getDriver(), accountpageheaderelement);
			return true;
		}catch(Exception e){
			return false;
			
		}
	}
	
	public void quickSearchWithAccountNumber(String accnumber)  {

        try {
        	CompaniesTabEle.click();
        	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), cnfBtnxpath);
        	
            if (searchCompBox.isPresent()) {
                searchCompBox.click();
                searchCompBox.type(accnumber.toString().trim());
                UIHelper.highlightElement(getDriver(), searchBtn);
            	((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", searchBtn);
            	 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), searchResultsConatiner);
           }

        } catch (Exception E) {
            
        }

}
	
	 }
