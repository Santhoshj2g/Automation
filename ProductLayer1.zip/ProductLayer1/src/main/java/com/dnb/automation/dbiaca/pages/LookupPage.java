package com.dnb.automation.dbiaca.pages;

import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

/**********************************************************************************************
 * LookupPage.java - This program contains steps for 
 * 1. User checks Lookup Page navigation
 *
 * @author   Sendhilkumar.R
***********************************************************************************************/

public class LookupPage extends PageObject{
	
	@FindBy(xpath="//i/a")
	private WebElementFacade companyNameLnk;
	public boolean flag;
	
	public void clickCompanyName(){
		try{
			
			if(companyNameLnk.isPresent()){
				companyNameLnk.click();
				UIHelper.waitForPageToLoad(getDriver());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public boolean verifyCompanyNameLink()
	{
		flag = false;
		try{
			if(companyNameLnk.isPresent()){
				flag = true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return flag;
	}

}
