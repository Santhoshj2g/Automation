package com.dnb.automation.bd.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class UserMyAccountCompProfilePage extends PageObject {
	
	@FindBy(xpath = "//li[@aria-labelledby='ui-id-2']")
    private WebElementFacade tabConnectionsClass;

	@FindBy(xpath = "//*[@id='user-company-profile-result']/div/a[@title='Next']")	
	private WebElementFacade imgNextClass;

	@FindBy(xpath = "//*[@id='user-company-profile-result']/div/a[@title='Next']/img")	
	private WebElementFacade imgNext;

	@FindBy(xpath = "//*[@id='flat-tabs']/div[7]/div")	
	private WebElementFacade imgLoading;
	
	String loadicon="//div[@class='loadmask-msg']";

	@FindBy(xpath = "//div[@id='About-company']")	
	private WebElementFacade aboutCompany;
	
	private static int compProfileRowCnt =0;	
		
	public String tableCompProfile = "//table[@id='user-company-profile-table-id']/tbody/tr";
	public String tablepart1 ="//*[@id='user-company-profile-container']/tr[";
	public String Col_CompName = "]/td[1]/span";
	public String Col_EditProfileButton = "]//a[@class='button editProfile']";
	public String Col_EditButton = "]//a[@class='button']";
	public String inviteRec_CompStatus = "]/td[4]";
	
	
	/***********************************************************************************
	* Function: Select the profile and verify the edit button 
	* Input : Profile Name
	* Action : NA 
	* Output : NA
	***********************************************************************************/	
	public boolean isProfileEditButtonEnabled(String dbProfileName) {
		int rowNum = getProfileRowNum_CompProfile(dbProfileName);
		WebElement EditButton = null;		
		if(rowNum>0)
		{
			EditButton = getDriver().findElement(By.xpath(tablepart1+rowNum+Col_EditProfileButton));			
			return EditButton.isEnabled();
		}else
		{
			return false;
		}
		
	}

	/***********************************************************************************
	* Function: Select the profile and click on the edit button 
	* Input : Profile Name
	* Action : NA 
	* Output : NA
	***********************************************************************************/	
	public boolean selectProfileAndEdit(String dbProfileName) {
		int rowNum = compProfileRowCnt;
		WebElement EditButton = null;		
		if(rowNum>0)
		{
			EditButton = getDriver().findElement(By.xpath(tablepart1+rowNum+Col_EditProfileButton));	
			EditButton.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadicon);
		}	
		UIHelper.waitForPageToLoad(getDriver());
		if(aboutCompany.isVisible())
		{
			return true;
		}else
		{
			return false;
		}		
	}


	/***********************************************************************************
	* Function: Get the profile row num from the list of company profiles 
	* Input : Profile Name
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
	public int getProfileRowNum_CompProfile(String dbProfileName)
	{
		WebElement profileName = null;
		String prflName = null;
		int i = 0;
		boolean prfFound = false;
		int rowCount = getDriver().findElements(By.xpath(tableCompProfile)).size(); 		
		for(i=1;i<=rowCount;i++)
		{
			profileName = getDriver().findElement(By.xpath(tablepart1+i+Col_CompName));			
			prflName = profileName.getAttribute("title").trim();			
			if(prflName.equalsIgnoreCase(dbProfileName))
			{
				prfFound = true;
				break;
			}else if(i%5 == 0)
			{
				if(imgNextClass.getAttribute("class").equalsIgnoreCase("next"))
				{
					imgNext.click();
				}else
				{
					break;
				}
				
			}
		}
		if(prfFound = true)
		{
			compProfileRowCnt = i;
			return i;
		}else
		{
			return 0;
		}
	}
	
}
