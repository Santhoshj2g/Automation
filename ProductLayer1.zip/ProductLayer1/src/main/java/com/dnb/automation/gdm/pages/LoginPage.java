package com.dnb.automation.gdm.pages;


import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.pages.PageObject;

/**
 * Created by 630239 on 6/15/2017.
 */
public class LoginPage extends PageObject {
    @FindBy(xpath=".//input[@name='userId']")
    private WebElementFacade userNametxt;

    @FindBy(xpath = ".//input[@name='userPassword']")
    private WebElementFacade passwordtxt;

    @FindBy(xpath=".//input[@name='submit1']")
    private WebElementFacade signinbtn;

    @FindBy(xpath = ".//table/tbody/tr/td/input[@value='Sign Up Later']")
    private WebElementFacade signupLaterbtn;

    @FindBy(xpath = ".//input[@value='I agree']")
    private WebElementFacade iAgreeBtn;

    public void enterCredentials(String username, String password) {
        enterUser(username);
        enterPass(password);
        clickSignIn();
    }

    private void clickSignIn() {
        if(signinbtn.isPresent()){
            UIHelper.highlightElement(getDriver(),signinbtn);
            signinbtn.click();
        }
    }

    private void enterPass(String password) {
        if(passwordtxt.isPresent()){
            UIHelper.highlightElement(getDriver(),passwordtxt);
            passwordtxt.type(password);
        }
    }

    private void enterUser(String username) {
        UIHelper.waitForPageToLoad(getDriver());
        if(userNametxt.isPresent()) {
            UIHelper.highlightElement(getDriver(), userNametxt);
            userNametxt.type(username);
        }
    }

    public void clickSignOutLaterbtn() {
        UIHelper.waitForPageToLoad(getDriver());
        if(signupLaterbtn.isPresent()){
            UIHelper.highlightElement(getDriver(),signupLaterbtn);
            signupLaterbtn.click();
        }
    }

    public void clickIAgreebtn() {
        UIHelper.waitForPageToLoad(getDriver());
        if(iAgreeBtn.isPresent()){
            UIHelper.highlightElement(getDriver(),iAgreeBtn);
            iAgreeBtn.click();
        }
    }
}
