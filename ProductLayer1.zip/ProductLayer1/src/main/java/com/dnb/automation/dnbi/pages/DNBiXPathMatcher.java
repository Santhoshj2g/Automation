package com.dnb.automation.dnbi.pages;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.stereotype.Component;

import net.serenitybdd.core.pages.PageObject;




import com.dnb.automation.dnbi.pages.XPathReturn;
import com.dnb.automation.dnbi.pages.XPathReturnImpl;
import com.dnb.automation.utils.FileCache;
import com.dnb.automation.utils.UIHelper;
import com.google.common.base.Predicate;

import net.serenitybdd.core.pages.WebElementFacade;
@Component
public class DNBiXPathMatcher extends PageObject {

	/**
	 * Compliance Check Loading image Xpath
	 */
	//XPathReturn getXPath;
	XPathReturnImpl xpimp = new XPathReturnImpl();
	@FindBy(xpath = "//*[@id='addDataFieldsAnd']")
	private WebElementFacade addFilterDataField;
	@FindBy(xpath = "//*[@id='removeDataFieldsAnd']")
	private WebElementFacade removeFilterDataField;
	@FindBy(xpath = "//div[@class='modal_content']//input[@type='text']")
	private WebElementFacade modelContentTextBox;
	@FindBy(xpath = "//div[@class='modal_content']//a[contains(.,'Add')]")
	private WebElementFacade modelAddLink;
	@FindBy(xpath = "//div[@class='modal_content']//img[contains(@src,'add.gif')]")
	private WebElementFacade modelCountryAddLink;
	@FindBy(xpath = "//img[contains(@src,'add.gif')]")
	private WebElementFacade amdmSelectVariable;

	@FindBy(xpath = "//div[@id='sel']//a[1]")
	private WebElementFacade addIcon;

	@FindBy(xpath = "//div[@class='widget_crediterms']/input[1]|//*[@id='ruleForm']//*[@id='expressionBox']")
	private WebElementFacade expressionValue;
	@FindBy(xpath = "//div[@class='modal_content']//input[contains(@value,'Submit')]")
	private WebElementFacade modelSubmitButton;
	@FindBy(xpath = "//div[@class='modal_content']//input[contains(@value,'Submit')]")
	private WebElementFacade modelCountrySubmitButton;
	@FindBy(xpath = "//iframe[@name='__modal_iframe_target']")
	private WebElementFacade iFrameElement;
	@FindBy(xpath = "//body[@class='iframe_modal']//div[@id='fields']//div[@id='seld']//select[@class='ad_selectPool']//option")
	private List<WebElementFacade> deselectScoreVariables;
	@FindBy(xpath = "//div[@class='Amodal_buttons']//input[contains(@value,'Yes')]")
	private WebElementFacade PopupSubmit;
	@FindBy(xpath = "//*[@id='main']//*[@id='srcRecordList']/tbody")
	private WebElementFacade applicationNameList;
	@FindBy(xpath = "//*[@id='modal_buttons']/input[@value='Yes']")
	private WebElementFacade Acceptiframepopup;
	@FindBy(xpath = "//div[@class='modal_buttons']//input[@value='Remove'][@type='button']")
	private WebElementFacade buttonCreditFileDelete;
	@FindBy(xpath = "//*[@class='modal_content']//input[contains(@value,'Yes')]")
	private WebElementFacade modelAdministrDelete;
	@FindBy(xpath = "//div[@class='modal_content']//div[@class='modal_buttons']//input[@value='OK']")
	private WebElementFacade modelAdministrSubmit;
	@FindBy(xpath = "//div[@class='modal_buttons']//input[@value='OK'][@type='submit']")
	private WebElementFacade enableFraudWrite;
	@FindBy(xpath = "//*[@id='ruleForm']//input[@value='Submit']")
	private WebElementFacade submitExp;
	public static final String xpathpath = "src/main/resources/Xpath.properties";
	String applinamewidget = "//*[@id='main']//*[@id='srcRecordList']/tbody";
	public static String parentWindowId;
	public void alertProcessModel(){
		try{
		Alert alert = getDriver().switchTo().alert();
		waitFor(100).milliseconds();
        alert.accept();
		}catch (Exception u) {

		}
	}
	public void reference2XPathClickForWindowAlert(String Name, String OptionName,
			String xPText) {
		try{
		String propname = xPText;
			UIHelper.waitForPageToLoad(getDriver());
			WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(
					Name, OptionName, propname))));
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", xPathEle);
			xPathEle.waitUntilEnabled().waitUntilVisible();
			UIHelper.highlightElement(getDriver(), xPathEle);
			xPathEle.click();
				PopupSubmit.click();
				UIHelper.waitForPageToLoad(getDriver());
				waitFor(500).milliseconds();
			}catch (Exception e) {

			}
			}
	public void reference2XPathClickMethod(String Name, String OptionName,
			String xPText) {
		String propname = xPText;
			UIHelper.waitForPageToLoad(getDriver());
			WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(
					Name, OptionName, propname))));
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", xPathEle);
			xPathEle.waitUntilEnabled().waitUntilVisible();
			UIHelper.highlightElement(getDriver(), xPathEle);
			xPathEle.click();
		}
	
	public void reference2XPathClickForModelAlert(String Name, String OptionName,
			String xPText) {
		try{
		String propname = xPText;
			UIHelper.waitForPageToLoad(getDriver());
			WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(
					Name, OptionName, propname))));
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", xPathEle);
			xPathEle.waitUntilEnabled().waitUntilVisible();
			UIHelper.highlightElement(getDriver(), xPathEle);
			xPathEle.click();
			waitFor(1000).milliseconds();
					modelAdministrDelete.click();
					waitFor(1000).milliseconds();
					modelAdministrSubmit.click();
					UIHelper.waitForPageToLoad(getDriver());
					waitFor(500).milliseconds();
		}catch (Exception e) {

		}
	}
	
	public void reference2XPathClickMethodForAlert(String Name, String OptionName,
			String xPText) {
		try{
		String propname = xPText;
			UIHelper.waitForPageToLoad(getDriver());
			WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(
					Name, OptionName, propname))));
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", xPathEle);
			xPathEle.waitUntilEnabled().waitUntilVisible();
			UIHelper.highlightElement(getDriver(), xPathEle);
			xPathEle.click();
			try{
				waitFor(500).milliseconds();
				alertProcessModel();
					UIHelper.waitForPageToLoad(getDriver());
			}catch (Exception A) {

					}
		}catch (Exception e) {

		}
	}
	public void reference2XPathClickMethodIframe(String Name, String OptionName,
			String xPText) {
		try{
		String propname = xPText;
			UIHelper.waitForPageToLoad(getDriver());
			WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(
					Name, OptionName, propname))));
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", xPathEle);
			xPathEle.waitUntilEnabled().waitUntilVisible();
			UIHelper.highlightElement(getDriver(), xPathEle);
			xPathEle.click();
			iFrameElement.waitUntilEnabled().waitUntilVisible();
					getDriver().switchTo().frame(iFrameElement);
					waitFor(500).milliseconds();
					Acceptiframepopup.click();
					getDriver().switchTo().defaultContent();
					UIHelper.waitForPageToLoad(getDriver());
					waitFor(500).milliseconds();
		}catch (Exception e) {

		}
	}
	
	public void pageXPathClickMethodFraud(String name, String xPText) {
		String propname = xPText;
			UIHelper.waitForPageToLoad(getDriver());
			WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(name,
					propname))));
			xPathEle.waitUntilEnabled().waitUntilVisible();
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", xPathEle);
			UIHelper.highlightElement(getDriver(), xPathEle);
			xPathEle.click();
			enableFraudWrite.waitUntilEnabled().waitUntilVisible();
				enableFraudWrite.click();
				UIHelper.waitForPageToLoad(getDriver());
	}
	public void pageXPathClickIFrame(String name, String xPText) {
		String propname = xPText;
		UIHelper.waitForPageToLoad(getDriver());
		WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(name,
				propname))));
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", xPathEle);
		xPathEle.waitUntilEnabled().waitUntilVisible();
		UIHelper.highlightElement(getDriver(), xPathEle);
		xPathEle.click();
		iFrameElement.waitUntilVisible();
		getDriver().switchTo().frame(iFrameElement);
		buttonCreditFileDelete.waitUntilEnabled().waitUntilVisible();
		buttonCreditFileDelete.click();
		getDriver().switchTo().defaultContent();
		UIHelper.waitForPageToLoad(getDriver());
	}
	public void pageXPathClickMethod(String name, String xPText) {
		UIHelper.waitForPageToLoad(getDriver());
		String propname = xPText;
		if (name.equals("Reset List")) {
			try {/* This try handled for button enable-disable state to run scenario due to other scenario to complete*/ 
				WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(name,
						propname))));
				xPathEle.waitUntilEnabled().waitUntilVisible();
				((JavascriptExecutor) getDriver()).executeScript(
						"arguments[0].scrollIntoView(true);", xPathEle);
				UIHelper.highlightElement(getDriver(), xPathEle);
				xPathEle.click();
			} catch (Exception e) {

			}
		} else {
			WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(name,
					propname))));
			xPathEle.waitUntilEnabled().waitUntilVisible();
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", xPathEle);
			xPathEle.waitUntilClickable();
			UIHelper.highlightElement(getDriver(), xPathEle);
			xPathEle.click();
			try {
				alertProcessModel();
				UIHelper.waitForPageToLoad(getDriver());
				} catch (Exception T) {
			}
		}
	
	}

	public void navXPathClickMethod(String name, String xPText) {
		String propname = xPText;
		UIHelper.waitForPageToLoad(getDriver());
		waitFor(1000).milliseconds();
		WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(name,
				propname))));
		xPathEle.waitUntilEnabled().waitUntilVisible();
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", xPathEle);
		UIHelper.highlightElement(getDriver(), xPathEle);
		xPathEle.click();
		waitFor(1000).milliseconds();
	}

	public void reference2XPathEnterMethod(String Name1, String Name2,
			String Value, String xPText) {
		String propname = xPText;
		waitFor(3000).milliseconds();
		WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(Name1,
				Name2, propname))));
		xPathEle.waitUntilEnabled().waitUntilVisible();
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", xPathEle);
		UIHelper.highlightElement(getDriver(), xPathEle);
		xPathEle.clear();
		xPathEle.type(Value.trim());
	}

	public void reference2XPathSelectMethod(String Name1, String Name2,
			String Value, String xPText) {
		String propname = xPText;
		WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(Name1,
				Name2, propname))));
		xPathEle.waitUntilEnabled().waitUntilVisible();
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", xPathEle);
		UIHelper.highlightElement(getDriver(), xPathEle);
		xPathEle.selectByVisibleText(Value);

	}

	public void XPathEnterUsingFieldMethod(String Name, String Value,
			String xPText) {
		String propname = xPText;
		WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(Name, propname))));
		xPathEle.waitUntilEnabled().waitUntilVisible();
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", xPathEle);
		UIHelper.highlightElement(getDriver(), xPathEle);
		xPathEle.click();
		xPathEle.clear();
		xPathEle.type(Value.trim());

	}

	public String XPathValidateAssertedValue(String assertValue, String xPText) {
		String propname = xPText;
		String assetValue = null;
		WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(assertValue,
				propname))));
		xPathEle.waitUntilEnabled().waitUntilVisible();
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", xPathEle);
		UIHelper.highlightElement(getDriver(), xPathEle);
		assetValue = xPathEle.getText().trim();

		return assetValue;
	}

	public String XPathValidateRefRecordAssertedValue(String RecName,
			String RecValue, String xPText) {
		String propname = xPText;
		String assetValue = null;
		WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(
				RecName, RecValue, propname))));
		xPathEle.waitUntilEnabled().waitUntilVisible();
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", xPathEle);
		UIHelper.highlightElement(getDriver(), xPathEle);
		assetValue = xPathEle.getText().trim();

		return assetValue;
	}

	public void XPathSelectForFieldMethod(String SelectField, String Value,
			String xPText) {
		String propname = xPText;
		WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(SelectField,
				propname))));
		xPathEle.waitUntilEnabled().waitUntilVisible();
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", xPathEle);
		UIHelper.highlightElement(getDriver(), xPathEle);
		waitFor(1000).milliseconds();
		xPathEle.selectByVisibleText(Value);
	}

	public void XPathMultiSelectForFieldMethod(String SelectField,
			String MultiValue, String xPText, String xPText2) {
		String propname = xPText;
		WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(SelectField,
				propname))));
		xPathEle.waitUntilEnabled().waitUntilVisible();
		UIHelper.highlightElement(getDriver(), xPathEle);
		String propname2 = xPText2;
		WebElementFacade xPathEle2 = (find(By.xpath(xpimp.XPath(propname2))));
		if (MultiValue.contains(":")) {
			String[] fieldsList = MultiValue.split(":");
			for (String fieldname : fieldsList) {
				waitFor(500).milliseconds();
				xPathEle.selectByVisibleText(fieldname);
				UIHelper.highlightElement(getDriver(), xPathEle2);
				((JavascriptExecutor) getDriver()).executeScript(
						"arguments[0].scrollIntoView(true);", xPathEle2);
				xPathEle2.click();
				try{
					alertProcessModel();
				}catch (Exception e) {

				}
			}
		} else {
			waitFor(500).milliseconds();
			xPathEle.selectByVisibleText(MultiValue);
			UIHelper.highlightElement(getDriver(), xPathEle2);
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", xPathEle2);
			xPathEle2.click();
		}

	}

	public void clickRemoveVariableList(String xPText) {
		try{
			String propname1 = xPText;
			WebElementFacade xPathEle1 = (find(By.xpath(xpimp.XPath(propname1))));
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", xPathEle1);
			UIHelper.highlightElement(getDriver(), xPathEle1);
		for (WebElementFacade listVariable : deselectScoreVariables) {
			listVariable.click();
			}
		xPathEle1.click();
		}catch (Exception e) {

		}
	}

	public void valueForRule(String Operator, String FieldName, String Value1,
			String Value2, String xPText, String xPText2) {
		String propname1 = xPText;
		WebElementFacade xPathEle1 = (find(By.xpath(xpimp.XPath(FieldName,
				propname1))));
		UIHelper.highlightElement(getDriver(), xPathEle1);
		xPathEle1.selectByVisibleText(Operator);
		if (Operator.equals("Contains") || Operator.equals("Does Not Contain")
				|| Operator.equals("Is Greater Than")
				|| Operator.equals("Is Greater Than Or Equal To")
				|| Operator.equals("Is Less Than")
				|| Operator.equals("Is Less Than Or Equal To")
				|| Operator.equals("Is Equal To")
				|| Operator.equals("Is Not Equal To")) {
			String propname2 = xPText2;
			WebElementFacade xPathEle2 = (find(By.xpath(xpimp.XPath(FieldName,
					propname2))));
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", xPathEle2);
			UIHelper.highlightElement(getDriver(), xPathEle2);
			xPathEle2.type(Value1.trim());
		} else if (Operator.equals("Is Blank")
				|| Operator.equals("Is Not Blank")
				|| Operator.equals("Is True") || Operator.equals("Is False")
				|| Operator.equals("Is True or Blank")
				|| Operator.equals("Is False or Blank")) {
		} else if (Operator.equals("Is Within Range")) {
			WebElementFacade minXPath = (find(By
					.xpath("//*[normalize-space(text())='"
							+ FieldName
							+ "']/ancestor::tr/following-sibling::tr[1]//tbody//td/input[contains(@name,'min')]")));
			minXPath.clear();
			minXPath.type(Value1.trim());
			WebElementFacade maxXPath = (find(By
					.xpath("//*[normalize-space(text())='"
							+ FieldName
							+ "']/ancestor::tr/following-sibling::tr[1]//tbody//td/input[contains(@name,'max')]")));
			maxXPath.clear();
			maxXPath.type(Value2.trim());
		}
	}

	public void addValueRangeForSelectedFieldMethod(String Operator,
			String FieldName, String Value1, String Value2, String xPText,
			String xPText2, String xPText3) {
		String propname1 = xPText;
		WebElementFacade xPathEle1 = (find(By.xpath(xpimp.XPath(FieldName,
				propname1))));
		xPathEle1.waitUntilEnabled().waitUntilVisible();
		UIHelper.highlightElement(getDriver(), xPathEle1);
		xPathEle1.selectByVisibleText(Operator);
		if (Operator.equals("Contains") || Operator.equals("Does Not Contain")
				|| Operator.equals("Is Greater Than")
				|| Operator.equals("Is Greater Than Or Equal To")
				|| Operator.equals("Is Less Than")
				|| Operator.equals("Is Less Than Or Equal To")) {
			String propname2 = xPText2;
			WebElementFacade xPathEle2 = (find(By.xpath(xpimp.XPath(FieldName,
					propname2))));
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", xPathEle2);
			UIHelper.highlightElement(getDriver(), xPathEle2);
			xPathEle2.type(Value1.trim());
		} else if (Operator.equals("Is Blank")
				|| Operator.equals("Is Not Blank")
				|| Operator.equals("Is True") || Operator.equals("Is False")
				|| Operator.equals("Is True or Blank")
				|| Operator.equals("Is False or Blank")) {
		} else if (Operator.equals("Is Equal To")
				|| Operator.equals("Is Not Equal To")) {
			String propname3 = xPText3;
			WebElementFacade xPathEle3 = (find(By.xpath(xpimp.XPath(FieldName,
					propname3))));
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", xPathEle3);
			UIHelper.highlightElement(getDriver(), xPathEle3);
			xPathEle3.click();
			if (FieldName.equals("Country")) {
				int flag=1;
				if (Value1.contains(":")) {
					String[] fieldsList = Value1.split(":");
					try{/*This try handled for two type of actions in 2 different modules*/
						for (String fieldname : fieldsList) {
							modelContentTextBox.type(fieldname);
							waitFor(500).milliseconds();
							modelAddLink.click();
						}
						modelSubmitButton.click();
						flag=2;
					}catch (Exception e) {

					}
					if(flag == 1){
					String propnam = xPText;
					String CountryPopupList = "Available Countries";
					WebElementFacade xPathEleCountry = (find(By
							.xpath(xpimp.XPath(CountryPopupList, propnam))));
					UIHelper.highlightElement(getDriver(), xPathEleCountry);
					for (String fieldname : fieldsList) {
						xPathEleCountry.selectByVisibleText(fieldname);
						waitFor(500).milliseconds();
						modelCountryAddLink.click();
					}
					modelCountrySubmitButton.click();
					flag=3;
					}
				} else {
					try{
						modelContentTextBox.type(Value1);
						waitFor(500).milliseconds();
						modelAddLink.click();
						modelSubmitButton.click();
						flag=4;
					} catch (Exception e) {

					}if(flag == 1){
					String propnam = xPText;
					String CountryPopupList = "Available Countries";
					WebElementFacade xPathEleCountry = (find(By
							.xpath(xpimp.XPath(CountryPopupList, propnam))));
					UIHelper.highlightElement(getDriver(), xPathEleCountry);
					xPathEleCountry.selectByVisibleText(Value1);
					waitFor(500).milliseconds();
					modelCountryAddLink.click();
					modelCountrySubmitButton.click();
				}
				}
			} else {
				if (Value1.contains(":")) {
					String[] fieldsList = Value1.split(":");
					for (String fieldname : fieldsList) {
						modelContentTextBox.type(fieldname);
						waitFor(500).milliseconds();
						modelAddLink.click();
					}
					modelSubmitButton.click();
				} else {
					modelContentTextBox.type(Value1);
					waitFor(500).milliseconds();
					modelAddLink.click();
					modelSubmitButton.click();
				}
			}
		} else if (Operator.equals("Is Within Range")) {

		}
	}
public void clickAddDataIcon(String xPText){
	String propname = xPText;
	UIHelper.waitForPageToLoad(getDriver());
	WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(propname))));
	xPathEle.waitUntilEnabled().waitUntilVisible();
	((JavascriptExecutor) getDriver()).executeScript(
			"arguments[0].scrollIntoView(true);", xPathEle);
	UIHelper.highlightElement(getDriver(), xPathEle);
	xPathEle.click();
}
	public void clickAddDataIcon(String option, String xPText) {
		String propname = xPText;
		UIHelper.waitForPageToLoad(getDriver());
		WebElementFacade xPathEle = (find(By.xpath(xpimp.XPath(propname))));
		xPathEle.waitUntilEnabled().waitUntilVisible();
		if(xPathEle.isSelected() && option.equals("Disable")){
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", xPathEle);
			UIHelper.highlightElement(getDriver(), xPathEle);
			xPathEle.click();	
			try{
			alertProcessModel();
			UIHelper.waitForPageToLoad(getDriver());
			}catch (Exception p) {

			}
		}else{
			
		}
		if (!xPathEle.isSelected() && option.equals("Enable")){
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", xPathEle);
			UIHelper.highlightElement(getDriver(), xPathEle);
			xPathEle.click();
			try{
			alertProcessModel();
			UIHelper.waitForPageToLoad(getDriver());
			}catch (Exception s) {

			}
	}else {
		
	}
	}

	public void switchToIFrame() {
		iFrameElement.waitUntilEnabled().waitUntilVisible();
		getDriver().switchTo().frame(iFrameElement);
	}

	public void switchToDefault() {
		getDriver().switchTo().defaultContent();
		UIHelper.waitForPageToLoad(getDriver());
	}

	public void addValueForDropDownRefMethod(String Operator, String FieldName,
			String Value1, String xPText, String xPText2) {
		String propname1 = xPText;
		WebElementFacade xPathEle1 = (find(By.xpath(xpimp.XPath(FieldName,
				propname1))));
		xPathEle1.waitUntilEnabled().waitUntilVisible();
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", xPathEle1);
		UIHelper.highlightElement(getDriver(), xPathEle1);
		xPathEle1.selectByVisibleText(Operator);
		if (Operator.equals("Contains") || Operator.equals("Does Not Contain")
				|| Operator.equals("Is Equal To")
				|| Operator.equals("Is Not Equal To")
				|| Operator.equals("Starts With")
				|| Operator.equals("Ends With")) {
			String propname2 = xPText2;
			WebElementFacade xPathEle2 = (find(By.xpath(xpimp.XPath(FieldName,
					propname2))));
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", xPathEle2);
			UIHelper.highlightElement(getDriver(), xPathEle2);
			xPathEle2.type(Value1.trim());
		} else if (Operator.equals("Is Blank")
				|| Operator.equals("Is Not Blank")) {
		}
	}

	public void selectValueForDropDownRefMethod(String Operator,
			String FieldName, String Value1, String xPText, String xPText2) {
		String propname1 = xPText;
		WebElementFacade xPathEle1 = (find(By.xpath(xpimp.XPath(FieldName,
				propname1))));
		xPathEle1.waitUntilEnabled().waitUntilVisible();
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", xPathEle1);
		UIHelper.highlightElement(getDriver(), xPathEle1);
		xPathEle1.selectByVisibleText(Operator);
		String propname2 = xPText2;
		WebElementFacade xPathEle2 = (find(By.xpath(xpimp.XPath(FieldName,
				propname2))));
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", xPathEle2);
		UIHelper.highlightElement(getDriver(), xPathEle2);
		xPathEle2.selectByVisibleText(Value1);
	}

	public void enterValueWithoutRef(String value, String xPText) {
		String propname1 = xPText;
		WebElementFacade xPathEle1 = (find(By.xpath(xpimp.XPath(propname1))));
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", xPathEle1);
		xPathEle1.waitUntilEnabled().waitUntilVisible();
		UIHelper.highlightElement(getDriver(), xPathEle1);
		xPathEle1.clear();
		waitFor(500).milliseconds();
		xPathEle1.type(value);
	}

	public void selectValueWithoutRef(String value, String xPText) {
		String propname1 = xPText;
		WebElementFacade xPathEle1 = (find(By.xpath(xpimp.XPath(propname1))));
		xPathEle1.waitUntilEnabled().waitUntilVisible();
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", xPathEle1);
		UIHelper.highlightElement(getDriver(), xPathEle1);
		xPathEle1.selectByVisibleText(value);
	}

	public void createUDFWithDataTypeMethod(String DispText, String DataType,
			String Expression, String xPText, String xPText2) {
		String propname1 = xPText;
		WebElementFacade xPathEle1 = (find(By.xpath(xpimp.XPath(propname1))));
		xPathEle1.waitUntilEnabled().waitUntilVisible();
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", xPathEle1);
		UIHelper.highlightElement(getDriver(), xPathEle1);
		xPathEle1.clear();
		xPathEle1.type(DispText);
		String propname2 = xPText2;
		WebElementFacade xPathEle2 = (find(By.xpath(xpimp.XPath(propname2))));
		xPathEle2.waitUntilEnabled().waitUntilVisible();
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", xPathEle2);
		waitFor(1000).milliseconds();
		UIHelper.highlightElement(getDriver(), xPathEle2);
		xPathEle2.selectByVisibleText(DataType);
		if (DataType.equals("Calculated")) {
			UIHelper.waitForPageToLoad(getDriver());
			expressionValue.clear();
			expressionValue.type(Expression);
			submitExp.click();
		}
	}

	public void click_Edit_Score_Card_BtnMethod(String ScorecardName) {
		String scorecardXpath = "//*[@id='dashboard']//*[@class='dashboard_row']//a[contains(.,'"
				+ ScorecardName
				+ "')]//following-sibling::div[@class='move_widget_dropdown']/a[contains(@class,'edit')]";
		WebElementFacade scorecardElement = find(By.xpath(scorecardXpath));
		scorecardElement.waitUntilEnabled().waitUntilVisible();
		UIHelper.highlightElement(getDriver(), scorecardElement);
		scorecardElement.click();
		UIHelper.waitForPageToLoad(getDriver());
	}

	public void click_Delete_Score_Card_BtnMethod(String ScorecardName) {
		String scorecardXpath = "//*[@id='dashboard']//*[@class='dashboard_row']//a[contains(.,'"
				+ ScorecardName
				+ "')]//following-sibling::div[@class='move_widget_dropdown']/a[contains(@class,'close')]";
		WebElementFacade scorecardElement = find(By.xpath(scorecardXpath));
		scorecardElement.waitUntilEnabled().waitUntilVisible();
		UIHelper.highlightElement(getDriver(), scorecardElement);
		scorecardElement.click();
		try{
		alertProcessModel();
		UIHelper.waitForPageToLoad(getDriver());
		}catch (Exception p) {

		}
		}

	public void enterApplicationNameAndSaveInFile(String TemplateName,
			String FilePathName, String xPText) throws IOException {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssms");
		Date date = new Date();
		String applicationname = TemplateName + dateFormat.format(date);
		String filePath1 = System.getProperty("user.dir");
		String mypath = filePath1.replace(":", ":\\");
		String filePath = mypath + FilePathName;
		System.out.println("File Path============" + filePath);
		FileWriter fstreamWrite = new FileWriter(filePath, false);
		BufferedWriter out = new BufferedWriter(fstreamWrite);
		out.write(applicationname);
		out.write("\r\n");
		out.close();
		fstreamWrite.close();
		String propname1 = xPText;
		UIHelper.waitForPageToLoad(getDriver());
		WebElementFacade xPathEle1 = (find(By.xpath(xpimp.XPath(propname1))));
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), xPathEle1);
		xPathEle1.clear();
		xPathEle1.type(applicationname);
	}

	public void FolderYes(String name, String xPText) {
		try {
			WebElementFacade xPathEle = (find(By
					.xpath(xpimp.XPath(name, xPText))));
			xPathEle.waitUntilEnabled().waitUntilVisible();
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].scrollIntoView(true);", xPathEle);
			UIHelper.highlightElement(getDriver(), xPathEle);
			xPathEle.click();
			WebElementFacade submitbtn = (find(By
					.xpath("//input[contains(@value,'XPValue')]")));
			submitbtn.click();
			UIHelper.waitForPageToLoad(getDriver());
		} catch (Exception e) {

		}
	}
	/*
	 * public void deleteRecordForManageAccount(){ WebElementFacade
	 * accSecEle=find(By.xpath(
	 * "//div[@class='vaps_leftContainer']//div[contains(@class,'vaps_main')]"
	 * )); String[] sectionList = accSecEle.getText(); for(String clickAccSec :
	 * sectionList){
	 * 
	 * } }
	 */
}