package com.dnb.automation.bd.pages;

import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

/******************************************************************************************************
 * Description : BDTabsPage class contains locators and methods for business directory main tabs.
 * 
 *******************************************************************************************************/

public class BDTabsPage extends PageObject {
	

	@FindBy(xpath = "//*[@id='navigation']//a[contains(text(),'HOME')]")
    private WebElementFacade tabHOME;

	@FindBy(xpath = "//*[@id='navigation']//a[contains(text(),'D-U-N-S NUMBER')]")
    private WebElementFacade tabDUNSNUMBER;

	@FindBy(xpath = "//*[@id='navigation']//a[contains(text(),'GET DUNS REGISTERED')]")
    private WebElementFacade tabGETDUNSREGISTERED;
	
	@FindBy(xpath = "//*[@id='navigation']//a[contains(text(),'MY ACCOUNT')]")
    private WebElementFacade tabMYACCOUNT;

	@FindBy(xpath = "//*[@id='navigation']//a[contains(text(),'MY DASHBOARD')]")
    private WebElementFacade tabMYDASHBOARD;
	
	@FindBy(xpath = "//*/a[@id='mydetails']")
    private WebElementFacade myDetailsTab;
	
	String loadicon="//*/div[@class='loadmask-msg']";
		
    /***********************************************************************************
     * Function: Home tab selection verification 
     * Input : NA 
     * Action : NA 
     * Output : NA
     ***********************************************************************************/
    public boolean getHomeTabSelection() throws Exception {    	
/*        if (tabHOME.getAttribute("class") != null) {
            return true;
        } else {
            return false;
        }
*/    	return tabHOME.getAttribute("class") != null;
    	}
	
    /***********************************************************************************
     * Function: Duns Number tab selection verification 
     * Input : NA 
     * Action : NA 
     * Output : NA
     ***********************************************************************************/
    public boolean getDUNSNUMBERTabSelection() throws Exception {    	
/*        if (tabDUNSNUMBER.getAttribute("class") != null) {
            return true;
        } else {
            return false;
        }
*/    	return tabDUNSNUMBER.getAttribute("class") != null;
    	}
	
    /***********************************************************************************
     * Function: Get Duns Registered tab selection verification 
     * Input : NA 
     * Action : NA 
     * Output : NA
     ***********************************************************************************/
    public boolean getGETDUNSREGISTEREDTabSelection() throws Exception {    	
/*        if (tabGETDUNSREGISTERED.getAttribute("class") != null) {
            return true;
        } else {
            return false;
        }
*/	    return tabGETDUNSREGISTERED.getAttribute("class") != null;
    	}

    /***********************************************************************************
     * Function: My Account tab selection verification 
     * Input : NA 
     * Action : NA 
     * Output : NA
     ***********************************************************************************/
    public boolean getMYACCOUNTTabSelection() throws Exception {    	
/*        if (tabMYACCOUNT.getAttribute("class") != null) {
            return true;
        } else {
            return false;
        }
*/    	return tabMYACCOUNT.getAttribute("class") != null;
    	}

    /***********************************************************************************
     * Function: Select My account tab 
     * Input : NA 
     * Action : NA 
     * Output : NA
     ***********************************************************************************/
    public boolean selectMYACCOUNTTab()
    {    	
    	UIHelper.waitForPageToLoad(getDriver());
    	tabMYACCOUNT.click();
    	UIHelper.waitForPageToLoad(getDriver());
    	return tabMYACCOUNT.getAttribute("class") != null;
   	}
    /******************************************************************************
    * Function: Select My Details tab 
    * Input : NA 
    * Action : NA 
    * Output : NA
   ***********************************************************************************/
   /*public boolean myDetailsTab()
   {    	
   	UIHelper.waitForPageToLoad(getDriver());
   	myDetailsTab.click();
   	UIHelper.waitForPageToLoad(getDriver());
   	UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), loadicon);
   	return myDetailsTab.getAttribute("class") != null;
  	} */  
    /***********************************************************************************
     * Function: Dashboard tab selection verification 
     * Input : NA 
     * Action : NA 
     * Output : NA
     ***********************************************************************************/
    public boolean getMYDASHBOARDTabSelection() throws Exception {
/*        if (tabMYDASHBOARD.getAttribute("class") != null) {
            return true;
        } else {
            return false;
        }
*/        return tabMYDASHBOARD.getAttribute("class") != null;
    }
	
    /***********************************************************************************
     * Function: Select Get Duns RegisteredTab 
     * Input : NA 
     * Action : NA 
     * Output : NA
     ***********************************************************************************/
	public boolean SelectGetDunsRegisteredTab() {		
		UIHelper.waitForPageToLoad(getDriver());
		tabGETDUNSREGISTERED.click();
    	UIHelper.waitForPageToLoad(getDriver());
    	return tabGETDUNSREGISTERED.getAttribute("class") != null;
		
	}

    /***********************************************************************************
     * Function: Select Home Tab 
     * Input : NA 
     * Action : NA 
     * Output : NA
     ***********************************************************************************/	
	public boolean SelectHomeTab() {
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
		tabHOME.click();
    	UIHelper.waitForPageToLoad(getDriver());
    	return tabHOME.getAttribute("class") != null;
		
	}


}
