package com.dnb.automation.utils;

import java.io.File;
import java.util.HashSet;


public class FileCache {

	private static HashSet<File> fileCache=new HashSet<File>();
	
	private FileCache() {

	}
	
	public static HashSet<File> getCache() { 
		return fileCache;
	}
	
	public static void addToCache(File f) {
		fileCache.add(f);
	}
	
	public static void clearCache() {
		fileCache=new HashSet<>();
	}
	
	public static void deleteCache() {
		for (File f: fileCache) {
			System.out.println("Deleting: " + f.toString());
			try {
				f.delete();
			}catch (Exception e) {
				e.printStackTrace();
				// Clean up as many files as we can..
			}
		}
		clearCache();
	}

	@Override
	protected void finalize() throws Throwable {
		deleteCache();
		super.finalize();
	}

	
}
