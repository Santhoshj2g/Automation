package com.dnb.automation.onboard.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class LoadProperties 
{
	@SuppressWarnings("resource")
	public Properties CommentryMapping(){
		    Properties commentryprop = new Properties ();
		    InputStream is = null;

		    // First try loading from the current directory
		    try {
		        File f = new File("src/test/resources/AppTestData/onboard/CommentryMapping.properties");
		        is = new FileInputStream( f );
		    }
		    catch ( Exception e ) { e.printStackTrace();is = null; }

		    try {
		        if ( is == null ) {
		            // Try loading from classpath
		            is = getClass().getResourceAsStream("src/test/resources/AppTestData/onboard/CommentryMapping.properties");
//		            ClassLoader classLoader = getClass().getClassLoader();
//		            File configurationFile = new File(classLoader.getResource(CONFIGURATION_FILE_NAME).getFile());
		        }

		        // Try loading properties from the file (if found)
		        commentryprop.load( is );
		    }
		    catch ( Exception e ) { e.printStackTrace();}
			return commentryprop;
		}
}
