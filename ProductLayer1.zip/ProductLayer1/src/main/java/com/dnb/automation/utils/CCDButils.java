package com.dnb.automation.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.dnb.automation.Constants;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class CCDButils {
	private static CCDButils ccdb = null;

	Connection connect = null;

	private CCDButils() throws ClassNotFoundException {
		try {
			Class.forName(System.getProperty(Constants.JDBC_DRIVER));
		} catch (ClassNotFoundException ex) {
			throw ex;
		}
	}

	public static CCDButils getInstance() {
		if (ccdb == null) {
			try {
				ccdb=new CCDButils();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		return ccdb;
	}
	private Connection getConnection() throws SQLException {
		if (connect == null) {
			try {
				connect = DriverManager.getConnection(System.getProperty(Constants.JDBC_CONNECTION_STRING),
						System.getProperty(Constants.JDBC_USER_NAME), System.getProperty(Constants.JDBC_PASSWORD));				
			} catch (SQLException ex) {
				throw ex;
			}
		}

		return connect;
	}

	@Override
	protected void finalize() throws Throwable {
		if (connect != null) {
			try {
				connect.close();
			} catch (Exception e) {
			}
		}
		super.finalize();
	}

	public int executeDDL(String query, Object[] parameters) throws SQLException {
		int count = -1;
		PreparedStatement stmt = null;
		try {

			stmt = getConnection().prepareStatement(query);
			for (int indx = 0; indx < parameters.length; indx++) {
				stmt.setObject(indx + 1, parameters[indx]);
			}
			count = stmt.executeUpdate(query);
		} catch (SQLException ex) {
			throw ex;
		} finally {
			closeStmtRS(stmt, null);
		}

		return count;
	}

	private void closeStmtRS(Statement stmt, ResultSet rs) {

		if (rs != null) {
			try {
				rs.close();
			} catch (Exception e) {
			}
		}

		if (stmt != null) {
			try {
				stmt.close();
			} catch (Exception e) {
			}
		}
	}

	public List<Map<String, Object>> selectStatement(String query, Object[] parameters) throws SQLException {
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<Map<String, Object>> results = new ArrayList<Map<String, Object>>();
		try {
			stmt = getConnection().prepareStatement(query);
			if (parameters != null) {
				for (int indx = 0; indx < parameters.length; indx++) {
					stmt.setObject(indx + 1, parameters[indx]);
				}
			}

			rs = stmt.executeQuery();
			ResultSetMetaData rsMetaData = stmt.getMetaData();

			while (rs.next()) {
				Map<String, Object> row = new HashMap<String, Object>();
				for (int indx = 1; indx <= rsMetaData.getColumnCount(); indx++) {
					row.put(rsMetaData.getColumnLabel(indx).toUpperCase(), rs.getObject(indx));
				}
				results.add(row);
			}

		} catch (SQLException ex) {
			throw ex;
		} finally {
			closeStmtRS(stmt, rs);
		}

		return results;
	}

	public void closeConnection() {
		if (connect != null) {
			try {
				connect.close();
				connect = null;
			} catch (Exception e) {
			}
		}
	}

}
