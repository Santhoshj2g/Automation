package com.dnb.automation.utils;

public class Rules {
	
   /* public static void Test(String x) {
    System.out.println("in test -- " +x);
    }
    */
	
	private String serviceValue;
	private String UIElementValue;
	private int flag;
	
	
	public String getServiceValue() {
		return serviceValue;
	}	

	public String getUIElementValue() {
		return UIElementValue;
	}
	
	public int getFlag() {
		return flag;
	}

	public Rules(String serviceValue,String UIElementValue)
	{		
		this.serviceValue = serviceValue;
	    this.UIElementValue = UIElementValue;
	}
	
	public Rules(String serviceValue,String UIElementValue,int flag)
	{		
		this.serviceValue = serviceValue;
	    this.UIElementValue = UIElementValue;
	    this.flag=flag;
	}
	
	public static Rules COMPNAME(String UIElementValue,String serviceValue)
	{
		System.out.println("**************************");
		System.out.println("inside COMPNAME");
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
	
		return new Rules(serviceValue,UIElementValue);
	}
	
    public static Rules DUNS(String UIElementValue,String serviceValue) {
    	
    	String[] dunsVal=UIElementValue.split("-");	
		UIElementValue="";
		if(dunsVal.length>0)
		{
			if(dunsVal!=null)
			{			
				for(int index=0;index<dunsVal.length;index++)
				{				
					UIElementValue=UIElementValue+dunsVal[index];							
				}	
			}
			else
			{
				UIElementValue=null;
			}
		}
		System.out.println("**************************");
		System.out.println("inside DUNS");
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
	
		return new Rules(serviceValue,UIElementValue);
    }
    
    public static Rules ADDR1(String UIElementValue,String serviceValue)
	{
    	System.out.println("**************************");
		System.out.println("inside ADDR1");
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
	
		return new Rules(serviceValue,UIElementValue);
	}    
    
    public static Rules TOWN(String UIElementValue,String serviceValue) {
    	System.out.println("**************************");
		System.out.println("inside TOWN");
		if(serviceValue.equals("") && UIElementValue.contains("-"))
		{
			System.out.println("inside null MAILCNTRY");		
			serviceValue="-";
		}
		else if(!UIElementValue.equals("-") || !UIElementValue.equals(null))
		{
	    	String[] town=UIElementValue.split(",");
	    	if(town.length>0)
	    	{
				if(town[0]!=null || !town[0].isEmpty())
				{
					UIElementValue=town[0];
				}
				else
				{
					UIElementValue=null;
				}
	    	}
		}
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
	
		return new Rules(serviceValue,UIElementValue);
   }
    
        
    public static Rules POSTCODE(String UIElementValue,String serviceValue) {
    	System.out.println("**************************");
		System.out.println("inside POSTCODE");
		if(serviceValue.equals("") && UIElementValue.contains("-"))
		{
			System.out.println("inside null MAILCNTRY");		
			serviceValue="-";
		}
		else if(!UIElementValue.equals("-") || !UIElementValue.equals(null))
		{
			String[] town=UIElementValue.split(",");
			System.out.println("array length:"+town.length);
			if(town.length>2)
			{
				if(town[2].trim()!=null || !town[2].trim().isEmpty())
				{
					UIElementValue=town[2].trim();
				}
				else
				{
					UIElementValue=null;
				}
			}
		}
		
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
	
		return new Rules(serviceValue,UIElementValue);
    }
    
    public static Rules ABBR(String UIElementValue,String serviceValue) {
    	System.out.println("**************************");
		System.out.println("inside ABBR");
		if(serviceValue.equals("") && UIElementValue.contains("-"))
		{
			System.out.println("inside null MAILCNTRY");		
			serviceValue="-";
		}
		else if(!UIElementValue.equals("-") || !UIElementValue.equals(null))
		{
	    	String[] town=UIElementValue.split(",");  
	    	if(town.length>1)
	    	{
				if(town[1].trim()!=null || !town[1].trim().isEmpty())
				{
					UIElementValue=town[1].trim();
				}
				else
				{
					UIElementValue=null;
				}
	    	}
		}
		
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
	
		return new Rules(serviceValue,UIElementValue);
    }
    
    public static Rules COUNTRY(String UIElementValue,String serviceValue)
   	{
    	System.out.println("**************************");
		System.out.println("inside COUNTRY");
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
		if(serviceValue.equals("") && UIElementValue.contains("-"))
		{
			System.out.println("inside null MAILCNTRY");		
			serviceValue="-";
		}		
	
   		return new Rules(serviceValue,UIElementValue);
   	}   
    
 
    public static Rules TRADESTYL(String UIElementValue,String serviceValue)
   	{
    	System.out.println("**************************");
		System.out.println("inside TRADESTYL");
		if(serviceValue.equals("") && UIElementValue.contains(""))
		{
			System.out.println("inside null TRADESTYL");		
			serviceValue="-";
			UIElementValue="-";
		}
		else if((!serviceValue.equals("") || !serviceValue.equals(null)) && !UIElementValue.contains(""))
		{
			String[] tradeStyle=UIElementValue.split(":");
			if(tradeStyle.length>1)
			{
				UIElementValue=tradeStyle[1].trim();
			}
		}
		else if(!serviceValue.equals("") && UIElementValue.equals(""))
		{
			UIElementValue="";
		}			
		
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
		
   		return new Rules(serviceValue,UIElementValue);
   	} 
       
    
    public static Rules TELE(String UIElementValue,String serviceValue) {
    	System.out.println("**************************");
		System.out.println("inside TELE");
    	String[] tele=UIElementValue.split("\\(");	
    	System.out.println("length :"+tele.length);
    	if(tele.length>0)
    	{
    		String[] telephone=tele[1].split(java.util.regex.Pattern.quote(")"));	 
    		if(telephone.length>0)
    		{
    			String[] no=telephone[1].trim().split("-");	   
        		if(no.length>0)
        		{
        			UIElementValue=telephone[0]+no[0]+no[1];
        		}
    		}    		    		
    	}		
		
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
		
		return new Rules(serviceValue,UIElementValue);
        }
    
    
    public static Rules TELECODE(String UIElementValue,String serviceValue) {
    	System.out.println("**************************");
		System.out.println("inside TELECODE");
    	String[] tele=UIElementValue.split("\\(");	
    	if(tele.length>0)
    	{
    		UIElementValue=tele[0].trim();
    	}
		
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
		
		return new Rules(serviceValue,UIElementValue);
        }
    
    
    public static Rules LOCTYP(String UIElementValue,String serviceValue) {
    	System.out.println("**************************");
		System.out.println("inside LOCTYP");
		if(serviceValue==null || serviceValue.isEmpty())
		{
			System.out.println("service value null/empty for loctype");
			if(UIElementValue.equalsIgnoreCase("Branch") || UIElementValue.equalsIgnoreCase("Headquarters") || 
					UIElementValue.equalsIgnoreCase("Subsidy"))
			{	    						
				UIElementValue="true";
				serviceValue="true";
			}
		}
		else if(serviceValue.equalsIgnoreCase("true"))
		{
			System.out.println("else if loctyp is true");
			if(!UIElementValue.equalsIgnoreCase("Branch") && !UIElementValue.equalsIgnoreCase("Headquarters") && 
					!UIElementValue.equalsIgnoreCase("Subsidy") && UIElementValue.contains("null"))
			{
				System.out.println("ui ele contains null");
				UIElementValue="true";
			}
		}
		
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
	
		return new Rules(serviceValue,UIElementValue);
    }
	
    public static Rules STATEOFINCORP(String UIElementValue,String serviceValue) {
    	System.out.println("**************************");
		System.out.println("inside STATEOFINCORP");
    	if(serviceValue==null)
		{
    		UIElementValue="StateOfIncorp";
			serviceValue="StateOfIncorp";			
		} 
		else if(UIElementValue.contains("Registered "+serviceValue+" Law") || UIElementValue.equalsIgnoreCase("Registered "+serviceValue+" Law"))
		{
/*			UIElementValue="StateOfIncorpAvailable";
			serviceValue="StateOfIncorpAvailable";	    					
*/		
			UIElementValue="Registered "+serviceValue+" Law";
			serviceValue="Registered "+serviceValue+" Law";	
		}
    	
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
	
    	return new Rules(serviceValue,UIElementValue);
       }
  
	
    public static Rules CNTRYOFINCORP(String UIElementValue,String serviceValue,Boolean elementDisplayed,int flag) {
    	System.out.println("**************************");
		System.out.println("inside CNTRYOFINCORP");
    	if(serviceValue==null && flag==1 && !elementDisplayed)
		{
    		System.out.println("inside if of cntry");
			UIElementValue="true";
			serviceValue="true";
		}
		else if(serviceValue!=null && flag==1)
		{
			System.out.println("inside else of cntry");
			if(serviceValue.equalsIgnoreCase("CA"))
			{
				if(UIElementValue.equalsIgnoreCase("Registered Federal Law") || UIElementValue.contains("Registered Federal Law"))
				{
					UIElementValue="Registered Federal Law";
					serviceValue="Registered Federal Law";
				}
			}	    					
		}
		else if(flag!=1)
		{
			System.out.println("inside else of cntry flag!=1");
			flag=3;
		}
    	
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
	
    	return new Rules(serviceValue,UIElementValue,flag);
        }
    
    public static Rules MAILADDDR(String UIElementValue,String serviceValue) {
    	System.out.println("**************************");
		System.out.println("inside MAILADDDR");
		System.out.println("UI val:"+UIElementValue);
		System.out.println("services val:"+serviceValue+":");
//		if(serviceValue.equals("") && UIElementValue.contains("-"))
		if(serviceValue==null && UIElementValue.contains("-"))
		{
			System.out.println("inside null addr");			
			serviceValue="-";
		}
/*		else if(UIElementValue.contains(serviceValue) || UIElementValue.equalsIgnoreCase(serviceValue))
		{
			System.out.println("inside contains addr");
			UIElementValue="true";
			serviceValue="true";
		}
	*/
				
		return new Rules(serviceValue,UIElementValue);
        }
        
    
    public static Rules MAILTOWN(String UIElementValue,String serviceValue) {
    	System.out.println("**************************");
		System.out.println("inside MAILTOWN");
//		if(serviceValue.equals("") && UIElementValue.contains("-"))
		if(serviceValue==null && UIElementValue.contains("-"))
		{
			System.out.println("inside null MAILTOWN");
			serviceValue="-";
		}
	/*	else if(UIElementValue.contains(serviceValue) || UIElementValue.equalsIgnoreCase(serviceValue))
		{
			System.out.println("inside contains MAILTOWN");
			UIElementValue="true";
			serviceValue="true";
		}
	*/	
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
		
		return new Rules(serviceValue,UIElementValue);
        }
        
    
    public static Rules MAILSTATE(String UIElementValue,String serviceValue) {
    	System.out.println("**************************");
		System.out.println("inside MAILSTATE");
//		if(serviceValue.equals("") && UIElementValue.contains("-"))
		if(serviceValue==null && UIElementValue.contains("-"))
		{
			System.out.println("inside null MAILSTATE");
			serviceValue="-";
		}
/*		else if(UIElementValue.contains(serviceValue) || UIElementValue.equalsIgnoreCase(serviceValue))
		{
			System.out.println("inside contains MAILSTATE");
			UIElementValue="true";
			serviceValue="true";
		}
		*/
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
	
		return new Rules(serviceValue,UIElementValue);
        }
        
    
    public static Rules MAILPOST(String UIElementValue,String serviceValue) {
    	System.out.println("**************************");
		System.out.println("inside MAILPOST");
    	
//		if(serviceValue.equals("") && UIElementValue.contains("-"))
		if(serviceValue==null && UIElementValue.contains("-"))
		{
			System.out.println("inside null MAILPOST");			
			serviceValue="-";
		}
	/*	else if(UIElementValue.contains(serviceValue) || UIElementValue.equalsIgnoreCase(serviceValue))
		{
			System.out.println("inside contains MAILPOST");
			UIElementValue="true";
			serviceValue="true";
		}
	*/	
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
		
		return new Rules(serviceValue,UIElementValue);
        }
        
    
    public static Rules MAILCNTRY(String UIElementValue,String serviceValue) {
    	System.out.println("**************************");
		System.out.println("inside MAILCNTRY");
    	
//		if(serviceValue.equals("") && UIElementValue.contains("-"))
		if(serviceValue==null && UIElementValue.contains("-"))
		{
			System.out.println("inside null MAILCNTRY");		
			serviceValue="-";
		}
	/*	else if(UIElementValue.contains(serviceValue) || UIElementValue.equalsIgnoreCase(serviceValue))
		{
			System.out.println("inside contains MAILCNTRY");
			UIElementValue="true";
			serviceValue="true";
		}
	*/	
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
		
		return new Rules(serviceValue,UIElementValue);
	}
    
    
    public static Rules FAXNO(String UIElementValue,String serviceValue) {
    	System.out.println("**************************");
		System.out.println("inside FAXNO");
//		if(serviceValue.equals("") && UIElementValue.contains("-"))
		if(serviceValue==null && UIElementValue.contains("-"))
		{
			System.out.println("inside null MAILCNTRY");		
			serviceValue="-";
		}
		else if(!UIElementValue.equals("-") || !UIElementValue.equals(null))
		{
			System.out.println("inside if1");
	    	String[] tele=UIElementValue.split("\\(");	
	    	if(tele.length>1)
	    	{
	    		System.out.println("inside if2"+tele.length);
	    		String[] telephone=tele[1].split(java.util.regex.Pattern.quote(")"));
	    		if(telephone.length>0)
	    		{
		    		String[] no=telephone[1].trim().split("-");	
		    		if(no.length>0)
		    		{
		    			UIElementValue=telephone[0]+no[0]+no[1];
		    		}  
	    		}
	    	}	
		}
		
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
		
		return new Rules(serviceValue,UIElementValue);
        }
    
    
    public static Rules FAXCODE(String UIElementValue,String serviceValue) {
    	System.out.println("**************************");
		System.out.println("inside FAXCODE");
//		if(serviceValue.equals("") && UIElementValue.contains("-"))
		if(serviceValue==null && UIElementValue.contains("-"))
		{
			System.out.println("inside null MAILCNTRY");		
			serviceValue="-";
		}
		else if(!UIElementValue.equals("-") || !UIElementValue.equals(null))
		{
	    	String[] tele=UIElementValue.split("\\(");	
	    	if(tele.length>0)
	    	{
	    		UIElementValue=tele[0].trim();
	    	}
		}
		
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
		
		return new Rules(serviceValue,UIElementValue);
        }
    
    public static Rules DATEOFINCORP(String UIElementValue,String serviceValue) {
    	System.out.println("**************************");
		System.out.println("inside DATEOFINCORP");
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
		
		return new Rules(serviceValue,UIElementValue);
        }
    
	 public static Rules LEGALFORM(String UIElementValue,String serviceValue) {
		 	System.out.println("**************************");
			System.out.println("inside LEGALFORM");
			System.out.println(UIElementValue);
			System.out.println(serviceValue);
			
			return new Rules(serviceValue,UIElementValue);
	     }    
	 
	 public static Rules SIC(String UIElementValue,String serviceValue) {
	 	
		 //add code
		 	System.out.println("**************************");
			System.out.println("inside SIC");
			System.out.println(UIElementValue);
			System.out.println(serviceValue);
			
			return new Rules(serviceValue,UIElementValue);
	     }
	 
	 public static Rules SICDESC(String UIElementValue,String serviceValue) {
	 	
		 //add code
		 	System.out.println("**************************");
		 	System.out.println("inside SICDESC");
			System.out.println(UIElementValue);
			System.out.println(serviceValue);
			
			return new Rules(serviceValue,UIElementValue);
	     }
	 
     public static Rules MAPTOWN(String UIElementValue,String serviceValue) 
     {
//    	if(serviceValue.equals("") && UIElementValue.contains(""))
    	if(serviceValue==null && UIElementValue.contains(""))
 		{
 			System.out.println("inside null TRADESTYL");		
 			serviceValue="-";
 			UIElementValue="-";
 		}
    	else
    	{
		     String[] town = UIElementValue.split(",");
		     // String[] addr1=addr[1].split(" ");
		     UIElementValue = town[0].substring(town[0].lastIndexOf(" ")).trim();		    
    	}
    	System.out.println(UIElementValue);
		System.out.println(serviceValue);
    	
 		return new Rules(serviceValue,UIElementValue);     
     }
     
     public static Rules MAPADDR1(String UIElementValue,String serviceValue) {
//    	if(serviceValue.equals("") && UIElementValue.contains(""))
    	if(serviceValue==null && UIElementValue.contains(""))
  		{
  			System.out.println("inside null TRADESTYL");		
  			serviceValue="-";
  			UIElementValue="-";
  		}
     	else
     	{
            String[] town = UIElementValue.split(",");
            String townName = town[0].substring(town[0].lastIndexOf(" "));
            String addrLine = town[0].replace(townName, " ");
            UIElementValue = addrLine.trim();           
     	}
    	 	System.out.println(UIElementValue);
 			System.out.println(serviceValue);
        	return new Rules(serviceValue,UIElementValue);
     }

     public static Rules MAPABBR(String UIElementValue,String serviceValue) {
//    	if(serviceValue.equals("") && UIElementValue.contains(""))
    	if(serviceValue==null && UIElementValue.contains(""))
   		{
   			System.out.println("inside null TRADESTYL");		
   			serviceValue="-";
   			UIElementValue="-";
   		}
      	else
      	{
    	 	String[] town = UIElementValue.split(",");
            String townName1 = town[1].trim();
            String[] townName2 = townName1.split(" ");
            UIElementValue = townName2[0];            
      	}
    		System.out.println(UIElementValue);
 			System.out.println(serviceValue);
        	return new Rules(serviceValue,UIElementValue);
     }
     
     public static Rules MAPPOSTCODE(String UIElementValue,String serviceValue) {
//    	if(serviceValue.equals("") && UIElementValue.contains(""))
    	if(serviceValue==null && UIElementValue.contains(""))
		{
			System.out.println("inside null TRADESTYL");		
			serviceValue="-";
			UIElementValue="-";
		}
       	else
       	{
    	 	String[] town = UIElementValue.split(",");
            String townName1 = town[1].trim();
            String[] townName2 = townName1.split(" ");
            UIElementValue = townName2[1] + " " + townName2[2];           
       	}
			System.out.println(UIElementValue);
			System.out.println(serviceValue);
        	return new Rules(serviceValue,UIElementValue);
     }

     public static Rules MAPCOUNTRY(String UIElementValue,String serviceValue) {
//    	if(serviceValue.equals("") && UIElementValue.contains(""))
    	if(serviceValue==null && UIElementValue.contains(""))
 		{
 			System.out.println("inside null TRADESTYL");		
 			serviceValue="-";
 			UIElementValue="-";
 		}
    	else
    	{
    	 	String[] town = UIElementValue.split(",");
            String townName1 = town[1].trim();
            String[] townName2 = townName1.split(" ");
            UIElementValue = townName2[3];          
    	}
		System.out.println(UIElementValue);
		System.out.println(serviceValue);
        return new Rules(serviceValue,UIElementValue);
     }	 
	 
	 public static Rules FAILPER(String UIElementValue,String serviceValue) {
		 	System.out.println("**************************");
			System.out.println("inside FAILPER");
			
//			if(serviceValue.equals("") && UIElementValue.contains("-"))
			if(serviceValue==null && UIElementValue.contains("-"))
			{
				System.out.println("inside null FAILPER");		
				serviceValue="-";
			}
//			else if(!serviceValue.equals("") && UIElementValue.equals(""))
			else if(serviceValue!=null && UIElementValue.equals(""))
			{
				UIElementValue="";
			}	
			System.out.println(UIElementValue);
			System.out.println(serviceValue);
			return new Rules(serviceValue,UIElementValue);
	     }
	 
	 public static Rules DELINQ(String UIElementValue,String serviceValue) {
		 	System.out.println("**************************");
			System.out.println("inside DELINQ");
//			if(serviceValue.equals("") && UIElementValue.contains("-"))
			if(serviceValue==null && UIElementValue.contains("-"))
			{
				System.out.println("inside null DELINQ");		
				serviceValue="-";
			}
//			else if(!serviceValue.equals("") && UIElementValue.equals(""))
			else if(serviceValue!=null && UIElementValue.equals(""))
			{
				UIElementValue="";
			}	
			System.out.println(UIElementValue);
			System.out.println(serviceValue);			
			return new Rules(serviceValue,UIElementValue);
	     }
	 
	 public static Rules INSOLVIND(String UIElementValue,String serviceValue) {
		 	System.out.println("**************************");
			System.out.println("inside INSOLVIND");
			System.out.println("UIElementValue :"+UIElementValue);
			System.out.println("serviceValue :"+serviceValue+":");
			if(serviceValue==null && UIElementValue.contains("No"))
			{
				System.out.println("inside null INSOLVIND");		
				serviceValue="No";
			}
			else if(serviceValue.equalsIgnoreCase("true") && UIElementValue.equalsIgnoreCase("Yes"))
			{
				UIElementValue="true";
			}
	/*		else if(serviceValue.equals("") && UIElementValue.contains("No"))
			{
				System.out.println("inside else2 INSOLVIND");		
				serviceValue="No";
			}		
		*/	
	        return new Rules(serviceValue,UIElementValue);
	  }    
	       
	public static Rules JUDGEIND(String UIElementValue,String serviceValue) {
	    	System.out.println("**************************");
	   		System.out.println("inside JUDGEIND");
	 //  		if(serviceValue.equals("") && UIElementValue.contains("0"))
	   		if(serviceValue==null && UIElementValue.contains("0"))	   		
			{
				System.out.println("inside null MAILCNTRY");		
				serviceValue="0";
			}
			
	   		System.out.println(UIElementValue);
	   		System.out.println(serviceValue);    
	        return new Rules(serviceValue,UIElementValue);
	  }
	       
	 public static Rules JUDGEVALUE(String UIElementValue,String serviceValue) {
		 	System.out.println("**************************");
			System.out.println("inside JUDGEVALUE");
			System.out.println(UIElementValue);
			System.out.println(serviceValue);	
			if(serviceValue==null && UIElementValue!="")
			{				
				UIElementValue=UIElementValue.replace("$","");
				serviceValue="0";
			}
			else if(serviceValue!=null && UIElementValue!="")
			{
				UIElementValue=UIElementValue.replace("$","");
			}	
	        return new Rules(serviceValue,UIElementValue);
	  }
	       
	 public static Rules JUDGEFILED(String UIElementValue,String serviceValue) {
		 	System.out.println("**************************");
			System.out.println("inside JUDGEFILED");
//			if(serviceValue.equals("") && UIElementValue.contains("-"))
			if(serviceValue==null && UIElementValue.contains("-"))
			{
				System.out.println("inside null MAILCNTRY");		
				serviceValue="-";
			}
			
			System.out.println(UIElementValue);
			System.out.println(serviceValue);    
			
	        return new Rules(serviceValue,UIElementValue);
	  }

	 public static Rules LIENSIND(String UIElementValue,String serviceValue) {
		 	System.out.println("**************************");
			System.out.println("inside LIENSIND");
			System.out.println(UIElementValue);
			System.out.println(serviceValue); 
			if(serviceValue==null && UIElementValue.contains("0"))	   		
			{
				System.out.println("inside null MAILCNTRY");		
				serviceValue="0";
			}
	        return new Rules(serviceValue,UIElementValue);
	  }
	       
	 public static Rules LIENSVALUE(String UIElementValue,String serviceValue) {
		 	System.out.println("**************************");
			System.out.println("inside LIENSVALUE");
			if(serviceValue==null && UIElementValue!="")
			{				
				UIElementValue=UIElementValue.replace("$","");
				serviceValue="0";
			}
			else if(serviceValue!=null && UIElementValue!="")
			{
				UIElementValue=UIElementValue.replace("$","");
			}	
			
			System.out.println(UIElementValue);
			System.out.println(serviceValue);     
	        return new Rules(serviceValue,UIElementValue);
	  }
	       
	 public static Rules LIENSFILED(String UIElementValue,String serviceValue) {
		 	System.out.println("**************************");
			System.out.println("inside LIENSFILED");
			if(serviceValue==null && UIElementValue.contains("-"))
			{
				System.out.println("inside null MAILCNTRY");		
				serviceValue="-";
			}
			
			System.out.println(UIElementValue);
			System.out.println(serviceValue);
	        return new Rules(serviceValue,UIElementValue);
	  }
	       
	public static Rules SUITIND(String UIElementValue,String serviceValue) {
			System.out.println("**************************");
			System.out.println("inside SUITIND");
			if(serviceValue==null && UIElementValue.contains("0"))	   		
			{
				System.out.println("inside null MAILCNTRY");		
				serviceValue="0";
			}
			System.out.println(UIElementValue);
			System.out.println(serviceValue);              
	        return new Rules(serviceValue,UIElementValue);
	  }
	       
	 public static Rules SUITVALUE(String UIElementValue,String serviceValue) {
		 	System.out.println("**************************");
			System.out.println("inside SUITVALUE");
			if(serviceValue==null && UIElementValue!="")
			{				
				UIElementValue=UIElementValue.replace("$","");				
				serviceValue="0";
			}
			else if(serviceValue!=null && UIElementValue!="")
			{
				UIElementValue=UIElementValue.replace("$","");
				UIElementValue=UIElementValue.replace(",", "");
			}	
		
			System.out.println(UIElementValue);
			System.out.println(serviceValue);       
	        return new Rules(serviceValue,UIElementValue);
	  }
	       
	 public static Rules SUITFILED(String UIElementValue,String serviceValue) {
		 	System.out.println("**************************");
			System.out.println("inside SUITFILED");
			if(serviceValue==null && UIElementValue.contains("-"))
			{
				System.out.println("inside null MAILCNTRY");		
				serviceValue="-";
			}
			System.out.println(UIElementValue);
			System.out.println(serviceValue);     
	        return new Rules(serviceValue,UIElementValue);
	  }
	       
	 public static Rules PPSAIND(String UIElementValue,String serviceValue) {
		 	System.out.println("**************************");
			System.out.println("inside PPSAIND");
//			if(serviceValue.equals("") && UIElementValue.contains("0"))
			if(serviceValue==null && UIElementValue.contains("0"))
			{
				System.out.println("inside null MAILCNTRY");		
				serviceValue="0";
			}
			
			System.out.println(UIElementValue);
			System.out.println(serviceValue);      
	        return new Rules(serviceValue,UIElementValue);
	  }
	       
	 public static Rules PPSAVALUE(String UIElementValue,String serviceValue) {
		 	System.out.println("**************************");
			System.out.println("inside PPSAVALUE");
			if(serviceValue==null && UIElementValue!="")
			{				
				UIElementValue=UIElementValue.replace("$","");
				serviceValue="0";
			}
			else if(serviceValue!=null && UIElementValue!="")
			{
				UIElementValue=UIElementValue.replace("$","");
			}	
			System.out.println(UIElementValue);
			System.out.println(serviceValue);      
	        return new Rules(serviceValue,UIElementValue);
	  }
	       
	 public static Rules PPSAFILED(String UIElementValue,String serviceValue) {
		 	System.out.println("**************************");
			System.out.println("inside PPSAFILED");
			if(serviceValue==null && UIElementValue.contains("-"))
			{
				System.out.println("inside null MAILCNTRY");		
				serviceValue="-";
			}
			System.out.println(UIElementValue);
			System.out.println(serviceValue);    
	        return new Rules(serviceValue,UIElementValue);
	  }                                                                                                               

	 
	 public static Rules FAMILYTREEMEM(String UIElementValue,String serviceValue) {
		 	
	        return new Rules(serviceValue,UIElementValue);
	  }  
	 
	 public static Rules SUBSIDIARIES(String UIElementValue,String serviceValue) {
		 	
	        return new Rules(serviceValue,UIElementValue);
	  }  
	 
	 public static Rules BRANCHES(String UIElementValue,String serviceValue) {
		 	
	        return new Rules(serviceValue,UIElementValue);
	  }  
	 
	 public static Rules CURRENTASSETS(String UIElementValue,String serviceValue) {
		 	
	        return new Rules(serviceValue,UIElementValue);
	  }  
	 
	 public static Rules TOTALASSETS(String UIElementValue,String serviceValue) {
		 	
	        return new Rules(serviceValue,UIElementValue);
	  }  
	 
	 public static Rules CURRENTLIABILITIES(String UIElementValue,String serviceValue) {
		 	
	        return new Rules(serviceValue,UIElementValue);
	  }  
	 
	 public static Rules CAPITALORNETCURRASSETS(String UIElementValue,String serviceValue) {
		 	
	        return new Rules(serviceValue,UIElementValue);
	  }  
	 
	 public static Rules LONGTERMLIABILITIES(String UIElementValue,String serviceValue) {
		 	
	        return new Rules(serviceValue,UIElementValue);
	  }  
	    
 }
