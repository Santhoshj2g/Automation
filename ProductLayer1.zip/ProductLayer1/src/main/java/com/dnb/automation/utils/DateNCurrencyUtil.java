package com.dnb.automation.utils;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Currency;
import java.util.Date;
import java.util.Locale;

public class DateNCurrencyUtil {
	
    public static void main(String[] args) throws ParseException{
        long number = 100000;

        //
        // Format currency for Canada locale in Canada locale, 
        // the decimal point symbol is a comma and currency
        // symbol is $.
        //
        NumberFormat format = 
                NumberFormat.getCurrencyInstance(Locale.CANADA);
        
        String currency = format.format(number);
        System.out.println("Currency in Canada : " + currency);

        //
        // Format currency for Germany locale in German locale,
        // the decimal point symbol is a dot and currency symbol
        // is â‚¬.
        //
        format = NumberFormat.getCurrencyInstance(Locale.US);
        currency = format.format(number);
        System.out.println("Currency in Germany: " + currency);
       
    }
    
    
    /***********************************************************************************
      	@author Anitha 
      	
	*	Function: Format date
	*	Input 	: Services value
	*	Action	: format,parse
	*   Output  : return formatted date
	
	***********************************************************************************/
    public static String changeDateFormat(String dateInServices) throws ParseException
    {       	
    	DateFormat format1 = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
    	Date date=format1.parse(dateInServices);
        SimpleDateFormat sdf;
        sdf = new SimpleDateFormat("dd MMM yyyy");
        System.out.println(sdf.format(date)); 
        return sdf.format(date);
	}
    
    /***********************************************************************************
    	@author Anitha 
    	
	*	Function: Add commas after every 3 digits from right to left
	*	Input 	: Digits
	*	Action	: get length,modulo
	*   Output  : return formatted number 
	***********************************************************************************/
    public static String addCommasToNumericString (String digits)
    {    	
        String result = "";
        int len = digits.length();
        int nDigits = 0;
        if(len>3)
        {
	        for (int i = len - 1; i >= 0; i--)                      
	        {
	            result = digits.charAt(i) + result;                 
	            nDigits++;                                          
	            if (((nDigits % 3) == 0) && (i > 0))                
	            {
	                result = "," + result;
	            }
	        }
        }
        else
        {
        	result=digits;
        }      
        return (result);
    }
    
    public static String getCurrCode(String countryCode)
    {
 //   	System.out.println("*************getCurrCode:");
    	String currencySymbol=null;
	    Locale [] locales = Locale.getAvailableLocales();			 
		for(Locale l: locales){
//			System.out.println("*************l.getCountry():"+l.getCountry());
		    if( null == l.getCountry() || l.getCountry().isEmpty())
		        continue;
		    Currency c = Currency.getInstance(l);
//		    System.out.println("*************c:"+c);
		    if(countryCode.equalsIgnoreCase("US") && l.toString().equalsIgnoreCase("es_US"))
		    {
		    	currencySymbol= c.getSymbol(l);			    	
		    	break;
		    }
		    else if(countryCode.equalsIgnoreCase("CA"))
		    {
		    	if(l.getCountry().equalsIgnoreCase(countryCode))
		    	{			    	
		    		currencySymbol= "C"+c.getSymbol(l);
		    		break;
		    	}
		    }
		    else
		    {
		    	if(!countryCode.equalsIgnoreCase("US") && !countryCode.equalsIgnoreCase("CA") && l.getCountry().equalsIgnoreCase(countryCode))
		    	{	
//		    		System.out.println("*************countryCode:"+countryCode);
		    		currencySymbol= c.getSymbol(l);			    		
		    		break;
		    	}
		    }
		}
//		System.out.println("*************currencySymbol:"+currencySymbol);
		return currencySymbol;
    }
    
    
    static final long MILLION = 1000000L;
	static final long BILLION = 1000000000L;
	static final long TRILLION = 1000000000000L;
	
	public static String truncateNum(double x) {			
	    return x < MILLION ?  String.valueOf(x) :
	           x < BILLION ?  String.format("%.01f",x / MILLION) + "M" :
	           x < TRILLION ?  String.format("%.01f",x / BILLION) + "B" : 
	        	   String.format("%.01f",x / TRILLION) + "T";
	}
    
    
}
 