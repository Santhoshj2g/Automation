package com.dnb.automation.dnbi.pages;

import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;
import com.thoughtworks.selenium.webdriven.commands.WaitForPageToLoad;

/**********************************************************************************************
 * HomePage.java - This class contains login functionality
 * 
 * @author Duvvuru Naveen
 * @version 1.0
 ***********************************************************************************************/
public class DNBiLoginPage extends PageObject {

    @FindBy(xpath = "//*[@id='parentDiv']//*//*[@id='loginForm']//*[@id='username']")
    private WebElementFacade unameBox;

    @FindBy(xpath = "//*[@id='parentDiv']//*//*[@id='loginForm']//*[@id='password']")
    private WebElementFacade pwordBox;

    @FindBy(xpath = ".//*[@id='LoginBtn']")
    private WebElementFacade submitBtn;

    @FindBy(xpath = "//*[contains(@href,'Dashboard')]")
    private WebElementFacade gotoDashboard;

    @FindBy(xpath = "//*[contains(@href,'Dashboard')]")
    private WebElementFacade dashboardTabEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@type='checkbox']")
    private WebElementFacade marKetingAdChkBox;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@value='Continue']")
    private WebElementFacade marKetingAdChkContinue;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@type='radio' and @value='NO']")
    private WebElementFacade rulesRadioNOOption;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@value='Next']")
    private WebElementFacade rulesNext;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@value,'Activate')]")
    private WebElementFacade activateSystem;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@value='Start']")
    private WebElementFacade adChkContinue;

    @FindBy(xpath = ".//*[@id='header_mainApp']//*[@id='primaryNav']//*[contains(text(),'Admin')]")
    private WebElementFacade tabAdmin;
    
    @FindBy(xpath = "//*[@id='header_toolbar']//a[contains(.,'Sign Out')]")
    private WebElementFacade signOutLink;
    
    String username="//*[@id='parentDiv']//*//*[@id='loginForm']//*[@id='username']";
    String singOutXpath="//*[@id='header_toolbar']//a[contains(.,'Sign Out')]";

    public void getURLAndLanuchApplication(String appURL) throws Exception {
        getDriver().manage().deleteAllCookies();
        getDriver().manage().window().maximize();
        getDriver().manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        getURLtoTEst(appURL);
    }

    public void login(String userName, String password) throws Exception {
    	UIHelper.waitForPageToLoad(getDriver());
        enterLogin(userName);
        enterPassword(password);
        clickLoginButton(userName, password);
    }

    public void getURLtoTEst(String appURL) throws Exception {
        getDriver().get(appURL);
    }

    public void enterLogin(String login) throws Exception {
    	UIHelper.waitForPageToLoad(getDriver());
        try {
            //unameBox.waitUntilPresent();
        	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), username);
            unameBox.type(login);
        } catch (Exception E) {
            throw E;
        }
    }

    public void enterPassword(String password) throws Exception {
        try {
            pwordBox.type(password);
        } catch (Exception E) {
            throw E;
        }
    }
public void click_SingOut_Link(){
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), singOutXpath);

((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", signOutLink);
	UIHelper.highlightElement(getDriver(), signOutLink);
	System.out.println("I am clicking signout");
	signOutLink.click();
	UIHelper.waitForPageToLoad(getDriver());
	getDriver().close();
	
}
    public void clickLoginButton(String usrName, String password)
            throws Exception {
//        if (submitBtn.isPresent()) {
            submitBtn.click();

            /*if (unameBox.isPresent()) {
                unameBox.type(usrName);
                pwordBox.type(password);

                submitBtn.click();
            }*/
/*
            if (adChkContinue.isPresent()) {
                adChkContinue.click();
            }
*/
            /*if (marKetingAdChkBox.isPresent()) {

                marKetingAdChkBox.click();
            }

            if (marKetingAdChkContinue.isPresent()) {

                marKetingAdChkContinue.click();
            }*/
/*
            if (rulesRadioNOOption.isPresent()) {

                rulesRadioNOOption.click();
            }

            if (rulesNext.isPresent()) {

                rulesNext.click();
                UIHelper.processalert(getDriver());
            }

            if (activateSystem.isPresent()) {

                activateSystem.click();
            }

            gotoDashboard.waitUntilPresent();
            if (gotoDashboard.isPresent()) {

                gotoDashboard.click();
            }

            if (marKetingAdChkBox.isPresent()) {

                marKetingAdChkBox.click();
            }

            if (marKetingAdChkContinue.isPresent()) {

                marKetingAdChkContinue.click();
            }

            if (activateSystem.isPresent()) {

                activateSystem.click();
            }
*/        
//        }
    }
}