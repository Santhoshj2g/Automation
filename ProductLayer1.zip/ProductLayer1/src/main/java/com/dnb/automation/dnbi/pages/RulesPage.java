package com.dnb.automation.dnbi.pages;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;



/**********************************************************************************************
 * RulesPage.java - This program contains below functionalities 1. Create Rule
 * 2. Disable Rule 3. Create Rule sets 4. Disable Rule Sets 5. Assign rule to
 * rule sets 6. Configure Rule Evaluation Order for rule sets
 * 
 * @author Duvvuru Naveen
 * @version 1.0
 ***********************************************************************************************/

public class RulesPage extends PageObject {

    @FindBy(xpath = "//*[@id='header_mainApp']//a[contains(text(),'Admin')]")
    private WebElementFacade adminHref;

    @FindBy(xpath = ".//*[@id='header_mainApp']//*[@id='primaryNav']//*[contains(text(),'Admin')]")
    private WebElementFacade tabAdmin;

    @FindBy(xpath = ".//*[@id='main']//*")
    private WebElementFacade adminHrefallControls;
    
    @FindBy(xpath = "//*[@class='outerDiv']")
    private WebElementFacade outerDivEle;

    // Select Table and Type

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='ecf_toc']/li/a[contains(text(),'Credit Applications')]")
    private WebElementFacade creditApplicationAdmin;

    @FindBy(xpath = "//*[@class='outerDiv']//*//table//*[contains(text(),'Decision Maker')]")
    private WebElementFacade desicionmakerSetRules;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='ecf_toc']/li/a[contains(text(),'Account Manager')]")
    private WebElementFacade accountManagerAdmin;

    @FindBy(xpath = "//*[@class='outerDiv']//*//table//*[contains(text(),'Account Review Rules')]")
    private WebElementFacade accountReviewRules;

    // Select Table and Type - End

    // *******************************************************************************

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='backRight']/input[contains(@value,'Nex')]")
    public WebElementFacade confirmDeleteUsedRules;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='fullTab' and contains(text(),'Rules')]")
    public WebElementFacade scoringRulesTab;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='tab1']/table/tbody/tr/td//a/img[contains(@alt,'Click to disable')]")
    public WebElementFacade existingRulesDisable;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']/table//*[@value='Create New Rule']")
    private WebElementFacade createNewRuleBTN;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']/table//*[contains(@value,'RuleSet')]")
    private WebElementFacade createNewRuleSETBTN;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']/table//*[contains(@value,'Evaluation')]")
    private WebElementFacade createNewRuleEvaluation;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']/table//*[contains(@value,'Outcome')]")
    private WebElementFacade createNewRuleOutcome;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@id='pageHead']")
    private WebElementFacade createNewRulepageHeadSecRuleOverview;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@id='pageHead']//*[@id='indiBlock']/ul/li")
    private WebElementFacade createNewRulepageHeadwithOptionsSecRuleOverview;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@value='Next' and contains(@class,'btn')]")
    private WebElementFacade ruleNextBtnEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='widget_form']//*[@id='cats']//*[@id='categoryPool']")
    private WebElementFacade createNewRuleSelectANDOptionsCats;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='widget_form']//*[@id='vars']//*[@id='pool']")
    private WebElementFacade createNewRuleSelectANDOptionsAvailableVars;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='widget_form']//*[@id='vars']//*[@id='pool']/option")
    private WebElementFacade createNewRuleSelectANDOptionsAvailableVarsOptions;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='fields']//*[@id='sel']//*[contains(@src,'add')]")
    private WebElementFacade createNewRuleSelectANDOptionsAvailableVarsAddBTN;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='fields']//*[@id='sel']//*[contains(@src,'remove')]")
    private WebElementFacade createNewRuleSelectANDOptionsAvailableVarsRemBTN;

    @FindBy(xpath = "//*[@class='outerDiv']//*//textarea")
    private WebElementFacade analystInstructionTextArea;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@id,'Right')]//*[contains(@value,'ave')]")
    private WebElementFacade saveDecisionRule;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@name='ruleName']")
    private WebElementFacade defineRuleName;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@class='widget_form']//*[@type='radio' and @checked='checked' and @value='YES']")
    private WebElementFacade enableRuleChkdYesBtn;

    // Decision type - Start

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='widget_form']//input[@type='radio' and @value='Pending']")
    private WebElementFacade decisionOutcomeasPending;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='widget_form']//input[@type='radio' and @value='Declined']")
    private WebElementFacade decisionOutcomeasDeclined;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='widget_form']//input[@type='radio' and @value='Approved']")
    private WebElementFacade decisionOutcomeasApproved;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='widget_form']//input[@type='radio' and contains(@value,'Credit Hold Adv')]")
    private WebElementFacade decisionOutcomeasCreditHoldAdvised;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='widget_form']//input[@type='radio' and contains(@value,'Credit Review')]")
    private WebElementFacade decisionOutcomeasCreditReviewReqd;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='widget_form']//input[@type='radio' and contains(@value,'Collections Req')]")
    private WebElementFacade decisionOutcomeasCollectionsReqd;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='widget_form']//input[@type='radio' and contains(@value,'Credit Increase')]")
    private WebElementFacade decisionOutcomeasCreditIncrease;

    // Decision type - End

    // *************************************************************************

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='results']//*[contains(@id,'operator')]")
    private List<WebElementFacade> andConditionswithRange;

    @FindBy(xpath = "//*[@class='outerDiv']")
    private WebElementFacade outerDivElement;

    @FindBy(xpath = "//*[@id='main']//*[@id='tab1']/table/tbody//*//*[contains(text(),'Delete')]")
    private WebElementFacade xpathDeleteElement;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[contains(@alt,'disable')]")
    private WebElementFacade xpathDisableRules;

    // Assertions for rule review:

    @FindBy(xpath = ".//*[@id='indiBlock']//*[@id='stepIndicatorBlock']")
    private WebElementFacade pageTitleBreadcrumb;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(text(),'Credit Hold Advised')]")
    private WebElementFacade creditHoldAdvice;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(text(),'Credit Review Required')]")
    private WebElementFacade creditReviewRequired;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(text(),'Collections Required')]")
    private WebElementFacade collectionRequired;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(text(),'Define Review Conditions')]")
    private WebElementFacade defineReviewConditions;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(text(),'Set Recommended Credit Limit & Terms')]")
    private WebElementFacade creditLimitTerms;

    @FindBy(xpath = "//*[@class='outerDiv']//*[a='Credit Limit & Terms']")
    private WebElementFacade creditLimitURL;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(text(),'Enter Analyst Instructions')]")
    private WebElementFacade EnterAnalystInsturction;

    @FindBy(xpath = "//*[@class='outerDiv']//*[a='instructions']")
    private WebElementFacade EnterAnalystInstructionURL;

    @FindBy(xpath = ".//*[@id='backLeft']//*[@value='Back']")
    private WebElementFacade backBtn;

    @FindBy(xpath = ".//*[@id='backMiddle']//*[@value='Home']")
    private WebElementFacade homeBtn;

    @FindBy(xpath = ".//*[@id='backRight']//*[@value='Next']")
    private WebElementFacade nextBtn;

    @FindBy(xpath = ".//*[@id='page_title']//*[contains(text(),'Create New Account Review Rule')]")
    private WebElementFacade createNewAccountRule;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@value='NO']")
    private WebElementFacade createRuleFromScratch;

    @FindBy(xpath = ".//*[@id='rad1']")
    private WebElementFacade applyRuleToUS;

    @FindBy(xpath = ".//*[@id='rad2']")
    private WebElementFacade applyRuleToOtherCountries;

    @FindBy(xpath = ".//*[@id='adminLayout']//*[@value='YES']")
    private WebElementFacade copyanExistingRule;

    @FindBy(xpath = ".//*[@id='main']//*[@name='criteriasetIdForClone']")
    private WebElementFacade copyanExistingRuleDD;

    // Assertions for Recommended actions

    @FindBy(xpath = "//*[@class='outerDiv']//*[@value='Credit Hold Advised']")
    private WebElementFacade creditHoldAdviseRadio;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(text(),'Credit Review Required')]")
    private WebElementFacade creditReviewRequiredRadio;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(text(),'Collections Required')]")
    private WebElementFacade collectionRequiredRadio;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(text(),'Credit Increase Recommended')]")
    private WebElementFacade creditIncreaseRecommendedRadio;

    // Assertions for AND conditions

    @FindBy(xpath = ".//*[@id='main']//a[contains(text(),'AND conditions.')]")
    private WebElementFacade andConditions;

    @FindBy(xpath = ".//*[@id='cats']//*[@id='categoryPool']")
    private WebElementFacade categorySelection;

    @FindBy(xpath = ".//*[@id='fields']//*[@id='pool']")
    private WebElementFacade availableValues;

    @FindBy(xpath = ".//*[@id='sel']/a[1]/img")
    private WebElementFacade addBtn;

    @FindBy(xpath = ".//*[@id='sel']/a[2]/img")
    private WebElementFacade removeBtn;

    @FindBy(xpath = ".//*[@id='seld']//*[contains(text(),'Selected Variables')]")
    private WebElementFacade selectedVariable;

    // Assertion for set AND condition

    @FindBy(xpath = ".//*[@id='main']//*[contains(@name,'operator')]")
    private WebElementFacade setANDConditionDD;

    @FindBy(xpath = ".//*[@id='main']//*[contains(text(),'Delete')]")
    private WebElementFacade deleteLink;

    @FindBy(xpath = ".//*[@id='main']//*[contains(@class,'showCriteriaField')]")
    private WebElementFacade setAndConditionTxtField;

    @FindBy(xpath = ".//*[@id='main']//*[contains(text(),'You must enter both a minimum and maximum value for this condition')]")
    private WebElementFacade validateionWithTxtField;

    // Assertion for set OR condition

    @FindBy(xpath = ".//*[@id='main']//*[contains(text(),'OR Conditions')]")
    private WebElementFacade orConditionURL;

    @FindBy(xpath = ".//*[@id='cats']//*[@id='categoryPool']")
    private WebElementFacade categoryDDforOR;

    @FindBy(xpath = ".//*[@id='fields']//*[@id='pool']")
    private WebElementFacade availableValuesforOR;

    @FindBy(xpath = ".//*[@id='sel']/a[1]/img")
    private WebElementFacade addBtnforOR;

    @FindBy(xpath = ".//*[@id='sel']/a[2]/img")
    private WebElementFacade removeBtnforOR;

    @FindBy(xpath = ".//*[@id='seld']//*[contains(text(),'Selected Variables')]")
    private WebElementFacade selectedValuesforOR;

    // Assertion for Save rule

    @FindBy(xpath = ".//*[@id='main']//*[Contains(text(),'click here')]")
    private WebElementFacade clickHereURL;

    @FindBy(xpath = ".//*[@id='main']//*[@name='ruleName']")
    private WebElementFacade reviewRuleNameTxtField;

    @FindBy(xpath = ".//*[@id='main']//*[@value='YES']")
    private WebElementFacade enableRuleYes;

    @FindBy(xpath = ".//*[@id='main']//*[@value='NO']")
    private WebElementFacade enableRuleNo;

    @FindBy(xpath = ".//*[@id='backRight']//*[@value='Save']")
    private WebElementFacade saveBtn;

    @FindBy(xpath = "//*[@id='tab1']//table//tbody//tr//td[5]//a")
    private WebElementFacade enabledChkBoxEle;

    private String enabledChkBoxEleXpath = "//*[@id='tab1']//table//tbody//tr//td[5]//a//img[@alt='Click to disable']";

    private String xpathDeleteElementRulesWithAutomationKeyword = "//*[@class='outerDiv']//*//table//*[contains(text(),'Auto') and not(contains(text(),'NASAAutomation'))]//ancestor::tr//*[contains(text(),'Del')]";

    private String scoringCreateVarscheckSelectedFieldsXpath = "//*[@class='outerDiv']//*[@class='widget_form']//*[@id='vars']//*[@id='pool']//*";

    // defineSpecialANDConditionsWithRangeToTriggerRecActions - Start

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//tr//*[@class='RowGray' or @class='RowWhite']//td//*[contains(text(),.)]")
    private List<WebElementFacade> conditionsKey;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//tr//*[@class='RowGray' or @class='RowWhite']//td//*[contains(text(),.)]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'_min_1')]")
    private List<WebElementFacade> conditionsKeyMin1;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//tr//*[@class='RowGray' or @class='RowWhite']//td//*[contains(text(),.)]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'_max_1')]")
    private List<WebElementFacade> conditionsKeyMax1;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),.)]//ancestor::tr[1]//following-sibling::tr[1]//select")
    private List<WebElementFacade> conditionsKeyMSelect;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),.)]//ancestor::tr[1]//following-sibling::tr[1]//select//*")
    private List<WebElementFacade> conditionsKeyMValuesToSelect;

    //

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST001')]")
    private WebElementFacade udf1;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST001')]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'_min_1')]")
    private WebElementFacade udf1Min;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST001')]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'max_1')]")
    private WebElementFacade udf1Max;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST001')]//ancestor::tr[1]//following-sibling::tr[1]//select")
    private WebElementFacade udf1Select;

    //

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST002')]")
    private WebElementFacade udf2;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST002')]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'_min_1')]")
    private WebElementFacade udf2Min;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST002')]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'max_1')]")
    private WebElementFacade udf2Max;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST002')]//ancestor::tr[1]//following-sibling::tr[1]//select")
    private WebElementFacade udf2Select;

    //

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST003')]")
    private WebElementFacade udf3;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST003')]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'_min_1')]")
    private WebElementFacade udf3Min;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST003')]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'max_1')]")
    private WebElementFacade udf3Max;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST003')]//ancestor::tr[1]//following-sibling::tr[1]//select")
    private WebElementFacade udf3Select;

    //

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST004')]")
    private WebElementFacade udf4;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST004')]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'_min_1')]")
    private WebElementFacade udf4Min;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST004')]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'max_1')]")
    private WebElementFacade udf4Max;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST004')]//ancestor::tr[1]//following-sibling::tr[1]//select")
    private WebElementFacade udf4Select;

    //

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST005')]")
    private WebElementFacade udf5;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST005')]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'_min_1')]")
    private WebElementFacade udf5Min;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST005')]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'max_1')]")
    private WebElementFacade udf5Max;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'UDF_TEST005')]//ancestor::tr[1]//following-sibling::tr[1]//select")
    private WebElementFacade udf5Select;

    // Define AND Conditions

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='widget_form']//*[@id='vars']//*[@id='pool']//*")
    private List<WebElementFacade> defineANDCondtionsForTheRule;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='adminLayout']//*[contains(@class,'Country')]//*[@type='radio']")
    private List<WebElementFacade> selectcountryFromtheOption;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results full')]")
    private WebElementFacade tableResFull;
    
    private String tableResFull1 ="//*[@class='outerDiv']//*[contains(@class,'results full')]";
    @FindBy(xpath = "//*[contains(@id,'div_viewRulesByGroups')]//*[@id='terr_valueTable'][contains(@class,'results')]")
    private WebElementFacade ruleSetTableResFull;
    
    @FindBy(xpath = "//*[contains(@class,'padTop')][contains(.,'View Items')]//select[@id='viewItems']")
    private WebElementFacade viewlistListbox;
    
  

    // Rules Dom & Int

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'CountryOption')]//*[contains(@value,'D')]")
    private WebElementFacade rulesSetDOM;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'CountryOption')]//*[contains(@value,'I')]")
    private WebElementFacade rulesSetINT;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results full')]//*//tr")
    private List<WebElementFacade> rulesTableSetData;

    @FindBy(xpath = "//*[@id='terr_valueTable']")
    private WebElementFacade ruleSetTableRes;

    private String tableResFullXpath = "//*[@class='outerDiv']//*[contains(@class,'results full')]";

    public String getTableResFullXpath() {
        return tableResFullXpath;
    }

    // defineCreditLimitTerms

    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='widget_form']//table//*[contains(@name,'Selected')]")
    private WebElementFacade defineCreditLimitTermsXpath;
    
    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='widget_form']//table//td[contains(.,'Select the Credit Limit & Terms for this Rule')]")
    private WebElementFacade selectDefineCreditLimitTerms;
    
  

    // Rules Advanced Analytics

    String minXpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//tr//*[@class='RowGray' or @class='RowWhite']//td//*[contains(text(),'FIFA')]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'_min_1')]";
    String maxpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//tr//*[@class='RowGray' or @class='RowWhite']//td//*[contains(text(),'FIFA')]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'_max_1')]";
    String selectxPath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'FIFA')]//ancestor::tr[1]//following-sibling::tr[1]//select";

    @FindBy(xpath = "//*[@id='main']//*[@id='tab1']//span[contains(.,'Loading')]")
    private WebElementFacade loadingRulesEle;

    private String loadingRulesEleXPath = "//*[@id='main']//*[@id='tab1']//span[contains(.,'Loading')]";

    private String tab2LoadingRulesEleXPath = "//*[@id='main']//*[@id='tab2']//span[contains(.,'Loading')]";

    ArrayList<String> partsDataList = new ArrayList<String>();
    ArrayList<String> getCurrentRuleCatsList = new ArrayList<String>();

    // Rule Sets
    @FindBy(xpath = "//*[@id='main']//input[@value='Create New RuleSet']")
    private WebElementFacade createRuleSetBtnEle;

    @FindBy(xpath = "//*[@id='main']//*[@id='ruleTab' and contains(.,'RuleSet')]")
    private WebElementFacade ruleSetTabEle;

    @FindBy(xpath = "//*[@id='adminLayout']//input[@name='groupName']")
    private WebElementFacade ruleSetNameFieldEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'ruleSetContainer')]//*[contains(@value,'I')]")
    private WebElementFacade rulesSetCountryOptINT;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'ruleSetContainer')]//*[contains(@value,'D')]")
    private WebElementFacade rulesSetCountryOptDOM;

    @FindBy(xpath = "//*[@id='categoryPool']")
    private WebElementFacade rulesSetCategory;

    @FindBy(xpath = "//*[@id='selVariable']")
    private WebElementFacade rulesSetVariable;

    @FindBy(xpath = "//*[@id='backLeft']/input[@value='Submit']")
    private WebElementFacade ruleSetSubmitBtn;

    @FindBy(xpath = ".//*[@id='terr_valueTable']/tbody/tr[2]/td[3]")
    private WebElementFacade firstRulesetElementInTable;

    @FindBy(xpath = ".//*[@id='terr_valueTable']/tbody/tr/td[3]")
    private List<WebElement> rulestNamesEle;

    private String createdRuleSetValXPath = "//*[@class='outerDiv']//*//table//*[contains(text(),'SERENITY')]//following-sibling::td[5]//a[contains(.,'Assign')]";

    @FindBy(xpath = "//*[@id='terr_valueTable']//tbody//td[contains(.,'Auto')]//following-sibling::td[5]//a[contains(.,'Assign')]")
    private WebElementFacade assignOrUnassignLinkEleInRuleSet;

    @FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
    private WebElementFacade iFrameEle;

    @FindBy(xpath = "//*[@id='pool']//option[contains(.,'FIFA')]")
    private WebElementFacade availableRulesInIFrameWindow;

    

    @FindBy(xpath = "//*[@id='sel']//a[1]//img[contains(@src,'add')]")
    private WebElementFacade addBtnInIFrameWindow;

    @FindBy(xpath = "//*[@class='iframe_modal']//*[@class='modal_buttons']//input[@value='Submit']")
    private WebElementFacade submitBtnInIFrameWindow;

    @FindBy(xpath = "//*[@id='main']//*[@value='Set Evaluation Order']")
    private WebElementFacade setEvaluationOrder;
    
    String area="//*[@class='outerDiv']//*//textarea";
	String RulenameBox="//*[@class='outerDiv']//*[@id='main']//*[@name='ruleName']";
    
    
    private WebElement deleteRuleSet;
    private WebElement clickCNRBtn;
     @FindBy(xpath = "//*[@id='page_title']//h2[contains(.,'Rules')]")
    private WebElementFacade rulePageTitleEle;
    private WebElement delRuleName;

    ArrayList<String> someTextList = new ArrayList<String>();
    ArrayList<String> finalData = new ArrayList<String>();
    ArrayList<String> finalDataReplica = new ArrayList<String>();

    ArrayList<String> ruleSetNames = new ArrayList<String>();

    private String rulePageTitle;

    boolean createdRuleSetValInResults;

    boolean assignedRuleInRuleSetDispVal;
    boolean isDispDeletedRule;

    public void goToRulespage(String ruleType) throws Exception {

        try {

            // Select Build Application score from Admin page
            if (tabAdmin.isPresent()) {
                tabAdmin.click();
            }
           /* waitFor(outerDivElement);
            outerDivElement.waitUntilPresent();*/

            if (ruleType.toString().trim().contains("App")) {
                navigateToAppRulesPage();
            } else {
                navigateToAcntRulesPage();
            }

            // goto Rules page and disable all existing rules;
            waitFor(confirmDeleteUsedRules);
            confirmDeleteUsedRules.waitUntilPresent();
            confirmDeleteUsedRules.click();
            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tableResFull1);
            /*waitFor(outerDivElement);
            outerDivElement.waitUntilPresent();

            if (loadingRulesEle.isPresent()) {
                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                        loadingRulesEleXPath);
            }

            UIHelper.waitForPageToLoad(getDriver());*/

        } catch (StaleElementReferenceException e) {

           e.printStackTrace();
        }

    }

    public String getRulePageTitle() {
        if (rulePageTitleEle.isPresent()) {
            rulePageTitle = rulePageTitleEle.getText();
        }
        return rulePageTitle;
    }

    public void navigateToAcntRulesPage() {

    	try
    	{
    	
        accountManagerAdmin.waitUntilPresent();
        waitFor(accountManagerAdmin);
        if (accountManagerAdmin.isPresent()) {
            accountManagerAdmin.click();
        }
        UIHelper.waitForPageToLoad(getDriver());
        waitFor(accountReviewRules);
        accountReviewRules.waitUntilPresent();

        // Click desicionmakerSetRules

        if (accountReviewRules.isPresent()) {
            accountReviewRules.click();
        }
    	}catch(StaleElementReferenceException e)
    	{
    		e.printStackTrace();
    	}
    }

    public void navigateToAppRulesPage() {

        creditApplicationAdmin.waitUntilPresent();

        if (creditApplicationAdmin.isPresent()) {
            creditApplicationAdmin.click();
        }
        desicionmakerSetRules.waitUntilPresent();

        // Click desicionmakerSetRules

        if (desicionmakerSetRules.isPresent()) {
            desicionmakerSetRules.click();
        }
    }

    // Disable Existing Rules
    public void disableExistingRules(String countryMode)
            throws InterruptedException, Exception {

        try {
            String tempXpath;

            if (countryMode.equalsIgnoreCase("DOM")) {

                tempXpath = xpathDeleteElementRulesWithAutomationKeyword
                        .replace("NASAAutomation", "INT");
            } else {

                tempXpath = xpathDeleteElementRulesWithAutomationKeyword
                        .replace("NASAAutomation", "DOM");
            }

            tableResFull.waitUntilPresent();

            if (tableResFull.isPresent()) {

                UIHelper.highlightElement(getDriver(), tableResFull);
            }

            try {
                int attempt = 0;
                main: while (attempt < 100) {

                    try {

                        List<WebElement> valuestobedeletedinTable = getDriver()
                                .findElements(By.xpath(tempXpath));

                        if (0 == valuestobedeletedinTable.size()) {

                            break main;
                        }

                        try {
                            for (int getcount = 0; getcount < 0; getcount++) {

                                valuestobedeletedinTable.remove(getcount);

                            }
                        } catch (Exception E) {

                        }

                        for (WebElement valuestobedeletedinTableData : valuestobedeletedinTable) {

                            UIHelper.highlightElement(getDriver(),
                                    valuestobedeletedinTableData);
                        }

                        Iterator<WebElement> clickDeleteforAll = valuestobedeletedinTable
                                .iterator();

                        if (valuestobedeletedinTable.size() > 0) {
                            while (clickDeleteforAll.hasNext()) {

                                clickDeleteforAll.next().click();

                                UIHelper.processalert(getDriver());

                                if (loadingRulesEle.isPresent()) {
                                    UIHelper.waitForInvisibilityOfAjaxImgByXpath(
                                            getDriver(), loadingRulesEleXPath);
                                }

                                UIHelper.waitForPageToLoad(getDriver());
                            }

                        } else {
                            break;

                        }

                    } catch (StaleElementReferenceException e) {

                        attempt++;

                    } catch (NoSuchElementException E) {

                    }

                } // End- While

                attempt = attempt + 100;

            } catch (Exception E) {

                throw E;
            }

            try {
                int disAttempt = 0;
                main: while (disAttempt < 100) {

                    try {
                        List<WebElement> valuestobedisableinTable = getDriver()
                                .findElements(By.xpath(enabledChkBoxEleXpath));

                        if (0 == valuestobedisableinTable.size()) {

                            break main;
                        }

                        try {
                            for (int getcount = 0; getcount < 0; getcount++) {

                                valuestobedisableinTable.remove(getcount);

                            }
                        } catch (Exception E) {

                        }

                        for (WebElement valuestobedisableddinTableData : valuestobedisableinTable) {

                            UIHelper.highlightElement(getDriver(),
                                    valuestobedisableddinTableData);
                        }

                        Iterator<WebElement> clickDisableforAll = valuestobedisableinTable
                                .iterator();

                        if (valuestobedisableinTable.size() > 0) {
                            while (clickDisableforAll.hasNext()) {

                                clickDisableforAll.next().click();
                                waitFor(7000).milliseconds();
                                getDriver().navigate().refresh();

                                if (loadingRulesEle.isPresent()) {
                                    UIHelper.waitForInvisibilityOfAjaxImgByXpath(
                                            getDriver(), loadingRulesEleXPath);
                                }

                                UIHelper.waitForPageToLoad(getDriver());
                            }

                        }
                    } catch (StaleElementReferenceException e) {

                        disAttempt++;

                    } catch (NoSuchElementException E) {

                    }

                } // End- While

                disAttempt = disAttempt + 100;

            } catch (Exception E) {

                // throw E;
            }

        } catch (Exception E) {

            // throw E;
        }

    }

    public String getAllRuleNames() {
        return tableResFull.getText();
    }

    // Disable existing rule sets
    public void disableExistingRuleSets(String countryMode)
            throws InterruptedException, Exception {

        try {

            ruleSetTabEle.waitUntilPresent();
            if (ruleSetTabEle.isPresent()) {
                ruleSetTabEle.click();

                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                        loadingRulesEleXPath);
                UIHelper.waitForPageToLoad(getDriver());
                waitFor(3000).milliseconds();
            }

            String deleteOrDisable;

            if (countryMode.equalsIgnoreCase("DOM")) {

                deleteOrDisable = xpathDeleteElementRulesWithAutomationKeyword
                        .replace("NASAAutomation", "INT");
            } else {

                deleteOrDisable = xpathDeleteElementRulesWithAutomationKeyword
                        .replace("NASAAutomation", "DOM");
            }

            try {
                int attempt = 0;
                main: while (attempt < 100) {

                    try {

                        List<WebElement> valuestobedeletedinTable = getDriver()
                                .findElements(By.xpath(deleteOrDisable));

                        if (0 == valuestobedeletedinTable.size()) {

                            break main;
                        }

                        try {
                            for (int getcount = 0; getcount < 0; getcount++) {

                                valuestobedeletedinTable.remove(getcount);

                            }
                        } catch (Exception E) {

                        }

                        for (WebElement valuestobedeletedinTableData : valuestobedeletedinTable) {

                            UIHelper.highlightElement(getDriver(),
                                    valuestobedeletedinTableData);
                        }

                        Iterator<WebElement> clickDeleteforAll = valuestobedeletedinTable
                                .iterator();

                        if (valuestobedeletedinTable.size() > 0) {
                            while (clickDeleteforAll.hasNext()) {

                                clickDeleteforAll.next().click();

                                UIHelper.processalert(getDriver());
                                waitFor(8000).milliseconds();
                            }

                        } else {
                            break;

                        }

                    } catch (StaleElementReferenceException e) {

                        attempt++;

                    } catch (NoSuchElementException E) {

                    }

                } // End- While

                attempt = attempt + 100;

            } catch (Exception E) {

                // throw E;
            }

        } catch (Exception E) {

            // throw E;
        }

    }

    public String getAllRuleSetsNames() {
        return ruleSetTableRes.getText();
    }

    public void createNewRuleFromRulesPage(String ruleType) throws Exception {

        try {

            // Click Create New rule button
            outerDivElement.waitUntilPresent();
            createNewRuleBTN.waitUntilClickable();

            if (createNewRuleBTN.isPresent()) {

                createNewRuleBTN.click();
            } else {

                goToRulespage(ruleType);
                outerDivElement.waitUntilPresent();
                createNewRuleBTN.waitUntilClickable();
                createNewRuleBTN.click();

            }

            outerDivElement.waitUntilPresent();
            UIHelper.waitForPageToLoad(getDriver());

        } catch (Exception E) {

            throw E;
        }

    }

    public void clickCreateNewRuleBtn(String Rulename) {
    	try{
    	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tableResFull1);
    	setRulesPerPage();
    	UIHelper.waitForPageToLoad(getDriver());
    	if (tableResFull.getText().contains(Rulename)){
    		
    		delRuleName=(getDriver().findElement(By
    						.xpath("//*[@class='outerDiv']//*[contains(@class,'results full')]//tbody//tr[contains(.,'"+Rulename+"')]//following-sibling::td//*[contains(.,'Delete')]")));
    		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", delRuleName);
    		UIHelper.highlightElement(getDriver(), delRuleName);
    		System.out.println("rule name which need to delete------------"+Rulename);
    		((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", delRuleName);
    		waitFor(3000).millisecond();
    		UIHelper.processalert(getDriver());
    		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tableResFull1);
    		String CNRBtn="//*[@class='outerDiv']//*[@id='main']/table//*[@value='Create New Rule']";
    		    		
    		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), CNRBtn);
    		clickCNRBtn=getDriver().findElement(By.xpath(CNRBtn));
    		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", clickCNRBtn);
    		UIHelper.highlightElement(getDriver(), clickCNRBtn);
    		((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", clickCNRBtn);
    		outerDivElement.waitUntilPresent();
    		UIHelper.waitForPageToLoad(getDriver());
    	
    	}else{
    		String CNRBtn="//*[@class='outerDiv']//*[@id='main']/table//*[@value='Create New Rule']";
    		clickCNRBtn=getDriver().findElement(By.xpath(CNRBtn));
    		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", clickCNRBtn);
    		UIHelper.highlightElement(getDriver(), clickCNRBtn);
    		((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", clickCNRBtn);
    		outerDivElement.waitUntilPresent();
    		UIHelper.waitForPageToLoad(getDriver());
    	}
    	}catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    }
    public void deleteExistingRuleSet(String rulesetname){
    	try{
    		ruleSetTabEle.waitUntilVisible();
    		 if (ruleSetTabEle.isPresent()) {
                 ruleSetTabEle.click();
 				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                     loadingRulesEleXPath);
 				UIHelper.waitForPageToLoad(getDriver());
 				waitFor(3000).milliseconds();
    		if (ruleSetTableResFull.getText().contains(rulesetname)){
    		
    			deleteRuleSet=(getDriver().findElement(By
    						.xpath("//*[@id='terr_valueTable']/tbody/tr/td[contains(.,'"+rulesetname+"')]//following-sibling::td//a[contains(.,'Delete')]")));
    			UIHelper.highlightElement(getDriver(), deleteRuleSet);
    			deleteRuleSet.click();
    			UIHelper.processalert(getDriver());
    			ruleSetTabEle.waitUntilPresent();
    			if (ruleSetTabEle.isPresent()) {
    				ruleSetTabEle.click();

    				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                        loadingRulesEleXPath);
    				UIHelper.waitForPageToLoad(getDriver());
    				waitFor(3000).milliseconds();
    			}
    		}
    	}
    	}catch (Exception E) {

    		throw E;
    	}
    }
    
    public void createNewRuleSetFromRulesPage(String ruleType, String rulesetname) throws Exception {

        try {
        	
        	
            // Click Create New rule button
            if (createRuleSetBtnEle.isPresent()) {
            	deleteExistingRuleSet(rulesetname);
                createRuleSetBtnEle.click();
                UIHelper.waitForPageToLoad(getDriver());
            } else {
                goToRulespage(ruleType);
                waitFor(createRuleSetBtnEle);
                deleteExistingRuleSet(rulesetname);
                createRuleSetBtnEle.waitUntilClickable();
                createRuleSetBtnEle.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        } catch (Exception E) {

            throw E;
        }

    }

    public void setEvaluationOrderForRulesSet(String ruleType)
            throws InterruptedException {

        try {

            // Click Set Evaluation Order button
            if (setEvaluationOrder.isPresent()) {

                setEvaluationOrder.click();
                UIHelper.waitForPageToLoad(getDriver());
            } else {
                goToRulespage(ruleType);
                setEvaluationOrder.waitUntilClickable();
                setEvaluationOrder.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        } catch (Exception E) {

            // throw E;
        }

    }

    public void goToRuleSetPage(String ruleType) throws Exception {

        try {
            if (ruleSetTabEle.isPresent()) {
                ruleSetTabEle.click();

                UIHelper.waitForPageToLoad(getDriver());
                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                        tab2LoadingRulesEleXPath);

            } else {
                goToRulespage(ruleType);
                ruleSetTabEle.waitUntilClickable();
                if (ruleSetTabEle.isPresent()) {
                    ruleSetTabEle.click();

                    UIHelper.waitForPageToLoad(getDriver());
                    UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                            tab2LoadingRulesEleXPath);
                }
            }
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

    public void selectCountryForRule() throws InterruptedException {

        try {
            // Click Next Button to define Decision Outcome
            outerDivElement.waitUntilPresent();

            // Select a country
            ruleNextBtnEle.waitUntilClickable();
            ruleNextBtnEle.click();

            outerDivElement.waitUntilPresent();
            UIHelper.waitForPageToLoad(getDriver());
        } catch (Exception E) {

            throw E;
        }

    }

    public void selectCountryAnDgoToDecisionOutcomePage(String ruleName,
            WebElementFacade... dataList) throws InterruptedException {

        // Select DOM or INT
        try {

            if (!ruleName.isEmpty() && ruleName != null) {

                if (ruleName.toString().trim().contains("INT")) {

                    if (rulesSetINT.isPresent()) {
                        rulesSetINT.click();
                    }
                } else {
                    if (rulesSetDOM.isPresent()) {
                        rulesSetDOM.click();
                    }
                }
            }
            outerDivElement.waitUntilPresent();
            ruleNextBtnEle.waitUntilClickable();

            ruleNextBtnEle.click();

            outerDivElement.waitUntilPresent();
            UIHelper.waitForPageToLoad(getDriver());

        } catch (Exception E) {

            throw E;

        }

    }

    public void createRuleSet(String getCurrentRuleCats, String formulaToADD,
            String ruleSetName) throws InterruptedException {

        // Select DOM or INT
        try {

            String[] parts = null;
            ArrayList<String> getCatDrpVals = new ArrayList<String>();
            String valsToSelect = null;
            boolean cats = false;

            if (!ruleSetName.isEmpty() && ruleSetName != null) {

                if (ruleSetName.toString().trim().contains("INT")) {

                    if (rulesSetCountryOptINT.isPresent()) {
                        rulesSetCountryOptINT.click();
                        ruleSetNameFieldEle.waitUntilPresent();
                        UIHelper.waitForPageToLoad(getDriver());
                    }
                } else {
                    if (rulesSetCountryOptDOM.isPresent()) {
                        rulesSetCountryOptDOM.click();
                        ruleSetNameFieldEle.waitUntilPresent();
                        UIHelper.waitForPageToLoad(getDriver());
                    }
                }
            }

            ruleSetNameFieldEle.click();
            ruleSetNameFieldEle.type(ruleSetName);

            rulesSetCategory.selectByVisibleText(getCurrentRuleCats);

            rulesSetVariable.waitUntilPresent();

            String splitFormulaVal[] = null;
            if (formulaToADD.toString().trim().contains(":")) {
                splitFormulaVal = formulaToADD.split(":");
            }

            rulesSetVariable.selectByVisibleText(splitFormulaVal[0]);
            UIHelper.waitForPageToLoad(getDriver());

            String WebElementFacadeContoller = "//*[@class='ruleSetContainer']//td[contains(.,'FIFA')]";
            String selectxPath = "//*[@class='ruleSetContainer']//td[contains(.,'FIFA')]//ancestor::table[1]//following-sibling::div//table//tr//td[1]//select";
            String minXpath = "//*[@class='ruleSetContainer']//td[contains(.,'FIFA')]//ancestor::table[1]//following-sibling::div//table//tr//td[1]//input[1]";
            String maxpath = "//*[@class='ruleSetContainer']//td[contains(.,'FIFA')]//ancestor::table[1]//following-sibling::div//table//tr//td[1]//input[2]";

            selectxPath = selectxPath.replace("FIFA", splitFormulaVal[0]);

            WebElementFacadeContoller = WebElementFacadeContoller.replace(
                    "FIFA", splitFormulaVal[0]);

            minXpath = minXpath.replace("FIFA", splitFormulaVal[0]);

            maxpath = maxpath.replace("FIFA", splitFormulaVal[0]);

            WebElementFacade selectEle = find(By.xpath(selectxPath));
            WebElementFacade WebElementFacadeContollerEle = find(By
                    .xpath(WebElementFacadeContoller));

            if (WebElementFacadeContollerEle.isPresent()) {

                UIHelper.highlightElement(getDriver(),
                        WebElementFacadeContollerEle);

            }

            if (splitFormulaVal[1].toString().trim().contains("VAL")) {

                String currentStringToSplitP1;
                currentStringToSplitP1 = "";

                parts = splitFormulaVal[1].toString().trim().split("VAL");

                currentStringToSplitP1 = parts[1].toString().trim();

                UIHelper.getAllAvailableOptions(selectEle, getCatDrpVals);

                getCatDrpValsData: for (String getCatDrpValsData : getCatDrpVals) {

                    if (getCatDrpValsData.toString().trim()
                            .contains(parts[0].toString().trim())) {

                        cats = true;
                        valsToSelect = getCatDrpValsData.toString().trim();

                        break getCatDrpValsData;
                    }
                }

                if (cats) {

                    if (selectEle.isPresent()) {

                        selectEle.selectByVisibleText(valsToSelect.toString()
                                .trim());
                    }
                } else {

                    if (selectEle.isPresent()) {
                        selectEle.selectByVisibleText("Is Not Blank");
                    }
                }

                getCatDrpVals.clear();

                String[] minMaxSplitter = null;

                if (currentStringToSplitP1.toString().trim().contains("to")) {

                    minMaxSplitter = currentStringToSplitP1.toString().trim()
                            .split("to");

                    WebElementFacade minEle = find(By.xpath(minXpath));
                    WebElementFacade maxEle = find(By.xpath(maxpath));

                    if (minEle.isPresent()) {
                        minEle.type(minMaxSplitter[0].toString().trim());
                    }

                    if (maxEle.isPresent()) {
                        maxEle.type(minMaxSplitter[1].toString().trim());
                    }

                } else {
                    WebElementFacade minEle = find(By.xpath(minXpath));
                    if (minEle.isPresent()) {
                        minEle.type(currentStringToSplitP1.toString().trim());
                    }
                }
            }

            ruleSetSubmitBtn.click();
            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                    loadingRulesEleXPath);
            UIHelper.waitForPageToLoad(getDriver());

            if (ruleSetTabEle.isPresent()) {
                createdRuleSetValXPath = createdRuleSetValXPath.replace("FIFA",
                        ruleSetName);
                ruleSetTabEle.click();
                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                        tab2LoadingRulesEleXPath);
                UIHelper.waitForPageToLoad(getDriver());
            }

        } catch (Exception E) {

            // throw E;

        }

    }
    
    public boolean getRuleSetNameFromResultsPageValue(String ruleSetName) {
    	int a=0;
    	List<WebElement> getValues=getDriver().findElements(By.xpath("//*[@id='terr_valueTable']/tbody/tr/td[3]"));
    	for(int i=2;i<getValues.size();i++){
    		String getRuleSetNames=getDriver().findElement(By.xpath("//*[@id='terr_valueTable']/tbody/tr["+i+"]/td[3]")).getText();
    		System.out.println("Rule Set names are:********" +getRuleSetNames);
    		if(getRuleSetNames.contains(ruleSetName)){
    			a=1;
    			break;
    		}
    		
    	}
    	if(a==1)
			return true;
		else 
			return false;
    	}
    
    public boolean validateAssignRuleSet(String ruleSetName){
    	String countryRuleSet=ruleSetName+"_INT";
    	System.out.println("Updated rules set name******" +countryRuleSet);
    	boolean ruleSet=false;
    	WebElement ruleSetListed=getDriver().findElement(By.xpath("//*[@id='terr_valueTable']/tbody/tr[contains(.,'"+countryRuleSet+"')]/td[3]"));
    	if(ruleSetListed.isDisplayed()){
    	ruleSet=true;
    	}
		return ruleSet;
    }

    public ArrayList<String> getRuleSetNameFromResultsPage() {
        try {
            for (WebElement ruleSetVal : rulestNamesEle) {
                String ruleSetName = ruleSetVal.getText();
                ruleSetNames.add(ruleSetName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return ruleSetNames;
       
    }

    public void assignRule(String getCurrentRuleCats, String ruleSetName)
            throws Exception {
        try {
            assignOrUnassignLinkEleInRuleSet.waitUntilClickable();
            String alteredXpath = "//*[@class='outerDiv']//*//table//*[contains(text(),'"+ruleSetName+"')]//following-sibling::td[5]//a[contains(.,'Assign')]";
            WebElementFacade assignOrUnassignLinkEle = find(By
                    .xpath(alteredXpath));

            if (assignOrUnassignLinkEle.isPresent()) {
                assignOrUnassignLinkEle.click();
                iFrameEle.waitUntilPresent();

                getDriver().switchTo().frame(iFrameEle);

                
                String availableRulesXpathInIFrameWindow = "//*[@id='pool']//option[contains(.,'"+getCurrentRuleCats+"')]";
                
                WebElementFacade availableRulesEleInIFrameWindow = find(By
                        .xpath(availableRulesXpathInIFrameWindow));

                availableRulesEleInIFrameWindow.click();

                addBtnInIFrameWindow.click();

                submitBtnInIFrameWindow.click();

                getDriver().switchTo().defaultContent();
                UIHelper.waitForPageToLoad(getDriver());
                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                        tab2LoadingRulesEleXPath);
                outerDivElement.waitUntilPresent();
                firstRulesetElementInTable.waitUntilPresent();
                waitFor(2000).milliseconds();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getAssignedRuleSetName(String ruleSetName) {
        outerDivElement.waitUntilPresent();
        String alteredXpath = createdRuleSetValXPath.replace("FIFA",
                ruleSetName);
        WebElementFacade alteredEle = find(By.xpath(alteredXpath));
        return alteredEle.getText();
    }

    public void selectDecisionTypeinDecRule(String ruleCondition)
            throws InterruptedException {

        try {

            outerDivElement.waitUntilPresent();

            selectDecision(ruleCondition);

            ruleNextBtnEle.click();

            outerDivElement.waitUntilPresent();
            UIHelper.waitForPageToLoad(getDriver());
        } catch (Exception E) {

            throw E;
        }

    }

    public void selectDecision(String ruleCondition) {
        if (ruleCondition.contains("Approved")) {
            decisionOutcomeasApproved.click();
        } else if (ruleCondition.contains("Pending")) {
            decisionOutcomeasPending.click();
        } else if (ruleCondition.contains("Declined")) {
            decisionOutcomeasDeclined.click();
        } else if (ruleCondition.contains("Collections Required")) {
            decisionOutcomeasCollectionsReqd.click();
        } else if (ruleCondition.contains("Credit Review Required")) {
            decisionOutcomeasCreditReviewReqd.click();
        } else if (ruleCondition.contains("Credit Increase Recommended")) {
            decisionOutcomeasCreditIncrease.click();
        } else if (ruleCondition.contains("Credit Hold Advised")) {
            decisionOutcomeasCreditHoldAdvised.click();
        }
    }

    public void applyANDRulesCondition(String getCurrentRuleCats,
            String formulaToADD) throws Exception {

        createANewruleWithSpecialCondiTions(getCurrentRuleCats, formulaToADD);

    }
    
    public void RulesConditionValuesAdd(String formulaToADD) throws Exception {

    	addVluesToVeriables(formulaToADD);

    }

    public void createANewruleWithSpecialCondiTions(String getCurrentRuleCats,
            String formulaToADD) throws Exception, InterruptedException {

        partsDataList.clear();
        getCurrentRuleCatsList.clear();
        finalData.clear();
        finalDataReplica.clear();

        outerDivElement.waitUntilPresent();

        int clearCounter = 1;

        try {

            String[] partsFOR = formulaToADD.toString().trim().split("FOR");

            for (int partsData = 0; partsData < partsFOR.length; partsData++) {

                partsDataList.add(partsFOR[partsData].toString().trim());

            }

            // Select Category
            createNewRuleSelectANDOptionsCats
                    .selectByVisibleText(getCurrentRuleCats.toString().trim());

            // Select Available Variable
            UIHelper.highlightElement(getDriver(),
                    createNewRuleSelectANDOptionsAvailableVars);

            UIHelper.highlightElement(getDriver(),
                    createNewRuleSelectANDOptionsAvailableVarsOptions);

            UIHelper.highlightElement(getDriver(),
                    createNewRuleSelectANDOptionsAvailableVarsAddBTN);

            // ***
            UIHelper.findandAddElementsToaList(getDriver(),
                    scoringCreateVarscheckSelectedFieldsXpath, someTextList);

            UIHelper.removeDuplicatesFromArrayList(someTextList);
            // Get an iterator.
            Iterator<String> ite = someTextList.iterator();
            ArrayList<String> partsDataListFiltered = new ArrayList<String>();
            String[] formulaPartsForRulesAnalytics;

            for (String partsDataListData : partsDataList) {

                if (partsDataListData.toString().trim().contains("Is")) {

                    formulaPartsForRulesAnalytics = partsDataListData
                            .toString().trim().split("Is");
                    
                    partsDataListFiltered.add(formulaPartsForRulesAnalytics[0]
                            .toString().trim());

                }

                else if (partsDataListData.toString().trim().contains("Does")) {

                    formulaPartsForRulesAnalytics = partsDataListData
                            .toString().trim().split("Does");
                    partsDataListFiltered.add(formulaPartsForRulesAnalytics[0]
                            .toString().trim());

                }

                else if (partsDataListData.toString().trim()
                        .contains("Contains")) {

                    formulaPartsForRulesAnalytics = partsDataListData
                            .toString().trim().split("Contains");
                    partsDataListFiltered.add(formulaPartsForRulesAnalytics[0]
                            .toString().trim());

                } else {
                    partsDataListFiltered.add(partsDataListData.toString()
                            .trim());
                }
            }

            UIHelper.removeDuplicatesFromArrayList(partsDataListFiltered);

            while (ite.hasNext()) {

                String getITe = ite.next();

                for (String twoDataList : partsDataListFiltered) {
                	
                   if (twoDataList.toString().trim()
                            .equalsIgnoreCase(getITe.toString().trim())) {
                    	
                    	
                        finalData.add(getITe.toString().trim());
                    }

                }

            }

            // Add all from Selected fields;
            
           /* for (String twoDataList : finalData) {

            	finalData.add(twoDataList.toString().trim());
            	System.out.println("finalData-------------------"+twoDataList.toString().trim());
            }*/

            UIHelper.removeDuplicatesFromArrayList(finalData);
          
            UIHelper.selectMultipleFromDropdownList(getDriver(),
                    createNewRuleSelectANDOptionsAvailableVars, finalData,
                    createNewRuleSelectANDOptionsAvailableVarsAddBTN);

            if (clearCounter == 1) {
                someTextList.clear();
                finalData.clear();

                clearCounter++;
            }
            
            // Add and Save
            // Select Available Variable - End
            // **********************************************************************

           /* ruleNextBtnEle.click();

            outerDivElement.waitUntilPresent();
            UIHelper.waitForPageToLoad(getDriver());

            for (String finalDataReplicaList : finalDataReplica) {
                finalData.add(finalDataReplicaList);

            }

            UIHelper.removeDuplicatesFromArrayList(finalData);
            finalData.remove(Collections.singleton(null));

            // Analytics Start
            for (String finalDataList : finalData) {

                String webElementFacadeController = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'FIFA')]";
                String selectxPath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'FIFA')]//ancestor::tr[1]//following-sibling::tr[1]//select";
                String minXpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//tr//*[@class='RowGray' or @class='RowWhite']//td//*[contains(text(),'FIFA')]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'_min_1')]";
                String maxpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//tr//*[@class='RowGray' or @class='RowWhite']//td//*[contains(text(),'FIFA')]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'_max_1')]";

                selectxPath = selectxPath.replace("FIFA", finalDataList
                        .toString().trim());

                webElementFacadeController = webElementFacadeController
                        .replace("FIFA", finalDataList.toString().trim());

                minXpath = minXpath.replace("FIFA", finalDataList.toString()
                        .trim());

                maxpath = maxpath.replace("FIFA", finalDataList.toString()
                        .trim());

                WebElementFacade selectEle = find(By.xpath(selectxPath));
                WebElementFacade webElementFacadeControllerEle = find(By
                        .xpath(webElementFacadeController));

                if (webElementFacadeControllerEle.isPresent()) {

                    UIHelper.highlightElement(getDriver(),
                            webElementFacadeControllerEle);

                }

                String[] parts = null;
                ArrayList<String> getCatDrpVals = new ArrayList<String>();
                String valsToSelect = null;
                boolean cats = false;

                try {

                    alphaDataList: for (String alphaDataList : partsDataList) {

                        if (alphaDataList.contains(finalDataList)) {

                            String getParser = alphaDataList.replace(
                                    finalDataList, "");

                            if (getParser.toString().trim().contains("VAL")) {

                                String currentStringToSplitP1;
                                currentStringToSplitP1 = "";

                                parts = getParser.toString().trim()
                                        .split("VAL");

                                currentStringToSplitP1 = parts[1].toString()
                                        .trim();

                                UIHelper.getAllAvailableOptions(selectEle,
                                        getCatDrpVals);

                                getCatDrpValsData: for (String getCatDrpValsData : getCatDrpVals) {

                                    if (getCatDrpValsData
                                            .toString()
                                            .trim()
                                            .contains(
                                                    parts[0].toString().trim())) {

                                        cats = true;
                                        valsToSelect = getCatDrpValsData
                                                .toString().trim();

                                        break getCatDrpValsData;
                                    }
                                }

                                if (cats) {

                                    if (selectEle.isPresent()) {

                                        selectEle
                                                .selectByVisibleText(valsToSelect
                                                        .toString().trim());
                                    }
                                } else {

                                    if (selectEle.isPresent()) {
                                        selectEle
                                                .selectByVisibleText("Is Not Blank");
                                    }
                                }

                                getCatDrpVals.clear();

                                String[] minMaxSplitter = null;

                                if (currentStringToSplitP1.toString().trim()
                                        .contains("to")) {

                                    minMaxSplitter = currentStringToSplitP1
                                            .toString().trim().split("to");

                                    WebElementFacade minEle = find(By
                                            .xpath(minXpath));
                                    WebElementFacade maxEle = find(By
                                            .xpath(maxpath));

                                    if (minEle.isPresent()) {
                                        minEle.type(minMaxSplitter[0]
                                                .toString().trim());
                                    }

                                    if (maxEle.isPresent()) {
                                        maxEle.type(minMaxSplitter[1]
                                                .toString().trim());
                                    }

                                } else {

                                    WebElementFacade minEle = find(By
                                            .xpath(minXpath));
                                    if (minEle.isPresent()) {
                                        minEle.type(currentStringToSplitP1
                                                .toString().trim());
                                    }
                                }

                                break alphaDataList;

                            }

                            else {
                                getCatDrpVals.clear();

                                UIHelper.getAllAvailableOptions(selectEle,
                                        getCatDrpVals);

                                cats = false;

                                getCatDrpValsData: for (String getCatDrpValsData : getCatDrpVals) {

                                    if (getCatDrpValsData
                                            .toString()
                                            .trim()
                                            .contains(
                                                    getParser.toString().trim()
                                                            .toString().trim())) {

                                        cats = true;
                                        valsToSelect = getCatDrpValsData
                                                .toString().trim();

                                        break getCatDrpValsData;
                                    }
                                }

                                if (cats) {

                                    if (selectEle.isPresent()) {

                                        selectEle
                                                .selectByVisibleText(valsToSelect
                                                        .toString().trim());
                                    }
                                } else {

                                    if (selectEle.isPresent()) {
                                        selectEle
                                                .selectByVisibleText("Is Not Blank");
                                    }
                                }

                                getCatDrpVals.clear();

                            }
                        }

                    }

                } catch (Exception e) {

                    e.printStackTrace();
                }

            }

            // Analytics End

            partsDataList.clear();

            getCurrentRuleCatsList.clear();
            finalData.clear();
            finalDataReplica.clear();*/

        } catch (Exception e) {

            e.printStackTrace();

            // throw E;
        }

    }
public void addVluesToVeriables(String formulaToADD){
	try{
		
		 	partsDataList.clear();
	        getCurrentRuleCatsList.clear();
	        finalData.clear();
	        finalDataReplica.clear();

	        outerDivElement.waitUntilPresent();

	        int clearCounter = 1;

	        try {

	            String[] partsFOR = formulaToADD.toString().trim().split("FOR");

	            for (int partsData = 0; partsData < partsFOR.length; partsData++) {

	               System.out.println("first--------------------------"+partsFOR[partsData].toString().trim());
	            	partsDataList.add(partsFOR[partsData].toString().trim());

	            }

	           UIHelper.removeDuplicatesFromArrayList(someTextList);
	            // Get an iterator.
	            Iterator<String> ite = someTextList.iterator();
	            ArrayList<String> partsDataListFiltered = new ArrayList<String>();
	            String[] formulaPartsForRulesAnalytics;

	            for (String partsDataListData : partsDataList) {

	                if (partsDataListData.toString().trim().contains("Is")) {

	                    formulaPartsForRulesAnalytics = partsDataListData
	                            .toString().trim().split("Is");
	                    System.out.println("second-----------------"+formulaPartsForRulesAnalytics[0]
	                            .toString().trim());
	                    partsDataListFiltered.add(formulaPartsForRulesAnalytics[0]
	                            .toString().trim());

	                }

	                else if (partsDataListData.toString().trim().contains("Does")) {

	                    formulaPartsForRulesAnalytics = partsDataListData
	                            .toString().trim().split("Does");
	                    partsDataListFiltered.add(formulaPartsForRulesAnalytics[0]
	                            .toString().trim());

	                }

	                else if (partsDataListData.toString().trim()
	                        .contains("Contains")) {

	                    formulaPartsForRulesAnalytics = partsDataListData
	                            .toString().trim().split("Contains");
	                    partsDataListFiltered.add(formulaPartsForRulesAnalytics[0]
	                            .toString().trim());

	                } else {
	                    partsDataListFiltered.add(partsDataListData.toString()
	                            .trim());
	                }
	            }

	            UIHelper.removeDuplicatesFromArrayList(partsDataListFiltered);

	            /* while (ite.hasNext()) {

	                String getITe = ite.next();

	                for (String twoDataList : partsDataListFiltered) {

	                    if (twoDataList.toString().trim()
	                            .equalsIgnoreCase(getITe.toString().trim())) {
	                    	System.out.println("last data-----------------------------"+getITe.toString().trim());
	                        finalData.add(getITe.toString().trim());
	                    }

	                }

	            }*/

	            // Add all from Selected fields;

	          
	            for (String twoDataList : partsDataListFiltered) {

	            	finalData.add(twoDataList.toString().trim());
	            }

	            UIHelper.removeDuplicatesFromArrayList(finalData);
	            for (String finalDataList : finalData) {

	                finalDataReplica.add(finalDataList);
	            }

	          if (clearCounter == 1) {
	                someTextList.clear();
	                finalData.clear();

	                clearCounter++;
	            }
		 // Add and Save
        // Select Available Variable - End
        // **********************************************************************

        ruleNextBtnEle.click();

        outerDivElement.waitUntilPresent();
        UIHelper.waitForPageToLoad(getDriver());

        for (String finalDataReplicaList : finalDataReplica) {
            
        	
        	finalData.add(finalDataReplicaList);

        }
        	
        UIHelper.removeDuplicatesFromArrayList(finalData);
        finalData.remove(Collections.singleton(null));

        // Analytics Start
        for (String finalDataList : finalData) {

            String webElementFacadeController = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'FIFA')]";
            String selectxPath = "//*[@class='outerDiv']//*[contains(@class,'results')]//td//*[contains(text(),'FIFA')]//ancestor::tr[1]//following-sibling::tr[1]//select";
            String minXpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//tr//*[@class='RowGray' or @class='RowWhite']//td//*[contains(text(),'FIFA')]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'_min_1')]";
            String maxpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//tr//*[@class='RowGray' or @class='RowWhite']//td//*[contains(text(),'FIFA')]//ancestor::tr[1]//following-sibling::tr[1]//*[contains(@id,'_max_1')]";

            selectxPath = selectxPath.replace("FIFA", finalDataList
                    .toString().trim());
            
            webElementFacadeController = webElementFacadeController
                    .replace("FIFA", finalDataList.toString().trim());
            
            minXpath = minXpath.replace("FIFA", finalDataList.toString()
                    .trim());

            maxpath = maxpath.replace("FIFA", finalDataList.toString()
                    .trim());

            WebElementFacade selectEle = find(By.xpath(selectxPath));
            WebElementFacade webElementFacadeControllerEle = find(By
                    .xpath(webElementFacadeController));

            if (webElementFacadeControllerEle.isPresent()) {

                UIHelper.highlightElement(getDriver(),
                        webElementFacadeControllerEle);

            }

            String[] parts = null;
            ArrayList<String> getCatDrpVals = new ArrayList<String>();
            String valsToSelect = null;
            boolean cats = false;

            try {

                alphaDataList: for (String alphaDataList : partsDataList) {

                    if (alphaDataList.contains(finalDataList)) {

                        String getParser = alphaDataList.replace(
                                finalDataList, "");

                        if (getParser.toString().trim().contains("VAL")) {

                            String currentStringToSplitP1;
                            currentStringToSplitP1 = "";

                            parts = getParser.toString().trim()
                                    .split("VAL");

                            currentStringToSplitP1 = parts[1].toString()
                                    .trim();

                            UIHelper.getAllAvailableOptions(selectEle,
                                    getCatDrpVals);

                            getCatDrpValsData: for (String getCatDrpValsData : getCatDrpVals) {

                                if (getCatDrpValsData
                                        .toString()
                                        .trim()
                                        .contains(
                                                parts[0].toString().trim())) {

                                    cats = true;
                                    valsToSelect = getCatDrpValsData
                                            .toString().trim();

                                    break getCatDrpValsData;
                                }
                            }

                            if (cats) {

                                if (selectEle.isPresent()) {

                                    selectEle
                                            .selectByVisibleText(valsToSelect
                                                    .toString().trim());
                                }
                            } else {

                                if (selectEle.isPresent()) {
                                    selectEle
                                            .selectByVisibleText("Is Not Blank");
                                }
                            }

                            getCatDrpVals.clear();

                            String[] minMaxSplitter = null;

                            if (currentStringToSplitP1.toString().trim()
                                    .contains("to")) {

                                minMaxSplitter = currentStringToSplitP1
                                        .toString().trim().split("to");

                                WebElementFacade minEle = find(By
                                        .xpath(minXpath));
                                WebElementFacade maxEle = find(By
                                        .xpath(maxpath));

                                if (minEle.isPresent()) {
                                    minEle.type(minMaxSplitter[0]
                                            .toString().trim());
                                }

                                if (maxEle.isPresent()) {
                                    maxEle.type(minMaxSplitter[1]
                                            .toString().trim());
                                }

                            } else {

                                WebElementFacade minEle = find(By
                                        .xpath(minXpath));
                                if (minEle.isPresent()) {
                                    minEle.type(currentStringToSplitP1
                                            .toString().trim());
                                }
                            }

                            break alphaDataList;

                        }

                        else {
                            getCatDrpVals.clear();

                            UIHelper.getAllAvailableOptions(selectEle,
                                    getCatDrpVals);

                            cats = false;

                            getCatDrpValsData: for (String getCatDrpValsData : getCatDrpVals) {

                                if (getCatDrpValsData
                                        .toString()
                                        .trim()
                                        .contains(
                                                getParser.toString().trim()
                                                        .toString().trim())) {

                                    cats = true;
                                    valsToSelect = getCatDrpValsData
                                            .toString().trim();

                                    break getCatDrpValsData;
                                }
                            }

                            if (cats) {

                                if (selectEle.isPresent()) {

                                    selectEle
                                            .selectByVisibleText(valsToSelect
                                                    .toString().trim());
                                }
                            } else {

                                if (selectEle.isPresent()) {
                                    selectEle
                                            .selectByVisibleText("Is Not Blank");
                                }
                            }

                            getCatDrpVals.clear();

                        }
                    }

                }

            } catch (Exception e) {

                e.printStackTrace();
            }

        }

        // Analytics End
        partsDataList.clear();

        getCurrentRuleCatsList.clear();
        finalData.clear();
        finalDataReplica.clear();
	}catch (Exception e) {

        e.printStackTrace();

        // throw E;
    }
	        
	}catch (Exception e) {

		
    }
	
}
    public void clickNextBtnInRuleConditions() throws Exception{
       try{
    	ruleNextBtnEle.waitUntilClickable();
        ruleNextBtnEle.click();

        outerDivElement.waitUntilPresent();
        UIHelper.waitForPageToLoad(getDriver());
       } catch (Exception E) {
           throw E;
       }
    }

    public void applyORRulesCondition(String getCurrentRuleCats,
            String formulaToADD) throws Exception {

        try {

            // Click Next - Inputs for OR are not mandatory
            createANewruleWithSpecialCondiTions(getCurrentRuleCats,
                    formulaToADD);

        } catch (Exception E) {
            throw E;
        }

    }

    public void applyOVERRIDERulesCondition(String getCurrentRuleCats,
            String formulaToADD) throws Exception {

        try {

            createANewruleWithSpecialCondiTions(getCurrentRuleCats,
                    formulaToADD);

        } catch (Exception E) {
            throw E;
        }

    }

    ArrayList<String> getCreditValsZpath = new ArrayList<String>();
    String getValsToSelect = null;

    public void defineCreditLimitTerms(String getCurrentCLToEnter)
            throws InterruptedException {

        try {

            outerDivElement.waitUntilPresent();
            selectDefineCreditLimitTerms.waitUntilVisible();
            UIHelper.highlightElement(getDriver(), selectDefineCreditLimitTerms);
            defineCreditLimitTermsXpath.waitUntilVisible();
            System.out.println("value which we have passed-----------------"+getCurrentCLToEnter);
            UIHelper.getAllAvailableOptions(defineCreditLimitTermsXpath,
                    getCreditValsZpath);

            getCreditValsZpath.remove(null);
            if (getCreditValsZpath.contains("Select the Credit Limit & Terms")) {
                getCreditValsZpath.remove("Select the Credit Limit & Terms");
            }

            boolean boolforRules = false;

            for (String getCreditValsZpathData : getCreditValsZpath) {
            	
                if (StringUtils.contains(getCreditValsZpathData,
                        getCurrentCLToEnter.toString().trim())) {

                    boolforRules = true;
                    getValsToSelect = getCreditValsZpathData.toString().trim();
                    
                    break;
                 }else{
                	 System.out.println("value is not matched-----------"+getCreditValsZpathData);
                	 System.out.println("value need to select-----------------"+getCurrentCLToEnter);
                 }
               	

            }

            if (boolforRules) {
            	System.out.println("condition is ture now value has to select-----------------"+getValsToSelect);
                defineCreditLimitTermsXpath.selectByVisibleText(getValsToSelect
                        .toString().trim());
                
            } else {

                for (String getCreditValsZpathData : getCreditValsZpath) {
                	System.out.println("value in else part---------------- "+getCreditValsZpath);
                    if (!getCreditValsZpathData.isEmpty()
                            && getCreditValsZpathData != null) {

                        if (!getCreditValsZpathData.toString().trim()
                                .contains("Select the Credit")) {
                        	System.out.println("value selected in else part---------------- "+getCreditValsZpath);
                            defineCreditLimitTermsXpath
                                    .selectByVisibleText(getCreditValsZpathData
                                            .toString().trim());
                            break;
                        }
                    }

                }
            }

            ruleNextBtnEle.waitUntilClickable();
            ruleNextBtnEle.click();

            outerDivElement.waitUntilPresent();
            UIHelper.waitForPageToLoad(getDriver());

        } catch (Exception E) {
            throw E;
        }
    }
    public void ClickNextBtn(){
    	if (ruleNextBtnEle.isPresent()){
    		ruleNextBtnEle.waitUntilClickable();
            ruleNextBtnEle.click();

            outerDivElement.waitUntilPresent();
            UIHelper.waitForPageToLoad(getDriver());
    		
    	}
    	 
    	
    }

    public void defineAnalystInstructions() throws InterruptedException {

        try {
        	// Enter some Analyst Instructions
        	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), area);

            if (analystInstructionTextArea.isPresent()) {

                analystInstructionTextArea.click();

                analystInstructionTextArea.type("DNBi Test AnalystText");

            } else {

            }

            // Click Next - Inputs for Credit Limits are not mandatory
            //ruleNextBtnEle.waitUntilClickable();
            UIHelper.highlightElement(getDriver(), ruleNextBtnEle);
            ruleNextBtnEle.click();
/*
            outerDivElement.waitUntilPresent();
            UIHelper.waitForPageToLoad(getDriver());*/
            
            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), RulenameBox);

        } catch (Exception E) {

            throw E;
        }

    }

    public void enteraRuleNameandSave(String ruleName) throws Exception {

        try {

            // Enter a Rule name and Save
        	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), RulenameBox);
        	defineRuleName.click();
            defineRuleName.type(ruleName);
            
            // Save
            UIHelper.highlightElement(getDriver(), saveDecisionRule);
            saveDecisionRule.click();
            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tableResFull1);

           /* if (loadingRulesEle.isPresent()) {
                UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                        loadingRulesEleXPath);
            }

            UIHelper.waitForPageToLoad(getDriver());*/

        } catch (Exception E) {

            throw E;
        }

    }

    public String getRulesFromResults() {
    	setRulesPerPage();
        return tableResFull.getText();
    }
    
    public void setRulesPerPage(){
    	 viewlistListbox.waitUntilPresent();
         UIHelper.highlightElement(getDriver(), viewlistListbox);
         viewlistListbox.selectByVisibleText("50");
         waitFor(5000).milliseconds();
         UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tableResFull1);
    }
}