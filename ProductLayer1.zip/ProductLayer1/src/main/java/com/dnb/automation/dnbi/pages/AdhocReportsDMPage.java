package com.dnb.automation.dnbi.pages;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;




import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class AdhocReportsDMPage extends PageObject{
	
	@FindBy(xpath="//*[@id='primaryNav']/li[5]/a")
	private WebElementFacade decisionMakerLink;
	
	@FindBy(xpath="//div[@class='full_widget widget']//a[@id='saveTemplates']")
	private WebElementFacade savedTemplates;
	
	@FindBy(xpath="//div[@id='widget_container']//input[@value='Create Report']")
	private WebElementFacade createReportBtn;
	
	@FindBy(xpath="//ul[@id='select_report']//input[@value='TABULAR']")
	private WebElementFacade tabularReport;
	
	@FindBy(xpath="//div[@id='backRight']//input[@value='Next >']")
	private WebElementFacade reportLayoutNextBtn;
	
	@FindBy(xpath="//img[@src='/dnbi/skins/credit/us/images/img_ico/arrow_right_blue_add.gif']")
	 private WebElementFacade clickAddVariables;
	 
	 @FindBy(xpath="//div[@id='reportArea_main']//input[@class='btn btnPrimary']")
	 private WebElementFacade clickNEXTVariables;
	 
	 @FindBy(xpath="//div[@id='reportArea_mainMill']//input[@value='Next >']")
	 private WebElementFacade sortNEXT;
	 
	 @FindBy(xpath="//input[@id='savereport']")
	 private WebElementFacade saveReport;
	 
	 @FindBy(xpath="//ul[@class='save_report']//input[@name='reportName']")
	 private WebElementFacade ReportNameXpath;
	 
	 @FindBy(xpath="//div[@class='tablistReport']//a[@id='generatedTab']")
	 private WebElementFacade completedReports;
	 
	 @FindBy(xpath="//div[@id='page_modal']//input[@value='Download']")
	 private WebElementFacade downloadBtn;
	
	 @FindBy(xpath="//div[@class='reports_backRight']//input[@value='Next >']")
	 private WebElementFacade groupNEXT;
	 
	 @FindBy(xpath="//*[@id='sumFunction[0]']")
	 private WebElementFacade sumFirstVariable;
	 
	 @FindBy(xpath="//*[@id='sumFunction[1]']")
	 private WebElementFacade sumSecondVariable;
	 
	 @FindBy(xpath="//*[@id='sumFunction[2]']")
	 private WebElementFacade sumThirdVariable;
	 
	 @FindBy(xpath="//div[@id='backRight']//input[@value='Next >']")
	 private WebElementFacade summaryNEXT;
	 
	 @FindBy(xpath="//div[@class='floatRight wid_report']//input[@id='runreport']")
	 private WebElementFacade saveRunReport;
	 
	 public String getStatus;
	 
	public void clickDecisionMakerTab(){

		decisionMakerLink.waitUntilClickable();
		decisionMakerLink.click();
		UIHelper.waitForPageToLoad(getDriver());

	}
	
	public void deleteReport(String reportName){
		try{
			savedTemplates.waitUntilClickable();
			waitFor(5000);
			savedTemplates.click();
			UIHelper.waitForPageToLoad(getDriver());
			List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr/td[1]"));
			if(getReportNames.size()>=1)
			for(int i=1;i<=getReportNames.size();i++){
				String getReportName=getDriver().findElement(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
				if(getReportName.equalsIgnoreCase(reportName)){
					getDriver().findElement(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[9]/a")).click();
					UIHelper.processalert(getDriver());
					UIHelper.waitForPageToLoad(getDriver());
					waitFor(3000);
				}
			}
			
			completedReports.waitUntilClickable();
			completedReports.click();
			UIHelper.waitForPageToLoad(getDriver());
			List<WebElement> getReportNameCompleted=getDriver().findElements(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr/td[1]"));
			if(getReportNameCompleted.size()>=1)
			for(int i=1;i<=getReportNameCompleted.size();i++)
			{
				String getReportName= getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
				if(getReportName.equalsIgnoreCase(reportName))
				{
					getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[9]")).click();
					UIHelper.processalert(getDriver());
					UIHelper.waitForPageToLoad(getDriver());
				}	
			}	
			
		}catch(StaleElementReferenceException e){
			e.printStackTrace();
		}
	}
	
	public void deleteConfirmation(){
		System.out.println("Deleted Alert:");
	}
	
	public void checkDeletedReport(String reportName){
		waitFor(3000);
		savedTemplates.waitUntilClickable();
		savedTemplates.click();
		UIHelper.waitForPageToLoad(getDriver());
		String getReportName="";
		List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr/td[1]"));
		System.out.println("Number of reports displayed:" +getReportNames.size());
		for(int i=1;i<=getReportNames.size();i++){
			UIHelper.waitForPageToLoad(getDriver());
			getReportName=getDriver().findElement(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
			Assert.assertFalse(reportName.contains(getReportName));
		}
	}
	
	public void clickCreateReportBtn(){
		createReportBtn.waitUntilClickable();
		createReportBtn.click();
	}
	
	public void clickTabularReport(){
		tabularReport.waitUntilClickable();
		tabularReport.click();
	}
	
	public void clickReportLayoutNext(){
		reportLayoutNextBtn.waitUntilClickable();
		reportLayoutNextBtn.click();
	}
	
	 public void selectCategoryVariablesDM(String category, String variableName1, String variableName2, String variableName3,String variableName4) throws InterruptedException{
		 try{
		 UIHelper.waitForPageToLoad(getDriver());
		 System.out.println("Category selected is:++++++++++++++++++++" +category);
		 Thread.sleep(2000);
		 Select selectCategory = new Select(getDriver().findElement(By.xpath("//div[@class='report_widget widget_form']//select[@name='selectedCategory']")));
		 selectCategory.selectByVisibleText(category);
		 Select addVariables = new Select(getDriver().findElement(By.xpath("//div[@id='vars']//select[@id='pool']")));
		 addVariables.selectByVisibleText(variableName1);
		 addVariables.selectByVisibleText(variableName2);
		 addVariables.selectByVisibleText(variableName3);
		 addVariables.selectByVisibleText(variableName4);
		 clickAddVariables.waitUntilClickable();
		 clickAddVariables.click();
		 clickNEXTVariables.click();
		 Thread.sleep(3000);
		 }catch(Exception e)
		 {
			 e.printStackTrace();
		 }
	 }

	 public void sortFilter(String SortVariable){
			try{
				UIHelper.waitForPageToLoad(getDriver());
				Select filter = new Select(getDriver().findElement(By.xpath("//table[@class='results customBorder']//select[@id='SORT_NAME_0']")));
				filter.selectByVisibleText(SortVariable);
				sortNEXT.click();
				Thread.sleep(3000);
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	 
	 public void saveReport(String reportName, String OutputFormat, String ReportType, String priority){

			
				System.out.println("Into Save Template method:");
			UIHelper.waitForPageToLoad(getDriver());
			System.out.println("Report Name is:++++++++" +reportName);
			ReportNameXpath.sendKeys(reportName);
			System.out.println("Output Format is:++++++++" +OutputFormat);
			//Select the Output Format
			if(OutputFormat.contains("HTML"))
			{
				getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[2]/span/input[1]")).click();
			}
			else if(OutputFormat.contains("PDF")){
				getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[2]/span/input[2]")).click();
			}
			else if(OutputFormat.contains("Excel")){
				getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[2]/span/input[3]")).click();
			}
			else{
				getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[2]/span/input[4]")).click();
			}
			
			System.out.println("ReportType is:++++++++" +ReportType);
			//Specify the report
			List<WebElement> getReportType = getDriver().findElements(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[3]/span/input"));
			for(int i=1;i<=getReportType.size();i++)
			{
				String reportType=getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[3]/span/input[" +i +"]")).getText();
				if(ReportType.equalsIgnoreCase(reportType))
				{
					getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[3]/span/input[" +i +"]")).click();
				}
			}
			
			System.out.println("Priority is:++++++++" +priority);
			//Report Priority
			if(priority.contains("High"))
				getDriver().findElement(By.xpath("//input[@id='highPriority']")).click();
			else
				getDriver().findElement(By.xpath("//input[@id='normalPriority']")).click();
			
			//Save Report
			saveReport.waitUntilClickable();
			saveReport.click();
			

		
	 }
	 
	 public void saveRunReport(String reportName, String OutputFormat, String ReportType, String priority){


				System.out.println("Into Save Template method:");
			UIHelper.waitForPageToLoad(getDriver());
			System.out.println("Report Name is:++++++++" +reportName);
			ReportNameXpath.sendKeys(reportName);
			System.out.println("Output Format is:++++++++" +OutputFormat);
			//Select the Output Format
			if(OutputFormat.contains("HTML"))
			{
				getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[2]/span/input[1]")).click();
			}
			else if(OutputFormat.contains("PDF")){
				getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[2]/span/input[2]")).click();
			}
			else if(OutputFormat.contains("Excel")){
				getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[2]/span/input[3]")).click();
			}
			else{
				getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[2]/span/input[4]")).click();
			}
			
			System.out.println("ReportType is:++++++++" +ReportType);
			//Specify the report
			List<WebElement> getReportType = getDriver().findElements(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[3]/span/input"));
			for(int i=1;i<=getReportType.size();i++)
			{
				String reportType=getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[3]/span/input[" +i +"]")).getText();
				if(ReportType.equalsIgnoreCase(reportType))
				{
					getDriver().findElement(By.xpath("//*[@id='reportArea_main']/div[1]/div/ul/li[3]/span/input[" +i +"]")).click();
				}
			}
			
			System.out.println("Priority is:++++++++" +priority);
			//Report Priority
			if(priority.contains("High"))
				getDriver().findElement(By.xpath("//input[@id='highPriority']")).click();
			else
				getDriver().findElement(By.xpath("//input[@id='normalPriority']")).click();
			
			//Save and Run Report
			saveRunReport.waitUntilClickable();
			saveRunReport.click();
			

		
	 }
	 
	 public void runReport(String ReportName){

			waitFor(3000).milliseconds();
			UIHelper.waitForPageToLoad(getDriver());
			
			List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr/td[1]"));
			for(int i=1;i<=getReportNames.size();i++)
			{
				String getReportName=getDriver().findElement(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
				System.out.println("All report Names are:++++++++" +getReportName);
				if(getReportName.equalsIgnoreCase(ReportName))
				{
					waitFor(3000).milliseconds();
					getDriver().findElement(By.xpath("//div[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[7]/a")).click();
					System.out.println("Clicked Run for reportName:+++++" +ReportName);	
					waitFor(3000).milliseconds();
				}			
			}
	
		}
	 
	 public void runHighReport(String ReportName){

			waitFor(3000).milliseconds();
			UIHelper.waitForPageToLoad(getDriver());
			
			List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr/td[1]"));
			for(int i=1;i<=getReportNames.size();i++)
			{
				String getReportName=getDriver().findElement(By.xpath("//*[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
				System.out.println("All report Names are:++++++++" +getReportName);
				if(getReportName.equalsIgnoreCase(ReportName))
				{
					waitFor(3000).milliseconds();
					getDriver().findElement(By.xpath("//div[@id='template_widget_container']/form/table/tbody/tr["+i+"]/td[7]/a")).click();
					System.out.println("Clicked Run for reportName:+++++" +ReportName);	
					waitFor(65000).milliseconds();
					getDriver().switchTo().frame("__modal_iframe_target");
					downloadBtn.waitUntilClickable();
					downloadBtn.click();
					System.out.println("Clicked on Download button++++++++++++++++++++++++++++++");
				}			
			}
	
		}
		
		public String checkStatus(String reportName){
			UIHelper.waitForPageToLoad(getDriver());
			waitFor(3000).milliseconds();
			savedTemplates.click();
			waitFor(5000).milliseconds();
			completedReports.click();
			waitFor(3000).milliseconds();
			
			List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr/td[1]"));
			for(int i=1;i<=getReportNames.size();i++)
			{
				String getReportName= getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
				System.out.println("All report Name:++++" +getReportName);
				if(getReportName.equalsIgnoreCase(reportName))
				{
					getStatus=getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[7]")).getText();
				}
			}
			if(!getStatus.equals("Completed")){
				getDriver().navigate().refresh();
				UIHelper.waitForPageToLoad(getDriver());
				waitFor(5000).milliseconds();
				getDriver().navigate().refresh();
				UIHelper.waitForPageToLoad(getDriver());
				for(int i=1;i<=getReportNames.size();i++)
				{
					String getReportName= getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
					System.out.println("All report Name:++++" +getReportName);
					if(getReportName.equalsIgnoreCase(reportName))
					{
						getStatus=getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[7]")).getText();
					}
				}
			}
			System.out.println("Current status:+++++" +getStatus);
			return getStatus;
		}
		
		public void openReport(String ReportName){
			try{
			List<WebElement> getReportNames=getDriver().findElements(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr/td[1]"));
			for(int i=1;i<=getReportNames.size();i++)
			{
				String getReportName= getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).getText();
				System.out.println("All report Name:++++" +getReportName);
				if(getReportName.equalsIgnoreCase(ReportName))
				{
					getDriver().findElement(By.xpath("//*[@id='report_widget_container']/form/table/tbody/tr["+i+"]/td[1]")).click();
				}	
			}
			Thread.sleep(6000);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		public void downloadReport(){
			UIHelper.waitForPageToLoad(getDriver());
			waitFor(5000);
			getDriver().switchTo().frame("__modal_iframe_target");
			downloadBtn.waitUntilClickable();
			downloadBtn.click();
		}
		
		public void groupInfo(String businessName, String Country, String DBRating)
		{
			UIHelper.waitForPageToLoad(getDriver());
			Select selectGroup1= new Select(getDriver().findElement(By.xpath("//ul[@class='group_report']//select[@name='groupFieldInfoList[0].groupFieldName']")));
			selectGroup1.selectByVisibleText(businessName);
			Select selectGroup2 = new Select(getDriver().findElement(By.xpath("//ul[@class='group_report']//select[@name='groupFieldInfoList[1].groupFieldName']")));
			selectGroup2.selectByVisibleText(Country);
			Select selectGroup3 = new Select(getDriver().findElement(By.xpath("//ul[@class='group_report']//select[@name='groupFieldInfoList[2].groupFieldName']")));
			selectGroup3.selectByVisibleText(DBRating);
			groupNEXT.click();
		}
		
		public void sumVariables(){
			sumFirstVariable.waitUntilClickable();
			sumFirstVariable.click();
			sumSecondVariable.click();
			sumThirdVariable.click();
			summaryNEXT.click();
		}
	
}
