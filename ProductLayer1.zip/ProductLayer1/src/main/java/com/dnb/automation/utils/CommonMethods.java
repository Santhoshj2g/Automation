package com.dnb.automation.utils;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Date;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.apache.commons.lang3.StringUtils;
import org.jruby.RubyProcess;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.dnb.automation.cirrus.model.ServicesResponseCache;
import com.dnb.automation.cirrus.pages.SearchPage;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.LongNode;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.Option;
import com.jayway.restassured.path.json.JsonPath;

import java.util.concurrent.TimeUnit;













import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPath;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;


import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.google.common.base.Predicate;

public class CommonMethods extends PageObject {

	private StringSelection selectString;
	private Clipboard clipBoard;
	private Transferable contentToPaste;
	private String dataToTransfer;
	private StringTokenizer strTokenizer;

	private String iconReportLoading = "//*/div[@class='dnb-wrapper-content']/div[@class='row pad-bot-10']//*/div[@ng-show='!summaryLoaded && !reportHeaderSummary']";
	private String iconDtldLoading = "//*/div[@class='dnb-wrapper-content']/div[@class='row']//*/growing-iframe/div[@class='loading']";
	private String iconLoadingAge = "//*/div[@class='dnb-wrapper-content']//*/div[@class='col-md-12']/div[@class='row']/div[@class='loading']";

	/***********************************************************************************
	 * Function: Wait for all icons to finish loading the report page Input : NA
	 * Action : Wait till invisibility of icons Output : Page will be loaded
	 * fully
	 ***********************************************************************************/
	public void waitForPageLoad(WebDriver driver) {
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(driver, iconReportLoading);
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(driver, iconLoadingAge);
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(driver, iconDtldLoading);
	}


	public static void waitForAnElement(final WebDriver driver, final String elementXpath, String elementValue) {
		FluentWait<By> fluentWait = new FluentWait<By>(By.xpath(elementXpath));
		fluentWait.pollingEvery(100, TimeUnit.MILLISECONDS);
		fluentWait.withTimeout(200, TimeUnit.SECONDS);
		fluentWait.until(new Predicate<By>() {
			public boolean apply(final By by) {
				try {
					String elementVal = driver.findElement(by).getText();
					return !elementVal.equalsIgnoreCase(elementValue);
				} catch (Exception ex) {
					return false;
				}
			}
		});
	}


	/***********************************************************************************
	 * Function: Copy content given in excel and paste it in search text box
	 * Input : Copied content Action : Type Output : Copied content should be
	 * pasted in search text box
	 ***********************************************************************************/
	public void pasteText(WebElementFacade element, String searchValue) {
		// copyToClipboard
		selectString = new StringSelection(searchValue);
		clipBoard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipBoard.setContents(selectString, selectString);

		// Paste
		clipBoard = Toolkit.getDefaultToolkit().getSystemClipboard();
		contentToPaste = clipBoard.getContents(new SearchPage().getClass());
		if (contentToPaste != null) {
			if (contentToPaste.isDataFlavorSupported(DataFlavor.stringFlavor)) {
				try {
					dataToTransfer = (String) contentToPaste
							.getTransferData(DataFlavor.stringFlavor);
					if (dataToTransfer != null) {
						strTokenizer = new StringTokenizer(dataToTransfer, "\n");
						while (strTokenizer.hasMoreElements())
							element.sendKeys(strTokenizer.nextToken());
					}
				} catch (IOException ex) {
					System.out.println("IOException");
				} catch (UnsupportedFlavorException ex) {
					System.out.println("UnsupportedFlavorException");
				}
			} else
				System.out.println("Wrong flavor.");
		}
	}

	/***********************************************************************************
	 * Function: Common function of Cirrus to mouseover,highlight and sendkeys
	 * to an element Input : Element and its value Action : Mouseover,hightlight
	 * and sendkeys Output : Highlights and sendkeys to an element
	 ***********************************************************************************/
	public void highlightAndSendKeys(final WebDriver driver,
									 WebElementFacade element, String inputValue) {
		UIHelper.highlightElement(driver, element);
		element.type(inputValue);
	}

	/***********************************************************************************
	 * Function: Common function of Cirrus to verify any attribute of an element
	 * Input : Element && attribute to verify Action : Verify Output : Returns
	 * true if attribute is present
	 ***********************************************************************************/
	public boolean isAttributePresent(WebElement element, String attribute) {
		Boolean result = false;
		try {
			String value = element.getAttribute(attribute);
			if (value != null) {
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/***********************************************************************************
	 * Function : Find element with specified index Input : Index of element
	 * Action : Locate element Output : Identifies element
	 ***********************************************************************************/
	public WebElement getElementWithIndex(By by, int index) {
		return getDriver().findElements(by).get(index);
	}

	/***********************************************************************************
	 * Function : Replace "-" in DUNS number Input : Index of element Action :
	 * Locate element Output : Identifies element
	 ***********************************************************************************/
	public static String replaceHypenInDuns(String duns) {
		if (duns.contains("-")) {
			return duns.replaceAll("-", "");
		} else {
			return null;
		}
	}

	/***********************************************************************************
	 * Function : Get value from services through directMapping Input :
	 * DUNS,ProdCode,jsonPath Action : get value of element from Custom Product
	 * services Output : NA
	 ***********************************************************************************/
	public static String getValueOfCustomProductByJsonPath(String duns,
														   String prodCode, String jsonPath) {
		String servicesValue = null;
		String responseString = ServicesResponseCache
				.getProduct(duns, prodCode);
		JsonPath jsonMainPath = new JsonPath(responseString)
				.setRoot("OrderProductResponse.OrderProductResponseDetail.Product");
		try {
			servicesValue = jsonMainPath.getString(jsonPath);
		} catch (IllegalArgumentException e) {
			servicesValue = null;
		}
		return servicesValue;
	}

	public static ArrayList<String> getCustProdByJsonPath(String duns,
														  String prodCode, String jsonPath) {
		ArrayList<String> servicesValue = new ArrayList();
		String responseString = ServicesResponseCache
				.getProduct(duns, prodCode);
		JsonPath jsonMainPath = new JsonPath(responseString)
				.setRoot("OrderProductResponse.OrderProductResponseDetail.Product");
		try {
			servicesValue = jsonMainPath.get(jsonPath);
		} catch (IllegalArgumentException e) {
			servicesValue = null;
		}
		return servicesValue;
	}

	public static String getValueOfCustomProductByJsonPathForSplEvents(
			String duns, String prodCode, String jsonPath, String countryCode) {
		String servicesValue = null;
		String responseString = ServicesResponseCache
				.getProductWithLangCodeForSplEvents(duns, prodCode, countryCode);

		JsonPath jsonMainPath = new JsonPath(responseString)
				.setRoot("OrderProductResponse.OrderProductResponseDetail.Product");

		try {
			servicesValue = jsonMainPath.getString(jsonPath);

		} catch (IllegalArgumentException e) {

			servicesValue = null;
		}
		return servicesValue;
	}

	/***********************************************************************************
	 * Function : Get result value from services Input : DUNS,ProdCode Action :
	 * Get result value Output : NA
	 ***********************************************************************************/
	public static String getResultValueOfCustomProduct(String duns,
													   String prodCode) {
		String resultValue = null;
		resultValue = ServicesResponseCache.getResultValue(duns, prodCode);
		return resultValue;
	}

	/***********************************************************************************
	 * Function : Get result value from services Input : DUNS,ProdCode
	 * ,countrycode Action : Get result value Output : NA
	 ***********************************************************************************/
	public static String getResultValueOfProdCatalog(String duns,
													 String countryCode, String jsonPath) {
		String servicesValue = null;
		String responseString = ServicesResponseCache
				.getResultValueOfProdCatalog(duns, countryCode);
		return responseString;
	}

	public static String getJsonValueOfProdCatalog(String duns,
												   String countryCode, String jsonPath) {
		String servicesValue = null;
		String responseString = ServicesResponseCache
				.getJsonPathValueOfProdCatalog(duns, countryCode);
		JsonPath jsonMainPath = new JsonPath(responseString)
				.setRoot("ListAvailableProductResponse");
		try {
			servicesValue = jsonMainPath.getString(jsonPath);
		} catch (IllegalArgumentException e) {
			servicesValue = null;
		}
		return servicesValue;
	}

	/***********************************************************************************
	 * Function : Get value from services through directMapping Input :
	 * DUNS,ProdCode,jsonPath Action : get value of element from Match services
	 * Output : NA
	 ***********************************************************************************/
	public static String getValueOfMatchByJsonPath(String duns, String jsonPath) {
		String servicesValue = null;
		String responseString = ServicesResponseCache.performDUNSMatch(duns);
		String replaceAtSymbolInResponseString = responseString.replace("@DNBCodeValue", "DNBCodeValue");
		JsonPath jsonMainPath = new JsonPath(replaceAtSymbolInResponseString)
				.setRoot("MatchResponse.MatchResponseDetail.MatchCandidate[0]");
		try {
			servicesValue = jsonMainPath.getString(jsonPath);
		} catch (IllegalArgumentException e) {
			servicesValue = null;

		}
		return servicesValue;
	}

	/***********************************************************************************
	 * Function : Get value from services through directMapping Input :
	 * DUNS,ProdCode,jsonPath Action : get value of element from Entity services
	 * Output : NA
	 ***********************************************************************************/
	public static String getValueOfEntityByJsonPath(String orgName,
													String country, String jsonPath) {
		String servicesValue = null;
		String responseString = ServicesResponseCache.performEntity(orgName,
				country);
		System.out.println("Response String *** " + responseString);
		JsonPath jsonMainPath = new JsonPath(responseString)
				.setRoot("FindCompanyResponse.FindCompanyResponseDetail");
		System.out.println(" Json Main Path *** " + jsonMainPath);
		try {
			servicesValue = jsonMainPath.getString(jsonPath).replace("[", "").replace("]", "");
			System.out.println("*** Service Value **** " + servicesValue);
		} catch (IllegalArgumentException e) {
			servicesValue = null;
		}
		return servicesValue;
	}

	public static String getCurrencyCode(String varCurrency) {
		// String currentAssetValUI = varCurrency.replaceAll("\\d",
		// "").replace(",", "").trim();
		String currentAssetValUI = varCurrency.replaceAll("[^A-Za-z$]", "")
				.replace(",", "").trim();
		return currentAssetValUI;

		/*
		 * if(servicesValue.equals("CAD")){ Assert.assertEquals("C$",
		 * currentAssetValUI); } else if(servicesValue.equals("USD")){
		 * Assert.assertEquals("US$", currentAssetValUI); } else{ }
		 */
	}

	public static String getNumericValue(String varValue) {
		String currentAssetValUI = varValue.replaceAll("[^\\d.]", "");
		return currentAssetValUI;
		// Assert.assertEquals(currentAssetValUI, servicesValue);
	}

	public String getCurrencyValue(String varCurrency) {
		// String currentAssetValUI = varCurrency.replaceAll("[^\\d.]", "");
		// String currentAssetValUI = varCurrency.replaceAll("[A-Za-z]",
		// "").replace("$", "").replace(",", "").trim(); // commented on
		// 7/7/2016 to implement UK & IE change if any failures
		String currentAssetValUI = varCurrency.replaceAll("[^0-9]", "").trim();
		return currentAssetValUI;
		// Assert.assertEquals(currentAssetValUI, servicesValue);
	}

	/***********************************************************************************************
	 * Function: Input : Action : Output :
	 ***********************************************************************************************/
	public static void writeToText(String writeDnbiReportFormatValueInPath,
								   String seqNo, String reportFormat) {
		try {
			FileWriter fstreamWrite = new FileWriter(
					writeDnbiReportFormatValueInPath, true);
			BufferedWriter out = new BufferedWriter(fstreamWrite);
			String valueToWrite = seqNo + "," + reportFormat;
			out.write(valueToWrite);
			out.write("\r\n");
			out.close();
			fstreamWrite.close();
		} catch (Exception e) {
		}
	}

	public static boolean verifyTextFileIsNotNull(String dnbiPath,
												  String cirrusPath) {
		boolean fileIsNotNull = false;
		try {
			FileInputStream fstreamDnbi = new FileInputStream(dnbiPath);
			BufferedReader brDnbi = new BufferedReader(new InputStreamReader(
					fstreamDnbi));
			String strLineDnbi;

			FileInputStream fstreamCirrus = new FileInputStream(dnbiPath);
			BufferedReader brCirrus = new BufferedReader(new InputStreamReader(
					fstreamCirrus));
			String strLineCirrus;

			if ((strLineDnbi = brDnbi.readLine()) != null
					&& (strLineCirrus = brCirrus.readLine()) != null) {
				fileIsNotNull = true;
			}
			brDnbi.close();
			fstreamDnbi.close();
			brCirrus.close();
			fstreamCirrus.close();
		} catch (Exception e) {
		}
		return fileIsNotNull;
	}

	public static boolean verifyFileExists(String dnbiPath, String cirrusPath) {
		boolean dnbiFileExists = false;
		boolean cirrusFileExists = false;

		File dnbiFile = new File(dnbiPath);
		dnbiFileExists = dnbiFile.isFile();

		File cirrusFile = new File(cirrusPath);
		cirrusFileExists = cirrusFile.isFile();

		if (dnbiFileExists && cirrusFileExists) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean compareBothTheTextFiles(String file1Path,
												  String file2Path) throws IOException {
		boolean match = false;
		int count = 0;
		/*
		 * File file = new File(file1Path); File file2= new File(file2Path);
		 * Scanner sc1 = new Scanner(file); Scanner sc2 = new Scanner(file2);
		 * while (sc1.hasNext() && sc2.hasNext()) { String str1 = sc1.next();
		 * System.out.println("*********str1:"+str1); String str2 = sc2.next();
		 * System.out.println("*********str2:"+str2); if (!str1.equals(str2)) {
		 * count=count+1; System.out.println("**********count:"+count); } }
		 *
		 * while (sc1.hasNext()) System.out.println(sc1.next() + " != EOF");
		 * while (sc2.hasNext()) System.out.println("EOF != " + sc2.next());
		 * sc1.close(); sc2.close();
		 */

		FileInputStream fstream1 = new FileInputStream(file1Path);
		BufferedReader br1 = new BufferedReader(new InputStreamReader(fstream1));
		String strLine1;

		FileInputStream fstream2 = new FileInputStream(file2Path);
		BufferedReader br2 = new BufferedReader(new InputStreamReader(fstream2));
		String strLine2 = null;

		while ((strLine1 = br1.readLine()) != null
				|| (strLine2 = br2.readLine()) != null) {
			if (!strLine1.equals(strLine2)) {
				count = count + 1;
			}
		}

		if (count != 0) {
			match = false;
		} else {
			match = true;
		}
		return match;
	}

	public static ArrayList<String> getOptionsOfListBox(
			List<WebElementFacade> elementName) {
		ArrayList<String> listOfOptions = new ArrayList();
		try {
			for (WebElementFacade options : elementName) {
				listOfOptions.add(options.getText());
			}
		} catch (Exception e) {

		}
		return listOfOptions;
	}

	public Map<String, String> asMap(String json) throws IOException,
			JSONException {
		ObjectMapper objectMapper = new ObjectMapper();
		if (StringUtils.isEmpty(json))
			return null;
		validate(json);
		JsonNode rootNode = objectMapper.readTree(json);
		Map<String, String> nodes = new HashMap<>();
		recursivelyIterateOverAllJsonPropertiesAndPutPropertiesInStringStringMap(
				rootNode, null, nodes);
		return nodes;
	}

	private void recursivelyIterateOverAllJsonPropertiesAndPutPropertiesInStringStringMap(
			JsonNode node, String rootPath, Map<String, String> properties) {
		if (node.isValueNode()) {
			addJsonPropertyToStringStringMap(node, rootPath, properties);
		} else if (node.isArray()) {
			int index = 0;
			Iterator<JsonNode> elements = node.elements();
			while (elements.hasNext()) {
				JsonNode element = elements.next();
				String path = buildJsonPathForArrayElement(rootPath, index);
				index++;
				recursivelyIterateOverAllJsonPropertiesAndPutPropertiesInStringStringMap(
						element, path, properties);
			}
		} else {
			Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
			while (fields.hasNext()) {
				Map.Entry<String, JsonNode> field = fields.next();
				String path = buildJsonPathForObject(rootPath, field.getKey());
				recursivelyIterateOverAllJsonPropertiesAndPutPropertiesInStringStringMap(
						field.getValue(), path, properties);
			}
		}
	}

	private void addJsonPropertyToStringStringMap(JsonNode node,
												  String rootPath, Map<String, String> properties) {
		if (node.isFloatingPointNumber() && node.asDouble() == node.asLong()) {
			node = new LongNode(node.asLong());
		}
		properties.put(rootPath, node.asText());
	}

	private String buildJsonPathForArrayElement(String rootPath, int index) {
		String name = String.format("[%d]", index);
		String path = (rootPath == null) ? name : rootPath + name;
		return path;
	}

	private String buildJsonPathForObject(String rootPath, String key) {
		return (rootPath == null) ? key : rootPath + FIELD_SEPARATOR + key;
	}

	private static String FIELD_SEPARATOR = ".";

	public String validate(String json) throws IOException, JSONException {
		JSONObject jsonObject;
		try {
			jsonObject = new JSONObject(json);
		} catch (Exception e) {
			String message = "Format issue :[" + json + "]";
			throw new JsonParseException(message, null, new Throwable(e));
		}
		return jsonObject.toString();
	}

	public static String getServiceValueDcx(String duns, String prodCode, String jsonPath, String countryCode) {
		String serviceValue = "";
		try {
			String responseString = ServicesResponseCache.getProduct(duns, prodCode).replaceAll("@", "");
			////System.out.println("responseString = "+responseString);
			StringBuffer completeCoulmnName = new StringBuffer();
			Configuration configuration = Configuration.defaultConfiguration()
					.addOptions(Option.DEFAULT_PATH_LEAF_TO_NULL)
					.addOptions(Option.SUPPRESS_EXCEPTIONS)
					.addOptions(Option.REQUIRE_PROPERTIES);
			DocumentContext dCtx = com.jayway.jsonpath.JsonPath.using(
					configuration).parse(responseString);
			serviceValue = dCtx.read(jsonPath) != null ? dCtx.read(jsonPath).toString() : "";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return serviceValue;
	}

	public static String getattributeinXML(String xmldata, String attr, int location) throws Exception {
		DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		//StringReader sreader = new StringReader(xmldata);
		InputSource src = new InputSource();
		src.setCharacterStream(new StringReader(xmldata));

		Document doc = builder.parse(src);
		//doc.getDocumentElement().normalize();
		//XPath xpath = XPathFactory.newInstance().newXPath();
		//NodeList node = (NodeList) xpath.compile(location).evaluate(doc, XPathConstants.NODESET);
		//System.out.println(node.item(0).getNodeValue());
		String attribute = doc.getElementsByTagName(attr).item(location).getTextContent();
		return attribute;
	}

	public String getCurrUrl() {
		String currentURL = null;
		UIHelper.waitForPageToLoad(getDriver());
		currentURL = getDriver().getCurrentUrl();
		return currentURL;
	}

	public void goToAUrl(String url) {
		getDriver().get(url);
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), "//*/div[@class='loading']");
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), "//*/div[@class='loading']");
	}

	public void waitForStaleness(final WebDriver driver, final List<WebElement> element, int timeout) {
//		 WebDriverWait wait = new WebDriverWait(driver, 10);		
//		 wait.until(ExpectedConditions.stalenessOf(element));	

		final WebDriverWait wait = new WebDriverWait(driver, timeout);
		wait.until(ExpectedConditions.refreshed(
				ExpectedConditions.visibilityOfAllElements((element))));
//		     element.get(element.size()).isEnabled();

	}


	public static String getCurrentDate() throws Exception {
		DateFormat dateformat = new SimpleDateFormat("dd-mm-yyyy");
		Date date = new Date();
		String currentDate = dateformat.format(date);
		return currentDate;
	}

	public static int getNodelength(String xmldata, String commentry) throws Exception {
		DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		InputSource src = new InputSource();
		src.setCharacterStream(new StringReader(xmldata));
		Document doc = builder.parse(src);
		int length = doc.getNodeName().length();
		return length;
	}

	public static List<String> getattributeListinXML(String xmldata, String attr) throws Exception {
		List<String> result = new ArrayList<>();
		DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		InputSource src = new InputSource();
		src.setCharacterStream(new StringReader(xmldata));
		Document doc = builder.parse(src);
		NodeList node = doc.getElementsByTagName(attr);
		for(int index=0;index<node.getLength(); index++)
			result.add(node.item(index).getTextContent());

		return result;
	}
}
