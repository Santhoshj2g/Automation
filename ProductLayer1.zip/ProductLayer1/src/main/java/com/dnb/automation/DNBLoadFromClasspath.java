package com.dnb.automation;

import java.io.IOException;
import java.util.Properties;

import org.jbehave.core.io.LoadFromClasspath;

/**
 * 
 * @author BlanchardB
 *
 */
public class DNBLoadFromClasspath extends LoadFromClasspath {

	/*
	 * 
	 */
	public DNBLoadFromClasspath() {
		super();
		Properties props = new Properties();
		String sysPropFileLocation = System.getProperty(Constants.SYSTEM_PROPERTY_FILE_LOCATION);
		if (sysPropFileLocation != null) {
			try {
				props.load(this.getClass().getResourceAsStream(
						sysPropFileLocation + System.getProperty(Constants.ENVIRONMENT) + ".properties"));
			} catch (IOException e) {
				e.printStackTrace();
			}
			for (Object key : props.keySet()) {
				if (System.getProperty(key.toString(), null) == null) {
					System.setProperty(key.toString(), props.getProperty(key.toString().trim()));
				}
			}
		}
	}

	/*
	 * This code changes the passed in resourcePath based Environment and
	 * apPUsername (non-Javadoc)
	 * 
	 * @see org.jbehave.core.io.LoadFromClasspath#loadResourceAsText(java.lang.
	 * String)
	 */
	@Override
	public String loadResourceAsText(String resourcePath) {

		String env = System.getProperty(Constants.ENVIRONMENT);
		String user = System.getProperty(Constants.APP_USER_NAME);
		String newPath = resourcePath.replaceAll("\\$env", env + "/" + user);

		return super.loadResourceAsText(newPath);
	}

}
