package com.dnb.automation.dnbcom.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * LoginPage.java - Program consists of the following actions 1. Launching the
 * web application DNB.com 2. Entering the User Name, Password and Department
 * and clicks on Button Login 3. Verifying navigation to the Info page
 *
 * @author Kumaran Balasubramaniam
 ***********************************************************************************************/

public class LoginPage extends PageObject {
    // Locators for elements User name, Password, Department, Login and Info
    // page element(next page element)

    @FindBy(xpath = ".//*[@id='form-username']")
    private WebElementFacade userName;

    @FindBy(xpath = ".//*[@id='form-password']")
    private WebElementFacade password;

    @FindBy(xpath = ".//*[@id='form-person']")
    private WebElementFacade department;

    @FindBy(xpath = ".//*[@id='formWrapper_1']/div/div/input[@value='Login']")
    private WebElementFacade loginbutton;

    @FindBy(xpath = ".//input[@name='PrefNoShow']/../a")
    private WebElementFacade infopage;

    // To launch application

    public void launchApplication(String appURL) {
        getDriver().manage().deleteAllCookies();
        getURLtoLaunch(appURL);
    }

    public void getURLtoLaunch(String appURL) {
        getDriver().get(appURL);
        getDriver().manage().window().maximize();
        UIHelper.waitForPageToLoad(getDriver());
    }

    // To pass credentials and login

    public void login(String username, String pwd, String dept)
            throws Exception {
        enterUserName(username);
        enterpassword(pwd);
        enterdepartment(dept);
        loginButton();
    }

    // To pass the credentials User name, Password and Department

    public void enterUserName(String username) throws Exception {
        try {
            UIHelper.highlightElement(getDriver(), userName);
            userName.type(username);
        } catch (Exception e) {
            throw e;
        }
    }

    public void enterpassword(String pwd) throws Exception {
        try {
            UIHelper.highlightElement(getDriver(), password);
            password.type(pwd);
        } catch (Exception e) {
            throw e;
        }
    }

    public void enterdepartment(String dept) throws Exception {
        try {
            UIHelper.highlightElement(getDriver(), department);
            department.type(dept);
        } catch (Exception e) {
            throw e;
        }
    }

    // To click login button

    public void loginButton() throws Exception {
        try {
            if (loginbutton.isPresent()) {
                UIHelper.highlightElement(getDriver(), loginbutton);
                loginbutton.click();
                loginbutton.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        } catch (Exception e) {
            throw e;
        }
    }

    // To wait for next page

    public void waitForInfoPage() throws Exception {
        try {
            infopage.waitUntilPresent();
        } catch (Exception e) {
            throw e;
        }
    }

    // To verify the next page element

    public boolean hasInfoPageElement() {
        if (infopage.isPresent()) {
            return true;
        } else {
            return false;
        }
    }
}
