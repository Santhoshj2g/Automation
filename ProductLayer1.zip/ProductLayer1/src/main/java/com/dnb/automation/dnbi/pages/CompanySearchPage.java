package com.dnb.automation.dnbi.pages;

import java.util.List;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * CompanySearchPage.java - This class performs Company Search
 *
 * @author Duvvuru Naveen
 * @version 1.0
 ***********************************************************************************************/
public class CompanySearchPage extends PageObject {

    @FindBy(xpath = "//*[@id='header_mainApp']//a[text()='Dashboard']")
    private WebElementFacade disHref;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']")
    private WebElementFacade searchBox;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields_expanded']")
    private WebElementFacade searchBoxExpanded;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields_expanded']//*[@id='search_toc']//*[contains(text(),'Company')]")
    private WebElementFacade companySearchTab;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@class='moreOpt']//*[@id='quicksearch_more_options' and contains(text(),'Fewer')]")
    private WebElementFacade searchFewerOptionsEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@class='moreOpt']//*[@id='quicksearch_more_options' and contains(text(),'Fewer')]")
    private WebElementFacade companySearchmoreoptionsFewer;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@class='moreOpt']//*[@id='quicksearch_more_options' and contains(text(),'More')]")
    private WebElementFacade companySearchmoreoptionsMore;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='international_search_table']//*[@id='BizInfo-BusinessName']")
    private WebElementFacade companySearchCompanyName;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='international_search_table']//*[@id='BizInfo-Country']")
    private WebElementFacade companySearchCountryName;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='international_search_table']//*[@id='BizInfo-StreetAddress']")
    private WebElementFacade companySearchAddress;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='international_search_table']//*[@id='BizInfo-City']")
    private WebElementFacade companySearchCity;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='international_search_table']//*[@id='BizInfo-ZIPCode']")
    private WebElementFacade companySearchZipCode;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='international_search_table']//*[@id='BizInfo-DUNS']")
    private WebElementFacade companySearchBizDuns;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='international_search_table']//*[@name='intcompanyPhoneNo']")
    private WebElementFacade companySearchphoneNumber;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*//*[@id='search_fields']//*[@class='frm_search1']//*[@name='Search']")
    private WebElementFacade companySearchButton;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*//*[@id='search_fields']//*[@class='frm_search1']//*[@name='reset']")
    private WebElementFacade companySearchResetbutton;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='BizInfo-State']")
    private WebElementFacade companySearchState;

    @FindBy(xpath = "//*[@id='folder_bar']//a[contains(.,'Search Now')]")
    private WebElementFacade searchNowBtnEle;

    @FindBy(xpath = "//*[@id='BizInfo-searchSnapShot']")
    private WebElementFacade includeSnapshotCheckboxEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='quicksearch_more_options' and contains(text(),'Fewer')] | //*[@class='outerDiv']//*[@id='search_box']//*[@class='moreOpt']//*[@id='quicksearch_more_options' and contains(text(),'More')]")
    private WebElementFacade fewerORMoreOptionsEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='header_mainApp']//*[contains(text(),'Companies')]")
    private WebElementFacade compHref;

    @FindBy(xpath = "//*[@class='modal_inner_content']//*[@id='loading']//a[contains(.,'click here')]")
    private WebElementFacade clickHere;

    @FindBy(xpath = ".//*[@class='lr_duns']")
    private WebElementFacade dunsNum;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='page_title']//*[text()='Search Results']")
    private WebElementFacade searchResultsConatinerEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@class='results full_company']//tbody")
    private WebElementFacade firstSearchItemEle;
    
    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='clear']//table//tbody//tr//a[contains(.,'Preview')]")
    private WebElementFacade previewLink;
    
    @FindBy(xpath = "//*[@class='modal_content']//*[@id='getReportTable']")
    private WebElementFacade reportPreviewPopup;
    @FindBy(xpath="//*[@id='modal_buttons']/input[1]")
    private WebElementFacade saveASnapshotEle;
    
    @FindBy(xpath = "//*[@id='getReportBtn']//input[@value='Get This Report']")
    private WebElementFacade getThisReportBtn;
    
    @FindBy(xpath = "//*[@id='entity_header']//h2")
    private WebElementFacade liveEcfPageHeaderElement;
    
    @FindBy(xpath = "//*[@id='header_mainApp']//li//a[contains(.,'Companies')]")
    private WebElementFacade CompaniesTabEle;
    
    @FindBy(xpath = "//*[@id='search_fields']//*[@id='international_search_table']//tbody//tr//td[contains(text(),'Country')]//following-sibling::td/select")
    private WebElementFacade countryList;
    @FindBy(xpath = "//iframe[@name='__modal_iframe_target']")
	private WebElementFacade iFrameEle;
    @FindBy(xpath = "//*[@id='search_fields']//*[@id='international_search_table']//tbody//tr//td[contains(text(),'Country')]//following-sibling::td/select/option")
    private List <WebElementFacade> countryOptionList;
    @FindBy(xpath = "//*[@id='header_toolbar']//li//a[contains(.,'My Profile')]")
    private WebElementFacade myProfileLink;
    private String searchResultsConatiner="//*[@class='outerDiv']//*[@id='main']//*[contains(@class,'results full')]//thead";
    String moreOptionXpath="//*[@class='outerDiv']//*[@id='quicksearch_more_options' and contains(text(),'Fewer')] | //*[@class='outerDiv']//*[@id='search_box']//*[@class='moreOpt']//*[@id='quicksearch_more_options' and contains(text(),'More')]";
    String companySearchXpath="//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields_expanded']//*[@id='search_toc']//*[contains(text(),'Company')]";
    String liveEcfPageHeader="//*[@id='entity_header']//h2";
    String cnfBtnxpath="//*[@id='main']//*[@class='compHome_newFolder']//input[@value='Create New Folder']";
    /**********************************************************************************************
     * Function: performCompanySearch Method Desctription: Perform Company
     * Search using 1. Company Name 2. Country Name 3. State 4. DUNSNumber 5.
     * ZIP Code and 6. IS Include SanpShot Option
     *
     ***********************************************************************************************/
    public void performCompanySearch(String compName, String CountryName,
            String State, String dunsNumber, String zipCode,
            String isIncludedSnapshot) throws InterruptedException {

        try {
            //disHref.click();

            fewerORMoreOptionsEle.waitUntilPresent();
            //waitFor(3000).milliseconds();
            if (companySearchmoreoptionsMore.isPresent()) {
            	System.out.println("company search is present 1st if");
                companySearchmoreoptionsMore.click();
                searchFewerOptionsEle.waitUntilPresent();
            }
            //waitFor(3000).milliseconds();
            if (companySearchTab.isPresent()) {

                companySearchTab.waitUntilClickable();
                UIHelper.highlightElement(getDriver(), companySearchTab);
                companySearchTab.click();
                companySearchCompanyName.waitUntilPresent();
                UIHelper.highlightElement(getDriver(), companySearchCompanyName);
            }

            if (companySearchCompanyName.isPresent()) {

                commonMethodToEnterDataInCompanySearch(compName, CountryName,
                        State, dunsNumber, zipCode, isIncludedSnapshot);
            }
        } catch (Exception e) {
            // e.printStackTrace();
        }

    }

    public void commonMethodToEnterDataInCompanySearch(String compName,
            String countryName, String state, String dunsNumber,
            String zipCode, String isIncludedSnapshot) {
        try {
        	UIHelper.highlightElement(getDriver(), companySearchCompanyName);
            companySearchCompanyName.type(compName);
            companySearchCompanyName.sendKeys(Keys.TAB);

            companySearchCountryName.selectByVisibleText(countryName);

            companySearchBizDuns.type(dunsNumber);

            if (companySearchState.isPresent()) {

                if (state.length() > 0) {
                    companySearchState.selectByVisibleText(state);
                }
            } else {

            }

            companySearchZipCode.type(zipCode);

            if (isIncludedSnapshot.equalsIgnoreCase("Check")) {
                includeSnapshotCheckboxEle.click();
            }

            companySearchButton.click();

            searchResultsConatinerEle.waitUntilPresent();
            disHref.waitUntilPresent();
            UIHelper.waitForPageToLoad(getDriver());
            //waitFor(3000).milliseconds();
           /* if (searchNowBtnEle.isPresent()) {
                searchNowBtnEle.click();
                //waitFor(3000).milliseconds();
                disHref.waitUntilPresent();
                UIHelper.waitForPageToLoad(getDriver());
            }*/

        } catch (NoSuchElementException E) {

        }
    }
    public void saveECFModelPopup(){
    	myProfileLink.click();
    	saveASnapshotEle.click();
    }
        public void enterDunsInSearchMoreoptions(String dunsNumber,String country)
        {
        	 fewerORMoreOptionsEle.waitUntilPresent();
             //waitFor(3000).milliseconds();
                 companySearchmoreoptionsMore.click();
                 try{
                	 getDriver().switchTo().frame(iFrameEle);
                	 ((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", saveASnapshotEle);
                	 getDriver().switchTo().defaultContent();
                	 companySearchmoreoptionsMore.click();
             	}catch(Exception e){
              	  
                }
                 searchFewerOptionsEle.waitUntilPresent();
                 
             //waitFor(3000).milliseconds();
             if (companySearchTab.isPresent()) {

                 companySearchTab.waitUntilClickable();
                 UIHelper.highlightElement(getDriver(), companySearchTab);
                // companySearchTab.click();

                 companySearchCompanyName.waitUntilPresent();
                 companySearchBizDuns.waitUntilPresent();
                 companySearchCountryName.waitUntilPresent();
                 companySearchButton.waitUntilPresent();
                 UIHelper.highlightElement(getDriver(), companySearchCompanyName);
             }

             if (companySearchCompanyName.isPresent()) {
            	 companySearchBizDuns.waitUntilPresent();
            	 searchWithDunsAndCountryInMorepotions(dunsNumber,country);
             }
        }
        public void searchWithDunsAndCountryInMorepotions(String dunsNumber, String country){
        		UIHelper.highlightElement(getDriver(), companySearchBizDuns);
        		companySearchBizDuns.type(dunsNumber);
        		UIHelper.highlightElement(getDriver(), companySearchCountryName);
        		 companySearchCountryName.selectByVisibleText(country);
        		 //waitFor(3000).milliseconds();
        		 companySearchButton.click();
                 searchResultsConatinerEle.waitUntilPresent();
                 disHref.waitUntilPresent();
                 UIHelper.waitForPageToLoad(getDriver());
                 //waitFor(3000).milliseconds();
                 if (searchNowBtnEle.isPresent()) {
                     searchNowBtnEle.click();
                     //waitFor(3000).milliseconds();
                     disHref.waitUntilPresent();
                     UIHelper.waitForPageToLoad(getDriver());
                 }
}
        public void more_search_With_Duns_Country_And_State(String dunsNumber, String country,String state){
       	 
        	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), moreOptionXpath);
           
            if (companySearchmoreoptionsMore.isPresent()) {
            	companySearchmoreoptionsMore.click();
            	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), companySearchXpath);
            }
            if (companySearchTab.isPresent()) {
            	UIHelper.highlightElement(getDriver(), companySearchBizDuns);
        		companySearchBizDuns.type(dunsNumber);
        		UIHelper.highlightElement(getDriver(), companySearchCountryName);
        		 companySearchCountryName.selectByVisibleText(country);
        		 UIHelper.highlightElement(getDriver(), companySearchState);
        		 companySearchState.selectByVisibleText(state);
        		 UIHelper.highlightElement(getDriver(), companySearchButton);
        		((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", companySearchButton);
               	 if (searchNowBtnEle.isPresent()) {
                     searchNowBtnEle.click();
                     }
                 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), searchResultsConatiner);
            }
        }
        
        public void more_search_With_Duns(String dunsNumber){
          	 
        	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), moreOptionXpath);
           
            if (companySearchmoreoptionsMore.isPresent()) {
            	companySearchmoreoptionsMore.click();
            	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), companySearchXpath);
            }
            if (companySearchTab.isPresent()) {
            	UIHelper.highlightElement(getDriver(), companySearchBizDuns);
        		companySearchBizDuns.type(dunsNumber);
        		UIHelper.highlightElement(getDriver(), companySearchCountryName);
        		 companySearchCountryName.selectByVisibleText("Select Country");
        		((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", companySearchButton);
               	 if (searchNowBtnEle.isPresent()) {
                     searchNowBtnEle.click();
                     }
                 UIHelper.waitForVisibilityOfEleByXpath(getDriver(), searchResultsConatiner);
            }
        }
       
        public void click_More_Option_Search(){
        	CompaniesTabEle.click();
        	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), cnfBtnxpath);
        	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), moreOptionXpath);
           
            if (companySearchmoreoptionsMore.isPresent()) {
            	companySearchmoreoptionsMore.click();
            	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), companySearchXpath);
            }
            
        }
        public void enter_Input_Data_For_Company_Search_TextField(String FieldName, String Value){
        	if (companySearchTab.isPresent()) {
            	String fieldNameXpath="//*[@id='search_fields']//*[@id='international_search_table']//tbody//tr//td[contains(text(),'"+FieldName+"')]//following-sibling::td/input";
            	WebElementFacade fieldNameElement=find(By.xpath(fieldNameXpath));
            	UIHelper.highlightElement(getDriver(), fieldNameElement);
            	fieldNameElement.clear();
            	fieldNameElement.type(Value);
            	fieldNameElement.sendKeys(Keys.ESCAPE);
            }
            
        }
        public void enter_Input_Data_For_Company_Search_TextFields(String SelectField, String Value){
        	if (companySearchTab.isPresent()) {
            	String fieldNameXpath="//*[@id='search_fields']//*[@id='international_search_table']//tbody//tr//td[contains(text(),'"+SelectField+"')]//following-sibling::td/input";
            	WebElementFacade fieldNameElement=find(By.xpath(fieldNameXpath));
            	UIHelper.highlightElement(getDriver(), fieldNameElement);
            	fieldNameElement.clear();
            	fieldNameElement.type(Value);
            	fieldNameElement.sendKeys(Keys.ESCAPE);
            }
            
        }
        
        public void select_Input_Data_For_Company_Search_ListField(String FieldName, String Value){
        	if (companySearchTab.isPresent()) {
            	String fieldNameXpath="//*[@id='search_fields']//*[@id='international_search_table']//tbody//tr//td[contains(text(),'"+FieldName+"')]//following-sibling::td/select";
            	WebElementFacade fieldNameElement=find(By.xpath(fieldNameXpath));
            	UIHelper.highlightElement(getDriver(), fieldNameElement);
            	fieldNameElement.selectByVisibleText(Value);
            }
            
        }
       
       public void click_More_Option_Search_Button(){
    	   
    	   UIHelper.highlightElement(getDriver(), companySearchButton);
    	   ((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", companySearchButton);
    	   UIHelper.waitForVisibilityOfEleByXpath(getDriver(), searchResultsConatiner);
    	   
         	 if (searchNowBtnEle.isPresent()) {
         		 searchNowBtnEle.click();
               }
         	waitFor(2000).milliseconds();
           UIHelper.waitForVisibilityOfEleByXpath(getDriver(), searchResultsConatiner);
      }
       
       public void reportPreviewPopup(){
    	   UIHelper.waitForPageToLoad(getDriver());
    	   previewLink.waitUntilClickable();
    	   UIHelper.highlightElement(getDriver(), previewLink);
    	   previewLink.click();
    	   waitFor(3000).milliseconds();
    	   UIHelper.highlightElement(getDriver(), reportPreviewPopup);
    	   getThisReportBtn.click();
    	   UIHelper.waitForVisibilityOfEleByXpath(getDriver(), liveEcfPageHeader);
       }
       
       public boolean verify_Live_report_EcfPage(){
    	   try{
    		   liveEcfPageHeaderElement.isVisible();
    		   UIHelper.highlightElement(getDriver(), liveEcfPageHeaderElement);
    		   return true;
       }catch(Exception e){
    	  return false;
       }
       }
       
       public boolean verify_CountryName_In_List(String CountryName){
    	   int countryFlag=0;
    	   UIHelper.highlightElement(getDriver(), countryList);
    	   for(WebElementFacade options: countryOptionList){
    		   if(options.getText().trim().equals(CountryName)){
    			   countryList.selectByVisibleText(CountryName);
    			   countryFlag=1;
    			   break;
    		   }
    		   else{
    			   countryFlag=2;
    		   }
    	   }
    	   if(countryFlag==1){
    		   return true;
    	   }else{
    		   return false;
    	   }
       }
       
       public boolean verify_CountryName_Not_In_List(String CountryName){
    	   int countryFlag=0;
    	   UIHelper.highlightElement(getDriver(), countryList);
    	   for(WebElementFacade options: countryOptionList){
    		   if(options.getText().trim().equals(CountryName)){
    			   countryFlag=1;
    			   break;
    		   }
    		   else{
    			   countryFlag=2;
    		   }
    	   }
    	   if(countryFlag==1){
    		   return false;
    	   }else{
    		   return true;
    	   }
       }
}
