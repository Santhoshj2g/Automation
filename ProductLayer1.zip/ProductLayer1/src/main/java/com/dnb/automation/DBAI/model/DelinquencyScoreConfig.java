package com.dnb.automation.DBAI.model;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class DelinquencyScoreConfig {
	
    public ArrayList<ArrayList<String>> getDelinqScoreFile() throws Exception {
        ArrayList<ArrayList<String>> resultArray = new ArrayList<>();
        try {
            Scanner scan = new Scanner(new File("D:\\c drive\\418415\\Test\\ProductLayer1\\src\\test\\resources\\AppTestData\\DBAI\\DelinquencyScoreConfig.csv"));
            while (scan.hasNextLine()) {
                resultArray.add(new ArrayList<String>(Arrays.asList(scan.nextLine().split(","))));

            }
            scan.close();
        } catch (Exception e) {

        }
        return resultArray;
    }


}
