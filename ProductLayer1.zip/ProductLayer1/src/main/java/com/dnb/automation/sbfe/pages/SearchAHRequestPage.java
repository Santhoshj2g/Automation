package com.dnb.automation.sbfe.pages;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;





import java.sql.Array;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;






import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

public class SearchAHRequestPage extends PageObject
{
	
	@FindBy(xpath="//*[@id='ahSearchTabui']")
	private WebElementFacade SearchAHRequest;
	
	@FindBy(xpath="//*[@id='ahSearchCtbrid']")
	private WebElementFacade CtbrNbr;
	
	@FindBy(xpath=".//*[@id='aHRequest']/a")
	private static WebElementFacade tabAHRequest;
	
	@FindBy(xpath=".//*[@id='ahSearchGoBtn']")
	private static WebElementFacade Go;
	
	@FindBy(xpath="//*/div[@id='ahSearchTab']/div[@id='aHTotalCountDiv']/p[@class='ahSearchTotCount']")
	private static WebElementFacade Totcnt;
	
	@FindBy(xpath="//*/div[@id='aHSearchTableDiv']/div[@class='additionalSearchTable']/p[@class='aHSearchTable']/tr/td")
	private static WebElementFacade td1;
	
	Connection con;
	Statement st;
	
	
public void SearchAHRequestTab() throws Exception
{
    	AHRequestTabclick();
}
    
    
public void AHRequestTabclick() throws Exception
{
    	try{
    	if (tabAHRequest.isPresent())    
    		UIHelper.highlightElement(getDriver(), tabAHRequest);
    	tabAHRequest.click();
    	UIHelper.waitForPageToLoad(getDriver());
       } catch(AssertionError e)
		{
		e.printStackTrace();
	    }
}


public void SearchAHRequestTabclick() throws Exception
{
        	try{
        	if (SearchAHRequest.isPresent())
        		UIHelper.highlightElement(getDriver(), SearchAHRequest);
        	SearchAHRequest.click();
        	UIHelper.waitForPageToLoad(getDriver());
                 } catch(AssertionError e)
    		{
    		e.printStackTrace();
    	    }
}
    
    
public void SearchContributor(String ContributorID) throws Exception
{
    		Class.forName("oracle.jdbc.driver.OracleDriver"); 
        	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
        	Statement st=con.createStatement();
        	String sqlquery1= "select SBFE_CTBR_NBR from sbfe_ctbr where sbfe_ctbr_id="+ContributorID;
        	ResultSet rs=st.executeQuery(sqlquery1);
        	while (rs.next())
        	{
        	String ctbrnbr=rs.getString("SBFE_CTBR_NBR");
        	
    		if(CtbrNbr.isPresent())
    			UIHelper.highlightElement(getDriver(), CtbrNbr);
    			CtbrNbr.type(ctbrnbr);
    			Go.click();
    		}
} 
		
    	
    	
    	
public String GetContributor(String ContributorID) throws Exception
{
    		
    		Class.forName("oracle.jdbc.driver.OracleDriver"); 
        	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
        	Statement st=con.createStatement();
        	String sqlquery1= "select SBFE_CTBR_NBR from sbfe_ctbr where sbfe_ctbr_id="+ContributorID;
        	ResultSet rs=st.executeQuery(sqlquery1);
        	String ctbr=null;        	
        	if(rs.next()){
        	ctbr=rs.getString("SBFE_CTBR_NBR");
        	// System.out.println("CTBRRRRRRRRRRRRRRRRRRRRRR"+ctbr);   		    			
    		}
    		else
    		{
    		ctbr=null;
    		}
    		return ctbr;
} 
    	
public String Getoldacct(String ContributorNumber) throws Exception
{
    		
    		Class.forName("oracle.jdbc.driver.OracleDriver"); 
        	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
        	Statement st=con.createStatement();        	
        	String sqlquery1= "select BEF_CHG_ACCT_NBR from acct_id_info_mnl_chg where sbfe_ctbr_nbr='"+ContributorNumber+"' order by row_cre_tmst desc";
        	ResultSet rs=st.executeQuery(sqlquery1);
        	String oldacct=null;        	
        	while(rs.next())
        	{
        	oldacct=rs.getString("BEF_CHG_ACCT_NBR");
        	if(td1.isPresent())
        	{
        		UIHelper.highlightElement(getDriver(), td1);
        	}
        	//System.out.println("oldaccttttttttttt"+oldacct);   		    			
    		}
        	
    		return oldacct;
} 
		
public String Getnewacct(String ContributorNumber) throws Exception
{
	
		Class.forName("oracle.jdbc.driver.OracleDriver"); 
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
		Statement st=con.createStatement();
		String sqlquery1= "select * from acct_id_info_mnl_chg where sbfe_ctbr_nbr='"+ContributorNumber+"' order by row_cre_tmst desc";
		ResultSet rs=st.executeQuery(sqlquery1);
		String newacct=null;        	
		while(rs.next())
		{
		newacct=rs.getString("AFT_CHG_ACCT_NBR");
		if(td1.isPresent())
		{
			UIHelper.highlightElement(getDriver(), td1);
		}
		System.out.println("CTBRRRRRRRRRRRRRRRRRRRRRR"+newacct);   		    			
		}
	
		return newacct;
} 

public String Getoldaccttype(String ContributorNumber) throws Exception
{
	
	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
	Statement st=con.createStatement();
	String sqlquery1= "select BEF_CHG_ACCT_TYP_CODE from acct_id_info_mnl_chg where sbfe_ctbr_nbr='"+ContributorNumber+"' order by row_cre_tmst desc";
	ResultSet rs=st.executeQuery(sqlquery1);
	String oldaccttype=null;        	
	while(rs.next())
	{
		oldaccttype=rs.getString("BEF_CHG_ACCT_TYP_CODE");
	if(td1.isPresent())
	{
		UIHelper.highlightElement(getDriver(), td1);
	}
	System.out.println("CTBRRRRRRRRRRRRRRRRRRRRRR"+oldaccttype);   		    			
	}
	
	return oldaccttype;
} 

public String Getnewdaccttype(String ContributorNumber) throws Exception
{
	
	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
	Statement st=con.createStatement();
	String sqlquery1= "select BEF_CHG_ACCT_TYP_CODE from acct_id_info_mnl_chg where sbfe_ctbr_nbr='"+ContributorNumber+"' order by row_cre_tmst desc";
	ResultSet rs=st.executeQuery(sqlquery1);
	String newaccttype=null;        	
	while(rs.next())
	{
		newaccttype=rs.getString("BEF_CHG_ACCT_TYP_CODE");
	if(td1.isPresent())
	{
		UIHelper.highlightElement(getDriver(), td1);
	}
	System.out.println("CTBRRRRRRRRRRRRRRRRRRRRRR"+newaccttype);   		    			
	}
	
	return newaccttype;
} 


public String Getacctconvtypecode(String ContributorNumber) throws Exception
{
	
	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
	Statement st=con.createStatement();
	String sqlquery1= "select ACCT_CONV_TYP_CODE from acct_id_info_mnl_chg where sbfe_ctbr_nbr='"+ContributorNumber+"' order by row_cre_tmst desc";
	ResultSet rs=st.executeQuery(sqlquery1);
	String acctconvtypecode=null;        	
	while(rs.next())
	{
		acctconvtypecode=rs.getString("ACCT_CONV_TYP_CODE");

		    			
	}
	
	return acctconvtypecode;
} 

public String GetAcctconvdate(String ContributorNumber) throws Exception
{
	
	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
	Statement st=con.createStatement();
	String sqlquery1= "select to_char(ACCT_CONV_DT,'MM/dd/yyyy') as dt from acct_id_info_mnl_chg where sbfe_ctbr_nbr='"+ContributorNumber+"' order by row_cre_tmst desc";
	ResultSet rs=st.executeQuery(sqlquery1);
   
	String acctconvdate = null;
	while(rs.next())
	{
		acctconvdate=rs.getString("dt");
		
	}
	
	return acctconvdate;
}
	
public String GetSBFEopname(String ContributorNumber) throws Exception
{
		
		Class.forName("oracle.jdbc.driver.OracleDriver"); 
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
		Statement st=con.createStatement();
		String sqlquery1= "select SBFE_OPRN_MBR_NME from acct_id_info_mnl_chg where sbfe_ctbr_nbr='"+ContributorNumber+"' order by row_cre_tmst desc";
		ResultSet rs=st.executeQuery(sqlquery1);
		String SBFEOPRNMBRNME=null;        	
		while(rs.next())
		{
			SBFEOPRNMBRNME=rs.getString("SBFE_OPRN_MBR_NME");

		//System.out.println("OPNNAMEDBBBBBBBBBB"+SBFEOPRNMBRNME);   		    			
		}
		
		return SBFEOPRNMBRNME;
} 


public String GetChgSubTMSP(String ContributorNumber) throws Exception
{
	
	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
	Statement st=con.createStatement();
	String sqlquery1= "select to_char(CHG_SBMT_TMST,'MM/dd/yyyy') as dt from acct_id_info_mnl_chg where sbfe_ctbr_nbr='"+ContributorNumber+"' order by row_cre_tmst desc";
	ResultSet rs=st.executeQuery(sqlquery1);
	String CHGSBMTTMST=null;        	
	while(rs.next())
	{
		CHGSBMTTMST=rs.getString("dt");

	System.out.println("chgtmstmpdbbbbbbbbbbbbbb"+CHGSBMTTMST);   		    			
	}
	
	return CHGSBMTTMST;


} 


public String GetChgStcode(String ContributorNumber) throws Exception
{
	
	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
	Statement st=con.createStatement();
	String sqlquery1= "select CHG_STAT_CD from acct_id_info_mnl_chg where sbfe_ctbr_nbr='"+ContributorNumber+"' order by row_cre_tmst desc";
	ResultSet rs=st.executeQuery(sqlquery1);
	String CHG_STAT_CD;  
	String text=null;
	while(rs.next())
	{
	CHG_STAT_CD=rs.getString("CHG_STAT_CD");
	if(CHG_STAT_CD.equals("29169"))
	{
		 text = "Completed";
		 System.out.println("dbbbbbbbbbChgcodeeeeeeeee"+text);  
	}
	else if (CHG_STAT_CD.equals("3426"))
	{
		text = "In-Progress";
		System.out.println("dbbbbbbbbbChgcodeeeeeeeee"+text);
	}
	   		    			
	}
	
	return text;
}



public String GetChgrescode(String ContributorNumber) throws Exception
{
	
	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
	Statement st=con.createStatement();
	String sqlquery1= "select CHG_RSLT_CD from acct_id_info_mnl_chg where sbfe_ctbr_nbr='"+ContributorNumber+"' order by row_cre_tmst desc";
	ResultSet rs=st.executeQuery(sqlquery1);
	String CHG_RSLT_CD;  
	String text=null;
	while(rs.next())
	{
		CHG_RSLT_CD=rs.getString("CHG_RSLT_CD");
	if(CHG_RSLT_CD.equals("29829"))
	{
		 text = "Rejected";
		 System.out.println("dbbbbbbbbbChgcodeeeeeeeee"+text);  
	}
	else if (CHG_RSLT_CD.equals("20095"))
	{
		text = "Success";
		System.out.println("dbbbbbbbbbChgcodeeeeeeeee"+text);
	}
	else
	{
		text="";
	}
	}
	
	return text;
}
	

public String GetChgResTMSP(String ContributorNumber) throws Exception
{
	
	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
	Statement st=con.createStatement();
	String sqlquery1= "select to_char(CHG_RSLT_TMST,'MM/dd/yyyy') as dt from acct_id_info_mnl_chg where sbfe_ctbr_nbr='"+ContributorNumber+"' order by row_cre_tmst desc";
	ResultSet rs=st.executeQuery(sqlquery1);
	String CHGRESTMST=null;        	
	while(rs.next())
	{
		CHGRESTMST=rs.getString("dt");

	System.out.println("chgtmstmpdbbbbbbbbbbbbbb"+CHGRESTMST);   		    			
	}
	
	return CHGRESTMST;


} 
		
  

public String GetChgRejRescode(String ContributorNumber) throws Exception
{
	
	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
	Statement st=con.createStatement();
	String sqlquery1= "select B.cd_val_desc as text from acct_id_info_mnl_chg A, cd_val_txt B where A.CHG_REJ_REAS_CD=B.CD_VAL_ID and A.sbfe_ctbr_nbr='"+ContributorNumber+"'";
	ResultSet rs=st.executeQuery(sqlquery1);
	String CHG_REJ_REAS_CD=null;  
	while(rs.next())
	{
		CHG_REJ_REAS_CD=rs.getString("text");
		System.out.println("RejRes codeeeeeeeeeeeee"+CHG_REJ_REAS_CD);   

	}
	
	return CHG_REJ_REAS_CD;
}





public String GetComments(String ContributorNumber) throws Exception
{
	
	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
	Statement st=con.createStatement();
	String sqlquery1= "select CHG_CMNT from acct_id_info_mnl_chg  where sbfe_ctbr_nbr='"+ContributorNumber+"' order by row_cre_tmst desc";
	ResultSet rs=st.executeQuery(sqlquery1);
	String sd=null;
	String CHG_CMNT=null;  
	while(rs.next())
	{
		CHG_CMNT=rs.getString("CHG_CMNT");
		//sd=CHG_CMNT.replace(" ","");
		System.out.println("Commentsssssssssdbbbbb"+CHG_CMNT);   

	}
	
	return CHG_CMNT;
}

    
public String SearchResults() throws Exception
{
    		Class.forName("oracle.jdbc.driver.OracleDriver"); 
        	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
        	Statement st=con.createStatement();
        	String sqlquery1= "select A.SBFE_CTBR_NBR from acct_id_info_mnl_chg A, sbfe_ctbr B where A.sbfe_ctbr_nbr=B.sbfe_ctbr_nbr and B.sbfe_ctbr_id=67007";
        	ResultSet rs=st.executeQuery(sqlquery1);
        	rs.next();
        	String ct=rs.getString("SBFE_CTBR_NBR");
        	String contributor=null;   	
        	
    	if(CtbrNbr.isPresent())
    	{
    		contributor=ct;
    	}
    	else
    	{
    		contributor=null;
    	}
    	return contributor;
} 
		
		
    	
    	
public String getAHChangesTabPressence()
{    
    		String elementPresence = null;
    		try
    		{
				if(tabAHRequest.isPresent())
				{
					UIHelper.mouseOveranElement(getDriver(), tabAHRequest);
					UIHelper.highlightElement(getDriver(), tabAHRequest);
					elementPresence=tabAHRequest.getText();
					//System.out.println("*********************"+elementPresence);
					//System.out.println("*********************");
				}
				else
				{
					elementPresence=null;
				}    
    		}catch(AssertionError e)
    		{
    			e.printStackTrace();
    		    }
    		return elementPresence;
}


public String PresenceSearchAHRequestTab()
{
    		String elementPresence = null;
    		if(SearchAHRequest.isPresent())
    		{
    			UIHelper.mouseOveranElement(getDriver(), SearchAHRequest);
				UIHelper.highlightElement(getDriver(), SearchAHRequest);
				elementPresence=SearchAHRequest.getText();
    		}
    		else
    		{
    			elementPresence=null;
    			
    		}
    		return elementPresence;
 }
    	
public String Searchcount()
{
    		UIHelper.highlightElement(getDriver(), Totcnt);
    		String[] totalCt1=Totcnt.getText().toString().trim().split(":");
    		String totalCt=totalCt1[1];
    		//System.out.println("ans"+totalCt);
    		String[] totct=totalCt.toString().split(" ");
    		String totct1=totct[1];
    		//System.out.println("ans111"+totct1);
    		return totct1;
    		
}
    		
    		
    	    		  		   		
public String totcntdb(String ContributorNumber) throws Exception
{
			
			Class.forName("oracle.jdbc.driver.OracleDriver"); 
        	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
        	Statement st=con.createStatement();
        	String sqlquery1= "select count(*) as C from acct_id_info_mnl_chg where sbfe_ctbr_nbr='"+ContributorNumber+"'";
        	ResultSet rs=st.executeQuery(sqlquery1);
        	rs.next();
        	String ct=rs.getString("C");
        	//System.out.println("ans"+ct);
            return ct;    
            			
}
		
		//UIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
		
public String contributorresults() throws Exception
{
			
			String ret = null;  
			List<WebElement> tablerows = getDriver().findElements(By.xpath("//*/div[@id='aHSearchTableDiv']/div[@class='additionalSearchTable']/table/tbody/tr"));
			
			ArrayList<ArrayList<String>> tablearray = new ArrayList<ArrayList<String>>();
			for(WebElement singleRow: tablerows)
			{
				ArrayList<String> rowsarray=new ArrayList<String>();	
				List<WebElement> rowTDs = singleRow.findElements(By.tagName("td"));
				for(WebElement singlecol: rowTDs) //this increments through that list of td's
		        {				
					rowsarray.add(singlecol.getText());	
		        }		
				tablearray.add(rowsarray);
			}
			for(ArrayList<String> row: tablearray){
				//System.out.println("*******************************************"+row); 
				ret = row.get(0);
				//System.out.println("*******************************************"+ret); 
			}
			
			return ret;
			
			
}
		
public String oldacctresults() throws Exception
{
			
			String ret = null;  
			List<WebElement> tablerows = getDriver().findElements(By.xpath("//*/div[@id='aHSearchTableDiv']/div[@class='additionalSearchTable']/table/tbody/tr"));
			
			ArrayList<ArrayList<String>> tablearray = new ArrayList<ArrayList<String>>();
			for(WebElement singleRow: tablerows)
			{
				ArrayList<String> rowsarray=new ArrayList<String>();	
				List<WebElement> rowTDs = singleRow.findElements(By.tagName("td"));
				for(WebElement singlecol: rowTDs) //this increments through that list of td's
		        {				
					rowsarray.add(singlecol.getText());	
		        }		
				tablearray.add(rowsarray);
			}
			for(ArrayList<String> row: tablearray){
				//System.out.println("*******************************************"+row); 
				ret = row.get(1);
				//System.out.println("*******************************************"+ret); 
			}
			
			return ret;
			
}
		
		
public String newacctresults() throws Exception
{
			
			String ret = null;  
			List<WebElement> tablerows = getDriver().findElements(By.xpath("//*/div[@id='aHSearchTableDiv']/div[@class='additionalSearchTable']/table/tbody/tr"));
			
			ArrayList<ArrayList<String>> tablearray = new ArrayList<ArrayList<String>>();
			for(WebElement singleRow: tablerows)
			{
				ArrayList<String> rowsarray=new ArrayList<String>();	
				List<WebElement> rowTDs = singleRow.findElements(By.tagName("td"));
				for(WebElement singlecol: rowTDs) //this increments through that list of td's
		        {				
					rowsarray.add(singlecol.getText());	
		        }		
				tablearray.add(rowsarray);
			}
			for(ArrayList<String> row: tablearray){
				//System.out.println("*******************************************"+row); 
				ret = row.get(2);
				//System.out.println("*******************************************"+ret); 
			}
			
			return ret;
			
			
}
		
public String oldaccttyperesults() throws Exception
{
			
			String ret = null;  
			List<WebElement> tablerows = getDriver().findElements(By.xpath("//*/div[@id='aHSearchTableDiv']/div[@class='additionalSearchTable']/table/tbody/tr"));
			
			ArrayList<ArrayList<String>> tablearray = new ArrayList<ArrayList<String>>();
			for(WebElement singleRow: tablerows)
			{
				ArrayList<String> rowsarray=new ArrayList<String>();	
				List<WebElement> rowTDs = singleRow.findElements(By.tagName("td"));
				for(WebElement singlecol: rowTDs) //this increments through that list of td's
		        {				
					rowsarray.add(singlecol.getText());	
		        }		
				tablearray.add(rowsarray);
			}
			for(ArrayList<String> row: tablearray){
				//System.out.println("*******************************************"+row); 
				ret = row.get(3);
				//System.out.println("*******************************************"+ret); 
			}
			
			return ret;
			
			
}
		
		
public String newaccttyperesults() throws Exception
{
			
			String ret = null;  
			List<WebElement> tablerows = getDriver().findElements(By.xpath("//*/div[@id='aHSearchTableDiv']/div[@class='additionalSearchTable']/table/tbody/tr"));
			
			ArrayList<ArrayList<String>> tablearray = new ArrayList<ArrayList<String>>();
			for(WebElement singleRow: tablerows)
			{
				ArrayList<String> rowsarray=new ArrayList<String>();	
				List<WebElement> rowTDs = singleRow.findElements(By.tagName("td"));
				for(WebElement singlecol: rowTDs) //this increments through that list of td's
		        {				
					rowsarray.add(singlecol.getText());	
		        }		
				tablearray.add(rowsarray);
			}
			for(ArrayList<String> row: tablearray){
				//System.out.println("*******************************************"+row); 
				ret = row.get(4);
				//System.out.println("*******************************************"+ret); 
			}
			
			return ret;
			
			
}
		
public String acctconvtypecoderesults() throws Exception
{
			
			String ret = null;  
			List<WebElement> tablerows = getDriver().findElements(By.xpath("//*/div[@id='aHSearchTableDiv']/div[@class='additionalSearchTable']/table/tbody/tr"));
			
			ArrayList<ArrayList<String>> tablearray = new ArrayList<ArrayList<String>>();
			for(WebElement singleRow: tablerows)
			{
				ArrayList<String> rowsarray=new ArrayList<String>();	
				List<WebElement> rowTDs = singleRow.findElements(By.tagName("td"));
				for(WebElement singlecol: rowTDs) //this increments through that list of td's
		        {				
					rowsarray.add(singlecol.getText());	
		        }		
				tablearray.add(rowsarray);
			}
			for(ArrayList<String> row: tablearray){
				//System.out.println("*******************************************"+row); 
				ret = row.get(5);
				//System.out.println("*******************************************"+ret); 
			}
			
			return ret;
			
			
} 
		
public String Acctconvdateresults() throws Exception
{
			
			String ret = null;  
			List<WebElement> tablerows = getDriver().findElements(By.xpath("//*/div[@id='aHSearchTableDiv']/div[@class='additionalSearchTable']/table/tbody/tr"));
			
			ArrayList<ArrayList<String>> tablearray = new ArrayList<ArrayList<String>>();
			for(WebElement singleRow: tablerows)
			{
				ArrayList<String> rowsarray=new ArrayList<String>();	
				List<WebElement> rowTDs = singleRow.findElements(By.tagName("td"));
				for(WebElement singlecol: rowTDs) //this increments through that list of td's
		        {				
					rowsarray.add(singlecol.getText());	
		        }		
				tablearray.add(rowsarray);
			}
			for(ArrayList<String> row: tablearray){
				//System.out.println("*******************************************"+row); 
				ret = row.get(6);
				//System.out.println("UIIIIIIIIIIIIIIIIIII"+ret); 
			}
			
			return ret;
			
			
}
		
public String SBFEopnameresults() throws Exception
{
			
			String ret = null;  
			List<WebElement> tablerows = getDriver().findElements(By.xpath("//*/div[@id='aHSearchTableDiv']/div[@class='additionalSearchTable']/table/tbody/tr"));
			
			ArrayList<ArrayList<String>> tablearray = new ArrayList<ArrayList<String>>();
			for(WebElement singleRow: tablerows)
			{
				ArrayList<String> rowsarray=new ArrayList<String>();	
				List<WebElement> rowTDs = singleRow.findElements(By.tagName("td"));
				for(WebElement singlecol: rowTDs) //this increments through that list of td's
		        {				
					rowsarray.add(singlecol.getText());	
		        }		
				tablearray.add(rowsarray);
			}
			for(ArrayList<String> row: tablearray){
				//System.out.println("*******************************************"+row); 
				ret = row.get(7);
				//System.out.println("OPNNAMEUIIIIIIIIIIIII"+ret); 
			}
			
			return ret;
			
			
}
		
		
public String ChgSubTMSPresults() throws Exception
{
			
			String ret = null;  
			List<WebElement> tablerows = getDriver().findElements(By.xpath("//*/div[@id='aHSearchTableDiv']/div[@class='additionalSearchTable']/table/tbody/tr"));
			
			ArrayList<ArrayList<String>> tablearray = new ArrayList<ArrayList<String>>();
			for(WebElement singleRow: tablerows)
			{
				ArrayList<String> rowsarray=new ArrayList<String>();	
				List<WebElement> rowTDs = singleRow.findElements(By.tagName("td"));
				for(WebElement singlecol: rowTDs) //this increments through that list of td's
		        {				
					rowsarray.add(singlecol.getText());	
		        }		
				tablearray.add(rowsarray);
			}
			for(ArrayList<String> row: tablearray){
				//System.out.println("*******************************************"+row); 
				ret = row.get(8);
				System.out.println("chgtimestampppppppppp"+ret); 
			}
			
			return ret;
			
			
}

		
		
public String ChgStcoderesults() throws Exception
{
			
			String ret = null;  
			List<WebElement> tablerows = getDriver().findElements(By.xpath("//*/div[@id='aHSearchTableDiv']/div[@class='additionalSearchTable']/table/tbody/tr"));
			
			ArrayList<ArrayList<String>> tablearray = new ArrayList<ArrayList<String>>();
			for(WebElement singleRow: tablerows)
			{
				ArrayList<String> rowsarray=new ArrayList<String>();	
				List<WebElement> rowTDs = singleRow.findElements(By.tagName("td"));
				for(WebElement singlecol: rowTDs) //this increments through that list of td's
		        {				
					rowsarray.add(singlecol.getText());	
		        }		
				tablearray.add(rowsarray);
			}
			for(ArrayList<String> row: tablearray){
				//System.out.println("*******************************************"+row); 
				ret = row.get(9);
				//System.out.println("codeeeeeeeee"+ret); 
			}
			
			return ret;
			
			
}
		
public String Chgrescoderesults() throws Exception
{
			
			String ret = null;  
			List<WebElement> tablerows = getDriver().findElements(By.xpath("//*/div[@id='aHSearchTableDiv']/div[@class='additionalSearchTable']/table/tbody/tr"));
			
			ArrayList<ArrayList<String>> tablearray = new ArrayList<ArrayList<String>>();
			for(WebElement singleRow: tablerows)
			{
				ArrayList<String> rowsarray=new ArrayList<String>();	
				List<WebElement> rowTDs = singleRow.findElements(By.tagName("td"));
				for(WebElement singlecol: rowTDs) //this increments through that list of td's
		        {				
					rowsarray.add(singlecol.getText());	
		        }		
				tablearray.add(rowsarray);
			}
			for(ArrayList<String> row: tablearray){
				//System.out.println("*******************************************"+row); 
				ret = row.get(10);
				//System.out.println("codeeeeeeeee"+ret); 
			}
			
			return ret;
			
			
}
		
		
public String ChgResTMSPresults() throws Exception
{
			
			String ret = null;  
			List<WebElement> tablerows = getDriver().findElements(By.xpath("//*/div[@id='aHSearchTableDiv']/div[@class='additionalSearchTable']/table/tbody/tr"));
			
			ArrayList<ArrayList<String>> tablearray = new ArrayList<ArrayList<String>>();
			for(WebElement singleRow: tablerows)
			{
				ArrayList<String> rowsarray=new ArrayList<String>();	
				List<WebElement> rowTDs = singleRow.findElements(By.tagName("td"));
				for(WebElement singlecol: rowTDs) //this increments through that list of td's
		        {				
					rowsarray.add(singlecol.getText());	
		        }		
				tablearray.add(rowsarray);
			}
			for(ArrayList<String> row: tablearray){
				//System.out.println("*******************************************"+row); 
				ret = row.get(11);
				System.out.println("chgtimestampppppppppp"+ret); 
			}
			
			return ret;
			
			
}
		
		
public String ChgRejRescoderesults() throws Exception
{
			
			String ret = null;  
			List<WebElement> tablerows = getDriver().findElements(By.xpath("//*/div[@id='aHSearchTableDiv']/div[@class='additionalSearchTable']/table/tbody/tr"));
			
			ArrayList<ArrayList<String>> tablearray = new ArrayList<ArrayList<String>>();
			for(WebElement singleRow: tablerows)
			{
				ArrayList<String> rowsarray=new ArrayList<String>();	
				List<WebElement> rowTDs = singleRow.findElements(By.tagName("td"));
				for(WebElement singlecol: rowTDs) //this increments through that list of td's
		        {				
					rowsarray.add(singlecol.getText());	
		        }		
				tablearray.add(rowsarray);
			}
			for(ArrayList<String> row: tablearray){
				//System.out.println("*******************************************"+row); 
				ret = row.get(12);
				System.out.println("chgtimestampppppppppp"+ret); 
			}
			
			return ret;
			
			
}
			
		
public String Commentsresults() throws Exception
{
			
			String ret = null;  
			List<WebElement> tablerows = getDriver().findElements(By.xpath("//*/div[@id='aHSearchTableDiv']/div[@class='additionalSearchTable']/table/tbody/tr"));
			
			ArrayList<ArrayList<String>> tablearray = new ArrayList<ArrayList<String>>();
			for(WebElement singleRow: tablerows)
			{
				ArrayList<String> rowsarray=new ArrayList<String>();	
				List<WebElement> rowTDs = singleRow.findElements(By.tagName("td"));
				for(WebElement singlecol: rowTDs) //this increments through that list of td's
		        {				
					rowsarray.add(singlecol.getText());	
		        }		
				tablearray.add(rowsarray);
			}
			for(ArrayList<String> row: tablearray){
				//System.out.println("*******************************************"+row); 
				ret = row.get(13);
				System.out.println(" "+ret); 
			}
			
			return ret;
			
			
}


}