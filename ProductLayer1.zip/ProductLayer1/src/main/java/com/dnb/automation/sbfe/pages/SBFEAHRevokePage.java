package com.dnb.automation.sbfe.pages;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Date;
import java.sql.Array;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


import com.dnb.automation.utils.UIHelper;

import java.sql.SQLException;

public class SBFEAHRevokePage extends PageObject
{
	
	
	@FindBy(xpath=".//*[@id='aHRevokeui']")
	private static WebElementFacade AHRevoketab;
	
	@FindBy(xpath=".//*[@id='ahChangesTabui']")
	private static WebElementFacade AHRequest;
	
	@FindBy(xpath=".//*[@id='aHFrm']//*[@id='oldCtbr']")
	private static WebElementFacade ContributorNO;
	
	@FindBy(xpath=".//*[@id='aHFrm']//*[@id='oldAcctNo']")
	private static WebElementFacade OldAcctNO;
	
	@FindBy(xpath=".//*[@id='aHRevokeSubmitBtn']")
	private static WebElementFacade RevokeSub;
	
	@FindBy(xpath=".//*/div[contains(@class,'ui-dialog-buttonpane')]/div/button[@id='okn-button-id-AHRevokeConform']")
	private static WebElementFacade DialogOkbutton;
	
	@FindBy(xpath=".//*/div[contains(@class,'ui-dialog-buttonpane')]/div/button[@id='okn-button-id-AH']/span")
	private static WebElementFacade DialogOkSuccessful;
	
	String dialogok=".//*/div[contains(@class,'ui-dialog-buttonpane')]/div/button[@id='okn-button-id-AH']/span";
	
	String sbfe_ctbrdb,bef_chg_acct_nbrdb,aft_chg_acct_nbrdb,acct_id_info_mnl_chg_iddb;
	


public void AHRevokeClick() 
{
	if(AHRevoketab.isPresent())
	{
		UIHelper.highlightElement(getDriver(), AHRevoketab);
		AHRevoketab.click();
		
		UIHelper.waitForPageToLoad(getDriver());
	}
	
		
}



public String AHRevoketabGetText() 
{
	String AHRevoketabname=AHRevoketab.getText();
	System.out.println("stringggggggggggggjjjjjjjjjjjjjjjg"+AHRevoketabname);
	return AHRevoketabname;
	
}



public void SelectContributor() throws ClassNotFoundException, SQLException 
{

	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
	Statement st=con.createStatement();
	String sqlquery1= "select acct_id_info_mnl_chg_id,sbfe_ctbr_nbr,bef_chg_acct_nbr,aft_chg_acct_nbr from acct_id_info_mnl_chg where chg_stat_cd=29864 and ROWNUM = 1 order by row_cre_tmst desc";
	ResultSet rs=st.executeQuery(sqlquery1);
	while(rs.next())
	{
		sbfe_ctbrdb=rs.getString("sbfe_ctbr_nbr");
		bef_chg_acct_nbrdb=rs.getString("bef_chg_acct_nbr");
		aft_chg_acct_nbrdb=rs.getString("aft_chg_acct_nbr");
		acct_id_info_mnl_chg_iddb=rs.getString("acct_id_info_mnl_chg_id");
		System.out.println("oooooooooooooooo"+acct_id_info_mnl_chg_iddb);
		if(!sbfe_ctbrdb.equals(null))
		{
			//List<WebElement> tablerows = getDriver().findElements(By.xpath("//*[@id='aHRevokeDetail']/tr"));
			WebElement tablecolumn = getDriver().findElement(By.xpath("//*[@id='aHRevokeDetail']/tr[contains(.,'"+sbfe_ctbrdb+"') and contains(.,'"+bef_chg_acct_nbrdb+"')]//input"));
			UIHelper.highlightElement(getDriver(), tablecolumn);
		    tablecolumn.click();
			
			
		}
	}
		
}



public void AHReqRevtab() 
{
	
	UIHelper.highlightElement(getDriver(), AHRevoketab);
}



public void ContriRevoke() 
{
	UIHelper.highlightElement(getDriver(), RevokeSub);
	RevokeSub.click();
	UIHelper.waitForPageToLoad(getDriver());
	DialogOkbutton.click();
	waitFor(5000).milliseconds();
	UIHelper.processalert(getDriver());
	UIHelper.highlightElement(getDriver(), DialogOkSuccessful);
	
		
}


public boolean AHRevokeVerifyDB() throws ClassNotFoundException, SQLException
{
	
	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
	Statement st=con.createStatement();
	String sqlquery1= "select sbfe_ctbr_nbr,bef_chg_acct_nbr,aft_chg_acct_nbr from acct_id_info_mnl_chg where acct_id_info_mnl_chg_id='"+acct_id_info_mnl_chg_iddb+"'";
	ResultSet rs=st.executeQuery(sqlquery1);
	//System.out.println("valuesssssssssssssssssssssssssssssinside01"+sbfe_ctbr+bef_chg_acct_nbr+aft_chg_acct_nbr);
	System.out.println("iiiiiiiiiiiiiiiiii"+acct_id_info_mnl_chg_iddb);
	int count=0;
	while(rs.next())
	{
		count+=1;

		
		String sbfe_ctbr1=rs.getString("sbfe_ctbr_nbr");
		String bef_chg_acct_nbr1=rs.getString("bef_chg_acct_nbr");
		String aft_chg_acct_nbr1=rs.getString("aft_chg_acct_nbr");
		
		if ((bef_chg_acct_nbr1).equals(null))
		{
			System.out.println("valuesssssssssssssssssssssssssssssinside"+sbfe_ctbr1+bef_chg_acct_nbr1+aft_chg_acct_nbr1);
			return true;
		}
		System.out.println("valuesssssssssssssssssssssssssssssoutside"+sbfe_ctbr1+bef_chg_acct_nbr1+aft_chg_acct_nbr1);
	
	}
	if(count==0)
	{
		return true;
	}
	else
	{
		return false;
	}

}


}


