package com.dnb.automation.gdm.pages;

import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;


import javax.xml.xpath.XPathExpression;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

/**
 * Created by 630239 on 6/16/2017.
 */
public class ReportPage extends PageObject{

    @FindBy(xpath=".//td/span[contains(text(),'SCORE DATE')]/parent::td/parent::tr/td[2]/b")
    private WebElementFacade assDateVM1;

    @FindBy(xpath=".//td/span[contains(text(),'ALGORITHM ID')]/parent::td/parent::tr/td[2]/b")
    private List<WebElementFacade> algIdVM;

    @FindBy(xpath = ".//td/span[contains(text(),'FAILURE RISK (FINANCIAL STRESS) SCORE')]/parent::td/parent::tr/td[2]/b")
    private WebElementFacade failScrVM;

    @FindBy(xpath = ".//td/span[contains(text(),'FAILURE RISK (FINANCIAL STRESS) SCORE  NATIONAL 1-100')]/parent::td/parent::tr/td[2]/b")
    private WebElementFacade failPercentVM;

    @FindBy(xpath=".//td/span[contains(text(),'RATING')]/parent::td/parent::tr/td[2]/b")
    private WebElementFacade dnbRatVM;

    @FindBy(xpath = ".//td/span[contains(text(),'SER RATING')]/parent::td/parent::tr/td[2]/b")
    private WebElementFacade serRatVM;

    @FindBy(xpath=".//td/span[contains(text(),'FAILURE RISK (FINANCIAL STRESS) SCORE COMMENTARY')]/parent::td/parent::tr/td[2]/b")
    private List<WebElementFacade> commentryTextVM;

   // @FindBy(xpath=".//td/pre[contains(text(),'Failure Score')/parent::tr/td[1]")
    @FindBy(xpath=".//td[contains(text(),'Failure Score')]/parent::tr/td[2]")
    private WebElementFacade failPercentBIRHTML;

    @FindBy(xpath=".//td[contains(text(),'Rating')]/parent::tr/td[4]")
    private WebElementFacade dnbRatBIRHTML;

    @FindBy(xpath = ".//td[contains(text(),'Maximum Credit')]/parent::tr/td[2]")
    private WebElementFacade maxCreditBIRHTML;

    @FindBy(xpath = ".//table[@class='databox']/tbody/tr/td/ul/li")
    private List<WebElementFacade> commentryTextBIRHTML;

    @FindBy(xpath=".//td/span[contains(text(),'RATING')]/parent::td/parent::tr/td[2]/b")
    private WebElementFacade failPercentBIRTEXT;

    @FindBy(xpath = ".//td/span[contains(text(),'SER RATING')]/parent::td/parent::tr/td[2]/b")
    private WebElementFacade dnbRatBIRTEXT;

    @FindBy(xpath = ".//td/span[contains(text(),'SER RATING')]/parent::td/parent::tr/td[2]/b")
    private WebElementFacade maxCreditBIRTEXT;

    @FindBy(xpath=".//td/span[contains(text(),'FAILURE RISK (FINANCIAL STRESS) SCORE COMMENTARY')]/parent::td/parent::tr/td[2]/b")
    private List<WebElementFacade> commentryTextBIRTEXT;

    @FindBy(xpath = ".//td[@title='RISK BAND']/parent::tr/td[2]/b")
    private WebElementFacade riskBand;

    @FindBy(xpath=".//tr/td[contains(text(),'CALCULATED SCORE:')]/parent::tr/td[3]/b")
    private List<WebElementFacade> rawScoreGDMplus;

    @FindBy(xpath=".//tr/td[contains(text(),'NATIONAL 1-100 SCORE:')]/parent::tr/td[3]/b")
    private List<WebElementFacade> failPercentileGDMplus;

    @FindBy(xpath = ".//tr/td[contains(text(),'RATING:')]/parent::tr/td[2]/b")
    private WebElementFacade dnbRatingGDMplus;

    @FindBy(xpath = ".//tr/td[contains(text(),'SCORE COMMENTARY CODE:')]/parent::tr/td[3]/b")
    private WebElementFacade commentryTextGDMplus;

    private String titleName=".//span[contains(text(),'SERENITY')]";

    private boolean isReportAvailable;

    public boolean verifyTitle(String reportname) {
        UIHelper.waitForPageToLoad(getDriver());
        WebElementFacade actualtitleName = find(By.xpath(titleName.replace("SERENITY",reportname)));
        if(actualtitleName.isPresent()) {
            UIHelper.highlightElement(getDriver(),actualtitleName);
            isReportAvailable = true;
            return true;
        }
        else
        {
            isReportAvailable=false;
            return false;
        }
    }

    public String verifyAssDateinVM() {

        String result="";
       // WebElementFacade actualXpath= find(By.xpath(actual));
        if(isReportAvailable){
            if(assDateVM1.isPresent()){
                UIHelper.highlightElement(getDriver(),assDateVM1);
                result= assDateVM1.getText().trim();
            }
        }
        return result;
    }

    public String verifyAlgorithminVM(String expected) {
        String result="";
        //List<WebElementFacade> actualXpath = find(By.xpath(actual));
        if(isReportAvailable){
            if(!algIdVM.isEmpty()){
                for(WebElementFacade abc: algIdVM){
                    if(abc.getText().equalsIgnoreCase(expected)){
                        UIHelper.highlightElement(getDriver(),abc);
                        result = abc.getText().toLowerCase().trim();
                        break;
                    }
                }
            }
        }
        return result;
    }

    public String verifyFailScrinVM() {
        String result="";
       // WebElementFacade actualXpath = find(By.xpath(actual));
        if(isReportAvailable){
            if(failScrVM.isPresent()){
                UIHelper.highlightElement(getDriver(),failScrVM);
                result= failScrVM.getText().trim();
            }
        }
        return result;
    }

    public String verifyFailPercentinVM() {
        String result="";
        //WebElementFacade actualXpath = find(By.xpath(actual));
        if(isReportAvailable){
            if(failPercentVM.isPresent()){
                UIHelper.highlightElement(getDriver(),failPercentVM);
                result= failPercentVM.getText().trim();
            }
        }
        return result;
    }

    public String verifyDnbRatinVM() {
        String result="";
        //WebElementFacade actualXpath = find(By.xpath(actual));
        if(isReportAvailable){
            if(dnbRatVM.isPresent()){
                UIHelper.highlightElement(getDriver(),dnbRatVM);
                result= dnbRatVM.getText().replace(" ","").trim();
            }
        }
        return result;
    }

    public List<String> verifyCommentryinVM() {
        List<String> actuallist = new ArrayList<>();
        //List<WebElementFacade> actualXpath = find(By.xpath(actual));
        if (!commentryTextVM.isEmpty()) {
            for (WebElementFacade abc : commentryTextVM) {
                UIHelper.highlightElement(getDriver(), abc);
                actuallist.add(abc.getText().toString());
            }
        }
        return actuallist;
    }

    public String verifySERRatinVM() {
        String result="";
        //WebElementFacade actualXpath = find(By.xpath(actual));
        if(isReportAvailable){
            if(serRatVM.isPresent()){
                UIHelper.highlightElement(getDriver(),serRatVM);
                result= serRatVM.getText().trim();
            }
        }
        return result;
    }

    public void NavigateToPreviousPage() {
        getDriver().navigate().back();
    }

    public String verifyFailPercentinBIRHTML() {
        String result="";
        if(failPercentBIRHTML.isPresent()){
            UIHelper.highlightElement(getDriver(),failPercentBIRHTML);
            result=failPercentBIRHTML.getText().trim();
        }
        return result;
    }

    public String verifyDnbRatinBIRHTML() {
        String result="";
        if(dnbRatBIRHTML.isPresent()){
            UIHelper.highlightElement(getDriver(),dnbRatBIRHTML);
            result=dnbRatBIRHTML.getText().trim();
            result =result.replace(" ","");
        }
        return result;
    }

    public String verifyMaxCreditinBIRHTML() {
        String result="";
        if(maxCreditBIRHTML.isPresent()){
            UIHelper.highlightElement(getDriver(),maxCreditBIRHTML);
            result=maxCreditBIRHTML.getText().trim();
        }
        return result;
    }

    public List<String> verifyCommentryinBIRHTML()
    {
        List<String> actuallist = new ArrayList<>();
        //List<WebElementFacade> actualXpath = find(By.xpath(actual));
        if (!commentryTextBIRHTML.isEmpty()) {
            for (WebElementFacade abc : commentryTextBIRHTML) {
                UIHelper.highlightElement(getDriver(), abc);
                actuallist.add(abc.getText().toString());
            }
        }
        return actuallist;
    }

    public String verifyFailPercentinBIRTEXT() {
        String result="";
        if(failPercentBIRTEXT.isPresent()){
            UIHelper.highlightElement(getDriver(),failPercentBIRTEXT);
            result=failPercentBIRTEXT.getText().trim();
        }
        return result;
    }

    public String verifyDnbRatinBIRTEXT() {
        String result="";
        if(dnbRatBIRTEXT.isPresent()){
            UIHelper.highlightElement(getDriver(),dnbRatBIRTEXT);
            result=dnbRatBIRTEXT.getText().trim();
        }
        return result;
    }

    public String verifyMaxCreditinBIRTEXT() {
        String result="";
        if(maxCreditBIRTEXT.isPresent()){
            UIHelper.highlightElement(getDriver(),maxCreditBIRTEXT);
            result=maxCreditBIRTEXT.getText().trim();
        }
        return result;
    }

    public List<String> verifyCommentryinBIRTEXT() {
        List<String> actuallist = new ArrayList<>();
        //List<WebElementFacade> actualXpath = find(By.xpath(actual));
        if (!commentryTextBIRTEXT.isEmpty()) {
            for (WebElementFacade abc : commentryTextBIRTEXT) {
                UIHelper.highlightElement(getDriver(), abc);
                actuallist.add(abc.getText().toString());
            }
        }
        return actuallist;

    }

    public String verifyRiskBandinGDM() {
        String result="";
        UIHelper.waitForPageToLoad(getDriver());
        if(riskBand.isPresent()){
            UIHelper.highlightElement(getDriver(),riskBand);
            result= riskBand.getText().toLowerCase().trim();
        }
        return result;
}

    public String verifyFailScrinGDMplus(String actual)
    {
        String result="";
        UIHelper.waitForPageToLoad(getDriver());
        if(!rawScoreGDMplus.isEmpty()){
            for(WebElementFacade abc : rawScoreGDMplus){
                if(abc.getText().trim().equals(actual)){
                    UIHelper.highlightElement(getDriver(),abc);
                    result=abc.getText().trim();
                    break;
                }
            }
        }
        return result;
    }

    public String verifyFailPercentinGDMplus(String actual) {
        String result="";
        if(!failPercentileGDMplus.isEmpty()){
            for(WebElementFacade abc: failPercentileGDMplus){
                if(abc.getText().trim().equals(actual)){
                    UIHelper.highlightElement(getDriver(),abc);
                    result=abc.getText().trim();
                    break;
                }
            }
        }
        return result;
    }

    public String verifyDnbRatinGDMplus() {
        String result="";
        if(dnbRatingGDMplus.isPresent()){
            UIHelper.highlightElement(getDriver(),dnbRatingGDMplus);
            result = dnbRatingGDMplus.getText().toLowerCase().trim();
        }
        return result;
    }

    public String[] verifyCommentryinGDMplus() {
        String[] result= null;
        if(commentryTextGDMplus.isPresent()){
            UIHelper.highlightElement(getDriver(),commentryTextGDMplus);
            String actual = commentryTextGDMplus.getText().trim();
            System.out.println(actual);
             result= actual.split("\\.");
            System.out.println(result);
        }

        return result;
    }
}
