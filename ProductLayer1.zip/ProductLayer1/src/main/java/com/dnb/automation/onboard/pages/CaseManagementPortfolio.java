package com.dnb.automation.onboard.pages;

import java.util.List;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;


public class CaseManagementPortfolio extends PageObject {
	
	@FindBy(xpath = "//div[1]/table[@class='casesTable']/tbody")
    private WebElementFacade casesTable;
	
	@FindBy(xpath = "//*[@id='_previous']")
    private WebElementFacade previousBtn;
	
	@FindBy(xpath = "//*[@id='_next']")
    private WebElementFacade nextBtn;
	
	String reportViewerLoading = "//div[@id='reportViewerLoading']//img[@class='loader'][@src='/onboard/resources/images/ajax-loader.gif']";
	
	@FindBy(xpath = "//div/div[2]/a[2][@class='next paginate_button paginate_button']")
    private WebElementFacade nextPg;
	
	@FindBy(xpath = "//div/ul/li[1][@ref='CASE_AUDIT'][@title='Audit Summary']")
    private WebElementFacade caseAuditRpt;
	
	@FindBy(xpath = "//div/table[@id='associatedEntitiesTable']/tbody")
    private WebElementFacade associatedEntitiesTable;
	
	@FindBy(xpath = "//div/table[@class='eventLogTable searchResults']/tbody")
    private WebElement eventLogTable;
	
	@FindBy(xpath = "//*/div/table/tbody/tr[1]/td[7]/ul/li/a")
    private WebElementFacade caseActions;
	
	@FindBy(xpath = "//*/div/table/tbody/tr[1]/td[7]/ul/li/ul/li[2]/a")
    private WebElementFacade viewCaseAudit;


	public void searchCaseViewAudit() throws InterruptedException
	{	
		UIHelper.highlightElement(getDriver(), caseActions);
		caseActions.click();
    	UIHelper.waitForPageToLoad(getDriver());	            	
    	UIHelper.highlightElement(getDriver(), viewCaseAudit);
    	viewCaseAudit.click();	           	
    	UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), reportViewerLoading);
		
	}
	
	public boolean caseAuditRpt()
	{
		if (caseAuditRpt.isPresent()){	
			UIHelper.highlightElement(getDriver(), caseAuditRpt);
			return true;
		}				
		else
			return false;
	}
	
	public void validateAssociateBusEntity(String Name, String DunsNumber) throws InterruptedException
	{
		search:
			do
			{			
				List <WebElement> row = associatedEntitiesTable.findElements(By.tagName("tr"));        
		        int row_count =  row.size();        
		        System.out.println("row count is " + row_count);

		        for (int i=0; i<row_count; i++)
		        {
		        	List <WebElement> col = row.get(i).findElements(By.tagName("td"));	        	  	        	
		            System.out.println("case name is : " + col.get(0).getText() + "link is :" + i ); 	           
		            
		            if(col.get(0).getText().equalsIgnoreCase(Name))
		            {
		            	if(col.get(1).getText().equalsIgnoreCase(DunsNumber))
		            	{
		            		i++;
		            		WebElement caseName = getDriver().findElement(By.xpath("//div/table[@id='associatedEntitiesTable']/tbody/tr["+i+"]/td[1]"));
		            		UIHelper.highlightElement(getDriver(), caseName);	
		            		
		            		WebElement Duns = getDriver().findElement(By.xpath("//div/table[@id='associatedEntitiesTable']/tbody/tr["+i+"]/td[2]"));
		            		UIHelper.highlightElement(getDriver(), Duns);
		            		
		            		break search;
		            }	
		        	
		        } 
		        	        
			}
		        nextBtn.click();
			
			}
		        while(nextPg.isPresent());

	}
	
	
	
	public void validateEventLog(String Name, String DunsNumber, String Description) throws InterruptedException
	{
		search:
			do
			{			
				List <WebElement> row = eventLogTable.findElements(By.tagName("tr"));        
		        int row_count =  row.size();        
		        System.out.println("row count is " + row_count);

		        for (int i=0; i<row_count; i++)
		        {
		        	List <WebElement> col = row.get(i).findElements(By.tagName("td"));	        	  	        	
		            System.out.println("case name is : " + col.get(0).getText() + "link is :" + i ); 	           
		            
		            if(col.get(1).getText().equalsIgnoreCase(Name))
		            {
		            	if(col.get(2).getText().equalsIgnoreCase(DunsNumber))
		            	{
		            		if(col.get(3).getText().equalsIgnoreCase(Description))
		            		i++;
		            		
		            		WebElement DunsName = getDriver().findElement(By.xpath("//div/table[@class='eventLogTable searchResults']/tbody/tr["+i+"]/td[2]"));
		            		UIHelper.highlightElement(getDriver(), DunsName);	
		            		
		            		
		            		WebElement DunsNum = getDriver().findElement(By.xpath("//div/table[@class='eventLogTable searchResults']/tbody/tr["+i+"]/td[3]"));
		            		UIHelper.highlightElement(getDriver(), DunsNum);	
		            		
		            		
		            		WebElement description = getDriver().findElement(By.xpath("//div/table[@class='eventLogTable searchResults']/tbody/tr["+i+"]/td[4]"));
		            		UIHelper.highlightElement(getDriver(), description);
		            		
		            		break search;
		            }	
		        	
		        } 
		        	        
			}
		        nextBtn.click();
			
			}
		        while(nextPg.isPresent());
	}
	
			}