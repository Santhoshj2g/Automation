package com.dnb.automation.cirrus.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import com.dnb.automation.utils.CirrusWebUiParserUtil;

public class WebUiResponseCache {

	private static HashMap<String, Map<String, List<Object>>> webUiElementMap;


	public HashMap<String, Map<String, List<Object>>> getUiTabData(String dunsNo,
			String tabName) {
		String key = dunsNo + "_" + tabName;
		try {
			if (webUiElementMap == null) {
				webUiElementMap = new HashMap<String, Map<String, List<Object>>>();
			}

			if (webUiElementMap.get(key) != null) {
				return webUiElementMap;
			} else {
				return null;
			}
		} catch (Exception e) {
		}
		return null;
	}
	
	public HashMap<String, Map<String, List<Object>>> readUiTabData(String duns,String tabName,WebDriver driver) throws InterruptedException{
		String key = duns + "_" + tabName;
		webUiElementMap.put(key,CirrusWebUiParserUtil.getTabWebElementMap(driver));
		return webUiElementMap;
	}
}