package com.dnb.automation.eram.pages;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;

import com.google.common.base.Predicate;
import com.dnb.automation.eram.pages.AccountPage;


public class eRAMToolsPage extends PageObject {
		AccountPage accountPageObject ;
		private final Logger log=Logger.getLogger(this.getClass().getPackage().getName());
	  @FindBy(xpath = "//span[contains(@id,'TOOLS-btnInnerEl')]/div[contains(.,'TOOLS')]")
	  private WebElementFacade toolsTab;
	  
	  @FindBy(xpath = "//span[contains(@id,'processbutton') and contains(@id,'btnInnerEl') and contains(.,'+New')]")
	  private WebElementFacade toolsNewBtn;
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Policies')]")
	  private WebElementFacade policiesTab;
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Credit Limit Policies')]")
	  private WebElementFacade creditLimitPoliciesTab;
	  
	  @FindBy(xpath = "//span[@id='CrLP_btn_1-btnInnerEl' and contains(.,'+ New Rule')]")
	  private WebElementFacade creditLimitPoliciesNewRuleBtn;
	  
	  @FindBy(xpath = "//*[@id='critRulId-inputEl']")
	  private WebElementFacade ruleDescriptionTextField;
	  
	  @FindBy(xpath = "//*[@id='dbCombo-trigger-picker']")
	  private WebElementFacade databaseFieldListBox;
	  
	  @FindBy(xpath = "//*[@id='opCombo-trigger-picker']")
	  private WebElementFacade operatorsListBox;
	  
	  @FindBy(xpath = "//*[@id='sql-boxLabelEl']")
	  private WebElementFacade sQLRadioBtn;
	  
	  @FindBy(xpath = "//*[@id='criteriaId-bodyEl']//textarea[@id='criteriaId-inputEl']")
	  private WebElementFacade criteriaTextArea;
	  
	  @FindBy(xpath = "//span[contains(@id,'processbutton') and contains(.,'Add to Criteria')]")
	  private WebElementFacade addToCriteriaBtn;
	  
	  @FindBy(xpath = "//span[contains(@id,'processbutton') and contains(.,'Save')]")
	  private WebElementFacade ruleSaveBtn;
	  
	  @FindBy(xpath = "//*[@id='criteriabuilderwindviewid-innerCt']//span[contains(@id,'processbutton') and contains(.,'Save')]")
	  private WebElementFacade ruleSaveBtn1;
	  
	  @FindBy(xpath = "//*[contains(@id,'messagebox') and contains(@id,'innerCt')]//*[contains(@id,'messagebox') and contains(@id,'msg') and contains(.,'The rule affects')]")
	  private WebElementFacade affectedRecordsMsg;
	  
	  @FindBy(xpath = "//*[contains(@id,'messagebox') and contains(@id,'innerCt')]//*[contains(@id,'messagebox') and contains(@id,'msg') and contains(.,'The rule is invalid')]")
	  private WebElementFacade invalidAlertMsg;
	  
	  @FindBy(xpath = "//*[contains(@id,'messagebox') and contains(@id,'toolbar-innerCt')]//span[contains(@id,'button') and contains(.,'OK')]")
	  private WebElementFacade cLTruleExpOKBtn;
	  
	  @FindBy(xpath = "//*[@id='calc_nbr_acctid-boxLabelEl']")
	  private WebElementFacade calculateNoOFRecordsCheckbox;
	  
	  @FindBy(xpath = "//span[contains(@id,'CrLP_btn') and contains(.,'+ New Expression')]")
	  private WebElementFacade creditLimitPoliciesNewExpressionBtn;
	  
	  @FindBy(xpath = "//*[@id='expRuleId-inputEl']")
	  private WebElementFacade expressionDescriptionTextField;
	  
	  @FindBy(xpath = "//*[@id='expSql-boxLabelEl']")
	  private WebElementFacade expresiionSQLRadioBtn;
	  
	  @FindBy(xpath = "//*[@id='expDesc-boxLabelEl']")
	  private WebElementFacade expresiionDescriptionRadioBtn;
	  
	  @FindBy(xpath = "//*[@id='expressionId-bodyEl']//textarea[@id='expressionId-inputEl']")
	  private WebElementFacade expressionTextArea;
	  
	  @FindBy(xpath = "//*[@id='expDbCombo-trigger-picker']")
	  private WebElementFacade expressionDatabaseFieldListBox;
	  
	  @FindBy(xpath = "//*[@id='expOpCombo-trigger-picker']")
	  private WebElementFacade expressionOperatorsListBox;
	  
	  @FindBy(xpath = "//span[contains(@id,'addexprbtnid') and contains(.,'Add to Expression')]")
	  private WebElementFacade addToExpressionBtn;
	  
	  @FindBy(xpath = "//*[@id='calcMinMaxAvgId-boxLabelEl']")
	  private WebElementFacade calculateMaxMinAvgCheckbox;
	  
	  @FindBy(xpath = "//span[@id='expBuilderSaveBtnId-btnInnerEl' and contains(.,'Save')]")
	  private WebElementFacade expressionSaveBtn;
	  
	  @FindBy(xpath = "//span[contains(@id,'CrLP_btn') and contains(.,'Link Expression')]")
	  private WebElementFacade linkExpressionBtn;
	  
	  @FindBy(xpath="//span[contains(@id,'button') and contains(.,'OK')]")
	  private WebElementFacade okButtonElement;
	  
	  @FindBy(xpath="//a[@id='deletefilter']//span[@id='deletefilter-btnInnerEl']")
	  private WebElement filterDeleteBtn;
	  
	  @FindBy(xpath="//*[@id='filtergridID-body']//table/tbody/tr/td[1]/div")
	  private List<WebElement> filterNaemList;
	  
	  @FindBy(xpath = "//span[contains(@id,'templatebutton') and contains(@id,'btnInnerEl') and contains(.,'+ New')]")
	  private WebElementFacade filterNewBtn;
	  
	  @FindBy(xpath="//label[@id='textfieldid-labelEl' and contains(.,'Enter New Filter Name:')]//following-sibling::div//input[@id='textfieldid-inputEl']")
	  private WebElementFacade filterNameTextBox;
	  
	  @FindBy(xpath = "/*[@id='newfilterId1-boxLabelEl']")
	  private WebElementFacade userFilterRadioBtn;
	  
	  @FindBy(xpath = "//*[@id='newfilterId2-boxLabelEl']")
	  private WebElementFacade groupFilterRadioBtn;
	  
	  @FindBy(xpath = "//*[@id='newfilterId3-boxLabelEl']")
	  private WebElementFacade globalFilterRadioBtn;
	  
	  
	  @FindBy(xpath = "//*[@id='newfiltercombo-trigger-picker']")
	  private WebElementFacade groupFilterListbox;
	  
	  @FindBy(xpath = "//span[contains(@id,'processbutton') and contains(.,'OK')]")
	  private WebElementFacade filterPopupOKBtn;
	  
	  @FindBy(xpath = "//input[@id='filcritRulId-inputEl']")
	  private WebElementFacade filterRuleNameteXtField;
	  
	  @FindBy(xpath = "//*[@id='fildbCombo-trigger-picker']")
	  private WebElementFacade filterRuleDataBaseFitledList;
	  
	  @FindBy(xpath = "//*[@id='filopCombo-trigger-picker']")
	  private WebElementFacade filterRuleOperatorList;
	  
	  @FindBy(xpath = "//label[contains(@id,'sql-boxLabelEl') and contains(.,'SQL')]")
	  private WebElementFacade sqlRadioBtn;
	  
	  @FindBy(xpath = "//*[@id='filcriteriaId-inputEl']")
	  private WebElementFacade filterRuleTextArea;
	  
	  @FindBy(xpath = "//label[contains(@id,'desc-boxLabelEl') and contains(.,'Description')]")
	  private WebElementFacade descriptionRadioBtn;
	  
	  @FindBy(xpath = "//*[@id='filcalc_nbr_acctid-boxLabelEl']")
	  private WebElementFacade filterRuleCalculatedCheckbox;
	  
	  @FindBy(xpath = "//*[@id='filsaveid-btnInnerEl']")
	  private WebElementFacade filterRuleSavebtn;
	  
	  @FindBy(xpath = "//span[contains(@id='btnInnerEl') and contains(.,'+ New')]")
	  private WebElementFacade anyNew_Btn;
	  
	  @FindBy(xpath = "//label[contains(@id,'combo')and contains(@id,'labelEl') and contains(.,'Process Type:')]//following-sibling::div//*[contains(@id,'combo') and contains(@id,'trigger-picker')]")
	  private WebElementFacade boundListButton;
	  
	  @FindBy(xpath = "//span[contains(@id,'templatebutton') and contains(@id,'btnInnerEl') and contains(.,'Schedule')]")
	  private WebElementFacade scheduleBtn;
	  
	  @FindBy(xpath = "//*[contains(@id,'title') and contains(.,'Completed Process Status')]")
	  private WebElementFacade tableheader;
	  
	  @FindBy(xpath = "//*[contains(@id,'panel') and contains(@id,'targetEl')]//label[contains(.,'Rules Applied')]//following-sibling::label")
	  private WebElementFacade rulesAppliedElement;
	  
	  @FindBy(xpath = "//span[@id='CoLP_btn_1-btnInnerEl' and contains(.,'+ New')]")
	  private WebElementFacade collectionsPoliciesNewBtn;
	  
	  @FindBy(xpath = "//span[@id='CoLP_btn_4-btnInnerEl' and contains(.,'+ New')]")
	  private WebElementFacade collectionsActionsNewBtn;
	  
	  @FindBy(xpath = "//*[@id='textfieldid-inputEl']")
	  private WebElementFacade actionTextField;
	  
	  @FindBy(xpath = "//span[contains(@id,'btnInnerEl') and contains(.,'Link Expression')]")
	  private WebElementFacade linkExpressionButton;
	  
	  @FindBy(xpath = "//span[contains(@id,'btnInnerEl') and contains(.,'Save')]")
	  private WebElementFacade saveButton;
	  
	  @FindBy(xpath = "//label[@id='scrovrvalchk-boxLabelEl']")
	  private WebElementFacade scoreOverrideValueCheckBox;
	  
	  @FindBy(xpath = "//input[@id='scrovrvaltxt-inputEl']")
	  private WebElementFacade scoreOverrideValueInputBox;
	  
	  @FindBy(xpath = "//textarea[@id='exceptiontextareaid-inputEl']")
	  private WebElementFacade analysisMessageTextBox;
	  
	  @FindBy(xpath = "//*[@id='critRulId-inputEl']")
	  private WebElementFacade exceptionPolicyRuleDesc;
	  
	  @FindBy(xpath = "//span[@id='SeLP_btn_1-btnInnerEl' and contains(.,'+ New')]")
	  private WebElementFacade sTPAccountTypeNewBtn;
	  
	  @FindBy(xpath = "//span[@id='SeLP_btn_4-btnInnerEl' and contains(.,'+ New')]")
	  private WebElementFacade sTermsNewBtn;
	  
	  @FindBy(xpath = "//*[@id='modl_nme-inputEl']")
	  private WebElementFacade modelNameTextField;
	  
	  @FindBy(xpath = "//*[@id='SPbtn']//span[@id='SPbtn-btnInnerEl']")
	  private WebElementFacade ruleSQLFormEditBtn;
	  
	  @FindBy(xpath = "//*[contains(@id,'title') and contains(.,'Policy Component')]//following-sibling::a//span[contains(@id,'btnInnerEl')]")
	  private WebElementFacade policyComponentEditBtn;
	  	  
	  @FindBy(xpath = "//label[contains(@id,'numberfield') and contains(.,'Credit Limit Weight')]//following-sibling::div[1]//input[contains(@id,'numberfield') and contains(@id,'inputEl')]")
	  private WebElementFacade creditLimitWeightTextBox;
	  
	  @FindBy(xpath = "//*[@id='scorechangecomponentviewid-body']//span[contains(@id,'processbutton') and contains(.,'Save')]")
	  private WebElementFacade componentsBtn1;
	  
	  @FindBy(xpath = "//span[contains(@id,'processbutton') and contains(.,'Save')]")
	  private WebElementFacade saveButtonForAll;
	  
	  @FindBy(xpath = "//span[contains(@id,'editPrioBtnId-btnInnerEl') and contains(.,'Save')]")
	  private WebElementFacade saveSCRSaveBtn;
	  
	  @FindBy(xpath = "//label[contains(@id,'textfield') and contains(.,'Label')]//following-sibling::div[1]//input[contains(@id,'textfield') and contains(@id,'inputEl')]")
	  private WebElementFacade customFieldLabelNameTextField;
	  
	  @FindBy(xpath = "//label[contains(@id,'radio') and contains(.,'Factor')]//ancestor::div[3]//following-sibling::div[1]//input[@type='text']")
	  private WebElementFacade customFieldComponentTextField;
	  
	  @FindBy(xpath = "//span[contains(@id,'templatebutton') and contains(.,'Attach Lookup')]")
	  private WebElementFacade attachLookupBtn;
	  
	  @FindBy(xpath = "//span[contains(@id,'templatebutton') and contains(.,'Save')]")
	  private WebElementFacade newCustromFieldSaveBtn;
	  
	  @FindBy(xpath = "//span[contains(@id,'templatebutton') and contains(.,'Cancel')]")
	  private WebElementFacade newCustromFieldCancelBtn;
	  
	  @FindBy(xpath = "//label[contains(@id,'checkbox') and contains(.,'Composite')]")
	  private WebElementFacade customFieldCompositeCheckbox;

	  @FindBy(xpath = "//*[contains(@id,'messagebox') and contains(@id,'body')]//*[contains(@id,'container') and contains(@id,'innerCt')]//div[contains(.,'The label is already exists. Please edit')]")
	  private WebElementFacade messageBoxtext;
	  
	  @FindBy(xpath = "//span[contains(@id,'newLkupLstId-btnInnerEl') and contains(.,'+ New')]")
	  private WebElementFacade lookupNewBtn;
	  
	  @FindBy(xpath = "//input[@id='lkupNmeId-inputEl']")
	  private WebElementFacade lookupTableNameTestField;
	  
	  @FindBy(xpath = "//*[@id='lkupValGridId-body']//table/tbody/tr/td[1]/div")
	  private WebElementFacade lookupTableDescription;
	  
	  @FindBy(xpath = "//input[contains(@id,'textfield') and contains(@id,'inputEl') and @name='lkup_det_desc']")
	  private WebElementFacade lookupTableDescription1;
	  
	  @FindBy(xpath = "//*[@id='lkupValGridId-body']//table/tbody/tr/td[2]/div")
	  private WebElementFacade lookupTableValue;
	  
	  @FindBy(xpath = "//input[contains(@id,'numberfield') and contains(@id,'inputEl') and @name='val']")
	  private WebElementFacade lookupTableValue1;
	  
	  @FindBy(xpath = "//*[@id='lkupValGridId-body']//table/tbody/tr/td[3]/div")
	  private WebElementFacade lookupTableNameBackup;
	  
	  @FindBy(xpath = "//input[contains(@id,'numberfield') and contains(@id,'inputEl') and @name='bkup_val']")
	  private WebElementFacade lookupTableNameBackup1;
	  
	  @FindBy(xpath = "//span[contains(@id,'lkupSaveValueId-btnInnerEl') and contains(.,'Save')]")
	  private WebElementFacade lookupTableSaveBtn;
	  
	  @FindBy(xpath = "//*[@id='creditRamScrGridId-body']//table/tbody/tr/td[2]/div")
	  private WebElementFacade ramScoreDate;
	  
	  @FindBy(xpath = "//*[@id='creditRamScrGridId-body']//table/tbody/tr/td[3]/div")
	  private WebElementFacade ramScoreModel;
	  
	  @FindBy(xpath = "//*[contains(@id,'panel') and contains(@id,'header') and contains(.,'Statements Available:')]//following-sibling::div//ul[contains(@id,'boundlist')]/li[1]")
	  private WebElementFacade statementAvailableList;
	  
	  @FindBy(xpath="//span[contains(@id,'button') and contains(.,'Add')]")
	  private WebElementFacade selectionPolicesAddBtn;
	  
	  
	  @FindBy(xpath="//input[@id='finSelMonthId-inputEl']")
	  private WebElementFacade statementsOlderThanMonthTextBox;
	  
	  int componenetcount;
	  static String cltruleName="";
	  public static String getCltruleName() {
		return cltruleName;
	  }
	String toolsTableXpath="//*[@id='profilegrid-body']//table/tbody";
	  String createNewRulePopupXpath="//*[@id='critRulId-triggerWrap']";
	  String creditLimtRuleTableXpath="//*[@id='treepanId-body']//table/tbody";
	  String createNewExpressionPopupXpath="//*[@id='expressionBuilderViewId-innerCt']";
	  String saveBtnXpath="//span[contains(@id,'processbutton') and contains(.,'Save')]";
	  String filterPopupXpath="//input[@id='textfieldid-inputEl']";
	  String filterTableXpath="//*[@id='filtergridID-body']//table/tbody";
	  String collectionPolicyTableXpath="//*[@id='treepanId-body']//table/tbody/tr/td";
	  boolean newCLTRuleFlag=true;
	public void click_Tools_Tab() {
		toolsTab.isVisible();
		AccountPage.highlightElement(getDriver(), toolsTab);
		toolsTab.click();
		AccountPage.waitForVisibilityOfeRAMElementsforlesstime(getDriver(),toolsTableXpath);
		AccountPage.highlightElement(getDriver(), toolsNewBtn);
	}
	
	public void click_Tools_PoliciesTab(){
		policiesTab.isVisible();
		AccountPage.mouseOverAndHighlightanElement(getDriver(), policiesTab);
		policiesTab.click();
		waitFor(2000).milliseconds();
	}
	
	public void click_Tools_CreditLimitPoliciesTab(){
		creditLimitPoliciesTab.isVisible();
		AccountPage.mouseOverAndHighlightanElement(getDriver(), creditLimitPoliciesTab);
		creditLimitPoliciesTab.click();
		waitFor(2000).milliseconds();
	}
	
	public void click_CreditLimitPolicies_New_Rule_Btn(){
		creditLimitPoliciesNewRuleBtn.isVisible();
		AccountPage.mouseOverandElementClick(getDriver(), creditLimitPoliciesNewRuleBtn);
		AccountPage.waitForVisibilityOfeRAMElementsforlesstime(getDriver(),createNewRulePopupXpath);
		waitFor(2000).milliseconds();
	}
	
	public void enter_Rule_Name(String RuleName,String FileName){
		AccountPage.mouseOverAndHighlightanElement(getDriver(), ruleDescriptionTextField);
		String ruleName1=AccountPage.append_Date_Format_To_Name(RuleName);
		ruleDescriptionTextField.type(ruleName1);
		AccountPage.write_Text_Into_File(FileName,ruleName1);
		log.log(Level.INFO,"Credit Limit Rule Name written in file --------------------- "+ruleName1);
	}
	

	
	/*public void input_Criteria(String DatabaseField, String Operator , String SQLExpression){
		
		if(!SQLExpression.equals("")){
			AccountPage.mouseOverandElementClick(getDriver(), sQLRadioBtn);
			waitFor(500).milliseconds();
			criteriaTextArea.click();
			waitFor(500).milliseconds();
			criteriaTextArea.type(SQLExpression);
		}else{
			accountPageObject.select_An_Option_From_List(databaseFieldListBox,DatabaseField);
			accountPageObject.select_An_Option_From_List(operatorsListBox,Operator);
			addToCriteriaBtn.click();
			waitFor(1000).milliseconds();
		}
		
	}*/
	
	public void creditLimit_rule_Input_Criteria(String DatabaseField, String Operator , String SQLExpression){
		rule_Input_Criteria(databaseFieldListBox, operatorsListBox, addToCriteriaBtn, sqlRadioBtn, criteriaTextArea, descriptionRadioBtn,DatabaseField, Operator ,SQLExpression);
	}

	public void select_Calculate_No_Of_Records_RadioBtn(String Flag){
		if(Flag.equals("Yes")){
			AccountPage.mouseOverandElementClick(getDriver(), calculateNoOFRecordsCheckbox);
		}
	}
	public void click_Rule_Save_Btn(){
		AccountPage.mouseOverandElementClick(getDriver(), ruleSaveBtn);
		AccountPage.waitForVisibilityOfeRAMElementsforlesstime(getDriver(),creditLimtRuleTableXpath);
		waitFor(5000).milliseconds();
		if(cLTruleExpOKBtn.isVisible()){
			cLTruleExpOKBtn.click();
			waitFor(1000).milliseconds();
		}
		/*if(affectedRecordsMsg.isVisible()){
			cLTruleExpOKBtn.click();
			waitFor(1000).milliseconds();
		}else if(invalidAlertMsg.isVisible()){
			cLTruleExpOKBtn.click();
			waitFor(1000).milliseconds();
			newCLTRuleFlag=false;
		}*/
	}
	
	public String get_Name_Form_File(String FileName){
			String rname=AccountPage.read_Text_From_File(FileName);
			return rname;
	}
	 	public boolean verify_Credit_Limit_Rule_Has_Created(String FileName){
	 		try{
	 			cltruleName=AccountPage.read_Text_From_File(FileName);
				log.log(Level.INFO,"Credit Limit Rule Name red from file --------------------- "+cltruleName);
	 			String RuleNameXpath="//*[@id='treepanId-body']//table/tbody//tr//td//span[contains(.,'"+cltruleName+"')]";
	 			WebElementFacade ruleNameElement=find(By.xpath(RuleNameXpath));
	 			AccountPage.mouseOverAndHighlightanElement(getDriver(), ruleNameElement);
	 			return true;
	 		}catch(Exception e){
	 			return false;
	 		}
	 		
	 	}
	 	
		public void click_CreditLimitPolicies_New_Expression_Btn(){
			creditLimitPoliciesNewExpressionBtn.isVisible();
			AccountPage.mouseOverandElementClick(getDriver(), creditLimitPoliciesNewExpressionBtn);
			AccountPage.waitForVisibilityOfeRAMElementsforlesstime(getDriver(),createNewExpressionPopupXpath);
			waitFor(2000).milliseconds();
		}
		
		public void enter_Expression_Name(String ExpressionName,String FileName){
			AccountPage.mouseOverAndHighlightanElement(getDriver(), expressionDescriptionTextField);
			String expressionName1=AccountPage.append_Date_Format_To_Name(ExpressionName);
			expressionDescriptionTextField.type(expressionName1);
			AccountPage.write_Text_Into_File(FileName,expressionName1);
			log.log(Level.INFO,"Credit Limit Rule Name written in file --------------------- "+expressionName1);
		}
		public void expression_Input_Criteria(String DatabaseField, String Operator , String SQLExpression){
			
			accountPageObject.select_An_Option_From_List(expressionDatabaseFieldListBox,DatabaseField);
			accountPageObject.select_An_Option_From_List(expressionOperatorsListBox,Operator);
			addToExpressionBtn.click();
			waitFor(1000).milliseconds();
			AccountPage.mouseOverandElementClick(getDriver(), expresiionSQLRadioBtn);
			waitFor(500).milliseconds();
			expressionTextArea.click();
			waitFor(500).milliseconds();
			expressionTextArea.sendKeys(SQLExpression);
			waitFor(500).milliseconds();
			AccountPage.mouseOverandElementClick(getDriver(), expresiionDescriptionRadioBtn);
			
		}
		public void select_Calculate_Min_Max_Avg_CheckBox(String Flag){
			if(Flag.equals("Yes")){
				AccountPage.mouseOverandElementClick(getDriver(), calculateMaxMinAvgCheckbox);
			}
		}
		
		public void click_Expression_Save_Btn(){
			AccountPage.mouseOverandElementClick(getDriver(), expressionSaveBtn);
			AccountPage.waitForVisibilityOfeRAMElementsforlesstime(getDriver(),creditLimtRuleTableXpath);
			waitFor(5000).milliseconds();
			if(cLTruleExpOKBtn.isVisible()){
				cLTruleExpOKBtn.click();
				waitFor(1000).milliseconds();
			}
		}
		
	 	public boolean verify_Credit_Limit_Expression_Has_Created(String FileName){
	 		try{
	 			String cltExpressionName=AccountPage.read_Text_From_File(FileName);
				log.log(Level.INFO,"Credit Limit Expression Name red from file --------------------- "+cltExpressionName);
	 			String RuleNameXpath="//*[@id='cred_lim_exp_view']//table/tbody//tr//td[contains(.,'"+cltExpressionName+"')]";
	 			WebElementFacade ruleNameElement=find(By.xpath(RuleNameXpath));
	 			AccountPage.mouseOverAndHighlightanElement(getDriver(), ruleNameElement);
	 			return true;
	 		}catch(Exception e){
	 			return false;
	 		}
	 		
	 	}
	 	public void select_Rule(String FileName){
	 		cltruleName=AccountPage.read_Text_From_File(FileName);
			log.log(Level.INFO,"Credit Limit Rule Nam select for link --------------------- "+cltruleName);
 			String RuleNameXpath="//*[@id='treepanId-body']//table/tbody//tr//td//span[contains(.,'"+cltruleName+"')]";
 			WebElementFacade ruleNameElement=find(By.xpath(RuleNameXpath));
 			AccountPage.mouseOverandElementClick(getDriver(), ruleNameElement);
 			waitFor(500).milliseconds();
	 	}
	 	
	 	public void select_Expression(String FileName){
	 		String cltExpressionName=AccountPage.read_Text_From_File(FileName);
			log.log(Level.INFO,"Credit Limit Expression Name select for link--------------------- "+cltExpressionName);
 			String RuleNameXpath="//*[@id='cred_lim_exp_view']//table/tbody//tr//td[contains(.,'"+cltExpressionName+"')]";
 			WebElementFacade ruleNameElement=find(By.xpath(RuleNameXpath));
 			AccountPage.mouseOverandElementClick(getDriver(), ruleNameElement);
 			waitFor(500).milliseconds();
	 		
	 	}
		public void click_link_Expression_Btn(){
			//AccountPage.mouseOverandElementClick(getDriver(), linkExpressionBtn);
			AccountPage.mouseOverandElementClick(getDriver(), linkExpressionButton);
			waitFor(1000).milliseconds();
			if(saveButton.isVisible()){
				AccountPage.mouseOverAndHighlightanElement(getDriver(), saveButton);
				saveButton.click();
				waitFor(2000).milliseconds();
			}
			if(cLTruleExpOKBtn.isVisible()){
				cLTruleExpOKBtn.click();
				waitFor(1000).milliseconds();
			}
			AccountPage.waitForVisibilityOfeRAMElementsforlesstime(getDriver(),creditLimtRuleTableXpath);
			waitFor(4000).milliseconds();
			
		}
		
	 	public boolean verify_Credit_Limit_Rule_Has_Linked_With_Expression(String FileName){
	 		try{
	 			cltruleName=AccountPage.read_Text_From_File(FileName);
				String RuleNameXpath="//*[@id='treepanId-body']//table/tbody//tr//td//span[contains(.,'"+cltruleName+"')]";
	 			WebElementFacade ruleNameElement=find(By.xpath(RuleNameXpath));
	 			AccountPage.mouseOverAndHighlightanElement(getDriver(), ruleNameElement);
	 			log.log(Level.INFO,"Credit Limit Rule linked with expression --------------------- "+cltruleName);
	 			return true;
	 		}catch(Exception e){
	 			return false;
	 		}
	 		
	 	}
	 	
		public void click_Tools_SubTabs(String SubTabName){
			  
			  String xpath="//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'"+SubTabName+"')]";
			  WebElementFacade plocySubTab_Element=find(By.xpath(xpath));
			  plocySubTab_Element.isVisible();
			AccountPage.mouseOverAndHighlightanElement(getDriver(), plocySubTab_Element);
			plocySubTab_Element.click();
			waitFor(2000).milliseconds();
		}
		
		public void click_Exceptions_Policies_New_Btn(){
			toolsNewBtn.isVisible();
			AccountPage.mouseOverandElementClick(getDriver(), toolsNewBtn);
			AccountPage.waitForVisibilityOfeRAMElementsforlesstime(getDriver(),saveBtnXpath);
			waitFor(2000).milliseconds();
		}
		
		public void click_Tools_Left_SideTab(String TabName){
			 String xpath="//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'"+TabName+"')]";
			  WebElementFacade SubTab_Element=find(By.xpath(xpath));
			AccountPage.mouseOverAndHighlightanElement(getDriver(), SubTab_Element);
			SubTab_Element.click();
			if(okButtonElement.isVisible()){
				okButtonElement.click();
			}
			waitFor(3000).milliseconds();
		}
		
		public boolean delete_Existing_Items(List<WebElement> element, String ItemName, WebElement deleteElement){
			
			int deleteFlag=0;
			for (WebElement trElement : element) {				
				AccountPage.mouseOveranElement(getDriver(), trElement);
				waitFor(100).milliseconds();
				if(trElement.getText().trim().equals(ItemName)){
					log.log(Level.INFO,"Element need to delete  --------------------- "+trElement.getText().trim());
					AccountPage.mouseOverandElementClick(getDriver(), trElement);
					waitFor(500).milliseconds();
					AccountPage.mouseOverandElementClick(getDriver(), deleteElement);
					if(okButtonElement.isVisible()){
						okButtonElement.click();
						waitFor(1000).milliseconds();
					}
					deleteFlag=1;
					break;
				}
			}
			if(deleteFlag==1){
				log.log(Level.INFO,"Element deleted sucessfully--------------------");
				return true;
			}else{
				return false;
			}
			
		}
		
		public boolean delete_Existing_Filter(String FilterName){
			return delete_Existing_Items(filterNaemList, FilterName, filterDeleteBtn);
		}
		
		public void click_Filter_New_Btn(){
			filterNewBtn.isVisible();
			AccountPage.mouseOverandElementClick(getDriver(), filterNewBtn);
			AccountPage.waitForVisibilityOfeRAMElementsforlesstime(getDriver(),filterPopupXpath);
			waitFor(1000).milliseconds();
		}
		
		public void enter_Filter_Name(String FilterName){
			filterNameTextBox.isVisible();
			AccountPage.highlightElement(getDriver(), filterNameTextBox);
			filterNameTextBox.type(FilterName);
			waitFor(500).milliseconds();
		}
		public void select_Filter_type(String FilterType, String FilterOption ){
			if(FilterType.equals("User Filter")){
				AccountPage.mouseOverandElementClick(getDriver(), userFilterRadioBtn);
			}
			else if(FilterType.equals("Group Filter")){
				AccountPage.mouseOverandElementClick(getDriver(), groupFilterRadioBtn);
				waitFor(1000).milliseconds();
				accountPageObject.select_An_Option_From_List(groupFilterListbox,FilterOption);
				
			}
			else if(FilterType.equals("Global Filter")){
				AccountPage.mouseOverandElementClick(getDriver(), globalFilterRadioBtn);
			}
			AccountPage.mouseOverandElementClick(getDriver(), filterPopupOKBtn);
			waitFor(10000).milliseconds();
		}
		
		public void enter_input_Name(WebElementFacade textField,String Name){
			AccountPage.mouseOverAndHighlightanElement(getDriver(), textField);
			textField.click();
			textField.type(Name);
			
		}
		public void rule_Input_Criteria(WebElementFacade DatabaseFieldelement, WebElementFacade Operatorelement, WebElementFacade addButton, WebElementFacade sqlButton, WebElementFacade textArea, WebElementFacade descriptionRadioButton,String DatabaseField, String Operator , String SQLExpression){
			waitFor(1000).milliseconds();
			accountPageObject.select_An_Option_From_List(DatabaseFieldelement,DatabaseField);
			waitFor(1000).milliseconds();
			accountPageObject.select_An_Option_From_List(Operatorelement,Operator);
			addButton.click();
			waitFor(1000).milliseconds();
			AccountPage.mouseOverandElementClick(getDriver(), sqlButton);
			waitFor(1500).milliseconds();
			textArea.click();
			waitFor(1000).milliseconds();
			String SQLExpression1="'"+SQLExpression+"'";
			textArea.sendKeys(SQLExpression1);
			waitFor(1000).milliseconds();
			AccountPage.mouseOverandElementClick(getDriver(), descriptionRadioButton);
			
		}
		
		public void select_Calculated_CheckBox(WebElementFacade checkbox,String Flag){
			if(Flag.equals("Yes")){
				AccountPage.mouseOverandElementClick(getDriver(), checkbox);
			}
		}
		
		public void click_Save_Btn(WebElementFacade SaveBtn,String waitelEmentXpath,WebElementFacade OKBtn){
			AccountPage.mouseOverandElementClick(getDriver(), SaveBtn);
			AccountPage.waitForVisibilityOfeRAMElementsforlesstime(getDriver(),waitelEmentXpath);
			waitFor(5000).milliseconds();
			if(OKBtn.isVisible()){
				OKBtn.click();
				waitFor(1000).milliseconds();
			}
		}
		public void enter_rule_Name(String RuleName){
			enter_input_Name(filterRuleNameteXtField,RuleName);
		}
		
		public void filter_rule_Input_Criteria(String DatabaseField, String Operator , String SQLExpression){
			rule_Input_Criteria(filterRuleDataBaseFitledList, filterRuleOperatorList, addToCriteriaBtn, sqlRadioBtn, filterRuleTextArea, descriptionRadioBtn,DatabaseField, Operator ,SQLExpression);
		}
		
		public void filter_Reule_Cal_CheckBox(String Flag){
			select_Calculated_CheckBox(filterRuleCalculatedCheckbox,Flag);
		}
		public void filter_Rule_Save_btn(){
			click_Save_Btn(filterRuleSavebtn,filterTableXpath,cLTruleExpOKBtn);
		}
		
		public String verify_Created_Items(List<WebElement> element, String ItemName){
			
			String itemNametext="";
			for (WebElement trElement : element) {				
				AccountPage.mouseOveranElement(getDriver(), trElement);
				waitFor(100).milliseconds();
				if(trElement.getText().trim().equals(ItemName)){
					log.log(Level.INFO,"Element created  --------------------- "+trElement.getText().trim());
					AccountPage.highlightElement(getDriver(), trElement);
					itemNametext=trElement.getText().trim();
					break;
				}
			}
			return itemNametext;
			
		}
		
		public String verify_Filter_has_Created(String FilterName){
			return verify_Created_Items(filterNaemList, FilterName);
		}
		
		public void click_Any_new_or_Yes_Btn(String ButtonName){
			String btnXpath="//span[contains(@id,'btnInnerEl') and contains(.,'"+ButtonName+"')]";
			WebElementFacade btnElement=find(By.xpath(btnXpath));
			btnElement.isVisible();
			btnElement.click();
			waitFor(3000).milliseconds();
		}
		
		public void select_Process_Type(String ProcessType, String AccountOption){
			accountPageObject.select_An_Option_From_List(boundListButton, ProcessType);
			waitFor(1000).milliseconds();
			String filterOptionXpath="//label[contains(@id,'radio') and contains(@id,'boxLabelEl') and contains(.,'"+AccountOption+"')]";
			WebElementFacade filterOptionElement=find(By.xpath(filterOptionXpath));
			AccountPage.mouseOverandElementClick(getDriver(), filterOptionElement);
		}
		
		public void click_Schedule_Btn(){
			scheduleBtn.isVisible();
			AccountPage.mouseOverandElementClick(getDriver(), scheduleBtn);
			waitFor(200).milliseconds();
			click_Any_new_or_Yes_Btn("Yes");
			waitFor(10000).milliseconds();
		}
		
	
		public String verify_Process_Status(){
			String userid="";
			String Status="";
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
	        Date date = new Date();
	        String date2= dateFormat.format(date);
			String loginid= System.getProperty("appUserName");
			AccountPage.mouseOverAndHighlightanElement(getDriver(), tableheader);
			waitFor(20000).milliseconds();
			String rowxpathUserid="//*[contains(@class,'x-panel-header x-header') and contains(.,'Completed Process Status')]//following-sibling::div[contains(@id,'panel') and contains(@id,'body')]//table[1]/tbody/tr/td[4]/div";
			String rowxpathScheduleTime="//*[contains(@class,'x-panel-header x-header') and contains(.,'Completed Process Status')]//following-sibling::div[contains(@id,'panel') and contains(@id,'body')]//table[1]/tbody/tr/td[5]/div";
			String rowxpathStatus="//*[contains(@class,'x-panel-header x-header') and contains(.,'Completed Process Status')]//following-sibling::div[contains(@id,'panel') and contains(@id,'body')]//table[1]/tbody/tr/td[8]/div";
			WebElement rowElement=getDriver().findElement(By.xpath(rowxpathUserid));
			List <WebElement> rowElementUseridList=getDriver().findElements(By.xpath("//*[contains(@class,'x-panel-header x-header') and contains(.,'Completed Process Status')]//following-sibling::div[contains(@id,'panel') and contains(@id,'body')]//table/tbody/tr/td[4]/div"));
			WebElement rowElementScheduleTime=getDriver().findElement(By.xpath(rowxpathScheduleTime));
			for(int j=0;j<3;j++){
				if(rowElement.isDisplayed()){
					for(WebElement userName :rowElementUseridList ){
						userid=userName.getText().trim();
						AccountPage.mouseOveranElement(getDriver(), userName);
						waitFor(2000).milliseconds();
						if(loginid.equals(userid)){
							log.log(Level.INFO,"user id name  --------------------- "+userid);
							String scheduleTime=rowElementScheduleTime.getText().trim();
							log.log(Level.INFO,"Schedule Time  --------------------- "+scheduleTime);
							log.log(Level.INFO,"current date  --------------------- "+date2);
							if(scheduleTime.contains(date2)){
								WebElement StatusrowElement=userName.findElement(By.xpath("//preceding-sibling::table/tbody/tr/td[8]/div"));
								for(int i=0;i<3;i++){
									if(StatusrowElement.isDisplayed()){
										Status=StatusrowElement.getText().trim();
										if(Status.equals("Completed")){
											AccountPage.mouseOverAndHighlightanElement(getDriver(), StatusrowElement);
											waitFor(1000).milliseconds();
											log.log(Level.INFO,"Status  --------------------- "+Status);
											break;
										}
										waitFor(1000).milliseconds();
									}
								}
								break;
							}
							
						}
					}
					
				break;	
			}
		}
			
/*			if(loginid.equals(userid)){
				WebElement StatusrowElement=getDriver().findElement(By.xpath(rowxpathStatus));
				for(int i=0;i<3;i++){
					if(StatusrowElement.isDisplayed()){
						Status=StatusrowElement.getText().trim();
						if(Status.equals("Completed")){
							log.log(Level.INFO,"Status  --------------------- "+Status);
							break;
						}
						waitFor(1000).milliseconds();
					}
				}
			}*/
			
			return Status;
		}
		
		public String verify_Rule_Under_CreditAnalysis_Tab(){
			waitFor(1000).milliseconds();
			rulesAppliedElement.isVisible();
			AccountPage.mouseOverAndHighlightanElement(getDriver(), rulesAppliedElement);
			String ruletext=rulesAppliedElement.getText().replace("(", "").replace(")", "").trim();
			return ruletext;
		}
		
		public void select_Calculated_CheckBox_For_All(String Flag){
			if(Flag.equals("Yes")){
				String checkboxXpath="//label[contains(@id,'boxLabelEl') and contains(.,'Calculate the Number Of Accounts Affected')]";
				WebElement checkboxElement=getDriver().findElement(By.xpath(checkboxXpath));
				AccountPage.mouseOverandElementClick(getDriver(), checkboxElement);
			}
		}
		
		public void click_Collection_Policy_New_Btn(){
			click_Some_New_Btns(collectionsPoliciesNewBtn);
		}
		
		public void click_Collection_ActionsNew_Btn(){
			click_Some_New_Btns(collectionsActionsNewBtn);
		}
		public void click_Some_New_Btns(WebElementFacade element){
			waitFor(1000).milliseconds();
			element.isVisible();
			AccountPage.mouseOverandElementClick(getDriver(), element);
			waitFor(4000).milliseconds();
		}
				
		public boolean delete_Existing_CollectionPolicy_Rule(String Name){
			String OptionNameListXpath="//*[@id='treepanId-body']//table/tbody/tr/td/div/span";
			String deleteBtnXpath="//*[@id='collectionpoliciesid-innerCt']//span[@id='CoLP_btn_2-btnInnerEl']";
			List <WebElement> OptionNameListElement=getDriver().findElements(By.xpath(OptionNameListXpath));
			WebElement deleteBtnElement=getDriver().findElement(By.xpath(deleteBtnXpath));
			return delete_Existing_Items(OptionNameListElement, Name, deleteBtnElement);
		}	
		
	 	public boolean verify_Collection_Policy_Rule_Has_Created(String PolicyName){
	 		try{
				String RuleNameXpath="//*[@id='treepanId-body']//table/tbody//tr//td//div//span[contains(.,'"+PolicyName+"')]";
	 			WebElementFacade ruleNameElement=find(By.xpath(RuleNameXpath));
	 			AccountPage.mouseOverAndHighlightanElement(getDriver(), ruleNameElement);
	 			waitFor(500).milliseconds();
	 			return true;
	 		}catch(Exception e){
	 			return false;
	 		}
	 		
	 	}
	 	
		public void collection_Policy_Rule_Save_btn(){
			click_Save_Btn(ruleSaveBtn,collectionPolicyTableXpath,cLTruleExpOKBtn);
		}
		public void enter_rule_Name_For_All(String RuleName){
			String RuleDescriptionXpath="//label[contains(@id,'labelEl') and contains(.,'Rule Description')]//following-sibling::div[1]//input[@type='text' and contains(@id,'inputEl')]";
 			WebElementFacade ruleDescriptionElement=find(By.xpath(RuleDescriptionXpath));
 			enter_input_Name(ruleDescriptionElement,RuleName);
		}
		
		public void All_rules_Input_Criteria(String DatabaseField, String Operator , String SQLExpression){
			String DataBaseFieldXpath="//label[contains(@id,'labelEl') and contains(.,'Database Fields:')]//following-sibling::div//div[contains(@id,'Combo-trigger-picker') and contains(@class,'arrow-trigger')]";
 			String OperatorXpath="//label[contains(@id,'labelEl') and contains(.,'Operators:')]//following-sibling::div//div[contains(@id,'Combo-trigger-picker') and contains(@class,'arrow-trigger')]";
 			String TextAreaXpath="//label[contains(@id,'labelEl') and contains(.,'Criteria:')]//following-sibling::div//textarea[contains(@id,'criteriaId-inputEl') and @role='textbox']";
 			WebElementFacade dataBaseFieldElement=find(By.xpath(DataBaseFieldXpath));
 			WebElementFacade operatorElement=find(By.xpath(OperatorXpath));
 			WebElementFacade textAreaElement=find(By.xpath(TextAreaXpath));
 			rule_Input_Criteria(dataBaseFieldElement, operatorElement, addToCriteriaBtn, sqlRadioBtn, textAreaElement, descriptionRadioBtn,DatabaseField, Operator ,SQLExpression);
		}
		
		public boolean delete_Existing_CollectionPolicy_Action(String Name){
			String OptionNameListXpath="//*[@id='coll_poli_view']//table/tbody/tr/td";
			String deleteBtnXpath="//*[@id='CoLP_btn_5']//span[@id='CoLP_btn_5-btnInnerEl']";
			List <WebElement> OptionNameListElement=getDriver().findElements(By.xpath(OptionNameListXpath));
			WebElement deleteBtnElement=getDriver().findElement(By.xpath(deleteBtnXpath));
			return delete_Existing_Items(OptionNameListElement, Name, deleteBtnElement);
		}
		
		public void enter_Collection_Action_Name(String ActionName){
			AccountPage.mouseOverAndHighlightanElement(getDriver(), actionTextField);
			actionTextField.type(ActionName);
			waitFor(500).milliseconds();
			AccountPage.mouseOverandElementClick(getDriver(), filterPopupOKBtn);
			waitFor(2000).milliseconds();
			log.log(Level.INFO,"Collection Action Name --------------------- "+ActionName);
		}
		
	 	public boolean verify_Collection_Action_Has_Created(String ActionName){
	 		try{
				String ActionNameXpath="//*[@id='coll_poli_view']//table/tbody/tr/td[contains(.,'"+ActionName+"')]";
	 			WebElementFacade actionNameElement=find(By.xpath(ActionNameXpath));
	 			AccountPage.mouseOverAndHighlightanElement(getDriver(), actionNameElement);
	 			waitFor(500).milliseconds();
	 			return true;
	 		}catch(Exception e){
	 			return false;
	 		}
	 	}
	 	
		public void select_CollectionPolicy_Rule_For_Link(String Name){
			log.log(Level.INFO,"Collection Policy Rule to select for link --------------------- "+Name);
 			String RuleNameXpath="//*[@id='treepanId-body']//table/tbody//tr//td//div//span[contains(.,'"+Name+"')]";
 			WebElementFacade ruleNameElement=find(By.xpath(RuleNameXpath));
 			AccountPage.mouseOverandElementClick(getDriver(), ruleNameElement);
 		}
		public void select_CollectionPolicy_Action_For_Link(String Name){
			log.log(Level.INFO,"Collection Action to select for link --------------------- "+Name);
 			String RuleNameXpath="//*[@id='coll_poli_view']//table/tbody/tr/td[contains(.,'"+Name+"')]";
 			WebElementFacade ruleNameElement=find(By.xpath(RuleNameXpath));
 			AccountPage.mouseOverandElementClick(getDriver(), ruleNameElement);
 		}
		
		public boolean delete_Existing_ExceptionPolicy_Rule(String Name){
			String OptionNameListXpath="//*[@id='exceptnGridId-body']//table/tbody/tr/td/div";
			String deleteBtnXpath="//*[@id='expDelBtnId']";
			List <WebElement> OptionNameListElement=getDriver().findElements(By.xpath(OptionNameListXpath));
			WebElement deleteBtnElement=getDriver().findElement(By.xpath(deleteBtnXpath));
			return delete_Existing_Items(OptionNameListElement, Name, deleteBtnElement);
		}	
		
		public void Rule_Save_btn(){
			AccountPage.mouseOverandElementClick(getDriver(), ruleSaveBtn);
			waitFor(5000).milliseconds();
			if(cLTruleExpOKBtn.isVisible()){
				cLTruleExpOKBtn.click();
				waitFor(1000).milliseconds();
			}
		}
		
	 	public boolean verify_Exception_Policy_Rule_Has_Created(String PolicyRuleName){
	 		try{
				String RuleNameXpath="//*[@id='exceptnGridId-body']//table/tbody/tr/td/div[contains(.,'"+PolicyRuleName+"')]";
	 			WebElementFacade ruleNameElement=find(By.xpath(RuleNameXpath));
	 			AccountPage.mouseOverAndHighlightanElement(getDriver(), ruleNameElement);
	 			waitFor(500).milliseconds();
	 			return true;
	 		}catch(Exception e){
	 			return false;
	 		}
	 		
	 	}
	 	
	 	public void enter_Score_Over_Override_Value(String ScoreValue){
	 		AccountPage.mouseOverandElementClick(getDriver(), scoreOverrideValueCheckBox);
			waitFor(500).milliseconds();
			scoreOverrideValueInputBox.sendKeys(ScoreValue);
			waitFor(500).milliseconds();
	 	}
	 	
	 	public void select_Exception_Status(String Status, String Message){
	 		String StatusXpath="//label[contains(@id,'boxLabelEl') and contains(.,'"+Status+"')]";
 			WebElementFacade statusElement=find(By.xpath(StatusXpath));
 			AccountPage.mouseOverandElementClick(getDriver(), statusElement);
 			waitFor(500).milliseconds();
 			analysisMessageTextBox.type(Message);
 			waitFor(500).milliseconds();
	 	}
	 	
		public void enter_Exception_rule_Name(String RuleName){
			enter_input_Name(exceptionPolicyRuleDesc,RuleName);
		}
		public void Rule_Save_btn1(){
			AccountPage.mouseOverandElementClick(getDriver(), ruleSaveBtn1);
			waitFor(5000).milliseconds();
			if(cLTruleExpOKBtn.isVisible()){
				cLTruleExpOKBtn.click();
				waitFor(1000).milliseconds();
			}
		}
	 	public String verify_Exception_Policy_Analysis_Message(String PolicyRuleName){
	 		
				String MessageXpath="//*[@id='exceptnGridId-body']//table/tbody/tr/td[contains(.,'"+PolicyRuleName+"')]//following-sibling::td[3]/div";
	 			WebElementFacade messageElement=find(By.xpath(MessageXpath));
	 			AccountPage.mouseOverAndHighlightanElement(getDriver(), messageElement);
	 			waitFor(500).milliseconds();
	 			log.log(Level.INFO,"Exception Policy Analysis Message----------------------- "+ messageElement.getText());
	 			return messageElement.getText().toString().trim();
	 	}
	 	
		public void click_STP_ActionsNew_Btn(){
			click_Some_New_Btns(sTPAccountTypeNewBtn);
		}
		
		public boolean delete_Existing_STP_Account_Type(String Name){
			String OptionNameListXpath="//*[@id='treepanId']//table/tbody/tr/td/div";
			String deleteBtnXpath="//*[@id='SeLP_btn_2']//span[@id='SeLP_btn_2-btnInnerEl']";
			List <WebElement> OptionNameListElement=getDriver().findElements(By.xpath(OptionNameListXpath));
			WebElement deleteBtnElement=getDriver().findElement(By.xpath(deleteBtnXpath));
			return delete_Existing_Items(OptionNameListElement, Name, deleteBtnElement);
		}
		
		
		public void enter_STP_Account_TypeName(String Name){
			AccountPage.mouseOverAndHighlightanElement(getDriver(), actionTextField);
			actionTextField.type(Name);
			waitFor(500).milliseconds();
			AccountPage.mouseOverandElementClick(getDriver(), filterPopupOKBtn);
			waitFor(2000).milliseconds();
			log.log(Level.INFO,"STP_Account_Type Name --------------------- "+Name);
		}
		
	 	public String verify_STP_Account_Type_Has_Created(String Name){

				String NameXpath="//*[@id='treepanId']//table/tbody/tr/td/div/span";
	 			List <WebElement> NameElement=getDriver().findElements(By.xpath(NameXpath));
	 			return verify_Created_Items(NameElement, Name);
	 		
	 	}
	 	
		public boolean delete_Existing_STerms(String Name){
			String OptionNameListXpath="//*[contains(@id,'panel') and contains(@id,'header') and contains(.,'Available Selling Terms')]//following-sibling::div[1][contains(@id,'panel') and contains(@id,'body')]//table/tbody/tr/td";
			String deleteBtnXpath="//*[@id='SeLP_btn_5']//span[@id='SeLP_btn_5-btnInnerEl']";
			List <WebElement> OptionNameListElement=getDriver().findElements(By.xpath(OptionNameListXpath));
			WebElement deleteBtnElement=getDriver().findElement(By.xpath(deleteBtnXpath));
			return delete_Existing_Items(OptionNameListElement, Name, deleteBtnElement);
			
			
		}
		public void click_STerms_New_Btn(){
			click_Some_New_Btns(sTermsNewBtn);
		}
		
		
		public void enter_STerms_Name(String Name){
			AccountPage.mouseOverAndHighlightanElement(getDriver(), actionTextField);
			actionTextField.type(Name);
			waitFor(500).milliseconds();
			AccountPage.mouseOverandElementClick(getDriver(), filterPopupOKBtn);
			waitFor(2000).milliseconds();
			log.log(Level.INFO,"Selling Terms Name --------------------- "+Name);
		}
	 	public String verify_STerms__Has_Created(String Name){

			String NameXpath="//*[contains(@id,'panel') and contains(@id,'header') and contains(.,'Available Selling Terms')]//following-sibling::div[1][contains(@id,'panel') and contains(@id,'body')]//table/tbody/tr/td";
 			List <WebElement> NameElement=getDriver().findElements(By.xpath(NameXpath));
 			return verify_Created_Items(NameElement, Name);
 		
 	}
		public void select_STP_Account_Type_For_Link(String Name){
			log.log(Level.INFO,"Collection Policy Rule to select for link --------------------- "+Name);
 			String NameXpath="//*[@id='treepanId']//table/tbody/tr/td/div/span[contains(.,'"+Name+"')]";
 			WebElementFacade NameElement=find(By.xpath(NameXpath));
 			AccountPage.mouseOverandElementClick(getDriver(), NameElement);
 		}
		
		public void select_STerms_For_Link(String Name){
			log.log(Level.INFO,"Collection Policy Rule to select for link --------------------- "+Name);
 			String NameXpath="//*[contains(@id,'panel') and contains(@id,'header') and contains(.,'Available Selling Terms')]//following-sibling::div[1][contains(@id,'panel') and contains(@id,'body')]//table/tbody/tr/td[contains(.,'"+Name+"')]";
 			WebElementFacade NameElement=find(By.xpath(NameXpath));
 			AccountPage.mouseOverandElementClick(getDriver(), NameElement);
 		}
		
		public boolean delete_Existing_Score_Policy(String Name){
			String OptionNameListXpath="//*[@id='scrGridId-body']//table/tbody/tr/td[1]/div";
			String deleteBtnXpath="//*[@id='scrDelBtnId']//span[@id='scrDelBtnId-btnInnerEl']";
			List <WebElement> OptionNameListElement=getDriver().findElements(By.xpath(OptionNameListXpath));
			WebElement deleteBtnElement=getDriver().findElement(By.xpath(deleteBtnXpath));
			return delete_Existing_Items(OptionNameListElement, Name, deleteBtnElement);
		}
		public void enter_Model_Name(String ModelName){
			AccountPage.mouseOverAndHighlightanElement(getDriver(), modelNameTextField);
			modelNameTextField.type(ModelName);
		}
		
		public void click_Rule_SQL_Edit_Btn(){
			ruleSQLFormEditBtn.click();
			waitFor(2000).milliseconds();
		}
		
		public void click_policyComponent_Edit_Btn(){
			policyComponentEditBtn.click();
			waitFor(2000).milliseconds();
			if(componentsBtn1.isCurrentlyVisible()){
				
			}else{
				policyComponentEditBtn.click();
				waitFor(2000).milliseconds();
			}
		}
		
		public void select_Components_For_Score_Policy(String ItemName){
			
			if(ItemName.contains(",")){
				String[] itemname1=ItemName.split(",");
				for(String itemname2 : itemname1){
					String[] itemname3=itemname2.split(":");
					select_component(itemname3[0], itemname3[1]);
				}
			}else{
				String[] itemname4=ItemName.split(":");
				select_component(itemname4[0], itemname4[1]);
			}
		}
		
		public void select_component(String ComponentName, String ComponentValue){
			String OptionNameListXpath="//*[@id='componentid-body']//table/tbody/tr/td[2]/div";
			List <WebElement> OptionNameListElement=getDriver().findElements(By.xpath(OptionNameListXpath));
			int i=0;
			componenetcount=OptionNameListElement.size();
			log.log(Level.INFO,"Element List Size =========================== "+componenetcount);
			for (WebElement trElement : OptionNameListElement) {				
				AccountPage.mouseOveranElement(getDriver(), trElement);
				waitFor(100).milliseconds();
			//	log.log(Level.INFO,"Elements in list  --------------------- itemNo= "+i+" "+trElement.getText().trim());
				if(ComponentName.equals(trElement.getText().trim())){
					log.log(Level.INFO,"Element need to select =========================== itemNo= "+i+" "+trElement.getText().trim());
					AccountPage.mouseOverAndHighlightanElement(getDriver(), trElement);
					waitFor(500).milliseconds();
					WebElement checkboxElement=getDriver().findElement(By.xpath("//*[@id='componentid-body']//table/tbody/tr/td[2][.='"+ComponentName+"']//preceding-sibling::td[1][contains(@data-columnid,'checkcolumn')]/div"));
					AccountPage.mouseOverandElementClick(getDriver(), checkboxElement);
					waitFor(1000).milliseconds();
					AccountPage.mouseOverandElementClick(getDriver(), creditLimitWeightTextBox);
					creditLimitWeightTextBox.type(ComponentValue);
					waitFor(500).milliseconds();
					break;
				}
				i++;
				
			}
		}
		
		public void component_Save_btn(){
			save_btn_For_All(componentsBtn1);
		}
		
		public void perfrom_Save_Action_For_All(){
			save_btn_For_All(saveButtonForAll);
		}
		
		
		public void save_btn_For_All(WebElement element){
			AccountPage.mouseOverandElementClick(getDriver(), element);
			waitFor(5000).milliseconds();
			if(cLTruleExpOKBtn.isVisible()){
				cLTruleExpOKBtn.click();
				waitFor(2000).milliseconds();
			}
		}
		
		public void save_btn_For_Set_Prioriy(){
			save_btn_For_All(saveSCRSaveBtn);
		}
		
		
		
	 	public String verify_Score_Policy_Has_Created(String Name){

				String NameXpath="//*[@id='scrGridId-body']//table/tbody/tr/td[1]/div";
	 			List <WebElement> NameElement=getDriver().findElements(By.xpath(NameXpath));
	 			return verify_Created_Items(NameElement, Name);
	 		
	 	}
	 	
		public void set_Priority_For_Score_Policy(String Name){
			String priorityXpath="//*[@id='scrGridId-body']//table/tbody/tr/td[.='"+Name+"']//following-sibling::td[1]//input[contains(@id,'textfield') and contains(@id,'inputEl')]";
			String priorityXpath1="//*[@id='scrGridId-body']//table[1]/tbody/tr/td[2]//input[contains(@id,'textfield') and contains(@id,'inputEl')]";
			String priorityText="";
			WebElementFacade priorityNameElement=find(By.xpath(priorityXpath));
			AccountPage.mouseOverAndHighlightanElement(getDriver(), priorityNameElement);
			waitFor(500).milliseconds();
			priorityText=priorityNameElement.getAttribute("value").trim();
			log.log(Level.INFO,"Score Rule =========================== "+Name+" Priority Value= "+priorityText);
			if(!priorityText.equals("1")){
				priorityNameElement.type("1");
				waitFor(500).milliseconds();
				WebElementFacade priorityNameElement1=find(By.xpath(priorityXpath1));
				AccountPage.mouseOverAndHighlightanElement(getDriver(), priorityNameElement1);
				waitFor(500).milliseconds();
				priorityNameElement1.type(priorityText);
			}
		}
		
		public void edit_Score_Policy(String Name){
			String priorityXpath="//*[@id='scrGridId-body']//table/tbody/tr/td/div[.='"+Name+"']";
			WebElementFacade priorityNameElement=find(By.xpath(priorityXpath));
			AccountPage.mouseOverAndHighlightanElement(getDriver(), priorityNameElement);
			waitFor(500).milliseconds();
			AccountPage.mouseOverandElementdoubleClick(getDriver(), priorityNameElement);
			waitFor(2000).milliseconds();
			
		}
		
		public void update_Components_For_Score_Policy(String ItemName){
			
			if(ItemName.contains(",")){
				String[] itemname1=ItemName.split(",");
				for(String itemname2 : itemname1){
					edit_component_For_Score_Policy(itemname2);
				}
			}else{
				
				edit_component_For_Score_Policy(ItemName);
			}
		}
		public void edit_component_For_Score_Policy(String ComponentName){
			String OptionNameListXpath="//*[@id='componentid-body']//table/tbody/tr/td[2]/div";
			List <WebElement> OptionNameListElement=getDriver().findElements(By.xpath(OptionNameListXpath));
			int i=0;
			componenetcount=OptionNameListElement.size();
			log.log(Level.INFO,"Edit Element List Size =========================== "+componenetcount);
			for (WebElement trElement : OptionNameListElement) {				
				AccountPage.mouseOveranElement(getDriver(), trElement);
				waitFor(100).milliseconds();
				if(ComponentName.equals(trElement.getText().trim())){
					log.log(Level.INFO,"Element need to Edit =========================== itemNo= "+i+" "+trElement.getText().trim());
					AccountPage.mouseOverAndHighlightanElement(getDriver(), trElement);
					AccountPage.mouseOverandElementClick(getDriver(), trElement);
					waitFor(500).milliseconds();
					AccountPage.mouseOverandElementClick(getDriver(), creditLimitWeightTextBox);
					creditLimitWeightTextBox.clear();
					waitFor(500).milliseconds();
					WebElement checkboxElement=getDriver().findElement(By.xpath("//*[@id='componentid-body']//table/tbody/tr/td[2][.='"+ComponentName+"']//preceding-sibling::td[1][contains(@data-columnid,'checkcolumn')]/div"));
					AccountPage.mouseOverandElementClick(getDriver(), checkboxElement);
					waitFor(1000).milliseconds();
					break;
				}
				i++;
				
			}
		}
		
		public void enter_Custom_Field_Label_Name(String LabelName){
			AccountPage.mouseOverAndHighlightanElement(getDriver(), customFieldLabelNameTextField);
			customFieldLabelNameTextField.type(LabelName);
		}
		
		public void select_Option_From_Combo_Field_Type(String FieldName,String Value){
			String FieldNameXpath="//label[contains(@id,'combo') and contains(.,'"+FieldName+"')]//following-sibling::div[contains(@id,'combo')]//*[contains(@id,'combo') and contains(@id,'trigger-picker')]";
			WebElementFacade fieldNmeElement=find(By.xpath(FieldNameXpath));
			accountPageObject.select_An_Option_From_List(fieldNmeElement,Value);
			
		}
		
		public void select_Cusotm_Filed_Type(String FieldType){
			String FieldNameXpath="//label[contains(@id,'radio') and contains(.,'"+FieldType+"')]";
			WebElementFacade fieldNmeElement=find(By.xpath(FieldNameXpath));
			AccountPage.mouseOverandElementClick(getDriver(), fieldNmeElement);
			waitFor(1000).milliseconds();
		}
		
		public void select_Cusotm_Filed_Component_And_Composite(String ComponentName,String LookupName ,String CompositeFlag){
			String FieldNameXpath="//label[contains(@id,'radio') and contains(.,'"+ComponentName+"')]";
			WebElementFacade fieldNmeElement=find(By.xpath(FieldNameXpath));
			AccountPage.mouseOverandElementClick(getDriver(), fieldNmeElement);
			waitFor(1000).milliseconds();
			if(ComponentName.equals("Factor")){
				customFieldComponentTextField.type("0.000001");
			}
			if(ComponentName.equals("Lookup")){
				AccountPage.mouseOverandElementClick(getDriver(), attachLookupBtn);
				waitFor(7000).milliseconds();
				String OptionNameListXpath="//*[contains(@id,'attachlookup')]//table/tbody/tr/td/div";
				List <WebElement> OptionNameListElement=getDriver().findElements(By.xpath(OptionNameListXpath));
				int i=0;
				log.log(Level.INFO,"Lookup List Size =========================== "+OptionNameListElement.size());
				for (WebElement trElement : OptionNameListElement) {				
					AccountPage.mouseOveranElement(getDriver(), trElement);
					waitFor(200).milliseconds();
					if(LookupName.equals(trElement.getText().trim())){
						log.log(Level.INFO,"Element need to Edit =========================== itemNo= "+i+" "+trElement.getText().trim());
						AccountPage.mouseOverandElementdoubleClick(getDriver(), trElement);
						waitFor(7000).milliseconds();
						break;
					}
					i++;
				}
			}
			if(CompositeFlag.equals("Yes")){
				AccountPage.mouseOverandElementClick(getDriver(), customFieldCompositeCheckbox);
				waitFor(500).milliseconds();
			}
		}
		
		public void new_CustomField_Save_btn(){
			AccountPage.mouseOverandElementClick(getDriver(), newCustromFieldSaveBtn);
			waitFor(5000).milliseconds();
			if(messageBoxtext.isVisible()){
				cLTruleExpOKBtn.click();
				waitFor(2000).milliseconds();
				newCustromFieldCancelBtn.click();
			}else if(cLTruleExpOKBtn.isVisible()){
				cLTruleExpOKBtn.click();
				waitFor(2000).milliseconds();
			}
			
			waitFor(5000).milliseconds();
		}
		
		public void click_Lookup_New_Btn(){
			lookupNewBtn.click();
			waitFor(2000).milliseconds();
		}
		public void enter_Looup_Table_Name(String TabelName){
			AccountPage.mouseOverAndHighlightanElement(getDriver(), lookupTableNameTestField);
			lookupTableNameTestField.type(TabelName);
		}
		
		public void select_Lookup_Table_Type(String TableType){
			String FieldNameXpath="//label[contains(@id,'boxLabelEl') and contains(.,'"+TableType+"')]";
			WebElementFacade fieldNmeElement=find(By.xpath(FieldNameXpath));
			AccountPage.mouseOverandElementClick(getDriver(), fieldNmeElement);
			waitFor(1000).milliseconds();
		}
		public void enter_The_Values_For_LookUp_Table(String Description, String Value, String Backup){
			AccountPage.mouseOverandElementClick(getDriver(), lookupTableDescription);
			waitFor(100).milliseconds();
			lookupTableDescription1.type(Description);
			waitFor(100).milliseconds();
			AccountPage.mouseOverandElementClick(getDriver(), lookupTableValue);
			waitFor(100).milliseconds();
			lookupTableValue1.type(Value);
			waitFor(100).milliseconds();
			AccountPage.mouseOverandElementClick(getDriver(), lookupTableNameBackup);
			waitFor(100).milliseconds();
			lookupTableNameBackup1.type(Backup);
			waitFor(100).milliseconds();
		}
		
		public void perfrom_Save_For_Lookup_Table(){
			save_btn_For_All(lookupTableSaveBtn);
		}
		
		public String verify_Sored_On_Date(){
			AccountPage.mouseOverAndHighlightanElement(getDriver(), ramScoreDate);
			String rdate=ramScoreDate.getText().trim();
			log.log(Level.INFO,"Scored on Date =========================== "+rdate);
	        return rdate;
		}
		public String verify_Model(){
			String rmodel=ramScoreModel.getText().trim();
			log.log(Level.INFO,"Ram Score Model =========================== "+rmodel);
	        return rmodel;
		}
		
		public void select_Statements_Available_Field(){
			AccountPage.mouseOverandElementClick(getDriver(), statementAvailableList);
			waitFor(100).milliseconds();
			AccountPage.mouseOverandElementClick(getDriver(), selectionPolicesAddBtn);
			waitFor(100).milliseconds();
			
		}
		
		public void enterValues_For_Statements_Older_Than_Monts(){
			AccountPage.mouseOverAndHighlightanElement(getDriver(), statementsOlderThanMonthTextBox);
			waitFor(100).milliseconds();
			statementsOlderThanMonthTextBox.clear();
			statementsOlderThanMonthTextBox.sendKeys("2");
			waitFor(100).milliseconds();
			
		}
		

		
		

}