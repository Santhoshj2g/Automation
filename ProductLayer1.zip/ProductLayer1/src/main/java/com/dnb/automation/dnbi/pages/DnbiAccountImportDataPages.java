package com.dnb.automation.dnbi.pages;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;
import com.google.common.base.Predicate;
import com.dnb.automation.dnbi.pages.ECFPage;


public class DnbiAccountImportDataPages extends PageObject {
   
	@FindBy(xpath = "//div[@class='primaryNav_div']//ul[@id='primaryNav']//li/a[contains(text(),'Admin')]")
    private WebElementFacade AdminTab;
	
	@FindBy(xpath = "//div[@id='main']/div[@class='pm_head_title']/span[contains(text(),'Account Manager')]")
	private WebElementFacade AccountManagerPageTitle;
	
	@FindBy(xpath = "//div[@id='page_title']/h2[contains(text(),'Account Manager Admin')]")
    private WebElementFacade AccountManagerAdminPageTitle;
	
	@FindBy(xpath = "//div[@id='main']//div[@class='widget ad_widget_portfolio']//table//tr//td[2]/b/a[contains(text(),'Import Account Data')]")
    private WebElementFacade importAccountDataTab;
	
	
	@FindBy(xpath = "//div[@id='page_title']/h2[contains(text(),'Import Account Data')]")
    private WebElementFacade ImportAccountDataPageTitle;
	
	@FindBy(xpath = "//div[@id='header_mainApp']//li[contains(.,'Account')]")
    private WebElementFacade accManagerTab;
	
//	@FindBy(xpath = "//div[@id='main']//div//ul//li/a[contains(text(),'Account Manager Admin')]")
	@FindBy(xpath = "//div[@class='primaryNav_div']/ul[@id='primaryNav']//a[contains(text(),'Account Manager')]")
	  private WebElementFacade AccountManagerTab;
	
	@FindBy(xpath = "//div[@id='main']/div[@ class='ecf_toc']/ul//li/a[contains(text(),'Account Manager Admin')]")
	 private WebElementFacade AccountManagerAdminTab;
	
	@FindBy(xpath = "//*[@id='edit-options']//input[@value='Create Custom Field']")
	private WebElementFacade CreateNewFieldButton;
	
	@FindBy(xpath = "//input[starts-with(@id,'field')]")
	private List<WebElementFacade> dnbiColCollection;
	
	
	@FindBy(xpath = "//div[@id='adminDivId']//input[@name='DisplayText']")
	private WebElementFacade DisplayText;
	
	@FindBy(xpath = "//div[@id='adminDivId']/table[@id='labellist_table']//td/select[@name='DataType']")
	private WebElementFacade DataType;
	
	@FindBy(xpath = "//div[@id='addField']//input[@value='Save']")
	private WebElementFacade savebutton;
	
    @FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
    private WebElementFacade iFrameEle;

	
	@FindBy(xpath = "//div[@class='modal_inner_content']//div[@class='cat2tablewrap']/table/tbody/tr")
	private List<WebElementFacade> editTableColCollection;
	
	
	@FindBy(xpath = "//div[@id='dataArea']//div[@ class='territory_block_pane']//input[@id='batchMatchFlag']")
	private WebElementFacade DunsMatchCheckbox;
	
	
	@FindBy(xpath = "//*[@id='main']//table//form/input[@value='no']")
	private WebElementFacade noCheckBox;
	
	@FindBy(xpath = ".//*[@id='main']//*[@id='backRight']/input[@type='button' and @value='Next >']")
    private WebElementFacade btnNextInImport;
	
	@FindBy(xpath = ".//*[@id='main']//*[@id='backRight']/input[@type='button'and @value='Cancel']")
    private WebElementFacade btnCancelInImport;
	
	@FindBy(xpath = "//div[@id='widget_container']//div[@class='frmSecEdit']//table//tr//td[@id='Acct-AccountNumber']/following-sibling::td[1]")
	 private WebElementFacade accNumber;
	
	@FindBy(xpath = "//div[@class='frmSecEdit']//div[@class='entcommon_reviewLeftTable']//td[@id='BizInfo-State']/following-sibling::td[1]")
    private WebElementFacade states;
	
	
	@FindBy(xpath = "//div[@id='compTitle']/h3[contains(text(),'Company Summary')]")
	private WebElementFacade CompanySummary;
	
	
	@FindBy(xpath = "//ul[@id='ecf_toc1']/li/a[contains(text(),'Audit Trail')]")
	private WebElementFacade AuditTrailTab;
	
	@FindBy(xpath = "//div[@id='widget_container']//div[@class='widget_ecfbox showExpAging']/h3[contains(text(),'Audit Trail')]")
	private WebElementFacade audittrailpage;
	
	//@FindBy(xpath = "//div[@id='aud_tab1']//table//tr[2]//td[4]") -- Below is the new Audi Trail Table content
	@FindBy(xpath = "//div[@id='aud_tab1']//table//tr//td[4]")
	private WebElementFacade Audittrailmessagetext;
	
	@FindBy (xpath ="//div[@id='mainFirst']//a[@id='textBtn']")
	private WebElementFacade TextWindow;
	
	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='quicksearch_more_options' and contains(text(),'Fewer')]")
    private WebElementFacade fewerOptionsEle;
    
    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='quicksearch_more_options' and contains(text(),'More')]")
    private WebElementFacade MoreOptionsEle;
	
  
    @FindBy(xpath = "//div[@class='ui-widget']/input[@id='quickSearchFld']")
    private WebElementFacade quickSearchFld;
	
	@FindBy(xpath = "//div[@id='agingArea']/div[@class='widget']/h3")
	private WebElementFacade agingRollUp;
	
	
	@FindBy(xpath = "//div[@id='search_box']//span[@id='search_fields_basic']//input[@value='Search']")
	private WebElementFacade searchbutton;
	
	@FindBy(xpath = "//div[@id='page_title']/h2[contains(text(),'Search Results')]")
	private WebElementFacade searchResults;
	
	//div[@id='main']//div/table[@class='results full']//tr/td[2]
	
	@FindBy(xpath = "//div[@id='main']//table[@class='results full']//tr/td[2]//a[@ class='navlinktable']")
	private WebElementFacade DunsNumbervalueMatch;
	
	
	@FindBy(xpath = "//div[@id='infoContainer']/ul[2]/li[1]")
	private WebElementFacade Accounttext;
	
	@FindBy(xpath = "//div[@id='infoContainer']/ul[2]/li[1]/following::li[1]")
	private WebElementFacade Accountvalue;
	
	
	@FindBy(xpath = "//div[@id='ecf_toc_main']/ul[@id='ecf_toc1']//li/a[contains(text(),'Aging')]")
	private WebElementFacade AgingTab;
	
	@FindBy(xpath = "//div[@id='agingList']/div[@class='widget_ecfbox showExpAging']/h3[contains(text(),'Aging')]")
	private WebElementFacade AgingPage;
	
	@FindBy(xpath = "//div[@id='tab1']//table[@class='results full tab_border']//tr/td/a[@class='navlinktable']")
	private WebElementFacade AgingDateLink;
	
	//@FindBy(xpath = "//div[@id='main']//table[@class='results externalBorder']//tr[2]/td[2]")
	//@FindBy(xpath = "//div[@id='main']//table[@class='results externalBorder']//tr[3]/td[2]")
	@FindBy(xpath = "//div[@id='main']//table[1]/tbody/tr/td/table[2]//tr[3]//td[2]")
	private WebElementFacade pastdue30;
	
	//@FindBy(xpath = "//div[@id='main']//table[@class='results externalBorder']//tr[3]/td[@class='rightAlign tabledark'][1]")
	//@FindBy(xpath="//div[@id='main']//table[@class='results externalBorder']//tr[4]//td[2]")
	@FindBy(xpath = "//div[@id='main']//table[1]/tbody/tr/td/table[2]//tr[4]//td[2]")
	private WebElementFacade pastdue60;
	
	@FindBy(xpath = "//div[@id='pageHead']/h2")
	private WebElementFacade importAccountinAging;
	
	@FindBy(xpath = "//div[@class='ad_borE8E8E8']//table[@class='results full']")
	private WebElementFacade resulttable;
	
	@FindBy(xpath = "//div[@id='main']//div[@id='pageHead']//div[@id='page_title']//h2[contains(text(),'Import Status Details')]")
	private WebElementFacade ImportStatuspage;
	
	@FindBy(xpath = "//div[@id='dol']/table[@class='tableborder']/tbody")
	private WebElementFacade agingResulttable;
	
	
	@FindBy(xpath = "//div[@id='agingArea']/div[@class='widget']/div[@class='clear']/table[@class='clear']/tbody/tr/td[1]")
	private WebElementFacade agingSummaryList;
	
	@FindBy(xpath ="//div[@id='agingArea']/div[@class='widget']/div[@class='clear']/table[@class='clear']/tbody/tr/td[2]")
	private WebElementFacade agingGraph;
	
	@FindBy(xpath = "//*[@id='agingArea']//table//tr//td[contains(text(),'1-30 Days Past Due')]")
	private WebElementFacade Aging30DaysPastDue;
	
	@FindBy(xpath = "//div[@id='agingArea']//table//tr//td[contains(text(),'91+ Days Past Due')]")
	private WebElementFacade Aging91DaysPastDue;
	
	
	@FindBy(xpath = "//div[@id='agingArea']//div[@class='clear']/table//input[@value='View Trend Summary']")
	private WebElementFacade trendSummaryButton;
	
	@FindBy(xpath = "//div[@id='dol']/table[@class='tableborder' ]//tr//td[contains(text(),'Total Outstanding')]")
	private WebElementFacade totaloutstanding;
	
	
	
	@FindBy(xpath = "//div[@id='agingArea']//div[@class='clear']/table//input[@value='View Trend Graph']")
	private WebElementFacade viewTrendGraphbutton;
	
	@FindBy(xpath = "//iframe[1]")
	private WebElementFacade viewAgingTrendGraphwindow;
	
	@FindBy(xpath = "//div[@id='exposureRollup']//div[@class='tools']/input[@value='View Corporate Exposure Report']")
	private WebElementFacade  ViewCorporateExposureReport;
	
	 @FindBy(xpath = "//div[@id='exposureRollup']//input[@value='Customize Report Columns']")
	 private WebElementFacade CustomizeReportColumns;
	

	 @FindBy(xpath = "//a[@id='add']/img")
	 private WebElementFacade addimgbutton;
	 
	 @FindBy(xpath = "//a[@id='remove']/img")
	 private WebElementFacade removeimgbutton;
	 
	 @FindBy(xpath = "//form[@id='customizeForm']//div[@class='modal_buttons']/input[@id='formSubmit']")
	 private WebElementFacade agingsubmitbutton;
	 
	 @FindBy(xpath = "//div[@id='main']//table[@class='results full tab_border']/thead//th/a")
	 private WebElementFacade tableheaders;
	 
	 
	 @FindBy(xpath = "//div[@class='ecfAcct_marginheight']//div[@id='vars']//select[@id='pool']")
	 private WebElementFacade selectEle;
	 
	 @FindBy(xpath = "//div[@ id='fields']//div[@id='seld']//select[@id='selectedFields']")
	 private WebElementFacade selectremove;
	
	 @FindBy(xpath = "//div[@class='widget_ecfbox showExpAging']//a[@id='expAgingData']/img/following::span[contains(text(),'Export')]")
	 private WebElementFacade exportlink;
	 
	 
	 @FindBy(xpath = "//div[@class='modal_title']/h3[contains(text(),'Downloading Export Data')]")
	 private WebElementFacade downloadPopUp;
	 
	 @FindBy(xpath = "//div[@id='loadingExport']//strong/a[contains(text(),'click here')]")
	 private WebElementFacade downloadClickHereLink;
	 @FindBy(xpath = "//*[@id='agingArea']//*[@class='clear']//input[@value='View Trend Summary']")
	 private WebElementFacade clickviewtrendbtn;
	
	 @FindBy(xpath = "//table[@id='importDataAuditTable']//tr//th/input[@value='Refresh' and @name='refresh']")
	 private WebElementFacade importaccountrefreshbutton;
	 @FindBy(xpath = "//div[@class='modal_inner_content']//div[@id='loadingPolling']/span[contains(text(),'Loading Data...')]")
	 private WebElementFacade loadingImg;
	 
	 @FindBy(xpath = "//div[@id='page_title']/h2[contains(text(),'View Import Log')]")
	 private WebElementFacade ViewImportLogPage;
	 @FindBy(xpath = "//*[@class='ageing_graphposition']//*[@id='per']//table[@class='tableborder']")
	 private WebElementFacade trendpercenttable;
	 @FindBy(xpath = "//div[@id='backRight']/input[@value='Next >']")
	 private WebElementFacade ImportLogNextButton;
	 @FindBy(xpath = "//*[@id='main']//*[@class='ageing_graphposition']//tbody//form[@name='agingTrendForm']//select")
	 private WebElementFacade viewtrendselectoption;
	 @FindBy(xpath = "//*[@id='page_title']/h2")
	 private WebElementFacade titletext;
	 @FindBy(xpath = "//*[@id='agingArea']//*[@class='results ']//td[normalize-space(text())='Total Outstanding']")
	 private WebElementFacade agingtablevariable;
	// MohanCode:
	 String agingpopupmain = "//*[@id='main']";
		 @FindBy(xpath="//*[@class='outerDiv']//*[@class='ad_borE8E8E8']//*[@class='results full']/tbody/tr[1]/td[1]/a")
		 private WebElement ImportMainStatus ;
		 
		 @FindBy(xpath="//*[@id='main']//*[@id='importDataAuditTable']/tbody/tr[1]/th[2]//*[@name='refresh']")
		 private WebElement RefreshBttn; 
		 
		 public static String parentWindowId;
		 
		 private String ImportMainStatusXpath="//*[@class='outerDiv']//*[@class='ad_borE8E8E8']//*[@class='results full']/tbody/tr[1]/td[1]/a";
	 
		 ECFPage ecfPage;
		
	 public static String  parentWindow;
//	 public static String  parentWindow1;
	 private int flagEditIterationForCustom = 0;
	 private String importedValue;
	 
	 private String paths;
	
	/**
	 * methods 	
	 */
	 
/*	 private static long getvalueofvariable;
		public static long getvalueofvariableinamagingtable() {
			return getvalueofvariable;
		}
		private static long getvalueintrendview;
		public static long getvalueofvariableintrendview() {
			return getvalueintrendview;
		}*/
		
	
	public boolean isAccountmanagerPageDisplayed() {
		// TODO Auto-generated method stub
//		AccountManagerAdminPageTitle.waitUntilPresent();
		AccountManagerPageTitle.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), AccountManagerPageTitle);
		String temp=AccountManagerPageTitle.getText().trim();
		System.out.println("-----1---------"+temp);
		if(temp.equalsIgnoreCase("Account Manager"))
		return true;
		else 
			return false;
		
	}
	
	
	public void clickAccManagerTab(){
		UIHelper.waitForPageToLoad(getDriver());
		accManagerTab.waitUntilClickable();
		accManagerTab.click();
	}

	public boolean isImportAccountDataPageDisplayed() {
		// TODO Auto-generated method stub
	
		ImportAccountDataPageTitle.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), 	ImportAccountDataPageTitle);
		String temp=ImportAccountDataPageTitle.getText().trim();
		System.out.println("-----2---------"+temp);
		if(temp.equalsIgnoreCase("Import Account Data"))
		return true;
		else 
			return false;
	}

	public void clickonCreateNewUDFButton(String customizedUDFName, String dataType) {
		System.out.println("---------------------");
		// TODO Auto-generated method stub
		
		boolean flag=MapYourHeadingPage.isClickedSave();
		System.out.println("The flag value--------"+flag);
		if(!flag){
//		System.out.println("--------------------1-------------------");
//		int dnbiColSize = dnbiColCollection.size();
//		System.out.println("dnbiColCollection.size()----->"+dnbiColCollection.size());
        for (int colIndex = 0; colIndex < dnbiColCollection.size(); colIndex++) {
        	
            flagEditIterationForCustom = 0;
           
            String dnbiValue = getDriver()
                    .findElements(
                            By.xpath("//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//tr[@id='firstLine']//td//div//input[starts-with(@id,'field')]"))
                    .get(colIndex).getAttribute("value");
//            System.out.println("--------------------3-------"+colIndex+"------------"+dnbiValue);
            importedValue = getDriver()
                    .findElements(
                            By.xpath("//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//tr[@id='secondLine']/td"))
                    .get(colIndex).getText();
//            System.out.println("--------------------4-------"+colIndex+"------------"+importedValue);
            if (dnbiValue.equals(" ") || !dnbiValue.contains(importedValue)) {
            	if(dnbiValue.startsWith("D-U-N-S")||importedValue.startsWith("D-U-N-S")||importedValue.contains("blank")){
            		continue;
            	}

          
   getDriver().findElement(By.xpath("//*[@class='combox rightColumnFirst']//*[@class='combox_input']//*[@id='editBtn"+ colIndex + "']")).click();
                
		CreateNewFieldButton.waitUntilPresent();
		CreateNewFieldButton.click();
		waitFor(2000).milliseconds();
		System.out.println("frameentered");
		getDriver().switchTo().frame(iFrameEle);
//		 getDriver().findElement(By.xpath("//div[@class='modal']//div[@class='modal_content']//iframe[@name='__modal_iframe_target']")).click();
		System.out.println("After frame enabled entered");
//		DisplayText.waitUntilPresent();
		DisplayText.clear();
//		DisplayText.sendKeys(customizedUDFName);
		DisplayText.sendKeys(importedValue);
		DataType.waitUntilPresent();
		System.out.println("++++++++++++++1+++++++++++");
		UIHelper.highlightElement(getDriver(), DataType);
		Select select = new Select(getDriver().findElement(By.xpath("//div[@id='adminDivId']/table[@id='labellist_table']//td/select[@name='DataType']")));
		select.selectByVisibleText("Currency");
		System.out.println("++++++++++++++2+++++++++++");
		UIHelper.highlightElement(getDriver(), savebutton);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='addField']//input[@value='Save']");
		((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", savebutton);
		savebutton.click();
//		je.executeScript("arguments[0].click();",savebutton);
//		savebutton.waitUntilPresent();
		
		UIHelper.waitForPageToLoad(getDriver());
            }
            if (colIndex == dnbiColCollection.size()){
            	break;
            }
            
        }
	}

	}

	public void enterCustomizedUDFname(String customizedUDFName) {
		// TODO Auto-generated method stub
		
		DisplayText.waitUntilPresent();
		DisplayText.sendKeys(customizedUDFName);
		savebutton.waitUntilPresent();
		savebutton.click();
		UIHelper.waitForPageToLoad(getDriver());
	}

	public void getUnmatchedRows() {
		// TODO Auto-generated method stub
		String text=getDriver().findElement(By.xpath("//div[@id='main']//div[@class='ad_impcompMap']")).getText();
		 String[] lines = text.split("<br/>");
		 String[] arr= new String[lines.length];
		 for(int i=0;i<lines.length;i++){
		 for(String line:lines){
			 arr[i]=line.substring(0, line.indexOf('(')-2);
				System.out.println(arr[i]);
		 }

		 }
		 for(String s:arr)
			 System.out.println("array values get from unmatched values"+s);
	}

	public void isDUNSNumberMatchingcheckboxSelected() {
		// TODO Auto-generated method stub
		if(!DunsMatchCheckbox.isSelected()){
			DunsMatchCheckbox.click();
		}else
		{
			
		}
	}
	
	
	public void clickNoandCancel() {
		// TODO Auto-generated method stub
		noCheckBox.waitUntilPresent();
		if(!noCheckBox.isSelected()){
			noCheckBox.click();
		}else
		{
	}
		btnCancelInImport.waitUntilPresent();
		btnCancelInImport.click();
	}
	
	public void clicknext(){
		btnNextInImport.waitUntilPresent();
		btnNextInImport.click();
	}
	public void entermapName(String mapname){
		String mapEle = "//tbody//td[@class='comcopyarea']//input[@class='regular']";
		WebElementFacade mapnameEle = find(By.xpath(mapEle));
		mapnameEle.clear();
		mapnameEle.type(mapname);
	}
	public void clickNoandNext() {
		// TODO Auto-generated method stub
		noCheckBox.waitUntilPresent();
		if(!noCheckBox.isSelected()){
			noCheckBox.click();
		}else
		{
	}
		btnNextInImport.waitUntilPresent();
		btnNextInImport.click();
	}

	public void clickonAccontNumber(String accontNumber) {
		// TODO Auto-generated method stub
		System.out.println("inside page class-----------------------");
		int size=getDriver().findElements(By.xpath("//div[@id='dd_inboxR']//table//tr")).size();
		System.out.println("account numbers count--------------"+size);
	for(int i=1;i<size;i++){
	
		paths=getDriver().findElement(By.xpath("//div[@id='dd_inboxR']//table//tr["+i+"]/td[1]/a")).getText().trim();
	if(paths.equalsIgnoreCase(accontNumber)){
		System.out.println("account number -------------"+paths);
		getDriver().findElement(By.xpath("//div[@id='dd_inboxR']//table//tr["+i+"]/td[1]/a")).click();
	UIHelper.waitForPageToLoad(getDriver());
	break;
	}else{
		System.out.println("account number in the else loop-------------"+paths);
	}
	}
	}

	public boolean isAccountNumberPresent(String accontNumber) {
		 accNumber.waitUntilPresent();
		 if(accNumber.getText().trim().equalsIgnoreCase(accontNumber)){
			return true; 
		 }
		 return false;
		
	}

	public boolean isStatePresent(String state) {
		// TODO Auto-generated method stub
		states.waitUntilPresent();
		UIHelper.highlightElement(getDriver(),states );
		 if(states.getText().trim().equalsIgnoreCase(state)){
				return true; 
			 }
			 return false;
	}

	public boolean iscomapanySummaryPageDisplayed() {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='compTitle']/h3[contains(text(),'Company Summary')]");
		UIHelper.highlightElement(getDriver(),CompanySummary );
		if(CompanySummary.getText().trim().equalsIgnoreCase("Company Summary")){
			return true;
		}
		return false;
	}

	public void clickonAuditTrailtab() {
		// TODO Auto-generated method stub
		AuditTrailTab.waitUntilPresent();
		UIHelper.highlightElement(getDriver(),AuditTrailTab );
		AuditTrailTab.click();
	}

	public void isAuditTrailPageDisplayed() {
		// TODO Auto-generated method stub
		audittrailpage.waitUntilPresent();
		UIHelper.highlightElement(getDriver(),audittrailpage );
		audittrailpage.isDisplayed();
	}

	public boolean isAuditTrailmessageDisplayed() {
		// TODO Auto-generated method stub
		UIHelper.highlightElement(getDriver(), TextWindow);
		TextWindow.click();
		UIHelper.waitForPageToLoad(getDriver());
		Audittrailmessagetext.waitUntilPresent();
		UIHelper.highlightElement(getDriver(),Audittrailmessagetext );
		String s=Audittrailmessagetext.getText().trim();
		System.out.println("Audittrailmessagetext-----"+s);
		if(s.contains("The account was imported and set with status")){
			return true;
		}
		return false;
	   }

	public boolean isAgingRollUpDisplayed() {
		// TODO Auto-generated method stub
		agingRollUp.waitUntilPresent();
		UIHelper.highlightElement(getDriver(),agingRollUp );
		agingRollUp.isDisplayed();
		System.out.println("--------------"+agingRollUp.getText().trim());
		if(agingRollUp.getText().trim().contains("Account Manager Aging Roll Up (Last Import On:")){
			return true;
		}
		return false;
	}

	public void clickonMoreoptionImport() {
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
		MoreOptionsEle.waitUntilPresent();
		if(MoreOptionsEle.isPresent())
		{
			MoreOptionsEle.click();
			
		}
	}

	public void clickonFeweroptionImport() {
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
		fewerOptionsEle.waitUntilPresent();
		if(fewerOptionsEle.isPresent())
		{
			fewerOptionsEle.click();
			
		}
	}

	public void giveValuequickSearchField(String dunsNumber) {
		// TODO Auto-generated method stub
		System.out.println("---------------------");
		UIHelper.waitForPageToLoad(getDriver());
		quickSearchFld.waitUntilPresent();
		quickSearchFld.sendKeys(dunsNumber);
	}

	public void clickonSearchButton() {
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
//		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='search_box']//span[@id='search_fields_basic']//input[@value='Search']");
		UIHelper.highlightElement(getDriver(), searchbutton);
//		searchbutton.waitUntilPresent();
//		searchbutton.click();
		searchbutton.submit();
		
	}

	public boolean isdisplaysearchpageDisplayed() {
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
//		UIHelper.highlightElement(getDriver(), searchResults);
		searchResults.waitUntilPresent();
		if(searchbutton.isDisplayed()){
			return true;
		}
		return false;
	}

	public boolean isimportedAccountDisplayed(String dunsNumber) {

		UIHelper.highlightElement(getDriver(), DunsNumbervalueMatch);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//div[@id='main']//table[@class='results full']//tr/td[2]//a[@ class='navlinktable']");
//		DunsNumbervalueMatch.waitUntilPresent();
		if(DunsNumbervalueMatch.getText().trim().contains(dunsNumber)){
			DunsNumbervalueMatch.click();
			return true;
		}
		return false;
	}

	public boolean isdisplayDunsNumberMatches(String dunsNumber) {
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), Accounttext);
		Accounttext.waitUntilPresent();
		
			if(Accountvalue.getText().trim().equalsIgnoreCase(dunsNumber)){
				return true;
		}
		
		return false;
	}

	public void clickonAgingTab() {
		// TODO Auto-generated method stub
//		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='ecf_toc_main']/ul[@id='ecf_toc1']//li/a[contains(text(),'Aging')]");
		UIHelper.highlightElement(getDriver(), AgingTab);
		AgingTab.click();
	}

	public boolean isAgingPageDisplayed() {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='agingList']/div[@class='widget_ecfbox showExpAging']/h3[contains(text(),'Aging')]");
		UIHelper.highlightElement(getDriver(), AgingPage);
		AgingPage.waitUntilPresent();
		if(AgingPage.isDisplayed()){
			return true;
	}
		return false;
	
	}

	public boolean isDatalinkAccessDisplayed() {
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), AgingDateLink);
		AgingDateLink.waitUntilPresent();
		if(AgingDateLink.isDisplayed()){
		
		return true;
		}
		return false;
	}

	
	public void isAccDisplayedinAnotherwindow(String accountNumber) {
		// TODO Auto-generated method stub

		String value=null;
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), AgingDateLink);
		
		parentWindow = getDriver().getWindowHandle();
		AgingDateLink.click();
		UIHelper.waitForPageToLoad(getDriver());
		Set<String> handles =  getDriver().getWindowHandles();
		for(String windowHandle  : handles) {
			System.out.println("-----------------------2----------------"+windowHandle);
			System.out.println("-----------------------3----------------"+parentWindow);
			if(!windowHandle.equals(parentWindow)) {
				
			getDriver().switchTo().window(windowHandle); 
			UIHelper.highlightElement(getDriver(), importAccountinAging);
			String accNo=importAccountinAging.getText().trim();
			Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher(accNo);
		     while(m.find()) {
		       value=m.group(1).trim();
		       System.out.println("The values in new window----------"+value);
		}//while
		     if(accountNumber.equalsIgnoreCase(value)){
		    	System.out.println("Account Value matches"); 
		    	getDriver().close();
		    	getDriver().switchTo().window(parentWindow);
		     }
		
	     }//for loop
		
		    //closing child window
		
		getDriver().switchTo().window(parentWindow); //cntrl to parent window
		    }
		
	}

	public boolean isDatamatchesinAgingAndCSVFile(String daysPastDue30,
			String daysPastDue60) {
		// TODO Auto-generated method stub
		ecfPage.switch_to_Required_Window();
		UIHelper.highlightElement(getDriver(), pastdue30);	
		String due30=pastdue30.getText().trim().substring(0, pastdue30.getText().trim().indexOf('.')).replace(",", "");
		UIHelper.highlightElement(getDriver(), pastdue60);	
		String due60=pastdue60.getText().trim().substring(0, pastdue60.getText().trim().indexOf('.')).replace(",", "");
		
		System.out.println("due30--------value-------"+due30);
		System.out.println("due60--------value-------"+due60);
		if((due30.equalsIgnoreCase(daysPastDue30.trim()))&(due60.equalsIgnoreCase(daysPastDue60.trim()))){
			System.out.println("------values are equal------------>>>>");
			ecfPage.close_the_Required_Window();
			System.out.println("i am calling parentwindow1");
			return true;
		}else{
			ecfPage.close_the_Required_Window();	
			return false;
		}
		
	}

	public boolean isResultsTableDisplayed() {
		// TODO Auto-generated method stub
		UIHelper.highlightElement(getDriver(), resulttable);
		if(resulttable.isDisplayed()){
			return true;
			}
		return false;
		
	}

public void clickOnMappingRequiredStatusLink() {
	try{
		UIHelper.highlightElement(getDriver(), ImportMainStatus);
		System.out.println("waited for element---------------------" + "clickOnMappingRequiredStatusLink mthd called");
		long start = System.currentTimeMillis( );						        										
		String storeStatusVal = null;
		long diffInMinutes;				
		 do{		
			 String CurrentStatus = ImportMainStatus.getText().toString().trim(); 
			 System.out.println("waited for element 1 ---------------------" + CurrentStatus);
					if(CurrentStatus.equalsIgnoreCase("Mapping Required")){
						UIHelper.highlightElement(getDriver(), ImportMainStatus);
						storeStatusVal = CurrentStatus;
						String CurrentStatus1 = ImportMainStatus.getText().toString().trim();
						System.out.println("waited for element---------------------" + CurrentStatus1);
						if(CurrentStatus1.equals("Mapping Required")){
							System.out.println("waited for element 2 ---------------------" + "2");
							UIHelper.highlightElement(getDriver(), ImportMainStatus);
							UIHelper.clickanElement(ImportMainStatus);
							UIHelper.waitForPageToLoad(getDriver());
							String currentWindow= getDriver().getWindowHandle();
							System.out.println(" Check title " + getDriver().getTitle()+ "<<<>>>" + getDriver().getWindowHandles().size());
							for (String popUpHandle :getDriver().getWindowHandles()) {  
								System.out.println("waited for element---------------------" + "3");
						        if(popUpHandle.equalsIgnoreCase(currentWindow))	
						        	continue;
						        System.out.println("waited for element---------------------" + "4");
						        getDriver().switchTo().window(popUpHandle);
						        String sTitle = getDriver().getTitle();	
								System.out.println("window switched------------------------------->>>5-");
								UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//div[@id='main']//div[@id='pageHead']//div[@id='page_title']//h2[contains(text(),'Import Status Details')]");
								UIHelper.highlightElement(getDriver(), ImportStatuspage);
								System.out.println("waited for element------------------->>6--");
								getDriver().close();
								getDriver().switchTo().window(currentWindow);	
						}
						
					}
				}
				if(storeStatusVal.equalsIgnoreCase("Processing")){  
					 	System.out.println("waited for element---------------------" + "5 Refresh");
						UIHelper.highlightElement(getDriver(), RefreshBttn);
						UIHelper.mouseOverandclickanElement(getDriver(), RefreshBttn);
						UIHelper.waitForPageToLoad(getDriver());
						UIHelper.waitForVisibilityOfEleByXpath(getDriver(), ImportMainStatusXpath);
						UIHelper.waitForPageToLoad(getDriver());
						Thread.sleep(40000);
				}					            
					long end = System.currentTimeMillis( );
					long diff = end - start;
					diffInMinutes = TimeUnit.MILLISECONDS.toMinutes(diff);
				}while(!(storeStatusVal.equalsIgnoreCase("Mapping Required"))
					&& !(storeStatusVal.equalsIgnoreCase("Errored"))
					&& (storeStatusVal.equalsIgnoreCase("Completed"))
					&& (diffInMinutes<15));
		 			System.out.println("waited for element---------------------" + "6 while OUT");
					UIHelper.waitForVisibilityOfEleByXpath( getDriver(),ImportMainStatusXpath);	
					String CurrentStatus1 = ImportMainStatus.getText().toString().trim();
					System.out.println("waited for element---------------------" + "6 while OUT"+CurrentStatus1);
		}catch (Exception e){
	}	
}
//		getDriver().switchTo().window(parentWindow1);

		
	/*public boolean isImportStatusDetailspageDisplayed() {
		waitFor(10000).milliseconds();
		 System.out.println("parentWindow1----------------"+parentWindow1);
		System.out.println("-------isImportStatusDetailspageDisplayed-----------");
		for (String handle : getDriver().getWindowHandles()) {
			 if(handle!=parentWindow1){
				 System.out.println("handle----------------"+handle);
			System.out.println("--------------i am going to child window--------1----------");
			getDriver().switchTo().window(handle);
			 System.out.println("--------------i am going to child window----2-------------");
			 UIHelper.highlightElement(getDriver(), ImportStatuspage);
          String text=ImportStatuspage.getText().trim();
          System.out.println("PageName-----------"+text);
		if(ImportStatuspage.isDisplayed())
		{
		getDriver().close();
		System.out.println("i am calling if block parentwindow1");
		getDriver().switchTo().window(parentWindow1);
			return true;
		}
		else{
		getDriver().close();
		System.out.println("i am calling  in else block parentwindow1");
		getDriver().switchTo().window(parentWindow1);
		return false;
		}
		
	}
		}
		return false;
		return true;
	}*/

	public void selectAgingTrendSummary() {
		// TODO Auto-generated method stub
		System.out.println("-------------aging1--------------");
		Select select = new Select(getDriver().findElement(By.xpath("//div[@id='tab1']/form[@id='agingForm']//select[@id='agingOption']")));
		select.selectByVisibleText("Aging Trend Summary");
		System.out.println("-------------aging2--------------");
	}

	public boolean isAgingTableDisplayed() {
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), agingResulttable);
		if(agingResulttable.isDisplayed()){
			return true;
			}
		return false;
	}

	
	public boolean isAging30DaysPastDueDisplayed() {
		// TODO Auto-generated method stub
		UIHelper.highlightElement(getDriver(), Aging30DaysPastDue);
		if(Aging30DaysPastDue.isDisplayed()){
	    return true;
	    
		}
		return false;
	}

	public boolean isAging91DaysPastDueDisplayed() {
		// TODO Auto-generated method stub
		UIHelper.highlightElement(getDriver(), Aging91DaysPastDue);
		if(Aging91DaysPastDue.isDisplayed()){
	    return true;
	    
		}
		return false;
	}

	

	

	

	

	public void clickonAgingTrendGraphButton() {
		// TODO Auto-generated method stub
		/*String  parentWindow= getDriver().getWindowHandle();//Return a string of alphanumeric window handle
//		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), viewTrendGraphbutton);
		viewTrendGraphbutton.click();
		for (String handle : getDriver().getWindowHandles()) {
			 if(handle!=parentWindow){
				  getDriver().switchTo().window(handle);
				  try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 }
		}*/
		
		
		
	/*String  parentWindow= getDriver().getWindowHandle();
	UIHelper.highlightElement(getDriver(), viewTrendGraphbutton);
	viewTrendGraphbutton.click();	
	UIHelper.waitForPageToLoad(getDriver());
	Set<String> handles =  getDriver().getWindowHandles();
	for(String windowHandle  : handles) {
		
		if(!windowHandle.equals(parentWindow)) {
			
		getDriver().switchTo().window(windowHandle);
		UIHelper.highlightElement(getDriver(), viewAgingTrendGraphwindow);
		UIHelper.waitForPageToLoad(getDriver());
		if(viewAgingTrendGraphwindow.isDisplayed()){
			System.out.println("viewAgingTrendGraphwindow is Displayed");
			
		}
		getDriver().close();
		}
		getDriver().switchTo().window(parentWindow); //cntrl to parent window	
	}//for loop
	
		*/
		String parentWindowId = getDriver().getWindowHandle();
		UIHelper.highlightElement(getDriver(), viewTrendGraphbutton);
		viewTrendGraphbutton.click();
        Set s = getDriver().getWindowHandles();
        Iterator ite = s.iterator();
        while (ite.hasNext()) {
          System.out.println("inside while loop--------------------------");
            String popupHandle = ite.next().toString();
            if (!popupHandle.contains(parentWindowId)) {
                 System.out.println("inside if loop-------------------------------------");
                 getDriver().switchTo().window(popupHandle);
                 System.out.println("window switched--------------------------------");
                 ((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", viewAgingTrendGraphwindow);
                 UIHelper.highlightElement(getDriver(), viewAgingTrendGraphwindow);
         		
         		if(viewAgingTrendGraphwindow.isDisplayed()){
         			System.out.println("viewAgingTrendGraphwindow is Displayed");
         		       			
         		}
         		getDriver().close();
         		getDriver().switchTo().window(parentWindowId);
         		}
         		getDriver().switchTo().window(parentWindowId);
                System.out.println("waited for element---------------------");
            }
        }
                
           

	public boolean isAgingviewGraphyDisplayed() {
		
//		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), viewAgingTrendGraphwindow);	
		/*if(viewAgingTrendGraphwindow.isDisplayed()){
			System.out.println("------------------------");
		    return true;
		}*/
			return true;
	}

	public void clickoncustomizereportButton() {
	
//		UIHelper.highlightElement(getDriver(), CustomizeReportColumns);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='exposureRollup']//input[@value='Customize Report Columns']");
		CustomizeReportColumns.click();
		UIHelper.waitForPageToLoad(getDriver());
//		getDriver().switchTo().frame("__modal_iframe_target");
	}

	public void clickonAddVariablesdue() {
		getDriver().switchTo().frame("__modal_iframe_target");
		
		ArrayList<String> al= new ArrayList<String>();
		al.add("1-30 Days Past Due");
		al.add("90+ Days Past Due");
		al.add("D-U-N-S® Number");
		al.add("Credit Limit");
		al.add("Total Outstanding");
		al.add("Credit Sales");
		al.add("Total Past Due");
		al.add("EmployeeSatisfaction");
		UIHelper.selectMultipleFromDropdownList(getDriver(), selectEle, al, addimgbutton);
		
		getDriver().manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		ArrayList<String> arl= new ArrayList<String>();
		al.add("Credit Sales");
		al.add("Total Past Due");
		al.add("EmployeeSatisfaction");
		al.add("Business Name");
		al.add("Location Type");
		al.add("Current");
		al.add("Credit Limit Utilization");
		UIHelper.selectMultipleFromDropdownList(getDriver(), selectremove, arl, removeimgbutton);
		UIHelper.waitForPageToLoad(getDriver());
		getDriver().manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
	
		System.out.println("submit button click");
		JavascriptExecutor je = (JavascriptExecutor)getDriver();
		je.executeScript("arguments[0].click();",agingsubmitbutton);
//		agingsubmitbutton.click();
		System.out.println("submit button2 click");
		UIHelper.waitForPageToLoad(getDriver());
//		getDriver().switchTo().defaultContent();
		
	/*	try{
		getDriver().switchTo().frame("__modal_iframe_target");	
		System.out.println("Iam in the clickonAddVariablesdue1-----");
		Select select = new Select(getDriver().findElement(By.xpath("//div[@class='ecfAcct_marginheight']//div[@id='vars']//select[@id='pool']")));
		select.selectByVisibleText("1-30 Days Past Due");
    	System.out.println("Iam in the clickonAddVariablesdue2-----");
//    	select.selectByVisibleText("90+ Days Past Due");
//    	Thread.sleep(1000);
    	UIHelper.highlightElement(getDriver(), addimgbutton);
    	addimgbutton.click();
    	System.out.println("Iam in the clickonAddVariablesdue3-----");

    	//UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//form[@id='customizeForm']//div[@class='modal_buttons']/input[@id='formSubmit']");
    	JavascriptExecutor je = (JavascriptExecutor)getDriver();
		je.executeScript("arguments[0].scrollIntoView(true);",agingsubmitbutton);
    	agingsubmitbutton.submit();
    	System.out.println("Iam in the clickonAddVariablesdue4-----");
		}catch(Exception e)	{
			
		}*/
		
	}

	public boolean clickonviewcorporateExposureReportButton() {
		int count=0;
		System.out.println("Iam in the clickonviewcorporateExposureReportButton--1---");		
		
		String  parentWindow= getDriver().getWindowHandle();
		getDriver().switchTo().window(parentWindow);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='exposureRollup']//div[@class='tools']/input[@value='View Corporate Exposure Report']");
		JavascriptExecutor je = (JavascriptExecutor)getDriver();
		je.executeScript("arguments[0].click();",ViewCorporateExposureReport);
//		ViewCorporateExposureReport.click();
		System.out.println("Iam in the clickonviewcorporateExposureReportButton--2---");
//		UIHelper.waitForPageToLoad(getDriver());
//		getDriver().manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		Set<String> handles =  getDriver().getWindowHandles();
		for(String windowHandle  : handles) {
			System.out.println("-----------I am in the for loop------------------");
			System.out.println("windowHandle---------------->"+windowHandle);
			System.out.println("parentWindow---------------->"+parentWindow);
			if(!windowHandle.equals(parentWindow)) {
				  getDriver().switchTo().window(windowHandle);
				  
				  System.out.println("I am in the child window");
				  UIHelper.highlightElement(getDriver(), tableheaders);
				  getDriver().manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
				//div[@id='main']//div/table[@class='results full tab_border']//tr/th[1]
					int size=getDriver().findElements(By.xpath("//div[@id='main']//table[@class='results full tab_border']/thead//th")).size();
					System.out.println("total number of headers in the table-------------"+size);
					List<WebElement> table_headers =getDriver().findElements(By.xpath("//div[@id='main']//table[@class='results full tab_border']/thead//th"));
					for (int i = 1; i <=size; i++) {
						WebElement el=getDriver().findElement(By.xpath("//div[@id='main']//table[@class='results full tab_border']/thead//th["+i+"]"));
						UIHelper.highlightElement(getDriver(), el);
						String value=getDriver().findElement(By.xpath("//div[@id='main']//table[@class='results full tab_border']/thead//th["+i+"]")).getText().trim();
						System.out.println("columnvalues-----------------"+value);
						if(value.equalsIgnoreCase("1-30 Days Past Due"))
							count++;
						if(value.equalsIgnoreCase("91+ Days Past Due"))
						count++;
					}
					if(count==2){
						System.out.println("the count value--------->"+count);
						return true;
					}
					getDriver().close();
					
			 }//if loop
			 
			 getDriver().switchTo().window(parentWindow); 
		}//for loop
		
	return false;
		
		
	}

	public boolean isPreviouslyAddedColumnsDisplayed(String daysPastDue31,String daysPastDue91) {
		// TODO Auto-generated method stub
		int count=0;
		UIHelper.highlightElement(getDriver(), tableheaders);
		int size=getDriver().findElements(By.xpath("//div[@id='main']//table[@class='results full tab_border']/thead//th")).size();
		System.out.println("total number of headers in the table-------------"+size);
		List<WebElement> table_headers =getDriver().findElements(By.xpath("//div[@id='main']//table[@class='results full tab_border']/thead//th"));
		for (int i = 1; i < size; i++) {
			String value=getDriver().findElement(By.xpath("//div[@id='main']//table[@class='results full tab_border']/thead//th"+i+"/a")).getText().trim();
			if(value.equalsIgnoreCase(daysPastDue31))
				count++;
			if(value.equalsIgnoreCase(daysPastDue91))
			count++;
		}
		if(count==2){
			System.out.println("the count value--------->"+count);
			return true;
		}
		return false;
	}

	public boolean isAccountmanagerAdminPageDisplayed() {
		UIHelper.highlightElement(getDriver(), AccountManagerAdminPageTitle);
		if(AccountManagerAdminPageTitle.isDisplayed()){
			return true;
		}
		return false;
	}

	public void clickonExportLink() {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@class='widget_ecfbox showExpAging']//a[@id='expAgingData']/img/following::span[contains(text(),'Export')]");
		exportlink.click();
		UIHelper.waitForPageToLoad(getDriver());
		
	}

	public boolean isDownloadpopupDisplayed() {
		// TODO Auto-generated method stub
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@class='modal_title']/h3[contains(text(),'Downloading Export Data')]");
		if(downloadPopUp.getText().trim().equalsIgnoreCase("Downloading Export Data")){
			return true;
		}
		return false;
	}

	public void clickonClickHeredownloadlink() {
		// TODO Auto-generated method stub
		System.out.println("888888888888888888888888888");
//		Serenity.getFirefoxProfile().setPreference("browser.helperApps.neverAsk.saveToDisk", "application/excel");
//		   Serenity.getFirefoxProfile().setPreference("browser.helperApps.neverAsk.openFile", "application/octet-stream");
		UIHelper.highlightElement(getDriver(), downloadClickHereLink);
		System.out.println("99999999999999999999999999999999999999999999");
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//div[@id='loadingExport']//strong/a[contains(text(),'click here')]");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		downloadClickHereLink.click();
		System.out.println("888888888888888888888888888");
	}


	public boolean checkTheImportStatus(String fileName) {
		// TODO Auto-generated method stub		
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@class='outerDiv']//div[@class='ad_borE8E8E8']/table[@class='results full']//tr[1]/td[3]/preceding::td[2][contains(.,'Completed')]");
		int size=getDriver().findElements(By.xpath("//div[@class='outerDiv']//div[@class='ad_borE8E8E8']/table[@class='results full']//tr")).size();
		for(int i=1;i<size;i++)
		{
			String name=getDriver().findElement(By.xpath("//div[@class='outerDiv']//div[@class='ad_borE8E8E8']/table[@class='results full']//tr["+i+"]/td[3]")).getText().trim();
			System.out.println("name------------>"+name+"fileName-------->"+fileName);
		 if(name.equalsIgnoreCase(fileName))
			{
			String status=getDriver().findElement(By.xpath("//div[@class='outerDiv']//div[@class='ad_borE8E8E8']/table[@class='results full']//tr["+i+"]/td[3]/preceding::td[2]")).getText().trim();
			System.out.println("Status value------------------>"+status);
			if(status.equalsIgnoreCase("Completed"))
				{
				 return true;
				}
			}
			return false;
		}
		return false;
	}
	public void isAccDisplayedinAnotherwindows(String accountNumber) {
		// TODO Auto-generated method stub
		String value=null;
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), AgingDateLink);
		
		String  parentWindow= getDriver().getWindowHandle();
		AgingDateLink.click();
		UIHelper.waitForPageToLoad(getDriver());
		Set<String> handles =  getDriver().getWindowHandles();
		for(String windowHandle  : handles) {
			System.out.println("-----------------------2----------------"+windowHandle);
			System.out.println("-----------------------3----------------"+parentWindow);
			if(!windowHandle.equals(parentWindow)) {
				
			getDriver().switchTo().window(windowHandle); 
			UIHelper.highlightElement(getDriver(), importAccountinAging);
			String accNo=importAccountinAging.getText().trim();
			Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher(accNo);
		     while(m.find()) {
		       value=m.group(1).trim();
		       System.out.println("The values in new window----------"+value);
		}//while
		     if(accountNumber.equalsIgnoreCase(value)){
		    	 
		    	System.out.println("Account Value matches"); 
//		    	getDriver().close();
		     }
		
	     }//for loop
		
		    //closing child window
		
//		getDriver().switchTo().window(parentWindow); //cntrl to parent window
		    }
			
	}

	public void clickonRefreshButtonImport() {
		// TODO Auto-generated method stub
		importaccountrefreshbutton.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//table[@id='importDataAuditTable']//tr//th/input[@value='Refresh' and @name='refresh']");
	}

	public void waituntilLoadImage() {
		// TODO Auto-generated method stub
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), "//div[@class='modal_inner_content']//div[@id='loadingPolling']/span[contains(text(),'Loading Data...')]");;
	
	}

	public boolean isviewImportlogpageDisplayed() {
		// TODO Auto-generated method stub
		if(ViewImportLogPage.isDisplayed()){
			return true;
		}
		return false;
	}

	public void clickImportLogNextButton() {
		// TODO Auto-generated method stub
		ImportLogNextButton.click();
	}

	public void clickOnRefreshButtonImportAccountPage() {
		getDriver().findElement(By.xpath("//*[@id='importDataAuditTable']/tbody/tr[1]/th[2]//input[@value='Refresh']")).click();
		waitFor(5000).milliseconds();
	}
}








