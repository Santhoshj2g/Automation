package com.dnb.automation.dnbi.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * MapYourHeadingPage.java - This class contains method for Map Your Heading
 * Page
 * 
 * @author Duvvuru Naveen
 * @version 1.0
 ***********************************************************************************************/
public class MapYourHeadingPage extends PageObject {

    private String firstRowName;
    private String secondRowName;
    private String importedValue;
    private boolean viewAllOption;
    private boolean viewMappedOnlyOption;
    private boolean viewUnMappedOnlyOption;
    private String selectedOption;
    private String selectedFieldVal = null;
    private String dnbiCurrentVal;
    private int flagEditIterationForCustom = 0;
    private boolean clickedCancelForCustomEdit;
    private boolean acceptNextAlert = true;
    private boolean templateExists;

    public boolean isTemplateExists() {
        return templateExists;
    }

    private boolean blockerWarning;

    public boolean isBlockerWarning() {
        return blockerWarning;
    }

    // MapYourHeadingPage editDetails;
    private boolean switchedToWarning;

    public boolean isSwitchedToWarning() {
        return switchedToWarning;
    }

    private boolean presenceOfCustomFrame;

    public boolean isPresenceOfCustomFrame() {
        return presenceOfCustomFrame;
    }

    public boolean isClickedCancelForCustomEdit() {
        return clickedCancelForCustomEdit;
    }

    private boolean editDoneForCustom;

    public boolean isEditDoneForCustom() {
        return editDoneForCustom;
    }

    private boolean selectedFieldNameForCustom;

    public boolean isSelectedFieldNameForCustom() {
        return selectedFieldNameForCustom;
    }

    private boolean removedFieldMapping;

    public boolean isRemovedFieldMapping() {
        return removedFieldMapping;
    }

    private boolean fieldsAreMapped;

    public boolean isFieldsAreMapped() {
        return fieldsAreMapped;
    }

    private boolean switchedToCustomModal;

    public boolean isSwitchedToCustomModal() {
        return switchedToCustomModal;
    }

    private static boolean clickedSave;

    public static boolean isClickedSave() {
        return clickedSave;
    }

    private boolean switchedToEditMappingModal;

    public boolean isSwitchedToEditMappingModal() {
        return switchedToEditMappingModal;
    }

    private boolean clickedCancel;

    public boolean isClickedCancel() {
        return clickedCancel;
    }

    private boolean editDone;

    public boolean isEditDone() {
        return editDone;
    }

    private boolean selectedFieldName;

    public boolean isSelectedFieldName() {
        return selectedFieldName;
    }

    private boolean colNameMatches;

    public boolean isColNameMatches() {
        return colNameMatches;
    }

    private boolean viewAllDisplayed;

    public boolean isViewAllDisplayed() {
        return viewAllDisplayed;
    }

    private boolean presenceOfRmvAllMappingLink;

    public boolean isPresenceOfRmvAllMappingLink() {
        return presenceOfRmvAllMappingLink;
    }

    private boolean removedExistingMapping;

    public boolean isRemovedExistingMapping() {
        return removedExistingMapping;
    }

    private boolean isClickedRmvAllMappingLink;

    public boolean isClickedRmvAllMappingLink() {
        return isClickedRmvAllMappingLink;
    }

    private boolean presenceOfApplyMappingTemplate;

    public boolean isPresenceOfApplyMappingTemplate() {
        return presenceOfApplyMappingTemplate;
    }

    private boolean mappedUsingExistingTemplate;

    public boolean isMappedUsingExistingTemplate() {
        return mappedUsingExistingTemplate;
    }

    private String some = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']";

    public String getSome() {
        return some;
    }

    public boolean isViewAllOption() {
        return viewAllOption;
    }

    public boolean isViewMappedOnlyOption() {
        return viewMappedOnlyOption;
    }

    public boolean isViewUnMappedOnlyOption() {
        return viewUnMappedOnlyOption;
    }

    public String getSelectedOption() {
        return selectedOption;
    }

    private String pgSaveYourImportMapping;

    private boolean titleSaveYourImportMapping;

    public boolean isTitleSaveYourImportMapping() {
        return titleSaveYourImportMapping;
    }

    // objects of map your heading page
    @FindBy(xpath = ".//*[@id='main']//*[@id='pageHead']//*[@id='page_title']/h2")
    private WebElementFacade pageHeading;

    @FindBy(id = "map")
    private WebElementFacade applyMappingTemplate;

    @FindBy(xpath = ".//*[@id='mappingHeader']/table/tbody/tr/td/input[@class='btn' and @value='Map']")
    private WebElementFacade btnMap;

    @FindBy(id = "delimiter")
    private WebElementFacade changeDelimiter;

    @FindBy(id = "btnChangeDeli")
    private WebElementFacade btnSelect;

    @FindBy(xpath = ".//*[@id='mapping']/table/tbody/tr/td/select[@name='viewBy']")
    private WebElementFacade lstView;

    @FindBy(xpath = ".//*[@id='mapping']/table/tbody/tr/td/input[@class='btn' and @value='Go']")
    private WebElementFacade btnGo;

    @FindBy(xpath = ".//*[@id='removeAllMapping']/a")
    private WebElementFacade lnkRemoveAllMapping;

    @FindBy(xpath = "//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//tr[@id='firstLine']//td//div//input[starts-with(@id,'second_hidden_field')]")
    private WebElementFacade removedDNBiCols;

    // table objects
    @FindBy(xpath = "//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//*[@id='topFirstRow' and @class='rightColumnFirst']")
    private WebElementFacade dnbiRow;

    public WebElementFacade getDnbiRow() {
        return dnbiRow;
    }

    @FindBy(xpath = "//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//*[@id='topSecondRow' and @class='rightColumnSecond']")
    private WebElementFacade importedFileRow;

    @FindBy(xpath = "//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//tr[@id='firstLine']//td//div")
    private WebElementFacade firstRow;

    @FindBy(xpath = "//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//tr[@id='secondLine']")
    private WebElementFacade secondRow;

    @FindBy(xpath = "//*[@class='combox rightColumnFirst']//*[@class='combox_input']//*[@value='Edit']")
    private WebElementFacade EditButton;

    @FindBy(xpath = "//*[@id='edit-options']//*[@id='editBtn']")
    private WebElementFacade EditMappingButton;

    @FindBy(xpath = "//*[@id='edit-options']//p//input[@value='Remove Mapping']")
    private WebElementFacade removeMappingButton;

    @FindBy(xpath = "//*[@id='edit-options']//p//input[@value='Create Custom Field']")
    private WebElementFacade createCustomeField;

    // modal dialog account map
    @FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
    private static WebElementFacade iframe;

    public static WebElementFacade getIframe() {
        return iframe;
    }

    @FindBy(xpath = ".//*[@id='errAddfield']")
    private WebElementFacade customFieldExistsErr;

    @FindBy(id = "addRowlnk")
    private WebElementFacade addRowInAccountMap;

    @FindBy(xpath = ".//*[@id='addField']//*[@class='modal_inner_content relativePos modal_overflow ieModal']//*/select[@name='ENTITY_TYPE']")
    private WebElementFacade selectCategory;

    @FindBy(xpath = "//*[@class='modal']//*[@class='modal_title']/a")
    private WebElementFacade closeiframe;

    @FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
    private WebElementFacade frame;

    @FindBy(xpath = ".//*[@id='addField']//*[@class='modal_inner_content relativePos modal_overflow ieModal']//*[@id='adminDivId']//*/input[@name='DisplayText']")
    private WebElementFacade displayTextInAccountMap;

    @FindBy(xpath = ".//*[@id='addField']//*[@class='modal_inner_content relativePos modal_overflow ieModal']//*/select[@name='DataType']")
    private WebElementFacade dataTypeInAccountMap;

    @FindBy(xpath = ".//*[@id='addField']//*[@class='modal_inner_content relativePos modal_overflow ieModal']//*/select[@name='EachSectionName']")
    private WebElementFacade sectionInAccountMap;

    @FindBy(xpath = ".//*[@id='addField']//*[@class='modal_buttons']/input[@value='Save']")
    private WebElementFacade btnSaveInAccountMap;

    @FindBy(xpath = ".//*[@id='addField']/div/input[@type='button' and @value='Cancel']")
    private WebElementFacade btnCancelInAccountMap;

    @FindBy(xpath = "//div[@class='modal']/div[@class='modal_title']/a")
    private WebElementFacade closeInAccountMap;

    // modal dialog for edit mapping
    @FindBy(xpath = "html/body/div[@class='modal']/div[@class='modal_title']/h3")
    private WebElementFacade iframeTitle;

    @FindBy(xpath = ".//*[@class='modal']//*[@class='modal_content']//*[@class='cat2tablewrap']//tr")
    private WebElementFacade mappingCategoryTable;

    @FindBy(xpath = ".//*[@class='modal']//*[@class='modal_content']//*[@class='cat2tablewrap']//tr")
    private WebElementFacade radioBtn;

    @FindBy(xpath = ".//*[@id='cat2table']/tr")
    private WebElementFacade currentFieldLabelColumn;

    @FindBy(xpath = "//input[@name='mapping-option']")
    private WebElementFacade radio;

    @FindBy(id = "cat1")
    private WebElementFacade fieldCategories;

    @FindBy(id = "/dnbi/pmAdmin/saveSectionField?fromPage=IMPORT")
    private WebElement saveInModal;

    @FindBy(css = ".modal_title>h3")
    private WebElementFacade modalHeading;

    @FindBy(xpath = "(//input[@value='Cancel'])[3]")
    private WebElement cancelInModal;

    // buttons of map your heading page
    @FindBy(xpath = "//*[@id='main']//*[@id='backRight']//input[@value='Next >']")
    private WebElementFacade nextInMapHeading;

    @FindBy(xpath = "//*[@id='main']//*[@id='backRight']//input[@type='button' and @value='< Back']")
    private WebElementFacade BackInMapHeading;

    @FindBy(xpath = "//*[@id='main']//*[@id='backRight']//input[@type='button' and @value='Cancel']")
    private WebElementFacade cancelInMapHeading;

    @FindBy(xpath = "//*[@class='modal']//*//a")
    private WebElementFacade clickCloseyetaGain;

    @FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//*[@class='modal_buttons']//input[@value='Cancel']")
    private WebElementFacade cancelInwarning;

    @FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//*[@class='modal_buttons']//input[@value='Continue']")
    private WebElementFacade continueInwarning;

    @FindBy(xpath = "//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//tr[@id='firstLine']//td//div//input[starts-with(@id,'second_hidden_field')]")
    private List<WebElementFacade> dnbiCols;

    @FindBy(xpath = "//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//tr[@id='firstLine']//td//div//input[starts-with(@id,'field')]")
    private List<WebElementFacade> allDnbiColCollection;

    @FindBy(xpath = "//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//tr[@id='firstLine']//td//div//input[starts-with(@id,'field')]")
    private List<WebElementFacade> mappedDnbiColCollection;

    @FindBy(xpath = "//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//tr[@id='secondLine']//td")
    private List<WebElementFacade> mappedImportedColCollection;

    @FindBy(xpath = "//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//tr[@id='firstLine']//td//div//input[starts-with(@id,'field')]")
    private List<WebElementFacade> unmappedDnbiColCollection;

    @FindBy(xpath = "//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//tr[@id='firstLine']/td")
    private List<WebElementFacade> unmappedImpColCollection;

    @FindBy(xpath = "//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//tr[@id='secondLine']//td")
    private List<WebElementFacade> allImportedColCollection;

    @FindBy(xpath = "//input[starts-with(@id,'field')]")
    private List<WebElementFacade> dnbiColCollection;

    @FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
    private WebElementFacade iFrameEle;

    @FindBy(xpath = ".//*[@id='addField']//*[@class='modal_inner_content relativePos modal_overflow ieModal']//*/select[@name='ENTITY_TYPE']")
    private WebElementFacade entityTypeEle;

    @FindBy(xpath = ".//*[@id='addField']//*[@class='modal_inner_content relativePos modal_overflow ieModal']//*[@id='adminDivId']//*/input[@name='DisplayText']")
    private WebElementFacade displayTxtEleInFrame;

    @FindBy(xpath = ".//*[@id='main']//*[@id='pageHead']//*[@id='page_title']/h2")
    private WebElementFacade pageTitleEle;

    @FindBy(xpath = "//*[@id='main']//*[@id='backRight']//input[@type='button' and @value='Next >']")
    private WebElementFacade nextBtnEle;

    @FindBy(xpath = ".//*[@id='main']")
    private WebElementFacade mainEle;

    /**
     * @return the pageHeading
     */
    public WebElementFacade getPageHeading() {
        return pageHeading;
    }

    /***********************************************************************************
     * Function: Click on remove all mapping link to remove all existing
     * mappings Input : NA Action : Click Output : DNBi columns and imported
     * data column of the table should be blank
     ***********************************************************************************/
    public void removeAllMapping() {
        int flag = 0;
        if (lnkRemoveAllMapping.isPresent()) {
            presenceOfRmvAllMappingLink = true;
            lnkRemoveAllMapping.isPresent();
            UIHelper.waitForPageToLoad(getDriver());
            if (!lnkRemoveAllMapping.isPresent()) {
                isClickedRmvAllMappingLink = true;

                for (int index = 0; index < dnbiCols.size(); index++) {
                    String removedDNBiColVal = dnbiCols.get(index)
                            .getAttribute("value");

                    if (removedDNBiColVal.equalsIgnoreCase("")) {
                        flag = 1;
                    } else {
                        flag = 0;
                    }
                }
                if (flag == 1) {
                    removedExistingMapping = true;
                } else {
                    removedExistingMapping = false;
                }
            } else {
                isClickedRmvAllMappingLink = false;
            }

        } else {
            presenceOfRmvAllMappingLink = false;
        }
    }

    /********************************************************************************************************
     * Function: Select any template from apply mapping template and click map
     * button Input : Option 1 Action : select Output : DNBi columns and
     * imported data column of the table should be mapped with existing template
     ********************************************************************************************************/
    public void useSavedTemplate(String selectTemplate) {
        if (applyMappingTemplate.isPresent()) {

            presenceOfApplyMappingTemplate = true;
            if (UIHelper.compareListValue(applyMappingTemplate, selectTemplate)) {
                templateExists = true;

                btnMap.click();

                UIHelper.waitForPageToLoad(getDriver());

                String dNBiColOneVal = dnbiCols.get(0).getAttribute("value");
                String dNBiColTwoVal = dnbiCols.get(1).getAttribute("value");

                if (!dNBiColOneVal.equalsIgnoreCase("")
                        && !dNBiColTwoVal.equalsIgnoreCase("")) {

                    mappedUsingExistingTemplate = true;
                } else {

                    mappedUsingExistingTemplate = false;
                }
            }
        } else {

            presenceOfApplyMappingTemplate = false;
        }
    }

    /***************************************************************************************************************
     * Function: Select All option in view field to view all mapped and unmapped
     * columns of DNBi and imported data Input : All Action : Select Output :
     * All DNBi columns and imported data column of the table should be
     * displayed
     ***************************************************************************************************************/
    public void mapChoiceIsAll() throws Exception {
        try {
            int flag = 0;
            new Select(getDriver().findElement(By.name("viewBy")))
                    .selectByValue("viewAll");
            getDriver().findElement(By.xpath("(//input[@value='Go'])[2]"))
                    .click();
            UIHelper.waitForPageToLoad(getDriver());

            int allDnbiColSize = allDnbiColCollection.size();

            for (int colIndex = 0; colIndex < allDnbiColSize; colIndex++) {
                String dnbiValue = allDnbiColCollection.get(colIndex)
                        .getAttribute("value");
                if (dnbiValue.equalsIgnoreCase("null")
                        | !dnbiValue.equalsIgnoreCase("null")) {
                    viewAllOption = true;

                    flag = 1;
                } else {
                    flag = 0;
                }

            }
            if (flag == 1) {
                viewAllDisplayed = true;
            } else {
                viewAllDisplayed = false;
            }
        } catch (Exception e) {
            throw e;
        }

    }

    /***************************************************************************************************************
     * Function: Select Mapped Only option in view field to view only mapped
     * columns of DNBi and imported data Input : Mapped Only Action : Select
     * Output : Mapped DNBi columns and imported data column of the table should
     * be displayed
     ***************************************************************************************************************/
    public void mapChoiceIsMappedOnly() throws Exception {
        try {

            new Select(getDriver().findElement(By.name("viewBy")))
                    .selectByValue("viewMapped");
            getDriver().findElement(By.xpath("(//input[@value='Go'])[2]"))
                    .click();
            UIHelper.waitForPageToLoad(getDriver());

            int mappedDnbiColSize = mappedDnbiColCollection.size();

            for (int colIndex = 0; colIndex < mappedDnbiColSize; colIndex++) {
                String dnbiValue = mappedDnbiColCollection.get(colIndex)
                        .getAttribute("value");
                String importedValue = mappedImportedColCollection
                        .get(colIndex).getText();
                if (!dnbiValue.isEmpty() && !importedValue.isEmpty()) {
                    viewMappedOnlyOption = true;

                } else
                    viewMappedOnlyOption = false;

            }

        } catch (Exception e) {
            throw e;
        }

    }

    /***************************************************************************************************************
     * Function: Select UnMapped Only option in view field to view only Unmapped
     * columns of DNBi and imported data Input : Un-Mapped Only Action : Select
     * Output : Unmapped DNBi columns and imported data column of the table
     * should be displayed
     ***************************************************************************************************************/
    public void mapChoiceIsUnMappedOnly() throws Exception {
        try {
            new Select(getDriver().findElement(By.name("viewBy")))
                    .selectByValue("viewUnmapped");
            getDriver().findElement(By.xpath("(//input[@value='Go'])[2]"))
                    .click();
            UIHelper.waitForPageToLoad(getDriver());

            int unmappedDnbiColSize = unmappedDnbiColCollection.size();

            int noOfUnmappedCols = unmappedImpColCollection.size();

            if (noOfUnmappedCols == 0) {
                viewUnMappedOnlyOption = true;
            } else {

                for (int colIndex = 0; colIndex < unmappedDnbiColSize; colIndex++) {
                    String dnbiValue = unmappedDnbiColCollection.get(colIndex)
                            .getAttribute("value");

                    if (dnbiValue.isEmpty()) {
                        viewUnMappedOnlyOption = true;

                    } else {
                        viewUnMappedOnlyOption = false;
                    }

                }
            }
            new Select(getDriver().findElement(By.name("viewBy")))
                    .selectByVisibleText("All");
            getDriver().findElement(By.xpath("(//input[@value='Go'])[2]"))
                    .click();
            UIHelper.waitForPageToLoad(getDriver());
        } catch (Exception e) {
            throw e;
        }

    }

    /***************************************************************************************************************
     * Function: verify column name in map your heading table Input : NA Action
     * :NA Output : DNBi & imported column name should be displayed
     ***************************************************************************************************************/
    public boolean columnNamesInMapYourHeading() {

        try {
            firstRowName = dnbiRow.getText();
            secondRowName = importedFileRow.getText();

            if (firstRowName.contains("DNBi Fields")
                    && secondRowName.contains("Import")) {
                colNameMatches = true;
            }

        } catch (Exception e) {
            // throw e;
        }
        return colNameMatches;
    }

    /***************************************************************************************************************
     * Function: remove particular field mapping Input : field name Action
     * :click remove mapping Output : field column should be blank
     ***************************************************************************************************************/
    public void removeParticularFieldMapping(String removeField) {
        try {

            int allDnbiColSize = allDnbiColCollection.size();

            for (int colIndex = 0; colIndex < allDnbiColSize; colIndex++) {
                String dnbiValue = allDnbiColCollection.get(colIndex)
                        .getAttribute("value");
                String importedValue = allImportedColCollection.get(colIndex)
                        .getText();
                if (removeField.contains(dnbiValue)
                        | removeField.contains(importedValue)) {

                    getDriver()
                            .findElement(
                                    By.xpath("//*[@class='combox rightColumnFirst']//*[@class='combox_input']//*[@id='editBtn"
                                            + colIndex + "']")).click();
                    removeMappingButton.click();
                    UIHelper.waitForPageToLoad(getDriver());

                    String dnbiCurrValue = allDnbiColCollection.get(colIndex)
                            .getAttribute("value");
                    if (dnbiCurrValue.isEmpty()) {

                        removedFieldMapping = true;
                        break;
                    }
                }

            }
        } catch (Exception e) {
            throw e;
        }

    }

    /***************************************************************************************************************
     * Function: edit mapping with custom field Input : custom field
     * name,datatype,section Action :click & select Output : custom field should
     * be displayed
     ***************************************************************************************************************/
    public void editMappingDNBiWithImportedFile(String editCategory,
            String custCategory, String[] custFieldDataType,
            String custFieldSection, String custEditCategory) {
        try {
            int dnbiColSize = dnbiColCollection.size();

            for (int colIndex = 0; colIndex < dnbiColSize; colIndex++) {
                flagEditIterationForCustom = 0;
                String dnbiValue = getDriver()
                        .findElements(
                                By.xpath("//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//tr[@id='firstLine']//td//div//input[starts-with(@id,'field')]"))
                        .get(colIndex).getAttribute("value");
                importedValue = getDriver()
                        .findElements(
                                By.xpath("//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//tr[@id='secondLine']/td"))
                        .get(colIndex).getText();

                if (dnbiValue.equals("") || !dnbiValue.contains(importedValue) ) {
                	if(dnbiValue.startsWith("D-U-N-S")||importedValue.startsWith("D-U-N-S")||importedValue.contains("blank")){
                		continue;
                	}
                	System.out.println("dnbiValue======>"+dnbiValue+" importedValue=====>"+importedValue);
                	
                    getDriver()
                            .findElement(
                                    By.xpath("//*[@class='combox rightColumnFirst']//*[@class='combox_input']//*[@id='editBtn"
                                            + colIndex + "']")).click();
                    EditMappingButton.click();
                    String modalHeader = modalHeading.getText();
                    if (modalHeader.contains("Account Map")) {
                        switchedToEditMappingModal = true;
                        clickedCancel = checkEditFieldMapping(colIndex,
                                editCategory, custEditCategory, custCategory,
                                custFieldDataType[colIndex],
                                flagEditIterationForCustom);
                    } else {
                        switchedToEditMappingModal = false;
                    }

                    if (clickedCancel) {

                        iFrameEle.waitUntilPresent();
                        getDriver().switchTo().frame(iFrameEle);

                        entityTypeEle.waitUntilPresent();
                        displayTxtEleInFrame.waitUntilPresent();

                        if (selectCategory.isPresent()) {
                            presenceOfCustomFrame = true;
                            selectCategory.waitUntilPresent();

                            selectCategory.selectByVisibleText(custCategory);

                            displayTextInAccountMap.clear();

                            displayTextInAccountMap.sendKeys(importedValue);

                            dataTypeInAccountMap.waitUntilPresent();

                            dataTypeInAccountMap
                                    .selectByVisibleText(custFieldDataType[colIndex]);

                            sectionInAccountMap.waitUntilPresent();

                            sectionInAccountMap
                                    .selectByVisibleText(custFieldSection);

                            btnSaveInAccountMap.click();

                            if (customFieldExistsErr.isPresent()) {
                                btnCancelInAccountMap.click();
                                getDriver().switchTo().defaultContent();

                            } else if (iframe.isPresent()) {
                                iFrameEle.waitUntilPresent();
                                getDriver().switchTo().frame(iFrameEle);

                                clickCloseyetaGain.click();
                                getDriver().switchTo().defaultContent();

                            } else {
                                getDriver().switchTo().defaultContent();

                            }
                            UIHelper.waitForPageToLoad(getDriver());
                            pageTitleEle.waitUntilPresent();

                            if (pageHeading.getText().equalsIgnoreCase(
                                    "Map Your Headings")) {

                                clickedSave = true;

                                WebElementFacade combBoxEditBtnEle = find(By
                                        .xpath("//*[@class='combox rightColumnFirst']//*[@class='combox_input']//*[@id='editBtn"
                                                + colIndex + "']"));
                                combBoxEditBtnEle.waitUntilPresent();

                                getDriver()
                                        .findElement(
                                                By.xpath("//*[@class='combox rightColumnFirst']//*[@class='combox_input']//*[@id='editBtn"
                                                        + colIndex + "']"))
                                        .click();

                                EditMappingButton.click();

                                flagEditIterationForCustom = 1;
                                clickedCancel = checkEditFieldMapping(colIndex,
                                        editCategory, custEditCategory,
                                        custCategory,
                                        custFieldDataType[colIndex],
                                        flagEditIterationForCustom);

                            } else {

                                clickedSave = false;
                            }
                        } else {
                            presenceOfCustomFrame = false;
                        }
                    } else {
                        continue;
                    }
                } else {
                    fieldsAreMapped = true;
                }

            }

        } catch (Exception e) {
            // throw e;
        }
    }

    /***************************************************************************************************************
     * Function: click next in map your heading page Input : NA Action :click
     * Output :Save Your Import Mapping page should be displayed
     * 
     * @throws Exception
     ***************************************************************************************************************/

    public void clickNext() throws Exception {
    	System.out.println("-------clickNext()  in MapyourHeading page--------------------");
    	((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", nextInMapHeading);
        nextInMapHeading.click();
        UIHelper.waitForPageToLoad(getDriver());
        if (modalHeading.isPresent()) {
            String modalHeader = modalHeading.getText();
            if (modalHeader.contains("Warning - Import file error(s) found")) {
                switchedToWarning = true;
                continueInwarning.click();
                nextBtnEle.waitUntilPresent();
            }
        }

        UIHelper.processalert(getDriver());
        UIHelper.waitForPageToLoad(getDriver());
    }

    /***************************************************************************************************************
     * Function: click continue in warning alert Input : NA Action :click Output
     * :Save Your Import Mapping page should be displayed
     * 
     * @throws Exception
     ***************************************************************************************************************/
    public String closeAlertAndGetItsText() throws Exception {
        try {

            Alert alert = getDriver().switchTo().alert();
            String alertText = alert.getText();
            if (acceptNextAlert) {
                alert.accept();
            } else {
                alert.dismiss();
            }
            return alertText;
        } finally {
            acceptNextAlert = true;
        }
    }

    /***************************************************************************************************************
     * Function: retrieve page title Input : NA Action :NA Output : Save Your
     * Import Mapping page title should be displayed
     ***************************************************************************************************************/
    public void getPageTitle() {
        pageHeading.waitUntilPresent();
        pgSaveYourImportMapping = pageHeading.getText();
        if (pgSaveYourImportMapping
                .equalsIgnoreCase("Save Your Import Mapping")) {
            titleSaveYourImportMapping = true;
        } else {
            titleSaveYourImportMapping = false;
        }
    }

    public String getSaveYourImpMapPgTitle() {
        pageHeading.waitUntilPresent();
        return pageHeading.getText();
    }

    /***************************************************************************************************************
     * Function: Verify imported column value is available in edit mapping
     * list.If available select & save else click cancel Input : imported column
     * name Action :select & click Output :
     ***************************************************************************************************************/
    public boolean checkEditFieldMapping(int colIndex, String editCategory,
            String custEditCategory, String custCategory,
            String expectedDataType, int flagEditIterationForCustom) {
    	System.out.println("editCategory---->"+editCategory+" custEditCategory-------> "+custEditCategory+" expectedDataType-------> "+expectedDataType+" flagEditIterationForCustom-----> "+flagEditIterationForCustom);
        boolean clickedCancelVal = false;
        switchedToEditMappingModal = true;
        getDriver().findElement(By.cssSelector("div.modal_title")).click();
        WebElement fieldCategory = getDriver().findElement(By.id("cat1"));
        if (flagEditIterationForCustom == 0) {
            Select clickThis = new Select(fieldCategory);
            clickThis.selectByVisibleText(editCategory.toString().trim());
        } else {
            Select clickThis = new Select(fieldCategory);
            clickThis.selectByVisibleText(custEditCategory.toString().trim());
        }
        List<WebElement> newFieldLabel = getDriver().findElements(
                By.xpath(".//*[@id='cat2table']/tr/td[2]"));
        List<WebElement> option = getDriver().findElements(
                By.xpath("(//input[@name='mapping-option'])"));
        List<WebElement> dataType = getDriver().findElements(
                By.xpath(".//*[@id='cat2table']/tr/td[4]"));
        for (int fieldIndex = 0; fieldIndex < option.size(); fieldIndex++) {
            option.get(fieldIndex).click();
            selectedFieldVal = newFieldLabel.get(fieldIndex).getText();
//            System.out.println("selectedFieldVal----"+selectedFieldVal);//it will have all the existing mappings
//            System.out.println("------verify the values--------------"+importedValue);//imported unmatched values
            if (selectedFieldVal.equalsIgnoreCase(importedValue) & dataType.get(fieldIndex).getText().contains(expectedDataType)) {
            	System.out.println("selectedFieldVal====>"+selectedFieldVal+"dataType.get(fieldIndex).getText()------>"+dataType.get(fieldIndex).getText()+"expectedDataType====>"+expectedDataType);
                if (flagEditIterationForCustom == 0) {
                    selectedFieldName = true;
                } else {
                    selectedFieldNameForCustom = true;
                }
                getDriver().manage().timeouts()
                        .implicitlyWait(2, TimeUnit.SECONDS);
                break;
            } else {
                if (flagEditIterationForCustom == 0) {
                    selectedFieldName = false;
                } else {
                    selectedFieldNameForCustom = false;
                }

            }
        }

        if (selectedFieldName || selectedFieldNameForCustom) {
            saveInModal.click();
            UIHelper.waitForPageToLoad(getDriver());
            dnbiCurrentVal = getDriver()
                    .findElements(
                            By.xpath("//*[@id='main']//*[@id='mapping']//*[@id='allDiv']//tr[@id='firstLine']//td//div//input[starts-with(@id,'field')]"))
                    .get(colIndex).getAttribute("value");
            if (dnbiCurrentVal.equalsIgnoreCase(selectedFieldVal)) {
                if (flagEditIterationForCustom == 0) {
                    editDone = true;
                } else {
                    editDoneForCustom = true;
                }

            } else {
                if (flagEditIterationForCustom == 0) {
                    editDone = false;
                } else {
                    editDoneForCustom = false;
                }

            }
        } else {
            cancelInModal.click();
            UIHelper.waitForPageToLoad(getDriver());
            pageHeading.waitUntilPresent();
            if (pageHeading.getText().equalsIgnoreCase("Map Your Headings")) {
                if (flagEditIterationForCustom == 0) {
                    clickedCancel = true;
                } else {
                    clickedCancelForCustomEdit = true;
                }
            }

        }

        return clickedCancelVal;
    }

    /***************************************************************************************************************
     * Function: Click cancel button in map your heading page Input : NA Action
     * : click Output : Import account page should be displayed
     ***************************************************************************************************************/
    public void clickCancelBtnInMapHeading() {
        cancelInMapHeading.click();
        mainEle.waitUntilPresent();
    }

}
