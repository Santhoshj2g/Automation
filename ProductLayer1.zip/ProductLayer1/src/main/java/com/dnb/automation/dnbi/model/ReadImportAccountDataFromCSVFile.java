package com.dnb.automation.dnbi.model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**********************************************************************************************
 * ReadImportAccountDataFromCSVFile.java - This class update the account number
 * in ImportAccountData.csv file
 * 
 * @author Duvvuru Naveen
 * @version 1.0
 ***********************************************************************************************/
public class ReadImportAccountDataFromCSVFile {

    ArrayList AccountWiseDataOfCSV = new ArrayList();
    ArrayList ColumnWiseSumOfCSV = new ArrayList();
    ArrayList accountNumberList = new ArrayList();
    List<ImportAccountDataCSV> importCSVList = new ArrayList<ImportAccountDataCSV>();
    // Object[] x = new Object[]{1,2,3,"srk"};
    float currentDollar = 0;
    ArrayList currentDollarList = new ArrayList();

    float daysPastDue130 = 0;
    ArrayList daysPastDue130List = new ArrayList();

    float daysPastDue3160 = 0;
    ArrayList daysPastDue3160List = new ArrayList();

    float daysPastDue6190 = 0;
    ArrayList daysPastDue6190List = new ArrayList();

    float daysPastDue91120 = 0;
    ArrayList daysPastDue91120List = new ArrayList();

    float daysPastDue121150 = 0;
    ArrayList daysPastDue121150List = new ArrayList();

    float moreThan151DaysPastDue = 0;
    ArrayList moreThan151DaysPastDueList = new ArrayList();

    // last AC no values
    float acCurrentDollar = 0;
    float acDaysPastDue130 = 0;
    float acDaysPastDue3160 = 0;
    float acDaysPastDue6190 = 0;
    float acDaysPastDue91Plus = 0;
    float acDaysPastDue91120 = 0;
    float acDaysPastDue121150 = 0;
    float acMoreThan151DaysPastDue = 0;

    public void setAccountWiseDataOfCSV(ArrayList<String> AccountWiseDataOfCSV) {
        this.AccountWiseDataOfCSV = AccountWiseDataOfCSV;
    }

    // Acount Number
    private String accnumber;
    @SuppressWarnings("rawtypes")
    private Iterator csvIterator;

    public String getAccnumber() {
        return accnumber;
    }

    // Current value
    private double xlcurrentvalue;

    public double getXlcurrentvalue() {
        return xlcurrentvalue;
    }

    // 1 to 30 days
    private double xlDaysPastDue1to30;

    public double getXlDaysPastDue1to30() {
        return xlDaysPastDue1to30;
    }

    // 31 to 60 days
    private double xlDaysPastDue31to60;

    public double getxlDaysPastDue31to60() {
        return xlDaysPastDue31to60;
    }

    // 61 to 90 days
    private double xlDaysPastDue61to90;

    public double getxlDaysPastDue61to90() {
        return xlDaysPastDue61to90;
    }

    // 91 to 180 days
    private double xlDaysPastDue91to120;

    public double getxlDaysPastDue91to120() {
        return xlDaysPastDue91to120;
    }

    // Total Out Standing
    private double xlDaysPastDue121150;

    public double getxlDaysPastDue121150() {
        return xlDaysPastDue121150;
    }

    private double xlDaysPastDue151Day;

    public double getxlDaysPastDue151Day() {
        return xlDaysPastDue151Day;
    }

    // Current value
    private double acxlcurrentvalue;

    // 1 to 30 days
    private double acxlDaysPastDue1to30;

    // 31 to 60 days
    private double acxlDaysPastDue31to60;

    // 61 to 90 days
    private double acxlDaysPastDue61to90;

    private double acxlDaysPastDue91Plus;

    public List importaccountDataReadingXLvalues(String uploadCSVFilesPath) {

        try {

            FileReader f = new FileReader(uploadCSVFilesPath);
            BufferedReader br = new BufferedReader(f);
            String s;
            int lineNbr = 0;
            while ((s = br.readLine()) != null) {

                lineNbr = lineNbr + 1;

                if (1 == lineNbr)
                    continue;

                String[] str = s.split(",");
                ImportAccountDataCSV impActDataCSV = new ImportAccountDataCSV();

                impActDataCSV.setAccountNumber(str[0]);
                impActDataCSV.setDUNSNumber(str[1]);
                impActDataCSV.setBusinessName(str[2]);
                impActDataCSV.setStateProvince(str[3]);
                impActDataCSV.setCountry(str[4]);
                impActDataCSV.setCurrent(Float.parseFloat(str[5]));
                impActDataCSV.setFrom1to30DaysPastDue(Float.parseFloat(str[6]));
                impActDataCSV
                        .setFrom31to60DaysPastDue(Float.parseFloat(str[7]));
                impActDataCSV
                        .setFrom61to90DaysPastDue(Float.parseFloat(str[8]));
                impActDataCSV
                        .setFrom91PlusDaysPastDue(Float.parseFloat(str[9]));
                /*
                 * impActDataCSV.setFrom91to120DaysPastDue(Float.parseFloat(str[9
                 * ]));
                 * impActDataCSV.setFrom121to150DaysPastDue(Float.parseFloat
                 * (str[10]));
                 * impActDataCSV.setMoreThan151DaysPastDue(Float.parseFloat
                 * (str[11]));
                 */

                importCSVList.add(impActDataCSV);

            }

            f.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return importCSVList;
    }

    // retrieving individual account wise details from csv file
    public ArrayList agingDataReadingAccountWiseCSVvalues(
            String uploadCSVFilesPath, int row) {

        try {

            List csvValuesSetList = importaccountDataReadingXLvalues(uploadCSVFilesPath);

            ImportAccountDataCSV impActDataCSV = (ImportAccountDataCSV) csvValuesSetList
                    .get(row);
            currentDollar = impActDataCSV.getCurrent();
            daysPastDue130 = impActDataCSV.getFrom1to30DaysPastDue();
            daysPastDue3160 = impActDataCSV.getFrom31to60DaysPastDue();
            daysPastDue6190 = impActDataCSV.getFrom61to90DaysPastDue();
            daysPastDue91120 = impActDataCSV.getFrom91to120DaysPastDue();
            daysPastDue121150 = impActDataCSV.getFrom121to150DaysPastDue();
            moreThan151DaysPastDue = impActDataCSV.getMoreThan151DaysPastDue();

            AccountWiseDataOfCSV.add(xlcurrentvalue = Math
                    .round(currentDollar * 100.0) / 100.0); // index-0
            AccountWiseDataOfCSV.add(xlDaysPastDue1to30 = Math
                    .round(daysPastDue130 * 100.0) / 100.0); // index-1
            AccountWiseDataOfCSV.add(xlDaysPastDue31to60 = Math
                    .round(daysPastDue3160 * 100.0) / 100.0); // index-2
            AccountWiseDataOfCSV.add(xlDaysPastDue61to90 = Math
                    .round(daysPastDue6190 * 100.0) / 100.0); // index-3
            AccountWiseDataOfCSV.add(xlDaysPastDue91to120 = Math
                    .round(daysPastDue91120 * 100.0) / 100.0); // index-4
            AccountWiseDataOfCSV.add(xlDaysPastDue121150 = Math
                    .round(daysPastDue121150 * 100.0) / 100.0); // index-5
            AccountWiseDataOfCSV.add(xlDaysPastDue151Day = Math
                    .round(moreThan151DaysPastDue * 100.0) / 100.0); // index-6

            // last Ac no vlaues
        } catch (Exception e) {
            e.printStackTrace();
        }
        return AccountWiseDataOfCSV;
    }

    // retrieving sum of values in a column
    public ArrayList accountNumberFromCSVFileForAging(String uploadCSVFilesPath) {

        try {

            // csvIterator = importCSVList.iterator();
            List csvValuesSetList = importaccountDataReadingXLvalues(uploadCSVFilesPath);
            csvIterator = csvValuesSetList.iterator();
            while (csvIterator.hasNext()) {
                ImportAccountDataCSV impActDataCSV = (ImportAccountDataCSV) csvIterator
                        .next();
                // accnumbersList.add(impActDataCSV.getAccountNumber());
                accountNumberList.add(impActDataCSV.getAccountNumber()); // array
                                                                         // index
                                                                         // -0

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return accountNumberList;
    }

    public ArrayList sumColumnWiseCSVFileDataForAging(String uploadCSVFilesPath) {

        try {
            ArrayList accountNumberList = accountNumberFromCSVFileForAging(uploadCSVFilesPath);
            List csvValuesSetList = importaccountDataReadingXLvalues(uploadCSVFilesPath);
            csvIterator = csvValuesSetList.iterator();
            for (int index = 0; index < accountNumberList.size(); index++) {
                ImportAccountDataCSV impActDataCSV = (ImportAccountDataCSV) csvIterator
                        .next();
                if (accountNumberList.get(index).equals(
                        impActDataCSV.getAccountNumber())) { // chk here

                    acCurrentDollar = acCurrentDollar
                            + impActDataCSV.getCurrent();
                    acDaysPastDue130 = acDaysPastDue130
                            + impActDataCSV.getFrom1to30DaysPastDue();
                    acDaysPastDue3160 = acDaysPastDue3160
                            + impActDataCSV.getFrom31to60DaysPastDue();
                    acDaysPastDue6190 = acDaysPastDue6190
                            + impActDataCSV.getFrom61to90DaysPastDue();
                    acDaysPastDue91Plus = acDaysPastDue91Plus
                            + impActDataCSV.getFrom91PlusDaysPastDue();
                    /*
                     * acDaysPastDue91120 =
                     * acDaysPastDue91120+impActDataCSV.getFrom91to120DaysPastDue
                     * (); acDaysPastDue121150 =
                     * acDaysPastDue121150+impActDataCSV
                     * .getFrom121to150DaysPastDue(); acMoreThan151DaysPastDue =
                     * acMoreThan151DaysPastDue
                     * +impActDataCSV.getMoreThan151DaysPastDue();
                     */

                }
            }

            acxlcurrentvalue = Math.round(acCurrentDollar * 100.0) / 100.0; // column
                                                                            // wise
                                                                            // sum
            acxlDaysPastDue1to30 = Math.round(acDaysPastDue130 * 100.0) / 100.0;
            acxlDaysPastDue31to60 = Math.round(acDaysPastDue3160 * 100.0) / 100.0;
            acxlDaysPastDue61to90 = Math.round(acDaysPastDue6190 * 100.0) / 100.0;
            acxlDaysPastDue91Plus = Math.round(acDaysPastDue91Plus * 100.0) / 100.0;
            /*
             * acxlDaysPastDue91to120 = Math.round(acDaysPastDue91120 * 100.0) /
             * 100.0; acxlDaysPastDue121150 = Math.round(acDaysPastDue121150 *
             * 100.0) / 100.0; acxlDaysPastDue151Day =
             * Math.round(acMoreThan151DaysPastDue * 100.0) / 100.0;
             */

            ColumnWiseSumOfCSV.add(acxlcurrentvalue); // array index -0
            ColumnWiseSumOfCSV.add(acxlDaysPastDue1to30); // array index -1
            ColumnWiseSumOfCSV.add(acxlDaysPastDue31to60); // array index -2
            ColumnWiseSumOfCSV.add(acxlDaysPastDue61to90); // array index -3
            ColumnWiseSumOfCSV.add(acxlDaysPastDue91Plus);
            /*
             * ColumnWiseSumOfCSV.add(acxlDaysPastDue91to120); //array index -4
             * ColumnWiseSumOfCSV.add(acxlDaysPastDue121150); //array index -5
             * ColumnWiseSumOfCSV.add(acxlDaysPastDue151Day);
             */// array index -6

        } catch (Exception e) {
            e.printStackTrace();
        }
        return ColumnWiseSumOfCSV;
    }

    public void addCSVFileValues(String uploadCSVFilesPath) throws Exception {

        try {
            importaccountDataReadingXLvalues(uploadCSVFilesPath);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
