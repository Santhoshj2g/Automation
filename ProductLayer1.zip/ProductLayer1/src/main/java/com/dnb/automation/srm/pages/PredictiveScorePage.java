package com.dnb.automation.srm.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;


/**********************************************************************************************
 * PredictiveScorePage.java - This program contains steps for 1. User clicks the
 * Predictive score tab 2. User checks the predictive score tab navigation 3.
 * User checks SSI-Rating value in Predictive score page 4. User checks
 * SER-Rating value in Predictive score page 5. User checks FSS-Percentile value
 * in Predictive score page 6. User checks the Dash-board page navigation for
 * next DUNS
 *
 * @author Joseph Dennison
 ***********************************************************************************************/

public class PredictiveScorePage extends PageObject {

    @FindBy(xpath = "//*[@id='wrapper']/div[6]/div[4]")
    private WebElementFacade PredictiveFrame;

    @FindBy(xpath = ".//*[@id='Predictive_Scores_section']/div[2]")
    private WebElementFacade predictiveScorePageFrame;

    @FindBy(xpath = "//*[@class='dashboard-container']//*[@class='supplierProfTabs']//*[@id='Predictive_Scores']/span/a")
    private WebElementFacade predictivescorelink;

    @FindBy(xpath = "//*[@class='SER_SSIClass']//*[@id='Predictive_Scores_SSI']/div//*[@class='CmpvalueContainer'] | //*[@id='Predictive_Scores_section']//div[2]//div//*[@class='SER_SSIClass']//ul//*[@id='Predictive_Scores_SSI'][contains(.,'Out of Business')]")
    private WebElementFacade predictiveScoreSSI;

    @FindBy(xpath = "//*[@class='SER_SSIClass']//*[@id='Predictive_Scores_SER']/div//*[@class='CmpvalueContainer'] | //*[@id='Predictive_Scores_section']//div[2]//div//*[@class='SER_SSIClass']//ul//*[@id='Predictive_Scores_SER'][contains(.,'Not Available')]")
    private WebElementFacade predictivescoreser;

    @FindBy(xpath = "//*[@class='SER_SSIClass']//*[@id='Predictive_Scores_FSS']/div//*[@class='CmpvalueContainer'] | //*[@id='Predictive_Scores_section']//div[2]//div//*[@class='SER_SSIClass']//ul//*[@id='Predictive_Scores_FSS'][contains(.,'Not Available')]")
    private WebElementFacade predictivescorefss;

    @FindBy(xpath = "//*[@class='SER_SSIClass']//*[@id='prescore_DNBSlider']/div//*[@class='CmpvalueContainer'] | //*[@id='Predictive_Scores_section']//div[2]//div//*[@class='SER_SSIClass']//ul//*[@id='prescore_DNB_Rating'][contains(.,'NQ')]")
    private WebElementFacade DnbRatingRiskIndicator;

    @FindBy(xpath = "//*[@class='SER_SSIClass']//*[@id='prescore_DNB_Rating'] | //*[@id='Predictive_Scores_section']//div[2]//div//*[@class='SER_SSIClass']//ul//*[@id='prescore_DNB_Rating'][contains(.,'NQ')] | //*[@id='Predictive_Scores_section']//div[2]//div//*[@class='SER_SSIClass']//ul//*[@id='prescore_DNB_Rating'][contains(.,'NQ-')]")
    private WebElementFacade DnbRating;

    @FindBy(xpath = "//*[@id='viabilityRating']//*[@class='score_divs']//*[@class='color_score_orange']//*[@id='Predictive_Score_Viability']")
    private WebElementFacade ViabScore;

    @FindBy(xpath = "//*[@id='Predictive_Score_Portfolio_Comparison']")
    private WebElementFacade PortfolioCompare;

    @FindBy(xpath = "//*[@id='Predictive_Score_Data_Depth']")
    private WebElementFacade DataDepthInd;

    @FindBy(xpath = "//*[@id='Predictive_Score_Company_Profile']")
    private WebElementFacade CompnayProfileVal;

    @FindBy(xpath = "//*[@class='short_passage']//*[@id='Predictive_Score_Financial_Data']")
    private WebElementFacade FinancialData;

    @FindBy(xpath = "//*[@class='short_passage']//*[@id='Predictive_Score_Trade_payments']")
    private WebElementFacade TradePayment;

    @FindBy(xpath = "//*[@class='short_passage']//*[@id='Predictive_Score_Company_Size']")
    private WebElementFacade CompanySize;

    @FindBy(xpath = "//*[@class='short_passage']//*[@id='Predictive_Score_Years_in_Business']")
    private WebElementFacade BusinessYears;

    @FindBy(xpath = "//*[@id='Predictive_Scores_section']//div[2]//div//*[@class='SER_SSIClass']//ul//li//h2/a[1][contains(.,'Failure Score (1-100)')]")
    private WebElementFacade FailureScoreNewNameCheck;

    @FindBy(xpath = "//*[@id='wrapper_header']//*[@class='header-tabs-container clearFix']//ul//*[@id='desktopMenu']/a")
    private WebElementFacade dashBoard;

    @FindBy(xpath = "//*[@id='wrapper_header']//*[@class='header-tabs-container clearFix']//ul//*[@id='alertsMenu']/a")
    private WebElementFacade alertMenu;

    @FindBy(xpath = "//*[@id='wrapper_header']//*[@class='header-tabs-container clearFix']//ul//*[@id='alertsMenu']//*[@id='alertInbox']/a")
    private WebElementFacade alertProfilepage;

    @FindBy(xpath = "//*[@id='Alerttabs-1']//*[@id='Inbox']//*[@class='workflow-alerts-detail clearFix']//*[@id='inbox_table']//*[@id='InboxBlock']//tr//td[3][contains(.,'Failure Score')]")
    private WebElementFacade alrtScoreNameCheck;

    @FindBy(xpath = "//*[@id='Alerttabs-1']/div")
    private WebElementFacade alertFrame;

    @FindBy(xpath = "//*[@id='Predictive_Scores_section']/div[2]/div[4]/div/div[1]/ul/li/h2/a[2]/img")
    private WebElementFacade GlossFSSNmeChk;

    @FindBy(xpath = "//*[@class='dashboard-container']//*[@class='history-detail border-bottom-radius']//*[@id='historyTable']//*[@id='history-results']")
    private WebElementFacade historyPageFrame;

    @FindBy(xpath = "//*[@class='dashboard-container']//*[@class='supplierProfTabs']//*[@id='History']//span//a[contains(@name,'j_id1308:j_id1314')]")
    private WebElementFacade historylink;

    @FindBy(xpath = "//*[@class='dashboard-container']//*[@class='history-detail border-bottom-radius']//*[@id='historyTable']//*[@id='history-results']//tr//td[2][contains(.,'Failure Score')]")
    private WebElementFacade FssnameChk;

    @FindBy(xpath = "html/body/span[81][contains(.,'Failure Score (1-100)')]")
    private WebElementFacade PredGlossNameVerify;

    @FindBy(xpath = ".//*[@id='wrapper']//*[@class='container']//*[@class='dashboard-container']//*[@class='page-heading']/h1")
    private WebElementFacade dashboardTitleEle;

    @FindBy(xpath = ".//*[@id='Predictive_Scores_section']/div[1]/h3")
    private WebElementFacade predictiveScoreSecEle;

    @FindBy(xpath = ".//*[@id='Predictive_Scores_section']/div[8]/span|.//*[@id='Predictive_Scores_section']/div/h3")
    private List<WebElement> predictiveScoreSectionEle;

  //  @FindBy(xpath=".//*[@id='update_rec']")
   // private WebElementFacade updateRecordbtn;
    
    @FindBy(name="updateRecord")
    private WebElementFacade updateRecordbtn;

    @FindBy(xpath=".//*[@id='update_rec_disabled']")
    private WebElementFacade UpdateRecordDisablebtn;

    @FindBy(xpath=".//*[@id='Predictive_Scores_FSS_Comment']")
    private WebElementFacade commelements;

    @FindBy(xpath=".//*[@id='Predictive_Scores_FSS_Comment']")
    private WebElementFacade CommentryTextinPS;

    @FindBy(xpath=".//*[@id='Predictive_Scores_SSI']")
    private WebElementFacade SSIinPS;

    @FindBy(xpath=".//*[@id='Predictive_Scores_SER']/div/div")
    private WebElementFacade SSIinPSvalue;

    private String commentryTable =".//*[@id='Predictive_Scores_section']/div[2]/div[4]/div/div[2]";
    private String SERBackcolorinPS=".//*[@id='Predictive_Scores_SER']/div[contains(@style,'Slider/%s.png')]";
    private String DnbRatingIndc;
    private String DnbRatg;
    private String SsiRat;
    private String SERRating;
    private String FSSRatingValue;
    private String FailureScreNmeChk;
    private String AltFailureScreNmeChk;
    private String historyeFailureScreNmeChk;
    private String PredFssGlosnameCk;
    private String ViabScor;
    private String PortfolCmp;
    private String DatadepthIndic;
    private String CompanyPflVal;
    private String FinancialDataStat;
    private String TradepaymentVal;
    private String CompanySizestatus;
    private String BusinessYearsStatus;

    private ArrayList<String> predictiveScoreSectionNames = new ArrayList<String>();



    // Click the Predictive score tab

    public void clickPredictivescoreLinkButton() throws Exception {
        try {
            UIHelper.waitForPageToLoad(getDriver());
            UIHelper.scrollWindowDown(getDriver());
            predictivescorelink.waitUntilEnabled();
            UIHelper.highlightElement(getDriver(), predictivescorelink);
            predictivescorelink.click();
            UIHelper.waitForPageToLoad(getDriver());
        } catch (Exception e) {

        }
    }



    // Verify Predictive score tab navigation

    public void navigateToPredictiveName() {
        PredictiveFrame.waitUntilPresent();
    }

    public void predictiveScorePageCheck() {
        try {
            if (element(predictiveScorePageFrame).isDisplayed()) {
                UIHelper.highlightElement(getDriver(), predictiveScoreSecEle);
                // element(predictivescorelink).isPresent();
                // element(predictivescorelink).click();
                // element(predictiveScorePageFrame).isDisplayed();
            }else
            {
                UIHelper.highlightElement(getDriver(), predictivescorelink);
                UIHelper.mouseOverandclickanElement(getDriver(), predictivescorelink);

            }
        } catch (Exception e) {

        }
    }



    // Verify SER Value in Predictive score page

    public String predictiveSerValue() throws Exception {
        try {
            if (element(predictivescoreser).isPresent()) {
                SERRating = predictivescoreser.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), predictivescoreser);
            }

        } catch (Exception e) {

        }
        return SERRating;
    }



    // Verify FSS Percentile Value in Predictive score page

    public String predictiveFSSValue()throws Exception {
        try {
            if (element(predictivescorefss).isPresent()) {
                FSSRatingValue = predictivescorefss.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), predictivescorefss);
            }
        } catch (Exception e) {

        }
        return FSSRatingValue;
    }



    // Verify SSI Value in Predictive score page

    public String predictiveSsiValue() throws Exception {
        try {
            if (element(predictiveScoreSSI).isPresent()) {
                UIHelper.waitForPageToLoad(getDriver());
                SsiRat = predictiveScoreSSI.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), predictiveScoreSSI);
            }
        } catch (Exception e) {

        }
        return SsiRat;
    }



    // Verify DNB Rating Risk Indicator value in Predictive score page

    public String PredictiveDnbRatRiskIndicValue() throws Exception {
        try {
            DnbRatingRiskIndicator.waitUntilPresent();
            if (element(DnbRatingRiskIndicator).isPresent()) {
                DnbRatingIndc = DnbRatingRiskIndicator.getText().toString()
                        .trim();
                UIHelper.highlightElement(getDriver(), DnbRatingRiskIndicator);
            }
        } catch (Exception e) {

        }

        return DnbRatingIndc;
    }



    // Verify DNB Rating value in Predictive score page

    public String PredictiveDnbRatValue() throws Exception {
        try {
            DnbRating.waitUntilPresent();
            if (element(DnbRating).isPresent()) {
                DnbRatg = DnbRating.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), DnbRating);
            }
        } catch (Exception e) {

        }

        return DnbRatg;
    }



    // Verify Viability Score value in Predictive score page

    public String verifyPredictivepageViabilityVal() throws Exception {
        try {
            ViabScore.waitUntilPresent();
            if (element(ViabScore).isPresent()) {
                ViabScor = ViabScore.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), ViabScore);
            }
        } catch (Exception e) {

        }

        return ViabScor;
    }



    // Verify Portfolio Comparison score in Predictive score page

    public String PredictivePortfolioComparisonScore() throws Exception {
        try {
            PortfolioCompare.waitUntilPresent();
            if (element(PortfolioCompare).isPresent()) {
                PortfolCmp = PortfolioCompare.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), PortfolioCompare);
            }
        } catch (Exception e) {

        }

        return PortfolCmp;
    }



    // Verify Data Depth Indicator value in Predictive score page

    public String verifyPredictivepageDataDepthIndiVal() throws Exception {
        try {
            DataDepthInd.waitUntilPresent();
            if (element(DataDepthInd).isPresent()) {
                DatadepthIndic = DataDepthInd.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), DataDepthInd);
            }
        } catch (Exception e) {

        }

        return DatadepthIndic;
    }



    // Verify Company Profile value in Predictive score page

    public String PredictiveCompanyProfileScore() throws Exception {
        try {
            CompnayProfileVal.waitUntilPresent();
            if (element(CompnayProfileVal).isPresent()) {
                CompanyPflVal = CompnayProfileVal.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), CompnayProfileVal);
            }
        } catch (Exception e) {

        }

        return CompanyPflVal;
    }



    // Verify Financial Data Status for viability rating in Predictive score page

    public String verifyPredictivepageFinancialStatus() throws Exception {
        try {
            FinancialData.waitUntilPresent();
            if (element(FinancialData).isPresent()) {
                FinancialDataStat = FinancialData.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), FinancialData);
            }
        } catch (Exception e) {

        }

        return FinancialDataStat;
    }



    // Verify Trade payments value in Predictive score page

    public String verifyTradepaymentVal() throws Exception {
        try {
            TradePayment.waitUntilPresent();
            if (element(TradePayment).isPresent()) {
                TradepaymentVal = TradePayment.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), TradePayment);
            }
        } catch (Exception e) {

        }

        return TradepaymentVal;
    }




    // Verify Company Size status value in Predictive score page

    public String verifyCompanySizeStatus() throws Exception {
        try {
            CompanySize.waitUntilPresent();
            if (element(CompanySize).isPresent()) {
                CompanySizestatus = CompanySize.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), CompanySize);
            }
        } catch (Exception e) {

        }

        return CompanySizestatus;
    }



    // Verify Business years status in Predictive score page

    public String verifyBusinessYearsVal() throws Exception {
        try {
            BusinessYears.waitUntilPresent();
            if (element(BusinessYears).isPresent()) {
                CompanySizestatus = BusinessYears.getText().toString().trim();
                UIHelper.highlightElement(getDriver(), BusinessYears);
            }
        } catch (Exception e) {

        }

        return CompanySizestatus;
    }



    // Verify the Failure score name change in Predictive page

    public String predScorenameChange() throws Exception {
        try {
            if (element(FailureScoreNewNameCheck).isPresent()) {
                FailureScreNmeChk = FailureScoreNewNameCheck.getText()
                        .toString().trim();
                UIHelper.highlightElement(getDriver(), FailureScoreNewNameCheck);
            }

        } catch (Exception e) {

        }
        return FailureScreNmeChk;

    }


    // Verify alert profile navigation for checking failure Score name as
    // Failure Score (1-100)

    public void alertProfilePage() throws Exception {
        try {
            if (element(alertMenu).isPresent()) {
                UIHelper.highlightElement(getDriver(), alertMenu);
                alertMenu.click();
                UIHelper.highlightElement(getDriver(), alertProfilepage);
                alertProfilepage.click();
                element(alertFrame).isDisplayed();
            }
        } catch (Exception e) {

        }
    }



    // Verify history tab navigation for checking failure Score name as Failure
    // Score (1-100)

    public void historyPage() throws Exception {
        try {
            if (element(historyPageFrame).isPresent()) {
                UIHelper.highlightElement(getDriver(), historylink);
                element(historylink).isPresent();
                element(historylink).click();
                element(historyPageFrame).isDisplayed();
            }
        } catch (Exception e) {

        }
    }



    // Verify the Failure score name change in Alert Profile page

    public String AlertFailureScorenameChange() throws Exception {
        try {
            if (element(alrtScoreNameCheck).isPresent()) {
                element(alrtScoreNameCheck).waitUntilVisible();
                UIHelper.highlightElement(getDriver(), alrtScoreNameCheck);
                AltFailureScreNmeChk = alrtScoreNameCheck.getText().toString()
                        .trim();
            }
        } catch (Exception e) {

        }
        return AltFailureScreNmeChk;
    }



    // Verify the Failure score name change in history tab

    public String historyFailureScorenameChange() throws Exception {
        try {
            if (element(FssnameChk).isPresent()) {
                element(FssnameChk).waitUntilVisible();
                UIHelper.highlightElement(getDriver(), FssnameChk);
                historyeFailureScreNmeChk = FssnameChk.getText().toString()
                        .trim();
            }
        } catch (Exception e) {

        }
        return historyeFailureScreNmeChk;
    }



    // Click the Failure score (1-100)GLosary button in predictive score tab

    public void GlosaryPredFSSbutton() throws Exception {
        try {
            String mainwindow = getDriver().getWindowHandle();
            GlossFSSNmeChk.click();

            for (String winHandle : getDriver().getWindowHandles()) {
                getDriver().switchTo().window(winHandle);
                getDriver().manage().window().maximize();
                getDriver().manage().timeouts()
                        .implicitlyWait(30, TimeUnit.SECONDS);
                UIHelper.highlightElement(getDriver(), GlossFSSNmeChk);
            }
            getDriver().close();
            getDriver().switchTo().window(mainwindow);

        } catch (Exception e) {

        }
    }



    // Verify the FailureScore (1-100) name of glossary change in predictive
    // score page

    public String predFailureScorenameChange() throws Exception {
        try {
            if (element(PredGlossNameVerify).isPresent()) {
                PredFssGlosnameCk = PredGlossNameVerify.getText().toString()
                        .trim();
                UIHelper.highlightElement(getDriver(), PredGlossNameVerify);
            }
        } catch (Exception e) {

        }
        return PredFssGlosnameCk;

    }


    // Verify Dash-board navigation for next DUNS number

    public void dashBoardPage() throws Exception {
        try {
            if (element(dashBoard).isPresent()) {
                UIHelper.waitForPageToLoad(getDriver());
                UIHelper.highlightElement(getDriver(), dashBoard);
                dashBoard.click();
                UIHelper.waitForPageToLoad(getDriver());
                dashboardTitleEle.waitUntilPresent();
            }
        } catch (Exception e) {

        }
    }



    //Click Predictive score tab

    public void clickPredictiveScoreTab()
    {
        try{
            UIHelper.waitForPageToLoad(getDriver());
            UIHelper.highlightElement(getDriver(), predictivescorelink);
            predictivescorelink.click();
            predictiveScoreSecEle.waitUntilPresent();

        }catch(Exception e){

        }
    }



    //Get Predictive scores section name

    public ArrayList<String> getPredectiveScoresSectionName()
    {
        for(WebElement element:predictiveScoreSectionEle)
        {
            predictiveScoreSectionNames.add(element.getText());
        }
        return predictiveScoreSectionNames;
    }

    //Click Update Record button
    public void clickUpdateRecordbtn()
    {
        try{
            if(updateRecordbtn.isEnabled()){
                UIHelper.waitForPageToLoad(getDriver());
                UIHelper.highlightElement(getDriver(), updateRecordbtn);
                updateRecordbtn.click();
                waitFor(5000).milliseconds();
                UIHelper.waitForPageToLoad(getDriver());
            }
            else
            {
            	System.out.println("Update record button is disabled..checking scores");
            }
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }



    public String[] verifyCommentry() {
        String[] actual = null;
        List<WebElementFacade> commentryText = find(By.xpath(commentryTable));
        if (!commentryText.isEmpty()) {
            for (int i = 0; i <= commentryText.size(); i++) {
                WebElementFacade actualCommentry = find(By.xpath(commentryTable.replace("num",String.valueOf(i))));
                UIHelper.highlightElement(getDriver(), actualCommentry);
                actual[i] = actualCommentry.getText().toString();
            }
        }
        return actual;
    }

    public boolean verifyPredictiveSSI() {
        boolean result=false;
        if(SSIinPS.isPresent())
        {
            String actual= SSIinPSvalue.getText();
            String actual1=SSIinPS.getText();
            if((!actual.equalsIgnoreCase("not available")) || (!actual.equalsIgnoreCase("not available"))){
                result=true;
            }else {
                result=false;
            }
        }
        return result;
    }



    public String verifySERBackColor(String SERBackColor)
    {
        String actual="";
        SERBackcolorinPS=String.format(SERBackcolorinPS, SERBackColor);
        WebElementFacade productBackColor = find(By.xpath(SERBackcolorinPS));
        if(productBackColor.isPresent())
        {
            UIHelper.highlightElement(getDriver(), productBackColor);
            actual=SERBackColor;
        }else{
            actual="";
        }

        return actual;
    }



	/*private String getPath(String xpath, int i)
	{
		String tempText= String.format(xpath, i);
		String value= UIHelper.getTextvalue(getDriver(), tempText);
				
		return value;
	}*/
}


	