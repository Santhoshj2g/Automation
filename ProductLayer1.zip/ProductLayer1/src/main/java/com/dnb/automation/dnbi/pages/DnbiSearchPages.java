package com.dnb.automation.dnbi.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;




public class DnbiSearchPages extends PageObject {
	
	
	
	
	@FindBy(xpath = "//*[@id='main']//*[@class='compHome_newFolder']//input[@value='Create New Folder']")
    private WebElementFacade createNewFolderBtn;
	
	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='quickSearchFld']")
	private WebElementFacade searchmain;

	@FindBy(xpath = "//div[@class='Search_Criteria search_searchCriteria']//*[@id='folder_bar']//a[contains(text(),'Search Now')]")
    private WebElementFacade buttonSearch;
	
	
	@FindBy(xpath = "//*[@id='main']/div/table/tbody/tr/td[1]/span/a")
    private WebElementFacade clickReport;
	
	
	@FindBy(xpath = "//div[@id='serach_criteria']/ul/li[1]/span[@id='Company']")
	private WebElementFacade dunscompany;
	
	@FindBy(xpath = "//table[@class='results full']//tr/th[2]")
	private WebElementFacade type;
	
	@FindBy(xpath = "//table[@class='results full']//tr/th[3]")
	private WebElementFacade CompanyName;
	
	@FindBy(xpath = "//table[@class='results full']//tr/th[4]")
	private WebElementFacade Preview;
	
	@FindBy(xpath = "//table[@class='results full']//tr/th[5]")
	private WebElementFacade LocationType;
	
	@FindBy(xpath = "//table[@class='results full']//tr/th[4]")
	private WebElementFacade CanadianLocationType;
	
	@FindBy(xpath = "//table[@class='results full']//tr/th[5]")
	private WebElementFacade CanadianTradeStyle;
	
	@FindBy(xpath = "//table[@class='results full']//tr/th[6]")
	private WebElementFacade CanadianOptions;
	
	@FindBy(xpath = "//table[@class='results full']//tr/th[6]")
	private WebElementFacade tradeStyle;
	
	@FindBy(xpath = "//table[@class='results full']//tr/th[7]")
	private WebElementFacade SIC ;
	
	@FindBy(xpath = "//table[@class='results full']//tr/th[8]")
	private WebElementFacade Employees;
	
	@FindBy(xpath = "//table[@class='results full']//tr/th[contains(text(),'Options')]")
	private WebElementFacade Options;
	
	@FindBy(xpath = "//table[@class='results full']//tr//th/a[contains(text(),'Options')]")
	private WebElementFacade linkOptions;
	
	@FindBy(xpath ="//table[@class='results full']//tr/td[2]//a/span")
	private WebElementFacade dunsNumMatch;
	
	@FindBy(xpath ="//*[@id='folder_bar']//div[@class='matchesResult']/strong")
	private WebElementFacade foldervalue;			
	
	@FindBy(xpath ="//table[@class='results full']//tr[1]//strong")
	private WebElementFacade companyValVerify;
	
	/***Investigation** start*/
	
	@FindBy(xpath ="//*[@id='quickSearchForm']//*[@id='quickSearchFld']")
	private WebElementFacade quickCompanyName;
	
	@FindBy(xpath="//*[@id='quickSearchForm']//*[@id='companyQSState']")
	private WebElementFacade quickStateName;
	
	@FindBy(xpath="//*[@id='quickSearchForm']//*[@id='search_fields_basic']//*[@value='Search']")
	private WebElementFacade quickSearchBttn;
	
	
	@FindBy(xpath ="//*[@id='main']//*[@id='SearchResultsForm']//*[@class='Search_Criteria search_searchCriteria']//*[@class='search_FloatWidth']//*[@class='search_Width600']/div/strong")
	private WebElementFacade messageInvestigation;
	
	@FindBy(xpath="//*[@id='main']//*[@id='SearchResultsForm']//*[@class='Search_Criteria search_searchCriteria']//*[@class='search_FloatWidth']//*[@class='search_Width600']//div//table//tbody//tr//td//a//strong[contains(text(),'Order investigation from D&B')]")
	private WebElementFacade OrderInvestigationSearch1;
	
	@FindBy(xpath="//*[@id='main']//*[@id='SearchResultsForm']//*[@class='Search_Criteria search_searchCriteria']//*[@class='search_FloatWidth']//*[@class='search_Width600']//div//table//tbody//tr//td//strong//a[contains(text(),'Search Small Business Risk Insight Database')]")
	private WebElementFacade SBRISearchLink;
	
	@FindBy(xpath="//*[@id='breadcrumb']/li[contains(text(),'Search Small Business Risk Insight')]")
	private WebElementFacade SBRISearchPage;
		
	@FindBy(xpath="//*[@id='main']//*[@id='page_title_links']/h2")
	private WebElementFacade CompInvReqpage;
	
	@FindBy(xpath="//*[@id='main']//*[@class='widget_form']/table[1]/tbody/tr[2]/td[2]//*[@id='CompanyName']")
	private WebElementFacade InvCompanyName;
	
	@FindBy(xpath="//*[@id='main']//*[@class='widget_form']/table[1]/tbody/tr[4]/td[2]//*[@id='BizInfo-StreetAddress']")
	private WebElementFacade AddressFrom ;
	
	@FindBy(xpath="//*[@id='main']//*[@class='widget_form']/table[1]/tbody/tr[5]/td[2]//*[@id='BizInfo-City']")
	private WebElementFacade CityForm ;
	
	@FindBy(xpath="//*[@id='main']//*[@class='widget_form']/table[1]/tbody/tr[6]/td[2]//*[@id='state']")
	private WebElementFacade StateForm ;
	
	@FindBy(xpath="//*[@id='main']//*[@class='widget_form']/table[2]/tbody/tr[1]/td[2]//*[@class='invest_txtArea']")
	private WebElementFacade AddInfoForm ;
	
	@FindBy(xpath="//*[@id='main']//*[@class='widget_form']/table[3]/tbody/tr/td[2]//*[@id='YourName']")
	private WebElementFacade UrNameForm ;
	
	@FindBy(xpath="//*[@id='main']//*[@class='widget_form']/table[4]/tbody/tr/td[2]//*[@id='YourPhone']")
	private WebElementFacade UrPhoneForm ;
	
	@FindBy(xpath="//*[@id='main']//*[@class='widget_form']/div//*[@value='Order']")
	private WebElementFacade OrderBttnForm;
	
	@FindBy(xpath="//*[@id='main']//*[@id='page_title_links']/h2")
	private WebElementFacade InvConfimPage;
	
	@FindBy(xpath="//*[@id='endorsement_title']//*[@class='frmField']//input")
	private WebElementFacade PrePopEndorsementInv ;
	
	@FindBy(xpath="//*[@id='main']//*[@class='widget_form']//*[@class='frmField']//*[@id='CompanyName']")
	private WebElementFacade PreInvFormCompNameInv ;
	
	@FindBy(xpath="//*[@id='main']//*[@class='widget_form']//*[@id='YourName']")
	private WebElementFacade PreYourNameInv ;
	
	@FindBy(xpath="//*[@id='main']//*[@class='widget_form']//*[@id='YourPhone']")
	private WebElementFacade PreYourPhoneInv ; 
	 
	
	/***Investigation** end*/
	
	@FindBy(xpath ="//table[@class='results full']//tr[1]/td[2]/strong")
	private WebElementFacade companyReasonCodeVerify;
	
	@FindBy(xpath ="//table[@class='results full']//tr[1]/td[2]")
	private WebElementFacade companyRegistrationNoVerify;
	
	@FindBy(xpath ="//*[@id='serach_criteria']//*[@id='Reason Code']")
	private WebElementFacade reasonCodenSearchPage;

	@FindBy(xpath ="//table[@class='results full']//tr[1]/td[3]")
	private WebElementFacade phoneNumValVerify;

	@FindBy(xpath ="//table[@class='results full']//tr/th[4]")
	private WebElementFacade folders;

	@FindBy(xpath ="//table[@class='results full']/tbody/tr/td[5]")
	private WebElementFacade cellExecutiveName;
	
	@FindBy(xpath ="//table[@class='results full']//tr/th[6]")
	private WebElementFacade dateCreated;
		
	@FindBy(xpath = "//table[@class='results full']//tr//a[contains(text(),'Options')]")
	private WebElementFacade compOptions;
	
//	@FindBy(xpath = "//table[@class='results full']//tr/th[7]")
//	private WebElementFacade compOptions;
	
	@FindBy(xpath = "//*[@id='header_mainApp']//li//a[contains(.,'Companies')]")
    private WebElementFacade CompaniesTabEle;
	
	
	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='quickSearchFld']")
    private WebElementFacade searchCompBox;
	
	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='companyQSState']")
    private WebElementFacade searchStateDropdown;	
	
	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='quickSearchForm']//*[@value='Search']")
    private WebElementFacade searchBtn;
	
	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='page_title']//*[text()='Search Results']")
    private WebElementFacade searchResultsConatinerEle;	

    @FindBy(xpath = "//table[@class='results full']/tbody/tr")
    private WebElementFacade firstSearchItemEle;
    
    @FindBy(xpath = "//*[@id='header_mainApp']//a[text()='Dashboard']")
    private WebElementFacade disHref;
    
    @FindBy(xpath = "//*[@id='folder_bar']//a[contains(.,'Search Now')]")
    private WebElementFacade searchNowBtnEle;

    @FindBy(xpath = "//form[@id='location_search']//table//td/input[@name='Search']")
    private WebElementFacade btnLocationSearch;

    @FindBy(xpath = "//form[@id='executive_search']//table//td/input[@name='Search']")
    private WebElementFacade btnExecutiveSearch;

    @FindBy(xpath = "//*[@id='autoSug']")
    private WebElementFacade autoSuggest;
       
    
    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='quicksearch_more_options' and contains(text(),'Fewer')] | //*[@class='outerDiv']//*[@id='search_box']//*[@class='moreOpt']//*[@id='quicksearch_more_options' and contains(text(),'More')]")
    private WebElementFacade fewerORMoreOptionsEle;
    
    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='quicksearch_more_options' and contains(text(),'Fewer')]")
    private WebElementFacade fewerOptionsEle;
    
    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='quicksearch_more_options' and contains(text(),'More')]")
    private WebElementFacade MoreOptionsEle;

    @FindBy(xpath = "//div[@id='search_fields_expanded']//a[contains(text(),'Location Search')]")
    private WebElementFacade locationSearch;

    @FindBy(xpath = "//div[@id='search_fields_expanded']//a[contains(text(),'Executive Search')]")
    private WebElementFacade ExecutiveSearch;
    
    @FindBy(xpath = "//div[@id='search_fields_expanded']//a[contains(text(),'Advanced Search')]")
    private WebElementFacade AdvancedSearch;
    
    @FindBy(xpath = "//div[@id='search_fields_expanded']//a[contains(text(),'Company Search')]")
    private WebElementFacade CompanySearch;    

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@class='moreOpt']//*[@id='quicksearch_more_options' and contains(text(),'More')]")
    private WebElementFacade companySearchmoreoptionsMore;
    
    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@class='moreOpt']//*[@id='quicksearch_more_options' and contains(text(),'Fewer')]")
    private WebElementFacade searchFewerOptionsEle;  
    
    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields_expanded']//*[@id='search_toc']//*[contains(text(),'Company')]")
    private WebElementFacade companySearchTab;
    
    @FindBy(xpath="//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields_expanded']//*[@id='search_toc']//*[contains(text(),'Location')]")
    private WebElementFacade locationSearchTab;
    
    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='international_search_table']//*[@id='BizInfo-BusinessName']")
    private WebElementFacade companySearchCompanyName;
    
   @FindBy(xpath ="//table[@id='international_search_table']//tr//*[@id='BizInfo-BusinessName']")
   private WebElementFacade compNametable;
   
   @FindBy(xpath ="//form[@id='international_search']//table//tr/td[2]/input[@value='Reset Fields']")
   private WebElementFacade resetbutton;

   @FindBy(xpath ="//form[@id='location_search']//table//td/input[@name='reset']")
   private WebElementFacade locResetFieldsButton;

   @FindBy(xpath ="//form[@id='location_search']//table//tr//input[@value='Reset Fields']")
   private WebElementFacade locationResetFieldsBtn;

   @FindBy(xpath ="//form[@id='executive_search']//table//tr//input[@value='Reset Fields']")
   private WebElementFacade executiveResetFieldsBtn;

   @FindBy(xpath = "//table[@id='international_search_table']//*[@id='BizInfo-StreetAddress']")
   private WebElementFacade Address;

   @FindBy(xpath = "//form[@id='executive_search']//table//tr//input[@name='companyExecutiveAddress']")
   private WebElementFacade ExecutiveAddress;

   @FindBy(xpath = "//form[@id='executive_search']//table//tr//input[@name='companyExecutiveCity']")
   private WebElementFacade ExecutiveTown;

   @FindBy(xpath = "//table[@id='international_search_table']//*[@id='BizInfo-City']")
   private WebElementFacade city;

   @FindBy(xpath = "//form[@id='location_search']//table//input[@id='BizInfo-StreetAddress']")
   private WebElementFacade txtStreetAddress;

   @FindBy(xpath = "//form[@id='executive_search']//table//input[@id='searc_exec_firstName']")
   private WebElementFacade txtFirstName;

   @FindBy(xpath = "//form[@id='executive_search']//table//input[@id='searc_exec_lastName']")
   private WebElementFacade txtLastName;

   @FindBy(xpath = "//form[@id='executive_search']//table//input[@id='searc_exec_initial']")
   private WebElementFacade txtInitial;

   @FindBy(xpath = "//form[@id='location_search']//table//input[@id='BizInfo-City']")
   private WebElementFacade txtTown;

   @FindBy(xpath = "//form[@id='location_search']//table//input[@id='BizInfo-Zip']")
   private WebElementFacade txtLocZip;

   @FindBy(xpath = "//table[@id='international_search_table']//select[@id='BizInfo-State']")
   private WebElementFacade companyState;
   
   @FindBy(xpath = "//table[@id='international_search_table']//select[@id='BizInfo-ReasonCode']")
   private WebElementFacade reasonCodeDropDown;
   
   
   
   @FindBy(xpath = "//table[@id='international_search_table']//*[@id='BizInfo-ZIPCode']")
   private WebElementFacade zip;
   
   @FindBy(xpath = "//table[@id='international_search_table']//*[@id='BizInfo-DUNS']")
   private WebElementFacade DunsNumber;

   @FindBy(xpath = "//table[@id='international_search_table']//input[@name='intcompanyPhoneNo']")
   private WebElementFacade phonenumber;

//   @FindBy(xpath ="//table[@id='international_search_table']//tr[3]/td[3]/table//tr[3]/td[2]/input[@name='intcompanyPhoneNo']")
//   private WebElementFacade phonenumber;
    
   @FindBy(xpath = "//table[@id='international_search_table']//tr[3]/td[3]/table//tr[4]/td[2]/input[@name='searchSnapShot']")
   private WebElementFacade checkboxsnapshot;
   
   @FindBy(xpath = "//input[@id='searchEndorsement']")
   private WebElementFacade billingreference;
  
    @FindBy(xpath = "//select[@id='BizInfo-Country']")
    private WebElementFacade country;
    
    @FindBy(xpath = "//table[@class='results full']//tr/th[4]")
    private WebElementFacade folderdetailssearch;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*//*[@id='search_fields']//*[@class='frm_search1']//input[@name='Search']")
    private WebElementFacade companySearchButton;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='international_search_table']//*[@id='BizInfo-Country']")
    private WebElementFacade companySearchCountryName;
    
    @FindBy(xpath = "//*[@class='outerDiv']//*[@class='clear']//table//tbody//tr//a[contains(@href,'javascript:showCompany')]")
    private WebElementFacade searchResultliveReport;
    
    private String liveReportPage="//*[@id='duns']//li[contains(@class,'first')]";
    
	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@id='pp_side_icon']//*[@class='saveToFolder_ecf']")
	private WebElementFacade saveToPortfolio;
	
	@FindBy(xpath="//*[@class='outerDiv']//*[@id='main']//*[contains(@class,'results full')]//tbody/tr/td//*[contains(@class,'tabText')]")
	private WebElementFacade warnigMessage;
	
	@FindBy(xpath="//*[@id='search_fields']//*[@id='location_search']/b | //*[@id='search_fields']//*[@id='executive_search']/b")
	private WebElementFacade warnigLocationMessage;
	
	@FindBy(xpath="//*[@id='main']/div/table/tbody/tr[1]/td[1]/span/a/span")
	private WebElementFacade searchPageResultDunslink;
	//*[@class='results full']/tbody/tr[1]/td[1]/span/a
	
	@FindBy(xpath="//*[@id='main']//*[@class='clear']//*[@class='results full']/tbody/tr/td[2]/span/a[contains(text(),'D&B Live Report Snapshot')]")
	private WebElementFacade searchSnapshotlink;
	
	@FindBy(xpath="//*[@id='main']//*[@id='pageHead']//*[@id='page_title']/h2[contains(text(),'International Request')]")
	private WebElementFacade internationalPage;
	
	@FindBy(xpath="//*[@class='entcommon_OrderPadding']/div[1]//*[@id='options']/div[4]//*[@value='View Report']")
	private WebElementFacade viewRepbttn;
	
	@FindBy(xpath="//*[@class='ecf_header']//*[@id='entity_header']/h2")
	private WebElementFacade LiveRepTitleNameIntl;
	
	/*----------------------EU ECF Val Elements --------------------------------------------*/
	
	@FindBy(xpath="//*[@id='ecf_toc_main']//*[@id='ecf_toc1']//a[contains(text(),'Company Summary')]")
	private WebElementFacade EUCompanySummary;
	
	@FindBy(xpath="//*[@class='widget wideWidget']/h2[contains(text(),'Score Bar')]")
	private WebElementFacade EUCompSumScoreBar;
	
	@FindBy(xpath="//*[@class='widget wideWidget']/div[2]")
	private WebElementFacade EUCompScoreValues;
	
	@FindBy(xpath="//*[@id='ecf_toc_main']//*[@id='ecf_toc1']//a[contains(text(),'Corporate Linkage')]")
	private WebElementFacade EUCorporateLinkage;
	
	@FindBy(xpath="//*[@class='TxtLink']/a[contains(text(),'View Dynamic Family Tree Information')]")
	private WebElementFacade EUCorpViewDynFamilyTree;
	
	@FindBy(xpath="//*[@id='cl_widget_div']/div/h3[contains(text(),'Branches (Domestic)')]")
	private WebElementFacade EUCorpViewBrachHeader;
	
	/**New CorpLinkage**/
	
	@FindBy(xpath ="//*[@class='cl-tabs']/a[contains(text(),'List')]")
	private WebElementFacade corplinkList;

	@FindBy(xpath ="//*[@class='cmpn-header-dtl']//*[@class='dtl-col']//*[@class='dtl-key'][contains(text(),'Companies')]")
	private WebElementFacade corplinkCompanies;

	@FindBy(xpath ="//*[@class='cmpn-header-dtl']//*[@class='dtl-col']//*[@class='dtl-key'][contains(text(),'Subsidaries (International)')]")
	private WebElementFacade corplinkSubsidaries;	
	
	/**New CorpLinkage**/
	
	@FindBy(xpath ="//*[@class='action_header']//*[@class='actionButtons']//*[@value='Create Application']")
	private WebElementFacade CreditAppButtn;
	
	@FindBy(xpath ="//*[@class='action_header']//*[@class='actionButtons']//*[@value='Save a Snapshot']")
	private WebElementFacade CreditSnapShotButtn;
	
	@FindBy(xpath ="//*[@class='iframe_modal']//form[@name='noteForm']//*[@class='results full']//*[@id='notation']")
	private WebElementFacade SnapForminput;
	
	@FindBy(xpath ="//*[@class='iframe_modal']//*[@class='noteerror_ecf']//*[@id='type']")
	private WebElementFacade visibilityType;
			
	@FindBy(xpath ="//*[@class='iframe_modal']//form[@name='noteForm']//*[@class='modal_buttons']//*[@id='ecf_note_submit']")
	private WebElementFacade SnapButtninput;
	
	@FindBy(xpath ="//*[@class='frmSecEdit']/h3")
	private WebElementFacade CreditAppCompInfoPage;
	
	@FindBy(xpath="//*[@class='loadnextbtn']")
	private WebElementFacade loadNextBttn;
	
	@FindBy(xpath="//*[@id='widget_form_BusinessInformationPage']//*[@class='frmSecEdit']//*[@class='form_leftMargin']/tbody//*[@class='frmField']//*[@name='FQ_BizProfile-ContactE-mailAddress']")
	private WebElementFacade EmailIDBox;
	
	@FindBy(xpath="//*[@class='Submitbtn']")
	private WebElementFacade EcfSubmitBttn;
	
	@FindBy(xpath="//*[@id='ecf_toc_main']//*[@id='ecf_toc1']/li/a[contains(text(),'D&B Data Overview')]")
	private WebElementFacade DNBDataOverviewTab;
	
	@FindBy(xpath="//*[@id='widget_container']//*[@id='ecf_widget_container']//*[@class='widget_full']//*[@class='widget_ecfbox']")
	private WebElementFacade DNBDataOverviewValues;
	
	
	
	
	
	
	@FindBy(xpath="//*[@id='ecf_toc_main']//*[@id='ecf_toc1']//a[contains(text(),'Predictive Scores')]")
	private WebElementFacade EUPredictiveScore;
	
	@FindBy(xpath="//*[@id='DBMAXCREDITECF']/div[1]//*[@class='fabprd_widget_ecfbox']/h3[contains(text(),'D&B Maximum Credit')]")
	private WebElementFacade EUPredictiveDnBMaximumCredit;
	
	@FindBy(xpath="//*[@id='DBRATINGECF']/div[1]//*[@class='fabprd_widget_ecfbox']/h3[contains(text(),'D&B Rating')]")
	private WebElementFacade EUPredictiveDnBRating;
	
	@FindBy(xpath="//*[@id='DBFAILSCRECF']/div[1]//*[@class='fabprd_widget_ecfbox']/h3[contains(text(),'D&B Failure Score')]")
	private WebElementFacade EUPredictiveFailureScore;
	
	@FindBy(xpath="//*[@id='ecf_toc_main']//*[@id='ecf_toc1']//a[contains(text(),'Trade Payments')]")
	private WebElementFacade EUTradePayement;
	
	@FindBy(xpath="//*[@id='PYDX_UK']/div[1]//*[@class='fabprd_widget_ecfbox']/h3")
	private WebElementFacade EUTradePaymentInformation;
	
	@FindBy(xpath="//*[@id='PAYEXP_UK']/div[1]//*[@class='fabprd_widget_ecfbox']/h3")
	private WebElementFacade EUTradePaymentExperiencesSummary;
	
	@FindBy(xpath="//*[@id='PYINDCMP_UK']/div[1]//*[@class='fabprd_widget_ecfbox']/h3")
	private WebElementFacade EUTradePaymentIndustryComparison ;
	
	@FindBy(xpath="//*[@id='ecf_toc_main']//*[@id='ecf_toc1']//a[contains(text(),'Public Filing')]")
	private WebElementFacade EUpublicFilngTab;
	
	@FindBy(xpath="//*[@id='SUMMECF']//*[@class='fabprd_widget_ecfbox']//h3[contains(text(),'Summary')]")
	private WebElementFacade EUpublicFilngTabSummary;
	
	@FindBy(xpath="//*[@id='JUDGMNTECF']//*[@class='fabprd_widget_ecfbox']//h3[contains(text(),'Judgments')]")
	private WebElementFacade EUpublicJudgments;
	
	@FindBy(xpath="//*[@id='ecf_toc_main']//*[@id='ecf_toc1']//a[contains(text(),'Special Events')]")
	private WebElementFacade EUSpecialEventTab;
	
	@FindBy(xpath="//*[@id='SPLEVT_UK']//*[@class='fabprd_widget_ecfbox']//h3[contains(text(),'Special Events')]")
	private WebElementFacade EUSpecialEventsTabValue;
	
	@FindBy(xpath="//*[@id='ecf_toc_main']//*[@id='ecf_toc1']//a[contains(text(),'History & Operations')]")
	private WebElementFacade EUHistoryNOperations;
	
	@FindBy(xpath="//*[@id='LGLST']//*[@class='widget widgetA']/h3")
	private WebElementFacade EUHistoryLegalStructureWdgt;
	
	
	@FindBy(xpath="//*[@id='ACTEMP']//*[@class='fabprd_widget_ecfbox']//h3")
	private WebElementFacade  EUHistoryLegalOperations;
	
	@FindBy(xpath="//*[@id='HISTLEGEVNT']//*[@class='fabprd_widget_ecfbox']//h3")
	private WebElementFacade  EUHistoryLegalHistory;
	
	@FindBy(xpath="//*[@id='ecf_toc_main']//*[@id='ecf_toc1']//a[contains(text(),'Principals')]")
	private WebElementFacade EUPrincipalsTab;
	
	@FindBy(xpath="//*[@id='CURPPL']//*[@class='fabprd_widget_ecfbox']//h3")
	private WebElementFacade  EUPrincipalsCurrntPrincipal;
	
	@FindBy(xpath="//*[@id='PRVPPL']//*[@class='fabprd_widget_ecfbox']//h3")
	private WebElementFacade  EUPrincipalsPrevsPrincipal;
	
	@FindBy(xpath="//*[@id='modal_buttons']/input[1]")
    private WebElementFacade saveASnapshotEle;
	@FindBy(xpath="//*[@id='ecf_toc_main']//*[@id='ecf_toc1']//a[contains(text(),'Financials')]")
	private WebElementFacade EUtabFinancials;
	
	@FindBy(xpath="//*[@id='FINSMRY']//*[@class='fabprd_widget_ecfbox']//h3")
	private WebElementFacade  EUFinanceSummary;
	
	@FindBy(xpath="//*[@id='PLACT']//*[@class='fabprd_widget_ecfbox']//h3")
	private WebElementFacade  EUProfnLossAccounts;
	
	@FindBy(xpath="//*[@id='BLSHT']//*[@class='fabprd_widget_ecfbox']//h3")
	private WebElementFacade  EUBalanceSheet;
	
	
	private String snapShotSideicon="//*[@class='outerDiv']//*[@id='main']//*[@id='pp_side_icon']";
    
  
    @FindBy(xpath = "//div[@id='serach_criteria']/ul[@class='criteria_info criteria_status']//span[@id='Address']")
    private WebElementFacade verifyAddress;
    
    private String searchResultsConatiner="//*[@class='outerDiv']//*[@id='main']//*[contains(@class,'results full')]//thead";
    
    
    
    
    public void clickonSearchNow() {
    	try{
    	if(buttonSearch.isCurrentlyEnabled()){
		buttonSearch.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), buttonSearch);
		buttonSearch.click();
		UIHelper.waitForPageToLoad(getDriver());
    	}
    	else{
    		System.out.println("Execute the next step:");
    	}
    	} catch (Exception e) {
            // e.printStackTrace();
        }
	}
    
    public void pullReport(String dunsNumber) {
    	
		UIHelper.highlightElement(getDriver(), clickReport);
		clickReport.click();
	
		UIHelper.waitForPageToLoad(getDriver());
		
	}

	public boolean isSearchResultDisplayed() {
		dunscompany.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), dunscompany);
		String duncompany=dunscompany.getText();
		return dunscompany.isDisplayed();
	}

	public boolean isSearchResultTypeDisplayed() {
		type.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), type);
		String temp=type.getText().trim();		
		if(temp.equalsIgnoreCase("Type"))
			return true;
		else 
			return false;
	}

	public boolean isSearchResultCompanyDisplayed() {
		CompanyName.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), CompanyName);
		String temp=CompanyName.getText().trim();
		if(temp.equalsIgnoreCase("Company Name"))
			return true;
		else 
			return false;
	}

	public boolean isSearchResultPreviewDisplayed() {
		
		Preview.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), Preview);
		String temp=Preview.getText().trim();
		if(temp.equalsIgnoreCase("Preview"))
			return true;
		else 
			return false;		
	}

	public boolean isSearchResultLocationDisplayed() {
		LocationType.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), LocationType);
		String temp=LocationType.getText().trim();
		if(temp.equalsIgnoreCase("Location Type"))
			return true;
		else 
			return false;
	}
	
	
	public boolean isCanadaSearchResultLocationDisplayed() {
		CanadianLocationType.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), CanadianLocationType);
		String temp=CanadianLocationType.getText().trim();
		if(temp.equalsIgnoreCase("Location Type"))
			return true;
		else 
			return false;
	}


	public boolean isSearchResultTradeStyleDisplayed() {
		tradeStyle.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), tradeStyle);
		String temp=tradeStyle.getText().trim();
		if(temp.equalsIgnoreCase("Trade Style"))
			return true;
		else 
			return false;
	}
	
	
	public boolean isCanadaSearchResultTradeStyleDisplayed() {
		CanadianTradeStyle.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), CanadianTradeStyle);
		String temp=CanadianTradeStyle.getText().trim();
		if(temp.equalsIgnoreCase("Trade Style"))
			return true;
		else 
			return false;
	}

	public boolean isSearchResultEmployeesDisplayed() {
		Employees.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), Employees);
		String temp=Employees.getText().trim();		
		if(temp.equalsIgnoreCase("Employees"))
			return true;
		else 
			return false;
	}

	public boolean isSearchResultOptionsDisplayed() {
		
		Options.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), Options);
		String temp=Options.getText().trim();

		if(temp.equalsIgnoreCase("Options"))
			return true;
		else 
			return false;
	}
	
		public boolean isCanadaSearchResultOptionsDisplayed() {
		
		CanadianOptions.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), CanadianOptions);
		String temp=CanadianOptions.getText().trim();

		if(temp.equalsIgnoreCase("Options"))
			return true;
		else 
			return false;
	}
	

	public boolean isSearchResultSICDisplayed() {
		SIC.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), SIC);
		String temp=SIC.getText().trim();
		if(temp.equalsIgnoreCase("SIC"))
			return true;
		else 
			return false;
	}

	public boolean isSearchResultMatchWithDunsNum(String dunsNumber) {
		String str;
		dunsNumMatch.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), dunsNumMatch);
		String match=dunsNumMatch.getText().trim();
		str=getDunsNumber(match);
		if(str.equalsIgnoreCase(dunsNumber))
			return true;
		else
			return false;
	}

	public String getDunsNumber(String st){
		
		String regexpattern = "(\\d+)(-(\\d+))(-(\\d+))?";
		Pattern pattern = Pattern.compile(regexpattern);
		Matcher matcher = pattern.matcher(st);
		while (matcher.find()){
		   return  matcher.group(0);
	}
		return matcher.group(0);
		
}

	public void quickSearchCompanyCountry(String companyName, String countryName) {
		
            		searchCompBox.waitUntilPresent();
                    searchCompBox.click();
                    if (saveASnapshotEle.isVisible()) {

        				saveASnapshotEle.click();
        				searchCompBox.click();
                	}
                    searchCompBox.click();
                    searchCompBox.type(companyName.toString().trim());
                    searchStateDropdown.waitUntilEnabled();
                if (countryName != null && !countryName.isEmpty()) {
                  searchStateDropdown.selectByVisibleText(countryName);
                }
        searchBtn.waitUntilClickable();        
        searchBtn.submit();
        UIHelper.waitForPageToLoad(getDriver());
        firstSearchItemEle.waitUntilVisible();

    }
	
	public void quickSearchWithAppID(String ApplicationId) {
		// TODO Auto-generated method stub
		searchCompBox.waitUntilPresent();
        searchCompBox.click();
        searchCompBox.type(ApplicationId.toString().trim());
        searchStateDropdown.waitUntilEnabled();
        searchBtn.waitUntilClickable();        
        searchBtn.submit();
	}
	
	public boolean checkFolderValue() {
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", foldervalue);
		//foldervalue.waitUntilPresent();
		int i=Integer.parseInt(foldervalue.getText().trim());

		if(i>0){
			UIHelper.highlightElement(getDriver(), foldervalue);
		return true;
		}else{
			if (searchResultliveReport.isPresent()) {
				searchResultliveReport.click();
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), liveReportPage);
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), snapShotSideicon);
				if (saveToPortfolio.isVisible()) {
					saveToPortfolio.click();
					waitFor(1000).milliseconds();
				}
			}
			return false;
		}
		
	}
	public boolean checkFolderValue1() {
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", foldervalue);
		foldervalue.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), foldervalue);
		int i=Integer.parseInt(foldervalue.getText().trim());

		if(i>0){
		return true;
		}else{
			return false;
		}
	}

	public boolean isCompanynamePresent(String companyName) {		
		//companyValVerify.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), companyValVerify);
		String s=companyValVerify.getText().replace(".", "");
		if(companyName.toLowerCase().contains(s.toLowerCase()))
			return true;
			else
			return false;
	}
	
	public boolean isInvestigationMessgaePresent() {		
		//companyValVerify.waitUntilPresent();
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), messageInvestigation);
		String CantFindMessage = messageInvestigation.getText().trim();
		System.out.println("Message>>>>>>>>>>>>"+ CantFindMessage );
		if(CantFindMessage.contains("Can’t find the company you are searching for"))
			return true;
			else
			return false;
		}
	
	public boolean isOrderInvestigationDisplayed() {		
		//companyValVerify.waitUntilPresent();
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), OrderInvestigationSearch1);
		String message1 = OrderInvestigationSearch1.getText().trim();
		System.out.println("Message>>>>>>>>>>>>"+ message1 );
		if(message1.contains("Order investigation from D&B"))
			return true;
			else
			return false;
	}
	
	public boolean isSBRIlinkDisplayed() {		
		//companyValVerify.waitUntilPresent();
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), SBRISearchLink);
		String message1 = SBRISearchLink.getText().trim();
		System.out.println("Message>>>>>>>>>>>>"+ message1 );
		if(message1.contains("Search Small Business Risk Insight Database"))
			return true;
			else
			return false;
	}
	
	public void clickSBRIlinkDisplayed(){
		SBRISearchLink.click();
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), SBRISearchPage);
		
	}
	
	public void performsearchwithcompanycountrystate(String CompanyName,String State){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), quickCompanyName);
		quickCompanyName.sendKeys(CompanyName);
		UIHelper.highlightElement(getDriver(), quickStateName);
		quickStateName.sendKeys(State);
		UIHelper.highlightElement(getDriver(), quickSearchBttn);
		quickSearchBttn.click();
		UIHelper.waitForPageToLoad(getDriver());
	}
	 
	
	public void clickOrderInvestigation(){
		OrderInvestigationSearch1.click();
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), CompInvReqpage);
		
	    }
	
	public boolean invReqPageDisplayed() {		
		//companyValVerify.waitUntilPresent();
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), CompInvReqpage);
		String compInvReqpageText = CompInvReqpage.getText().trim();
		if(CompInvReqpage.containsText("Company Investigation Request"))
			return true;
		else
			return false;	
	}
	
	public void fillOrderInvestigationsform(String invFormCompName, String address, String city, String state, String addinformation, String yourName, String yourPhone, String selectLevel){
		UIHelper.highlightElement(getDriver(), InvCompanyName);
		InvCompanyName.sendKeys(invFormCompName);
		UIHelper.highlightElement(getDriver(), AddressFrom);
		AddressFrom.sendKeys(address);
		UIHelper.highlightElement(getDriver(), CityForm);
		CityForm.sendKeys(city);
		UIHelper.highlightElement(getDriver(), StateForm);
		StateForm.selectByVisibleText(state);
		UIHelper.highlightElement(getDriver(), AddInfoForm);
		AddInfoForm.sendKeys(addinformation);
		UIHelper.highlightElement(getDriver(), UrNameForm);
		UrNameForm.sendKeys(yourName);
		UIHelper.highlightElement(getDriver(), UrPhoneForm);
		UrPhoneForm.sendKeys(yourPhone);
		UIHelper.highlightElement(getDriver(), OrderBttnForm);
		OrderBttnForm.click(); 
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), InvConfimPage);		
	}
	
	
	public boolean valPrepopInvestigationForm(String Endorsement, String InvFormCompName, String YourName, String YourPhone){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), PrePopEndorsementInv);
		String prepop = getDriver().findElement(By.xpath("//*[@id='endorsement_title']//*[@class='frmField']//input")).getAttribute("Value").trim();
		String prepopEndo = PrePopEndorsementInv.getAttribute("Value").trim();
		System.out.println("Message>>>>>>>>>>>>1"+ prepop);
		System.out.println("Message>>>>>>>>>>>>1"+ prepopEndo);
		System.out.println("Message>>>>>>>>>>>>1"+ Endorsement);
		String prepopCompName =getDriver().findElement(By.xpath("//*[@id='main']//*[@class='widget_form']//*[@class='frmField']//*[@id='CompanyName']")).getAttribute("Value").trim();
		System.out.println("Message>>>>>>>>>>>>2"+ prepopCompName);
		System.out.println("Message>>>>>>>>>>>>2"+ InvFormCompName);
		String prepopUrName =getDriver().findElement(By.xpath("//*[@id='main']//*[@class='widget_form']//*[@id='YourName']")).getAttribute("Value").trim();
		System.out.println("Message>>>>>>>>>>>>3"+ prepopUrName);
		System.out.println("Message>>>>>>>>>>>>3"+ YourName );
		String prepopPhNumber =getDriver().findElement(By.xpath("//*[@id='main']//*[@class='widget_form']//*[@id='YourPhone']")).getAttribute("Value").trim();
		System.out.println("Message>>>>>>>>>>>>4"+ prepopPhNumber);
		System.out.println("Message>>>>>>>>>>>>4"+ YourPhone);
		if(prepopEndo.contains(Endorsement)&&
				prepopCompName.contains(InvFormCompName)&&
					prepopUrName.contains(YourName)&& 
						prepopPhNumber.contains(YourPhone))
			return true;
			else
			return false;
    	 }

	
	
	public boolean invConfirmPageDisplayed() {		
		//companyValVerify.waitUntilPresent();
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), InvConfimPage);
		String title2 = InvConfimPage.getText().trim();
		System.out.println("Message>>>>>>>>>>>>"+ title2 );
		if(title2.contains("Company Investigation Request - Confirmation"))
			return true;
			else
			return false;
	}
	

	public boolean isCompanynamePresentReason(String companyName) {		
		//companyValVerify.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), companyReasonCodeVerify);
		String ReasonComp=companyReasonCodeVerify.getText();
		System.out.println("Execute the next step:"+ ReasonComp );
		if(ReasonComp.toLowerCase().contains(companyName.toLowerCase()))
			return true;
			else
			return false;
	}
	
	public boolean isCompanynamePresentInternational(String companyName) {		
		//companyValVerify.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), companyReasonCodeVerify);
		String ReasonComp=companyReasonCodeVerify.getText();
		System.out.println("Execute the next step:"+ ReasonComp );
		if(ReasonComp.toLowerCase().contains(companyName.toLowerCase()))
			return true;
			else
			return false;
	  }
	
	
	public boolean isCompanynamePresentInternational() {		
		//companyValVerify.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), internationalPage);
		String IntReqPage=internationalPage.getText();
		System.out.println("Execute the next step:"+ "Landed in IntReqPage");
		if(IntReqPage.equalsIgnoreCase("International Request"))
			return true;
		else
			return false;
	}
	
	public boolean islivRepIntDisplayed(String companyName) {		
		//companyValVerify.waitUntilPresent();
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), LiveRepTitleNameIntl);
		String IntLivRepPage=LiveRepTitleNameIntl.getText();
		System.out.println("Execute the next step:"+ IntLivRepPage);
		String CompName = IntLivRepPage;
		String[] parts = CompName.split(" : ");
		String Regpart1 = parts[0]; // 004
		System.out.println("Execute the next step:"+ Regpart1 );
		String Regpart2 = parts[1]; // 034556
		System.out.println("Execute the next step:"+ Regpart2 );
		System.out.println("Execute the next step:"+ Regpart1 );
		System.out.println("Execute the next step:"+ Regpart2 );
		if(Regpart2.contains(companyName))
			return true;
			else
			return false;
		}
		
	public void searchPageResultDunslink() {
		
	    if(buttonSearch.isCurrentlyEnabled()){
			buttonSearch.waitUntilClickable();
			UIHelper.highlightElement(getDriver(), buttonSearch);
			buttonSearch.click();
			UIHelper.waitForPageToLoad(getDriver());
	    	}else{
	    	System.out.println("Execute the next step:");
	        }
		searchPageResultDunslink.waitUntilPresent();
		System.out.println("-----autoit-------"+"SearchedDUNSlink>>>>>>>>>>>>>>>>>>>>>>>>>>>>");	
		UIHelper.highlightElement(getDriver(), searchPageResultDunslink);		
		searchPageResultDunslink.click();
		System.out.println("-----autoit-------"+"SearchedDUNSlink>>>>>>>>>>>>>>>>>>>>>>>>>>>>1");
		UIHelper.waitForPageToLoad(getDriver());
		if(internationalPage.isVisible()){
			System.out.println("-----autoit-------"+"iF loop");				
			viewRepbttn.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), viewRepbttn);			
			viewRepbttn.click();
		}else{
			UIHelper.highlightElement(getDriver(), LiveRepTitleNameIntl);
			String IntLivRepPage=LiveRepTitleNameIntl.getText();
			System.out.println("Execute the next step:"+ IntLivRepPage);
		}
		System.out.println("-----autoit-------"+"Search Result DUNS Link clicked");	
	} 
	
	public void clickViewReportBttn(){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), viewRepbttn);
		viewRepbttn.waitUntilPresent();
		viewRepbttn.click();
		System.out.println("-----autoit-------"+"Search Result viewRepbttn clicked");
	}
	
	public boolean isCompanynamePresentForEU(String companyName) {		
		//companyValVerify.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), companyReasonCodeVerify);
		String ReasonComp=companyReasonCodeVerify.getText();
		System.out.println("Execute the next step:"+ ReasonComp );
		if(ReasonComp.toLowerCase().contains(companyName.toLowerCase()))
			return true;
			else
			return false;
	}
	
	
	public boolean isCompanynamePresentRegistration(String RegistratioNo) {		
		//companyValVerify.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), companyRegistrationNoVerify);
		String RegNoComp= companyRegistrationNoVerify.getText();
		System.out.println("Execute the next step:"+ RegNoComp );
		String RegNoCompStr = RegNoComp;
		String[] parts = RegNoCompStr.split("REGN. ");
		String Regpart1 = parts[0]; // 004
		System.out.println("Execute the next step:"+ Regpart1 );
		String Regpart2 = parts[1]; // 034556
		System.out.println("Execute the next step:"+ Regpart2 );
		System.out.println("Execute the next step:"+ Regpart1 );
		System.out.println("Execute the next step:"+ Regpart2 );
		if(Regpart2.contains(RegistratioNo))
			return true;
			else
			return false;
		}
	
	public boolean isReasonCodePresent(String ReasonCode) {		
		//companyValVerify.waitUntilPresent();
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(),reasonCodenSearchPage);
		String reasoncode =reasonCodenSearchPage.getText();
		if(reasoncode.contains(ReasonCode))
			return true;
			else
			return false;
	   }
	
	public boolean isPhoneNumPresent(String PhoneNumber) {
		//phoneNumValVerify.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), phoneNumValVerify);
		String s=phoneNumValVerify.getText().split("\n")[4].split(":")[1].trim();
		if(s.equalsIgnoreCase(PhoneNumber))
			return true;
		else
			return false;
	}

	public boolean isSearchResultFoldersDisplayed() {
		//folders.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), folders);
		String temp=folders.getText().trim();
		if(temp.equalsIgnoreCase("Folders"))
		return true;
		else 
			return false;
	}

	public boolean isSearchResultDateDisplayed() {

		//dateCreated.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), dateCreated);
		String temp=dateCreated.getText().trim();

		if(temp.equalsIgnoreCase("Date Created"))
		return true;
		else 
			return false;
	}

	public boolean isSearchResultCompOptionsDisplayed() {

		//compOptions.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), compOptions);
		String temp=compOptions.getText().trim();

		if(temp.equalsIgnoreCase("Options"))
		return true;
		else 
			return false;
	}

	public boolean isCompanynameDisplayed(String companyName) {

		String s=companyValVerify.getText();
		if(s.toLowerCase().contains(companyName.toLowerCase()))
			return true;
			else
				return false;
	}

	public void performautoSearchWithCompanyName(String companyName) {
		UIHelper.highlightElement(getDriver(), searchmain);
		searchmain.waitUntilPresent();
		searchmain.clear();
		searchmain.sendKeys(companyName);
		System.out.println("-----autoit-------");	
	} 

	public void displayAutoSuggestResults() {
		System.out.println("-----autoit2-------");
		UIHelper.highlightElement(getDriver(), autoSuggest);
		autoSuggest.waitUntilPresent();
		autoSuggest.isDisplayed();
		System.out.println("-----autoit2-------");
	}

	public void clickAutoSuggestResults() {
		// TODO Auto-generated method stub
		System.out.println("-----autoit3-------");
		getDriver().findElement(By.xpath("//*[@class='outerDiv']//*[@id='search_box']//*[@id='quickSearchFld']"));
		waitFor(3000).milliseconds();
		List <WebElement> listItems = getDriver().findElements(By.xpath("//*[@id='autoSug']"));
		listItems.get(2).click();
		System.out.println("-----autoit4-------");
		/*if (searchBtn.isPresent()) {
		getDriver().findElement(By.id("searchBtn")).click();
		 searchResultsConatinerEle.waitUntilPresent();
		}*/
	}

	public void isStateEmpty() {
		// TODO Auto-generated method stub
		UIHelper.highlightElement(getDriver(), companyState);		
//		Select select = new Select(getDriver().findElement(By.xpath("//table[@id='international_search_table']//*[@id='BizInfo-State']")));
		String selectedOption = new Select(getDriver().findElement(By.xpath("//table[@id='international_search_table']//*[@id='BizInfo-State']"))).getFirstSelectedOption().getText();
		
		System.out.println("SELECET STATE AFTER RESET-------"+selectedOption);
		Assert.assertEquals("Select State", selectedOption);
		//Select State
		
//		UIHelper.highlightElement(getDriver(), companyState);
//		companyState.selectByVisibleText("Select State");
		
	}

	public boolean snapShotChecked() {
		// TODO Auto-generated method stub
		
		checkboxsnapshot.waitUntilPresent();
		checkboxsnapshot.click();
		if(checkboxsnapshot.isSelected())
			return true;
		else
			return false;
	}

	public boolean isPhoneTabEmpty() {
		// TODO Auto-generated method stub
		phonenumber.waitUntilPresent();
		if(phonenumber.getText().equalsIgnoreCase(" "))
			return true;
		else
			return false;
	}

	
	public boolean isStreetAddressEmpty() {		
		if(txtStreetAddress.getText().equalsIgnoreCase(""))
			return true;
		else
			return false;	
	}

	public boolean isFirstNameEmpty() {		
		if(txtFirstName.getText().equalsIgnoreCase(""))
			return true;
		else
			return false;	
	}

	public boolean isLastNameEmpty() {		
		if(txtLastName.getText().equalsIgnoreCase(""))
			return true;
		else
			return false;	
	}

	public boolean isInitialEmpty() {		
		if(txtInitial.getText().equalsIgnoreCase(""))
			return true;
		else
			return false;	
	}

	
	public boolean isTownEmpty() {
		txtTown.waitUntilPresent();
		if(txtTown.getText().equalsIgnoreCase(""))
			return true;
		else
			return false;	
	}

	public boolean isLocZipEmpty() {
		txtLocZip.waitUntilPresent();
		if(txtLocZip.getText().equalsIgnoreCase(""))
			return true;
		else
			return false;	
	}
	
	public boolean isTownTabEmpty() {
		// TODO Auto-generated method stub
		
		city.waitUntilPresent();
		if(city.getText().equalsIgnoreCase(" "))
			return true;
		else
			return false;	
	}

	public boolean isDunFieldEmpty() {
		// TODO Auto-generated method stub
		DunsNumber.waitUntilPresent();
		if(DunsNumber.getText().equalsIgnoreCase(" "))
			return true;
		else
			return false;
		
	}

	public boolean isAddressFieldEmpty() {
		Address.waitUntilPresent();
		if(Address.getText().equalsIgnoreCase(""))
			return true;
		else
			return false;
	
	}

	public boolean isExecutiveAddressEmpty() {		
		ExecutiveAddress.waitUntilPresent();
		if(ExecutiveAddress.getText().equalsIgnoreCase(""))
			return true;
		else
			return false;
	
	}

	public boolean isExecutiveTownEmpty() {		
		ExecutiveTown.waitUntilPresent();
		if(ExecutiveTown.getText().equalsIgnoreCase(""))
			return true;
		else
			return false;
	
	}
		
	public boolean isCountyFieldEmpty() {
		// TODO Auto-generated method stub
		country.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), country);
		if(country.getText().equalsIgnoreCase("United States Of America"))
			return true;
		else
			return false;
	}
	
	
	public boolean displayWarningMessage() {
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
		warnigMessage.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), warnigMessage);
		if(warnigMessage.getText().equalsIgnoreCase("There were no matching companies found."))
			return true;
		else
			return false;
	}
	

	public boolean isCompanyyFieldEmpty() {
		// TODO Auto-generated method stub
		compNametable.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), compNametable);
		if(compNametable.getText().length()==0)
			return true;
		else
			return false;
	}

	public void clickResetButton() {
		
		resetbutton.waitUntilEnabled();
		UIHelper.highlightElement(getDriver(),resetbutton);
		resetbutton.click();
		waitFor(3000).milliseconds();
//		System.out.println("clicking reset second time");
//		resetbutton.click();
//		waitFor(3000).milliseconds();
	}

	public void clickLocResetButton() {			
		UIHelper.highlightElement(getDriver(),locationResetFieldsBtn);
		locationResetFieldsBtn.click();
		txtStreetAddress.waitUntilEnabled();
//		waitFor(3000).milliseconds();
	}

	public void clickExecutiveResetButton() {			
		UIHelper.highlightElement(getDriver(),executiveResetFieldsBtn);
		executiveResetFieldsBtn.click();
		txtFirstName.waitUntilEnabled();
//		waitFor(3000).milliseconds();
	}
	
	public void clickLocationSearch() {
		try {			
			if(locationSearch.isPresent())
			{
				locationSearch.click();
				UIHelper.waitForPageToLoad(getDriver());
				locationResetFieldsBtn.waitUntilPresent();
			}
        } catch (Exception e) {
            // e.printStackTrace();
        }		
	}
	
	public void clickExcecutiveSearch() {
		try {			
			if(ExecutiveSearch.isPresent())
			{
				ExecutiveSearch.click();
				UIHelper.waitForPageToLoad(getDriver());
				locationResetFieldsBtn.waitUntilPresent();
			}
        } catch (Exception e) {
            // e.printStackTrace();
        }
	}
	
	public boolean locationWarningMssg() {
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
		warnigLocationMessage.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), warnigLocationMessage);
		if(warnigLocationMessage.getText().equalsIgnoreCase("Enter the following information to search D&B for possible matches based on locations for US Companies."))
			return true;
		else
			return false;
	    }
	
	public void clicExecutiveSearch() {			
				ExecutiveSearch.click();
				waitFor(3000).milliseconds();
				UIHelper.waitForPageToLoad(getDriver());
				executiveResetFieldsBtn.waitUntilEnabled();
	}

	
	public void clickMoreOptions() {
			if(!fewerOptionsEle.isVisible())
			{
				MoreOptionsEle.click();
				resetbutton.waitUntilPresent();
			}
	}
	
	public boolean verifyMoreOptionLinks(){		
		if(locationSearch.isDisplayed())
		  locationSearch.click();
		  waitFor(3000).milliseconds();
		  UIHelper.waitForPageToLoad(getDriver());
		  ExecutiveSearch.click();
		  waitFor(3000).milliseconds();
		  UIHelper.waitForPageToLoad(getDriver());
		  AdvancedSearch.click();
		  waitFor(3000).milliseconds();
		  UIHelper.waitForPageToLoad(getDriver());
		  CompanySearch.click();
		  waitFor(3000).milliseconds();
		  UIHelper.waitForPageToLoad(getDriver());
		 return true;
	  }
	
	public boolean isZipEmpty() {	
		zip.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), zip);
		if(zip.getText().length()==0)
			return true;
		else
			return false;
	}

	public boolean isBillReferenceEmpty() {		
		billingreference.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), billingreference);
		if(billingreference.getText().length()==0)
			return true;
		else
			return false;
	}

	public void performsearchwithcompanycountrystate(String CompanyName,String CountryName,String State) {
		commonMethodToEnterDataInFullCompanySearch(CompanyName,CountryName," "," ",State," "," "," "," ");
	}
	
	public void performsearchwithcompanycountryReasonCode(String CompanyName,String CountryName, String ReasonCode) {
		commonMethodToEnterDataInFullReasonCodeSearch(CompanyName,CountryName," "," ",ReasonCode," "," "," "," ");
	}
	
	public void performsearchwithcompanycountry(String CompanyName,String CountryName) {
		commonMethodToEnterDataInFullComapanyCountrySearch(CompanyName,CountryName);
	}

	public void performSearchWithDunsCountryState(String DunsNumber,String CountryName,String State) {

		commonMethodToEnterDataInFullCompanySearch(" ",CountryName," "," ",State,DunsNumber," "," "," ");
	}

	public void performSearchWithPhoneCountryState(String PhoneNumber,String CountryName,String State) {
		commonMethodToEnterDataInFullCompanySearch(" ",CountryName," "," ",State," ",PhoneNumber," "," ");
	}
	
	public void performLocationSearchWithStreetAddTownStateZip(String StreetAddress,String Town,String State,String Zip) {
		System.out.println("i am in the search    ------------"+StreetAddress+"-----------"+Town+"---------   "+Town+"--------"+Zip);
		UIHelper.highlightElement(getDriver(), txtStreetAddress);
		txtStreetAddress.sendKeys(StreetAddress);
		UIHelper.highlightElement(getDriver(), txtTown);
		txtTown.sendKeys(Town);
        Select sel = new Select(getDriver().findElement(By.xpath("//select[@id='state']")));
        sel.selectByVisibleText(State);
        UIHelper.highlightElement(getDriver(), txtLocZip);
        txtLocZip.sendKeys(Zip);	
        btnLocationSearch.click();
        type.waitUntilPresent();
//        UIHelper.waitForPageToLoad(getDriver());        
	}

	public void performExecutiveSearchWithFirstNameInitialLastNameAddressTownState(String FirstName,String Initial,String LastName,String Address,String Town,String State) {
		// TODO Auto-generated method stub
		System.out.println("i am in1 --------performLocationSearchWithStreetAddTownStateZip-----------");		
		UIHelper.highlightElement(getDriver(), txtFirstName);
		txtFirstName.sendKeys(FirstName);

		UIHelper.highlightElement(getDriver(), txtInitial);
		txtInitial.sendKeys(Initial);

		UIHelper.highlightElement(getDriver(), txtLastName);
		txtLastName.sendKeys(LastName);

		UIHelper.highlightElement(getDriver(), ExecutiveAddress);
		ExecutiveAddress.sendKeys(Address);

		UIHelper.highlightElement(getDriver(), ExecutiveTown);
		ExecutiveTown.sendKeys(Town);

		Select sel = new Select(getDriver().findElement(By.xpath("//select[@id='state']")));
        sel.selectByVisibleText(State);

        btnExecutiveSearch.click();
        type.waitUntilPresent();
//        UIHelper.waitForPageToLoad(getDriver());
	}
	
	public boolean isLocationSearchWithStreetAddTownStateZipDisplayed(String StreetAddress,String Town,String State,String Zip) {
		phoneNumValVerify.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), phoneNumValVerify);
		String uiStreetAdd=phoneNumValVerify.getText().split("\n")[1].trim();
		String uiTown=phoneNumValVerify.getText().split("\n")[2].trim();
		if(uiStreetAdd.equalsIgnoreCase(StreetAddress))
			return true;
		else
			return false;             
	}

	public boolean isExecutiveSearchWithSearchWithFirstNameInitialLastNameAddressTownStateDisplayed(String FirstName,String Initial,String LastName,String Address,String Town,String State) {
		
		UIHelper.highlightElement(getDriver(), cellExecutiveName);
		String uiExecutiveName=cellExecutiveName.getText().trim();
		String uiFirstName = uiExecutiveName.split(" ")[0].trim();
		String uiInitial = uiExecutiveName.split(" ")[1].trim();
		String uiLastName = uiExecutiveName.split(" ")[2].trim();
		String uiTown=phoneNumValVerify.getText().split("\n")[2].trim().split(",")[0];
		if(uiTown.equalsIgnoreCase(Town) && uiFirstName.equalsIgnoreCase(FirstName) && uiInitial.equalsIgnoreCase(Initial) && uiLastName.equalsIgnoreCase(LastName) )
			return true;
		else
			return false;             
	}

	public boolean isFolderDetaislAvilable() {
		// TODO Auto-generated method stub
		folderdetailssearch.waitUntilPresent();
		if(folderdetailssearch.isPresent())
			return true;
		else
			return false;
	}

	
	/**
	 * common method to perform company search
	 */
	//--------
    public void commonMethodToEnterDataInCompanySearch(String compName,
            String countryName, String state, String dunsNumber,
            String zipCode, String isIncludedSnapshot, String PhoneNumber) {
        try {

            companySearchCompanyName.sendKeys(compName);
            companySearchCompanyName.sendKeys(Keys.TAB);
                        
            UIHelper.highlightElement(getDriver(), companySearchCountryName);
            Select sel = new Select(getDriver().findElement(By.xpath("//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='international_search_table']//*[@id='BizInfo-Country']")));
            sel.selectByVisibleText(countryName);
            DunsNumber.sendKeys(dunsNumber);
            phonenumber.sendKeys(PhoneNumber);
           	UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//table[@id='international_search_table']//select[@id='BizInfo-State']");
            if (state.length() > 0) {
//            	companyState.selectByVisibleText(state);
       	
            	((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", companyState);
//            	  System.out.println("--------1-------"+ state);
            	UIHelper.highlightElement(getDriver(), companyState);
//            	companyState.selectByVisibleText(state);
                Select dropdown = new Select(getDriver().findElement(By.xpath("//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='BizInfo-State']")));
                dropdown.selectByVisibleText(state);
////                dropdown.selectByIndex(1);
//                dropdown.selectByValue("California");
//                dropdown.selectByValue("Florida");
//                System.out.println("---------2------"+ state);
            }
            
//           	UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//table[@id='international_search_table']//select[@id='BizInfo-State']");
/*                if (state.length() > 0) {           
//                	((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", companyState);
//                	UIHelper.highlightElement(getDriver(), companyState);
                    Select dropdown = new Select(getDriver().findElement(By.xpath("//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='BizInfo-State']")));
//                    dropdown.selectByVisibleText("Nationwide - US");
                    dropdown.selectByVisibleText(state);
                }
*/            zip.sendKeys(zipCode);
            if (isIncludedSnapshot.equalsIgnoreCase("Check")) {
            	UIHelper.highlightElement(getDriver(),checkboxsnapshot);
            	checkboxsnapshot.click();
            }
//            getDriver().manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
//            ((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", companySearchButton);
            companySearchButton.click();

            searchResultsConatinerEle.waitUntilPresent();
            UIHelper.waitForPageToLoad(getDriver());
            searchNowBtnEle.waitUntilClickable();
//            waitFor(3000).milliseconds();
//            if (searchNowBtnEle.isPresent()) {
//                waitFor(3000).milliseconds();
//                disHref.waitUntilPresent();
//                UIHelper.waitForPageToLoad(getDriver());
//            }

        } catch (NoSuchElementException E) {

        }
    }

	public boolean isCompOptionDisplayed() {
		if(linkOptions.isVisible() || Options.isVisible())
		{
			return true;
		}
		else
			return false;
//		Options.waitUntilPresent();
//		UIHelper.highlightElement(getDriver(), Options);
//		return Options.isDisplayed();
//		String temp=Options.getText().trim();
//		System.out.println("-----7---------"+temp);
//		if(temp.equalsIgnoreCase("Options"))
//		return true;
//		else 
//			return false;
	}

	public void performsearchwithcompanyTotalDetails(String companyName,
			String countryName, String address, String town, String state,
			String zip) {
		// TODO Auto-generated method stub
		commonMethodToEnterDataInFullCompanySearch(companyName,countryName,address,town,state," "," ",zip," ");
	}
	
	/**
	 * commonfullsearchDetails
	 * 
	 */
	 public void commonMethodToEnterDataInFullCompanySearch(String compName,
	            String countryName, String address, String town,String state, String dunsNumber,String PhoneNumber,
	            String zipCode, String isIncludedSnapshot) {

	        	System.out.println("i am in the fullcompanysearch    ------------"+compName+"-----------"+countryName+"---------   "+state);
	        	if (compName != null && !compName.isEmpty())
	        	{
	        		companySearchCompanyName.sendKeys(compName);	        		
	        	}
	            companySearchCompanyName.sendKeys(Keys.TAB);
	                        
	            UIHelper.highlightElement(getDriver(), companySearchCountryName);
	            Select selCountry = new Select(getDriver().findElement(By.xpath("//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='international_search_table']//*[@id='BizInfo-Country']")));
	            selCountry.selectByVisibleText(countryName);
	            if (dunsNumber != null && !dunsNumber.isEmpty())
	            {
	            	DunsNumber.sendKeys(dunsNumber);	            	
	            }

	            if (PhoneNumber != null && !PhoneNumber.isEmpty())
	            {
	            	phonenumber.sendKeys(PhoneNumber);	            	
	            }
	            
//	           	UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//table[@id='international_search_table']//select[@id='BizInfo-State']");
	                if (state.length() > 0) {
	                	UIHelper.highlightElement(getDriver(), companyState);
	                    Select selState = new Select(getDriver().findElement(By.xpath("//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='BizInfo-State']")));
	                    selState.selectByVisibleText(state);
	                }
	            zip.sendKeys(zipCode);
	            Address.sendKeys(address);
	            city.sendKeys(town);
	            if (isIncludedSnapshot.equalsIgnoreCase("Check")) {
	            	UIHelper.highlightElement(getDriver(),checkboxsnapshot);
	            	checkboxsnapshot.click();
	            }
	            companySearchButton.click();
	            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), searchResultsConatiner);
	           //searchResultsConatinerEle.waitUntilPresent();
//	            UIHelper.waitForPageToLoad(getDriver());
	    }
	 public void clicksearchbutton(){
		 companySearchButton.click();
         UIHelper.waitForVisibilityOfEleByXpath(getDriver(), searchResultsConatiner);
         
		 
	 }
	 
	 public void commonMethodToEnterDataInFullReasonCodeSearch(String compName,
	            String countryName, String address, String town,String ReasonCode, String dunsNumber,String PhoneNumber,
	            String zipCode, String isIncludedSnapshot) {

	        	System.out.println("i am in the fullcompanysearch    ------------"+compName+"-----------"+countryName+"---------   "+ReasonCode);
	        	if (compName != null && !compName.isEmpty())
	        	{
	        		companySearchCompanyName.sendKeys(compName);	        		
	        	}
	            companySearchCompanyName.sendKeys(Keys.TAB);
	                        
	            UIHelper.highlightElement(getDriver(), companySearchCountryName);
	            Select selCountry = new Select(getDriver().findElement(By.xpath("//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='international_search_table']//*[@id='BizInfo-Country']")));
	            selCountry.selectByVisibleText(countryName);
	            if (dunsNumber != null && !dunsNumber.isEmpty())
	            {
	            	DunsNumber.sendKeys(dunsNumber);	            	
	            }

	            if (PhoneNumber != null && !PhoneNumber.isEmpty())
	            {
	            	phonenumber.sendKeys(PhoneNumber);	            	
	            }
	            
//	           	UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//table[@id='international_search_table']//select[@id='BizInfo-State']");
	                if (ReasonCode.length() > 0) {
	                	UIHelper.highlightElement(getDriver(), reasonCodeDropDown);
	                    Select selReasonCode = new Select(getDriver().findElement(By.xpath("//table[@id='international_search_table']//select[@id='BizInfo-ReasonCode']")));
	                    selReasonCode.selectByVisibleText(ReasonCode);
	                }
	            zip.sendKeys(zipCode);
	            Address.sendKeys(address);
	            city.sendKeys(town);
	            if (isIncludedSnapshot.equalsIgnoreCase("Check")) {
	            	UIHelper.highlightElement(getDriver(),checkboxsnapshot);
	            	checkboxsnapshot.click();
	            }
	            companySearchButton.click();
	            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), searchResultsConatiner);
	           //searchResultsConatinerEle.waitUntilPresent();
//	            UIHelper.waitForPageToLoad(getDriver());
	    }
	 
	 public void commonMethodToEnterDataInFullComapanyCountrySearch(String compName,
	            String countryName) {

	        	System.out.println("i am in the fullcompanysearch    ------------"+compName+"-----------"+countryName+"---------   ");
	        	if (compName != null && !compName.isEmpty())
	        	{
	        		companySearchCompanyName.sendKeys(compName);	        		
	        	}
	            companySearchCompanyName.sendKeys(Keys.TAB);
	                        
	            UIHelper.highlightElement(getDriver(), companySearchCountryName);
	            Select selCountry = new Select(getDriver().findElement(By.xpath("//*[@class='outerDiv']//*[@id='search_box']//*[@id='search_fields']//*[@id='international_search_table']//*[@id='BizInfo-Country']")));
	            selCountry.selectByVisibleText(countryName);
	            companySearchButton.click();
	            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), searchResultsConatiner);
	           //searchResultsConatinerEle.waitUntilPresent();
//	            UIHelper.waitForPageToLoad(getDriver());
	    }
	 public void clicksearchForReasonCode(){
		 companySearchButton.click();
      UIHelper.waitForVisibilityOfEleByXpath(getDriver(), searchResultsConatiner);
		 
	 }

	public boolean isFullSearchAddressMatched(String Address) {
		// TODO Auto-generated method stub
		verifyAddress.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), verifyAddress);
		
		String temp=verifyAddress.getText().trim();
		System.out.println("-----7---------"+temp);
		if(temp.equalsIgnoreCase(Address))
		return true;
		else 
			return false;
	}

	public void performSearchWithDunsCountry(String dunsNumber, String countryName) {
		// TODO Auto-generated method stub
		System.out.println("+++++pages++++++++countryname+++"+countryName);
		System.out.println("I am in performSearchWithDunsCountry() only dunsnumber---------");
		commonMethodToEnterDataInFullCompanySearch("",
				countryName,"", "","", dunsNumber,"",
	            "", "")	;
		if(buttonSearch.isCurrentlyEnabled()){
			buttonSearch.waitUntilClickable();
			UIHelper.highlightElement(getDriver(), buttonSearch);
			buttonSearch.click();
			UIHelper.waitForPageToLoad(getDriver());
	    	}
	    	else{
	    		System.out.println("Execute the next step:");
	    	}
	}
	
	public boolean createAppBttndisp(){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(),CreditAppButtn);
		if(CreditAppButtn.isDisplayed())
			return true;
			else 
		    return false;
	 }
		
	public void createAppBttnClicked() {
		// TODO Auto-generated method stub
		CreditAppButtn.click();
		UIHelper.waitForPageToLoad(getDriver());
		String pagetitle = CreditAppCompInfoPage.getText().trim();
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>"+pagetitle);
	}
	
	public void createSnapShotBttnClicked() {
		// TODO Auto-generated method stub
		CreditSnapShotButtn.click();
		UIHelper.waitForPageToLoad(getDriver());
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>"+ "ModalWindowOpened");
	}
	
	public void  addSnaptoFolderPortfolio(){
		UIHelper.waitForPageToLoad(getDriver());
		getDriver().switchTo().frame("__modal_iframe_target");
		UIHelper.highlightElement(getDriver(), SnapForminput);
		visibilityType.selectByVisibleText("Everyone");
		SnapForminput.sendKeys("Adding this live Report to portfolio");
		UIHelper.highlightElement(getDriver(), SnapButtninput);
		SnapButtninput.click();
		UIHelper.waitForPageToLoad(getDriver());		
	}
	
	public void clickSnapshotlink(){
		UIHelper.highlightElement(getDriver(), searchSnapshotlink);
		searchSnapshotlink.click();
		UIHelper.waitForPageToLoad(getDriver());
	}
	
	public boolean companyIdentificationDisplay() {
		// TODO Auto-generated method stub
		UIHelper.highlightElement(getDriver(), CreditAppCompInfoPage);
		if(CreditAppCompInfoPage.getText().equalsIgnoreCase("Company Identification"))
			  return true;
			else 
		      return false;	  
	}

	public void valuesinForm1() {
		// TODO Auto-generated method stub
		UIHelper.highlightElement(getDriver(), loadNextBttn);
		loadNextBttn.click();
		UIHelper.waitForPageToLoad(getDriver());
	}
	

	public void valuesinForm2(String emailid) {
		// TODO Auto-generated method stub
		UIHelper.highlightElement(getDriver(), EmailIDBox);
		EmailIDBox.sendKeys(emailid);	
		EcfSubmitBttn.isVisible();
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", EcfSubmitBttn); 
		UIHelper.highlightElement(getDriver(), EcfSubmitBttn);
		EcfSubmitBttn.click();
	}

	public boolean DnBDataOverviewTabdisdisp() {
		// TODO Auto-generated method stub
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), DNBDataOverviewTab);
		if(DNBDataOverviewTab.isVisible())
		  return true;
		else 
	      return false;
	}

	public void DnBDataOverviewTabClick() {
		// TODO Auto-generated method stub
		DNBDataOverviewTab.click();
		UIHelper.waitForPageToLoad(getDriver());
	}

	public boolean DnBDataOverviewTabValueDisp() {
		// TODO Auto-generated method stub
		UIHelper.highlightElement(getDriver(), DNBDataOverviewValues);
		if(DNBDataOverviewValues.isVisible())
			  return true;
			else 
		      return false;
		}
	
}
