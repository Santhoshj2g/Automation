package com.dnb.automation.sbfe.pages;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Date;
import java.net.HttpURLConnection;
import java.net.URLConnection;
import java.sql.Array;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;




















import java.sql.Array;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;









import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;









import java.sql.Array;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

import com.dnb.automation.utils.UIHelper;
import com.gargoylesoftware.htmlunit.javascript.host.URL;

import java.sql.SQLException;
public class SBFEAHRequestPage extends PageObject
{
	

	@FindBy(xpath=".//*[@id='aHRequest']/a")
	private static WebElementFacade tabAHChanges;
	
	@FindBy(xpath=".//*[@id='ahChangesTabui']")
	private static WebElementFacade AHRequest;
	
	@FindBy(xpath=".//*[@id='aHFrm']//*[@id='oldCtbr']")
	private static WebElementFacade ContributorNO;
	
	@FindBy(xpath=".//*[@id='aHFrm']//*[@id='oldAcctNo']")
	private static WebElementFacade OldAcctNO;
	
	@FindBy(xpath=".//*[@id='aHFrm']//*[@id='oldAcctTypeCd']")
	private static WebElementFacade OldAcctType;
	
	@FindBy(xpath=".//*[@id='ahNewAcctHeader']/span")
	private static WebElementFacade EnterNewSection;
	
	@FindBy(xpath=".//*[@id='ahOldAcctId']//*[@id='ahGoOldBtn']")
	private static WebElementFacade GoBtn;
	
	@FindBy(xpath=".//*[@id='newAcctNo']")
	private static WebElementFacade Newacctno;
	
	@FindBy(xpath=".//*[@id='newAcctTypeCd']")
	private static WebElementFacade Newaccttypecode;
	
	@FindBy(xpath=".//*[@id='newAcctConvTypeCd']")
	private static WebElementFacade AcctConvTypeCodedd;
	
	@FindBy(xpath=".//*[@id='aHAccConvdatepicker']")
	private static WebElementFacade AcctConvDate;
	
	@FindBy(xpath=".//*[@id='aHAccConvdatepickerDiv']/img")
	private static WebElementFacade AcctConvDatePicker;
	
	@FindBy(xpath=".//*[@id='newCtbr']")
	private static WebElementFacade NewContrNo;
	
	@FindBy(xpath=".//*[@id='ui-datepicker-div']/div/div/span[1]")
	private static WebElementFacade AcctConvDateMonth;
	
	@FindBy(xpath=".//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[1]")
	private static WebElementFacade AcctConvDateDAte;
	
	@FindBy(xpath=".//*[@id='newCtbr']")
	private static WebElementFacade AcctConvdate;
	
	@FindBy(xpath=".//*[@id='aHSubmitBtn']")
	private static WebElementFacade SubmitBtn;
	
	@FindBy(xpath="//*/div[contains(@class,'ui-dialog-content')]//*/div/span")
	private static WebElementFacade DialogboxAHRequest;

	@FindBy(xpath="//*/div[contains(@class,'ui-dialog-buttonpane')]/div/button[@id='okn-button-id-AH']")
	private static WebElementFacade DialogboxAHRequestOkButton;
	
	@FindBy(xpath="//*[@id='launch']")
	private static WebElementFacade LaunchButton;

public void AHRequestTabClick() throws Exception
{
	if(AHRequest.isPresent()){
		UIHelper.highlightElement(getDriver(), AHRequest);
		AHRequest.click();
		UIHelper.waitForPageToLoad(getDriver());
	}
}

public String AHRequestTab() throws Exception
{
	String elementpresent=null;
	if(AHRequest.isPresent())
	{
		elementpresent=AHRequest.getText();
	}
	
	return elementpresent;
}

public void EnterContrNo(String ContributorNumber) throws Exception
{
	if(ContributorNO.isPresent())
	{
		ContributorNO.type(ContributorNumber);
	}
	
}
	
public void EnterOldacctno(String OldAcctNo) throws Exception
{
	
	if(OldAcctNO.isPresent())
	{
		OldAcctNO.type(OldAcctNo);
	}
	
}

public void EnterOldaccttype(String OldAcctTypecode) throws Exception
{
	
	if(OldAcctType.isPresent())
	{
		OldAcctType.selectByVisibleText(OldAcctTypecode);
	}
}
	

	public void AHRequestGobtn() throws Exception
	{
		if(EnterNewSection.isPresent())
		{
			GoBtn.click();
		}
			
	}
	
	// get text of new section label name to update new account details
	public String NewSection() throws Exception
	{
		String elementpresent=null;
		if(EnterNewSection.isPresent())
		{
			elementpresent=EnterNewSection.getText();
			
			
		}
		return elementpresent;
	}
	
	// verifies if new section is present to update new account details
	public void newsectionpresent()
	{
		if(EnterNewSection.isPresent())
		{
			UIHelper.highlightElement(getDriver(), EnterNewSection);	
		}
	}
	
	// enters new acct no
	public void newacctnofn(String NewAcctNo)
	{
		if(Newacctno.isPresent())
		{
			Newacctno.type(NewAcctNo);
		}
		
	}
	
	// enters new accttypecode
	public void newaccttypecode(String NewAcctTypeCode)
	{
		if(Newaccttypecode.isPresent())
		{
			Newaccttypecode.selectByVisibleText(NewAcctTypeCode);
		}
		
	}
	
	// Select accountconvtype code from dropdown
	public void AcctConvTypeCodefn(String AccountConversionTypeCode)
	{
		if(AcctConvTypeCodedd.isPresent())
		{
			AcctConvTypeCodedd.selectByVisibleText(AccountConversionTypeCode);
			
		}
		
	}
	// Picks Account conversion date from calendar
	public void AcctConvTypeDateMonth() throws ParseException
	{
		if(AcctConvDatePicker.isPresent())
		{
			AcctConvDatePicker.click();
			WebElement effectiveDate = getDriver().findElement(By.id("ui-datepicker-div"));  
            //List<WebElement> rows=dateWidget.findElements(By.tagName("tr"));  
            List<WebElement> effcolumns=effectiveDate.findElements(By.tagName("td"));
           
           
            for (WebElement cell: effcolumns)
            	
            { 
            	 Date today = Calendar.getInstance().getTime();
                 DateFormat df = new SimpleDateFormat("dd");
                 String reportDate = df.format(today);
                    if (cell.getText().equals(reportDate))
                    {  
                    	cell.findElement(By.linkText(reportDate)).click();  
                    }
                    	
            }
		
	    }
    }
	
	//Submits the AH Request
	
	public void SubmitRequest() throws Exception
	{
	if(SubmitBtn.isPresent())
	{
		SubmitBtn.click();
		DialogboxAHRequestOkButton.click();
	}
	}
	
	//Close the message pop up and if AH request is submitted successfully, this method will take the values from db and return it else it will return null
	
	public ArrayList<String> AHRequestSearchResultsDB(String ContributorNumber) throws ClassNotFoundException, SQLException {
		ArrayList<String> dbValue=new ArrayList();
		String dialogboxtext=DialogboxAHRequest.getTextValue();
		UIHelper.highlightElement(getDriver(),DialogboxAHRequestOkButton);	
		String MasterChild = "Status of old account does not match the status of new Account (Master - Child ). Open ticket to override the validation";
		String AHReqSuccessMsg = "AH Request placed Successfully";		
		Class.forName("oracle.jdbc.driver.OracleDriver"); 
    	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
    	Statement st=con.createStatement();
    	String sqlquery1= "select SBFE_CTBR_NBR, BEF_CHG_ACCT_NBR, AFT_CHG_ACCT_NBR, bef_chg_acct_typ_code,aft_chg_acct_typ_code,acct_conv_typ_code from acct_id_info_mnl_chg where sbfe_ctbr_nbr='"+ContributorNumber+"' and ROWNUM = 1 order by row_cre_tmst desc";
    	ResultSet rs=st.executeQuery(sqlquery1);
    	while (rs.next())
    	{
    		if(dialogboxtext.equals(AHReqSuccessMsg))
    		{
    			UIHelper.highlightElement(getDriver(),DialogboxAHRequestOkButton);
    			//DialogboxAHRequestOkButton.click();
    			dbValue.add(rs.getString("SBFE_CTBR_NBR"));
    			dbValue.add(rs.getString("BEF_CHG_ACCT_NBR"));
    			dbValue.add(rs.getString("AFT_CHG_ACCT_NBR"));
    			dbValue.add(rs.getString("bef_chg_acct_typ_code"));
    			dbValue.add(rs.getString("aft_chg_acct_typ_code"));
    			dbValue.add(rs.getString("acct_conv_typ_code"));
    
    			
    			//System.out.println("trueeeeeeeeeeeeeee*********"+dbValue);
    		}	
    		else if(dialogboxtext.equals(MasterChild))
    		{
    			
    			dbValue=null;
    			//DialogboxAHRequestOkButton.click();
    			//System.out.println("falseeeeeeeeeeeeee"+dbValue);
    			  
    		}
    	    
	    }    	    	
    	
    	System.out.println("finalllllllllllllllllllllllllllllllllll"+dbValue);
		return dbValue;
		
		}


	public ArrayList<String> AHRequestSearchResultsUI(String ContributorNumber, String OldAcctNo, String OldAcctTypecode,String NewAcctNo,String NewAcctTypeCode,String AccountConversionTypeCode)
	{
		String MasterChild = "Status of old account does not match the status of new Account (Master - Child ). Open ticket to override the validation";
		String AHReqSuccessMsg = "AH Request placed Successfully";
		ArrayList<String> UIEnteredValue=new ArrayList();
		String dialogboxtext=DialogboxAHRequest.getTextValue();
		if(dialogboxtext.equals(AHReqSuccessMsg))
		{
		
		UIEnteredValue.add(ContributorNumber);
		UIEnteredValue.add(OldAcctNo);
		UIEnteredValue.add(OldAcctTypecode);
		UIEnteredValue.add(NewAcctNo);
		UIEnteredValue.add(NewAcctTypeCode);
		UIEnteredValue.add(AccountConversionTypeCode);
		//System.out.println("returnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
		//System.out.println("returnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"+UIEnteredValue);
		
		
	}
		else if(dialogboxtext.equals(MasterChild))
		{
			UIEnteredValue=null;
			//System.out.println("returnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"+UIEnteredValue);
		}
		System.out.println("finalllllllllllllllllllllll"+UIEnteredValue);
		return UIEnteredValue;
	}

	public Boolean AHReqSubmStatusCodeDB(String ContributorNumber) throws ClassNotFoundException, SQLException {
		
		String MasterChild = "Status of old account does not match the status of new Account (Master - Child ). Open ticket to override the validation";
		String AHReqSuccessMsg = "AH Request placed Successfully";
		String dialogboxtext=DialogboxAHRequest.getTextValue();
		Class.forName("oracle.jdbc.driver.OracleDriver"); 
    	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
    	Statement st=con.createStatement();
    	String sqlquery1= "select CHG_STAT_CD from acct_id_info_mnl_chg where sbfe_ctbr_nbr='"+ContributorNumber+"' and ROWNUM = 1 order by row_cre_tmst desc";
    	ResultSet rs=st.executeQuery(sqlquery1);
    	while (rs.next())
		if(dialogboxtext.equals(AHReqSuccessMsg))
		{
			String CHG_STAT_CD=rs.getString("CHG_STAT_CD");
			if (CHG_STAT_CD.equals(29169))
			{
				
				System.out.println("Status code for AH Request Success message from DB"+CHG_STAT_CD);
				return true;
			}
			if (!CHG_STAT_CD.equals(29169))
			{
				return false;
			}
			
		}
    	if(dialogboxtext.equals(MasterChild))
    	{
    		return false;
    	}
		
    	return false;
	}
	
	
public Boolean AHReqSubmStatusCodeUI() throws ClassNotFoundException, SQLException 
{
		
		String MasterChild = "Status of old account does not match the status of new Account (Master - Child ). Open ticket to override the validation";
		String AHReqSuccessMsg = "AH Request placed Successfully";
		String dialogboxtext=DialogboxAHRequest.getTextValue();
		if(dialogboxtext.equals(AHReqSuccessMsg))
		{
			return true;
		}
		if(dialogboxtext.equals(MasterChild))
    	{
    		return false;
    	}
		
    	return false;
		
 }


public Boolean AHReqSubmResultCodeDB(String ContributorNumber) throws ClassNotFoundException, SQLException {
	
	String MasterChild = "Status of old account does not match the status of new Account (Master - Child ). Open ticket to override the validation";
	String AHReqSuccessMsg = "AH Request placed Successfully";
	String dialogboxtext=DialogboxAHRequest.getTextValue();
	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
	Statement st=con.createStatement();
	String sqlquery1= "select CHG_RSLT_CD from acct_id_info_mnl_chg where sbfe_ctbr_nbr='"+ContributorNumber+"' and ROWNUM = 1 order by row_cre_tmst desc";
	ResultSet rs=st.executeQuery(sqlquery1);
	while (rs.next())
	if(dialogboxtext.equals(AHReqSuccessMsg))
	{
		String CHG_RSLT_CD=rs.getString("CHG_RSLT_CD");
		if (CHG_RSLT_CD.equals(20095))
		{
			
			
			return true;
		}
		else if (CHG_RSLT_CD.equals(29829))
		{
			System.out.println("Status code for AH Request Success message from DB-Rejected"+CHG_RSLT_CD);
			return false;
		}
		
	}
	if(dialogboxtext.equals(MasterChild))
	{
		return false;
	}
	
	return false;
}



public Boolean AHReqSubmResultCodeUI() throws ClassNotFoundException, SQLException 
{
		
		String MasterChild = "Status of old account does not match the status of new Account (Master - Child ). Open ticket to override the validation";
		String AHReqSuccessMsg = "AH Request placed Successfully";
		String dialogboxtext=DialogboxAHRequest.getTextValue();
		if(dialogboxtext.equals(AHReqSuccessMsg))
		{
			return true;
		}
		if(dialogboxtext.equals(MasterChild))
    	{
    		return false;
    	}
		
    	return false;
		
 }

public void AHRequestJobInvoke() {
	
	String url = "http://158.151.156.215:8080/sbfe-acct-id-change/jobs/AcctIdChangeJob";
	getDriver().get(url);
	getDriver().manage().window().maximize();
	UIHelper.waitForPageToLoad(getDriver());
	LaunchButton.click();
	
	
}







}
				
		
	
	
		
		



