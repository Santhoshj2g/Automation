package com.dnb.automation.imreg.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class IMHomePage extends PageObject {
	
	@FindBy(xpath = "//*[@id='banner_top_part']//*[@id='tblNav']//*/a[contains(.,'Home')]")
	private WebElementFacade homeLink;
		
	public boolean verifyHomePageDisplayed() throws Exception
	{
		getDriver().switchTo().frame("Banner");
		if(homeLink.isDisplayed())
		{
			getDriver().switchTo().defaultContent();
			Thread.sleep(4000);
			return true;
		}
		else
		{
			return false;
		}
	}
}
