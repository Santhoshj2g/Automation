package com.dnb.automation.onboard.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;
import com.dnb.automation.utils.UIHelper;

public class LoginPage extends PageObject {

 //   @FindBy(xpath = "//*[@id='userid']")
 //   private WebElementFacade userName;
	
	@FindBy(id="user_email")
	private WebElementFacade userName;

  //  @FindBy(xpath = "//*[@id='password-password']")
  //  private WebElementFacade password;
	
	@FindBy(id="user_password")
	private WebElementFacade password;

    //@FindBy(xpath = ".//*[@id='loginButton']")
    //private WebElementFacade loginbutton;
	
	@FindBy(id="user_submit")
    private WebElementFacade loginbutton;

    @FindBy(xpath = "//*[@id='container']//*[@id='form']//*@id='qaServicesRadio']")
    private WebElementFacade environmentQA;

	
	@FindBy(id= "advancedLnk")
	private WebElementFacade advancelink;
	
	//@FindBy(xpath = "//*[@id='session']")
   // private WebElementFacade casereference;
	
	@FindBy(id="newSessionId")
	private WebElementFacade casereference;
	
	@FindBy(id="changeSessionRef")
	private WebElementFacade caseRefOkBtn;
	
    // User launch the application

    public void launchOnboardApplication(String appURL) {
        getDriver().manage().deleteAllCookies();
        getURLtoLaunch(appURL);
    }

    // User Launch the URL
    public void getURLtoLaunch(String appURL) {
        getDriver().get(appURL);
        getDriver().manage().window().maximize();
        UIHelper.waitForPageToLoad(getDriver());
    }

    // User verifies the login credentials

    public void login(String username, String pwd, String caseref) throws Exception {
        enterLogin(username);
        enterpassword(pwd);  
        loginButton();
        UIHelper.waitForPageToLoad(getDriver());
        entercaseref(caseref);
		//onRadioButtonClicked(environment);
        
    }

    public void enterLogin(String username) throws Exception {
        try {
            UIHelper.highlightElement(getDriver(), userName);
            userName.type(username);
        }

        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void enterpassword(String pwd) throws Exception {
        try {
            UIHelper.highlightElement(getDriver(), password);
            password.type(pwd);
        }

        catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    //user enters case reference name
    public void entercaseref(String caseref) throws Exception {
        try {
            UIHelper.highlightElement(getDriver(), casereference);
            casereference.type(caseref);
            UIHelper.highlightElement(getDriver(), caseRefOkBtn);
            caseRefOkBtn.click();
            
        }

        catch (Exception e) {
            e.printStackTrace();
        }
    }
    // User clicks on login button

    public void loginButton() throws Exception {
        try {
            if (loginbutton.isPresent()) {
                UIHelper.highlightElement(getDriver(), loginbutton);
                loginbutton.click();
                UIHelper.waitForPageToLoad(getDriver());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
