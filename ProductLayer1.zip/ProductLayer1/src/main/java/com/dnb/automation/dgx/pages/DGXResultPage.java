package com.dnb.automation.dgx.pages;

import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.CommonMethods;
import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import java.util.ArrayList;
import java.util.List;

public class DGXResultPage extends PageObject
{

	@FindBy(xpath=".//table/tbody/tr/td/pre")
	private WebElementFacade xmlresult;

	private String result="";
	private String code="CODE";
	private String assDate="ASMT_DT";
	private String algID="ALGM_ID";
	private String failScr="FAIL_SCR";
	private String failpercentile="FAIL_SCR_NATL_PCTG";
	private String dnbRating="DNB_RATG";
	private String commentry="SCR_CMTY_CD";
	private String serRat="SER_RAT";
	private String scrClass="SCR_CLAS";
	private String defInci="DEFU_INDN";
	private String creditLim="MAX_CR";
	private String failOverride ="FAIL_SCR_OVRD_CD";

	public boolean verifyResultPage(String expected)
	{
		boolean flag=false;
		try{
			xmlresult.waitUntilPresent();
			result=CommonMethods.getattributeinXML(xmlresult.getText(),code,0);
			if(result.trim().equals(expected)){
				flag= true;
			}else{
				flag= false;
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}

	public String verifyFailScr()
	{
		try{
			if(xmlresult.isPresent()){
				result=CommonMethods.getattributeinXML(xmlresult.getText(),failScr, 0);
			}
		}catch(Exception e){

		}
		return result;
	}

	public String verifyAssDate()
	{
		try{
			if(xmlresult.isPresent()){
				result=CommonMethods.getattributeinXML(xmlresult.getText(),assDate, 0);
			}
		}catch(Exception e){

		}
		return result;
	}

	public String verifyAlgorithm(String servicesValue)
	{
		String result="";
		List<String> actual= new ArrayList<>();
		try{
			if(xmlresult.isPresent()){
				actual = CommonMethods.getattributeListinXML(xmlresult.getText(),algID);
				for(int i=0;i<actual.size();i++){
					if(actual.get(i).equalsIgnoreCase(servicesValue))
						result=actual.get(i);
				}
			}



		}catch(Exception e){

		}
		return result;

	}

	public String verifyFailPercent()
	{
		try{
			if(xmlresult.isPresent())
				result=CommonMethods.getattributeinXML(xmlresult.getText(),failpercentile, 0);

		}catch(Exception e){

		}
		return result;
	}

	public List<String> verifyCommentry()throws Exception
	{
		List<String> actual = new ArrayList<>();

		try{
			if(xmlresult.isPresent()){
				int length = CommonMethods.getNodelength(xmlresult.getText(),commentry);
				actual=CommonMethods.getattributeListinXML(xmlresult.getText(),commentry);
			}

		}
		catch(Exception e){

		}
		return actual;
	}

	public String verifyDnbRat()
	{
		try{
			if(xmlresult.isPresent())
				result=CommonMethods.getattributeinXML(xmlresult.getText(),dnbRating, 0);

		}catch(Exception e){

		}
		return result;
	}

	public String verifySERRat() {

		try{
			if(xmlresult.isPresent())
				result=CommonMethods.getattributeinXML(xmlresult.getText(),serRat, 0);

		}catch(Exception e){

		}
		return result;
	}

	public String verifyScrClass()
	{
		try{
			if(xmlresult.isPresent())
				result=CommonMethods.getattributeinXML(xmlresult.getText(),scrClass, 0);

		}catch(Exception e){

		}
		return result;

	}

	public String verifyDefIncidence()
	{
		try{
			if(xmlresult.isPresent())
				result=CommonMethods.getattributeinXML(xmlresult.getText(),defInci, 0);

		}catch(Exception e){

		}
		return result;
	}

	public String verifyCreditLimit() {
		try{
			if(xmlresult.isPresent())
				result=CommonMethods.getattributeinXML(xmlresult.getText(),creditLim, 0);

		}catch(Exception e){

		}
		return result;
	}

	public String verifyFailOverride() {
		try{
			if(xmlresult.isPresent())
				result=CommonMethods.getattributeinXML(xmlresult.getText(),failOverride,0);

		}catch(Exception e){

		}
		return result;
	}
}


