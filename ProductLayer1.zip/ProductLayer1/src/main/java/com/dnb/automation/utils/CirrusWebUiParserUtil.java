package com.dnb.automation.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CirrusWebUiParserUtil {

    public static Map<String, String> serviceVsWeb = new LinkedHashMap<String, String>();

    public static void main(String a[]) throws InterruptedException {
        // Map<String, String> jsonResponse = getWebserviceResponse();

        WebDriver driver = new FirefoxDriver();
//        driver.get("https://uat-cirrus.dnbcloud.com/report/200443976/tab/company-profile?country=CA");// company
        // profile
        driver.get("https://uat-cirrus.dnbcloud.com/report/202095022?country=CA");// summary

        // driver.get("https://uat-cirrus.dnbcloud.com/report/200443976/tab/legal-events?country=CA");
        // driver.get("https://uat-cirrus.dnbcloud.com/report/200443976/tab/legal-events?country=CA");//legalevent
        driver.manage().window().maximize();
        login(driver);
        Thread.sleep(5000);
        sideMenuItems(driver);
        Thread.sleep(5000);
        Map<String, List<Object>> map = tabNames(driver);
        // To read the list of Key Sets COMPANY PROFILE, RISK ASSESSMENT,
        map.keySet();
        ((Map<String,Map<String,String>>)map.get("LEGAL EVENTS").get(0)).get("Insolvency").get("Indicator/Count");
        getWebElementValue("LEGAL EVENTS|Insolvency|Indicator/Count",map);
        System.out.println("End" + map.toString());
        driver.close();
    }

    public static Map<String, List<Object>> getTabWebElementMap(WebDriver driver) throws InterruptedException {
        Map<String, List<Object>> map = tabNames(driver);
        return map;
    }

    @SuppressWarnings("unchecked")
    public static String getWebElementValue(String webUiQueryParam, Map<String, List<Object>> map) {
        String value = "";
        String[] webUiPath = webUiQueryParam.split("\\|");
        if (webUiPath.length > 2) {
            if (map.containsKey(webUiPath[0])
                    && ((Map<String, Map<String, String>>) map.get(webUiPath[0]).get(0)).containsKey(webUiPath[1])
                    && ((Map<String, Map<String, String>>) map.get(webUiPath[0]).get(0)).get(webUiPath[1]).containsKey(
                            webUiPath[2])) {
                value = ((Map<String, Map<String, String>>) map.get(webUiPath[0]).get(0)).get(webUiPath[1]).get(
                        webUiPath[2]);
            } else {
                return null;
            }
        } else {
            if (map.containsKey(webUiPath[0])
                    && ((Map<String, String>) map.get(webUiPath[0]).get(1)).containsKey(webUiPath[1])) {
                value = ((Map<String, String>) map.get(webUiPath[0]).get(1)).get(webUiPath[1]);
            } else {
                return null;
            }
        }
        return value;
    }

    private static Map<String, List<Object>> tabNames(WebDriver driver) throws InterruptedException {
        List<WebElement> elementList;
        Thread.sleep(5000);
        elementList = driver.findElements(By.className("cirrus-panel"));
        Map<String, List<Object>> section = new LinkedHashMap<String, List<Object>>();
        for (WebElement ele : elementList) {
            List<WebElement> panelBodyEleList = ele.findElements(By.className("panel-body"));
            section.put(ele.findElement(By.className("panel-heading")).getText(), elementNameAndValue(panelBodyEleList));
        }
        return section;
    }

    private static List<Object> elementNameAndValue(List<WebElement> panelBodyEleList) {
        Map<String, Map<String, String>> table2d = new LinkedHashMap<String, Map<String, String>>();
        Map<String, String> elementMap = new LinkedHashMap<String, String>();
        for (WebElement ele : panelBodyEleList) {
            if (elementContainsByClassName(ele, By.className("panel-heading"))) {
                elementMap.putAll(parseHeadingValuePair(ele));// TRADE PAYMENTS
            } else if (elementContainsByClassName(ele, By.tagName("table"))
                    && !elementContainsByClassName(ele, By.tagName("thead"))) {
                elementMap.putAll(parse2dTable(ele));
            } else if (elementContainsByClassName(ele, By.tagName("table"))) {
                table2d.putAll(parseTable(ele));// LEGAL EVENTS
            } else if (elementContainsByClassName(ele, By.className("headline-plus"))) {
                elementMap.putAll(parseHeadlineSubTitleValue(ele));
            } else if (elementContainsByClassName(ele, By.className("row"))) {
                elementMap.putAll(parseColumnArray(ele));
            }
            else{
                elementMap.putAll(parseNameValuePair(ele));// COMPANY PROFILE
            }
        }
        List<Object> listSection = new ArrayList<Object>();
        listSection.add(table2d);
        listSection.add(elementMap);
        System.out.println(table2d.toString());
        System.out.println(elementMap.toString());
        return listSection;
    }

    private static  Map<String, String> parseColumnArray(WebElement ele) {
        Map<String, String> map = new LinkedHashMap<String, String>();
        // COMPANY PROFILE
        try {
            List<WebElement> elementTitleList = ele.findElements(By.className("columnar-list-title"));
            List<WebElement> elementValueList = ele.findElements(By.className("columnar-list-value"));
            int i = 0;
            for (WebElement titleElement : elementTitleList) {
              map.put(titleElement.getText() ,elementValueList.get(i++).getText());
            }
        } catch (Exception e) {

        }
        return map;
    }
    
    private static Map<String, String> parse2dTable(WebElement element) {
        Map<String, String> table2d = new LinkedHashMap<String, String>();
        try {
            WebElement tableElement = element.findElement(By.tagName("table"));
            List<WebElement> tableRowList = tableElement.findElements(By.tagName("tr"));
            // fill values
            if (tableRowList.size() != 0) {
                if (tableRowList.get(0).findElements(By.tagName("td")).size() > 2) {
                    WebElement keyRow = tableRowList.get(0).findElements(By.tagName("td")).get(1);
                    Map<String, String> tableContent = new LinkedHashMap<String, String>();
                    // table2d.put(keyRow.getText(), tableContent);
                    for (int i = 0; i < tableRowList.size(); i++) {
                        List<WebElement> tableColumnList = tableRowList.get(i).findElements(By.tagName("td"));
                        tableContent.put(tableColumnList.get(0).getText(), tableColumnList.get(1).getText());
                    }
                } else {

                    for (WebElement rowElement : tableRowList) {
                        List<WebElement> columnList = rowElement.findElements(By.tagName("td"));
                        if (!columnList.isEmpty()) {
                            table2d.put(columnList.get(0).getText(), columnList.get(1).getText());
                            System.out.println(columnList.get(0).getText() + " = " + columnList.get(1).getText());
                        }
                    }
                }
            }
            return table2d;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return table2d;
    }

    private static Map<String, String> parseNameValuePair(WebElement element) {
        Map<String, String> elementMap = new LinkedHashMap<String, String>();
        try {
            String[] elementKeyValue = element.getText().split("\n");
            for (int i = 0; i < elementKeyValue.length; i++) {
                elementMap.put(elementKeyValue[i], elementKeyValue[++i]);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return elementMap;
    }

    private static Map<String, String> parseHeadingValuePair(WebElement element) {
        Map<String, String> elementMap = new LinkedHashMap<String, String>();
        try {
            if (elementContainsByClassName(element, By.className("row"))) {
                List<WebElement> rowElementList = element.findElements(By.className("row"));
                for (WebElement rowElement : rowElementList) {
                    // Getting the Select UI Model
                    if (elementContainsByClassName(rowElement, By.className("selected"))) {
                        WebElement elementPanelHeading = element.findElement(By.className("panel-heading"));
                        String value = rowElement.findElement(By.className("selected")).getText();
                        elementMap.put(elementPanelHeading.getText(), value);
                    } else if (elementContainsByClassName(rowElement, By.tagName("table"))) {// parse table inside row
                                                                                             // div
                        elementMap.putAll(parse2dTable(rowElement));
                    } else { // parse row content
                        WebElement elementPanelHeading = element.findElement(By.className("panel-heading"));
                        String value = rowElement.getText();
                        elementMap.put(elementPanelHeading.getText(), value);
                    }

                }
            } else {
                WebElement elementPanelHeading = element.findElement(By.className("panel-heading"));
                elementMap.putAll(parseHeadlineSubValue(elementPanelHeading));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return elementMap;
    }

    private static boolean elementContainsByClassName(WebElement element, By type) {
        try {
            element.findElement(type);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static Map<String, String> parseHeadlineSubTitleValue(WebElement ele) {
        Map<String, String> map = new LinkedHashMap<String, String>();

        List<WebElement> elementPanelHeading = ele.findElements(By.className("headline-plus"));
        for (WebElement elementPanel : elementPanelHeading) {
            try {
                List<WebElement> elementList = elementPanel.findElements(By.tagName("div"));
                for (int i = 0; i < elementList.size(); i++) {
                    map.put(elementList.get(i).getText(), elementList.get(++i).getText());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return map;
    }

    private static Map<String, String> parseHeadlineSubValue(WebElement ele) {
        Map<String, String> elementMap = new LinkedHashMap<String, String>();
        try {
            List<WebElement> elementPanelHeading = ele.findElements(By.className("headline-plus"));

            for (WebElement elementPanel : elementPanelHeading) {
                if (!elementPanel.getText().equals("")) {
                    List<WebElement> elementValueList = elementPanel.findElements(By.className("headline-plus-value"));
                    List<WebElement> elementSubValueList = elementPanel.findElements(By
                            .className("headline-plus-subvalue"));
                    if (elementContainsByClassName(elementPanel, By.className("headline-plus-subvalue"))) {
                        for (int i = 0; i < elementValueList.size(); i++) {
                            elementMap.put(elementValueList.get(i).getText(), elementSubValueList.get(i).getText());
                        }
                    } else {
                        elementMap.put(ele.findElement(By.className("panel-heading")).getText(), elementValueList
                                .get(0).getText());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return elementMap;
    }

    private static Map<String, Map<String, String>> parseTable(WebElement ele) {
        Map<String, Map<String, String>> table = new HashMap<String, Map<String, String>>();
        try {
            WebElement tableElement = ele.findElement(By.tagName("table"));
            List<WebElement> tableHeadList = tableElement.findElement(By.tagName("thead")).findElements(
                    By.tagName("td"));
            List<WebElement> tableRowList = tableElement.findElements(By.tagName("tr"));

            Map<Integer, String> headerMap = new LinkedHashMap<Integer, String>();
            // Column name
            for (int i = 1; i < tableHeadList.size(); i++) {
                headerMap.put(i, tableHeadList.get(i).getText());
            }
            // fill values
            for (int i = 1; i < tableRowList.size(); i++) {
                List<WebElement> tableColumnList = tableRowList.get(i).findElements(By.tagName("td"));
                LinkedHashMap<String, String> coulmnValueMap = new LinkedHashMap<String, String>();
                table.put(tableColumnList.get(0).getText(), coulmnValueMap);
                for (int columnInc = 1; columnInc < tableColumnList.size(); columnInc++) {
                    coulmnValueMap.put(headerMap.get(columnInc), tableColumnList.get(columnInc).getText());
                }
            }
            System.out.println(table.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
        return table;
    }

    private static void sideMenuItems(WebDriver driver) {
        WebElement element = driver.findElement(By.className("cirrus-tabs"));
        List<WebElement> elementList = element.findElements(By.tagName("span"));

        for (WebElement ele : elementList) {
            // TODO add code for navigate and get all the menu item
            if (!ele.getText().equals("")) {
                System.out.println(ele.getText().trim());
            }
        }
    }

    private static void login(WebDriver driver) {
        WebElement element = driver.findElement(By.name("username"));
        element.clear();
        element.sendKeys("george@uat.com");
        element = driver.findElement(By.name("password"));
        element.clear();
        element.sendKeys("Welcome1");
        element.submit();
    }

}