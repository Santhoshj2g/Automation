package com.dnb.automation.cirrus.pages;

import java.awt.datatransfer.Transferable;
import java.util.ArrayList;
import java.util.List;

import org.jbehave.core.annotations.Named;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.CommonMethods;
import com.dnb.automation.utils.UIHelper;
import com.gargoylesoftware.htmlunit.javascript.host.media.webkitAudioContext;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.core.pages.WebElementState;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/******************************************************************************************************
 * Description : SearchPage class contains locators and methods for search page
 *
 *******************************************************************************************************/
public class SearchPage extends PageObject {

	// variable declaration
	private String searchedDUNSValue;
	private String searchedDUNS;
	private String searchedRowValue;
	private boolean isMatchSearchResult;
	private String clickedCompanyName;
	private String companyNameInReportPg;

	private String resultantValue = null;
	private String getCompanyValues = null;
	private String tradeUpMsgStart = "The branch report you selected for ";
	private String tradeUpMsgEnd = " has been automatically upgraded to the headquarters report. If you still wish to view the branch report, click here";
	private String tradeheaderMsg = null;
	ArrayList<String> elementsOfKeydataPanel = new ArrayList<String>();

	private String normalDunsMsg = "Get the full report to see complete information on this company.";
	private String outofBusniessDunsMsg = "This company is Out of Business. You may still view the full report to see complete information";
	private String stopDistributionDunsMsg = "The report could not be fulfilled because D&B is currently verifying the accuracy of information on this company or there is a technical issue with delivery of the report. Until this time D&B has stopped distribution of this report";
	private String annualSales = null;
	private String lineOfbusiness = null;
	private String ownerShip = null;
	private String employees = null;

	CommonMethods objCommonMethods;

	// getters
	public boolean isMatchSearchResult() {
		System.out.println("Is Match Result ?? " +isMatchSearchResult);
		return isMatchSearchResult;
	}

	// Xpaths
	@FindBy(xpath = "//*/basic-search-view/form/div[@class='input-group country-dropdown']/input")
	private WebElementFacade txtSearch;

	@FindBy(xpath = "//*/button[@ng-click='search()']")
	// //*/basic-search-view/form/div[@class='input-group
	// country-dropdown']/span/button[@class='btn btn-default btn-search']
	private WebElementFacade iconSearch;

	@FindBy(xpath = "//*/a[@class='select2-choice ui-select-match']/span[@class='select2-chosen']/span")
	private WebElementFacade drpdwnCountry;

	@FindBy(xpath = "//*/ul[@class='ui-select-choices ui-select-choices-content select2-results']/li/ul")
	private WebElementFacade drpdwnElementCountryList;

	@FindBy(xpath = "//*/ul[@class='ui-select-choices ui-select-choices-content select2-results']/li/ul/li/div/span")
	private List<WebElementFacade> drpdwnCountryValues;

	@FindBy(xpath = "//*/input[@class='ui-select-search select2-input ng-pristine ng-valid ng-touched']")
	private WebElementFacade txtBoxCountry;
	
	@FindBy(xpath = "//*/input[contains(@class,'ui-select-search select2-input')]")
	private WebElementFacade searchTextBoxCountry;
	
	@FindBy(xpath = "//fieldset//div[@class='form-group']//div[@class='select2-search']/input")
	private WebElementFacade advanceSearchTextBoxCountry;
	
	String  advanceSearchTextBoxStateStr ="//div/div/div/div/div/div/div/form/fieldset/div/div/div[2]/div/div/a";
	@FindBy(xpath = "//div/div/div/div/div/div/div/form/fieldset/div/div/div[2]/div/div/a")
	private WebElementFacade advanceSearchTextBoxState;
	
	@FindBy(xpath = "//body/div/div/div/div/div/div/div/form/fieldset/div[1]/div[2]/div[2]/div/div/div/div/input")
	private WebElementFacade advanceSearchTextBoxStateinput;
	
	List<String>  advanceSearchTextBoxStateNameListStr =new ArrayList<>();
	@FindBy(xpath = "//form/fieldset//div[@name='territory']//ul/li/ul/li/div")
	private List<WebElementFacade> advanceSearchTextBoxStateNameList;
	
	@FindBy(xpath = "//form/fieldset//div[@name='territory']//ul/li/ul/li/div/span")
	private WebElementFacade advanceSearchTextBoxStateName;
	
	@FindBy(xpath = "//basic-search-view/form/div/div/div/ul")
	private WebElementFacade quickSearchTextBoxremovedCountryName;
	
	@FindBy(xpath = "//form/fieldset//div/ul[contains(@repeat,'country in countries')]")
	private WebElementFacade advancedSearchTextBoxremovedCountryName;
		
	@FindBy(xpath = "//*[@id='top-nav-search-container']/basic-search-view/form/div/div/a/span/span[contains(@translate,'country')]")
	private WebElementFacade getdropdownCountryname;
	
	@FindBy(xpath = "//body//basic-search-view/form//div/span[contains(@translate,'country')]")
	private List<WebElementFacade> getdropdownCountrynameList;
	
	@FindBy(xpath = "//basic-search-view/form/div/div/div/ul")
	private List<WebElementFacade> getdropdownremovedCountrynameList;	
	
	@FindBy(xpath = "//fieldset/div/div/div/div/div/div/ul/li/ul/li/div/span[contains(@translate,'country')]")
	private List<WebElementFacade> getAdvanceddropdownCountrynameList;	
	
	@FindBy(xpath = "//form[@name='advancedSearchForm']//div[@class='col-xs-6']/a/span")
	private List<WebElementFacade> advanceSearchExit;	
	
	@FindBy(xpath = "//*[@id='ui-select-choices-row-6-0']/div/span")
	private WebElementFacade advanceSearchgetdropdownStatename;
	
	@FindBy(xpath = "//*[@id='countryObj']/a/span/span")
	private WebElementFacade advanceSearchgetdropdownCountryname;
	
	@FindBy(xpath = "//*[@id='top-nav-search-container']/basic-search-view/form//span[contains(@class,'advanced-search-anchor')]/a")
	private WebElementFacade advancesearchexpand;
	
	@FindBy(xpath = "//*[@id='countryObj']/a")
	private WebElementFacade noSearchCompanytxt;
	
	@FindBy(xpath = "//div[@class='modal fade advanced-search-modal in']//fieldset//a/span/span")
	private WebElementFacade advancesearchcountry;	

	@FindBy(xpath = "//form//a[contains(@class,'advancedSearchClose')]")
	private WebElementFacade closeBtn;
	
	@FindBy(xpath = "//*/search-info-row//*/div[@class='row panel-body']")
	private List<WebElementFacade> lstSearchRows;
	
	@FindBy(xpath = "//*/search-info-row/div/div[1]")
	private List<WebElementFacade> noOfRowsDisplayedinPreviewPage;
	
	@FindBy(xpath = "//*/search-info-row//h2[@class='result-company-name']/a")
	private List<WebElementFacade> companyNamesfromEachRow;

	@FindBy(xpath = "//*/search-info-row//*/h2/a")
	private List<WebElementFacade> lstSearchedCompanyNames;

	@FindBy(xpath = "//*/search-info-row//*/dl/dd[@ng-show='company.duns']")
	private List<WebElementFacade> valSearchedDUNS;

	@FindBy(xpath = "//*/ul[@class='nav navbar-nav navbar-right']//*/a")
	private WebElementFacade btnUser;

	@FindBy(xpath = "//*/ul[@class='nav navbar-nav navbar-right']//*/ul/li/a")
	private WebElementFacade lstUserBtn;

	@FindBy(xpath = "//*/header//*/div[contains(@class,'investigation')]/p/a")
	private WebElementFacade lnkOrderInvestigationInHeader;

	@FindBy(xpath = "//*/div[@class='col-md-12 no-padding']/div/span/p[1]")
	private WebElementFacade noResult;

	private String iconLoading = "//*/main/div[@class='content']//*/div[@class='loading']";

	@FindBy(xpath = "//*/search-info-row//*/dl/dd[@ng-show='company.duns']")
	private WebElement valDUNS;

	@FindBy(xpath="//*/search-info-row//*/dl[@class='search-row-registration']/dd")
	private WebElementFacade valRegNo;

	@FindBy(xpath="//*/search-info-row//*/div//*/dl/dd[@ng-show='company.phone']")
	private WebElementFacade valTelNo;

	@FindBy(xpath = "//*/button/span[contains(text(),'View Report')]")
	private WebElementFacade btnViewReport;

	@FindBy(xpath = "//*/div[@class='cirrus-navbar row hidden-sm hidden-xs']//*/a[@class='select2-choice ui-select-match']/span[@class='select2-chosen']/span")
	private WebElementFacade btnSearchCountry;

	@FindBy(xpath = "//*/header//*/div[contains(@class,'investigation')]/p/span")
	private WebElementFacade msgCantFindBusiness;

	@FindBy(xpath = "//*/footer/div/p/a")
	private WebElementFacade lnkOrderInvestigationInFooter;

	@FindBy(xpath = "html/body//*/input[@name='username']")
	private WebElementFacade txtUserName;

	@FindBy(xpath = "//*/div[@class='clearfix container cirrus-container']//*/div[@class='growl-container growl-fixed top-right']/div")
	private WebElementFacade popUp;

	@FindBy(xpath = "//*/div[@class='clearfix container cirrus-container']//*/div[@class='growl-container growl-fixed top-right']"
			+ "/div[contains(@class,'alert-error alert-danger icon ')]")
	private WebElementFacade popUpMsgErr;

	@FindBy(xpath = "//*/div[@class='clearfix container cirrus-container']//*/div[@class='growl-container growl-fixed top-right']"
			+ "/div[contains(@class,'alert-error alert-danger icon ')]/button[@data-dismiss='alert']")
	private WebElementFacade closeErrPopUp;

	@FindBy(xpath = "//*/div[@class='clearfix container cirrus-container']//*/div[@class='growl-container growl-fixed top-right']/div/div")
	private WebElementFacade popUpMsg;

	// @FindBy(xpath="//*/div[@class='row panel-body']//h1")
	@FindBy(xpath = "//*/div[contains(@class,'panel report-header panel-default')]/div[@class='row row-height panel-body']/div/h1-style")
	private WebElementFacade companyName;

	@FindBy(xpath = "//*/div[contains(@class,'panel-body')]//*/div/button/span[contains(text(),'Get Report')]")
	private WebElementFacade getReportBtn;

	@FindBy(xpath = "//*/div[contains(@class,'panel-body')]//*/div/ul/li/button")
	private WebElementFacade trackThisCompanyBtn;

	@FindBy(xpath = "//*/div[@class='modal-dialog']//div[@class='modal-content']")
	private WebElementFacade stopTrackModal;

	@FindBy(xpath = "//*/div[contains(@class,'panel-body')]//*/div/ul/li/button[contains(.,'Track this Company')]")
	private WebElementFacade trackThisCompanyBtnSpl;

	@FindBy(xpath = "//*/div[@class='modal-dialog']//div[@class='modal-content']//div[@class='modal-footer']/button[@class='btn btn-danger']")
	private WebElementFacade continueBtnInModal;

	@FindBy(xpath = "//*/main/div/div[2]/div[2]/div/div[2]/div[1]/div/div[3]/div/div[3]/report-header-action-buttons/div/ul/li[1]/button/span[2]")
	private WebElementFacade latestReportBtn;

	@FindBy(xpath = "html/body/div[1]/div[2]/div/main/div/div[2]/div[2]/div/div[2]/div[1]/div/div[3]/div")
	private WebElementFacade latestReportContainer;

	@FindBy(xpath = "//*/div[@class='clearfix container cirrus-container']//*/div[@class='growl-container growl-fixed top-right']"
			+ "/div/button[@data-dismiss='alert']")
	private WebElementFacade closePopUp;

	@FindBy(xpath = "//*/div[@class='row company-row']//*/h2/a")
	private WebElementFacade lnk1stComp;

	// QA-
	// @FindBy(xpath="//*/div[@class='cirrus-panel']/div[@class='panel-heading']/h3/a[contains(text(),'Company')]")
	@FindBy(xpath = "//*/div[@class='cirrus-panel']/div[@class='panel-heading']/h3/a/span[contains(text(),'Company')]")
	private WebElementFacade compProfileHeading;

	private String iconReportLoading = "//*/div[@class='content']//*/div[@class='loading']";
	private String iconLoadingAge = "//*/div[@class='dnb-wrapper-content']//*/div[@class='col-md-12']/div[@class='row']/div[@class='loading']";

	Transferable pasteSearch;

	@FindBy(xpath = "//*/main/div/div/h1")
	private WebElementFacade titleInvestigateABusiness;

	@FindBy(xpath = "//*//form[@class='form-horizontal ng-pristine ng-valid']//*/div[@class='input-group-btn']/button")
	private WebElementFacade btnCountryOfBusiness;

	@FindBy(xpath = "//*/div[@class='introjs-tooltipbuttons']/a[@class='introjs-button introjs-skipbutton']")
	private WebElementFacade btnSkipTour;

	@FindBy(xpath = "//*/div[@class='introjs-tooltipReferenceLayer']")
	private WebElementFacade toolTipSkipTour;

	@FindBy(xpath = "//*/div[@class='row panel-body']//*/dl/dt[contains(text(),'D-U-N-S')]/following-sibling::dd[1]")
	private WebElementFacade dunsNoInReportHeader;

	@FindBy(xpath = "//*/small/strong[contains(text(),'Report as of')]/ancestor::small")
	private WebElementFacade reportAsOfdate;

	@FindBy(xpath = "//*[@class='notice-content']/span")
	private WebElementFacade noticeContentMsg;

	@FindBy(xpath = "//*[@class='result-company-name']/a")
	private WebElementFacade resultCompanyName;

	@FindBy(xpath = "//*[@id='left-hand-menu']//*/a[contains(.,'Ownership')]/span[1]")
	private WebElementFacade ownershipDropDown;

	@FindBy(xpath = "//*[@id='left-hand-menu']//*/a[contains(.,'Family Tree')]/span")
	private WebElementFacade familyTreeLnk;

	@FindBy(xpath = "//*/div[contains(@class,'node-parent-selected')]/ul/li[@class='node-hq no-display'][1]//div[@class='node-content']/a/span")
	private WebElementFacade hqLink;

	@FindBy(xpath = "//*[@class='notice-content']/div")
	private WebElementFacade noticeContentMsgDiv;

	@FindBy(xpath = "//*[@id='left-hand-menu']//*[@class='disabled']")
	private List<WebElementFacade> leftHandMenuItems;

	@FindBy(xpath = "//*[@class='headlines']//*/p[@class='hl-label']")
	private WebElementFacade elementsKeydata;

	@FindBy(xpath = "//*[@class='headlines']//*/p[@class='hl-label']")
	private List<WebElementFacade> lstElementsKeydata;

	@FindBy(xpath = "//*[@class='headlines']//*/p[contains(text(),'Annual Sales')]")
	private WebElementFacade annualSalesElement;

	@FindBy(xpath = "//*[@class='headlines']//*/p[contains(text(),'Line of Business')]")
	private WebElementFacade lineOfBusinessElement;

	@FindBy(xpath = "//*[@class='headlines']//*/p[contains(text(),'Ownership')]")
	private WebElementFacade ownershipElement;

	@FindBy(xpath = "//*[@class='headlines']//*/p[contains(text(),'Employees')]")
	private WebElementFacade employeesElement;

	@FindBy(xpath = "//*[@class='company-profile-map']")
	private WebElementFacade googleMap;

	@FindBy(xpath = "//*[@class='headlines']//*/p[contains(text(),'Failure Score')]")
	private WebElementFacade failureScoreElement;

	@FindBy(xpath = "//*[@class='headlines']//*/p[contains(text(),'Delinquency Score')]")
	private WebElementFacade delinquencyScoreElement;

	@FindBy(xpath = "//*[@class='headlines']//*/p[contains(text(),'Age of Business')]")
	private WebElementFacade ageOfBusinessElement;

	@FindBy(xpath = "//*/div[contains(@class,'panel-body')]//div[contains(@class,'hide-in-pdf')]")
	private WebElementFacade portfolioReportHeader;

	@FindBy(xpath = "//*//div[contains(@class,'popover-inner')]//div[contains(@class,'popover-content')]/div")
	private WebElementFacade portfolioToolTip;

	@FindBy(xpath = "//*[@id='reportPortfolioPopover']")
	private WebElementFacade portfolioTag;
	// */div[contains(@class,'panel-body')]//div/ul/li[1]/span

	@FindBy(xpath = "//*//div[contains(@class,'popover-inner')]//div[contains(@class,'popover-content')]/div")
	private WebElementFacade tagToolTip;

	@FindBy(xpath = "//*[@id='reportTagPopover']")
	private WebElementFacade TagIcon;
	
	@FindBy(xpath = "//*[@id='searchPortfolioPopover']")
	private WebElementFacade portfolioButton;

	@FindBy(xpath = "//*/div[contains(@class,'panel-body')]//div/ul[contains(@class,'report-header-indicator')]/li[3]//div[contains(@class,'popover-inner')]//div[contains(@class,'popover-container')]")
	private WebElementFacade alertsToolTip;

	@FindBy(xpath = "//*/div[contains(@class,'panel-body')]//div/ul[contains(@class,'report-header-indicator')]/li[3]/span")
	private WebElementFacade alertsIcon;

	@FindBy(xpath = "//*/div[contains(@class,'report-header')]//*/div[contains(@class,'status-labels')]/span[1]")
	private WebElementFacade bussStatus;

	@FindBy(xpath = "//*/report-header-action-buttons/div/ul/li/span/button")
	private WebElementFacade exportAsPdfBtn;

	@FindBy(xpath = "//*/report-header-action-buttons/div/ul/li/span/ul/li/a[contains(text(),'Export as PDF')]")
	private WebElementFacade exportAsPDFDropDown;

	@FindBy(xpath = "//*/div[@class='content']//*/div[contains(@class,'growl-message')]/span[contains(@class,'flashing-dots')]")
	private WebElementFacade renderingPdfEle;

	private String renderingPdfEleStr = "//*/div[@class='content']//*/div[contains(@class,'growl-message')]/span[contains(@class,'flashing-dots')]";

	@FindBy(xpath = "//*/div[@class='content']//*/div[contains(@class,'growl-item alert')]/div[@class='growl-message']/a")
	private WebElementFacade clickHereBtn;

	private String clickHereBtnStr = "//*/div[@class='content']//*/div[contains(@class,'growl-item alert')]/div[@class='growl-message']/a";

	@FindBy(xpath = "//*/div[@class='content']//*/div[contains(@class,'growl-item alert')]/div[@class='growl-message']")
	private WebElementFacade growlMsg;

	@FindBy(xpath = ".//*[@id='toolbarViewer']")
	private WebElementFacade toolBarInPdf;

	@FindBy(xpath = ".//*[@id='pageContainer1']/xhtml:div[2]")
	private WebElementFacade pdfPageWindow;

	@FindBy(xpath = ".//*[@id='download']/span")
	private WebElementFacade downloadBtnInPdf;

	@FindBy(xpath = "html/body//*/input[@name='password']")
	private WebElementFacade txtPassword;

	@FindBy(xpath = "//div/section/div/form/button[@type='submit']")
	private WebElementFacade btnSubmit;

	@FindBy(xpath = "//div[contains(@class,'order-reference')]//*/div/small[2]")
	private WebElementFacade reportAsOfdateEle;

	@FindBy(xpath = "//report-header-action-buttons//li[@ng-if='headerData.isPurchased && headerData.isStaticReport && !headerData.isLive']/button/span[contains(text(),'Get Latest Report')]")
	private WebElementFacade getLatestReportButtonName;
	
	@FindBy(xpath = "//*[@id='top-nav-search-container']/basic-search-view/form[@role='search']//a[contains(@aria-label,'Select box')]")
	private WebElementFacade quickSearchDropDown;
	// methodsm 
	/***********************************************************************************
	 * Function: Select the country value Input : Country value Action : Click
	 * country button & select given country Output : Country should be selected
	 *
	 * @return
	 ***********************************************************************************/
	public void selectCountry(String country) {
		List<String> webelements = new ArrayList<String>();
		if (drpdwnCountry.isPresent()) {

			drpdwnCountry.click();
			drpdwnCountry.waitUntilVisible();
			if (drpdwnCountry.isDisplayed()) {
				for(WebElement e : drpdwnCountryValues)
				{
					webelements.add(e.getText());
				}
			}
				
			if(webelements.contains(country))
			{
				for (WebElement option : drpdwnCountryValues) {
					UIHelper.highlightElement(getDriver(), option);
					if (option.getText().equalsIgnoreCase(country)) {
						option.click();
						break;
					}
				}
			} else if(!webelements.contains(country))
			{
				UIHelper.highlightElement(getDriver(), searchTextBoxCountry);
				searchTextBoxCountry.waitUntilPresent();
				if(searchTextBoxCountry.isPresent()){
					searchTextBoxCountry.sendKeys(country);
					searchTextBoxCountry.sendKeys(Keys.ENTER);
				}
				
			}
				
				// txtBoxCountry.type(country);
				/*for (WebElement option : drpdwnCountryValues) {
					UIHelper.highlightElement(getDriver(), option);
					System.out.println("Options iterating from dropdown  : "+option.getText());
					if (option.getText().equalsIgnoreCase(country)) {
						System.out.println("I am inside to click the country name : " +option.getText());
						option.click();
						break;
					}
				}*/
			
		}

		// return drpdwnCountry.getText();
	}

	public String getDefaultCountry()
	{
		String defaultCountryVal=null;
		try
		{
			if (drpdwnCountry.isPresent())
			{
				defaultCountryVal=drpdwnCountry.getText();
			}
		}catch(NullPointerException n)
		{
			defaultCountryVal=null;
		}
		return defaultCountryVal;
	}

	/***********************************************************************************
	 * Function : Search for a company or DUNS by typing value in text box Input
	 * : Company name/DUNS Action : Enter search value & click search icon
	 * Output : Search result
	 ***********************************************************************************/
	public void basicSearch(String searchVal) throws Exception {

		// txtSearchXpath.waitUntilVisible();
		if (txtSearch.isPresent()) {

			UIHelper.highlightElement(getDriver(), txtSearch);
			if (iconSearch.isPresent()) {

				UIHelper.highlightElement(getDriver(), iconSearch);

				txtSearch.type(searchVal);
				iconSearch.waitUntilClickable();
				iconSearch.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						iconLoading);
			}
		}
	}

	/***********************************************************************************
	 * Function : Search for a company with Registration number by typing value in text box Input
	 * :
	 * Output : Search result
	 ***********************************************************************************/
	public void regNoSearch(String registrationNo) throws Exception {

		// txtSearchXpath.waitUntilVisible();
		if (txtSearch.isPresent()) {

			UIHelper.highlightElement(getDriver(), txtSearch);
			if (iconSearch.isPresent()) {

				UIHelper.highlightElement(getDriver(), iconSearch);

				txtSearch.type(registrationNo);
				iconSearch.waitUntilClickable();
				iconSearch.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						iconLoading);
			}
		}
	}
	/***********************************************************************************
	 * Function : Search for a company with Telephone number by typing value in text box Input
	 * :
	 * Output : Search result
	 ***********************************************************************************/
	public void telNoSearch(String telephoneNo) throws Exception {

		// txtSearchXpath.waitUntilVisible();
		if (txtSearch.isPresent()) {

			UIHelper.highlightElement(getDriver(), txtSearch);
			if (iconSearch.isPresent()) {

				UIHelper.highlightElement(getDriver(), iconSearch);

				txtSearch.type(telephoneNo);
				iconSearch.waitUntilClickable();
				iconSearch.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						iconLoading);
			}
		}
	}

	/***********************************************************************************
	 * Function : Verify search result is displayed Input : NA Action : Verify
	 * element displayed Output : Return true if search result is displayed
	 ***********************************************************************************/
	public boolean verifySearchResultIsDisplayed() {
		if (!noResult.isPresent()) {
			return true;
		} else {
			return false;
		}
	}

	/*************************************************************************************************************************************
	 * Function: Verify whether company search result is relevant to company
	 * name searched Input : Company Name Action : Verify company name in all
	 * rows of search result Output : Search result with purchase report button
	 **************************************************************************************************************************************/
	public boolean isCompanySearchResultRelevant(String searchValue)
			throws Exception {
		isMatchSearchResult = false;
		((JavascriptExecutor) getDriver()).executeScript("scroll(0, -250);");
		for (int count = 0; count < lstSearchRows.size(); count++) {
			UIHelper.mouseOveranElement(getDriver(),
					lstSearchedCompanyNames.get(count));
			
			UIHelper.highlightElement(getDriver(),
					lstSearchedCompanyNames.get(count));
			
			searchedRowValue = lstSearchedCompanyNames.get(count).getText();
			if (searchedRowValue.equalsIgnoreCase(searchValue)
					|| searchedRowValue.toLowerCase().contains(
							searchValue.toLowerCase())) {
				System.out.println("Inside if condition for searchedRowValue " +searchedRowValue);
				isMatchSearchResult = true;
			} else {
				isMatchSearchResult = false;
				break;
			}
		}
		return isMatchSearchResult;
	}

	// added for DBCREDIT2208
	
	public String verifySearchResultMatchesCompanyName(String compName) {
		
		int size = noOfRowsDisplayedinPreviewPage.size();
		String returnCompName = null;
		String companyName = null;
		for(int i = 0; i<size ;i++) {
		companyName = companyNamesfromEachRow.get(i).getText();
		
		if(companyName.equalsIgnoreCase(compName) || companyName.contains(compName))
		{
			UIHelper.highlightElement(getDriver(), companyNamesfromEachRow.get(i));
			returnCompName = companyName;
			System.out.println("Company taken from Preview page is : **** "+returnCompName);
			break;
		}
			
		}
		
		return returnCompName;
		
	}
	
	// added for DBCREDIT 2208
	
	public void getReportForCompanyNameAndDuns(String compnamefromStory , String dunsnofromStory)
	{
		String compName = null;
		String dunsNo = null;
		for(int i = 0; i<noOfRowsDisplayedinPreviewPage.size(); i++)
		{
			compName = companyNamesfromEachRow.get(i).getText();
			dunsNo = valSearchedDUNS.get(i).getText().replace("-", "");
		
			if(compName.equalsIgnoreCase(compnamefromStory) && dunsnofromStory.equalsIgnoreCase(dunsNo))
			{
				UIHelper.highlightElement(getDriver(), companyNamesfromEachRow.get(i));
				UIHelper.highlightElement(getDriver(), valSearchedDUNS.get(i));
				
				if(getReportBtn.isPresent())
				{
					UIHelper.highlightElement(getDriver(), getReportBtn);
					getReportBtn.click();
				}
				
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
						iconReportLoading);
				companyName.waitUntilVisible();
				UIHelper.highlightElement(getDriver(), companyName);
			}
		}
	}
	
	
	/*************************************************************************************************************************************
	 * Function: Verify whether company search result is relevant to company
	 * name searched for with purchase report button for new companies Input :
	 * Company Name Action : Verify purchase report button in 1st row of search
	 * result Output : Search result with purchase report button
	 *
	 * @return
	 **************************************************************************************************************************************/
	public boolean isPurchaseReportBtnDisplayed(String searchValue)
			throws Exception {
		boolean attributeOfPurchase = getDriver()
				.findElement(
						By.xpath("//*/search-info-row//*/div[@ng-show='!company.purchased']"))
				.getAttribute("aria-hidden").contains("true");

		WebElementFacade btnPurchase = findBy("//*/div[@class='col-md-12 dnb-search-item']/div[1]/search-info-row//*//div[@ng-show='!company.purchased']");
		if (attributeOfPurchase && btnPurchase.isPresent()) {
			UIHelper.highlightElement(getDriver(), btnPurchase);
			return true;
		} else {
			return false;
		}
	}

	/*************************************************************************************************************************************
	 * Function: Input : Action : Output :
	 *
	 * @return
	 **************************************************************************************************************************************/
	public String getMsgForInvestigationInSearchPg() {
		if (msgCantFindBusiness.isPresent())
			return msgCantFindBusiness.getText();
		else
			return null;
	}

	/*************************************************************************************************************************************
	 * Function: Verify whether company search result is relevant to company
	 * name searched for with no view report button for purchased companies
	 * Input : Company Name Action : Verify view report button in 1st row of
	 * search result Output : Search result without view report button
	 *
	 * @return
	 **************************************************************************************************************************************/
	public boolean isViewReportBtnHidden(String searchValue) throws Exception {
		boolean attributeOfPurchase = getDriver()
				.findElement(
						By.xpath("//*/search-info-row//*/div[@ng-show='!company.purchased']"))
				.getAttribute("aria-hidden").contains("true");
		String attributeOfPurchaseValue = getDriver()
				.findElement(
						By.xpath("//*/search-info-row//*/div[@ng-show='!company.purchased']"))
				.getAttribute("aria-hidden");
		WebElementFacade btnPurchase = findBy("//*/div[@class='col-md-12 dnb-search-item']/div[1]/search-info-row//*//div[@ng-show='!company.purchased']");
		boolean viewBtn = verifyViewReportBtn();
		if (!attributeOfPurchase && !btnPurchase.isPresent() && viewBtn) {
			return true;
		} else {
			return false;
		}
	}

	/****************************************************************************************************************
	 * Function: Verify whether company search result is relevant to duns
	 * searched for with purchase report button Input : Duns Number Action :
	 * Verify duns number in all rows of search result is with purchase report
	 * button Output : Search result with purchase report button
	 *****************************************************************************************************************/
	public void isDunsSearchResultRelevant(String searchValue) throws Exception {
		isMatchSearchResult = false;
		((JavascriptExecutor) getDriver()).executeScript("scroll(0, -250);");
		for (int count = 0; count < lstSearchRows.size(); count++) {
			searchedDUNSValue = "";
			UIHelper.mouseOveranElement(getDriver(), valSearchedDUNS.get(count));
			UIHelper.highlightElement(getDriver(), valSearchedDUNS.get(count));
			searchedDUNS = valSearchedDUNS.get(count).getText();
			String[] dunsVal = searchedDUNS.split("-");
			if (dunsVal.length > 0) {
				for (int index = 0; index < dunsVal.length; index++) {
					searchedDUNSValue = searchedDUNSValue + dunsVal[index];
				}
				if (searchedDUNSValue.contains(searchValue)) {
					isMatchSearchResult = true;
				} else {
					isMatchSearchResult = false;
					break;
				}
			}
		}
	}

	/****************************************************************************************************************
	 * Function: Verify whether company search result is relevant to duns
	 * searched for with purchase report button Input : Duns Number Action :
	 * Verify duns number in all rows of search result is with purchase report
	 * button Output : Search result with purchase report button
	 *****************************************************************************************************************/
	public String getDuns(String searchValue) throws Exception {

		isMatchSearchResult = false;
		((JavascriptExecutor) getDriver()).executeScript("scroll(0, -250);");
		searchedDUNSValue = "";
		UIHelper.mouseOveranElement(getDriver(), valDUNS);
		UIHelper.highlightElement(getDriver(), valDUNS);
		searchedDUNS = valDUNS.getText().replace("-", "");
		return searchedDUNSValue;
	}
	/****************************************************************************************************************
	 * Function: Verify whether company search result is relevant to Reg NO
	 * searched for with purchase report button Input : Reg no Number Action :
	 * Verify Reg number in all rows of search result is with purchase report
	 * button Output : Search result with purchase report button
	 *****************************************************************************************************************/
	public String getRegNo() throws Exception {

//		isMatchSearchResult = false;
//		((JavascriptExecutor) getDriver()).executeScript("scroll(0, -250);");
//		searchedDUNSValue = "";
		UIHelper.mouseOveranElement(getDriver(), valRegNo);
		UIHelper.highlightElement(getDriver(), valRegNo);
		String regNoUI = valRegNo.getText().trim();
		return regNoUI;
	}
	/****************************************************************************************************************
	 * Function: Verify whether company search result is relevant to Telephone NO
	 * searched for with purchase report button Input : Reg no Number Action :
	 * Verify Reg number in all rows of search result is with purchase report
	 * button Output : Search result with purchase report button
	 *****************************************************************************************************************/
	public String getTelNo() throws Exception {

//		isMatchSearchResult = false;
//		((JavascriptExecutor) getDriver()).executeScript("scroll(0, -250);");
//		searchedDUNSValue = "";
		UIHelper.mouseOveranElement(getDriver(), valTelNo);
		UIHelper.highlightElement(getDriver(), valTelNo);
		String telNoUI = valTelNo.getText().trim();
		return telNoUI;
	}

	/***********************************************************************************
	 * Function: Verify presence of View Report button Input : NA Action :
	 * Verify presence of element Output : NA
	 ***********************************************************************************/
	public boolean verifyViewReportBtn() {
		if (!btnViewReport.isPresent()) {
			return true;
		} else {
			return false;
		}
	}

	/***********************************************************************************
	 * Function: Paste company name in search text box Input : Company name
	 * Action : Paste company name Output : Value should be pasted in search
	 * text box
	 ***********************************************************************************/
	public void pasteCompanyValueInSearchBox(String companyName) {
		txtSearch.clear();
		objCommonMethods.pasteText(txtSearch, companyName);
	}

	/***********************************************************************************
	 * Function: Paste DUNS in search text box Input : DUNS Action : Paste DUNS
	 * Output : Value should be pasted in search text box
	 ***********************************************************************************/
	public void pasteDunsValueInSearchBox(String dunsNumber) {
		txtSearch.clear();
		objCommonMethods.pasteText(txtSearch, dunsNumber);
	}

	/***********************************************************************************
	 * Function: Paste company name/DUNS in search text box Input : Company
	 * name/DUNS Action : Paste company name/DUNS Output : Value should be
	 * pasted in search text box
	 ***********************************************************************************/
	public void clickSearchIcon() {
		iconSearch.waitUntilClickable();
		iconSearch.click();
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), iconLoading);
	}

	/***********************************************************************************
	 * Function: Retrieve value pasted in search text box Input : NA Action :
	 * get Output : Value pasted in search text box
	 ***********************************************************************************/
	public String getValueInSearchBox() {
		return txtSearch.getAttribute("value");
	}

	/***********************************************************************************
	 * Function: Click purchase report button in search result Input : NA Action
	 * : Click purchase report button of 1st company Output : Summary report of
	 * the company/Duns should be displayed
	 *
	 * @return
	 ***********************************************************************************/
	public boolean clickPurchaseReportBtn() {
		// boolean
		// attributeOfPurchase=getDriver().findElement(By.xpath("//*/search-info-row//*/div[@ng-show='!company.purchased']")).
		// getAttribute("class").equalsIgnoreCase("indicator-purchase");

		boolean attributeOfPurchase = getDriver()
				.findElement(
						By.xpath("//*/search-info-row//*/div[@ng-show='!company.purchased']"))
				.getAttribute("aria-hidden").contains("true");
		WebElementFacade btnPurchase = findBy("//*/div[@class='col-md-12 dnb-search-item']/div[1]/search-info-row//*/div[@ng-show='!company.purchased']/button");
		if (btnPurchase.isPresent() && attributeOfPurchase) {
			UIHelper.highlightElement(getDriver(), btnPurchase);
			btnPurchase.click();
			popUp.waitUntilVisible();
			return true;
		} else {
			return false;
		}
	}

	/***********************************************************************************
	 * Function: Verify whether a pop up is displayed on clicking purchase
	 * report button Input : NA Action : Close pop up if displayed and verify
	 * whether report page is displayed Output : NA
	 *
	 * @throws Exception
	 ***********************************************************************************/
	public boolean closePopUp(String duns) throws Exception {
		// if(popUpMsgErr.isPresent())
		// {
		// closeErrPopUp.click();
		// }
		// else if(popUpMsg.isPresent())
		// {
		// closePopUp.click();
		// }
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
				iconReportLoading);
		// UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
		// iconLoadingAge);

		if (companyName.isPresent()
				&& dunsNoInReportHeader.getText().replaceAll("-", "")
						.equals(duns)) {

			return true;
		}
		/*
		 * else if(!dunsValInHeader.equals(duns)) { selectCountry(country);
		 * searchByDuns(duns); getDuns(duns); clickCompanyNameLink(); }
		 */else {

			return false;
		}
	}

	/***********************************************************************************
	 * Function: Verify whether company profile panel is displayed on clicking
	 * purchase report button Input : NA Action : NA Output : NA
	 ***********************************************************************************/
	public boolean isDisplayedCompanyProfilePanel() {
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
				iconReportLoading);
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
				iconLoadingAge);
		companyName.waitUntilPresent();
		compProfileHeading.waitUntilPresent();
		if (compProfileHeading.isPresent()) {
			return true;
		} else {
			return false;
		}
	}

	/***********************************************************************************
	 * Function: Click company name in search result Input : NA Action : Click
	 * 1st company name link in search result Output : Summary report of the
	 * record should be displayed
	 ***********************************************************************************/
	public boolean clickCompanyNameLink() {
		((JavascriptExecutor) getDriver()).executeScript("scroll(0, -250);");
		if (lnk1stComp.isPresent()) {
			clickedCompanyName = lnk1stComp.getText();
			lnk1stComp.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
					iconReportLoading);
			companyName.waitUntilVisible();
			UIHelper.highlightElement(getDriver(), companyName);
			companyNameInReportPg = companyName.getText();
		}
		if (clickedCompanyName.equalsIgnoreCase(companyNameInReportPg)) {
			return true;
		} else {
			return false;
		}
	}

	/***********************************************************************************
	 * Function: Click company name in search result Input : NA Action : Click
	 ***********************************************************************************/
	public void clickCompanyNameLinkInSearch() {

		lnk1stComp.isPresent();
		lnk1stComp.click();
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
				iconReportLoading);

	}

	/***********************************************************************************
	 * Function: Click Get Report in search result Input : NA Action : Click Get
	 * Report from 1st company name link in search result Output : Summary
	 * report of the record should be displayed
	 ***********************************************************************************/
	public void clickGetReportBtn() {
		if (lnk1stComp.isPresent()) {
			getReportBtn.isPresent();
			UIHelper.highlightElement(getDriver(), getReportBtn);
			getReportBtn.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
					iconReportLoading);
			companyName.waitUntilVisible();

		}
	}

	/***********************************************************************************
	 * Function: Retrieve Order investigation Link text Input : NA Action :
	 * getText of link Output : True if available
	 ***********************************************************************************/
	public String getOrderInvestigationLinkName() {
		((JavascriptExecutor) getDriver()).executeScript("scroll(0, -250);");
		if (lnkOrderInvestigationInHeader.isPresent()) {
			UIHelper.highlightElement(getDriver(),
					lnkOrderInvestigationInHeader);
			return lnkOrderInvestigationInHeader.getText();
		} else {
			return null;
		}
	}

	/***********************************************************************************
	 * Function: Verify the presence of Order investigation Link Input : NA
	 * Action : Verify element availability Output : True if available
	 ***********************************************************************************/
	public String isOrderInvestigationLink() {
		lnkOrderInvestigationInHeader.waitUntilPresent();
		if (lnkOrderInvestigationInHeader.isPresent()) {
			UIHelper.highlightElement(getDriver(),
					lnkOrderInvestigationInHeader);
			return lnkOrderInvestigationInHeader.getText();
		} else {
			return null;
		}
	}

	/***********************************************************************************
	 * Function: Click Order investigation Link Input : NA Action : Click Order
	 * investigation link Output : True if available
	 ***********************************************************************************/
	public void clickOrderInvestigationLink() {
		lnkOrderInvestigationInHeader.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), lnkOrderInvestigationInHeader);
		lnkOrderInvestigationInHeader.click();
		UIHelper.waitForPageToLoad(getDriver());
		titleInvestigateABusiness.waitUntilPresent();
	}

	/***********************************************************************************
	 * Function: Click Order investigation Link Input : NA Action : Click Output
	 * : Investigation page should be displayed
	 ***********************************************************************************/
	public void clickOrderInvestigationLinkNew() {
		((JavascriptExecutor) getDriver()).executeScript("scroll(0, -250);");
		UIHelper.mouseOveranElement(getDriver(), lnkOrderInvestigationInHeader);
		UIHelper.highlightElement(getDriver(), lnkOrderInvestigationInHeader);
		lnkOrderInvestigationInHeader.click();
		UIHelper.waitForPageToLoad(getDriver());
		titleInvestigateABusiness.waitUntilVisible();
	}

	/***********************************************************************************
	 * Function: Check Report as of date is todays' date Input : NA Action : get
	 * Report Date Output : Return value if its true
	 ***********************************************************************************/
	public String verifyReportAsofDate() {
		try {

			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			// Date date = new Date();
			// Calendar calendar =
			// Calendar.getInstance(TimeZone.getTimeZone("UTC-05:00"));
			// // Date currentDate = calendar.getTime();
			// System.out.println("currentTimezone: "+calendar);

			DateTimeZone timeZone = DateTimeZone
					.forID("bogota, lima, quito, rio branco");
			DateTime now = DateTime.now(timeZone.UTC);
			System.out.println("Test: " + now);
			String currentDate = dateFormat.format(now);
			System.out.println("Current date: " + currentDate);
			UIHelper.highlightElement(getDriver(), reportAsOfdate);
			String dateFromUi = reportAsOfdate.getText().replace(
					"Report as of: ", "");
			System.out.println("Report date: " + dateFromUi);
			if (dateFromUi.contains(currentDate)) {

				resultantValue = "Report As of Date is same as Current date";

			} else {
				resultantValue = "Report As of Date is not same as Current date --"
						+ reportAsOfdate.getText().toString().trim();
			}
		} catch (Exception E) {
			throw E;
		}

		return resultantValue;
	}

	/***********************************************************************************
	 * Function: Check Trade up message has been displayed Input : NA Action :
	 * get Report Date Output : Return value if its true
	 ***********************************************************************************/
	public void getCompanyNameFromSearchResult() {

		try {
			if (resultCompanyName.isDisplayed()
					&& resultCompanyName.isEnabled()) {
				UIHelper.highlightElement(getDriver(), resultCompanyName);
				getCompanyValues = resultCompanyName.getText().toString()
						.trim();
			}
		} catch (Exception E) {
			throw E;
		}

	}

	/***********************************************************************************
	 * Function: Check Trade up message has been displayed Input : NA Action :
	 * get Report Date Output : Return value if its true
	 ***********************************************************************************/
	public String verifyTradeUpMsg() {

		try {

			tradeheaderMsg = tradeUpMsgStart + getCompanyValues + tradeUpMsgEnd;
			UIHelper.highlightElement(getDriver(), noticeContentMsg);

			if (noticeContentMsg.getText().toString().trim().toLowerCase()
					.contains(tradeUpMsgStart.toLowerCase())) {
				resultantValue = "Exepected Text message has been displayed in Report header";
			} else {

				resultantValue = "Expected Result : " + tradeheaderMsg
						+ "Actual Result : "
						+ noticeContentMsg.getText().toString().trim();
			}
		} catch (Exception E) {
			throw E;
		}

		return resultantValue;
	}

	/***********************************************************************************
	 * Function: Check Trade up message has not been displayed for HQ and Sub
	 * Input : NA Action : get message displayed or not Output : Return value if
	 * its true
	 ***********************************************************************************/
	public String verifyHQAndSubisdiriesTradeUpMsg() {

		try {

			tradeheaderMsg = tradeUpMsgStart + getCompanyValues + tradeUpMsgEnd;
			UIHelper.highlightElement(getDriver(), noticeContentMsg);

			if (noticeContentMsg.getText().toString().trim()
					.equalsIgnoreCase(tradeheaderMsg)) {
				resultantValue = "Exepected Text message is not displayed in Report header";
			} else {

				resultantValue = "Exepected Text message is displayed in Report header";
			}
		} catch (Exception E) {
			throw E;
		}

		return resultantValue;
	}

	/***********************************************************************************
	 * Function: Verify Get Report Button for Live Market Input : Duns No Action
	 * : Output : Get Report
	 ***********************************************************************************/
	public String verifyGetReportForLiveRep() throws Exception {

		String getReportUI = null;
		try {
			getReportBtn.isPresent();
			UIHelper.highlightElement(getDriver(), getReportBtn);
			getReportUI = getReportBtn.getText().toString().trim();
		} catch (Exception e) {
			e.printStackTrace();
			;
		}
		return getReportUI;
	}

	/***********************************************************************************
	 * Function: Verify View latest Report Button for Live Market Input : Duns
	 * No Action : Output : Latest Report
	 ***********************************************************************************/
	public String verifyLatestRepButton() throws Exception {

		String latestReportUI = null;
		try {
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
					iconReportLoading);
			UIHelper.highlightElement(getDriver(), latestReportContainer);
			latestReportBtn.isPresent();
			UIHelper.highlightElement(getDriver(), latestReportBtn);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return latestReportUI;
	}

	/***********************************************************************************
	 * Function: Check Trade up message has been displayed for Normal DUNS Input
	 * : NA Action : get message displayed or not Output : Return value if its
	 * true
	 ***********************************************************************************/
	public String verifynormalDUNSMsg() {

		try {
			UIHelper.highlightElement(getDriver(), resultCompanyName);
			resultCompanyName.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
					iconReportLoading);

			if (normalDunsMsg.equalsIgnoreCase(noticeContentMsgDiv.getText()
					.toString().trim())) {
				resultantValue = "Exepected Text message is displayed in Report header";
			} else {
				resultantValue = "Exepected Result : " + normalDunsMsg + "  "
						+ "Actual Result :"
						+ noticeContentMsgDiv.getText().toString().trim();

			}
		} catch (Exception E) {
			throw E;
		}

		return resultantValue;
	}

	/***********************************************************************************
	 * Function: Check Trade up message has been displayed for Out of Business
	 * DUNS Input : NA Action : get message displayed or not Output : Return
	 * value if its true
	 ***********************************************************************************/
	public String verifyOOBDUNSMsg() {

		try {

			if (outofBusniessDunsMsg.equalsIgnoreCase(noticeContentMsgDiv
					.getText().toString().trim())) {
				resultantValue = "Exepected Text message is displayed in Report header";
			} else {

				resultantValue = "Exepected Result : " + outofBusniessDunsMsg
						+ "  " + "Actual Result :"
						+ noticeContentMsgDiv.getText().toString().trim();
			}
		} catch (Exception E) {
			throw E;
		}

		return resultantValue;
	}

	/***********************************************************************************
	 * Function: Check Trade up message has been displayed for Normal DUNS Input
	 * : NA Action : get message displayed or not Output : Return value if its
	 * true
	 ***********************************************************************************/
	public String verifyStopDistrubutionDUNSMsg() {

		try {

			if (stopDistributionDunsMsg.equalsIgnoreCase(noticeContentMsgDiv
					.getText().toString().trim())) {
				UIHelper.highlightElement(getDriver(), noticeContentMsgDiv);
				resultantValue = "Exepected Text message is displayed in Report header";
			} else {

				resultantValue = "Exepected Result : "
						+ stopDistributionDunsMsg + "  " + "Actual Result :"
						+ noticeContentMsgDiv.getText().toString().trim();
			}
		} catch (Exception E) {
			throw E;
		}

		return resultantValue;
	}

	/***********************************************************************************
	 * Function: Check Trade up message has been displayed for Normal DUNS Input
	 * : NA Action : get message displayed or not Output : Return value if its
	 * true
	 ***********************************************************************************/
	public String verifyLeftNavigationDisabled() {

		try {
			UIHelper.highlightElement(getDriver(), resultCompanyName);
			resultCompanyName.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
					iconReportLoading);

			for (int i = 0; i < leftHandMenuItems.size(); i++) {

				if (leftHandMenuItems.get(i).getAttribute("class").toString()
						.trim().contains("disabled")
						&& !leftHandMenuItems.get(i).toString().trim()
								.contains("Summary")
						&& !leftHandMenuItems.get(i).toString().trim()
								.contains("Attachments")
						&& !leftHandMenuItems.get(i).toString().trim()
								.contains("Audit")) {
					UIHelper.highlightElement(getDriver(),
							leftHandMenuItems.get(i));
					resultantValue = "Exepected Text message is displayed in Report header";
				} else {
					resultantValue = leftHandMenuItems.get(i)
							+ "is enabled in the left hand navigation side";
					break;

				}
			}

		} catch (Exception E) {
			throw E;
		}

		return resultantValue;
	}

	/***********************************************************************************
	 * Function: Get the elements name in key data panel Input : NA Action :
	 * getText() Output : return the array list of elements
	 *
	 * @return
	 ***********************************************************************************/
	public String getElementsOfKeydataPanel() {

		UIHelper.highlightElement(getDriver(), resultCompanyName);
		resultCompanyName.click();
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
				iconReportLoading);
		if (annualSalesElement.isDisplayed()) {
			annualSales = "Annual Sales Element is Displayed";
			UIHelper.highlightElement(getDriver(), annualSalesElement);
		} else {
			annualSales = "Annual Sales Element is not Displayed";
		}
		if (lineOfBusinessElement.isDisplayed()) {

			UIHelper.highlightElement(getDriver(), lineOfBusinessElement);
			lineOfbusiness = "Line of Business Element is Displayed";
		} else {

			lineOfbusiness = "Line of Business Element is not Displayed";
		}
		if (ownershipElement.isDisplayed()) {

			UIHelper.highlightElement(getDriver(), ownershipElement);
			ownerShip = "OwnerShip Element is Displayed";
		} else {

			ownerShip = "OwnerShip Element is not Displayed";
		}
		if (employeesElement.isDisplayed()) {

			UIHelper.highlightElement(getDriver(), employeesElement);
			employees = "Employees element is displayed";
		} else {

			employees = "Employees element is not displayed";
		}

		resultantValue = annualSales + "," + lineOfbusiness + "," + ownerShip
				+ "," + employees;

		return resultantValue;
	}

	/***********************************************************************************
	 * Function: Get the elements name in key data panel Input : NA Action :
	 * getText() Output : return the array list of elements
	 *
	 * @return
	 ***********************************************************************************/
	public String getElementsOfKeydataPanelForSDDuns() {

		UIHelper.highlightElement(getDriver(), resultCompanyName);
		resultCompanyName.click();
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
				iconReportLoading);
		if (failureScoreElement.isDisplayed()) {
			annualSales = "Failure Score Element is Displayed";
			UIHelper.highlightElement(getDriver(), failureScoreElement);
		} else {
			annualSales = "Failure Score Element is not Displayed";
		}
		if (delinquencyScoreElement.isDisplayed()) {

			UIHelper.highlightElement(getDriver(), delinquencyScoreElement);
			lineOfbusiness = "Delinquency Score Element is Displayed";
		} else {

			lineOfbusiness = "Delinquency Score Element is not Displayed";
		}
		if (ageOfBusinessElement.isDisplayed()) {

			UIHelper.highlightElement(getDriver(), ageOfBusinessElement);
			ownerShip = "Age of Business Element is Displayed";
		} else {

			ownerShip = "Age of Business Element is not Displayed";
		}
		if (employeesElement.isDisplayed()) {

			UIHelper.highlightElement(getDriver(), employeesElement);
			employees = "Employees element is displayed";
		} else {

			employees = "Employees element is not displayed";
		}

		resultantValue = annualSales + "," + lineOfbusiness + "," + ownerShip
				+ "," + employees;

		return resultantValue;
	}

	/***********************************************************************************
	 * Function: Check Trade up message has been displayed for Normal DUNS Input
	 * : NA Action : get message displayed or not Output : Return value if its
	 * true
	 ***********************************************************************************/
	public String verifyGooglemapisDisplayed() {

		try {
			UIHelper.highlightElement(getDriver(), resultCompanyName);
			resultCompanyName.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
					iconReportLoading);
			if (googleMap.isDisplayed()) {
				UIHelper.highlightElement(getDriver(), googleMap);
				resultantValue = "Google Map is displayed in key Data Element Panel";
			} else {
				resultantValue = "Google Map is not displayed in key Data Element Panel";
			}

		} catch (Exception E) {
			throw E;
		}

		return resultantValue;
	}

	/***********************************************************************************
	 * Function: Verify Portfolio tool tip message in summary Input : Action :
	 * Output :
	 ***********************************************************************************/
	public String verifyPortfolioToolTipMsg() throws Exception {

		String portfolioMsgUI = null;
		try {
			// UIHelper.highlightElement(getDriver(), portfolioReportHeader);
			// UIHelper.highlightElement(getDriver(), portfolioTag);
			// portfolioTag.click();
			UIHelper.mouseOverandclickanElement(getDriver(), portfolioTag);
			UIHelper.waitForVisibilityOfEleByXpath(
					getDriver(),
					"//*//div[contains(@class,'popover-inner')]//div[contains(@class,'popover-content')]/div");
			UIHelper.highlightElement(getDriver(), portfolioToolTip);
			portfolioMsgUI = portfolioToolTip.getText().toString().trim();
			System.out.println("portfoliomsgb4: " + portfolioMsgUI);
			if (!portfolioMsgUI
					.equalsIgnoreCase("Track This Company to add to your portfolio")) {
				trackThisCompanyBtn.click();
				stopTrackModal.waitUntilPresent();
				UIHelper.highlightElement(getDriver(), stopTrackModal);
				continueBtnInModal.click();
				UIHelper.waitForVisibilityOfEleByXpath(
						getDriver(),
						"//*/div[contains(@class,'panel-body')]//*/div/ul/li/button[contains(.,'Track this Company')]");
				UIHelper.mouseOverandclickanElement(getDriver(), portfolioTag);
				UIHelper.waitForVisibilityOfEleByXpath(
						getDriver(),
						"//*//div[contains(@class,'popover-inner')]//div[contains(@class,'popover-content')]/div");
				UIHelper.highlightElement(getDriver(), portfolioToolTip);
				portfolioMsgUI = portfolioToolTip.getText().toString().trim();
			} else {
				// Actions builder1 = new Actions(getDriver());
				// builder1.moveToElement(portfolioTag).build().perform();
				// portfolioToolTip.waitUntilPresent();
				// UIHelper.highlightElement(getDriver(), portfolioToolTip);
				portfolioMsgUI = portfolioToolTip.getText().toString().trim();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return portfolioMsgUI;
	}

	/***********************************************************************************
	 * Function: Verify Portfolio tool tip message in summary Input : Action :
	 * Output :
	 ***********************************************************************************/
	public String verifyTagToolTipMessage() throws Exception {

		String tagMsgUI = null;
		try {

			// Actions builder = new Actions(getDriver());
			// builder.moveToElement(TagIcon).click().build().perform();
			// TagIcon.click();
			UIHelper.mouseOverandclickanElement(getDriver(), TagIcon);
			UIHelper.waitForVisibilityOfEleByXpath(
					getDriver(),
					"//*//div[contains(@class,'popover-inner')]//div[contains(@class,'popover-content')]/div");
			UIHelper.highlightElement(getDriver(), tagToolTip);
			tagMsgUI = tagToolTip.getText().toString().trim();
			System.out.println("Tagmsgb4: " + tagMsgUI);
			// if (!tagMsgUI.equalsIgnoreCase("Track This Company to add tags"))
			// {
			// trackThisCompanyBtn.click();
			// stopTrackModal.waitUntilPresent();
			// UIHelper.highlightElement(getDriver(), stopTrackModal);
			// continueBtnInModal.click();
			// UIHelper.waitForVisibilityOfEleByXpath(
			// getDriver(),
			// "//*/div[contains(@class,'panel-body')]//*/div/ul/li/button[contains(.,'Track this Company')]");
			// UIHelper.highlightElement(getDriver(), trackThisCompanyBtnSpl);
			// trackThisCompanyBtnSpl.click();
			// UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
			// "//*//li[2]/span[contains(@class,'disabled')]");
			// // Actions builder1 = new Actions(getDriver());
			// // builder1.moveToElement(TagIcon).click().build().perform();
			// UIHelper.mouseOverandclickanElement(getDriver(), TagIcon);
			// UIHelper.waitForVisibilityOfEleByXpath(
			// getDriver(),
			// "//*//div[contains(@class,'popover-inner')]//div[contains(@class,'popover-content')]/div");
			// UIHelper.highlightElement(getDriver(), tagToolTip);
			// tagMsgUI = tagToolTip.getText().toString().trim();
			// } else {
			// tagMsgUI = tagToolTip.getText().toString().trim();
			// }
		} catch (Exception e) {
			e.printStackTrace();

		}
		return tagMsgUI;
	}

	/***********************************************************************************
	 * Function: Verify Alerts tool tip message in summary Input : Action :
	 * Output :
	 ***********************************************************************************/
	public String verifyAlertsToolTipMessage() throws Exception {

		String alertMsgUI = null;
		try {
			UIHelper.mouseOverandclickanElement(getDriver(), alertsIcon);
			UIHelper.waitForVisibilityOfEleByXpath(
					getDriver(),
					"//*//div[contains(@class,'popover-inner')]//div[contains(@class,'popover-content')]/div");
			UIHelper.highlightElement(getDriver(), alertsToolTip);
			alertMsgUI = alertsToolTip.getText().toString().trim();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return alertMsgUI;
	}

	/***********************************************************************************
	 * Function: Verify Alerts tool tip message in summary Input : Action :
	 * Output :
	 ***********************************************************************************/
	public String verifyPortfolioToolTipMSgAfter() throws Exception {

		String inPortfolioUI = null;
		try {
			portfolioTag.click();
			portfolioToolTip.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), portfolioToolTip);
			inPortfolioUI = portfolioToolTip.getText().toString().trim();
		} catch (Exception e) {
			e.printStackTrace();
			;
		}
		return inPortfolioUI;
	}

	/***********************************************************************************
	 * Function: Verify Business status is Active Input : Action : Output :
	 ***********************************************************************************/
	public String verifyBussStatus() throws Exception {

		String bussStatusUI = null;
		try {
			bussStatus.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), bussStatus);
			bussStatusUI = bussStatus.getText().toString().trim();
		} catch (Exception e) {
			e.printStackTrace();
			;
		}
		return bussStatusUI;
	}

	/***************************************************************************************
	 * Function: Click Export As PDF Button in PDF : Action : Output :
	 *
	 ****************************************************************************************/
	public void clickExportPdfButton() throws Exception {

		try {
			exportAsPdfBtn.isPresent();
			UIHelper.highlightElement(getDriver(), exportAsPdfBtn);
			exportAsPdfBtn.click();
			exportAsPDFDropDown.waitUntilPresent();
			exportAsPDFDropDown.click();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/***************************************************************************************
	 * Function:"Click Here" Button : Action : Output :
	 *
	 ****************************************************************************************/
	public void clickClicHereBtn() throws Exception {

		try {
			UIHelper.highlightElement(getDriver(), renderingPdfEle);
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
					renderingPdfEleStr);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), clickHereBtnStr);
			UIHelper.highlightElement(getDriver(), growlMsg);
			clickHereBtn.isPresent();
			UIHelper.highlightElement(getDriver(), clickHereBtn);
			clickHereBtn.click();
			UIHelper.waitForPageToLoad(getDriver());

			// String newWindow = null;
			// ArrayList<String> tabs2 = new ArrayList<String>(getDriver()
			// .getWindowHandles());
			// getDriver().switchTo().window(tabs2.get(1));
			//
			// newWindow = getDriver().getCurrentUrl();
			// System.out.println("newwindow1:" + newWindow);
			// // getDriver().manage().window().maximize();
			// Thread.sleep(5000);
			// UIHelper.highlightElement(getDriver(), toolBarInPdf);
			// downloadBtnInPdf.waitUntilClickable();
			// UIHelper.highlightElement(getDriver(), downloadBtnInPdf);
			// downloadBtnInPdf.click();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/***************************************************************************************
	 * Function:To delete existing file in the given location : Action : Output
	 * :
	 *
	 ****************************************************************************************/
	public void deleteAllFileFromPath(String location) {

		File file = new File(location);
		purgeDirectory(file);
	}

	public void purgeDirectory(File dir) {
		for (File file : dir.listFiles()) {
			if (file.isDirectory())
				purgeDirectory(file);
			if (file.exists()) {
				file.delete();
			}

		}

	}

	// public boolean openSavedFile(String location) throws Exception
	// {
	// Thread.sleep(90000);
	// final File folder = new File(location);
	//
	// String fileName = listFilesForFolder(folder);
	// boolean result = true;
	// List<String> exportedDuns = new ArrayList<String>();
	// String csvFile = location +"\\"+fileName;

	/***************************************************************************************
	 * Function:To get file name : Action : Output :
	 *
	 * @return
	 *
	 ****************************************************************************************/
	public String listFilesForFolder(final File folder) {
		String fileName = "";
		for (final File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				listFilesForFolder(fileEntry);
			} else {
				fileName = fileEntry.getName();
				System.out.println(fileEntry.getName());
			}
		}
		return fileName;
	}

	/***************************************************************************************
	 * Function:Validate Pdf content : Action : Output :
	 *
	 * @return
	 *
	 ****************************************************************************************/
	public String openSavedFile(String location) throws Exception {

		String newWindow = null;
		Thread.sleep(5000);
		// final File folder = new File(location);
		// String fileName = listFilesForFolder(folder);
		// System.out.println("folderPath "+fileName);
		// PdfReader reader = new PdfReader(
		// location +"\\"+fileName);
		// System.out.println("filefullPath "+reader);
		String winHandleBefore = getDriver().getWindowHandle();
		for (String winHandle : getDriver().getWindowHandles()) {
			getDriver().switchTo().window(winHandle);
		}
		newWindow = getDriver().getCurrentUrl();
		System.out.println("newwindow:" + newWindow);
		URL TestURL = new URL(newWindow);
		System.out.println("TestURL:" + TestURL);
		// UIHelper.highlightElement(getDriver(), toolBarInPdf);
		// UIHelper.highlightElement(getDriver(), pdfPageWindow);
		// UIHelper.highlightElement(getDriver(), downloadBtnInPdf);
		// URL website = new URL(newWindow);
		// ReadableByteChannel rbc = Channels.newChannel(website.openStream());
		// FileOutputStream fos = new FileOutputStream(".pdf");
		// fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
		// Actions builder = new Actions(getDriver());
		// builder.moveToElement(downloadBtnInPdf).click().build().perform();
		// UIHelper.highlightElement(getDriver(), downloadBtnInPdf);
		// downloadBtnInPdf.click();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String dtFormat = dateFormat.format(date);
		System.out.println(dateFormat.format(date));
		String Test = "C:\\Users\\QAAdmin\\Downloads";
//		PdfReader reader = new PdfReader(Test + dtFormat + ".pdf");
		PdfReader reader = new PdfReader(this.getClass().getResourceAsStream(Test+"air-*.pdf"));
		int noPage = reader.getNumberOfPages();
		System.out.println("Total Number of pages are:" + noPage);
		String pdfText = PdfTextExtractor.getTextFromPage(reader, 1);
		System.out.println(pdfText);
		return pdfText;

	}

	/***************************************************************************************
	 * Function:Validate Pdf content : Action : Output :
	 *
	 * @return
	 *
	 ****************************************************************************************/
	public List<String> readContectFromPDFDoc(String location) throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String dtFormat = dateFormat.format(date);
		System.out.println(dateFormat.format(date));
		String fileName = "air-canada_";
		List<String> pdfContent = new ArrayList<String>();
		PdfReader reader = new PdfReader(location.startsWith(fileName) + ".pdf");
		int pageCount = reader.getNumberOfPages();
		// System.out.println("Number of pages are:" +pageCount);
		for (int i = 1; i <= pageCount; i++) {
			pdfContent.add(PdfTextExtractor.getTextFromPage(reader, i));
			System.out.println("PDF Text content:" + pdfContent);
		}
		return pdfContent;
	}

	// String dnBLogoPDF = null;
	// String newWindow = null;
	//
	// File file = new File(
	// "C:/Desktop/ukrainian_farmers_co_operative_ltd_02_01_2016.pdf");
	// PDFTextStripper pdfStripper = null;
	// PDDocument pdDoc = null;
	// COSDocument cosDoc = null;
	//
	// try {
	// // String winHandleBefore = getDriver().getWindowHandle();
	// // for(String winHandle : getDriver().getWindowHandles()){
	// // getDriver().switchTo().window(winHandle);
	// // }
	// // newWindow=getDriver().getCurrentUrl();
	// // System.out.println("newwindow:"+newWindow);
	// // getDriver().manage().window().maximize();
	// // URL TestURL = new URL(newWindow);
	// // System.out.println("TestURL:"+TestURL);
	// // BufferedInputStream TestFile = new
	// // BufferedInputStream(TestURL.openStream());
	// // PDFParser TestPDF = new PDFParser((RandomAccessRead) TestFile);
	// // TestPDF.parse();
	// // dnBLogoPDF = new
	// // PDFTextStripper().getText(TestPDF.getPDDocument());
	// // System.out.println("pdfTotext:"+dnBLogoPDF);
	// //
	// // getDriver().close();
	// // // Switch back to original browser (first window)
	// // getDriver().switchTo().window(winHandleBefore);
	// // getDriver().switchTo().defaultContent();
	// // getDriver().findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL,
	// // Keys.PAGE_DOWN);
	// Thread.sleep(1000);
	// ArrayList<String> tabs2 = new ArrayList<String>(getDriver()
	// .getWindowHandles());
	// getDriver().switchTo().window(tabs2.get(1));
	//
	// newWindow = getDriver().getCurrentUrl();
	// System.out.println("newwindow1:" + newWindow);
	// getDriver().manage().window().maximize();
	// Thread.sleep(5000);
	// UIHelper.highlightElement(getDriver(), downloadBtnInPdf);
	// // downloadBtnInPdf.click();
	//
	// // Thread.sleep(5000);
	// URL url = new URL(getDriver().getCurrentUrl());
	// System.out.println("currentURL:" + url);
	//
	// PDFParser parser = new PDFParser(FileInputStream(file));
	// parser.parse();
	// cosDoc = parser.getDocument();
	// pdfStripper = new PDFTextStripper();
	// pdDoc = new PDDocument(cosDoc);
	// pdfStripper.setStartPage(1);
	// pdfStripper.setEndPage(5);
	// String parsedText = pdfStripper.getText(pdDoc);
	// System.out.println(parsedText);
	//
	// // RandomAccessRead fileToParse = (RandomAccessRead) new
	// // BufferedInputStream(url.openStream());
	// // PDFParser parser = new PDFParser(fileToParse);
	// // parser.parse();
	// //
	// // dnBLogoPDF = new
	// // PDFTextStripper().getText(parser.getPDDocument());
	// // System.out.println("pdfToText:"+dnBLogoPDF);
	// getDriver().close();
	// getDriver().switchTo().window(tabs2.get(0));
	//
	// // parser.getPDDocument().close();
	// //
	// // URL TestURL = new URL(
	// //
	// "https://dnbi-stg.malibucoding.com/services/pdf/download/c3e0e5d8-912b-4397-a95a-d072fb3f4845/ukrainian_farmers_co_operative_ltd_02_01_2016.pdf");
	// //
	// // BufferedInputStream TestFile = new BufferedInputStream(
	// // TestURL.openStream());
	// // PDFParser TestPDF = new PDFParser(TestFile);
	// // TestPDF.parse();
	// // String TestText = new PDFTextStripper().getText(TestPDF
	// // .getPDDocument());
	// // reader.setStartPage(i);
	// // reader.setEndPage(i);
	// // String pageText = reader.getText(doc);
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// return dnBLogoPDF;
	// }
	//
	// private RandomAccessRead FileInputStream(File file) {
	// // TODO Auto-generated method stub
	// return null;
	// }

	/***********************************************************************************
	 * Function: Login as child user Input : User name and password Action :
	 * Type and click Output : Welcome message with user name should be
	 * displayed
	 ***********************************************************************************/
	public void enterIntoChildLogin(String username, String password)
			throws Exception {
		try {
			txtUserName.type(username);
			txtPassword.type(password);
			btnSubmit.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/***********************************************************************************
	 * Function: Click Latest Report in search result Input : NA Action : Click
	 * Get Report from 1st company name link in search result Output : Summary
	 * report of the record should be displayed
	 ***********************************************************************************/
	public void clickonLatestReportBtn() {
		try {
			latestReportBtn.isPresent();
			UIHelper.highlightElement(getDriver(), latestReportBtn);
			latestReportBtn.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
					iconReportLoading);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/***************************************************************************************
	 * Function:Verify D&B Logo in PDF : Action : Output :
	 *
	 * @return
	 *
	 ****************************************************************************************/
	public String verifyLatestReportDat() {
		String latestRepDtUI = null;
		try {
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
					iconReportLoading);
			reportAsOfdateEle.isPresent();
			UIHelper.highlightElement(getDriver(), reportAsOfdateEle);
			String latestRepDtUI1[] = reportAsOfdateEle.getText().trim()
					.toString().split(":");
			latestRepDtUI = latestRepDtUI1[1].trim();
			System.out.println("ReportAsOfDateUI:" + latestRepDtUI);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return latestRepDtUI;
	}

	/***************************************************************************************
	 * Function:Validate Pdf content for US: Action : Output :
	 *
	 * @return
	 *
	 ****************************************************************************************/
	public List<String> readContectFromPDFDocUS(String location)
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String dtFormat = dateFormat.format(date);
		System.out.println(dateFormat.format(date));
		String fileName = "international-";
		List<String> pdfContent = new ArrayList<String>();
		PdfReader reader = new PdfReader(location.startsWith(fileName) + ".pdf");
		int pageCount = reader.getNumberOfPages();
		// System.out.println("Number of pages are:" +pageCount);
		for (int i = 1; i <= pageCount; i++) {
			pdfContent.add(PdfTextExtractor.getTextFromPage(reader, i));
			System.out.println("PDF Text contentUS:" + pdfContent);
		}
		return pdfContent;
	}

	public String verifyGetLatestReportButtonName(String getLatestReport) {
		getLatestReportButtonName.isPresent();
		UIHelper.highlightElement(getDriver(), getLatestReportButtonName);
		String results = getLatestReportButtonName.getText();
		return results;
	}
	
	public String isPortfolioIconEnabledPage() {
		String portfolioIndicator = "";
		UIHelper.highlightElement(getDriver(), portfolioButton);
		
		if(portfolioButton.isEnabled()){
			portfolioIndicator = "enabled";
		}  else {
			portfolioIndicator = "portfolio indicator disabled";
		}
	
		return portfolioIndicator;
		
	}
	
	public void clickOnQuickSearchDropDown() {
		   drpdwnCountry.isPresent();

			drpdwnCountry.click();
			searchTextBoxCountry.waitUntilPresent();		
	}
	
	public String enterCountryName(String countryname){

		List<String> countryNamesList = new ArrayList<String>();
		
		searchTextBoxCountry.isPresent();
		UIHelper.highlightElement(getDriver(), searchTextBoxCountry);
			searchTextBoxCountry.clear();
			searchTextBoxCountry.sendKeys(countryname);	
		
		for(WebElement name : getdropdownCountrynameList){
			//UIHelper.waitForVisibilityOfEleByXpath(getDriver(),name.getText());
			System.out.println("****** name.getText()***** " +name.getText());
			countryNamesList.add(name.getText());
		}
		if(countryNamesList.contains(countryname)){
			System.out.println("I am in if condition ***** ");
			return countryname;
	    } else {
	    	System.out.println("I am in else condition ***** ");
	    	return null;
	    }
		
		
	}
	public String AdvancedSearchNavigator(String value) {
		String result=null;
		if(advancesearchexpand.isPresent()) {
			UIHelper.highlightElement(getDriver(), advancesearchexpand);
			advancesearchexpand.click();
			advancesearchcountry.waitUntilVisible();
			advancesearchcountry.click();
			advanceSearchTextBoxCountry.waitUntilVisible();
			result=value;
			System.out.println("I am in Advanced search navigator : ******* "+result);
		}else {
			result="Advance search window not displayed";
		}
		
		return result;
	}
	
	public String enterCountryNameAdvanceSearch(String countryname){
		String country = "";
		List<String> countryNamesList = new ArrayList<String>();
		UIHelper.highlightElement(getDriver(), advanceSearchTextBoxCountry);
		advanceSearchTextBoxCountry.isPresent();
		UIHelper.highlightElement(getDriver(), advanceSearchTextBoxCountry);
			advanceSearchTextBoxCountry.clear();
			advanceSearchTextBoxCountry.sendKeys(countryname);
			
		
		for(WebElement name : getAdvanceddropdownCountrynameList){
			//UIHelper.waitForVisibilityOfEleByXpath(getDriver(),name.getText());
			System.out.println("****** name.getText()***** " +name.getText());
			countryNamesList.add(name.getText());
		}
		if(countryNamesList.contains(countryname)){
			System.out.println("I am in if condition ***** ");
			country= countryname;
	    } 
	    	closeBtn.click();
	    	return country;
	    
		
}

	public String advanceSearchEnterCountryName(String countryname, String statename){
		String stateName = "";
		
		advanceSearchTextBoxCountry.waitUntilPresent();
		advanceSearchTextBoxCountry.isPresent();
		UIHelper.highlightElement(getDriver(), advanceSearchTextBoxCountry);
			advanceSearchTextBoxCountry.sendKeys(countryname);
			advanceSearchTextBoxCountry.sendKeys(Keys.ENTER);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), advanceSearchTextBoxStateStr);
			advanceSearchTextBoxState.waitUntilPresent();
			advanceSearchTextBoxState.isPresent();
			UIHelper.highlightElement(getDriver(), advanceSearchTextBoxState);
			advanceSearchTextBoxState.click();
//			advanceSearchTextBoxState.type(statename);
			advanceSearchTextBoxStateinput.sendKeys(statename);
			UIHelper.highlightElement(getDriver(), advanceSearchTextBoxStateName);
		 stateName=advanceSearchTextBoxStateName.getText();
			System.out.println("***State Name is :"+stateName);
			
			
		
	/*	for(WebElement name : advanceSearchTextBoxStateNameList){
			//UIHelper.waitForVisibilityOfEleByXpath(getDriver(),name.getText());
			System.out.println("****** name.getText()***** " +name.getText());
			stateNamesList.add(name.getText());
		}
		if(!stateNamesList.contains(statename)){
			result=false;
		}*/
			
			closeBtn.click();	
		return stateName;
	}

	public String enterRemovedCountryName(String countryname){
		String result = countryname+" Should not display";
		//List<String> countryNamesList = new ArrayList<String>();
		String Str1=getdropdownCountryname.getText();
		searchTextBoxCountry.isPresent();
		UIHelper.highlightElement(getDriver(), searchTextBoxCountry);
			searchTextBoxCountry.clear();
			searchTextBoxCountry.sendKeys(countryname);	
			searchTextBoxCountry.sendKeys(Keys.ENTER);
		//for(WebElement name : getdropdownremovedCountrynameList){
			//UIHelper.waitForVisibilityOfEleByXpath(getDriver(),name.getText());
			//System.out.println("****** name.getText()***** " +name.getText());
			//countryNamesList.add(name.getText());
			
		String Str2 = getdropdownCountryname.getText();
		if(Str1.equals(Str2)){
			return result;
	    } else {	    	
	    	return Str2;
	    }
		
	}
	
	public String enterRemovedCountryNameAdvanceSearch(String countryname){
		
		String result = countryname+" Should not display";
		
		advanceSearchTextBoxCountry.isPresent();
		UIHelper.highlightElement(getDriver(), advanceSearchTextBoxCountry);
		advanceSearchTextBoxCountry.clear();
		advanceSearchTextBoxCountry.sendKeys(countryname);	
		String emptyCountry ="";
		try
		{
			WebElement emptyCountryName = getDriver().findElement(By.xpath("//form/fieldset//div[@class='select2-drop select2-with-searchbox select2-drop-active']//ul"));
			emptyCountry = emptyCountryName.getText().trim();
		}catch(NullPointerException e){
			closeBtn.click();
			return result;
		}
		
		if(emptyCountry.equals("")){
			closeBtn.click();
			return result;
		}
		 	closeBtn.click();
	    	return emptyCountry;	
	}

}