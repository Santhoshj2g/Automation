package com.dnb.automation.srm.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * CompanyProfilePage.java - This program contains steps for 1. User checks the
 * Company profile-page navigation 2. User clicks the button named as
 * 'update-Record' for latest records update 3. User checks SER-Rating value in
 * company profile page 4. User checks SSI-Rating value in company profile page
 * 5. User checks FSS Percentile value in company profile page
 *
 * @author Joseph Dennison
 ***********************************************************************************************/
public class SupplierProfilePage extends PageObject {

	//private static final boolean False = false;

	@FindBy(xpath = "//*[@class='dashboard-container']//*[@class='screening-alerts-detail clearFix']//*[@id='example']//*[@id='0']/td[1]/h4/a")
	private WebElementFacade companyname;

	@FindBy(xpath = "//*[@id='wrapper']/div[6]/div[4]")
	private WebElementFacade companyNameFrame;

	@FindBy(xpath = "//*[@id='wrapper']/div[6]/div[4]")
	private WebElementFacade profileFrame;

	@FindBy(xpath = "//*[@class='box-container']//li[5]//*[@id='update_rec'] | //*[@class='box-container']//li[5]//*[@id='update_rec_disabled']")
	private WebElementFacade updaterecord;

	@FindBy(xpath = ".//*[contains(@class,'box-container')]/ul/li[@id='header-right-box']/button[contains(@id,'update_rec_disabled') and contains(@style,'display:')]//ancestor::li[@id='header-right-box']/button[contains(@id,'update_rec')]")
	private WebElementFacade updaterecordEnableBtnEle;

	@FindBy(xpath = ".//*[contains(@class,'box-container')]/ul/li[@id='header-right-box']/button[contains(@id,'update_rec') and contains(@style,'display:')]//following-sibling::button[contains(@id,'update_rec_disabled')]")
	private WebElementFacade updaterecordDisableBtnEle;

	@FindBy(xpath = "//*[@id='profile_section']//*[@id='profile_prescore']//ul//li[2]//*[@id='cmp_SERSlider']//div//*[@class='CmpvalueContainer'] | //*[@id='profile_section']//*[@id='profile_prescore']//ul//li[2]//*[@id='cmp_SERSlider'][contains(.,'Not Available')] | //*[@id='profile_section']//*[@id='profile_prescore']//ul//li[2]//*[@id='cmp_SERSlider'][contains(.,'Out of Business')]")
	private WebElementFacade profileserRating;

	@FindBy(xpath = ".//*[@id='cstmFieldContainer']/span[contains(text(),'Amount Details')]/following::span[1]")
	private WebElementFacade amountDetailsValue;
	
	@FindBy(xpath=".//*[@id='cstmFieldContainer']/span[contains(text(),'Are You Certified')]/following::span[1]")
	private WebElementFacade areyouCertifiedValue;
    
	@FindBy(xpath=".//*[@id='cstmFieldContainer']/span[contains(text(),'Date Started')]/following::span[1]")
	private WebElementFacade dateValue;
	
	@FindBy(xpath=".//*[@id='cstmFieldContainer']/span[contains(text(),'Public Share')]/following::span[1]")
	private WebElementFacade publicShareValue;
	
	@FindBy(xpath=" .//*[@id='cstmFieldContainer']/span[contains(text(),'Your Share')]/following::span[1]")
	private WebElementFacade yourShareValue;
	
	@FindBy(xpath = "//*[@id='cmp_SSISlider']//div//*[@class='CmpvalueContainer'] | //*[@id='profile_section']//*[@id='profile_prescore']//ul//li[1]//*[@id='cmp_SSISlider'][contains(.,'Out of Business')]")
	private WebElementFacade profilessiRating;

	@FindBy(xpath = "//*[@id='cmp_FssSlider']//div//*[@class='CmpvalueContainer'] | //*[@id='profile_section']//*[@id='profile_prescore']//ul//li[6]//*[@id='cmp_FssSlider'][contains(.,'Not Available')] | //*[@id='profile_section']//*[@id='profile_prescore']//ul//li[6]//*[@id='cmp_FssSlider'][contains(.,'Out of Business')]")
	private WebElementFacade profilefssRating;

	@FindBy(xpath = "//*[@id='profile_section']//*[@id='profile_prescore']//ul//li[6]//*[@class='Nmae_l'][contains(.,'Failure Score (1-100)')]")
	private WebElementFacade profileFailuerScoreNameCheck;

	@FindBy(xpath = "//*[@id='profile_prescore']/ul/li[6]//*[@class='Nmae_l']//a//img")
	private WebElementFacade profileGlossaryFSSnmeChk;

	@FindBy(xpath = "html/body/span[81][contains(.,'Failure Score (1-100)')]")
	private WebElementFacade GlossaryNmeVerify;

	@FindBy(xpath = "//*[@id='wrapper_header']//*[@class='header-tabs-container clearFix']//ul//*[@id='desktopMenu']/a")
	private WebElementFacade dashBoard;

	@FindBy(xpath = ".//*[@id='wrapper']//*[@class='container']//*[@class='dashboard-container']//*[@class='page-heading']/h1")
	private WebElementFacade dashboardTitleEle;

	@FindBy(xpath = ".//*[@id='profile_section']//*[@class='rich-panel-header panelheader']")
	private List<WebElement> profileSections;

	@FindBy(xpath = "/*[@class='container']//*[@id='errMsg']")
	private WebElementFacade updateRecordErrorMsg;

	@FindBy(xpath = "//*[@class='container']//*[@id='errMsg']//img")
	private WebElementFacade updateRecordErrorCloseBtn;

	private String fssValue;
	private String SSIValue;
	private String SERValue;
	private String FailureScoreChangedName;
	private String FssGlossaryNmeChk;
	private ArrayList<String> sectionNamesInProfileTab = new ArrayList<String>();

	//private WebElementFacade areyouCertifiedValue;

	// Verify Company profile-page navigation

	public void navigateToCompanyName() {
		companyNameFrame.waitUntilPresent();
	}

	public void companyNamePage() throws Exception {
		try {
			waitFor(10000).milliseconds();
			companyname.waitUntilEnabled();
			UIHelper.highlightElement(getDriver(), companyname);
			companyname.click();
			UIHelper.waitForPageToLoad(getDriver());
		} catch (Exception e) {

		}
	}

	public void toolkitCredentials() throws Exception {

	}

	// Click the button named as 'update-Record' for latest record update in
	// database

	public boolean updateRecordButton(String DUNSNO) throws Exception {
		boolean UpdateRcdErrormsg = false;
		String BackURL;
		String B[] = new String[2];
		try {
			if (updaterecordEnableBtnEle.isPresent()) {
				updaterecord.click();
				UIHelper.waitForPageToLoad(getDriver());
				if (System.getProperty("appURL").contains("/cp/login")) {
					B = System.getProperty("appURL").split("/cp");
					System.out.println(B[0]);
					BackURL = B[0] + "/cp/search?mainSearch=" + DUNSNO
							+ "&nationalBusCode=&nationalBusNum=&searchTab=D-U-N-S%20Universe&searchType=D-U-N-S%20Number&searchIndex=1&curTab=3&curHeaderTab=desktopMenu&duns=&city=&zipCd=&address=&state=&stateName=&location=&country=&countryIsoCode=&cstmFld1=&cstmFld2=&cstmFld3=&cstmFld4=&cstmFld5=#errorMessageNav";
					System.out.println(BackURL);
				} else {
					BackURL = System.getProperty("appURL") + "/cp/search?mainSearch=" + DUNSNO
							+ "&searchTab=D-U-N-S%20Universe&searchType=D-U-N-S%20Number&searchIndex=1&curTab=0&curHeaderTab=desktopMenu&duns=&city=&zipCd=&address=&state=&stateName=&location=&country=&countryIsoCode=";
				}
				getDriver().get(BackURL);
				UIHelper.waitForPageToLoad(getDriver());
			} else if (updaterecordDisableBtnEle.isPresent()) {
				if (System.getProperty("appURL").contains("/cp/login")) {
					B = System.getProperty("appURL").split("/cp");
					System.out.println(B[0]);
					BackURL = B[0] + "/cp/search?mainSearch=" + DUNSNO
							+ "&nationalBusCode=&nationalBusNum=&searchTab=D-U-N-S%20Universe&searchType=D-U-N-S%20Number&searchIndex=1&curTab=3&curHeaderTab=desktopMenu&duns=&city=&zipCd=&address=&state=&stateName=&location=&country=&countryIsoCode=&cstmFld1=&cstmFld2=&cstmFld3=&cstmFld4=&cstmFld5=#errorMessageNav";
				} else {
					BackURL = System.getProperty("appURL") + "/cp/search?mainSearch=" + DUNSNO
							+ "&searchTab=D-U-N-S%20Universe&searchType=D-U-N-S%20Number&searchIndex=1&curTab=0&curHeaderTab=desktopMenu&duns=&city=&zipCd=&address=&state=&stateName=&location=&country=&countryIsoCode=";
				}
				getDriver().get(BackURL);
				UIHelper.waitForPageToLoad(getDriver());
				// BackURL =
				// System.getProperty("appURL")+"/cp/search?mainSearch="+DUNSNO+"&searchTab=D-U-N-S%20Universe&searchType=D-U-N-S%20Number&searchIndex=1&curTab=0&curHeaderTab=desktopMenu&duns=&city=&zipCd=&address=&state=&stateName=&location=&country=&countryIsoCode=";
				// getDriver().get(BackURL);
				// UIHelper.waitForPageToLoad(getDriver());
			}

		} catch (Exception e) {

		}
		return UpdateRcdErrormsg;
	}

	// Verify the Company profile-page Frame

	public boolean profilePageCheck() {
		profileFrame.waitUntilPresent();
		if (profileFrame.isPresent()) {
			return true;
		} else {
			return false;
		}
	}

	// Verify the SSI-Rating value in Supplier Profile page

	public String profileSsiVal() throws Exception {
		try {
			if (element(profilessiRating).isPresent()) {
				// UIHelper.waitForPageToLoad(getDriver());
				SSIValue = profilessiRating.getText().toString().trim();
				UIHelper.highlightElement(getDriver(), profilessiRating);

			}
		} catch (Exception e) {

		}
		return SSIValue;
	}

	// Verify the SER-Rating value in Supplier Profile page

	public String profileSerVal() throws Exception {
		try {
			profileserRating.waitUntilPresent();
			if (element(profileserRating).isPresent()) {
				SERValue = profileserRating.getText().toString().trim();
				UIHelper.highlightElement(getDriver(), profileserRating);
			}
		} catch (Exception e) {

		}
		return SERValue;
	}
	// Verify the Amount Details value in Supplier Profile page

	public String verifyAmountDetailValue() throws Exception {
		String amtDetVal = null;
		try {
			amountDetailsValue.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), amountDetailsValue);
			amtDetVal = amountDetailsValue.getText().toString().trim();
			System.out.println("amountDetValue: "+amtDetVal);
		} catch (Exception e) {

		}
		return amtDetVal;
	}
	
	//verify the Are you certified value in Supplier Profile page
	public String verifyAreyouCertifiedValue()throws Exception {
      String certifiedval=null;
      try
      {
   
	areyouCertifiedValue.waitUntilPresent();
	  UIHelper.highlightElement(getDriver(),  areyouCertifiedValue);
	  certifiedval =  areyouCertifiedValue.getText().toString().trim();
	System.out.println("areyouCertifiedValue: "+certifiedval);
    } catch (Exception e) {

   }
     return certifiedval;
    }
  //verify Date started value in supplier profile page
	
	public String  verifyDateValue() throws Exception{
		String dateVal = null;
		try {
			dateValue.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), amountDetailsValue);
			dateVal = dateValue.getText().toString().trim();
			System.out.println("dateValue: "+dateVal);
		} catch (Exception e) {

		}
		return dateVal;
		
	}
	
	//verify public value in supplier profile page
	
	public String verifyPublicShareValue() throws Exception {
		String publicval = null;
		try {
			publicShareValue.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), publicShareValue);
			publicval = publicShareValue.getText().toString().trim();
			System.out.println("publicShareValue: "+publicval);
		} catch (Exception e) {

		}
		return publicval;
	}
		
	//Verify your share value in supplier profile page
	
	public String verifyYourShareValue()  throws Exception {
		String yourShareval= null;
		try {
			yourShareValue.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), yourShareValue);
			yourShareval = yourShareValue.getText().toString().trim();
			System.out.println("yourShareValue: "+yourShareval);
		} catch (Exception e) {

		}
		return yourShareval; 
		
		
	}


	// Verify the FailureScore (1-100) value in Supplier Profile page

	public String profileFSSValue() throws Exception {
		try {
			profilefssRating.waitUntilPresent();
			if (element(profilefssRating).isPresent()) {
				fssValue = profilefssRating.getText().toString().trim();
				UIHelper.highlightElement(getDriver(), profilefssRating);
			}
		} catch (Exception e) {

		}
		return fssValue;
	}

	// Verify the FailureScore (1-100) name change in Supplier profile page

	public String profileFailureScorenameChange() throws Exception {
		try {
			profileFailuerScoreNameCheck.waitUntilPresent();
			if (element(profileFailuerScoreNameCheck).isPresent()) {
				FailureScoreChangedName = profileFailuerScoreNameCheck.getText().toString().trim();
				UIHelper.highlightElement(getDriver(), profileFailuerScoreNameCheck);
			}
		} catch (Exception e) {

		}
		return FailureScoreChangedName;
	}

	// Click the Failure score (1-100)GLosary button

	public void GlosaryFSSbutton() throws Exception {
		try {

			String mainwindow = getDriver().getWindowHandle();
			profileGlossaryFSSnmeChk.click();
			for (String winHandle : getDriver().getWindowHandles()) {
				getDriver().switchTo().window(winHandle);
				getDriver().manage().window().maximize();
				getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				UIHelper.highlightElement(getDriver(), profileGlossaryFSSnmeChk);
			}
			getDriver().close();
			getDriver().switchTo().window(mainwindow);

		} catch (Exception e) {

		}
	}

	// Verify the FailureScore (1-100) name of glossary change in Supplier
	// profile page

	public String GlossaryFssNewName() throws Exception {
		try {
			if (element(GlossaryNmeVerify).isPresent()) {
				FssGlossaryNmeChk = GlossaryNmeVerify.getText().toString().trim();
				UIHelper.highlightElement(getDriver(), GlossaryNmeVerify);
			}
		} catch (Exception e) {

		}
		return FssGlossaryNmeChk;

	}

	// Verify Dash-board navigation for next DUNS number

	public void dashBoardPage() throws Exception {
		try {
			if (element(dashBoard).isPresent()) {
				UIHelper.highlightElement(getDriver(), dashBoard);
				dashBoard.click();
				dashBoard.wait(8000);
				// UIHelper.waitForPageToLoad(getDriver());
				dashboardTitleEle.waitUntilPresent();
			}
		} catch (Exception e) {

		}
	}

	// Get the section names from Profile tab
	public ArrayList<String> getSectionNamesFromProfileTab() {
		for (WebElement element : profileSections) {
			sectionNamesInProfileTab.add(element.getText());
		}

		return sectionNamesInProfileTab;
	}

	
	
	

	
}