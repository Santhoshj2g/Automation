package com.dnb.automation.eram.pages;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import com.google.common.base.Predicate;
import com.dnb.automation.eram.pages.AccountPage;


public class eRamAdministrationPage extends PageObject {
	 private final Logger log=Logger.getLogger(this.getClass().getPackage().getName());
	  @FindBy(xpath = "//span[contains(@id,'ADMIN-btnInnerEl')]/div[contains(.,'ADMIN')]")
	  private WebElementFacade adminTab;
	  
	  @FindBy(xpath = "//span[contains(@id,'processbutton') and contains(@id,'btnInnerEl') and contains(.,'+New')]")
	  private WebElementFacade userProfileNewBtn;
	  
	  @FindBy(xpath = "//*[@id='userprofilelistviewid-innerCt']//span[contains(@id,'gridcolumn') and contains(@id,'textEl') and contains(.,'User Login')]")
	  private WebElementFacade userLoginColumn;
	  
	  @FindBy(xpath = "//*[@id='userprofilelistviewid-innerCt']//*[contains(@id,'gridcolumn') and contains(@id,'triggerEl')]")
	  private WebElementFacade uspSortOrderList;
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Credit Limit Policies')]")
	  private WebElementFacade creditLimitPoliciesTab;
	  
	  @FindBy(xpath = "//span[@id='CrLP_btn_1-btnInnerEl' and contains(.,'+ New')]")
	  private WebElementFacade creditLimitPoliciesNewRuleBtn;
	  
	  String userProfileTableXpath="//*[@id='userProfilegridid-body']//table/tbody";
	  
	  static String sortUserLoginName ;
	  
	public static String getSortUserLoginName() {
		return sortUserLoginName;
	}

	public void click_Admin_Tab() {
		adminTab.isVisible();
		AccountPage.highlightElement(getDriver(), adminTab);
		adminTab.click();
		AccountPage.waitForVisibilityOfeRAMElementsforlesstime(getDriver(),userProfileTableXpath);
		AccountPage.highlightElement(getDriver(), userProfileNewBtn);
	}
	
	public boolean verify_Admin_Page_Has_Displayed(){
		return userProfileNewBtn.isVisible();
	}
	
	public boolean verify_user_Lgin_Sort_Order(String SortOrderOption){
		
		boolean isSorted = true;
		List<String> sortedList = new ArrayList<String>();
		AccountPage.mouseOverAndHighlightanElement(getDriver(), userLoginColumn);
		uspSortOrderList.isVisible();
		AccountPage.mouseOveranElement(getDriver(), uspSortOrderList);
		waitFor(200).milliseconds();
		uspSortOrderList.click();
		waitFor(300).milliseconds();
		String ValueXpath="//*[contains(@id,'menuitem')]//a[@role='menuitem']/span[.='"+SortOrderOption+"']";
		WebElementFacade valueElement=find(By.xpath(ValueXpath));
		AccountPage.highlightElement(getDriver(), valueElement);
		valueElement.click();
		AccountPage.waitForVisibilityOfeRAMElementsforlesstime(getDriver(),userProfileTableXpath);
		waitFor(2000).milliseconds();
		List<WebElement> allrows = getDriver().findElements(By.xpath("//*[@id='userProfilegridid-body']//table/tbody/tr/td[1]/div"));
		for (WebElement trElement : allrows) {				
			AccountPage.mouseOveranElement(getDriver(), trElement);
			waitFor(100).milliseconds();
			sortedList.add(trElement.getText().trim());	
		}
		log.log(Level.INFO,"User login Name List Size  --------------------- "+sortedList.size());
		if(SortOrderOption.equals("Sort Descending")){
			for(int i = 0; i < sortedList.size() - 1; i++) {
				log.log(Level.INFO,"User login Name Descending order "+i+" --------------------- "+sortedList.get(i));
				if(sortedList.get(i).compareToIgnoreCase(sortedList.get(i + 1)) < 0) { // For Descending order check in a list
					sortUserLoginName=sortedList.get(i);
					log.log(Level.INFO,"Wrongly Sorted Descending User login Name "+i+"  ---- "+sortedList.get(i));
	    	       isSorted = false;
	    	       break;
	    	     }
		    }
		}else if(SortOrderOption.equals("Sort Ascending")){
			for(int i = 0; i < sortedList.size() - 1; i++) {
				log.log(Level.INFO,"User login Name Ascending Order "+i+"  --------------------- "+sortedList.get(i));
				if(sortedList.get(i).compareToIgnoreCase(sortedList.get(i + 1)) > 0) { // For Ascending order check in a list
					sortUserLoginName=sortedList.get(i);
					log.log(Level.INFO,"Wrongly Sorted Ascending User login Name "+i+"  ---- "+sortedList.get(i));
	    	       isSorted = false;
	    	       break;
	    	     }
		    }
		}
		
		return isSorted;
	 	
	}

	 		
}