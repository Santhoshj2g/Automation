package com.dnb.automation.sba.pages;

import java.util.Map;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.sba.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class SuppFamilyWithRiskPage extends PageObject{

	int totalDuns;

	/*Supplier Family WebElements*/

	@FindBy(xpath = "//*[@id='supplierFamily']/a")
	private WebElementFacade supplierFamily;

	@FindBy(xpath ="//*[@id='ui-id-7']")
	private WebElementFacade analysisSubTab;

	@FindBy(xpath ="//*[@id='analysisFilter-button']/span[1]")
	private WebElementFacade filter;

	@FindBy(xpath ="//*[@id='analysisFilter-menu']/li[6]/a")
	private WebElementFacade Risk;

	@FindBy(xpath ="//*[@id='SfAnalysisTotalCount']")
	private WebElementFacade totalRecords;

	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[2]")
	private WebElementFacade dunsNumber;

	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[3]")
	private WebElementFacade spend;

	@FindBy(xpath ="//*[@id='supplierAnalysis-ManageBtn']")
	private WebElementFacade manageCols;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[1]/span/a")
	private WebElementFacade cmpnyProfile_AF;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[2]/span/a")
	private WebElementFacade corpLinkage_AF;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[6]/span/a")
	private WebElementFacade socialResp_AF;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[7]/span/a")
	private WebElementFacade spend_AF;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[5]/span/a")
	private WebElementFacade risk_AF;

	@FindBy(xpath ="//*[@id='manageColumnsTreeView']/ul/li[3]/span/a")
	private WebElementFacade diversity_AF;

	@FindBy(xpath ="//*[@id='manageColumn-addbtnAnalysis']")
	private WebElementFacade manageColAddBtn;

	@FindBy(xpath ="//*[@id='manageColumn-applyBtn']")
	private WebElementFacade applyBtn;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[4]/ul/li[1]/span/a")
	private WebElementFacade forestryServices;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[4]/ul/li[2]/span/a")
	private WebElementFacade timberTracts;

	@FindBy(xpath ="(//*[@id='analysisTreeView']//*[@class='dynatree-container']//*[@class='dynatree-expander'])[1]")
	private WebElementFacade parentNode;

	@FindBy(xpath ="//*[@id='100']")
	private WebElementFacade itemsPerPage;

	@FindBy(xpath ="//*[@id='dynaPagHolder']/div[1]/div/a[2]")
	private WebElementFacade nextPage;

	@FindBy(xpath ="//*[@id='block_jump_valSF']")
	private WebElementFacade pageNum;

	@FindBy(xpath ="//*[@id='supplierAnalysis-DownloadListBtn']")
	private WebElementFacade export;

	@FindBy(xpath ="//*[@id='gridExcel']")
	private WebElementFacade exportToExcel;
	
	@FindBy(xpath ="//*[@id='block_jumpSF']")
	private WebElementFacade goButton;

	public String gridTableLoading ="//*[@class='analysisRightTab']//*[@class='innercontainer']//*[@class='gridViewTableLoading']/img[@src='static/images/ajax-loader.gif']";
	
	
	/*Risk WebElements*/
	int totalDunsOfRisk;

	@FindBy(xpath ="//*[@id='riskAnalysis']/a")
	private WebElementFacade RiskTab;

	@FindBy(xpath ="//*[@id='ui-id-10']")
	private WebElementFacade analysisTabOfRisk;

	@FindBy(xpath ="//*[@id='analysisFilter-button']/span[2]")
	private WebElementFacade filterOfBU;

	@FindBy(xpath ="//*[@id='searchInpDIV']")
	private WebElementFacade RiskCategory;

	@FindBy(xpath ="//*[@id='analysisTreeView']/ul/li[4]/span/a")
	private WebElementFacade agriculturalProductionCropsOfBU;

	@FindBy(xpath ="//*[@id='RaAnalysisTotalCount']")
	private WebElementFacade totalRecordsOfRisk;

	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[2]")
	private WebElementFacade dunsOfRisk;

	@FindBy(xpath ="//*[@id='supplierAnalysisTBody']/tr[1]/td[3]")
	private WebElementFacade spendOfRisk;

	@FindBy(xpath ="//*[@id='manageColumn-addBtn']")
	private WebElementFacade manageColAddBtnRisk;

	@FindBy(xpath ="//*[@id='supplierAnalysisPiecontainer']//*[name()='svg']/*[name()='g'][2]/*[name()='g'][2]/*[name()='text']/*[contains(.,'Low')]")
	private WebElementFacade parentItemInRisk;

	@FindBy(xpath ="//*[@id='riskAnalDrop-button']/span[2]")
	private WebElementFacade riskFilter;

	@FindBy(xpath ="//*[@id='ui-selectmenu-item-289']")
	private WebElementFacade riskFactor_SSI;

	@FindBy(xpath ="//*[@id='riskAnalDrop-menu']/li[2]/a")
	private WebElementFacade riskFactor_SER;

	@FindBy(xpath ="//*[@id='dynaPagHolder']/div[1]/div/a[2]")
	private WebElementFacade nextPageOfRisk;

	@FindBy(xpath ="(//*[@id='100'])[1]")
	private WebElementFacade itemsPerPageRisk;

	@FindBy(xpath ="//*[@id='block_jump_valSF']")
	private WebElementFacade pageNumRisk;

	@FindBy(xpath ="//*[@id='searchInpSF']")
	private WebElementFacade search;
	
	@FindBy(xpath ="//*[@id='block_jumpSF']")
	private WebElementFacade goButtonOfRisk;

	String child1="//*[@id='supplierAnalysisPiecontainer']//*[name()='svg']/*[name()='g'][2]/*[name()='g']/*[name()='text']/*[name()='tspan'][contains(text(),'1')]";
	String child2="//*[@id='supplierAnalysisPiecontainer']//*[name()='svg']/*[name()='g'][2]/*[name()='g']/*[name()='text']/*[name()='tspan'][contains(text(),'2')]";



	public void chooseRisk(){
		UIHelper.clickAnElement(filter);
		UIHelper.clickAnElement(Risk);
	}

	public void clickOnParentItem(){
		UIHelper.switchToTab(getDriver(),"supplierFamily");
		UIHelper.clickAnElement(parentNode);
	}

	public int getTotalRecords(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDuns=UIHelper.getTotalRecords(totalRecords);
		System.out.println("getTotalRecords :"+totalDuns);
		return UIHelper.getTotalRecords(totalRecords);
	}

	public Map<String,String> getSpendValue(){
		UIHelper.switchToTab(getDriver(),"supplierFamily");
		String preXpath="//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.clickAnElement(itemsPerPage);
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDuns, nextPage);
	}

	public Map<String,String> getSpendAfterAddcols(){
		String preXpath="//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDuns, nextPage);
	}

	public Map<String, String> getSpendValueOfChild(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDuns=UIHelper.getTotalRecords(totalRecords);
		UIHelper.clickAnElement(itemsPerPage);
		return getSpendAfterAddcols();
	}

	/*Risk page*/

	public void clickOnRisk(){
		String URL=getDriver().getCurrentUrl();
		UIHelper.openInNewTab(getDriver(),URL);
		UIHelper.clickAnElement(RiskTab);
	}

	public void clickOnAnalysisTabOfRisk(){
		analysisTabOfRisk.click();
	}

	public void chooseRiskFactor(){
		riskFilter.click();
		riskFactor_SER.click();
	}

	public void clickOnParentItemInRisk(){
		UIHelper.switchToTab(getDriver(),"notSF");
		UIHelper.clickAnElement(parentItemInRisk);
	}

	public int getTotalRecordsInRisk(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDunsOfRisk=UIHelper.getTotalRecords(totalRecordsOfRisk);
		System.out.println("getTotalRecordsOfRisk :"+totalDunsOfRisk);
		return UIHelper.getTotalRecords(totalRecordsOfRisk);
	}

	public Map<String,String> getSpendValueInRisk(){
		UIHelper.switchToTab(getDriver(),"notSF");
		String preXpath="//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.clickAnElement(itemsPerPageRisk);
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDunsOfRisk, nextPageOfRisk);
	}

	public Map<String, String> getSpendValueOfChildInRisk(){
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		totalDunsOfRisk=UIHelper.getTotalRecords(totalRecordsOfRisk);
		UIHelper.clickAnElement(itemsPerPageRisk);
		return getSpendAfterAddColsInRisk();
	}

	public void clickOnManageColsOfRisk(){
		UIHelper.switchToTab(getDriver(),"notSF");
		UIHelper.gotoFirstPage(pageNumRisk,goButtonOfRisk);
		UIHelper.clickAnElement(manageCols);
	}

	public void addColsAndClickApplyInRisk(){
		cmpnyProfile_AF.waitUntilPresent();
		cmpnyProfile_AF.click();
		manageColAddBtnRisk.click();

		if(corpLinkage_AF.isPresent())
		{
			corpLinkage_AF.click();
			manageColAddBtnRisk.click();
		}
		if(diversity_AF.isPresent())
		{
			diversity_AF.click();
			manageColAddBtnRisk.click();
		}
		if(spend_AF.isPresent())
		{
			spend_AF.click();
			manageColAddBtnRisk.click();
		}
		if(risk_AF.isPresent())
		{
			risk_AF.click();
			manageColAddBtnRisk.click();
		}
		if(socialResp_AF.isPresent())
		{
			socialResp_AF.click();
			manageColAddBtnRisk.click();
		}
		applyBtn.click();
	}


	public Map<String,String> getSpendAfterAddColsInRisk(){
		String preXpath="//*[@id='supplierAnalysisTBody']/tr[";
		UIHelper.waitForInvisibilityOfChartAndTable(getDriver());
		return UIHelper.getAllSpendValues(getDriver(), preXpath, totalDunsOfRisk, nextPageOfRisk);
	}

	public boolean isTotalRecDisplayed()
	{
		return UIHelper.isElementDisplayed(totalRecords);
	}

	public void typeAndEnter(String value)
	{
		search.typeAndEnter(value);
	}

	public void clickOnExportToExcelInRisk(){
		UIHelper.switchToTab(getDriver(), "notSF");
		UIHelper.mouseOveranElement(getDriver(),export);
	}

	public boolean isDataExportedInRisk(){
		return exportToExcel.isPresent();
	}

}
