package com.dnb.automation.utils;

import static com.jayway.restassured.RestAssured.given;

public class RestJSONParser {

    public String testAuthentication() throws Exception {
        String authString = given().header("Content-Type", "application/json")
        /*
         * .header(readJsonfile.getGetRestUserName(),
         * readJsonfile.getGetRestUserNameVal())
         * .header(readJsonfile.getGetRestPwd(),
         * readJsonfile.getGetRestPwdVal()).when()
         * .get(readJsonfile.getGetRestURL()) .header("Authorization");
         */.header("x-dnb-user", "cirrustest@dnb.com")
                .header("x-dnb-pwd", "password").when()
                .get("http://services-ext-stg.dnb.com/rest/Authentication")
                .header("Authorization");
        return authString;
    }

    public String testProduct(String authKey, String dunsNo) {
        String responseString = given()
                .header("Content-Type", "application/json")
                .header("Authorization", authKey)
                .header("ApplicationId", "42")
                // .header("ApplicationId", readJsonfile.getApplnID())
                .when()
                .get("http://services-ext-stg.dnb.com/V2/organizations/"
                        + dunsNo + "/products/CP_SMMR").asString();

        return responseString;
    }
    // JsonPath jsonPath = new
    // JsonPath(responseString).setRoot("OrderProductResponse.OrderProductResponseDetail.Product");

}
