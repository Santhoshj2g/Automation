package com.dnb.automation.dnbi.pages;

import java.util.List;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * ECFPDFGenerationPage.java - This class contains methods for creating PDF's
 * for credit files in ECF page
 * 
 * @author Duvvuru Naveen
 * @version 1.0
 ***********************************************************************************************/
public class ECFPDFGenerationPage extends PageObject {

    // *Creating a template for an application and for an account

    @FindBy(xpath = "//*[@id='header_mainApp']//*[@class='primaryNav_div']//a[text()='Companies']")
    private WebElementFacade companiesTab;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//a")
    private WebElementFacade folderTabTableEle;

    private String loadingImageEleXpath = "//*[@id='loading']/span";

    @FindBy(xpath = ".//*[@class='results full']//tr[2]//a[contains(.,'All Credit Files')]")
    private WebElementFacade allCreditFiles;

    @FindBy(xpath = ".//*[@class='disInline']//*[@id='entityFilter']")
    private WebElementFacade viewDropDown;

    @FindBy(xpath = ".//*[@class='alert_box include_filterBG']//*[@value='Apply']")
    private WebElementFacade applyButton;

    @FindBy(xpath = ".//*[@class='results full_company']//tr[1]//td[2]//*[@class='navlinktable']")
    private WebElementFacade firstEle;

    @FindBy(xpath = ".//*[@id='enablePdf']//a[contains(.,'PDF')]//span")
    private WebElementFacade pdf;

    @FindBy(xpath = "//*[@class='modal_inner_content']//*[@id='loading']//a[contains(.,'click here')]")
    private WebElementFacade clickHere;

    @FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
    private WebElementFacade iFrameEle;

    @FindBy(xpath = "//*[@id='main']/table/tbody/tr//td[2]")
    private List<WebElement> tableElements;

    @FindBy(xpath = ".//*[@id='page_title_links']/h2")
    private WebElementFacade creditFilesPageTitle;

    private String lodingImgInPDFWindow = "//*[@id='loading']/div/img";

    private String clickHereXpath = "//*[@class='modal_inner_content']//*[@id='loading']//a[contains(.,'click here')]";

    // Generate PDF's for Credit Files
    public void generatePDFForCreditFiles(String viewBy) {
        navigateToAllCreditFiles(viewBy);
        for (int index = 0; index < tableElements.size(); index++) {
            generatePDFForAllElements(tableElements.get(index));
            navigateToAllCreditFiles(viewBy);
        }
    }

    // Navigate to Credit Files Page
    public void navigateToAllCreditFiles(String viewBy) {
        try {
        	UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),"//*[@id='header_mainApp']//*[@class='primaryNav_div']//a[text()='Companies']");
            companiesTab.click();
            UIHelper.waitForPageToLoad(getDriver());
            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                    loadingImageEleXpath);

            allCreditFiles.waitUntilPresent();
            allCreditFiles.click();
            viewDropDown.waitUntilPresent();
            viewDropDown.selectByVisibleText(viewBy);

            UIHelper.waitForPageToLoad(getDriver());
            applyButton.waitUntilPresent();
            applyButton.click();
            UIHelper.waitForPageToLoad(getDriver());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Generate PDF for all credit files in ECF PAge
    public void generatePDFForAllElements(WebElement ele) {
        try {
            ele.click();
            UIHelper.waitForPageToLoad(getDriver());
            pdf.waitUntilPresent();
            pdf.click();
            waitFor(3000).milliseconds();
//            if (iFrameEle.isPresent()) {
//                getDriver().switchTo().frame(iFrameEle);
//            }
 
//           getDriver().findElement(By.xpath("//div[@class='modal']//div[@class='modal_content']//div[@class='modal_inner_content']")).sendKeys(Keys.ENTER);
 
           waitFor(1000).milliseconds();
            UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
                    lodingImgInPDFWindow);
             waitFor(1000).milliseconds();
            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                    lodingImgInPDFWindow);
             waitFor(2000).milliseconds();
            UIHelper.waitForVisibilityOfEleByXpath(getDriver(), clickHereXpath);
            clickHere.click();
            UIHelper.waitForPageToLoad(getDriver());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // Get the All Credit Files Page title
    public String getCreditFilePageTitle() {
        return creditFilesPageTitle.getText();
    }
   }