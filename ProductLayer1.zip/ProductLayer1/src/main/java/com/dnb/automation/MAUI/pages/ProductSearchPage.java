package com.dnb.automation.MAUI.pages;

import org.openqa.selenium.By;

import com.dnb.automation.sba.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class ProductSearchPage extends PageObject
{

	private String prdname = ".//td/font[text()='SERENITY']";
	private String prdclick =".//a[contains(@href,'PRODUCT')]/font[contains(text(),'LANGUAGE')]";
	
	public boolean enterProduct(String product, String language) 
	{
		boolean flag=false;
		try{
			String tempPrdname=prdname.replace("SERENITY", product);
			WebElementFacade prdnamexpath=find(By.xpath(tempPrdname));		
			if(prdnamexpath.isPresent())	{
				UIHelper.highlightElement(getDriver(), prdnamexpath);
				product= product.replace(" ","+");
				String tempPrdResultclick = prdclick.replace("PRODUCT", product)
						.replace("LANGUAGE", language);
				WebElementFacade PrdResultClick =find(By.xpath(tempPrdResultclick));
				if(PrdResultClick.isPresent()){
					UIHelper.highlightElement(getDriver(), PrdResultClick);
					PrdResultClick.click();
					flag=true;
				}else{
					flag=false;
				}
			}
				}catch(Exception e){
					
			}
		return flag;
		}
		
}
