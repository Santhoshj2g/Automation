package com.dnb.automation.dnbi.pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class XPathReturnImpl implements XPathReturn{
	public static final String xpathpath = "src/main/resources/Xpath.properties";
	public BufferedReader fileInputReader() throws FileNotFoundException {
		/*File file = new File(xpathpath);
		FileInputStream fileInput = null;
		fileInput = new FileInputStream(file);*/
		BufferedReader fileInput = null;
		//FileReader file = new FileReader(xpathpath);
		fileInput = new BufferedReader(new FileReader(xpathpath));
		return fileInput;
	}

	public String XPath(String propname) {
		String getXPath = null;
		String findXPath = null;
		Properties prop = new Properties();
		try {
			prop.load(fileInputReader());
			findXPath = prop.getProperty(propname);
			getXPath = findXPath;
		} catch (IOException e) {
			e.printStackTrace();
		}synchronized ( getXPath ) {
		return getXPath;
		}
	}

	public String XPath(String appvalue, String propname) {
		String getSingleXPath = null;
		String findXPath = null;
		Properties prop = new Properties();
		try {
			prop.load(fileInputReader());
			findXPath = prop.getProperty(propname);
			getSingleXPath = findXPath.replace("XPValue", appvalue);
		} catch (Exception ex) {
			ex.printStackTrace();
		}synchronized ( getSingleXPath ) {
		return getSingleXPath;
		}
	}

	public String XPath(String appvalue1, String appvalue2,
			String propname) {
		String getRefXPath = null;
		String findXPath = null;
		Properties prop = new Properties();
		try {
			prop.load(fileInputReader());
			findXPath = prop.getProperty(propname);
			getRefXPath = findXPath.replace("XPValue1", appvalue1).replace(
					"XPValue2", appvalue2);
		} catch (Exception ex) {
			ex.printStackTrace();
		}synchronized ( getRefXPath ) {
		return getRefXPath;
		}
	}

}
