package com.dnb.automation.dbiaopal.pages;


import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

/**
 * Created by 630239 on 5/19/2017.
 */
public class LoginPage extends PageObject {

    @FindBy(xpath=".//*[@id='SubscriberNumber']")
    private WebElementFacade subscribernum;

    @FindBy(xpath=".//*[@id='UserId']")
    private WebElementFacade UserName;

    @FindBy(xpath=".//*[@id='Password']")
    private WebElementFacade Password;

    @FindBy(xpath=".//*[@id='DoLoginButton']")
    private WebElementFacade loginbtn;

    public void getURLtoLaunch(String applicationURL) {
        getDriver().manage().deleteAllCookies();
        launchURL(applicationURL);
    }

    private void launchURL(String appURL) {

        getDriver().get(appURL);
        getDriver().manage().window().maximize();
        UIHelper.waitForPageToLoad(getDriver());
    }

    public void login(String subscribberID, String username, String password) {
        enterSubsciber(subscribberID);
        enterUsername(username);
        enterPassword(password);
        clickLogin();
    }

    private void clickLogin() {
        try {
            UIHelper.highlightElement(getDriver(), loginbtn);
            loginbtn.click();
        } catch(AssertionError e)
        {
            e.printStackTrace();
        }
    }

    private void enterPassword(String password) {
        try {
            UIHelper.highlightElement(getDriver(), Password);
            Password.type(password);
        } catch(AssertionError e)
        {
            e.printStackTrace();
        }
    }

    private void enterUsername(String username) {
        try {
            UIHelper.highlightElement(getDriver(), UserName);
            UserName.type(username);
        } catch(AssertionError e)
        {
            e.printStackTrace();
        }
    }

    private void enterSubsciber(String subscribberID) {
        try {
            UIHelper.highlightElement(getDriver(), subscribernum);
            subscribernum.type(subscribberID);
        } catch(AssertionError e)
        {
            e.printStackTrace();
        }
    }
}
