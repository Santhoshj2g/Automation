package com.dnb.automation.bd.pages;

import java.util.List;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dnb.automation.utils.UIHelper;

/******************************************************************************************************
 * Description : UserMyAccountPage class contains locators and methods for User MyAccount page
 
 *******************************************************************************************************/
public class UserMyAccountPage extends PageObject{

	@FindBy(xpath = "//li[@aria-labelledby='ui-id-2']")
    private WebElementFacade tabConnectionsClass;

	@FindBy(xpath = "//*[@id='ui-id-2']")
    private WebElementFacade tabConnections;

	@FindBy(xpath = "//li[@aria-labelledby='ui-id-1']")
    private WebElementFacade tabCompanyProfileClass;
	
	@FindBy(xpath = "//*[@id='ui-id-1']")
    private WebElementFacade tabCompanyProfile;
	
	@FindBy(xpath = "//tbody[@id='connectionPflist']/div[@class='loadmask-msg']/div")	
	private WebElementFacade imgLoading;

	@FindBy(xpath = "//*[@id='secondone']/div/a[@title='Previous ']/img")	
	private WebElementFacade imgPrevious_Received;

	@FindBy(xpath = "//*[@id='flat-tabs-4']//a[@title='Previous ']/img")	
	private WebElementFacade imgPrevious_Sent;
	
	@FindBy(xpath = "//*[@id='secondone']/div/a[@title='Next']/img")	
	private WebElementFacade imgNext_Received;

	@FindBy(xpath = ".//*[@id='flat-tabs-4']/div/div[4]/div/a[@title='Next']/img")	
	private WebElementFacade imgNext_Sent;

	@FindBy(xpath = "//*[@id='secondone']/div/a[@title='Next']")	
	private WebElementFacade imgNextClass_Received;

	@FindBy(xpath = ".//*[@id='flat-tabs-4']/div/div[4]/div/a[@title='Next']")	
	private WebElementFacade imgNextClass_Sent;	

	@FindBy(xpath = "//*[@id='user-profile-users-result']/div/a[@title='Next']/img")	
	private WebElementFacade imgNext_ProfileUsers;

	@FindBy(xpath = "//*[@id='user-profile-users-result']/div/a[@title='Next']")	
	private WebElementFacade imgNextClass_ProfileUsers;

	@FindBy(xpath = "//table[@id='pagerReceived']/tbody/tr/td/input[@class='conn-company-name']")	
	private List<WebElementFacade> companyName;
	
	@FindBy(xpath = "//a[@id='profileUsers']")	
	private WebElementFacade profileUserstab;	
	
	@FindBy(xpath = "//table[@id='user-profile-table-id']/thead/tr/th")	
	private List<WebElementFacade> headerFields;
	
	@FindBy(xpath = "//a[@id='addUser']")	
	private WebElementFacade addUserBtn;	
	
	@FindBy(xpath = "//input[@id='newEnteredEmailId']")	
	private WebElementFacade newUsrId;
	
	@FindBy(xpath = "//a[@class='saveandedit']/img")	
	private WebElementFacade saveBtn;
	
	@FindBy(xpath = "//input[@id='editrightid']")	
	private WebElementFacade editRightsBtn;
	
	@FindBy(xpath = "//span[contains(text(),'Submit Changes')]")	
	private WebElementFacade submitBtn;
	
	@FindBy(xpath = "//div[@id='showSuccessError']")	
	private WebElementFacade successMsg;
	
	@FindBy(xpath = "//img[@class='closePflUserDetailsEdit']")	
	private WebElementFacade btnClose;
	
	@FindBy(xpath = "html/body/div[5]/div[1]/div/div/div[4]/div[3]/div[3]/div[4]/table/tbody/tr/td")	
	private List<WebElementFacade> profileUsrsFrame;
	
	public int i,rowNum,rowNum1,totalusr;
	public String usercountval,usercountval1,usrname,usrname1;
	
	@FindBy(xpath = "//table[@id='editPflUserTable']/tbody/tr/td")	
	private List<WebElementFacade> secondaryUsrFrame;	

	@FindBy(xpath = "//input[@type='radio']")	
	private List<WebElementFacade> radioBtn;
	
	@FindBy(xpath = "//input[@id='editrightid']")	
	private List<WebElementFacade> editradioBtn;	
	
	@FindBy(xpath = "//input[@id='connectrifht']")	
	private List<WebElementFacade> connectReqBtn;
	
	@FindBy(xpath = "//img[@id='deletedUsers']")	
	private List<WebElementFacade>  deleteUsr;
	
	@FindBy(xpath = "//div[@id='warning_pfl_deletet']//span[@id='rejectButton']/a")	
	private WebElementFacade BtnYes;	
	
	@FindBy(xpath = "//input[@checked='checked']")	
	private WebElementFacade radioBtnChecked;
	
	
	
	
	
	
	
	
	
	
// This block of strings are used to construct the dynamic xpath for connect profiles
	public String tableReceived = "//table[@id='pagerReceived']/tbody/tr";
	public String tableProfileUsers = "//table[@id='user-profile-table-id']/tbody/tr";	
	public String tableSent = "//table[@id='pagerSent']/tbody/tr";
	public String tableReceivedpart ="//*[@id='connectionPflist']/tr[";
	public String tableProfileUsersPart1 ="//*[@id='user-profile-container']/tr[";
	public String tableSentpart ="//*[@id='connectionSentPflist']/tr[";
	public String inviteRec_CompName = "]/td[2]";
	public String profileUsers_CompName = "]/td[1]";
	public String inviteRec_CompStatus = "]/td[4]";
	public String inviteSent_CompName = "]/td[2]";
	public String inviteSent_CompStatus = "]/td[5]";
	public String btnDelete = "]//img[@title='Delete']";
	public String btnReject = "]//img[@title='Reject']";
	public String btnApprove = "]//img[@title='Approve']";
	public String profiletable = "//table[@id='user-profile-table-id']/tbody/tr/td";
	public String btnEdit = "//a[@class='profileUserEdit button']";
	public String  profileUsrsTable="//table[@id='user-profile-table-id']/tbody/tr/td";
	public String imgload="//div[@class='loadmask-msg']";
	
// block ends

	@FindBy(xpath = "//*[@id='connectionSentPflist']/tr[1]/td[2]")	
	private WebElementFacade InviteSentCompName;

	@FindBy(xpath = "//*[@id='connectionSentPflist']/tr[1]/td[5]")	
	private WebElementFacade InviteSentCompStatus;
		
	@FindBy(xpath = "//*[@id='confirmation_2']/center/a")	
	private WebElementFacade CancelDeleteConnectConfirmation;

	@FindBy(xpath = "//*[@id='rejectButton']/a")	
	private WebElementFacade OkDeleteConnectConfirmation;

	@FindBy(xpath = "//*[@id='warning_2']/center/a")	
	private WebElementFacade OkInformationMessage;

	@FindBy(xpath = "//*[@id='inviteSent']")	
	private WebElementFacade InvitesSent;

	@FindBy(xpath = "//*[@id='firstOne']")	
	private WebElementFacade InvitesReceived;
	
/***********************************************************************************
* Function: Select User Connections tab 
* Input : NA 
* Action : NA 
* Output : NA
***********************************************************************************/
	public String selectConnectionsTab()
	{
		if(tabConnections.isPresent())			
		{				
			if(tabConnectionsClass.getAttribute("aria-selected").equals("false"))				
			{				
				tabConnections.waitUntilClickable();
				tabConnections.click();
//				imgLoading.waitUntilVisible();				
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {					
					e.printStackTrace();
				}
				imgLoading.waitUntilNotVisible();
			}
		}
		return tabConnectionsClass.getAttribute("aria-selected");
	}

	/***********************************************************************************
	* Function: Select the profile and delete the connect request 
	* Input : Profile Name
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
	public boolean selectProfileConnectRequestAndDelete(String dbProfileName)
	{
		WebElement profileDelete = null;
		int rowNum = getProfileRowNum_Received(dbProfileName);
		profileDelete = getDriver().findElement(By.xpath(tableReceivedpart+rowNum+btnDelete));
		boolean prfDelete = false;
		if(rowNum>0)
		{
			profileDelete.click();	
			OkDeleteConnectConfirmation.waitUntilVisible();			
		}else
		{
			System.out.println("Profile is not available");
		}
		if(OkDeleteConnectConfirmation.isVisible())
		{			
			prfDelete = true;
		}
		return prfDelete;		
	}

	/***********************************************************************************
	* Function: Select the Invites Sent section 
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void selectInvitesSent()
	{
		InvitesSent.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/***********************************************************************************
	* Function: Select the Invites Received section 
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void selectInvitesReceived()
	{
		InvitesReceived.click();
		imgLoading.waitUntilNotVisible();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
		
	/***********************************************************************************
	* Function: verify the information box is displayed 
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public boolean isInformationBoxDisplayed()
	{
		return OkInformationMessage.isVisible();
	}

	/***********************************************************************************
	* Function: verify the delete confirmation is displayed 
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public boolean isDeleteConfirmationDisplayed()
	{
		return OkDeleteConnectConfirmation.isVisible();
	}
	
	/***********************************************************************************
	* Function: Accept the delete confirmation 
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void acceptDeleteConfirmation()
	{
		OkDeleteConnectConfirmation.click();
		OkInformationMessage.waitUntilVisible();
	}

	/***********************************************************************************
	* Function: Accept the Information Message box 
	* Input : NA
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void acceptInformationBox()
	{
		OkInformationMessage.click();
	}

	/***********************************************************************************
	* Function: Get the Profile Name from the invite Sent section 
	* Input : NA
	* Action : NA 
	* Output : Company Name
	***********************************************************************************/
	public String getInviteSentCompName()
	{
		return InviteSentCompName.getAttribute("title").trim();
	}
	
	/***********************************************************************************
	* Function: Get the Profile status from the invite Sent section 
	* Input : NA
	* Action : NA 
	* Output : Profile status
	***********************************************************************************/
	public String getInviteSentCompStatus()
	{
		return InviteSentCompStatus.getText().trim();
	}
	
	/***********************************************************************************
	* Function: Select the profile and reject the connect request 
	* Input : Profile Name
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
	public boolean selectProfileConnectRequestAndReject(String dbProfileName)
	{
		WebElement profileDelete = null;
		int rowNum = getProfileRowNum_Received(dbProfileName);
		profileDelete = getDriver().findElement(By.xpath(tableReceivedpart+rowNum+btnReject));
		boolean prfReject = false;
		if(rowNum>0)
		{
			profileDelete.click();	
			OkInformationMessage.waitUntilVisible();			
		}else
		{
			System.out.println("Profile is not available");
		}
		if(OkInformationMessage.isVisible())
		{			
			prfReject = true;
		}
		return prfReject;		
	}

	/***********************************************************************************
	* Function: Select the profile and approve the connect request 
	* Input : Profile Name
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
	public boolean selectProfileConnectRequestAndApprove(String dbProfileName)
	{
		WebElement profileDelete = null;
		int rowNum = getProfileRowNum_Received(dbProfileName);
		profileDelete = getDriver().findElement(By.xpath(tableReceivedpart+rowNum+btnApprove));
		boolean prfReject = false;
		if(rowNum>0)
		{
			profileDelete.click();	
			OkInformationMessage.waitUntilVisible();			
		}else
		{
			System.out.println("Profile is not available as pending in connect requests");
		}
		if(OkInformationMessage.isVisible())
		{			
			prfReject = true;
		}
		return prfReject;		
	}

	/***********************************************************************************
	* Function: Verify the profile status is pending in invite sent section 
	* Input : Profile Name
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
	public boolean isProfileStatusPendingInInviteSent(String dbProfileName)
	{		
		int rowNum = getProfileRowNum_Sent(dbProfileName);	
		if(rowNum>0)
		{
			return true;
		}else
		{
			return false;
		}
	}
	
	/***********************************************************************************
	* Function: Get the profile row num from the list of profile Users 
	* Input : Profile Name
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
	public int getProfileRowNum_ProfileUsers(String dbProfileName)
	{		
		WebElement profileName = null;
				
		String prflName = null;
		int i = 0;
		boolean prfFound = false;
		int rowCount = getDriver().findElements(By.xpath(tableProfileUsers)).size(); 
		for(i=1;i<=rowCount;i++)
		{			
			profileName = getDriver().findElement(By.xpath(tableProfileUsersPart1+i+profileUsers_CompName));						
			prflName = profileName.getAttribute("title").trim();
			if(prflName.equals(dbProfileName))
			{
				prfFound = true;
				break;
			}
			if(i%5 == 0)
			{
				if(imgNextClass_ProfileUsers.getAttribute("class").equalsIgnoreCase("next"))
				{
					imgNext_ProfileUsers.click();
				}else
				{
					break;
				}
				
			}
		}
		if(prfFound)
		{
			return i;
		}else
		{
			return 0;
		}
	}
	
	
	/***********************************************************************************
	* Function: Get the profile row num from the list of received connected profiles 
	* Input : Profile Name
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
	public int getProfileRowNum_Received(String dbProfileName)
	{
		WebElement profilestatus = null;
		WebElement profileName = null;
		
		String prflStatus = null;
		String prflName = null;
		int i = 0;
		boolean prfFound = false;
		int rowCount = getDriver().findElements(By.xpath(tableReceived)).size(); 
		for(i=1;i<=rowCount;i++)
		{
			profilestatus = getDriver().findElement(By.xpath(tableReceivedpart+i+inviteRec_CompStatus));
			profileName = getDriver().findElement(By.xpath(tableReceivedpart+i+inviteRec_CompName));			
			prflStatus = profilestatus.getText().trim();
			prflName = profileName.getAttribute("title").trim();
			if(prflStatus.equalsIgnoreCase("Pending") && prflName.equals(dbProfileName))
			{
				prfFound = true;
				break;
			}
			if(i%5 == 0)
			{
				if(imgNextClass_Received.getAttribute("class").equalsIgnoreCase("next"))
				{
					imgNext_Received.click();
				}else
				{
					break;
				}
				
			}
		}
		if(prfFound)
		{
			return i;
		}else
		{
			return 0;
		}
	}

	/***********************************************************************************
	* Function: Get the pending profile row num from the list of sent connected profiles 
	* Input : Profile Name
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
	public int getProfileRowNum_Sent(String dbProfileName)
	{
		WebElement profilestatus = null;
		WebElement profileName = null;
		
		String prflStatus = null;
		String prflName = null;
		int i = 0;
		boolean prfFound = false;
		int rowCount = getDriver().findElements(By.xpath(tableSent)).size(); 
		for(i=1;i<=rowCount;i++)
		{
			profilestatus = getDriver().findElement(By.xpath(tableSentpart+i+inviteSent_CompStatus));
			profileName = getDriver().findElement(By.xpath(tableSentpart+i+inviteSent_CompName));			
			prflStatus = profilestatus.getText().trim();
			prflName = profileName.getAttribute("title").trim();			
			if(prflStatus.equalsIgnoreCase("Pending") && prflName.equals(dbProfileName))
			{
				prfFound = true;
				break;
			}
			if(i%5 == 0)
			{
				if(imgNextClass_Sent.getAttribute("class").equalsIgnoreCase("next"))
				{
					imgNext_Sent.click();
				}else
				{
					break;
				}
				
			}
		}
		if(prfFound)
		{
			return i;
		}else
		{
			return 0;
		}
	}

	/***********************************************************************************
	* Function: Select User Company profile tab 
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
		public String selectCompanyProfileTab()
		{
			if(tabCompanyProfile.isPresent())			
			{				
				if(tabCompanyProfileClass.getAttribute("aria-selected").equals("false"))				
				{				
					tabCompanyProfile.waitUntilClickable();
					tabCompanyProfile.click();
//					imgLoading.waitUntilVisible();				
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {					
						e.printStackTrace();
					}
					imgLoading.waitUntilNotVisible();
				}
			}
			return tabCompanyProfileClass.getAttribute("aria-selected");
		}
		
		
		/***********************************************************************************
		* Function: To click the Profile Users tab under My Account
		* Input : NA 
		* Action : NA 
		* Output : NA
		***********************************************************************************/
	public boolean clickProfileUsers()
	{
		if (profileUserstab.isPresent())
		{
			profileUserstab.click();
			UIHelper.waitForPageToLoad(getDriver());
			return true;
		}else
		{
			return false;
		}
	}
	
	/***********************************************************************************
	* Function: To verify the Company Name
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void verifyCompanyName()
	{
		int fieldsize=headerFields.size();
//		System.out.println(fieldsize);
		for (int i=0;i<fieldsize;i++)
		{
			String fieldname=headerFields.get(i).getText();
//			System.out.println(fieldname);
		}
	}
	
	
	/***********************************************************************************
	* Function: To get the Profile Name form database using Duns No
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void selectProfile(String dbProfileName)
	{	
		WebElement profile1 = null;
		rowNum = getProfileRowNum_ProfileUsers(dbProfileName);
//		System.out.println("Db profile Name is"+dbProfileName);
//		System.out.println("row num is"+rowNum);
		rowNum1=rowNum+1;
//		System.out.println(rowNum1);
		profile1=getDriver().findElement(By.xpath("//table[@id='user-profile-table-id']/tbody/tr["+rowNum+"]/td[1]"));
//		System.out.println("profile id is"+profile1);		
//		System.out.println("profile is selected");
		WebElement editBtn=getDriver().findElement(By.xpath("//table[@id='user-profile-table-id']/tbody/tr["+rowNum+"]/td[6]/a[2]"));
		editBtn.click();
		waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgload);
		addUserBtn.waitUntilEnabled();
//		UIHelper.waitForPageToLoad(getDriver());
//		System.out.println("Edit button is clicked");		
	}
	
	/***********************************************************************************
	* Function: To click the Add Users button
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void clickAddUserBtn()
	{
		addUserBtn.click();	
//		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgload);
	}
	
	/***********************************************************************************
	* Function: To enter new User details
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void enterNewUser(String emailid)
	{
		newUsrId.click();
		newUsrId.clear();
		newUsrId.sendKeys(emailid);
	}
	
	/***********************************************************************************
	* Function: To add a new secondary User
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void addNewUser(String emailid1)
	{
		newUsrId.click();
		newUsrId.clear();
		newUsrId.sendKeys(emailid1);
	}	 
	
	/***********************************************************************************
	* Function: To click the Save button 
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void clickSaveBtn()
	{
		saveBtn.click();
		waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgload);		
		//UIHelper.waitForPageToLoad(getDriver());
	}
	
	/***********************************************************************************
	* Function: To select the Edit Rights button
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void selectEditRightsBtn()	
	{
		editRightsBtn.click();
	}
	
	/***********************************************************************************
	* Function: To click the Submit button
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void clickSubmitBtn()
	{
		submitBtn.click();
		waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgload);							
	}
	
	/***********************************************************************************
	* Function: To capture the success Message displayed in Add Users pop up
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void verifyMsg()
	{
		if(successMsg.isPresent())
		{
			String msg=successMsg.getText();
//			System.out.println(msg);			
		}
	}
	
	/***********************************************************************************
	* Function: To close the Add Users pop up 
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void closePopUp()
	{
		btnClose.click();
		UIHelper.waitForPageToLoad(getDriver());
	}
	
	/***********************************************************************************
	* Function: To get the User Count value
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public String getUserCnt(String dbProfileName)
	{
//		System.out.println(dbProfileName);
//		System.out.println(rowNum1);
		WebElement usrCount = getDriver().findElement(By.xpath("//table[@id='user-profile-table-id']/tbody/tr["+rowNum+"]/td[5]"));
		usercountval=usrCount.getText();
//		System.out.println("first count is"+usercountval);		
		return usercountval;		
	}
	
	/***********************************************************************************
	* Function: To get the Secondary user Count value
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public String SecondaryUsrCnt(String dbProfileName)
	{
//		System.out.println(dbProfileName);
//		System.out.println(rowNum1);
		WebElement usrCount = getDriver().findElement(By.xpath("//table[@id='user-profile-table-id']/tbody/tr["+rowNum+"]/td[5]"));
		usercountval1=usrCount.getText();
//		System.out.println("first count is"+usercountval1);		
		return usercountval1;		
	}
	/***********************************************************************************
	* Function: To verify the User count value
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public boolean verifyUsrCnt()
	{
//		System.out.println(usercountval);
		/*WebElement userCountfld=getDriver().findElement(By.xpath("html/body/div[5]/div[1]/div/div/div[4]/div[3]/div[3]/div[4]/table/tbody/tr["+rowNum1+"]/td[5]"));
		userCountfld.click();
		userCountval1=userCountfld.getText();*/
//		System.out.println("Second count is"+usercountval1);	
		if(usercountval1.equals(usercountval))
		{
//			System.out.println("User Count value is not increased");
			return false;
		}else
		{
			System.out.println("User Count value is increased");
			return true;
		}
	}
	
	/***********************************************************************************
	* Function: To get the User Type value 
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public boolean getUserType()
	{
		WebElement usertype=getDriver().findElement(By.xpath("html/body/div[5]/div[1]/div/div/div[4]/div[3]/div[3]/div[4]/table/tbody/tr["+rowNum1+"]/td[4]"));
		usertype.click();
		String userTypeval=usertype.getText();
//		System.out.println(userTypeval);
		if (userTypeval.equalsIgnoreCase("Primary"))
		{
			System.out.println("This user is primary user of this company");
			return true;
		}else
		{
			System.out.println("This user is secondary user of this company");
			return false;
		}
	}
	
	/***********************************************************************************
	* Function: To verify the Edit Button status
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void verifyEditBtn()
	{
//		System.out.println(rowNum1);
		WebElement editBtn=getDriver().findElement(By.xpath("html/body/div[5]/div[1]/div/div/div[4]/div[3]/div[3]/div[4]/table/tbody/tr["+rowNum1+"]/td[6]/a[@class='profileUserEdit button']"));		
		if(editBtn.isEnabled())
			{
			System.out.println("Edit button is enabled");			
			}else
			{
				System.out.println("Edit button is not enabled");
			}
		
		String editBtnStatus=editBtn.getText();
//		System.out.println("The edit button status is"+editBtnStatus);			
	}
	
	/***********************************************************************************
	* Function: To verify the Edit button status of Secondary User
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void secUsrEditBtn()
	{
//		System.out.println(rowNum1);
		
		WebElement editBtn=getDriver().findElement(By.xpath("html/body/div[5]/div[1]/div/div/div[4]/div[3]/div[3]/div[4]/table/tbody/tr["+rowNum1+"]/td[6]/a[2][@class='secondar-user button tip-gray']"));		
		if(editBtn.isDisplayed())
			{
			System.out.println("Edit button is disabled");			
			}else
			{
				System.out.println("Edit button is not enabled");
			}		
		String editBtnStatus=editBtn.getText();
		System.out.println("The edit button status is"+editBtnStatus);
	}
	/*public void SecondaryUsrDetails()
	{
		int frmsize=secondaryUsrFrame.size();
		System.out.println(frmsize);
		for(int j=0;j<frmsize;j++)
		{
			String framecontents=secondaryUsrFrame.get(j).getText();
			System.out.println(framecontents);
		}		
	}*/
	
	
	/***********************************************************************************
	* Function: To provide Edit Rights to Secondary User 
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public boolean verifyEditRights()
	{
		int editBtnselected=0;
		int editbtnSize=editradioBtn.size();
//		System.out.println(editbtnSize);
		for (int k=0;k<editbtnSize;k++)
		{
			boolean status=editradioBtn.get(k).isSelected();
//			System.out.println(status);	
			if(status=true)
			{
//				System.out.println(k);
				editradioBtn.get(k+1).click();	
				break;
			}else if(status=true && k==editbtnSize)
			{
//				System.out.println(k);
				editradioBtn.get(k-1).click();	
				break;
			}
		}
		System.out.println("Selecting radio button is completed");
		for(int k=0;k<editbtnSize;k++)
		{
			boolean radiobtnstatus=editradioBtn.get(k).isSelected();			
//			System.out.println(radiobtnstatus);
			usrname=editradioBtn.get(k).getTextValue();
//			System.out.println(usrname);
			if(radiobtnstatus==true)
			{
//				System.out.println(editBtnselected);
				editBtnselected=editBtnselected+1;
			}
//			System.out.println(editBtnselected);			
		}
		if(editBtnselected==1)
		{
			System.out.println("Primary User assigned Edit rights to only one secondary user");
			return true;
		}
		else
		{
			System.out.println("Primary User assigned Edit rights to more than one secondary user");
			return false;
		}				
	}
	
	
	/***********************************************************************************
	* Function: To verify the Connect recipient rights of Secondary User
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public boolean verifyConnectRequest()
	{
		int connectBtnselected=0;
		int connectBtnSize=connectReqBtn.size();
//		System.out.println(connectBtnSize);
		for(int k=0;k<connectBtnSize;k++)
		{
			boolean connectBtnstatus=connectReqBtn.get(k).isSelected();
			if(connectBtnstatus == false)
			{
				connectReqBtn.get(k).click();	
			}
//			System.out.println(connectBtnstatus);			
			/*if(connectBtnstatus==true && k==connectBtnSize)
			{
				System.out.println(k);
				connectReqBtn.get(k-1).click();	
				break;
			}else if(connectBtnstatus==true)
			{
				System.out.println(k);
				connectReqBtn.get(k+1).click();	
				break;
			}*/			
		}
//		System.out.println("Test1..Entering second loop");
		for(int k=0;k<connectBtnSize;k++)
		{
			boolean connectradiobtnstatus=connectReqBtn.get(k).isSelected();
//			System.out.println(connectradiobtnstatus);
			usrname1=connectReqBtn.get(k).getText();
//			System.out.println(usrname1);
			if(connectradiobtnstatus==true)
			{
				connectBtnselected=connectBtnselected+1;
			}
//			System.out.println("Test2.."+connectBtnselected);			
		}
		if(connectBtnselected==1)
		{
			System.out.println("Primary User assigned Connect request to only one secondary user");
			return true;
		}
		else
		{
			System.out.println("Primary User assigned connect request to more than one secondary user");
			return false;
		}	
		
	}
	
	/***********************************************************************************
	* Function: To provide Connect recipient rights to secondary user
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void clickConnectRecipient()
	{
		WebElement connectRecipientBtn=getDriver().findElement(By.xpath("html/body/div[5]/div[1]/div/div/div[4]/div[3]/div[3]/div[3]/div[3]/div[2]/div[2]/table/tbody/tr[3]/td[4]/input"));
		connectRecipientBtn.click();
	}
	/***********************************************************************************
	* Function: To get the Secondary User details
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void getdetails()
	{
		int size=secondaryUsrFrame.size();
		int BtnCnt=0;
//		System.out.println(size);
		for (int k=0;k<size;k++)
		{
			String rowdetail=secondaryUsrFrame.get(k).getText();
//			System.out.println("rowdetail is"+rowdetail);
			if(radioBtnChecked.isPresent())
			{
				BtnCnt=BtnCnt+1;
//				System.out.println("radio Button is checked");
//				System.out.println(k);
			}
		}
		
	}
	
	/***********************************************************************************
	* Function: To delete the Secondary User
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	public void deleteUser()
	{
		totalusr=deleteUsr.size();
//		System.out.println(totalusr);
		if(totalusr==0)
		{
			System.out.println("No existing Secondary User");
		}else
		{
		for(int i=0;i<totalusr;i++)
		{
//			System.out.println("entered for loop");
			String img=deleteUsr.get(i).getText();
//			System.out.println(img);		
			deleteUsr.get(i).click();
			if(BtnYes.isPresent())
			{
//				BtnYes.submit();
				BtnYes.click();	
				//UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgload);	
			}
//			System.out.println("User/Users deleted successfully");			
		}
		}	
		if(totalusr!=0)
		{
			submitBtn.click();
			waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgload);	
		}		
	}
	
	/***********************************************************************************
	* Function: Wait for Invisibility of Ajax control
	* Input : NA 
	* Action : NA 
	* Output : NA
	***********************************************************************************/
	
    public void waitForInvisibilityOfAjaxImgByXpath(
            final WebDriver driver, final String ajaxElementxpath) {

        try {
            WebDriverWait wait = new WebDriverWait(driver, 6);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By
                    .xpath(ajaxElementxpath)));
        } catch (Exception e) {

        }
    }

	
	
	
}
