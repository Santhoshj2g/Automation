package com.dnb.automation.dnbi.pages;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;
import com.google.common.base.Predicate;
import com.thoughtworks.selenium.webdriven.commands.WaitForPageToLoad;
import com.dnb.automation.dnbi.pages.InternalOCAVerificationPage;
/**********************************************************************************************
 * 
 * 
 * @author Vamsi Krishna NV
 * @version 1.0
 ***********************************************************************************************/
public class ExternalOCAVerificationPage extends PageObject {
	InternalOCAVerificationPage internalOCA;
	EUECFPage reDecisionOCA;
	@FindBy(xpath = "//*[@class='container']//*[@class='cw_login_apply']//*[contains(.,'Apply for Credit')]")
	private WebElementFacade applyForCredit;
	
	@FindBy(xpath = "//*[@class='container']//*[@class='cw_main']//input[@value='Apply Now']")
    private WebElementFacade ApplyNow;
	
	@FindBy(xpath = "//*[@class='container']//*[@class='cfa-report-content']//h3")
    private WebElementFacade applaPgeHeader;
	
	@FindBy(xpath = "//*[@id='sectionWrap_TermsAndConditionsPage']//*[@class='cw_main']//*[@class='frmField ieField']//input[contains(@id,'Terms-and-Conditions-UserName')]")
	private WebElementFacade Name;
	
	@FindBy(xpath = "//*[@class='container']//*[@id='sectionWrap_TermsAndConditionsPage']//*[@class='frmField emailPanel']//input[contains(@id,'emailAddress')]")
	private WebElementFacade Email;
	
	@FindBy(xpath = "//*[@id='sectionWrap_TermsAndConditionsPage']//*[@class='cw_main']//table//tbody//tr//td//input[@name='signatureLabel1']")
	private WebElementFacade signature1;
	
	@FindBy(xpath = "//*[@id='sectionWrap_TermsAndConditionsPage']//*[@class='cw_main']//table//tbody//tr//td//input[@name='signatureTitle1']")
	private WebElementFacade signature2;
	
	@FindBy(xpath = "//*[@id='sectionWrap_TermsAndConditionsPage']//*[@class='cw_main']//h3[contains(.,'Terms and Conditions')]")
	private WebElementFacade termsPageHeader;
	
	@FindBy(xpath = "//*[@id='sectionWrap_TermsAndConditionsPage']//*[contains(@class,'frmField ieField')]  [contains(.,'I agree to the terms')]")
	private WebElementFacade agreeTermstext;
	
	@FindBy(xpath = "//*[@id='sectionWrap_TermsAndConditionsPage']//*[contains(@class,'frmField ieField')]  [contains(.,'I agree to the terms')]//input")
	private WebElementFacade agreeTermsCheckBox;
	
	@FindBy(xpath = "//*[@id='page_titleNew']/h2")
	private WebElementFacade thanksPageHeading;
	
	@FindBy(xpath = "//*[@class='cw_main']//*[@id='thankYouMsg']//p")
	private WebElementFacade thanksMessage;
	
	@FindBy(xpath = "//div[@id='widget_container']//div[@class='reviewStatus']//span[1][contains(.,'Approved')]")
	private WebElementFacade status;
	
	@FindBy(xpath = "//*[@class='cw_main']//input[@value='Finish']")
	private WebElementFacade finishBtn;

	@FindBy(xpath = "//*[@id='main']//*[@id='srcRecordList']/tbody")
	private WebElementFacade applicationNameList;
	
	@FindBy(xpath = "//*[@class='cw_main']//strong[contains(.,'Application ID')]//ancestor::span[1]//following-sibling::span[1]")
	private WebElementFacade applicationID;
	
	@FindBy(xpath = "//*[@class='cw_main']//strong[contains(.,'E-Mail ID')]//ancestor::span[1]//following-sibling::span[1]")
	private WebElementFacade emailID;
	
	@FindBy(xpath = "//*[contains(@id,'ecf_toc')]//a[contains(.,'Online Credit Application')]")
	public WebElementFacade onlineCreditApplicationLink;
	
	@FindBy(xpath = "//*[@class='widget_form']//*[@id='fqForm1']//table//tbody//tr[1]//td[1]//input[@type='radio']")
	private WebElementFacade dbSearchResults1;
	@FindBy(xpath = "//*[@class='widget_form']//*[@class='bureau_list']//input[@type='radio']")
	private WebElementFacade dbSearchResults;
	
	
	@FindBy(xpath = "//*[@class='container']//*[@class='cfa-report-content']//h3[contains(.,'Company Identification')]")
	private WebElementFacade headerCID;
	
	@FindBy(xpath = "//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'Company Identification')]")
	private WebElementFacade subHeaderCID;
	
	@FindBy(xpath = "//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'Company Identification')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'Business Name')]//following-sibling::td[contains(@class, 'frmField')]//input[contains(@class, 'regular')]")
	private WebElementFacade businessNameField;
	
	@FindBy(xpath = "//*[@class='cfa-report-content']//*[@id='entityWorkItemForm']//div//*[contains(.,'Company Identification')]//ancestor::div[1]//following-sibling::div//input[contains(@value,'Re-Submit Search')]")
	private WebElementFacade resubmitBtn;
	
	@FindBy(xpath = "//*[@class='widget_form']//*[@class='bureau_list']//input[@type='radio']//ancestor::div[@class='widget_form']//following-sibling::div[@class='load-next-section-wrap clearfix']//input[@type='button']")
	private WebElementFacade dBLoadnextBtn;
	
		
	@FindBy(xpath = "//*[@class='container']//*[@class='cfa-report-content']//h5")
	private List<WebElementFacade> headers;
	
	@FindBy(xpath = "//*[contains(@id,'fin_tab1')]//table[contains(@class,'results full tab_borde')]//tbody//tr//a[contains(.,'View')]")
	private WebElementFacade financialViewLink;
	
	@FindBy(xpath = "//*[@id='main']//*[@id='pageHead']//h2[contains(.,'Financial View')]")
	private WebElementFacade finHeaderElement;
	
	@FindBy(xpath = "//*[@class='container']//*[contains(@class,'letterhead-container')]")
	private WebElementFacade lTTextAllignment;
	
	@FindBy(xpath = "//*[@class='container']//*[contains(@class,'letterhead-container')]//*[@id='letterHeadVal']")
	private WebElementFacade lTText;
	
	@FindBy(xpath = "//*[@id='document']//ul[@class='pages']//li//div[contains(@class,'pdfFormField signature required')]")
	private WebElementFacade signatureclick;
	
	@FindBy(xpath = "//*[@id='document']//button[contains(.,'Start')]")
	private WebElementFacade startBtn;
	
	
	
	@FindBy(xpath = "//*[@id='document']//ul[@class='pages']//li//div[contains(@class,'pdfFormField text_field required')]//input[@name='echosign_email']")
	private WebElementFacade emailEchoSign;
	
	@FindBy(xpath = "//*[@id='mainContent']//div[@class='modal-content']//div[@class='signature-panel-inner']//div[@class='input-group signature-name-wrapper']//input")
	private WebElementFacade writeSignature;
	
	@FindBy(xpath = ".//*[@id='mainContent']//div[@class='modal-content']//div[@class='modal-header sign-panel-header']//ul//li//p[contains(.,'Type')]")
	private WebElementFacade typeclick;
	
	@FindBy(xpath = "//*[@id='mainContent']//div[@class='modal-content']//div[@class='modal-footer signature-footer']//*[@class='footer-buttons']//button[contains(.,'Apply')]")
	private WebElementFacade signatureApplyBtn;
	
	@FindBy(xpath = "//*[@id='contentSubHeader']//*[contains(@class,'agreement-name-container')]//p//span")
	private WebElementFacade pleaseSignText;
	
	@FindBy(xpath = "//*[@id='footer']//button[contains(.,'Click to sign')]")
	private WebElementFacade click_To_Sign_Text;
	
	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
	private WebElementFacade iFrameEle;
	
	@FindBy(xpath = "//div//iframe[contains(@src,'https://secure.na1.echosign.com/public')]")
	private WebElementFacade iFrameEle1;
	
	@FindBy(xpath = "//*[@id='calendar']//*[@id='content']//table")
	private WebElementFacade calendarwindowelement;
	
	@FindBy(xpath = "//*[@id='page_titleNew']//h2")
	private WebElementFacade findCompanyHeader;
	
	@FindBy(xpath = "//*[@class='widget_form']")
	private WebElementFacade widgetForm;
	
	@FindBy(xpath = "//*[@class='widget_form']//*[@id='fqForm1']//table")
	private WebElementFacade searchResultsTable;
	
	@FindBy(xpath = "//*[@class='widget_form']//*[@id='fqForm1']//table//thead")
	private WebElementFacade searchResultsTableColumnHeader;
	@FindBy(xpath = "//*[@id='main']//*[@class='DnBAddressAcc']//li[contains(@class, 'unmatchAcc')]//input[contains(@value, 'Match Company')]")
	private WebElementFacade matchcompanybtn;
	@FindBy(xpath = "//div[@class='modal-dialog']//div[@class='modal_content']//div[@class='modal_buttons']//input[@id='okAlertBtn']")
	private WebElementFacade submitaletproceed;
	@FindBy(xpath = "//*[@class='frmSecEdit']//tbody//tr//input[@id='loadNextReference']")
	private WebElementFacade nextreference;
	
	private String appID;
	public String getAppID() {
		return appID;
	}

	private String emailAddress;
	public String getEmailAddress() {
		return emailAddress;
	}
	private WebElementFacade verifyFieldName;
	private WebElementFacade enterconditionFieldName;
	public static String parentWindowId;
	public static String fullDate; 
	
	public static String getFullDate() {
		return fullDate;
	}
	String nextreferencecheck="//*[@class='frmSecEdit']//tbody//tr//input[@id='loadNextReference']";
String submitaletproceedcheck = "//div[@class='modal-dialog']//div[@class='modal_content']//div[@class='modal_buttons']//input[@id='okAlertBtn']";
	String applinamewidget="//*[@id='main']//*[@id='srcRecordList']/tbody";
    String applyOfCreditheading = "//*[@class='container']//*[@class='cw_login_apply']//*[contains(.,'Apply for Credit')]";
    String applHeader="//*[@class='container']//*[@class='cfa-report-content']";
    String editHeaderbtnCI="//*[@class='cfa-report-content']//*[@id='entityWorkItemForm']//div//*[contains(.,'Company Identification')]//ancestor::div[1]//following-sibling::div//input[contains(@value,'Edit Section')]";
    String editHeaderbtnCinf="//*[@class='cfa-report-content']//*[@id='entityWorkItemForm']//div//*[contains(.,'Company Information')]//ancestor::div[1]//following-sibling::div//input[contains(@value,'Edit Section')]";
    String submitXpath = "//*[@id='sectionWrap_TermsAndConditionsPage']//*[@id = 'saveApplication']";
    String signSubmitXpath = "//*[@id='sectionWrap_TermsAndConditionsPage']//*[@value='Sign and Submit Application']";
    String termsConditionspageHeader="//*[@id='sectionWrap_TermsAndConditionsPage']//*[@class='cw_main']//h3[contains(.,'Terms and Conditions')]";
    String thanksPageHeader="//*[@id='page_titleNew']/h2";
    String Ecf_Section_Header=".//*[@id='widget_container']//h3[contains(.,'Company Identification')]";
    String dbSearchTitleXpath="//*[@class='widget_form']//*[@id='fqForm1']";
    String fin_Header_Xpath="//*[@id='main']//*[@id='pageHead']//h2[contains(.,'Financial View')]";
    String pleseSignTextXpath="//*[@id='contentSubHeader']//*[contains(@class,'agreement-name-container')]//p//span";
    String framexpath="//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']";
    String calendarwindwoxpath="//*[@id='calendar']//*[@id='content']";
  String dnbSearchResults1 = "//*[@class='widget_form']//*[@id='fqForm1']//table//tbody//tr[1]//td[1]//input[@type='radio']";
  String agreetermsname = "//*[@id='sectionWrap_TermsAndConditionsPage']//*[@class='cw_main']//*[@class='frmField ieField']//input[contains(@id,'UserName')]";
  //String agreetermsemail = "//*[@class='container']//*[@id='sectionWrap_TermsAndConditionsPage']//*[@class='frmField emailPanel']//input";
    
	public void click_External_OCA_Name(String FileName) throws Exception{
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), applinamewidget);
		String filePath1 = System.getProperty("user.dir");
		String mypath=filePath1.replace(":", ":\\");
		String filePath = mypath+FileName;
		System.out.println("File Path============"+filePath);
		
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		try {
		    String line = br.readLine();
		    br.close();
		    System.out.println("application Name-----------------"+line);
		    if((getDriver()
					.findElement(
							By.xpath("//*[@id='srcRecordList']/tbody/*[@class='odd-row' or @class='even-row']/td[1][contains(text(),'"
									+ line.trim()
									+ "')]"))).isDisplayed()){
		    	 WebElement oCAName = (getDriver()
							.findElement(
									By.xpath("//*[@id='srcRecordList']/tbody/*[@class='odd-row' or @class='even-row']/td[1][contains(text(),'"
											+ line.trim()
											+ "')]//following-sibling::td[@class='leftAlign']//*[@class='linkDiv']//a")));
			
			UIHelper.highlightElement(getDriver(), oCAName);
			parentWindowId = getDriver().getWindowHandle();
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", oCAName);
			//oCAName.click();
			             
			

             Set s = getDriver().getWindowHandles();
             Iterator ite = s.iterator();
             while (ite.hasNext()) {
            	 System.out.println("inside while loop--------------------------");
                 String popupHandle = ite.next().toString();
                 if (!popupHandle.contains(parentWindowId)) {
                	 System.out.println("inside if loop-------------------------------------");
                	 getDriver().switchTo().window(popupHandle);
                	 System.out.println("window switched--------------------------------");
                	 UIHelper.waitForPageToLoad(getDriver());
                     UIHelper.waitForVisibilityOfEleByXpath(getDriver(),applyOfCreditheading);
                     UIHelper.highlightElement(getDriver(), applyForCredit);
                     System.out.println("waited for element---------------------");
                 }
             }
		    	
		    }
		   
		    
		} finally {
		    
		}
	}
	
	public boolean verify_External_Window(){
		if(applyForCredit.isVisible()){
			return true;
		}else{
			return false;
		}
		
	}
	public void click_ApplyNow_Btn() {
		ApplyNow.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), ApplyNow);
		ApplyNow.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), applHeader);
	}
	public boolean verify_External_Application_Page(){
		UIHelper.waitForPageToLoad(getDriver());
		if(applaPgeHeader.isVisible()){
			return true;
		}else{
			return false;
		}
		
	}
	public boolean findHeaderSectionName(String xlSectionName) {
		/*int headerCount=0;*/
String nextsectioname = "//*[@class='container']//*[@class='cfa-report-content']//h3[contains(.,'xlSectionName')]";
		
		if (nextsectioname.contains(xlSectionName)){
	
			}
		
		return true;
		/*waitFor(5000).milliseconds();
		for(WebElementFacade HeaderName : headers){
			System.out.println("names of sections ----------------------"+HeaderName.getText());
			if(HeaderName.getText().contains(xlSectionName)){
				headerCount=1;
				break;
				
			}else{
				headerCount=2;
		}
		}
		System.out.println("return value-----------------"+headerCount);
		if(headerCount==1){
			return true;
		}else{
			return false;
		}
		*//*if ((find(By.xpath("//*[@class='container']//*[@class='cfa-report-content']//h3[contains(.,'"
								+ xlSectionName + "')]"))).isPresent()) {

			WebElementFacade sectionHeadTitle = find(By.xpath("//*[@class='container']//*[@class='cfa-report-content']//h3[contains(.,'"
									+ xlSectionName + "')]"));
			

			UIHelper.highlightElement(getDriver(), sectionHeadTitle);
			return true;
		} else {
			return false;
		}*/
	}
	
	public boolean findHeaderSectionNameNotDisplayed(String xlSectionName) {
		
		/*int headerCount=0;*/
		String nextsectioname = "//*[@class='container']//*[@class='cfa-report-content']//h3[contains(.,'xlSectionName')]";
		
		if (nextsectioname != xlSectionName){
		return true;
			}
		
		return false;
		/*System.out.println("return value-----------------"+headerCount);
		if(headerCount==1){
			return true;
		}else{
			return false;
		}*/
		/*WebElementFacade sectionHeadTitle = find(By.xpath("//*[@class='container']//*[@class='cfa-report-content']//h3[contains(.,'"
				+ xlSectionName + "')]"));
if (!isPresent(getDriver(), sectionHeadTitle)){
			WebElementFacade sectionHeadTitle = find(By.xpath("//*[@class='container']//*[@class='cfa-report-content']//h3[contains(.,'"
									+ xlSectionName + "')]"));
			

			UIHelper.highlightElement(getDriver(), sectionHeadTitle);
			return true;
		} else {
			return false;
		}
		
		int headerCount=0;
		for(int i=0;i<=headers.size();i++){
			if(headers.contains(xlSectionName)){
				headerCount=1;
				break;
				
			}else{
				headerCount=2;
		}
		}
		System.out.println("return value-----------------"+headerCount);
		if(headerCount==1){
			return false;
		}else{
			return true;
		}*/
		
		/*if (!(Locatable(xpath("//*[@class='container']//*[@class='cfa-report-content']//h3[contains(.,'"
								+ xlSectionName + "')]"))).isPresent()) {*/
		
	}

	public boolean verifyFieldName(String xlSectionName, String xlFieldName) {
		if ((getDriver()
				.findElement(By
						.xpath("//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
								+ xlSectionName
								+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
								+ xlFieldName + "')]"))).isDisplayed()) {

			WebElement mandatoryfield = getDriver()
					.findElement(
							By.xpath("//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
									+ xlSectionName
									+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
									+ xlFieldName + "')]"));
			UIHelper.highlightElement(getDriver(), mandatoryfield);
			return true;
		} else {
			return false;
		}

	}

	public boolean findMandatoryField(String xlSectionName, String xlFieldName) {

		if ((getDriver()
				.findElement(By
						.xpath("//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
								+ xlSectionName
								+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
								+ xlFieldName
								+ "')]//following-sibling::b[contains(@class, 'required')]")))
				.isDisplayed()) {

			WebElement mandatoryfield = getDriver()
					.findElement(
							By.xpath("//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
									+ xlSectionName
									+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
									+ xlFieldName + "')]"));
			UIHelper.highlightElement(getDriver(), mandatoryfield);
			return true;
		} else {
			return false;
		}

	}
	public boolean findFieldName(String xlSectionName, String xlFieldName) {
		String fieldname="//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
				+ xlSectionName
				+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
				+ xlFieldName
				+ "')]";

			if((find(By.xpath(fieldname))).isPresent()){
				verifyFieldName=find(By.xpath(fieldname));
				UIHelper.mouseOveranElement(getDriver(), verifyFieldName);
				UIHelper.highlightElement(getDriver(), verifyFieldName);
				return true;
			}else{
				return false;
			}
	}
	
			public boolean modifiedFieldName(String xlSectionName, String xlFieldName) {
				String fieldname="//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
						+ xlSectionName
						+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
						+ xlFieldName
						+ "')]";

					if((find(By.xpath(fieldname))).isPresent()){
						verifyFieldName=find(By.xpath(fieldname));
						UIHelper.mouseOveranElement(getDriver(), verifyFieldName);
						UIHelper.highlightElement(getDriver(), verifyFieldName);
						return true;
					}else{
						return false;
					}
			
		/*if ((getDriver()
				.findElement(By
						.xpath("//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
								+ xlSectionName
								+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
								+ xlFieldName
								+ "')]")))
				.isDisplayed()) {

			WebElement mandatoryfield = getDriver()
					.findElement(
							By.xpath("//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
									+ xlSectionName
									+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
									+ xlFieldName + "')]"));
			UIHelper.highlightElement(getDriver(), mandatoryfield);
			return true;
		} else {
			return false;
		}*/

	}
	
	public void Enter_Data_Into_Text_Fields(String Value,
			String xlFieldName, String xlSectionName) {

		if ((getDriver()
				.findElement(By
						.xpath("//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
								+ xlSectionName
								+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
								+ xlFieldName + "')]"))).isDisplayed()) {

			WebElement textfield = getDriver()
					.findElement(
							By.xpath("//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
									+ xlSectionName
									+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
									+ xlFieldName
									+ "')]//following-sibling::td[contains(@class, 'frmField')]//input[contains(@class, 'regular')]"));
			UIHelper.mouseOveranElement(getDriver(), textfield);
			textfield.clear();
			textfield.sendKeys(Value.trim());
		}
	}
	public boolean verifyexternalocaFieldName(String xlSectionName,
			String xlFieldName) {
		if ((getDriver()
				.findElement(By
						.xpath("//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
								+ xlSectionName
								+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
								+ xlFieldName + "')]"))).isDisplayed()) {

			WebElement fieldname = getDriver()
					.findElement(
							By.xpath("//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
									+ xlSectionName
									+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
									+ xlFieldName + "')]"));

			UIHelper.highlightElement(getDriver(), fieldname);
			return true;
		} else {
			return false;
		}

	}
	public void select_Data_For_List_Fields(String xlSectionName,
			String xlFieldName, String Value) {

		if ((getDriver()
				.findElement(By
						.xpath("//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
								+ xlSectionName
								+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
								+ xlFieldName + "')]"))).isDisplayed()) {

			WebElement selectField = getDriver()
					.findElement(
							By.xpath("//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
									+ xlSectionName
									+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
									+ xlFieldName
									+ "')]//following-sibling::td[contains(@class, 'frmField')]//select"));

			Select selectElement = new Select(selectField);
			selectElement.selectByVisibleText(Value.trim());
		}
	}

	public void click_Load_Next_Btn(String SectionName) {

		WebElement loadNextEle = getDriver()
				.findElement(
						By.xpath("//*[@class='cfa-report-content']//*[@id='entityWorkItemForm']//div//*[contains(text(),'"
								+ SectionName
								+ "')]//ancestor::div[1]//following-sibling::div//input[contains(@value,'Load Next Section')]"));

		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", loadNextEle);
		UIHelper.highlightElement(getDriver(), loadNextEle);
		loadNextEle.click();
		waitFor(10000).milliseconds();
		/*
		 * String editHeaderbtnCI =
		 * "//*[@class='cfa-report-content']//*[@id='entityWorkItemForm']//div//*[contains(.,'"
		 * + SectionName +
		 * "')]//ancestor::div[1]//following-sibling::div//input[contains(@value,'Edit Section')]"
		 * ; UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
		 * editHeaderbtnCI);
		 */
	}
	
	public void DB_click_Load_Next_Btn(String SectionName) {

		WebElement loadNextEle = getDriver()
				.findElement(
						By.xpath("//*[@class='cfa-report-content']//*[@id='entityWorkItemForm']//div//*[contains(text(),'"
								+ SectionName
								+ "')]//ancestor::div[1]//following-sibling::div//input[contains(@value,'Load Next Section')]"));

		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", loadNextEle);
		UIHelper.highlightElement(getDriver(), loadNextEle);
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", loadNextEle);

	}
	
	public void click_Re_Submit_Search_Btn(String SectionName) {
waitFor(resubmitBtn);
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", resubmitBtn);
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", resubmitBtn);
		//UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), "//*[@id='page_titleNew']/h2");
		waitFor(15000).milliseconds();
		System.out.println("waited for time----------------------------");
		if(dbSearchResults.isVisible()){
			System.out.println("searh results displayed----------------------------");
			UIHelper.mouseOveranElement(getDriver(), dbSearchResults);
			//dbSearchResults.click();
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", dbSearchResults);
			if(dBLoadnextBtn.isPresent()){
				dBLoadnextBtn.click();
			}
			
			
		}
		
	}
	
	public void click_Edit_Section_Btn(String SectionName) {

		WebElementFacade EditBtn = find(By
				.xpath("//*[@class='cfa-report-content']//*[@id='entityWorkItemForm']//div//*[contains(.,'"
						+ SectionName
						+ "')]//ancestor::div[1]//following-sibling::div//input[contains(@value,'Edit Section')]"));

		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", EditBtn);
		UIHelper.highlightElement(getDriver(), EditBtn);
		EditBtn.click();
		waitFor(7000).milliseconds();
		/*
		 * String loadnextbtnCI =
		 * "//*[@class='cfa-report-content']//*[@id='entityWorkItemForm']//div//*[contains(.,'"
		 * + SectionName +
		 * "')]//ancestor::div[1]//following-sibling::div//input[contains(@value,'Load Next Section')]"
		 * ; UIHelper.waitForVisibilityOfEleByXpath(getDriver(), loadnextbtnCI);
		 */
	}

	public void enterNameAndEmail(String name, String email) {
	    Name.isDisplayed();
	    	UIHelper.highlightElement(getDriver(), Name);
	    Name.sendKeys(name);
  Email.isDisplayed();
	    	UIHelper.highlightElement(getDriver(), Email);
	    	Email.sendKeys(email);
	    }
	public void enterNameAndEmailaftersave(String name, String email) {

	    try
	    {
	    	Name.isDisplayed();
	    	JavascriptExecutor javascript = (JavascriptExecutor) getDriver();
	    	String toenable = "document.getElementsByName('Name')[0].removeAttribute('disabled');";
	    	  javascript.executeScript(toenable);
	    	  Thread.sleep(3000);
	    	  ((JavascriptExecutor) getDriver()).executeScript(
		  				"arguments[0].scrollIntoView(true);", Name);
	    	  UIHelper.highlightElement(getDriver(), Name);
	    	  Name.sendKeys(name);
	    }catch(Exception e){
			e.printStackTrace();
	    }try{
	    	Email.isDisplayed();
	    	JavascriptExecutor javascript = (JavascriptExecutor) getDriver();
	    	String emailtoenable = "document.getElementsByName('Email')[0].removeAttribute('disabled');";
	    	  javascript.executeScript(emailtoenable);
	    	  Thread.sleep(3000);
	    	  ((JavascriptExecutor) getDriver()).executeScript(
		  				"arguments[0].scrollIntoView(true);", Email);
	    	  UIHelper.highlightElement(getDriver(), Email);
	    	  Email.sendKeys(email);
	    }catch(Exception e){
			e.printStackTrace();
	    }
	    }
	public void WriteSignatures(String sign1, String sign2) {
		
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", signature1);
	    UIHelper.highlightElement(getDriver(), signature1);
	    signature1.sendKeys(sign1);
	    UIHelper.highlightElement(getDriver(), signature2);
	    signature2.sendKeys(sign2);
	        
	    }
public void select_Agree_Terms_Checkbox() {
	waitFor(2000).milliseconds();
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", agreeTermstext);
	    UIHelper.highlightElement(getDriver(), agreeTermstext);
	    if(!agreeTermsCheckBox.isSelected()){
	    	agreeTermsCheckBox.click();
	    	waitFor(1000).milliseconds();
	    }
	        
	    }
	
	public void submitbtnclick() {

		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), submitXpath);
		WebElement submitbtn = getDriver()
				.findElement(By
						.xpath("//*[@id='sectionWrap_TermsAndConditionsPage']//*[@id = 'saveApplication']"));
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", submitbtn);
		UIHelper.highlightElement(getDriver(), submitbtn);
		submitbtn.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), thanksPageHeader);
		

	}
	public void submitbtnclickaftersave() {

		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), submitXpath);
		WebElement submitbtn = getDriver()
				.findElement(By
						.xpath("//*[@id='sectionWrap_TermsAndConditionsPage']//*[@id = 'saveApplication']"));
		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", submitbtn);
		UIHelper.highlightElement(getDriver(), submitbtn);
		submitbtn.click();
		//getDriver().switchTo().frame(iFrameEle);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), submitaletproceedcheck);
		submitaletproceed.click();
		//getDriver().switchTo().defaultContent();

	}
	
	
	public boolean thankYouPageHasDisplayed(){
		if(thanksPageHeading.isVisible()){
			UIHelper.highlightElement(getDriver(), thanksPageHeading);
			return true;
		}else{
			return false;
		}
		
	}
public void getApplicationIDAndEmailID(String FileName)  throws Exception{
	try{
	if(applicationID.isVisible()){
		UIHelper.highlightElement(getDriver(), applicationID);
		appID=applicationID.getText();
		System.out.println("application id-------"+appID);
		String filePath1 = System.getProperty("user.dir");
		String mypath=filePath1.replace(":", ":\\");
		String filePath = mypath+FileName;
		System.out.println("File Path============"+filePath);
		 // String filePath = System.getProperty("user.dir")+"\\src\\test\\resources\\OCA\\applicationID.txt";
	       // FileWriter fstreamWrite = new FileWriter(filePath, true); //-- it will not over write
	         FileWriter fstreamWrite = new FileWriter(filePath, false); //-- it will  over write
	         BufferedWriter out = new BufferedWriter(fstreamWrite);
	         out.write(appID);
	         out.write("\r\n");
	         out.close();
	         fstreamWrite.close();
		
	}
	/*if(emailID.isVisible()){
		UIHelper.highlightElement(getDriver(), emailID);
		 emailAddress=emailID.getText();
		
	}*/
	} finally {
	    
	}
}
	public void finishBtnclick() {
		try{

		if (finishBtn.isVisible()) {
			UIHelper.highlightElement(getDriver(), finishBtn);
			finishBtn.click();
			waitFor(7000).milliseconds();
		}
		swithch_To_ParentWindow();
		}catch(Exception e){
			e.printStackTrace();
		}
			
		
	}

	public void swithch_To_ParentWindow() {
		Set s = getDriver().getWindowHandles();
		Iterator ite = s.iterator();
		while (ite.hasNext()) {
			System.out
					.println("inside finsih button while loop--------------------------");
			String popupHandle = ite.next().toString();
			if (popupHandle.contains(popupHandle)) {
				System.out
						.println("popup window closed-------------------------");
				getDriver().close();
				break;
			}
		}
		getDriver().switchTo().window(parentWindowId);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), applinamewidget);
		UIHelper.highlightElement(getDriver(), applicationNameList);
	}
	
	public boolean verify_Online_Credit_Application_Link() {
		if (onlineCreditApplicationLink.isVisible()) {
			return true;
		}else{
			return false;

		
	}
	}
		public void click_OCA_Link_ECF(){
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", onlineCreditApplicationLink);
			onlineCreditApplicationLink.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),Ecf_Section_Header);
			
		}
		
	public boolean verify_Data_In_Ecf_Page(String SectionName,
			String FieldName, String Value) {

		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), Ecf_Section_Header);
		WebElement FieldValue = getDriver()
				.findElement(
						By.xpath("//*[@id='widget_container']//h3[contains(.,'"
								+ SectionName
								+ "')]//ancestor::div[1]//following-sibling::div//tbody//td[contains(.,'"
								+ FieldName + "')]//following-sibling::td"));

		((JavascriptExecutor) getDriver()).executeScript(
				"arguments[0].scrollIntoView(true);", FieldValue);
		UIHelper.highlightElement(getDriver(), FieldValue);
		System.out.println("value displayed in ecf page-----------"
				+ FieldValue.getText());
		System.out.println("value has been given-----------" + Value);
		if (FieldValue.getText().contains(Value)) {
			System.out.println("given value matched-------------------");
			return true;
		} else {
			System.out.println("given value not matched-------------------");
			return false;
		}
	}
	public void validateRulePage(String condition)
    
    {
		if(matchcompanybtn.isVisible()){
			internalOCA.matchCompany();
			reDecisionOCA.validateApplicationReDecisioning();
			String[] conditionNames=   condition.split(",");
	           for(String condtionName:conditionNames){
	                  String getSingleConditionName=getDriver().findElement(By.xpath("//table[@class='results tab_border']//tbody//td[contains(.,'"+condtionName+"')]")).getText();
	                  String getConditionValue=getDriver().findElement(By.xpath("//table[@class='results tab_border']//tbody//td[contains(.,'"+condtionName+"')]//following-sibling::td")).getText();
	                  
	                  if(condtionName.contains(getSingleConditionName))
	                  {
	                        System.out.println("Both are matched:" +condtionName);
	                  }
	        
			}
		}
		else{
		String[] conditionNames=   condition.split(",");
           for(String condtionName:conditionNames){
                  String getSingleConditionName=getDriver().findElement(By.xpath("//table[@class='results tab_border']//tbody//td[contains(.,'"+condtionName+"')]")).getText();
                  String getConditionValue=getDriver().findElement(By.xpath("//table[@class='results tab_border']//tbody//td[contains(.,'"+condtionName+"')]//following-sibling::td")).getText();
                  
                  if(condtionName.contains(getSingleConditionName))
                  {
                        System.out.println("Both are matched:" +condtionName);
                  }
           }
		}
    }
	
	public boolean Field_Is_Not_Dispalyed(String xlSectionName, String xlFieldName) {
		int fieldvalue=0;
		String fieldname="//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
								+ xlSectionName
								+ "')]//following-sibling::div[1][@class='frmSecEdit']//tr//td[@class='frmTitleF']";
		
		
		//List <WebElement> fieldNameList=getDriver().findElements(By.xpath(fieldname));
		List <WebElementFacade> fieldNameList=findAll(By.xpath(fieldname));
		for(WebElementFacade list : fieldNameList ){
			
			if(list.getText().contains(xlFieldName)){
				fieldvalue=1;
				UIHelper.mouseOveranElement(getDriver(), list);
				UIHelper.highlightElement(getDriver(), list);
				
		}else{
			fieldvalue=2;
		}
		}
			System.out.println("return value for verify field-------------"+fieldvalue);
			
			if(fieldvalue==1){
				return false;
			}else{
				return true;
			}

		/*if ((find(By.xpath("//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
								+ xlSectionName
								+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
								+ xlFieldName
								+ "')]//following-sibling::b[contains(@class, 'required')]")))
				.isVisible()) {

			WebElement mandatoryfield = getDriver()
					.findElement(
							By.xpath("//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
									+ xlSectionName
									+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
									+ xlFieldName + "')]"));
			UIHelper.highlightElement(getDriver(), mandatoryfield);
			return false;
		} else {
			return true;
		}*/

	}
	
	public boolean verify_Field_Is_Dispalyed(String xlSectionName, String xlFieldName) {
		int fieldvalue=0;
		String fieldname="//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
								+ xlSectionName
								+ "')]//following-sibling::div[1][@class='frmSecEdit']//tr//td[@class='frmTitleF']";
		
		
		List <WebElementFacade> fieldNameList=findAll(By.xpath(fieldname));
		for(WebElementFacade list : fieldNameList ){
			
			if(list.getText().contains(xlFieldName)){
				fieldvalue=1;
				UIHelper.mouseOveranElement(getDriver(), list);
				UIHelper.highlightElement(getDriver(), list);
				break;
				
		}else{
			fieldvalue=2;
		}
		}
			System.out.println("return value for verify field-------------"+fieldvalue);
			if(fieldvalue==1){
				return true;
			}else{
				return false;
			}
	}
	
	public void is_D_And_B_Search_Results_Displayed(){
		try
		{
			if(dbSearchResults1.isVisible()){

				UIHelper.highlightElement(getDriver(), widgetForm);
				UIHelper.highlightElement(getDriver(), searchResultsTable);

				System.out.println("option highligh if---------------");
				
				
			}else{
				UIHelper.mouseOveranElement(getDriver(), dbSearchResults);

				System.out.println("option highligh else---------------");
							
				
			}
					

		}
		catch(Exception e){
			
		}
	}
	public void select_A_Match_From_Results2(){
			if(dbSearchResults1.isVisible()){

				UIHelper.highlightElement(getDriver(), widgetForm);
				((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", dbSearchResults1);
				UIHelper.highlightElement(getDriver(), searchResultsTable);
				((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", dbSearchResults1);
				waitFor(1000).milliseconds();
				
			}else{
				((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", dbSearchResults);
				UIHelper.mouseOveranElement(getDriver(), dbSearchResults);
				((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", dbSearchResults);
				System.out.println("option highligh else---------------");
				waitFor(1000).milliseconds();
				
			}
					

		}
		
	
	public void select_A_Match_From_Results(){
		if(dbSearchResults1.isVisible()){
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", dbSearchResults1);
			waitFor(1000).milliseconds();
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", dbSearchResults1);
			System.out.println("option highligh if---------------");
			
			
		}else{
			UIHelper.mouseOveranElement(getDriver(), dbSearchResults);
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", dbSearchResults);
			waitFor(1000).milliseconds();
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", dbSearchResults);
			System.out.println("option highligh else---------------");
						
			
		}
		
	}
	public void Enter_Data_Into_Business_Name_Field(String Value) {
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", headerCID);

		((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", headerCID);

		UIHelper.mouseOveranElement(getDriver(), subHeaderCID);
		UIHelper.highlightElement(getDriver(), subHeaderCID);
			businessNameField.clear();
			businessNameField.sendKeys(Value.trim());
		} 
	

public void again_Enter_Data_Into_Text_Fields(String MainSectionName, String subSectionName, String xlFieldName,String Value) {
	System.out.println("section Name which we have passed--------------------- "+MainSectionName);
	
	String headerCIDxpath="//*[@class='container']//*[@class='cfa-report-content']//h3[contains(.,'"
			+ MainSectionName
			+ "')]";
	String subHeaderCIDxpath="//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
			+ subSectionName
			+ "')]";
	
	/*String fieldname="//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
			+ xlSectionName
			+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
			+ xlFieldName
			+ "')]";*/
	String enterconditionfieldvalue="//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
			+ subSectionName
			+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
			+ xlFieldName
			+ "')]//following-sibling::td[contains(@class, 'frmField')]//input[contains(@class, 'regular')]";
	
	
	WebElementFacade headerCIDelement=find(By.xpath(headerCIDxpath));
	WebElementFacade subHeaderCIDelement=find(By.xpath(subHeaderCIDxpath));
	
	((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", headerCIDelement);

	((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", headerCIDelement);

	UIHelper.mouseOveranElement(getDriver(), headerCIDelement);
	UIHelper.highlightElement(getDriver(), headerCIDelement);
	enterconditionFieldName=find(By.xpath(enterconditionfieldvalue));
	enterconditionFieldName.clear();
	enterconditionFieldName.sendKeys(Value.trim());
	} 

public void again_Select_Value_From_List_Fields(String xlSectionName, String xlFieldName,String Value) {
	System.out.println("section Name which we have passed--------------------- "+xlSectionName);
	
	String headerCIDxpath="//*[@class='container']//*[@class='cfa-report-content']//h3[contains(.,'"
			+ xlSectionName
			+ "')]";
	String subHeaderCIDxpath="//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
			+ xlSectionName
			+ "')]";
	
	String fieldname="//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
			+ xlSectionName
			+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
			+ xlFieldName
			+ "')]";
	String enterconditionfieldvalue="//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
			+ xlSectionName
			+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
			+ xlFieldName
			+ "')]//following-sibling::td[contains(@class, 'frmField')]//input[contains(@class, 'regular')]";
	
	
	WebElementFacade headerCIDelement=find(By.xpath(headerCIDxpath));
	WebElementFacade subHeaderCIDelement=find(By.xpath(subHeaderCIDxpath));
	
	((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", headerCIDelement);

	((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", headerCIDelement);

	UIHelper.mouseOveranElement(getDriver(), headerCIDelement);
	UIHelper.highlightElement(getDriver(), headerCIDelement);
	enterconditionFieldName=find(By.xpath(enterconditionfieldvalue));
	
	enterconditionFieldName.selectByVisibleText(Value.trim());
	} 

public boolean getStatusMessage(String Status){
	String [] applicationStatus=Status.split("OR");
	System.out.println("given values----------------"+applicationStatus[0]+" --- "+applicationStatus[1]+" --- "+applicationStatus[2]);
	String statusMessage=thanksMessage.getText();
	System.out.println("statusMessage------"+statusMessage);
	if(statusMessage.contains(applicationStatus[0].trim()) || statusMessage.contains(applicationStatus[1].trim()) || statusMessage.contains(applicationStatus[2].trim())){
		return true;
	}else{
		return false;
	}
	
}

public boolean getAppStatus(String Status){
	try{
		UIHelper.waitForPageToLoad(getDriver());
		String statusname=getDriver().findElement(By.xpath("//div[@id='widget_container']//div[@class='reviewStatus']//span[1][contains(.,'Approved')]")).getText();
		if(statusname.contains(Status)){
            return true;
      }
      
	}catch (Exception e) {
		e.printStackTrace();
    }
	return false;
}
public void click_Fin_View_Link(){
	
	if(financialViewLink.isPresent()){
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", financialViewLink);
		parentWindowId = getDriver().getWindowHandle();
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", financialViewLink);
		financialViewLink.click();
		 Set s = getDriver().getWindowHandles();
         Iterator ite = s.iterator();
         while (ite.hasNext()) {
        	 System.out.println("inside while loop--------------------------");
             String popupHandle = ite.next().toString();
             if (!popupHandle.contains(parentWindowId)) {
            	 System.out.println("inside if loop-------------------------------------");
            	 getDriver().switchTo().window(popupHandle);
            	 System.out.println("window switched--------------------------------");
                 UIHelper.waitForVisibilityOfEleByXpath(getDriver(),fin_Header_Xpath);
                 UIHelper.highlightElement(getDriver(), finHeaderElement);
                 System.out.println("waited for element---------------------");
             }
         }
		
		
	}
}

public boolean verify_Financial_Data_In_Financial_View_Page(String SectionName,
		String FieldName, String Value) {

	UIHelper.waitForVisibilityOfEleByXpath(getDriver(),fin_Header_Xpath);
	String finFieldXpath=".//*[@id='main']//th[contains(.,'"+SectionName+"')]//ancestor::thead//following-sibling::tbody//td[contains(.,'"+FieldName+"')]//following-sibling::td[1]";
	WebElementFacade finFieldName=find(By.xpath(finFieldXpath));
	

	((JavascriptExecutor) getDriver()).executeScript(
			"arguments[0].scrollIntoView(true);", finFieldName);
	UIHelper.highlightElement(getDriver(), finFieldName);
	System.out.println("value displayed in ecf page-----------"
			+ finFieldName.getText());
	System.out.println("value has been given-----------" + Value);
	if (finFieldName.getText().contains(Value)) {
		System.out.println("given value matched-------------------");
		return true;
	} else {
		System.out.println("given value not matched-------------------");
		return false;
	}
}
public void financial_Swithch_To_ParentWindow() {
	Set s = getDriver().getWindowHandles();
	Iterator ite = s.iterator();
	while (ite.hasNext()) {
		System.out
				.println("inside finsih button while loop--------------------------");
		String popupHandle = ite.next().toString();
		if (popupHandle.contains(popupHandle)) {
			System.out
					.println("popup window closed-------------------------");
			getDriver().close();
			break;
		}
	}
	getDriver().switchTo().window(parentWindowId);
	String financialsheader = "//*[@id='widget_container']//*[contains(@class,'summary_links')]//div//*[contains(.,'Financial')]";
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), financialsheader);
	
}

public boolean verify_Allignment(String AlignmentOption){
	int val=0;
	if(lTTextAllignment.isVisible()){
		String alignmentvalue=lTTextAllignment.getAttribute("class");
		if (alignmentvalue.contains(AlignmentOption)){
			val=1;
		}else{
			val=2;
		}
	}
	if(val == 1){
		return true;
	}else{
		return false;
	}
	
}

public boolean verify_LetterHeadText(String LetterHeadText){
	int val=0;
	if(lTText.isVisible()){
		String alignmentvalue=lTText.getText();
		if (alignmentvalue.contains(LetterHeadText)){
			val=1;
		}else{
			val=2;
		}
	}
	if(val == 1){
		return true;
	}else{
		return false;
	}
	
}
public void signAndSubmitBtnClick() {

	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), signSubmitXpath);
	WebElement signAndsubmitbtn = getDriver()
			.findElement(By
					.xpath("//*[@id='sectionWrap_TermsAndConditionsPage']//*[@value='Sign and Submit Application']"));
	((JavascriptExecutor) getDriver()).executeScript(
			"arguments[0].scrollIntoView(true);", signAndsubmitbtn);
	UIHelper.highlightElement(getDriver(), signAndsubmitbtn);
	signAndsubmitbtn.click();
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
	getDriver().switchTo().frame(iFrameEle);
	waitFor(500).milliseconds();
	getDriver().switchTo().frame(iFrameEle1);
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), pleseSignTextXpath);
	
	

}

public boolean echoSignPageHasDisplayed(){
	if(pleaseSignText.isVisible()){
		UIHelper.highlightElement(getDriver(), pleaseSignText);
		return true;
	}else{
		return false;
	}
	
}
public void Enter_Echosign(String echoSign, String emailid){
	emailEchoSign.waitUntilPresent();
	UIHelper.highlightElement(getDriver(), emailEchoSign);
	emailEchoSign.sendKeys(emailid);
	waitFor(500).milliseconds();
	signatureclick.click();
	waitFor(2000).milliseconds();
	UIHelper.highlightElement(getDriver(), typeclick);
	typeclick.click();
	UIHelper.highlightElement(getDriver(), writeSignature);
	writeSignature.sendKeys(echoSign);
	waitFor(1000).milliseconds();
	UIHelper.highlightElement(getDriver(), signatureApplyBtn);
	signatureApplyBtn.click();
	waitFor(2000).milliseconds();
	
}
public void click_Sign(){
	click_To_Sign_Text.isVisible();
	click_To_Sign_Text.click();
	getDriver().switchTo().defaultContent();
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), thanksPageHeader);
	
	
}
public void focus_Cahnge_To_ParentWindow() {
	Set s = getDriver().getWindowHandles();
	Iterator ite = s.iterator();
	while (ite.hasNext()) {
		System.out
				.println("inside finsih button while loop--------------------------");
		String popupHandle = ite.next().toString();
		if (popupHandle.contains(popupHandle)) {
			System.out
					.println("popup window closed-------------------------");
			getDriver().close();
			break;
		}
	}
	getDriver().switchTo().window(parentWindowId);
	
}
public void switch_To_Date_Widnow(){
	
	Set<String> AllWindowHandles = getDriver().getWindowHandles(); 
	System.out.println("window count------   "+AllWindowHandles.size());
	String window1 = (String) AllWindowHandles.toArray()[0]; 
	System.out.print("window1 handle code = "+AllWindowHandles.toArray()[0]); 
	String window2 = (String) AllWindowHandles.toArray()[1]; 
	System.out.print("\nwindow2 handle code = "+AllWindowHandles.toArray()[1]); 
	String window3 = (String) AllWindowHandles.toArray()[2]; 
	System.out.print("\nwindow3 handle code = "+AllWindowHandles.toArray()[2]); 
	getDriver().switchTo().window(window3);
	 System.out.println("calendar window switched--------------------------------");
    UIHelper.waitForVisibilityOfEleByXpath(getDriver(),calendarwindwoxpath);
    UIHelper.highlightElement(getDriver(), calendarwindowelement);
    System.out.println("calendar waited for element---------------------");
	
	/* Set s = getDriver().getWindowHandles();
	
	System.out.println("window count------   "+s.size());
    Iterator ite = s.iterator();
     while (ite.hasNext()) {
    	 System.out.println("calendar inside while loop--------------------------");
         String popupHandle = ite.next().toString();
         if (!popupHandle.contains(parentWindowId)) {
        	 System.out.println("child window id -------------------------------------"+popupHandle);
        	 
        	 getDriver().switchTo().window(popupHandle);
        	 System.out.println("calendar window switched--------------------------------");
             UIHelper.waitForVisibilityOfEleByXpath(getDriver(),calendarwindwoxpath);
             UIHelper.highlightElement(getDriver(), calendarwindowelement);
             System.out.println("calendar waited for element---------------------");
         }
     }*/
}
public void select_Date_Into_Date_Field(String xlSectionName, String xlFieldName) {
	String dateFieldXpath="//*[@class='container']//*[@class='cfa-report-content']//h5[contains(.,'"
							+ xlSectionName
							+ "')]//following-sibling::div[@class='frmSecEdit']//tr//td[contains(.,'"
							+ xlFieldName
							+ "')]//following-sibling::td[contains(@class, 'frmField')]//a//img[contains(@src,'calendar')]";
	WebElementFacade dateField=find(By.xpath(dateFieldXpath));

	if (dateField.isVisible()) {
		System.out.println("date field is visisble");
		parentWindowId = getDriver().getWindowHandle();
		UIHelper.mouseOveranElement(getDriver(), dateField);
		dateField.click();
		waitFor(3000).milliseconds();
		switch_To_Date_Widnow();
		select_Date_ICon();
		getDriver().switchTo().window(parentWindowId);
	} 
}


public void select_Date_ICon(){
	DateFormat dateFormat = new SimpleDateFormat("d");
	DateFormat dateFormat2 = new SimpleDateFormat("MM/dd/yyyy");
    Date date = new Date();
    String onlyDay =dateFormat.format(date);
    System.out.println("today date --- "+onlyDay);
    fullDate =dateFormat2.format(date);
   System.out.println("Full date:----- "+fullDate);	
	List<WebElement> columns=getDriver().findElements(By.xpath("//*[@id='calendar']//*[@id='content']//table//tbody//tr//td//a"));

	for (WebElement cell: columns){
	   System.out.println("date values------------"+cell.getText());
	   if (cell.getText().trim().equalsIgnoreCase(onlyDay.trim())){
		   System.out.println("inside if date values------------  "+cell.getText()); 
		   UIHelper.highlightElement(getDriver(), cell);
		  cell.click();
	     
	      break;
	 }
}

}
public void nexttradreference(){
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), nextreferencecheck);
	nextreference.click();
}
}
	

