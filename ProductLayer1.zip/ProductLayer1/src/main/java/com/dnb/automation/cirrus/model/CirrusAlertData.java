package com.dnb.automation.cirrus.model;

public class CirrusAlertData {

	static String profileId;
	static String profileIdChild;


	public static String getProfileIdChild() {
		return profileIdChild;
	}

	public static void setProfileIdChild(String profileIdChild) {
		CirrusAlertData.profileIdChild = profileIdChild;
	}

	public static String getProfileId() {
		return profileId;
	}

	public static void setProfileId(String profileId) {
		CirrusAlertData.profileId = profileId;
	}
	
	

}
