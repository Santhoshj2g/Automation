package com.dnb.automation.sba.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Predicate;

import net.serenitybdd.core.pages.WebElementFacade;

public class UIHelper {

	public static final int MINPOLLINGTIME = 100;

	public static final int MINPOLLINGTIMEX2 = 400;

	public static final int POLLINGEVERYSECTIME = 3;

	public static final int MAXPOLLINGTIME = 180;

	public static final int HIGHLIGHTERINT = 5;

	public static final int HIGHLIGHTERINTMAX = 10;

	private static String gridViewTableLoading= "//*[@class='analysisRightTab']//*[@class='innercontainer']//*[@class='gridViewTableLoading']/img[@src='static/images/ajax-loader.gif']";
	private static String chartTableLoading= "//*[@class='analysisRightTab']//*[@class='innercontainer']//*[@class='chartTableLoading']/img[@src='static/images/ajax-loader.gif']";

	public static void waitForPageToLoad(final WebDriver driver) {
		try {
			(new WebDriverWait(driver, MINPOLLINGTIME))
			.until(new ExpectedCondition<Boolean>() {
				public Boolean apply(final WebDriver d) {
					return (((org.openqa.selenium.JavascriptExecutor) driver)
							.executeScript("return document.readyState")
							.equals("complete"));
				}
			});
		} catch (Exception e) {

		}
	}


	public static void findandAddElementsToaList(final WebDriver driver,
			final String xpath, final ArrayList<String> someStringSet) {

		try {

			List<WebElement> getArrayMembers = driver.findElements(By
					.xpath(xpath));

			for (WebElement listData : getArrayMembers) {
				someStringSet.add(listData.getText());
			}
		} catch (Exception e) {

		}
	}


	public static void scrollToAnElement(final WebElement element) {

		try {

			Coordinates coordinate = ((Locatable) element).getCoordinates();
			coordinate.onPage();
			coordinate.inViewPort();
		} catch (Exception e) {

		}
	}


	public static void highlightElement(final WebDriver driver,
			final WebElement element) {

		try {

			for (int i = 0; i < HIGHLIGHTERINT; i++) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript(
						"arguments[0].setAttribute('style', arguments[1]);",
						element, "color: #800000; border: 2px solid blue;");
			}
		} catch (Exception e) {

		}
	}

	public static void waitForInvisibilityOfAjaxImgByXpath(
			final WebDriver driver, final String ajaxElementxpath) {

		try {
			WebDriverWait wait = new WebDriverWait(driver, MINPOLLINGTIMEX2);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By
					.xpath(ajaxElementxpath)));
		} catch (Exception e) {

		}
	}

	public static void waitForVisibilityOfEleByXpath(final WebDriver driver,
			String elementXpath) {
		FluentWait<By> fluentWait = new FluentWait<By>(By.xpath(elementXpath));
		fluentWait.pollingEvery(100, TimeUnit.MILLISECONDS);
		fluentWait.withTimeout(120, TimeUnit.SECONDS);
		fluentWait.until(new Predicate<By>() {
			public boolean apply(final By by) {
				try {
					return driver.findElement(by).isDisplayed();
				} catch (Exception ex) {

					return false;
				}
			}
		});
	}

	public static void mouseOveranElement(final WebDriver driver,
			final WebElement element1) {

		try {

			Actions action = new Actions(driver);
			UIHelper.highlightElement(driver, element1);

			action.moveToElement(element1).build().perform();

		} catch (Exception e) {

		}
	}

	public static void mouseOverandclickanElement(final WebDriver driver,
			final WebElement element1) {
		try {
			if (element1.isDisplayed()) {
				Actions action = new Actions(driver);
				action.moveToElement(element1).click().build().perform();
			}
		} catch (Exception e) {

		}
	}

	public static void clickAnElement(final WebElementFacade myElement) {
		try {
			waitForVisibilityOfElement(myElement);
			if (myElement.isDisplayed()) {
				myElement.click();
			}
		} catch (Exception e) {
			System.out.println("Element is not available");
		}
	}


	public static Map<String,String> getAllSpendValues(final WebDriver driver,String preXpath,int totalDuns,final WebElementFacade nextPage){

		Map<String, String> dunsAndSpendHmap = new TreeMap<String, String>();
		System.out.println("inside the get all spend values: ");
		int maxPerPage=100;
		int dunsPerPage;
		float numOfPages=totalDuns/100f;
		if(0!=totalDuns)
		{
			for(int nop=0;nop<(int)Math.ceil(numOfPages);nop++)
			{
				if(totalDuns>maxPerPage)
				{
					dunsPerPage=maxPerPage;
				}
				else
				{
					dunsPerPage=totalDuns;
				}

				for(int i=1;i<=dunsPerPage;i++)
				{
					String xpathOfDuns=preXpath+i+"]/td[2]";
					String xpathOfSpend=preXpath+i+"]/td[3]";
					String duns;
					String spend;
					try
					{
						highlightElement(driver, getWebElementOfxpath(driver,xpathOfDuns));
						duns=getWebElementOfxpath(driver,xpathOfDuns).getText();
					}
					catch(Exception e)
					{
						waitForVisibilityOfEleByXpath(driver, xpathOfDuns);
						highlightElement(driver, getWebElementOfxpath(driver,xpathOfDuns));
						duns=getWebElementOfxpath(driver,xpathOfDuns).getText();
					}
					System.out.print("DUNS number="+duns);
					try
					{
						spend=getWebElementOfxpath(driver,xpathOfSpend).getText();
					}
					catch(Exception e)
					{
						waitForVisibilityOfEleByXpath(driver, xpathOfSpend);
						spend=getWebElementOfxpath(driver,xpathOfSpend).getText();
					}
					System.out.println("------spend="+spend);
					dunsAndSpendHmap.put(duns.trim(), spend.trim());
				}
				totalDuns=totalDuns-maxPerPage;
				UIHelper.clickAnElement(nextPage);
			}
		}
		return dunsAndSpendHmap;
	}

	public static WebElement getWebElementOfxpath(WebDriver driver ,String xpath)
	{
		waitForVisibilityOfEleByXpath(driver,xpath);
		try
		{
			return driver.findElement(By.xpath(xpath));
		}
		catch(Exception e)
		{
			System.out.println("Exception:"+e);
		}
		return null;
	}

	public static Set<String> getDUNSNumber(Map<String,String> dunsAndSpendMap){
		return dunsAndSpendMap.keySet();
	}

	public static void openInNewTab(final WebDriver driver,String URL)
	{
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL+"t");
		driver.get(URL);
	}

	public static void switchToTab(final WebDriver driver,String tab) {
		String xpathOfSF="//*[@id='supplierFamily' and @class='selected ShowSubMenu']/a";
		boolean sfTab =isElementDisplayed(driver, xpathOfSF);
		if(tab.equalsIgnoreCase("supplierFamily")&&!sfTab)
		{
			driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"\t");
			driver.switchTo().defaultContent(); 
			System.out.println("inside SF tab");
		}
		else if(tab.equalsIgnoreCase("notSF")&&sfTab)
		{
			driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"\t");
			driver.switchTo().defaultContent(); 
			System.out.println("inside nonSF tab");
		}

	}

	public static boolean isElementDisplayed(WebElement element) {
		try
		{
			waitForVisibilityOfElement(element);
			if((element != null) && (element.isDisplayed()))
			{
				return true;
			}
			else
			{
				return false;
			}
		} catch (Exception e) {

			return false;
		}
	}

	public static boolean isElementDisplayed(final WebDriver driver,String xpath)
	{
		try
		{
			if((driver.findElement(By.xpath(xpath)) != null) && (driver.findElement(By.xpath(xpath)).isDisplayed()))
			{
				System.out.println("isElementDisplayed:true: ");
				return true;
			}
			else
			{
				System.out.println("isElementDisplayed: false: ");
				return false;
			}
		} catch (Exception e) {

			System.out.println("isElementDisplayed: Exception: ");
			return false;
		}
	}

	public static boolean clickAnElement(final WebDriver driver,String xpath) {

		try
		{
			waitForVisibilityOfEleByXpath(driver,xpath);
			WebElement myElement=driver.findElement(By.xpath(xpath));

			if (myElement.isDisplayed())
			{
				System.out.println("clickAnElement clicked");
				highlightElement(driver, driver.findElement(By.xpath(xpath)));
				myElement.click();
				return true;
			}
			else
			{
				System.out.println("clickAnElement else");
				return false;
			}
		}
		catch (Exception e)
		{
			System.out.println("Exception while clickAnElement");
			return false;
		}
	}

	public static void waitForVisibilityOfElement(WebElement element) {

		FluentWait<WebElement> fluentWait = new FluentWait<WebElement>(element);
		fluentWait.pollingEvery(100, TimeUnit.MILLISECONDS);
		fluentWait.withTimeout(60, TimeUnit.SECONDS);
		fluentWait.until(new Predicate<WebElement>() {
			public boolean apply(final WebElement ele) {
				try {
					return ele.isDisplayed();
				} catch (Exception ex) {

					return false;
				}
			}
		});
	}

	public static void waitForVisibilityOfElement(WebElementFacade element) {

		FluentWait<WebElementFacade> fluentWait = new FluentWait<WebElementFacade>(element);
		fluentWait.pollingEvery(100, TimeUnit.MILLISECONDS);
		fluentWait.withTimeout(60, TimeUnit.SECONDS);
		fluentWait.until(new Predicate<WebElementFacade>() {
			public boolean apply(final WebElementFacade ele) {
				try {
					return ele.isDisplayed();
				} catch (Exception ex) {

					//return false;
					return true;
				}
			}
		});
	}

	public static int getTotalRecords(WebElementFacade element)
	{
		try
		{
			UIHelper.waitForVisibilityOfElement(element);
			String value=element.getText().replaceAll(",", "");
			return Integer.parseInt(value);
		}
		catch(Exception e)
		{
			return 0;
		}
	}

	public static boolean waitForAjaxToLoad(WebDriver driver) {

		WebDriverWait wait = new WebDriverWait(driver, 30);

		// wait for jQuery to load
		ExpectedCondition<Boolean> jQueryLoad = new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				try {
					return ((Long)((JavascriptExecutor)driver).executeScript("return jQuery.active") == 0);
				}
				catch (Exception e) {
					// no jQuery present
					return true;
				}
			}
		};

		// wait for Javascript to load
		ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor)driver).executeScript("return document.readyState")
						.toString().equals("complete");
			}
		};

		return wait.until(jQueryLoad) && wait.until(jsLoad);
	}

	public static void gotoFirstPage(WebElementFacade pageBlock,WebElementFacade goButton)
	{
		if(pageBlock.isEnabled())
		{
			pageBlock.type("1");
			clickAnElement(goButton);
		}
	}

	public static void waitForInvisibilityOfChartAndTable(WebDriver driver)
	{
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(driver, chartTableLoading);
		UIHelper.waitForPageToLoad(driver);
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(driver, gridViewTableLoading);
		UIHelper.waitForPageToLoad(driver);
	}

	public static Map<String,Set<Entry<String, String>>> compareMaps(Map<String,String> map1,Map<String,String> map2)
	{
		Set<Entry<String, String>> diff12 = new HashSet<Entry<String, String>>(map1.entrySet());
		Set<Entry<String, String>> diff21 = new HashSet<Entry<String, String>>(map2.entrySet());
		Map<String, Set<Entry<String, String>>> map = new HashMap<String, Set<Entry<String, String>>>();

		diff12.removeAll(map2.entrySet());
		diff21.removeAll(map1.entrySet());
		if(!diff12.isEmpty())
		map.put("map1", diff12);
		if(!diff21.isEmpty())
		map.put("map2",diff21);
		return map;
	}
}
