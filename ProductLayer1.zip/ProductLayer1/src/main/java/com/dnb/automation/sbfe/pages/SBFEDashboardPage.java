package com.dnb.automation.sbfe.pages;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;



import org.openqa.selenium.WebElement;















//import com.dnb.automation.utils.CommonMethods;
import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class SBFEDashboardPage extends PageObject{

@FindBy(xpath=".//*[@id='dashBoard']/a")
private WebElementFacade dashboardlink;

@FindBy(xpath=".//*[@id='dashBoard']/a/p")
private WebElementFacade dashboardText;

@FindBy(xpath=".//*[@id='inProgressFileDiv']//table[@id='isummaryTbl']")
private WebElementFacade SBFEProcessTable;

@FindBy(xpath=".//*[@id='idbSummaryTbody']/tr/td[contains(text(),'File Batches')]/following-sibling::td[1]")
private WebElementFacade fileBatchCount;

@FindBy(xpath=".//*[@id='idbSummaryTbody']/tr/td[text()='No of Files']/following-sibling::td[1]")
private WebElementFacade filesCount;

@FindBy(xpath=".//*[@id='idbSummaryTbody']/tr/td[contains(text(),'CTBR Files')]/following-sibling::td[1]")
private WebElementFacade contributorFileCount;

@FindBy(xpath=".//*[@id='idbSummaryTbody']/tr/td[contains(text(),'CTBR Files')]/following-sibling::td[1]/span")
private WebElementFacade contributorFilelink;

@FindBy(xpath=".//*[@id='idbSummaryTbody']/tr/td[contains(text(),'Start Time')]/following-sibling::td[1]")
private WebElementFacade startTime;

@FindBy(xpath=".//*[@id='idbSummaryTbody']/tr/td[contains(text(),'Records')]/following-sibling::td[1]")
private WebElementFacade recordCount;

@FindBy(xpath=".//*[@id='idbSummaryTbody']/tr/td[contains(text(),'Accounts')]/following-sibling::td[1]")
private WebElementFacade accountCount;

@FindBy(xpath=".//*[@id='dailyPendTableId']/tbody/tr/td/div/div[@class='fileNmDiv']/label")
private List<WebElementFacade> fileNameinCTBR;

@FindBy(xpath=".//table[@id='dailyPendTableId']")
private WebElementFacade ctbrTable;

@FindBy(xpath=".//*[@id='dailyPendTableId']/tbody/tr/td/div/div/label[contains(text(),'.TKN')]")
private List<WebElementFacade> fileRows;

@FindBy(xpath=".//*[@id='dailyPendTableId']/tbody/tr/td/div/div/button[@id='fileViewBtn']")
private List<WebElementFacade> fileExpandButton;

@FindBy(xpath=".//*[@id='fleValdnTbleBody']/tr/td[6]")
private WebElementFacade ctbrFileCount;

@FindBy(xpath=".//div[contains(@class,'fileSummaryPopUp')]/div/button/span[(@class='ui-button-text') and (text()='close')]")
private WebElementFacade ctbrPopupCloseBtn;

private String expandRows=".//table[@id='dailyPendTableId']/tbody/tr[xxx]/td/button[@id='expCtbrStatus']";

private String fileReceivedDate = ".//*[@id='dailyPendTableId']/tbody/tr[xxx]/td/div/div/label[contains(text(),'.TKN')]/parent::div/parent::div/parent::td/following-sibling::td[1]";

private String ctbrfileXpath =".//*[@id='dailyPendTableId']/tbody/tr[xxx]/td[@class='expandedRow right']/div/div[@class='fileNmDiv']/label";

private String ctbrexpandbtn =".//*[@id='dailyPendTableId']/tbody/tr/td/div/div/button[@id='ctbrViewBtn']";

@FindBy(xpath=".//*[@id='dailyPendTableId']/tbody/tr/td/div/div/button[@id='ctbrViewBtn']")
private List<WebElementFacade> ctbrFileExpandBtn;

@FindBy(xpath=".//*[@id='ctbrFlesummaryDetails']/tr/td[1]")
private WebElementFacade ctbrAccCount;

@FindBy(xpath=".//*[@id='ctbrFlesummaryDetails']/tr/td[3]")
private WebElementFacade ctbrCrrAccCount;

@FindBy(xpath=".//*[@id='ctbrFlesummaryDetails']/tr/td[4]")
private WebElementFacade ctbrFailAccCount;

@FindBy(xpath=".//div[contains(@class,'ctbrSummLinkPopup')]/div/button/span[(@class='ui-button-text') and (text()='close')]")
private WebElementFacade ctbrPopUpCloseBtn;

@FindBy(xpath=".//*[@id='idbDetailTbody']/tr/td/span[contains(text(),'File Validation')]/parent::td/following-sibling::td[2]")
private WebElementFacade filevalidation;

@FindBy(xpath=".//*[@id='idbDetailTbody']/tr/td/span[contains(text(),'Record Validation')]/parent::td/following-sibling::td[2]")
private WebElementFacade recordvalidation;

private String fileStatus = ".//*[@id='idbDetailTbody']/tr/td/span[contains(text(),'File Validation')]/parent::td/following-sibling::td[1]";
private String recordStatus =".//*[@id='idbDetailTbody']/tr/td/span[contains(text(),'Record Validation')]/parent::td/following-sibling::td[1]";

//private String ctbrFilesinfileRow =".//*[@id='dailyPendTableId']/tbody/tr/td[@class='expandedRow right']/div/div[@class='fileNmDiv']";

private String commSBFETableXpath=".//*[@id='idbSummaryTbody']//td[text()='SERENITY']/following-sibling::td";

private int accCount = 0;
private int crrAccCount =0;
private int failAccCount=0;
private int recCount=0;
private String result ="";

	public String verifyDashboard() throws Exception
	{
		if(dashboardlink.isPresent()){
			Thread.sleep(10000);
			UIHelper.highlightElement(getDriver(), dashboardlink);
			dashboardlink.click();
			return dashboardText.getText().toLowerCase();
		}else {
			return null;
		}		
	}

	public String verifySBFEProcessedDate(String Date) throws Exception {
		String actualcurrectDate="";
		if (SBFEProcessTable.isPresent()){
			String currentDatexpath=commSBFETableXpath.replace("SERENITY", "SBFE processed Date");
			String currentDate=find(By.xpath(currentDatexpath)).getText().toString().trim();
			if(Date.equals(currentDate)){
				actualcurrectDate= currentDate;
			}
		}
		return actualcurrectDate;
	}



	public String verifyFileBatchCount() 
	{
		String count="";
		if(element(fileBatchCount).isPresent()){
			UIHelper.highlightElement(getDriver(), fileBatchCount);
			count=fileBatchCount.getText().toString().trim();
		}
		return count;
	}

	public String verifyFileCount() {
		String count="";
		if(element(filesCount).isPresent()){
			UIHelper.highlightElement(getDriver(), filesCount);
			count=filesCount.getText().toString().trim();
		}
		return count;
	}

	public String verifycontributorFileCount() {
		String count="";
			if(element(contributorFileCount).isPresent()){
			UIHelper.highlightElement(getDriver(), contributorFileCount);
			count=contributorFileCount.getText().toString().trim();
		}
		return count;
	}

	public boolean verifyrecordCount() {
		boolean flag =false;
		if(element(recordCount).isPresent()){
		UIHelper.highlightElement(getDriver(), recordCount);
		String count=recordCount.getText().toString().trim();
		if(count.equals(Integer.toString(recCount))){
			flag= true;
		}
	}
	return flag;
	}

	public boolean ClickContributorRecordlink() {
	if(contributorFilelink.isPresent()){
		UIHelper.highlightElement(getDriver(), contributorFilelink);
		contributorFilelink.click();
		return true;
	}else{
		return false;
	}
	}

	public boolean verifySwitchWindow() throws Exception
	{
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.switchToChildWindow1(getDriver());
		getDriver().manage().window().maximize();
		String currentURL= getDriver().getCurrentUrl();
		if(currentURL.contains("ctbrFiles")){
			return true;
		}else{
			return false;
		}
	}

	public String[] getCTBRFileName(int i) 
	{
		String[] filename={""};
		String[] splitfilename={""};
		if(ctbrTable.isPresent()){
			WebElementFacade actualexpandRow = find(By.xpath(expandRows.replace("xxx", Integer.toString(i))));
				actualexpandRow.click();
				for(int j=1;j<=ctbrFileExpandBtn.size();j++){
					WebElementFacade actualFileName = find(By.xpath(ctbrfileXpath.replace("xxx",Integer.toString(i+1))));
					splitfilename = actualFileName.getText().toString().split("-");
					filename [i+j+1] =splitfilename[0].trim();
			}
		}
		return filename;
	}

	public int getContrFileCount() 
	{
		int count=0;
		String actual;
		if(ctbrTable.isPresent()){
			for(WebElementFacade abc: fileExpandButton){
					//UIHelper.highlightElement(getDriver(), abc);
					abc.click();
					UIHelper.waitForPageToLoad(getDriver());
					UIHelper.highlightElement(getDriver(), ctbrFileCount);
					actual=ctbrFileCount.getText();
					count= count + Integer.parseInt(actual);
					UIHelper.highlightElement(getDriver(), ctbrPopupCloseBtn);
					ctbrPopupCloseBtn.click();
			}
		}
		return count;
	}

	public String  getCTBRReceivedDate(int i) throws Exception
	{
		String actualreceivedDate="";
		if(ctbrTable.isPresent()){
			WebElementFacade actualDate = find(By.xpath(fileReceivedDate.replace("xxx",Integer.toString(i))));
				actualreceivedDate= actualDate.getText();
				DateFormat df = new SimpleDateFormat("dd=MMM-YYYY");
				Date receivedDate = df.parse(actualreceivedDate);
				actualreceivedDate = df.format(receivedDate);
		}
		return actualreceivedDate;
	}

	public String GetStartTimeStamp() 
	{
		if(startTime.isPresent()){
			UIHelper.highlightElement(getDriver(), startTime);
			String actual[]= startTime.getText().split(" ");
			return actual[0];
					
		}else{
			return "";
		}
	}

	public boolean verifyContributorDetails(String query) throws Exception
	{
		int ctbrFileCount = getContrFileCount();
		for (int i=0;i<=ctbrFileCount;i++){
			String receivedDate = getCTBRReceivedDate(i+2);
			for(int j=1;j<=ctbrFileExpandBtn.size();j++){
				String ctbrFileName[] = getCTBRFileName(i+2);
				WebElementFacade expbtn = find(By.xpath(ctbrexpandbtn.replace("xxx",Integer.toString(i+2))));
				expbtn.click();
				UIHelper.waitForPageToLoad(getDriver());
				query = query.replace("FILENAME", ctbrFileName[i+2]).replace("CURRENTDATE", receivedDate);
				
				int curraccCount = executeQuery(query, "ACCT_CNT");
				result = compareValues(curraccCount, element(ctbrAccCount).getText());
				accCount = accCount + curraccCount;
				
				int cuurcrrAccCount= executeQuery(query, "VLD_CRCT_ACCT_CNT");
				result = compareValues(cuurcrrAccCount, element(ctbrCrrAccCount).getText());
				crrAccCount = crrAccCount + cuurcrrAccCount;
				
				int currfailAccCount = executeQuery(query, "FAILD_ACCT_CNT");
				result = compareValues(currfailAccCount, element(ctbrFailAccCount).getText());
				failAccCount = failAccCount + currfailAccCount;
				
				recCount= recCount + executeQuery(query,"TOT_REC_CNT");
				ctbrPopUpCloseBtn.click();
			}
		}
		if(result != ""){
			return true;
		}else{
		return false;
	}
	}
	
	
	private String compareValues(int count1, String element1) 
	{
		String count = Integer.toString(count1);
		if(count.equals(element1)){
			result = "true";
		}
		return result;
	}

	private int executeQuery(String sqlquery1, String columnName) throws SQLException, ClassNotFoundException
	{
		int count=0;
		Class.forName("oracle.jdbc.driver.OracleDriver"); 
	    Connection con = DriverManager.getConnection("jdbc:oracle:thin:@sbfqa-scan.us.dnb.com:1521/sbfdsqa" ,"SBFEOWNER","SBFEOWNER");
	    Statement st=con.createStatement();
	    //String sqlquery1= "select SBFE_CTBR_NBR from sbfe_ctbr where sbfe_ctbr_id="+ContributorID;
	    ResultSet rs=st.executeQuery(sqlquery1);         
	    if(rs.next()){
	    count=rs.getInt(columnName);
	    }
	    return count;

	}

	public boolean verifyAccountCount() 
	{
		boolean flag =false;
		if(element(accountCount).isPresent()){
		UIHelper.highlightElement(getDriver(), accountCount);
		String count=accountCount.getText().toString().trim();
		if(count.equals(Integer.toString(accCount))){
			flag= true;
		}
	}
	return flag;
	}

	public String verifyFileName(String fileName) 
	{
		String filename = null;
		if(!fileNameinCTBR.isEmpty()){
			for(WebElementFacade abc : fileNameinCTBR){
			 filename = abc.getText();
			  if(filename.equals(fileName)){
				  break;
			  }
		}
		}else
		{
			filename = null;
		}
		return filename;
	}

	public boolean verifyFileDetails(String fileName, String query1) throws Exception
	{
		int ctbrFileCount = getContrFileCount();
		for (int i=0;i<=ctbrFileCount;i++){
			String receivedDate = getCTBRReceivedDate(i+2);
			for(int j=1;j<=ctbrFileExpandBtn.size();j++){
				String ctbrFileName[] = getCTBRFileName(i+2);
				WebElementFacade expbtn = find(By.xpath(ctbrexpandbtn.replace("xxx",Integer.toString(i+2))));
				expbtn.click();
				UIHelper.waitForPageToLoad(getDriver());
				query1 = query1.replace("FILENAME", ctbrFileName[i+2]).replace("CURRENTDATE", receivedDate);
				
				int curraccCount = executeQuery(query1, "ACCT_CNT");
				result = compareValues(curraccCount, element(ctbrAccCount).getText());
				accCount = accCount + curraccCount;
				
				int cuurcrrAccCount= executeQuery(query1, "VLD_CRCT_ACCT_CNT");
				result = compareValues(cuurcrrAccCount, element(ctbrCrrAccCount).getText());
				crrAccCount = crrAccCount + cuurcrrAccCount;
				
				int currfailAccCount = executeQuery(query1, "FAILD_ACCT_CNT");
				result = compareValues(currfailAccCount, element(ctbrFailAccCount).getText());
				failAccCount = failAccCount + currfailAccCount;
				
				recCount= recCount + executeQuery(query1,"TOT_REC_CNT");
				ctbrPopUpCloseBtn.click();
			}
		}
		if(result != ""){
			return true;
		}else{
		return false;
	}
		}

	public String verifyFileValidationStatus() throws Exception
	{
		String status = null;
		if(filevalidation.isPresent()){
			waitForProcessComplete(fileStatus);
			status = filevalidation.getText().toString().trim();
		}else {
			status = null;
		}
		return status;
	}

	private void waitForProcessComplete(String element) throws Exception
	{
		Thread.sleep(1000);
		WebElementFacade stepStatus = find(By.xpath(element));
		String Status = stepStatus.getText().toString().trim();
		/*do{
			getDriver().navigate().refresh();
			UIHelper.waitForPageToLoad(getDriver());
		}while (!Status.equals("Completed"));*/
	}

	public String verifyRecordValidationStatus() throws Exception
	{
		String status = null;
		if(recordvalidation.isPresent()){
			waitForProcessComplete(recordStatus);
			status = recordvalidation.getText().toString().trim();
		}else {
			status = null;
		}
		return status;
	}
}

