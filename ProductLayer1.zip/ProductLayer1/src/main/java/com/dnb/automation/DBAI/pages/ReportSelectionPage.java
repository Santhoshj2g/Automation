package com.dnb.automation.DBAI.pages;

import java.util.concurrent.TimeUnit;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by 630239 on 5/9/2017.
 */
public class ReportSelectionPage extends PageObject {

    private String Duns="//table/tbody/tr/td/b[contains(text(),'D-U-N-S')]/parent::td[contains(text(),'DUNS')]]";

    @FindBy(xpath="//a/img[contains(@src,'order_en')]")
    private WebElementFacade reportbtn;

    @FindBy(xpath=".//*[@id='TRProd153']/input[contains(@value,'European Report')]/parent::div/input[@type='RADIO']")
    private WebElementFacade selectreportOption;
    
    @FindBy(xpath=".//*[@id='TRProd80']/input[contains(@value,'80')]")
    private WebElementFacade selectCompReport;
    
    @FindBy(xpath=".//*[@id='TRProd79']/input[contains(@value,'79')]")
    private WebElementFacade selectCompactReport;
    
    @FindBy(id="TRProd153")
    private WebElementFacade selectEuropeanReport;
    
    @FindBy(name="MonitorAll_Dup")
    private WebElementFacade monitoringCheckbox;

    public boolean verifyDunsNo(String duns) {
        getDriver().switchTo().defaultContent();
        switchToFrame(getDriver(), "Main");
        UIHelper.waitForPageToLoad(getDriver());
        String actualDunsXpath = Duns.replace("DUNS", duns);
        WebElementFacade actualDuns =find(By.xpath(actualDunsXpath)) ;
        UIHelper.highlightElement(getDriver(),actualDuns);
        String actual =actualDuns.getText();
            if(actual.contains(duns))
                return true;
            else
                return false;
        }

    public void clickFreeRptBtn() {

        UIHelper.highlightElement(getDriver(),reportbtn);
        reportbtn.click();
    }


    private void switchToFrame(WebDriver driver, String frameName) {
        driver.switchTo().frame(frameName);
    }

 /*   public void selectReport(String reportname) {
        UIHelper.waitForPageToLoad(getDriver());
        getDriver().switchTo().defaultContent();
        getDriver().switchTo().frame("Main");
        UIHelper.waitForPageToLoad(getDriver());
        if(selectreportOption.isPresent()) {
            UIHelper.highlightElement(getDriver(), selectreportOption);
            selectreportOption.click();
        }    
    }*/
    
    public void selectReport(String reportname) {
        UIHelper.waitForPageToLoad(getDriver());
        getDriver().switchTo().defaultContent();
        getDriver().switchTo().frame("Main");
        UIHelper.waitForPageToLoad(getDriver());
        if(reportname.contains("Comprehensive"))
        {
           if(selectCompReport.isPresent()) {
               UIHelper.highlightElement(getDriver(), selectCompReport);
               selectCompReport.click();
           }
        }
        else if(reportname.contains("Compact"))
        {
            if(selectCompactReport.isPresent()) {
                UIHelper.highlightElement(getDriver(), selectCompactReport);
                selectCompactReport.click();
            }
        }
        else if(reportname.contains("European"))
        {
            if(selectEuropeanReport.isPresent()) {
                UIHelper.highlightElement(getDriver(), selectEuropeanReport);
                selectEuropeanReport.click();
            }
        }
    }
    
    public void uncheckMonitoring(){
        UIHelper.waitForPageToLoad(getDriver());
        if(monitoringCheckbox.isPresent()){
        	if(monitoringCheckbox.isSelected()){
                UIHelper.highlightElement(getDriver(), monitoringCheckbox);
        		monitoringCheckbox.click();
        	}
        }
    }
}

