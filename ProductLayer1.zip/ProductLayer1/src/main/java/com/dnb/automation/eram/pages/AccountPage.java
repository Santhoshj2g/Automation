package com.dnb.automation.eram.pages;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import com.google.common.base.Predicate;


public class AccountPage extends PageObject {
	 public static final int HIGHLIGHTERINT = 5;
	 private final Logger log=Logger.getLogger(this.getClass().getPackage().getName());
	 public static final int MINPOLLINGTIME = 100;
	  @FindBy(xpath = "//*/div[contains(@class,'x-form-item-body')]//*/div/input[@name='username']")
	  private WebElementFacade unameBox;
	
	  @FindBy(xpath = "//*/div[contains(@class,'x-form-item-body')]//*/div/input[@name='pwd']")
	  private WebElementFacade pwordBox;
	  
	  @FindBy(xpath = "//*[contains(@class,'x-form-item-body')]//*/div/input[@name='database']")
	  private WebElementFacade dataBaseBox;
	  
	  @FindBy(xpath = "//*[@id='newButton-btnInnerEl']")
	  private WebElementFacade createAccountNewBtn;
	  
	  @FindBy(xpath = "//span[contains(@id,'ACCOUNTS-btnInnerEl')]/div[contains(.,'ACCOUNTS')]")
	  private WebElementFacade accountsTab;
	  
	  @FindBy(xpath = "//*[contains(@id,'customerinfoview') and contains(@id,'innerCt')]//*[contains(@id,'toolbar') and contains(@id,'innerCt')]//*[contains(@id,'label')]/h2")
	  private WebElementFacade customerAccInfoHeader;
	  
	  @FindBy(xpath = "//span[contains(@id,'templatebutton') and contains(.,'Create')]")
	  private WebElementFacade accountsCreateBtn;
	  
	  @FindBy(xpath = "//*[@id='topFirstId-innerCt']//label[@id='topFirstData']")
	  private WebElementFacade createdAccName;
	  
	  @FindBy(xpath = "//*[@id='topFirstId-innerCt']//label[@id='topSecData']")
	  private WebElementFacade createdAccNumber;
	  
	  @FindBy(xpath = "//a[contains(@id,'templatebutton')]//span[contains(@id,'btnInnerEl') and contains(.,'Ok')]")
	  private WebElementFacade oIpOkBtn;
	  
	  @FindBy(xpath = "//*[contains(@id,'gridview')]//div[@class='x-grid-item-container']//table[@data-recordindex='0']/tbody/tr/td/div")
	  private WebElementFacade orderStatusElement;
	  
	  @FindBy(xpath = "//*[@id='communicationqueueid']//*[@id='communicationqueueid_header-targetEl']//div[contains(.,'::after')]")
	  private WebElementFacade orderStatusCloseImage;
	  
	  @FindBy(xpath = "//*[@id='fltrButtonId-btnInnerEl']")
	  private WebElementFacade filterBtn;
	  
	  @FindBy(xpath = "//*[@id='fltrButtonId-btnInnerEl']/span")
	  private WebElementFacade selectedFilter;
	  
	  @FindBy(xpath = "//*[@id='eramtoolbar-innerCt']//*[@id='displayItem']")
	  private WebElementFacade pageCount;
	  
	  @FindBy(xpath = "//*[@id='next-btnInnerEl']")
	  private WebElementFacade accNextBtn;
	  
	  @FindBy(xpath = "//*[@id='accountgridID-body']//table[1]/tbody/tr/td/div")
	  private WebElementFacade accFirstRecord;
	  
	  @FindBy(xpath = "//*[@id='editid-btnInnerEl']")
	  private WebElementFacade editIcon;
	  
	  @FindBy(xpath = "//*[@id='newAccId-inputEl']")
	  private WebElementFacade newAccountNoField;
	  
	  @FindBy(xpath = "//*[@id='accEditSavebtnId-btnInnerEl']")
	  private WebElementFacade editOKBtn;
	  
	  @FindBy(xpath = "//*[@id='deleteid-btnInnerEl']")
	  private WebElementFacade deleteIcon;
	  
	  @FindBy(xpath = "//*[contains(@id,'toolbar')]//*[contains(@id,'toolbar') and contains(@id,'innerCt')]//a//span//span[contains(@id,'button') and contains(.,'Delete')]")
	  private WebElementFacade confirmationdeleteBtn;
	  
	  @FindBy(xpath = "//*[@id='radio1-boxLabelEl']")
	  private WebElementFacade deleteAccountradioBtn;
	  
	  @FindBy(xpath = "//*[@id='radio2-boxLabelEl']")
	  private WebElementFacade DeleteDNBInforadioBtn;
	  
	  @FindBy(xpath = "//*[@id='radio3-boxLabelEl']")
	  private WebElementFacade DeletePrincipalInforadioBtn;
	  
	  @FindBy(xpath = "//span[contains(@id,'ANALYSIS-btnInnerEl')]//div[contains(.,'ANALYSIS')]")
	  private WebElementFacade analysisBtn;
	  
	  @FindBy(xpath = "//span[contains(@id,'DASHBOARD-btnInnerEl')]//div[contains(.,'DASHBOARD')]")
	  private WebElementFacade dashboardTab;
	  
	  @FindBy(xpath = "//*[@id='iagreeid']")
	  private WebElementFacade iAgreeBtn;
	  
	  @FindBy(xpath = "//*[@id='searchbarid-innerCt']//*[contains(@id,'textfield') and contains(@id,'bodyEl')]//input[contains(@id,'textfield') and contains(@id,'inputEl')]")
	  private WebElementFacade companyNameOrDunsTextbox;
	  
	  @FindBy(xpath = "//*[@id='searchbarid-innerCt']//div[contains(@class,'x-field x-combo-country')]//*[contains(@id,'combo') and contains(@id,'bodyEl')]//input[contains(@id,'combo') and contains(@id,'inputEl')]")
	  private WebElementFacade countryField;
	  
	  @FindBy(xpath = "//*[@id='searchbarid-innerCt']//div[contains(@class,'x-field x-combo-state')]//*[contains(@id,'combo') and contains(@id,'bodyEl')]//input[contains(@id,'combo') and contains(@id,'inputEl')]")
	  private WebElementFacade stateField;
	  
	  @FindBy(xpath = "//*[@id='searchbarid-innerCt']//div[contains(@class,'x-field x-combo-country')]//*[contains(@id,'combo') and contains(@id,'bodyEl')]//div[contains(@id,'combo') and contains(@id,'trigger-picker')]")
	  private WebElementFacade countryListbox;
	  
	  @FindBy(xpath = "//*[@id='searchbarid-innerCt']//div[contains(@class,'x-field x-combo-state')]//*[contains(@id,'combo') and contains(@id,'bodyEl')]//div[contains(@id,'combo') and contains(@id,'trigger-picker')]")
	  private WebElementFacade stateListbox;
	  
	  @FindBy(xpath = "//*[@id='searchbuttonid-btnIconEl']")
	  private WebElementFacade searchBtn;
	  
	  @FindBy(xpath = "//*[@id='searchdnbgridviewId-body']//table[1]/tbody//tr/td//a[contains(@id,'templatebutton')]//span[contains(@id,'templatebutton') and contains(@id,'btnInnerEl') and contains(.,'+ Account')]")
	  private WebElementFacade addAccountBtn;
	  
	  @FindBy(xpath = "//*[@id='accSrchTypId-inputEl']")
	  private WebElementFacade searchType;
	  
	  @FindBy(xpath = "//*[@id='accSrchTypId-trigger-picker']")
	  private WebElementFacade accsearchTypeListBox;
	  
	  @FindBy(xpath = "//*[@id='accSrchFldId-inputEl']")
	  private WebElementFacade accSearchField;
	  
	  @FindBy(xpath = "//*[@id='exactMatchSrchId-boxLabelEl']")
	  private WebElementFacade exactMatchCheckbox;
	  
	  @FindBy(xpath = "//*[@id='accSrchbtnid-btnIconEl']")
	  private WebElementFacade accsearchBtn;
	  
	  @FindBy(xpath = "//*[contains(@id,'messagebox') and contains(@id,'toolbar-innerCt')]//span[contains(@id,'button') and contains(@id,'btnInnerEl') and contains(.,'OK')]")
	  private WebElementFacade accNotMatchOkBtn;
	  	  
	  @FindBy(xpath = "//*[@id='scoreid-btnInnerEl']")
	  private WebElementFacade accScoreBtn;
	  
	  @FindBy(xpath = "//*[@id='scrcurraccid-boxLabelEl']")
	  private WebElementFacade ScorecurrentaccountOption;
	  
	  @FindBy(xpath = "//*[@id='scrselaccid-boxLabelEl']")
	  private WebElementFacade ScoreselectedaccountsOption;
	  
	  @FindBy(xpath = "//*[@id='scraccfltrid-boxLabelEl']")
	  private WebElementFacade ScoreaccountsincurrentfilterOption;
	  
	  @FindBy(xpath = "//*[@id='scrallaccid-boxLabelEl']")
	  private WebElementFacade ScoreallaccountsOption;
	  
	  @FindBy(xpath = "//*[@id='savescoreid-boxLabelEl']")
	  private WebElementFacade saveScoreDetailsCheckbox;
	  	

	  @FindBy(xpath = "//*[@id='greenbuttonviewid-btnInnerEl']")
	  private WebElementFacade scoreOKBtn;
	  
	  @FindBy(xpath = "//span[contains(@id,'templatebutton') and contains(@id,'btnInnerEl') and contains(.,'Schedule')]")
	  private WebElementFacade scoreScheduleBtn;
	  
	  @FindBy(xpath = "//*[@id='SCORE-btnEl']")
	  private WebElementFacade accPageScoreBtn;
	  
	  @FindBy(xpath = "//*[@id='firstInfoPanel-innerCt']//label[contains(.,'RAM Score')]//following-sibling::label[1]")
	  private WebElementFacade ramScoreCount;
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Credit Analysis')]")
	  private WebElementFacade creditAnalysisTab;
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'SBRI Info')]")
	  private WebElementFacade sBRIInfoTab;
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'D&B Account Info')]")
	  private WebElementFacade dandBAccountInfoTab;
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Corp. Exposure')]")
	  private WebElementFacade corpExposureTab;
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'D&B Scores')]")
	  private WebElementFacade dandBScoresTab;
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Customer Account Info')]")
	  private WebElementFacade customerAccountInfoTab;
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Custom Fields')]")
	  private WebElementFacade customFieldsTab;
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Bank References')]")
	  private WebElementFacade bankReferencesTab;
	  
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Trade References')]")
	  private WebElementFacade tradeReferencesTab;
	  
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'List')]")
	  private WebElementFacade listTab;
	  
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Comparison')]")
	  private WebElementFacade comparisonTab;
	  
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Variance')]")
	  private WebElementFacade varianceTab;
	  
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Cash Flow Analysis')]")
	  private WebElementFacade cashFlowAnalysisTab;
	  
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Principal Info')]")
	  private WebElementFacade principalInfoTab;
	  
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Small Business Info')]")
	  private WebElementFacade smallBusinessInfoTab;
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Documents')]")
	  private WebElementFacade documentsTab;
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Notes & To-Do')]")
	  private WebElementFacade notesToDosTab;
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'D&B Info')]")
	  private WebElementFacade DandBInfoTab;
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Customer Info')]")
	  private WebElementFacade customerInfoTab;
	  
	  @FindBy(xpath = "//*[@id='treemenuviewid-body']//table[contains(@id,'treeview') and contains(@id,'record')]/tbody/tr/td//span[contains(.,'Financials')]")
	  private WebElementFacade financialsTab;
	  
	  @FindBy(xpath = "//*[@id='exportid-btnInnerEl']")
	  private WebElementFacade exprotIcon;
	  
	  
	  @FindBy(xpath = "//*[@id='last-btnInnerEl']")
	  private WebElementFacade accLastBtn;
	  
	  @FindBy(xpath = "//*[@id='prev-btnInnerEl']")
	  private WebElementFacade accPreviousBtn;
	  
	  @FindBy(xpath = "//*[@id='first-btnInnerEl']")
	  private WebElementFacade accFirstBtn;
	  
	  @FindBy(xpath = "//a[contains(@id,'templatebutton')]//span[contains(@id,'btnInnerEl') and contains(.,'Cancel')]")
	  private WebElementFacade oIpCancelBtn;

	  @FindBy(xpath = "//*[@id='topPanelViewId-innerCt']//a[@id='FIND']//*[@id='FIND-btnWrap']//span[@id='FIND-btnInnerEl' and contains(.,'Find')]")
	  private WebElementFacade accFindtBtn;
	  
	  @FindBy(xpath = "//*[@id='PRINT-btnInnerEl']")
	  private WebElementFacade accPrintBtn;
	  
	  @FindBy(xpath = "//*[@id='findCmbId-trigger-picker']")
	  private WebElementFacade findByListbox;
	  	  
	  @FindBy(xpath = "//*[@id='findCmbId-inputEl']")
	  private WebElementFacade findByListbox1;
	  
	  @FindBy(xpath = "//*[@id='findSrchFldId-inputEl']")
	  private WebElementFacade accfindTextbox;
	  
	  @FindBy(xpath = "//*[@id='findpopupviewid-innerCt']//label[contains(@id,'checkbox') and contains(@id,'boxLabelEl') and contains(.,'Exact Match')]")
	  private WebElementFacade findExactMatchCheckbox;
	  
	  
	  @FindBy(xpath = "//*[@id='greenbuttonviewid-btnInnerEl']")
	  private WebElementFacade accfindOKbtn;
	  
	  @FindBy(xpath = "//*[@id='sumByButtonId-btnInnerEl']")
	  private WebElementFacade accSumByButton;
	  
	  @FindBy(xpath = "//*[@id='sumbyId-trigger-picker']")
	  private WebElementFacade accsumByListbox;
	  
	  @FindBy(xpath = "//span[contains(@id,'processbutton') and contains(@id,'btnInnerEl') and contains(.,'OK')]")
	  private WebElementFacade accSumByPopupOKButoon;
	  
	  @FindBy(xpath = "//*[@id='SumByGridId']//*[@id='SumByGridId-body']//table/tbody")
	  private WebElementFacade accsumByTable;
	  
	  @FindBy(xpath = "//*[@id='SumByGridId']//*[@id='SumByGridId-body']//table")
	  private List <WebElementFacade> accsumByTablerows;
	  
	  @FindBy(xpath = "//*[@id='sum-boxLabelEl']")
	  private WebElementFacade accsumBySumRadioBtn;
	  
	  @FindBy(xpath = "//*[@id='avg-boxLabelEl']")
	  private WebElementFacade accsumByAvgRadiobtn;
	  
	  @FindBy(xpath = "//*[@id='accountgridID-body']//table/tbody")
	  private WebElementFacade accResultsTableElement;
	  
	  @FindBy(xpath = "//*[@id='editColButtonId-btnInnerEl']")
	  private WebElementFacade EditColumnBtn;
	  
	  @FindBy(xpath = "//span[contains(@id,'button') and contains(@id,'btnInnerEl') and contains(.,'Add')]")
	  private WebElementFacade editColumnAddBtn;
	  
	  @FindBy(xpath = "//span[contains(@id,'button') and contains(@id,'btnInnerEl') and contains(.,'Remove')]")
	  private WebElementFacade editColumnRemoveBtn;
	  
	  @FindBy(xpath = "//*[@id='saveAsBtnId-btnInnerEl']")
	  private WebElementFacade editColumnSaveAsBtn;
	  
	  @FindBy(xpath = "//*[contains(@id,'multiselectfield') and contains(@id,'innerCt')]//div[contains(@id,'panel') and contains(@id,'header') and contains(.,'Available Fields')]//following-sibling::div[1]//ul[contains(@id,'boundlist')]//li")
	  private List <WebElementFacade> availableFieldsList;
	  
	  @FindBy(xpath = "//*[contains(@id,'multiselectfield') and contains(@id,'innerCt')]//div[contains(@id,'panel') and contains(@id,'header')]//div[contains(.,'Available Fields')]")
	  private WebElementFacade availableFieldsBox;
	  
	  @FindBy(xpath = "//*[@id='selectColmnId-innerCt']")
	  private WebElementFacade editColumnpopup1;
	  
	  @FindBy(xpath = "//*[contains(@id,'multiselectfield') and contains(@id,'innerCt')]//div[contains(@id,'panel') and contains(@id,'header') and contains(.,'Selected Fields')]//following-sibling::div//ul[contains(@id,'boundlist')]//li")
	  private List <WebElementFacade> selectedFieldsList;
	  
	  @FindBy(xpath = "//span[contains(@id,'processbutton') and contains(.,'Cancel')]")
	  private WebElementFacade editColumnCancelBtn;
	  	  
	  @FindBy(xpath = "//*[@id='proflNme-inputEl']")
	  private WebElementFacade enterProfileName;
	  
	  @FindBy(xpath = "/*[@id='saveAsUsrId-boxLabelEl']")
	  private WebElementFacade userProfileRadioBtn;
	  
	  @FindBy(xpath = "//*[@id='saveAsGrpId-boxLabelEl']")
	  private WebElementFacade groupProfileRadioBtn;
	  
	  @FindBy(xpath = "//*[@id='saveAsGblId-boxLabelEl']")
	  private WebElementFacade globalProfileRadioBtn;
	  
	  @FindBy(xpath = "//*[@id='allGrpSaveAsId-trigger-picker']")
	  private WebElementFacade groupProfileListbox;
	  
	  @FindBy(xpath = "//span[contains(@id,'processbutton') and contains(.,'OK')]")
	  private WebElementFacade profileOKBtn;
	  
	  @FindBy(xpath = "//*[@id='prflBtnId-btnInnerEl']")
	  private WebElementFacade profileButton;
	  
	  @FindBy(xpath = "//*[@id='prflBtnId-btnInnerEl']/span")
	  private WebElementFacade selectedProfile;
	  
	  @FindBy(xpath = "//*[@id='saveBtnId-btnInnerEl']")
	  private WebElementFacade selectColumnPopupSaveBtn;
	  
	  @FindBy(xpath = "//*/div[contains(@id,'communicationqueueid-innerCt')]//*/div[contains(text(),'Product ordered Successfully.')]")
	  private WebElementFacade COM_QUE;
	  
	  @FindBy(id = "communicationqueueid")
	  private WebElementFacade Comqueuepopup;
	  
	  static String SavedProfileName;
	  public static String getSavedProfileName() {
		return SavedProfileName;
	}
	static String textFileAccNo;
	  public static String getTextFileAccNo() {
		return textFileAccNo;
	}
	  double allrowValue=0.0;
	  static double ramScoreSumcout;
	  
	public static double getRamScoreSumcout() {
		return ramScoreSumcout;
	}

	static double ramScoreText;
	
	static String accFirstRecordText;
	  
	  public static String getAccFirstRecordText() {
		return accFirstRecordText;
	}
	static String accFirstRecordNo;
	  public static String getAccFirstRecordNo() {
		return accFirstRecordNo;
	}
	  static String beforeEditaccFirstRecordNo;
	  
	  
	  public static String getBeforeEditaccFirstRecordNo() {
		return beforeEditaccFirstRecordNo;
	}
	  static String newAccNumber;
	  
	  public static String getNewAccNumber() {
		return newAccNumber;
	}
	  String loginBtnXpath="//a[@id='sign']//span[@id='sign-btnWrap']";
	  String accountsTableXpath="//*[@id='accountgridID-body']//table/tbody";
	  String createAccInforTableXpath="//*[contains(@id,'demographicsview')]//table[contains(@id,'ext-element')]";
	  String productListHeader="//*[@id='productlistid']//*[@id='productlistid-body']";
	  String orderInvestigationwindowXpath="//*[contains(@class,'x-window-default x-closable')]//*[contains(@id,'investigation') and contains(@id,'header')]";
	  String orderStatusPopup="//*[@id='communicationqueueid']//*[@id='communicationqueueid-body']";
	  String filterPopupXpath="//*[@id='filterPopupViewID-body']//*[@id='filtrPopupId-body']//table/tbody";
	  String accountPagheaderXpath="//*[@id='topPanelViewId']//*[@id=topPanelViewId-body]";
	  String eRamHomePageXpath="//span[contains(@id,'DASHBOARD-btnInnerEl')]";
	  String editAccPopup="//*[@id='editAccNumbrId-innerCt']";
	  String searchResultsTableXpath="//*[@id='searchdnbgridviewId-body']//table/tbody";
	  String ScoreOptionsPopupXpath="//label[contains(@id,'fieldcontainer') and contains(@id,'labelEl')]/span[contains(.,'Score Account')]";
	  String dashboardPageTableXpath="//*[@id='containeridtext1-innerCt']//*[@id='containerid1-innerCt']//*[@id='riskycompanyviewid-body']//table/tbody";
	  String CreditAnalysisbodyXpath="//*[@id='CreditTopPanelId-body']";
	  String accountinfoPagheaderXpath="//*[@id=topPanelViewId-body]";
	  String findPopupXpath="//*[@id='findpan-innerCt']";
	  String sumByPopupXpath="//*[@id=sumbypopupviewid-innerCt']";
	  String sumByAccountListPageXpath="//*[@id='SumByGridId']//*[@id='SumByGridId-body']//table/tbody";
	  String SelectColumnsPopup="//*[@id='selectColViewId-body']";
	  String createProfilePopupXpath="//*[@id='saveAsNewPrflId-body']";
	  String profilePopupXpath="//*[@id='profilePopGrid-body']//table/tbody";
	  public static void waitForVisibilityOfeRAMElements(final WebDriver driver,
	            String elementXpath) {

	        FluentWait<By> fluentWait = new FluentWait<By>(By.xpath(elementXpath));
	        fluentWait.pollingEvery(100, TimeUnit.MILLISECONDS);
	        fluentWait.withTimeout(600, TimeUnit.SECONDS);
	        fluentWait.until(new Predicate<By>() {
	            public boolean apply(final By by) {
	                try {

	                    return driver.findElement(by).isDisplayed();
	                } catch (Exception ex) {

	                    return false;
	                }
	            }
	        });
	    }
	  public static void waitForVisibilityOfeRAMElementsforlesstime(final WebDriver driver,
	            String elementXpath) {

	        FluentWait<By> fluentWait = new FluentWait<By>(By.xpath(elementXpath));
	        fluentWait.pollingEvery(100, TimeUnit.MILLISECONDS);
	        fluentWait.withTimeout(100, TimeUnit.SECONDS);
	        fluentWait.until(new Predicate<By>() {
	            public boolean apply(final By by) {
	                try {

	                    return driver.findElement(by).isDisplayed();
	                } catch (Exception ex) {

	                    return false;
	                }
	            }
	        });
	    }
	    
	 public static void highlightElement(final WebDriver driver,
	            final WebElement element) {

	        try {

	            for (int i = 0; i < HIGHLIGHTERINT; i++) {
	                JavascriptExecutor js = (JavascriptExecutor) driver;
	                js.executeScript(
	                        "arguments[0].setAttribute('style', arguments[1]);",
	                        element, "color: #800000; border: 2px solid blue;");
	            }
	        } catch (Exception e) {

	        }
	    }
	 
	 public static void mouseOverandElementdoubleClick(final WebDriver driver,
	            final WebElement element1) {

	        try {

	            Actions action = new Actions(driver);
	            highlightElement(driver, element1);

	            action.moveToElement(element1).doubleClick().build().perform();

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	 
	 public static void mouseOverandElementClick(final WebDriver driver,
	            final WebElement element1) {

	        try {

	            Actions action = new Actions(driver);
	           // highlightElement(driver, element1);
	            action.moveToElement(element1).click().build().perform();

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	 public static void mouseOveranElement(final WebDriver driver,
	            final WebElement element1) {

	        try {

	            Actions action = new Actions(driver);
	            
	             action.moveToElement(element1).build().perform();

	        } catch (Exception e) {

	        }
	    }
	 
	 public static void mouseOverAndHighlightanElement(final WebDriver driver,
	            final WebElement element1) {

	        try {

	            Actions action = new Actions(driver);
	            highlightElement(driver, element1);
	             action.moveToElement(element1).build().perform();

	        } catch (Exception e) {

	        }
	    }
	  
	 public static void waitForPageToLoad(final WebDriver driver) {
	        try {
	            (new WebDriverWait(driver, MINPOLLINGTIME))
	                    .until(new ExpectedCondition<Boolean>() {
	                        public Boolean apply(final WebDriver d) {
	                            return (((org.openqa.selenium.JavascriptExecutor) driver)
	                                    .executeScript("return document.readyState")
	                                    .equals("complete"));
	                        }
	                    });
	        } catch (Exception e) {

	        }
	    }
	 
		public void select_An_Option_From_List(WebElement element1,String Value){
			element1.click();
			waitFor(1000).milliseconds();
			String ValueXpath="//ul[contains(@id,'boundlist')]//li[.='"+Value+"']";
			log.log(Level.INFO,"Option Xpath --------------------- "+ValueXpath);
			WebElementFacade valueElement=find(By.xpath(ValueXpath));
			mouseOverAndHighlightanElement(getDriver(), valueElement);
			waitFor(500).milliseconds();
			valueElement.click();
			
		}
		
 
	 public static String append_Date_Format_To_Name(String Name){
			DateFormat dateFormat = new SimpleDateFormat("ddHHmmss");
	        Date date = new Date();
	        String date2= dateFormat.format(date);
	        String Name1=Name.trim()+date2.trim();
	        return Name1;
		}
		public static void write_Text_Into_File(String FileName,String WritenValue){
		
			try{
				String filePath1 = System.getProperty("user.dir");
				String mypath=filePath1.replace(":", ":\\");
				String filePath = mypath+FileName;
				System.out.println("File Path============"+filePath);
				FileWriter fstreamWrite = new FileWriter(filePath, false); //-- it will  over write
				BufferedWriter out = new BufferedWriter(fstreamWrite);
				out.write(WritenValue);
				out.write("\r\n");
				out.close();
				fstreamWrite.close();
			}catch(Exception e){
			
			}
		}
		
		public static String read_Text_From_File(String FileName){
			String line="";
			try{
				String filePath1 = System.getProperty("user.dir");
				String mypath=filePath1.replace(":", ":\\");
				String filePath = mypath+FileName;
				System.out.println("File Path============"+filePath);
				BufferedReader br = new BufferedReader(new FileReader(filePath));
				 line= br.readLine();
			    br.close();
			}catch(Exception e){
				
			}
			return line;
		}
	
	public void click_Accounts_Tab() {
		
		 try {
			 	accountsTab.isVisible();
			 	highlightElement(getDriver(), accountsTab);
			 	accountsTab.click();
			 	waitForVisibilityOfeRAMElements(getDriver(),accountsTableXpath);
			 	highlightElement(getDriver(), createAccountNewBtn);
	        	
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	     }
	public void click_Accounts_New_Btn() {
		
		 try {
			 	createAccountNewBtn.isVisible();
			 	createAccountNewBtn.click();
			 	waitForVisibilityOfeRAMElements(getDriver(),createAccInforTableXpath);
			 	highlightElement(getDriver(), customerAccInfoHeader);
	        	
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	     }
	public void enter_Account_Data_Into_Textfield(String FieldName,String Value){
		String FieldNameXpath="//label[contains(@id,'textfield') and contains(.,'"+FieldName+"')]//following-sibling::div[contains(@id,'textfield')]//input[contains(@id,'textfield')]";
		WebElementFacade fieldNameElement=find(By.xpath(FieldNameXpath));
		highlightElement(getDriver(), fieldNameElement);
		fieldNameElement.clear();
		fieldNameElement.type(Value);
		waitFor(200).milliseconds();
	}
	
	public void enter_Account_Data_Into_Combofield(String FieldName,String Value){
		String FieldNameXpath="//label[contains(@id,'combo') and contains(.,'"+FieldName+"')]//following-sibling::div[contains(@id,'combo')]//*[contains(@id,'combo') and contains(@id,'trigger-picker')]";
		String ValueXpath="//ul[contains(@id,'boundlist')]//li[.='"+Value+"']";
		WebElementFacade fieldNmeElement=find(By.xpath(FieldNameXpath));
		select_An_Option_From_List(fieldNmeElement,Value);
		/*highlightElement(getDriver(), fieldNmeElement);
		fieldNmeElement.click();
		waitFor(500).milliseconds();
		WebElementFacade valueElement=find(By.xpath(ValueXpath));
		highlightElement(getDriver(), valueElement);
		valueElement.click();
		waitFor(300).milliseconds();*/
	}
	public void click_Acc_Create_Button(){
		try{
			accountsCreateBtn.isVisible();
			highlightElement(getDriver(), accountsCreateBtn);
			accountsCreateBtn.click();
			waitForPageToLoad(getDriver());
			waitForVisibilityOfeRAMElements(getDriver(),createAccInforTableXpath);
			waitFor(7000).milliseconds();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public boolean verify_Account_has_Created(){
	
			createdAccName.isVisible();
			newAccNumber=createdAccNumber.getText().trim();
			return createdAccNumber.isVisible();
	}
	
	public void verify_Account_has_Created_And_Save_Acc_No(String FileName) throws Exception{
		try{
			createdAccName.isVisible();
			createdAccNumber.isVisible();
			newAccNumber=createdAccNumber.getText().trim();
			write_Text_Into_File(FileName, newAccNumber);
			/*String filePath1 = System.getProperty("user.dir");
	 		String mypath=filePath1.replace(":", ":\\");
	 		String filePath = mypath+FileName;
	 		System.out.println("File Path============"+filePath);
	         FileWriter fstreamWrite = new FileWriter(filePath, false); //-- it will  over write
	         BufferedWriter out = new BufferedWriter(fstreamWrite);
	         out.write(newAccNumber);
	         out.write("\r\n");
	         out.close();
	         fstreamWrite.close();*/
	
		}catch(Exception e){
			
		}
	}
	public void click_Ordere_Product_Btn_In_AccountInfor_page(){
		try{
			
			String ButtonNameXpath="//*[@id='ORDERPROD-btnInnerEl']";
			
			WebElementFacade ButtonNmeElement=find(By.xpath(ButtonNameXpath));
			highlightElement(getDriver(), ButtonNmeElement);
			ButtonNmeElement.click();
			waitForVisibilityOfeRAMElements(getDriver(), productListHeader);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void click_OrderInvestigation_Link_In_Order_Product(){
		try{
			String LinkNameXpath="//*[@id='productlistid']//*[@id='productlistid-innerCt']//table//tbody//div[contains(.,'Order Investigation')]";
			WebElementFacade LinkNmeElement=find(By.xpath(LinkNameXpath));
			highlightElement(getDriver(), LinkNmeElement);
			LinkNmeElement.click();
			waitForVisibilityOfeRAMElements(getDriver(), orderInvestigationwindowXpath);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void click_order_OkBtn(){

			oIpOkBtn.isVisible();
			highlightElement(getDriver(), oIpOkBtn);
			oIpOkBtn.click();
			waitForVisibilityOfeRAMElements(getDriver(), orderStatusPopup);
			
		
	}
	public boolean verify_OI_Status_has_Changed(){
			String OrderInvestigationStatus="";
			orderStatusElement.isVisible();
			highlightElement(getDriver(), orderStatusElement);
			do{
				waitFor(5000).milliseconds();
				OrderInvestigationStatus=orderStatusElement.getText().trim();
				System.out.println("Status-----------------"+OrderInvestigationStatus);
				}while(OrderInvestigationStatus.equals("Completed"));
			
			
			waitFor(2000).milliseconds();
			orderStatusCloseImage.click();
			waitForPageToLoad(getDriver());
			waitForVisibilityOfeRAMElements(getDriver(),createAccInforTableXpath);
			waitFor(10000).milliseconds();
		return true;	
		
	}
	
	public void click_Filter_Btn(){
		try{
			filterBtn.isVisible();
			highlightElement(getDriver(), filterBtn);
			filterBtn.click();
			waitForVisibilityOfeRAMElements(getDriver(), filterPopupXpath);
			
		}catch(Exception e){
			
		}
	}
	
	public void selected_Required_Filter_Name(String FilterName){
		try{
			String FilterNameXpath="//*[@id='filtrPopupId-body']//table[contains(@id,'gridview')]//tbody/tr/td/div[contains(.,'"+FilterName+"')]";
			WebElement FilterNameElement=getDriver().findElement((By.xpath(FilterNameXpath)));
			mouseOverandElementdoubleClick(getDriver(), FilterNameElement);
			waitFor(10000).milliseconds();
			waitForVisibilityOfeRAMElements(getDriver(),accountsTableXpath);
		 	highlightElement(getDriver(), filterBtn);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public String get_Selecte_Filter_Name(){
		return selectedFilter.getText().toString().trim();
	}
	
	public void account_Pagination(){
		mouseOveranElement(getDriver(),pageCount);
		String[] pagecount=pageCount.getText().trim().split("of");
		int pagecount1=Integer.parseInt(pagecount[1].trim());
		if(pagecount1 > 20){
			DecimalFormat df = new DecimalFormat("0"); //defining the decimal points foramt
			int pagecount2 = Integer.parseInt(df.format(pagecount1/20));
			log.log(Level.INFO,"page count--------------------- "+pagecount2);
				for(int i=1; i<pagecount2; i++){
					log.log(Level.INFO, "page no in loop -------------------- "+i);
					highlightElement(getDriver(), accNextBtn);
					accNextBtn.click();
					waitForPageToLoad(getDriver());
					waitForVisibilityOfeRAMElements(getDriver(),accountsTableXpath);
					waitFor(7000).milliseconds();
					if(i >=2){
						break;
					}
				}
			}
	}
	
	public void click_Acc_First_Record_Link(){
		waitFor(5000).milliseconds();
		accFirstRecordNo=accFirstRecord.getText().trim();
		mouseOverandElementdoubleClick(getDriver(), accFirstRecord);
		waitFor(7000).milliseconds();
	}
	public String get_Acc_No_In_Account_Page(){
		
		return createdAccNumber.getText().toString().trim();
	}
	
	public void edit_Account_Number(String AccountNumber){
		waitFor(5000).milliseconds();
		DateFormat dateFormat = new SimpleDateFormat("ddHHmmss");
        Date date = new Date();
        String date2= dateFormat.format(date);
		beforeEditaccFirstRecordNo=AccountNumber.trim()+date2.trim();
		accFirstRecord.click();
		waitFor(2000).milliseconds();
		mouseOveranElement(getDriver(), editIcon);
		editIcon.click();
		waitForVisibilityOfeRAMElements(getDriver(),editAccPopup);
		waitFor(3000).milliseconds();
		newAccountNoField.sendKeys(beforeEditaccFirstRecordNo);
		editOKBtn.click();
		waitForPageToLoad(getDriver());
		waitForVisibilityOfeRAMElements(getDriver(),accountsTableXpath);
		waitFor(7000).milliseconds();
		
	}
	
public String get_Acc_No_In_AccountFilter_Page(){
		log.log(Level.INFO,"Expected Edit Account Name ================= "+beforeEditaccFirstRecordNo);
		String recordAccnoxpath="//*[@id='accountgridID-body']//table/tbody/tr/td/div[contains(.,'"+beforeEditaccFirstRecordNo+"')]";
		waitFor(4000).milliseconds();
		WebElementFacade editAccnoele=find(By.xpath(recordAccnoxpath));
		editAccnoele.click();
		log.log(Level.INFO,"Acctual Edit Account Name +++++++++++++++++ "+editAccnoele.getText());
		return editAccnoele.getText().toString().trim();
	}

public void Delete_An_Account(String DeleteOption){
	waitFor(5000).milliseconds();
	accFirstRecord.click();
	waitFor(2000).milliseconds();
	deleteIcon.click();
	waitFor(5000).milliseconds();
	if(DeleteOption.equals("Delete Account")){
		highlightElement(getDriver(), deleteAccountradioBtn);
		deleteAccountradioBtn.click();
	}else if(DeleteOption.equals("Delete DNB Info")){
		highlightElement(getDriver(), DeleteDNBInforadioBtn);
		DeleteDNBInforadioBtn.click();
	}else if(DeleteOption.equals("Delete Principal Info")){
		highlightElement(getDriver(), DeletePrincipalInforadioBtn);
		DeletePrincipalInforadioBtn.click();
	}
	highlightElement(getDriver(), confirmationdeleteBtn);
	confirmationdeleteBtn.click();
	waitFor(7000).milliseconds();
	waitForPageToLoad(getDriver());
	waitForVisibilityOfeRAMElements(getDriver(),accountsTableXpath);
}

public void click_Analysis_Tab(){
	analysisBtn.isVisible();
	analysisBtn.click();
	waitFor(7000).milliseconds();
	
}

public void click_DashboardTab(){
	dashboardTab.isVisible();
	dashboardTab.click();
	 if(iAgreeBtn.isVisible()){
   	  	highlightElement(getDriver(), iAgreeBtn);
   	  	iAgreeBtn.click();
   	  }
	 waitForVisibilityOfeRAMElements(getDriver(), eRamHomePageXpath);
	waitFor(5000).milliseconds();
	
}

public void perform_Search(String Country, String State, String CompanyName){
	waitForVisibilityOfeRAMElements(getDriver(), dashboardPageTableXpath);
	countryField.isVisible();
	if(!Country.equals(null)){
		countryField.type(Country);
		countryField.sendKeys(Keys.ESCAPE);
		waitFor(300).milliseconds();
	}
	if(!State.equals(null)){
		stateField.type(State);
		stateField.sendKeys(Keys.ESCAPE);
		waitFor(300).milliseconds();
	}
	if(!CompanyName.equals(null)){
		companyNameOrDunsTextbox.type(CompanyName);
		waitFor(500).milliseconds();
	}
	searchBtn.click();
	waitForVisibilityOfeRAMElements(getDriver(), searchResultsTableXpath);
	waitFor(5000).milliseconds();
	
}
public void click_Account_Button_In_FromSearch_Resutls(){
	addAccountBtn.isVisible();
	highlightElement(getDriver(), addAccountBtn);
	addAccountBtn.click();
 	waitForVisibilityOfeRAMElements(getDriver(),createAccInforTableXpath);
 	highlightElement(getDriver(), customerAccInfoHeader);
 	waitFor(8000).milliseconds();
}

public void acc_Search_wtih_Accno(){
	searchType.isVisible();
	searchType.type("Account Number");
	searchType.sendKeys(Keys.ESCAPE);
	accSearchField.sendKeys(newAccNumber);
	exactMatchCheckbox.click();
	accsearchBtn.click();
	if(accNotMatchOkBtn.isVisible()){
   	  	highlightElement(getDriver(), accNotMatchOkBtn);
   	  	accNotMatchOkBtn.click();
   	  }
	waitFor(7000).milliseconds();
	waitForPageToLoad(getDriver());
	waitForVisibilityOfeRAMElements(getDriver(),accountsTableXpath);
 	
}

public String get_Acc_No_In_Accountresults_Page(){
	log.log(Level.INFO,"Expected Account Number ================= "+newAccNumber);
	String recordAccnoxpath="//*[@id='accountgridID-body']//table/tbody/tr/td/div[contains(.,'"+newAccNumber+"')]";
	WebElementFacade editAccnoele=find(By.xpath(recordAccnoxpath));
	mouseOveranElement(getDriver(), editAccnoele);
	editAccnoele.click();
	log.log(Level.INFO,"Acctual Account Number +++++++++++++++++ "+editAccnoele.getText());
	return editAccnoele.getText().toString().trim();
}

public void click_Score_Btn(){
	accScoreBtn.isVisible();
	accScoreBtn.click();
	waitForVisibilityOfeRAMElements(getDriver(),ScoreOptionsPopupXpath);
}

public void select_Score_Acc_Option(String ScoreOption){
	log.log(Level.INFO,"Score Option has to select ================= "+ScoreOption);
	highlightElement(getDriver(), scoreOKBtn);
	if(ScoreOption.equals("Score current account")){
		highlightElement(getDriver(), ScorecurrentaccountOption);
		ScorecurrentaccountOption.click();
	}else if(ScoreOption.equals("Score selected accounts")){
		highlightElement(getDriver(), ScoreselectedaccountsOption);
		ScoreselectedaccountsOption.click();
	}else if(ScoreOption.equals("Score accounts in current filter")){
		highlightElement(getDriver(), ScoreaccountsincurrentfilterOption);
		ScoreaccountsincurrentfilterOption.click();
	}else if(ScoreOption.equals("Score all accounts")){
		highlightElement(getDriver(), ScoreallaccountsOption);
		ScoreallaccountsOption.click();
	}
	waitFor(200).milliseconds();
	saveScoreDetailsCheckbox.click();
	waitFor(200).milliseconds();
	scoreOKBtn.click();
	waitFor(5000).milliseconds();
	if(scoreScheduleBtn.isVisible()){
		/*WebElementFacade scheduleOptionele=find(By.xpath(scheduleOptionXpath));
   	  	highlightElement(getDriver(), scheduleOptionele);
   	  	scheduleOptionele.click();*/
   	  	scoreScheduleBtn.click();
   	  	waitFor(7000).milliseconds();
   	  }

}

public void select_First_Ac_Record(){
	waitFor(5000).milliseconds();
	accFirstRecord.click();
	waitFor(2000).milliseconds();
}

public void open_First_Acc_Record(){
	waitFor(5000).milliseconds();
	mouseOverandElementdoubleClick(getDriver(), accFirstRecord);
	waitFor(7000).milliseconds();
}
public void click_Acc_PageScore_Btn(){
	accPageScoreBtn.isVisible();
	waitFor(1000).milliseconds();
	mouseOverAndHighlightanElement(getDriver(), accPageScoreBtn);
	accPageScoreBtn.click();
	waitFor(1500).milliseconds();
	waitForVisibilityOfeRAMElements(getDriver(),ScoreOptionsPopupXpath);
}

public void get_Ram_Score_Count_before(){
	ramScoreText=Double.parseDouble(ramScoreCount.getText().trim());
}

public void click_Acc_Credit_Analysis_Tab(){
	creditAnalysisTab.isVisible();
	creditAnalysisTab.click();
	waitForVisibilityOfeRAMElements(getDriver(),CreditAnalysisbodyXpath);
	waitFor(7000).milliseconds();
}





public boolean verify_Ram_Score_Count_Updated(){
	log.log(Level.INFO,"before update RAM Score ================= "+ramScoreText);
	double ramScoreText1=Double.parseDouble(ramScoreCount.getText().trim());
	log.log(Level.INFO,"after update RAM Score ================= "+ramScoreText1);
	if(ramScoreText1 >= ramScoreText){
		return true;
	}else{
		return false;
	}
}

public boolean verify_Exprot_Icon(){
	try{
		exprotIcon.isVisible();
		mouseOverAndHighlightanElement(getDriver(), exprotIcon);
		return true;
	}catch(Exception e){
		return false;
	}
}
public void accTablepageload(){
	waitForPageToLoad(getDriver());
	waitForVisibilityOfeRAMElements(getDriver(),accountsTableXpath);
	waitFor(7000).milliseconds();
}
public void account_Pagination_All_Buttons(){
	mouseOveranElement(getDriver(),pageCount);
	if(accFirstBtn.isVisible()){
		accFirstBtn.click();
		accTablepageload();
	}
	String[] pagecount=pageCount.getText().trim().split("of");
	int pagecount1=Integer.parseInt(pagecount[1].trim());
	log.log(Level.INFO,"page count in application--------------------- "+pagecount1);
	if(pagecount1 > 20){
		DecimalFormat df = new DecimalFormat("0"); //defining the decimal points foramt
		int pagecount2 = Integer.parseInt(df.format(pagecount1/20));
		log.log(Level.INFO,"page count--------------------- "+pagecount2);
			for(int i=1; i<pagecount2; i++){
				log.log(Level.INFO, "page no in loop -------------------- "+i);
				highlightElement(getDriver(), accNextBtn);
				accNextBtn.click();
				accTablepageload();
				if(i >=2){
					break;
				}
			}
			accLastBtn.click();
			accTablepageload();
			accPreviousBtn.click();
			accTablepageload();
			accFirstBtn.click();
			accTablepageload();
			
		}
	}

	public void click_order_Investigation_Cancel_Btn(){
		oIpCancelBtn.isVisible();
		highlightElement(getDriver(), oIpCancelBtn);
		oIpCancelBtn.click();
		waitFor(7000).milliseconds();
	}
	
	public boolean verify_Find_Button_has_Displayed(){
		try{
			accFindtBtn.isVisible();
			mouseOverAndHighlightanElement(getDriver(), accFindtBtn);
			return true;
		}catch(Exception e){
			return false;
		}
	}
	
	public void click_Acc_sBRIInfoTab_Tab(){
		sBRIInfoTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), sBRIInfoTab);
		sBRIInfoTab.click();
		waitFor(7000).milliseconds();
	}
	
	public void click_Acc_DBAccountInfo_Tab(){
		dandBAccountInfoTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), dandBAccountInfoTab);
		dandBAccountInfoTab.click();
		waitFor(7000).milliseconds();
	}
	
	public void click_Acc_Corp_Exposure_Tab(){
		corpExposureTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), corpExposureTab);
		corpExposureTab.click();
		waitFor(7000).milliseconds();
	}
	
	public void click_Acc_DB_Scores_Tab(){
		dandBScoresTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), dandBScoresTab);
		dandBScoresTab.click();
		waitFor(7000).milliseconds();
	}
	
	public void click_Acc_Customer_Account_Info_Tab(){
		customerAccountInfoTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), customerAccountInfoTab);
		customerAccountInfoTab.click();
		waitFor(7000).milliseconds();
	}
	
	public void click_Acc_Custom_Fields_Tab(){
		customFieldsTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), customFieldsTab);
		customFieldsTab.click();
		waitFor(7000).milliseconds();
	}

	
	public void click_Acc_BankReferences_Tab(){
		bankReferencesTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), bankReferencesTab);
		bankReferencesTab.click();
		waitFor(7000).milliseconds();
	}	
	public void click_Acc_TradeReferences_Tab(){
		tradeReferencesTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), tradeReferencesTab);
		tradeReferencesTab.click();
		waitFor(7000).milliseconds();
	}	
	public void click_Acc_List_Tab(){
		listTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), listTab);
		listTab.click();
		waitFor(7000).milliseconds();
	}	
	public void click_Acc_Comparison_Tab(){
		comparisonTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), comparisonTab);
		comparisonTab.click();
		waitFor(7000).milliseconds();
	}	
	public void click_Acc_Variance_Tab(){
		varianceTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), varianceTab);
		varianceTab.click();
		waitFor(7000).milliseconds();
	}	
	public void click_Acc_CashFlowAnalysis_Tab(){
		cashFlowAnalysisTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), cashFlowAnalysisTab);
		cashFlowAnalysisTab.click();
		waitFor(7000).milliseconds();
	}	
	public void click_Acc_PrincipalInfo_Tab(){
		principalInfoTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), principalInfoTab);
		principalInfoTab.click();
		waitFor(7000).milliseconds();
	}	
	public void click_Acc_SmallBusinessInfo_Tab(){
		smallBusinessInfoTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), smallBusinessInfoTab);
		smallBusinessInfoTab.click();
		waitFor(7000).milliseconds();
	}	
	public void click_Acc_Documents_Tab(){
		documentsTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), documentsTab);
		documentsTab.click();
		waitFor(7000).milliseconds();
	}	
	public void click_Acc_NotesToDos_Tab(){
		notesToDosTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), notesToDosTab);
		notesToDosTab.click();
		waitFor(7000).milliseconds();
	}
	
	public void click_Acc_DandBInfo_Tab(){
		DandBInfoTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), DandBInfoTab);
		DandBInfoTab.click();
		waitFor(2000).milliseconds();
	}
	
	public void click_Acc_CustomerInfo_Tab(){
		customerInfoTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), customerInfoTab);
		customerInfoTab.click();
		waitFor(2000).milliseconds();
	}
	
	public void click_Acc_Financials_Tab(){
		financialsTab.isVisible();
		mouseOverAndHighlightanElement(getDriver(), financialsTab);
		financialsTab.click();
		waitFor(2000).milliseconds();
	}
	
	public boolean verify_Print_Button_has_Displayed(){
		try{
			accPrintBtn.isVisible();
			mouseOverAndHighlightanElement(getDriver(), accPrintBtn);
			return true;
		}catch(Exception e){
			return false;
		}
	}
	
	public void click_Required_Acc_No_In_AccountResults(String FileName) throws Exception{
		try {	
		String line=read_Text_From_File(FileName);
		    log.log(Level.INFO,"Account Number ================= "+line);
		    String recordAccnoxpath="//*[@id='accountgridID-body']//table/tbody/tr/td/div[contains(.,'"+line+"')]";
		    WebElementFacade accnoele=find(By.xpath(recordAccnoxpath));
		    mouseOverandElementdoubleClick(getDriver(), accnoele);
		    waitFor(7000).milliseconds();
		}finally {
		    
		}
	}
	
	public void search_And_Click_Required_Acc_No_In_AccountResults(String FileName,String ColumnName) throws Exception{
		try {
			String line=read_Text_From_File(FileName);
		    log.log(Level.INFO,"Account Number ================= "+line);
		    acc_Input_Values_And_Exactmatch(ColumnName,line);
		    String recordAccnoxpath="//*[@id='accountgridID-body']//table/tbody/tr/td/div[contains(.,'"+line+"')]";
		    WebElementFacade accnoele=find(By.xpath(recordAccnoxpath));
		    mouseOverandElementdoubleClick(getDriver(), accnoele);
		    waitFor(7000).milliseconds();
		}finally {
		    
		}
	}
	
	public void click_Find_Button(){
		waitFor(7000).milliseconds();
		accFindtBtn.isVisible();
		mouseOverandElementClick(getDriver(), accFindtBtn);
		waitForVisibilityOfeRAMElements(getDriver(),findPopupXpath);
		
	}
	
	public void acc_Find_Input_Values(String ColumnName, String Value){
		waitFor(2000).milliseconds();
		String columnameXpath="//ul[contains(@id,'boundlist')]//li[.='"+ColumnName+"']";
		findByListbox.click();
		waitFor(300).milliseconds();
		WebElementFacade columnNameElement=find(By.xpath(columnameXpath));
		highlightElement(getDriver(), columnNameElement);
		columnNameElement.click();
		waitFor(100).milliseconds();
		accfindTextbox.sendKeys(Value);
		waitFor(200).milliseconds();
		accfindOKbtn.click();
		waitFor(8000).milliseconds();
	}
	
	public void acc_Find_Input_Values_And_Exactmatch(String ColumnName, String Value){
		waitFor(2000).milliseconds();
		String columnameXpath="//ul[contains(@id,'boundlist')]//li[.='"+ColumnName+"']";
		findByListbox.click();
		waitFor(300).milliseconds();
		WebElementFacade columnNameElement=find(By.xpath(columnameXpath));
		highlightElement(getDriver(), columnNameElement);
		columnNameElement.click();
		waitFor(100).milliseconds();
		accfindTextbox.sendKeys(Value);
		waitFor(200).milliseconds();
		findExactMatchCheckbox.click();
		waitFor(200).milliseconds();
		accfindOKbtn.click();
		waitFor(8000).milliseconds();
	}
	
	public void acc_Input_Values_And_Exactmatch(String ColumnName, String Value){
		select_An_Option_From_List(accsearchTypeListBox,ColumnName);
		 accSearchField.sendKeys(Value);
		    exactMatchCheckbox.click();
		    accsearchBtn.click();
		    if(accNotMatchOkBtn.isVisible()){
	   	  		highlightElement(getDriver(), accNotMatchOkBtn);
	   	  		accNotMatchOkBtn.click();
		    }
		    waitFor(7000).milliseconds();
	}
	
	public boolean verify_message(){
		if(accNotMatchOkBtn.isVisible()){
	   	  	highlightElement(getDriver(), accNotMatchOkBtn);
	   	  	accNotMatchOkBtn.click();
	   	  	return true;
	   	  }else{
	   		  return false;
	   	  }
		
	}
	
	public void acc_Search_wtih_Accno_from_txtFile(String FileName) throws Exception{
		String filePath1 = System.getProperty("user.dir");
		String mypath=filePath1.replace(":", ":\\");
		String filePath = mypath+FileName;
		System.out.println("File Path============"+filePath);
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		try {
		    String line = br.readLine();
		    br.close();
		    textFileAccNo=line.trim();
		    log.log(Level.INFO,"Account Number ================= "+line);
		    searchType.isVisible();
		    searchType.type("Account Number");
		    searchType.sendKeys(Keys.ESCAPE);
		    accSearchField.sendKeys(line.trim());
		    exactMatchCheckbox.click();
		    accsearchBtn.click();
		    if(accNotMatchOkBtn.isVisible()){
	   	  		highlightElement(getDriver(), accNotMatchOkBtn);
	   	  		accNotMatchOkBtn.click();
		    }
		    waitFor(7000).milliseconds();
		}finally {
		    
		}
	}
	
	public String get_txtAcc_No_In_Accountresults_Page(){
		log.log(Level.INFO,"Expected Account Number ================= "+textFileAccNo);
		String recordAccnoxpath="//*[@id='accountgridID-body']//table/tbody/tr/td/div[contains(.,'"+textFileAccNo+"')]";
		WebElementFacade editAccnoele=find(By.xpath(recordAccnoxpath));
		mouseOveranElement(getDriver(), editAccnoele);
		editAccnoele.click();
		log.log(Level.INFO,"Acctual Account Number +++++++++++++++++ "+editAccnoele.getText());
		return editAccnoele.getText().toString().trim();
	}
	
	public String verify_CompanyName_has_displayed(){
			createdAccName.isVisible();
			return createdAccName.getText().trim();
		}
	
	public void acc_Select_Sum_By_Option(String Option){
		mouseOverandElementClick(getDriver(), accSumByButton);
		waitFor(3000).milliseconds();
		accsumByListbox.click();
		waitFor(300).milliseconds();
		String OptionXpath="//ul[contains(@id,'boundlist')]//li[.='"+Option+"']";
		WebElementFacade optionElement=find(By.xpath(OptionXpath));
		highlightElement(getDriver(), optionElement);
		optionElement.click();
		waitFor(100).milliseconds();
		accSumByPopupOKButoon.click();
		waitForVisibilityOfeRAMElements(getDriver(),sumByAccountListPageXpath);
		waitFor(7000).milliseconds();
	}
	
	public boolean verify_Sum_By_Table(){
		try{
			accsumByTable.isVisible();
			return true;
		}catch(Exception e){
			return false;
		}
	}
	
	public void calCulating_Sum_in_Account_List_Table(){
		double tcount=0.0;
		int countFlag=1;
		mouseOverandElementClick(getDriver(), accsumBySumRadioBtn);
		waitForVisibilityOfeRAMElements(getDriver(),sumByAccountListPageXpath);
		waitFor(7000).milliseconds();
		log.log(Level.INFO,"row count ================= "+accsumByTablerows.size());
		for(int i=1;i<=accsumByTablerows.size();i++){
			String tablexpath="//*[@id='SumByGridId']//*[@id='SumByGridId-body']//table["+i+"]/tbody/tr/td[1]/div";
			WebElementFacade teableElement=find(By.xpath(tablexpath));
			String rowtext=teableElement.getText().trim();
			if(!rowtext.contains("Total") && !rowtext.contains("No Value Recorded(NULL)")){
				log.log(Level.INFO,"From row test sum ================= "+rowtext);
				String ramscorexpath="//*[@id='SumByGridId']//*[@id='SumByGridId-body']//table["+i+"]/tbody/tr/td[3]/div";
				WebElementFacade ramScoreElement=find(By.xpath(ramscorexpath));
				double rowvalue=Double.parseDouble(ramScoreElement.getText().trim());
				log.log(Level.INFO,"RAM Score sum "+rowtext+" ================= "+rowvalue);
				allrowValue=allrowValue + rowvalue;
				countFlag=countFlag+1;
				log.log(Level.INFO,"Adding RAM Score sum +++++++++++++++++++ "+allrowValue);
			}else{
				break;
			}
		}
		/*for(WebElement cell : accsumByTablerows ){
			String rowtext=cell.findElement(By.xpath("/tbody/tr/td[1]/div")).getText().trim();
			if(!rowtext.contains("Total")){
				log.log(Level.INFO,"From row test sum ================= "+rowtext);
				double rowvalue=Double.parseDouble(cell.findElement(By.xpath("/tbody/tr/td[3]/div")).getText().trim());
				log.log(Level.INFO,"RAM Score sum "+rowtext+" ================= "+rowvalue);
				allrowValue=rowvalue + rowvalue;
				log.log(Level.INFO,"Adding RAM Score sum +++++++++++++++++++ "+allrowValue);
			}else{
				break;
			}
		}*/
		log.log(Level.INFO,"count flag  +++++++++++++++++++ "+countFlag);
		DecimalFormat df = new DecimalFormat("0.00"); //defining the decimal points foramt
		ramScoreSumcout=Double.parseDouble(df.format(allrowValue));
		
		log.log(Level.INFO,"Total ramscore sum calculation  +++++++++++++++++++ "+ramScoreSumcout);
	}
	
	public void calCulating_Average_in_Account_List_Table(){
		double tcount=0.0;
		int countFlag=1;
		mouseOverandElementClick(getDriver(), accsumByAvgRadiobtn);
		waitForVisibilityOfeRAMElements(getDriver(),sumByAccountListPageXpath);
		waitFor(7000).milliseconds();
		log.log(Level.INFO,"row count **********************"+accsumByTablerows.size());
		
		for(int i=1;i<=accsumByTablerows.size();i++){
			
			String tablexpath="//*[@id='SumByGridId']//*[@id='SumByGridId-body']//table["+i+"]/tbody/tr/td[1]/div";
			WebElementFacade teableElement=find(By.xpath(tablexpath));
			String rowtext=teableElement.getText().trim();
			if(!rowtext.contains("Total") && !rowtext.contains("No Value Recorded(NULL)")){
				
				log.log(Level.INFO,"From row test avg ================= "+rowtext);
				String ramscorexpath="//*[@id='SumByGridId']//*[@id='SumByGridId-body']//table["+i+"]/tbody/tr/td[3]/div";
				WebElementFacade ramScoreElement=find(By.xpath(ramscorexpath));
				double rowvalue=Double.parseDouble(ramScoreElement.getText().trim());
				log.log(Level.INFO,"RAM Score avg"+rowtext+"================= "+rowvalue);
				allrowValue=allrowValue + rowvalue;
				countFlag=countFlag+1;
				log.log(Level.INFO,"Adding RAM Score Avg +++++++++++++++++++ "+allrowValue);
			}else{
				break;
			}
		}
		log.log(Level.INFO,"count flag  +++++++++++++++++++ "+countFlag);
		DecimalFormat df = new DecimalFormat("0"); //defining the decimal points foramt
		ramScoreSumcout=Double.parseDouble(df.format(allrowValue/countFlag));
		log.log(Level.INFO,"Total ram score avg cal  +++++++++++++++++++ "+ramScoreSumcout);
		
	}
	public double get_Total_count(){
		String totalCountXpath="//*[@id='SumByGridId']//*[@id='SumByGridId-body']//table/tbody/tr/td[1]/div[contains(.,'Total')]//ancestor::td[1]//following-sibling::td[2]/div";
		WebElementFacade totalCountEle=find(By.xpath(totalCountXpath));
		mouseOverAndHighlightanElement(getDriver(), totalCountEle);
		double count1=Double.parseDouble(totalCountEle.getText().trim());
		/*DecimalFormat df = new DecimalFormat("0");
		return Double.parseDouble(df.format(count1));*/
		log.log(Level.INFO,"Total RAM Score  +++++++++++++++++++ "+count1);
		return count1;
	}
	
	public double get_Total_count1(){
		String totalCountXpath="//*[@id='SumByGridId']//*[@id='SumByGridId-body']//table/tbody/tr/td[1]/div[contains(.,'Total')]//ancestor::td[1]//following-sibling::td[2]/div";
		WebElementFacade totalCountEle=find(By.xpath(totalCountXpath));
		mouseOverAndHighlightanElement(getDriver(), totalCountEle);
		double count1=Double.parseDouble(totalCountEle.getText().trim());
		DecimalFormat df = new DecimalFormat("0");
		log.log(Level.INFO,"Total RAM Score  +++++++++++++++++++ "+Double.parseDouble(df.format(count1)));
		return Double.parseDouble(df.format(count1));
		
	}
	
	public void click_Required_Range_Account_List_Row(String Range){

		mouseOverandElementClick(getDriver(), accsumBySumRadioBtn);
		waitForVisibilityOfeRAMElements(getDriver(),sumByAccountListPageXpath);
		waitFor(5000).milliseconds();
		log.log(Level.INFO,"row count ================= "+accsumByTablerows.size());
		for(int i=1;i<=accsumByTablerows.size();i++){
			String tablexpath="//*[@id='SumByGridId']//*[@id='SumByGridId-body']//table["+i+"]/tbody/tr/td[1]/div";
			WebElementFacade teableElement=find(By.xpath(tablexpath));
			String rowtext=teableElement.getText().trim();
			mouseOverAndHighlightanElement(getDriver(), teableElement);
			log.log(Level.INFO,"From row test sum ================= "+rowtext);
			if(rowtext.contains(Range)){
				log.log(Level.INFO,"Range matched ================= "+rowtext);
				mouseOverandElementdoubleClick(getDriver(), teableElement);
				waitForVisibilityOfeRAMElementsforlesstime(getDriver(),accountsTableXpath);
				waitFor(5000).milliseconds();
				break;
			}
		}
	}
	
	public boolean verify_Acc_Range_Record_Opened(){
		try{
			accResultsTableElement.isVisible();
			
			return true;
		}catch(Exception e){
			return false;
		}
	}
	public void Click_Edit_Column_Popup(){
		EditColumnBtn.isVisible();
		mouseOverandElementClick(getDriver(), EditColumnBtn);
		waitForVisibilityOfeRAMElementsforlesstime(getDriver(),SelectColumnsPopup);
		waitFor(5000).milliseconds();
	}
	
	public void select_Option_From_Available_list(String OptionValue){
		//mouseOverAndHighlightanElement(getDriver(), editColumnpopup1);
		mouseOverAndHighlightanElement(getDriver(), availableFieldsBox);
		if(OptionValue.contains(",")){
			String[] Option=OptionValue.split(",");
			for (String OptionName : Option ){

				for(WebElementFacade field : availableFieldsList){
					String itemName1=field.getText().trim();
					if(itemName1.equalsIgnoreCase(OptionName.trim())){
						mouseOverandElementClick(getDriver(), field);
						//field.click();
						waitFor(300).milliseconds();
						mouseOverandElementClick(getDriver(), editColumnAddBtn);
						waitFor(100).milliseconds();
						break;
					}
				}
			}
		}else{
			for(WebElementFacade field : availableFieldsList){
				String itemName1=field.getText().trim();
				if(itemName1.equalsIgnoreCase(OptionValue.trim())){
					mouseOverandElementClick(getDriver(), field);
					//field.click();
					waitFor(300).milliseconds();
					mouseOverandElementClick(getDriver(), editColumnAddBtn);
					waitFor(100).milliseconds();
					break;
				}
			}
		}
		/*int j=0;
		for(WebElementFacade option:selectedFieldsList){
			String itemName=option.getText().trim();
			if(itemName.equalsIgnoreCase(Optionname.trim())){
				highlightElement(getDriver(), editColumnCancelBtn);
				editColumnCancelBtn.click();
				j=1;
				break;
			}
		}
				if(j!=1){
			for(WebElementFacade field : availableFieldsList){
				String itemName1=field.getText().trim();
				
				if(itemName1.equalsIgnoreCase(Optionname.trim())){
					mouseOverandElementClick(getDriver(), field);
					mouseOverandElementClick(getDriver(), editColumnAddBtn);
					waitFor(1000).milliseconds();
					for(WebElementFacade option:selectedFieldsList){
						String itemName=option.getText().trim();
						if(itemName.equalsIgnoreCase(Optionname.trim())){
							break;
						}
					}
					highlightElement(getDriver(), editColumnSaveAsBtn);
					editColumnSaveAsBtn.click();
					break;
				}
			}
			
		}*/


	}
	public void remove_Options_From_List(String OptionValue ){
		if(OptionValue.contains(",")){
			String[] Option=OptionValue.split(",");
			for (String OptionName : Option ){

				for(WebElementFacade field : selectedFieldsList){
					String itemName1=field.getText().trim();
					if(itemName1.equalsIgnoreCase(OptionName.trim())){
						mouseOverandElementClick(getDriver(), field);
						//field.click();
						waitFor(300).milliseconds();
						mouseOverandElementClick(getDriver(), editColumnRemoveBtn);
						waitFor(100).milliseconds();
						break;
					}
				}
			}
		}else{
			for(WebElementFacade field : selectedFieldsList){
				String itemName1=field.getText().trim();
				if(itemName1.equalsIgnoreCase(OptionValue.trim())){
					mouseOverandElementClick(getDriver(), field);
					//field.click();
					waitFor(300).milliseconds();
					mouseOverandElementClick(getDriver(), editColumnRemoveBtn);
					waitFor(300).milliseconds();
					break;
				}
			}
		}
		
	}
	public void click_Profile_SaveAs_Btn(){
			highlightElement(getDriver(), editColumnSaveAsBtn);
			editColumnSaveAsBtn.click();
			waitFor(1000).milliseconds();
		}
	public void click_Profile_Save_Btn(){
		//highlightElement(getDriver(), selectColumnPopupSaveBtn);
		selectColumnPopupSaveBtn.click();
		waitFor(3000).milliseconds();
	}
	
	public void create_Profile(String ProfileName, String ProfileType, String ProfileOption){
		waitForVisibilityOfeRAMElementsforlesstime(getDriver(),createProfilePopupXpath);
		waitFor(1000).milliseconds();
		mouseOverAndHighlightanElement(getDriver(), enterProfileName);
		DateFormat dateFormat = new SimpleDateFormat("ddHHmmss");
        Date date = new Date();
        String date2= dateFormat.format(date);
        SavedProfileName=ProfileName.trim()+date2.trim();
		enterProfileName.type(SavedProfileName);
		if(ProfileType.equals("User Profile")){
			mouseOverandElementClick(getDriver(), userProfileRadioBtn);
		}
		else if(ProfileType.equals("Group Profile")){
			mouseOverandElementClick(getDriver(), groupProfileRadioBtn);
			waitFor(1000).milliseconds();
			groupProfileListbox.click();
			waitFor(1000).milliseconds();
			String ValueXpath="//ul[contains(@id,'boundlist')]//li[.='"+ProfileOption+"']";
			WebElementFacade valueElement=find(By.xpath(ValueXpath));
			highlightElement(getDriver(), valueElement);
			valueElement.click();
			waitFor(300).milliseconds();
		}
		else if(ProfileType.equals("Global Profile")){
			mouseOverandElementClick(getDriver(), globalProfileRadioBtn);
		}
		mouseOverandElementClick(getDriver(), profileOKBtn);
		waitFor(10000).milliseconds();
	}
	public void click_Profile_Btn(){
		waitFor(2000).milliseconds();
		profileButton.isVisible();
		highlightElement(getDriver(), profileButton);
		profileButton.click();
		waitForVisibilityOfeRAMElements(getDriver(), profilePopupXpath);
		waitFor(1000).milliseconds();
	}
	
	public void selected_Required_Profile_Name(String ProfileName){
		String ProfileNameXpath="//*[@id='profilePopGrid-body']//table[contains(@id,'gridview')]//tbody/tr/td/div[contains(.,'"+ProfileName+"')]";
		WebElement ProfileNameElement=getDriver().findElement((By.xpath(ProfileNameXpath)));
		mouseOverandElementdoubleClick(getDriver(), ProfileNameElement);
		waitFor(10000).milliseconds();
		waitForVisibilityOfeRAMElements(getDriver(),accountsTableXpath);
		highlightElement(getDriver(), profileButton);
	}
	public String get_Select_Profile_Name(){
		return selectedProfile.getText().toString().trim();
	}
	public boolean verify_Edit_Columns_Popup_Save_btn(){
		if(!selectColumnPopupSaveBtn.isVisible()){
			return true;
		}else{
			return false;
		}
		
	}
	
	public void perform_Search_BySelecting_Inputs(String Country, String State, String CompanyName){
		waitForVisibilityOfeRAMElements(getDriver(), dashboardPageTableXpath);
		countryField.isVisible();
		if(!Country.equals(null)){
			countryListbox.click();
			waitFor(500).milliseconds();
			String ValueXpath="//ul[contains(@id,'boundlist')]//li[.='"+Country+"']";
			WebElementFacade valueElement=find(By.xpath(ValueXpath));
			highlightElement(getDriver(), valueElement);
			valueElement.click();
			waitFor(500).milliseconds();
		}
		if(!State.equals(null)){
			stateListbox.click();
			waitFor(500).milliseconds();
			String ValueXpath="//ul[contains(@id,'boundlist')]//li[.='"+State+"']";
			WebElementFacade valueElement=find(By.xpath(ValueXpath));
			highlightElement(getDriver(), valueElement);
			valueElement.click();
			waitFor(500).milliseconds();
		}
		if(!CompanyName.equals(null)){
			companyNameOrDunsTextbox.type(CompanyName);
			waitFor(500).milliseconds();
		}
		searchBtn.click();
		waitForVisibilityOfeRAMElements(getDriver(), searchResultsTableXpath);
		waitFor(5000).milliseconds();
		
	}
	
	public void acc_Search_wtih_Input_Data(String SearchOption, String SearchValue){
		searchType.isVisible();
		accsearchTypeListBox.click();
		waitFor(500).milliseconds();
		String ValueXpath="//ul[contains(@id,'boundlist')]//li[.='"+SearchOption+"']";
		WebElementFacade valueElement=find(By.xpath(ValueXpath));
		highlightElement(getDriver(), valueElement);
		valueElement.click();
		waitFor(500).milliseconds();
		accSearchField.sendKeys(SearchValue);
		waitFor(200).milliseconds();
		accsearchBtn.click();
		if(accNotMatchOkBtn.isVisible()){
	   	  	highlightElement(getDriver(), accNotMatchOkBtn);
	   	  	accNotMatchOkBtn.click();
	   	  }
		waitFor(7000).milliseconds();
		waitForPageToLoad(getDriver());
		waitForVisibilityOfeRAMElements(getDriver(),accountsTableXpath);
	 	
	}
	
	public void save_Acc_First_Record(){
		waitFor(5000).milliseconds();
		mouseOverAndHighlightanElement(getDriver(), accFirstRecord);
		accFirstRecordText=accFirstRecord.getText().trim();
		log.log(Level.INFO,"First record of account number------------------------ "+accFirstRecordText);
		}
	
	public void click_OrderProduct_Link(String LinkName){
		
			String LinkNameXpath="//*[@id='productlistid-innerCt']//*[@class='x-grid-item-container']//table//tbody//tr//td//div[contains(.,'"+LinkName+"')]";
			WebElementFacade LinkNmeElement=find(By.xpath(LinkNameXpath));
			mouseOverandElementdoubleClick(getDriver(), LinkNmeElement);
			waitFor(5000).milliseconds();
	}
	
	public String VerifycommqueProcessStatus(){
		String OrderInvestigationStatus=null;
		COM_QUE.isVisible();
		waitFor(5000).milliseconds();
		String comqueStatusXpath="//*[contains(@id,'communicationqueueid-innerCt')]//table[1]/tbody/tr/td[1]/div";
		
		do{
			WebElementFacade comqueElement=find(By.xpath(comqueStatusXpath));
			OrderInvestigationStatus=comqueElement.getText().trim();
			log.log(Level.INFO,"product order status in Com Que------------------------ "+OrderInvestigationStatus);
			waitFor(5000).milliseconds();
		}while(OrderInvestigationStatus.equals("Processing"));
		
		OrderInvestigationStatus=COM_QUE.getText().trim();
		OrderInvestigationStatus.replaceAll(" ","");
		if((OrderInvestigationStatus.equals("ProductorderedSuccessfully"))){
			waitFor(5000).milliseconds();
			System.out.println("Results-----------------"+OrderInvestigationStatus);
			waitFor(5000).milliseconds();
		}
		Comqueuepopup.sendKeys(Keys.ESCAPE);
	return OrderInvestigationStatus;

}
	
	public String verify_Ram_Score_In_Account_Page(){
		ramScoreCount.isVisible();
		log.log(Level.INFO,"Updated RAM Score for Account------------------------ "+ramScoreCount.getText());
		return ramScoreCount.getText().toString().trim();
			
	}

}