package com.dnb.automation.DBAI.pages;

import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

import static com.dnb.automation.sba.utils.UIHelper.*;

/**
 * Created by 630239 on 5/8/2017.
 */
public class DunsSearchPage extends PageObject{

    @FindBy(xpath="html/body/form/table[1]/tbody/tr/td/p/font[1]/b")
    private WebElementFacade title;

    @FindBy(xpath=".//table/tbody/tr/td/select[@name='Country']")
    private WebElementFacade countryDD;

    @FindBy(xpath = ".//table/tbody/tr/td/input[@value='duns']")
    private WebElementFacade dunsOption;

    @FindBy(xpath = ".//table/tbody/tr/td/input[@name='InputNumber']")
    private WebElementFacade Duns;

    @FindBy(xpath = ".//table/tbody/tr/td/a/img[contains(@src,'Submit_quicksearch')]")
    private WebElementFacade submitbtn;

    public boolean verifyTitle() {
        boolean flag= false;
        getDriver().switchTo().frame("Main");
        if (title.isPresent()){
            UIHelper.highlightElement(getDriver(), title);
            flag = true;
        }
        return flag;
    }

    private void switchToFrame(WebDriver driver, String frameName) {
        driver.switchTo().frame(frameName);
    }

    public void enterDunsAndSubmit(String country, String duns) {
        selectCountryinDropDown(country);
        enterDuns(duns);
    }

    private void enterDuns(String duns) {
        getDriver().switchTo().defaultContent();
        getDriver().switchTo().frame("LeftNav");
        try{
            UIHelper.highlightElement(getDriver(),dunsOption);
            dunsOption.click();
            UIHelper.highlightElement(getDriver(),Duns);
            Duns.type(duns);
        }catch (Exception e){

        }
    }

    private void selectCountryinDropDown(String country) {
        UIHelper.waitForPageToLoad(getDriver());
        getDriver().switchTo().defaultContent();
        getDriver().switchTo().frame("LeftNav");
       // String frameid =switchFrame(getDriver());

        try{
            UIHelper.highlightElement(getDriver(),countryDD);
            Select se = new Select(countryDD);
            se.selectByVisibleText(country);
           // countryDD.click();


        }catch(Exception e){

        }
    }

    private String switchFrame(WebDriver driver) {
        String frameid = null;
        List<WebElement> frameset = driver.findElements(By.tagName("frame"));
        for(WebElement frame : frameset){
            if(frame.getAttribute("src").contains("/default/blank.html") &&
                    frame.getAttribute("name").contains("LeftNav")) {
                frameid = frame.getAttribute("id");
                break;
            }
        }
        return frameid;
    }

    public void clickSubmitbtn() {
        try {
            UIHelper.highlightElement(getDriver(), submitbtn);
            submitbtn.click();
        }catch (Exception e){

        }
    }
}
