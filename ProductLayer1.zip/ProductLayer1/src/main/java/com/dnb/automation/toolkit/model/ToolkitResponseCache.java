package com.dnb.automation.toolkit.model;

import static com.jayway.restassured.RestAssured.given;

import java.util.HashMap;
import com.jayway.restassured.path.xml.XmlPath;

public class ToolkitResponseCache {

    private static String serviceEndPoint;
    private static String userName;
    private static String userPassword;
    private static HashMap<String, String> servicesResponse;

    public static String getServiceEndPoint() {
        return serviceEndPoint;
    }

    public static void setServiceEndPoint(String serviceEndPoint) {
        ToolkitResponseCache.serviceEndPoint = serviceEndPoint;
    }

    public static String getUserName() {
        return userName;
    }

    public static void setUserName(String userName) {
        ToolkitResponseCache.userName = userName;
    }

    public static String getUserPassword() {
        return userPassword;
    }

    public static void setUserPassword(String userPassword) {
        ToolkitResponseCache.userPassword = userPassword;
    }

    public static String getProduct(String endPoint, String userName,
            String userPassword, String dunsNo, String prodCode) {
        String toolkitResponse = "";
        try {
            if (servicesResponse == null) {
                servicesResponse = new HashMap();
            }

            if (servicesResponse.get(dunsNo + "_" + prodCode) != null) {
                System.out.println("Taken from Cache");
                toolkitResponse = (String) servicesResponse.get(dunsNo + "_" + prodCode);
                
            } else {

                System.out.println("Taken from Toolkit");
                String toolkitRequest = "<DGX> <SIGNONMSGSRQV1> <SONRQ> <DTCLIENT>2014-02-13 17:10:45</DTCLIENT> <USERID>"
                        + userName
                        + "</USERID> <USERPASS>"
                        + userPassword
                        + "</USERPASS> <LANGUAGE> EN</LANGUAGE> <FI> <ORG>DUN and BRADSTREET</ORG> </FI> <APPID>3k</APPID> <APPVER>0010</APPVER> </SONRQ> </SIGNONMSGSRQV1> <CREDITMSGSRQV2> <DATATRNRQ> <TRNUID/> <DATARQ> <SRVRTID/> <SVC_TYPE_CD/> <REAS_CD>1</REAS_CD> <CUST_ENDR/> <FILE_ID/> <CUST_RQ/> <REFRESH_IND>Y</REFRESH_IND> <IGNORE_REQD_FLDS_IND/> <SUBJ_DET> <DUNS_NBR>"
                        + dunsNo
                        + "</DUNS_NBR> <SBRI_UMTC_AGN/> <CTRY_CD/> <TRD_UP_IND/> <PRIM_NME/> </SUBJ_DET> <PROD>"
                        + prodCode
                        + "</PROD> <PROD_TYPE_CD>D</PROD_TYPE_CD> <CHAR_SET_PREF_OVRD/> <DELV_REQS_NOW> <DELV_MODE_CD>Direct</DELV_MODE_CD> <DELV_FMT_CD>XML</DELV_FMT_CD> <LANG>EN</LANG> <DELV_EMAIL/> <DELV_EMAIL_CC/> </DELV_REQS_NOW> <ADDL_DET> <FLD_LST/> </ADDL_DET> </DATARQ> </DATATRNRQ> </CREDITMSGSRQV2> </DGX>";

                toolkitResponse = given()
                        .header("Content-Type", "text/xml; charset=UTF-8")
                        .request().body(toolkitRequest).when().post(endPoint)
                        .asString();

                servicesResponse.put(dunsNo + "_" + prodCode, toolkitResponse);
            }
        } catch (Exception e) {
        }
      //  System.out.println(userName);
      //  System.out.println(userPassword);
      //  System.out.println(toolkitResponse);
        return toolkitResponse;
    }

    public static void main(String[] arg) {
        //ToolkitResponseCache src = new ToolkitResponseCache();
        String toolkitResponse = ToolkitResponseCache.getProduct(
                "http://10.162.228.116:80/services/ToolkitXMLGateway-Testing/",
                "buzbyv", "ver0nica", "300363576", "Enterprise Management");
        System.out.println("Assement Date - " + XmlPath.with(toolkitResponse).get("DGX.CREDITMSGSRSV2.DATATRNRS.DATARS.FAIL_SCR_ENTR.SCR_GRP.ASMT_DT"));
        System.out.println("Algorithm Id  - " + XmlPath.with(toolkitResponse).get("DGX.CREDITMSGSRSV2.DATATRNRS.DATARS.FAIL_SCR_ENTR.SCR_GRP.ALGM_ID"));
        System.out.println("SER Value - " + XmlPath.with(toolkitResponse).get("DGX.CREDITMSGSRSV2.DATATRNRS.DATARS.SER_RAT_ENTR.RSK_SCR"));
        System.out.println("Failure Score - " + XmlPath.with(toolkitResponse).get("DGX.CREDITMSGSRSV2.DATATRNRS.DATARS.FAIL_SCR_ENTR.SCR_GRP.NATL_PCTL")); 
        System.out.println("Deliquency Score - " + XmlPath.with(toolkitResponse).get("DGX.CREDITMSGSRSV2.DATATRNRS.DATARS.DELQ_SCR_ENTR.SCR_GRP.NATL_PCTL")); 
        System.out.println("SER Score - " + XmlPath.with(toolkitResponse).get("DGX.CREDITMSGSRSV2.DATATRNRS.DATARS.SER_RAT_ENTR.RSK_SCR")); 
        System.out.println("Paydex Score - " + XmlPath.with(toolkitResponse).get("DGX.CREDITMSGSRSV2.DATATRNRS.DATARS.PAYD_SCR"));
        System.out.println("DNBRating - " + XmlPath.with(toolkitResponse).get("DGX.CREDITMSGSRSV2.DATATRNRS.DATARS.DNB_RATG"));
        System.out.println("ViabilityScore - " + XmlPath.with(toolkitResponse).get("DGX.CREDITMSGSRSV2.DATATRNRS.DATARS.DNB_VBLTY_RATG_ENTR.VBLTY_SCR.CLAS_SCR"));
        System.out.println("PortfolioComparisonScore - " + XmlPath.with(toolkitResponse).get("DGX.CREDITMSGSRSV2.DATATRNRS.DATARS.DNB_VBLTY_RATG_ENTR.PTFL_CMPA_SCR.CLAS_SCR"));
        System.out.println("DataDepthIndicator Value - " + XmlPath.with(toolkitResponse).get("DGX.CREDITMSGSRSV2.DATATRNRS.DATARS.DNB_VBLTY_RATG_ENTR.DATA_DPTH_DTL.DATA_DPTH_INDC"));
        System.out.println("Company Profile Value - " + XmlPath.with(toolkitResponse).get("DGX.CREDITMSGSRSV2.DATATRNRS.DATARS.DNB_VBLTY_RATG_ENTR.ORG_PFL_DTL.ORG_PFL_RAT"));
        System.out.println("Financial Data - " + XmlPath.with(toolkitResponse).get("DGX.CREDITMSGSRSV2.DATATRNRS.DATARS.DNB_VBLTY_RATG_ENTR.ORG_PFL_DTL.FINL_DATA_AVIL_INDC"));
        System.out.println("TradePayment - " + XmlPath.with(toolkitResponse).get("DGX.CREDITMSGSRSV2.DATATRNRS.DATARS.DNB_VBLTY_RATG_ENTR.TRD_DATA_AVLB_DTL.ASMT_TXT"));
        System.out.println("CompanySize status - " + XmlPath.with(toolkitResponse).get("DGX.CREDITMSGSRSV2.DATATRNRS.DATARS.DNB_VBLTY_RATG_ENTR.ORG_SZ_DTL.ORG_SZ_CATG_TXT"));
        System.out.println("Years in Business - " + XmlPath.with(toolkitResponse).get("DGX.CREDITMSGSRSV2.DATATRNRS.DATARS.DNB_VBLTY_RATG_ENTR.ORG_PFL_DTL.YRS_IN_BUS_DTL.YRS_IN_BUS_CATG_TXT"));
        
        
   
    }
}