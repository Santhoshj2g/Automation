package com.dnb.automation.dbiaopal.pages;


import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

/**
 * Created by 630239 on 5/19/2017.
 */
public class SearchPage extends PageObject {
    
    @FindBy(xpath=".//*[@id='top-menu']/ul/li/a[text()='DBIA Search']")
    private WebElementFacade searchLink;

    @FindBy(xpath=".//*[@id='SearchPage']/div/div[contains(@class,'panel-heading')]")
    private WebElementFacade title;

    @FindBy(xpath=".//*[@id='Country']")
    private WebElementFacade countryDD;

    @FindBy(xpath=".//label[2]/input[@id='SearchBy']")
    private WebElementFacade dunsOption;

    @FindBy(xpath=".//input[@id='SearchDetails']")
    private WebElementFacade dunsTxt;

    @FindBy(xpath=".//*[@id='SearchButton']")
    private WebElementFacade searchbtn;


    @FindBy(xpath=".//button[contains(@class,'ok-btn')]")
    private WebElementFacade closepopUp;

    public void clickDBIASearch() {
        if(searchLink.isPresent()){
            UIHelper.highlightElement(getDriver(),searchLink);
            searchLink.click();;
        }
    }

    public boolean verifyTitle() {
        if(title.isPresent())
            return true;
        else
            return false;
    }

    public void enterCountryAndDuns(String country, String duns) {
        selectCountryfromDD(country);
        enterDunsOption();
        enterDuns(duns);
        clickSearchbtn();
    }

    private void clickSearchbtn() {
        try {
            if(searchbtn.isPresent()){
                UIHelper.highlightElement(getDriver(),searchbtn);
                searchbtn.click();
                UIHelper.waitForPageToLoad(getDriver());
            }
        }catch (Exception e){

        }
    }

    private void enterDuns(String duns) {
        try{
            UIHelper.waitForPageToLoad(getDriver());
            if(dunsTxt.isPresent()){
                UIHelper.highlightElement(getDriver(),dunsTxt);
                dunsTxt.type(duns);
            }
        }catch (Exception e){

        }
    }

    private void enterDunsOption() {
        UIHelper.waitForPageToLoad(getDriver());
        try{
            if(dunsOption.isPresent()){
                UIHelper.highlightElement(getDriver(),dunsOption);
                dunsOption.click();
            }
        }catch (Exception e){

        }
    }

    private void selectCountryfromDD(String country) {
        try{
            if(countryDD.isPresent()){
                UIHelper.highlightElement(getDriver(),countryDD);
                Select se = new Select(countryDD);
                se.selectByVisibleText(country);
                UIHelper.waitForPageToLoad(getDriver());

            }
        }catch (Exception e){

        }

    }

    public void toSelectNextReport(String duns) throws Exception{
        if(closepopUp.isPresent()){
            UIHelper.highlightElement(getDriver(),closepopUp);
            closepopUp.click();
        }
        enterDuns(duns);
        clickSearchbtn();
    }

    private void switchWindow(WebDriver driver) {
        String childWindow = driver.getWindowHandle();
        ArrayList<String> tabs = new ArrayList (driver.getWindowHandles());
        System.out.println(tabs.size());
        int i=1;
        driver.switchTo().window(tabs.get(i));

    }

    private void swithWindow() {
        String childWindow = getDriver().getWindowHandle();
        Set<String> allWindows = getDriver().getWindowHandles();
        Iterator<String> windowIterator =  allWindows.iterator();
        while(windowIterator.hasNext()){
            String homeWindow = windowIterator.next();
            if (childWindow.equals(homeWindow)){
                getDriver().switchTo().window(childWindow);
                getDriver().close();
                getDriver().switchTo().window(homeWindow);
            }
        }

    }

}
