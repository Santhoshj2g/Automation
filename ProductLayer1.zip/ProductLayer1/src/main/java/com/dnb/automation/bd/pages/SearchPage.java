package com.dnb.automation.bd.pages;

import java.util.List;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.dnb.automation.utils.UIHelper;

public class SearchPage extends PageObject{

	//Variable declaration
	private String profile_Name;	
	String recordcnt;
	//Xpaths
	 @FindBy(xpath = ".//*[@id='qck-unspsc']")
	 private WebElementFacade drpDwnBox;
	 
	 @FindBy(xpath = ".//*[@id='qckSearchKeyword']")
	 private WebElementFacade searchBox;
	 
	 @FindBy(xpath = ".//*[@id='qckSearchButton']/span")
	 private WebElementFacade btnSearch;
	 
	 @FindBy(xpath = ".//*[@id='formal-result-body']/tr[1]/td[1]")
	 private WebElementFacade searchResult;
	 
	 @FindBy(xpath = ".//*[@id='businessinfo']/table/tbody/tr/td[2]")
	 private WebElementFacade profile;

	 @FindBy(xpath = ".//*[@id='shell']/div/div/div[5]/h1")
	 private WebElementFacade profileName;

	 @FindBy(xpath = ".//*[@id='formal-result-body']")
	 private WebElementFacade searchResultBody;
		 
	 @FindBy(xpath = "//*/select[@id='itemsPerPge']")
	 private WebElementFacade lstItemsPerPg;
	 
	 @FindBy(xpath = "//*/div[@id='results-container']/table[@id='formal-result']/tbody/tr")
	 private List<WebElementFacade> rowsInSearchResult;

	 @FindBy(xpath = "html/body/div[3]/div[1]/div/div/div[4]/div[2]/div[1]/ul/li[1]/a")
	 private WebElementFacade resetPswdLnk;
	 
	 @FindBy(xpath = "//*[@id='adminResetPassword']")
	 private WebElementFacade resetPswdPage;
	 
	 @FindBy(xpath = "//*[@id='resetPasswordEmail']")
	 private WebElementFacade emailld;
	 
	 @FindBy(xpath = "//*[@class='firstName']")
	 private WebElementFacade firstName;
	 
	 @FindBy(xpath = "//*[@class='lastName']")
	 private WebElementFacade lastName;
	 
	 @FindBy(xpath = "html/body/div[3]/div[1]/div/div/div[4]/div[2]/div[1]/ul")
	 private WebElementFacade Element;
	 
	 @FindBy(xpath = " //*[@id='user-home']")
	 private WebElementFacade home;
	 
	 @FindBy(xpath = "//*/div[@id='extras']/div/ul/li/a[contains(text(),'Edit My Profile Online')]")
	 private WebElementFacade editProfile;	
	 
	 @FindBy(xpath = "//*/div[@id='flat-tabs']/ul/li/a[contains(text(),'My Details')]")
	 private WebElementFacade editProfilePage;
	 
	 @FindBy(xpath = "//*[@class='dotted-bottom' and contains(text(),'Manage Account')]")
	 private WebElementFacade mngAccountLnk;
	 
	 @FindBy(xpath = "//*[@class='pageHead']")
	 private WebElementFacade resetPswdAdmin;
	 
	 @FindBy(xpath = "//*[@name='email']")
	 private WebElementFacade emailid;
		 
	 @FindBy(xpath = "//*[@name='strPrefix']")
	 private WebElementFacade prefix; 	 
	 
	 @FindBy(xpath = "//*[@class='countryCode']")
	 private WebElementFacade countryCode;
	 
	 @FindBy(xpath = "//*[@class='areaCode']")
	 private WebElementFacade areaCode;
	 
	 @FindBy(xpath = "//*[@class='phoneNumber']")
	 private WebElementFacade phoneNo;
	 
	 @FindBy(xpath = "//*[@class='phoneExt']")
	 private WebElementFacade phoneExtn;
	 
	 @FindBy(xpath = "//*[@name='country']")
	 private WebElementFacade country;	 
	 
	 @FindBy(xpath = "//*/div/p[contains(text(),'Role')]")
	 private WebElementFacade role;
	 	 
	 @FindBy(xpath = "//*/div[@id='extras']/div/ul/li/a[contains(text(),'Create New User')]")
	 private WebElementFacade createNewUser; 	
	
	 @FindBy(xpath = "//*[@class='dotted-bottom' and contains(text(),'Downloads & Offers')]")
	 private WebElementFacade downlaodandoffers;
	 
	 @FindBy(xpath = "//*/div[@id='extras']/div/b/a[contains(text(),'Manage Downloads')]")
	 private WebElementFacade manageDownloadsLnk;
	 
	 @FindBy(xpath = "//*[@id='productDescription']")
	 private WebElementFacade productDesc;
	 
	 @FindBy(xpath = "//*[@id='productOfferCode']")
	 private WebElementFacade productOfferCode;
	 
	 @FindBy(xpath = "//*[@id='downloadCountLimit']")
	 private WebElementFacade downloadCountLimit;
	 
	 @FindBy(xpath = "//*[@id='expiryDate']")
	 private WebElementFacade expiryDate;
	 
	 @FindBy(xpath = "//*/form[@id='managedownloadForm']/div/div/div[contains(text(),'Document File')]")
	 private WebElementFacade docfile;
	
	 @FindBy(xpath = " //*/form[@id='managedownloadForm']/div/div/div/a/span[contains(text(),'Upload')]")
	 private WebElementFacade uploadBtn;
	 
	 @FindBy(xpath = "//*[@id='cancel-button']")
	 private WebElementFacade cancelBtn;
	
	 @FindBy(xpath = "//*[@id='documentFile']")
	 private WebElementFacade browsebtn;	
	 
	 @FindBy(xpath = "//*[@class='pageHead']")
	 private WebElementFacade mngDownloads_myAcc;
	 
	 @FindBy(xpath = "//*/div[@id='extras']/div/ul/li/a[contains(text(),'See my requested connections')]")
	 private WebElementFacade seeMyReqConnec_cmpnyUser;
	 
	 @FindBy(xpath = "//*/div[@class='pageHead']/div/a[contains(text(),'My Account')]")
	 private WebElementFacade Connections_myAcc;
	 
	 @FindBy(xpath = "//*/div[@id='firstOne'][contains(text(),'Invites Received')]")
	 private WebElementFacade ConnectionsHdr_cmpnyUser;
	 
	 @FindBy(xpath = "//*/table[@id='pagerReceived']/thead/tr/th/div/a[contains(text(),'Request For')]")
	 private WebElementFacade requestFor;
	 
	 @FindBy(xpath = "//*[@id='registerCheckBox']")
	 private WebElementFacade trmsandConditions;
	 
	 @FindBy(xpath = "//*/div/a/span[contains(text(),'Register')]")
	 private WebElementFacade registerButton;
	 
	 @FindBy(xpath = "//*/div/p/a/span[contains(text(),'Search')]")
	 private WebElementFacade searchButton;
	 
	 @FindBy(xpath = "//*/form[@id='managedownloadForm']/div/div/div/label/a/span[contains(text(),'Browse')]")
	 private WebElementFacade browseButton;
	 
	 @FindBy(xpath = "//*/div[@class='pageHead']/div/a[contains(text(),'Connections')]")
	 private WebElementFacade connectionsPage;
	 
	 @FindBy(xpath = "//*/table[@id='pagerReceived']/thead/tr/th/div/a[contains(text(),'Received')]")
	 private WebElementFacade received;
	 
	 @FindBy(xpath = "//*/table[@id='pagerReceived']/thead/tr/th/div/a[contains(text(),'Received From')]")
	 private WebElementFacade ReceivedFrom;
	 
	 @FindBy(xpath = "//*/table[@id='pagerReceived']/thead/tr/th/div/a[contains(text(),'Status')]")
	 private WebElementFacade status;
	 
	 @FindBy(xpath = "//*/div[@id='inviteSent']")
	 private WebElementFacade invitesSent;
	 
	 @FindBy(xpath = "//*[@class='companyURL']")
	 private WebElementFacade companyUrl;
	 	 
	 @FindBy(xpath = "//*/div[@id='extras']/div/ul/li/a[contains(text(),'Edit my profile online')]")
	 private WebElementFacade editMyprofileonline;
	 
	 @FindBy(xpath = "//*[@name='canReceiveMarketingMails']")
	 private WebElementFacade termsandCondtns;
	 
	 @FindBy(xpath = "//*/div/a/span[contains(text(),'Save')]")
	 private WebElementFacade saveBtn;
	 
	 @FindBy(xpath = "//*/div[@id='extras']/div/ul/li/a[contains(text(),'Add new users to my account')]")
	 private WebElementFacade addNewuser;
	 
	 @FindBy(xpath = "//*/div[@class='pageHead']/div/a[contains(text(),'My Details')]")
	 private WebElementFacade myDetails;
	 
	 @FindBy(xpath = "//*/div[@id='extras']/div/ul/li/a[contains(text(),'Add photos')]")
	 private WebElementFacade addPhotos;
	 
	 @FindBy(xpath = "//*/div[@class='pageHead']/div/a[contains(text(),'Company Profile')]")
	 private WebElementFacade companyProfile;
	 
	 @FindBy(xpath = "//*/div[@class='pageHead']/div/a[contains(text(),'My Account')]")
	 private WebElementFacade myAcc;
	 
	 @FindBy(xpath = "//*/table/thead/tr/th/div/a[contains(text(),'Company Name')]")
	 private WebElementFacade companyName;
	 
	 @FindBy(xpath = "//*/table[@id='user-company-profile-table-id']/thead/tr/th/div/a[contains(text(),'Location')]")
	 private WebElementFacade location;
	 
	 @FindBy(xpath = "//*/table[@id='user-company-profile-table-id']/thead/tr/th/div/a[contains(text(),'Line of Business Type')]")
	 private WebElementFacade lineofBusiness;
	 
	 @FindBy(xpath = "//*/table[@id='user-company-profile-table-id']/thead/tr/th/div/a[contains(text(),'Claimed On')]")
	 private WebElementFacade claimedOn; 
	 
	 @FindBy(xpath = "//*/table[@id='user-company-profile-table-id']/thead/tr/th/div[contains(text(),'QR code')]")
	 private WebElementFacade qrCode;
	 
	 @FindBy(xpath = "//*/div[@id='extras']/div/b/a[contains(text(),'offer code')]")
	 private WebElementFacade offerCodeLnk;	 
	 
	 @FindBy(xpath = "//*/div[@id='extras']/div/p/a[contains(text(),'Submit')]")
	 private WebElementFacade submitBtn;
	 
	 @FindBy(xpath = "//*/div[@class='pageHead']/div/a[contains(text(),'Profile Users')]")
	 private WebElementFacade profileUsers;	 
	 
	 @FindBy(xpath = "//*/table[@id='user-profile-table-id']/thead/tr/th/div/a[contains(text(),'User Type')]")
	 private WebElementFacade userType;
	 
	 @FindBy(xpath = "//*/table[@id='user-profile-table-id']/thead/tr/th/div/a[contains(text(),'User Count')]")
	 private WebElementFacade userCount;
	 
	 @FindBy(xpath = "//*/div[@class='pageHead']/div/a[contains(text(),'User Registration Management')]")
	 private WebElementFacade userRegMngmnt;
	 
	 @FindBy(xpath = "//*/form[@id='result-param']/select[@name='userOption']")
	 private WebElementFacade userOption;
	
	 @FindBy(xpath = "//*/form[@id='result-param']/input[@id='qckSearchKeyword']")
	 private WebElementFacade enterSrchtrm;
	 
	 @FindBy(xpath = "//select[@id='location']")
	 private WebElementFacade selectLocation;
	 
	 @FindBy(xpath = "//select[@name='state']")
	 private WebElementFacade selectState;	
	 
	 @FindBy(xpath = "//div[@id='narrowResults']")
	 private WebElementFacade narrwoResults;
	 
	 @FindBy(xpath = "//*/input[@id='dunsRegistered']")
	 private WebElementFacade dunsRegchkbox;
	 
	 @FindBy(xpath = "//*/span[contains(text(),'Apply Filters')]")
	 private WebElementFacade applyFilters;

	 @FindBy(xpath = "//*/p[@class='range pagerange']")
	 private WebElementFacade pageRange;	
	 
	 @FindBy(xpath = "//*/a[contains(text(),'Remove Filters')]")
	 private WebElementFacade removeFilters;
	
	 @FindBy(xpath = "//*/div[@data-index='0']")
	 private WebElementFacade autosuggestion;
	 
	 String processicon="//*/div[@id='process']/img[contains(text(),'Loading')]";
	 
	 @FindBy(xpath = "//select[@id='currencyCode']")
	 private WebElementFacade currencyCode;
	 
	 @FindBy(xpath = "//select[@id='numemployees']")
	 private WebElementFacade noofEmployees; 
	
	 @FindBy(xpath = "//select[@name='revenue']")
	 private WebElementFacade salesRevenue;	
	 
	 @FindBy(xpath = "//a[@class='resultrows']")
	 private WebElementFacade result;
	 
	 @FindBy(xpath = "//a[@id='ui-id-1']")
	 private WebElementFacade dnbVerifiedInfoTab;	
	 
	 @FindBy(xpath = "//a[@id='ui-id-2']")
	 private WebElementFacade companyProvidedInfoTab;
	 
	 @FindBy(xpath = "//div[@class='cmp-titleflagbg']")
	 private WebElementFacade overviewSection;
	 
	 @FindBy(xpath = "//div[@id='relatedtags']/div")
	 private WebElementFacade relatedTags;
	
	 @FindBy(xpath = "//div[@id='corpinfo']/h3")
	 private WebElementFacade corporateinformation;
	 
	 @FindBy(xpath = "//div[@id='registrationinfo']/h3")
	 private WebElementFacade registrationinformation;
	 
	 @FindBy(xpath = "//div[@id='businessinfo']/h3")
	 private WebElementFacade DunsNumberSection;
	 
	 @FindBy(xpath = "//div[@id='keyemployee']/h3")
	 private WebElementFacade keyEmployeeSection;
	 
	 @FindBy(xpath = "//div[@id='financialinfo']/h3")
	 private WebElementFacade financialInfoSection;
	 
	 @FindBy(xpath = "//div[@id='productsbrands']")
	 private WebElementFacade productsandBrands;
	 
	 @FindBy(xpath = "//div[@id='executives']")
	 private WebElementFacade executives;	 
	 
	 @FindBy(xpath = "//ul[@class='cmpData']/li/label")
	 private WebElementFacade nameFld;
	 
	 @FindBy(xpath = "//ul[@class='cmpData']/li/label[contains(text(),'Title')]")
	 private WebElementFacade titleFld;
	 
	 @FindBy(xpath = "//img[@id='imageConnect']")
	 private WebElementFacade connectBtn;
	 
	 @FindBy(xpath = "//img[@class='dnbdunsicon logoImagesChange']")
	 private WebElementFacade DUNSRegSeal;
	 
	 @FindBy(xpath = "//div[@id='dnbverified']")
	 private WebElementFacade dbVerifiedText;
	 
	 @FindBy(xpath = "//div[@id='about']")
	 private WebElementFacade aboutTheCmpny;
	 
	 @FindBy(xpath = "//td[@itemprop='isicV4']")
	 private WebElementFacade LOBDesc;
	 	 
	 @FindBy(xpath = "//div[@class='tag-container']/a/span")
	 private List<WebElementFacade> relatedTagsDesc;	 
	 
	 @FindBy(xpath = "//a[@id='qckSearchButton']/span")
	 private WebElementFacade searchOption;
	
	 @FindBy(xpath = "//div[@id='disclaimer']")
	 private WebElementFacade disclaimer;
	 
	 @FindBy(xpath = "//ul[@class='utilitylinks']/li")
	 private WebElementFacade signedinasLink;
	 
	 @FindBy(xpath = "//a[contains(text(),'Logout')]")
	 private WebElementFacade signOutLink;
	 
	 @FindBy(xpath = "//img[@id='imageClaim']")
	 private WebElementFacade claimBtn;	
	 
	 @FindBy(xpath = "//a[@id='myDashboard']")
	 private WebElementFacade myDashboard;	 
	 
	 @FindBy(xpath = "html/body/div[3]/div[1]/div/div/div[6]/div[4]/div[1]")
	 private WebElementFacade addsec;
	
	
	
    /***********************************************************************************
	 * Function: Search the Profile to View 
	 * Input : Search option and search value
	 * Action: Search
	 * Output : NA
	***********************************************************************************/
	 
	 public void search(String option,String dunsNo) throws Exception
	 {
		 if(drpDwnBox.isPresent())
		 {
			 selectSearch(option);
			 enterSearch(dunsNo);
			 clickSearchButton();
		 }					
	 }

    /***********************************************************************************
	 * Function: Select the Profile to View 
	 * Input : NA
	 * Action: select 
	 * Output : NA
	***********************************************************************************/
	 public void selectProfileToView()
	 {
		 searchResult.findBy(By.tagName("a")).waitUntilVisible();
		 searchResult.findBy(By.tagName("a")).waitUntilClickable();		 
		 searchResult.findBy(By.tagName("a")).click();
		 UIHelper.waitForPageToLoad(getDriver());
	 }

    /***********************************************************************************
	 * Function: Get the displayed Profile name 
	 * Input : NA
	 * Action: Get the visible profile name 
	 * Output : return the profile name
	***********************************************************************************/
	 public String getDispProfileName()
	 {
		 if(profileName.isPresent())
		 {
			 return profileName.getText();
		 }else
		 {
			 return null;
		 }
	 }	 
	/***********************************************************************************
	 * Function: Verify the result body table 
	 * Input : NA
	 * Action: Result table is visible 
	 * Output : NA
	***********************************************************************************/
	public boolean getResultBodyVisibility()
	{		 
		 return searchResultBody.isPresent();		 
	}
	/***********************************************************************************
	 * Function: To get the displyed profile duns number 
	 * Input : NA
	 * Action: NA 
	 * Output : Duns number
	***********************************************************************************/
	
	 public boolean getDisplayedProfileDuns(String dunsNo)
	 {		 
		 String profile_Duns =profile.getAttribute("dunsnbr");
	        if (profile_Duns.equalsIgnoreCase(dunsNo)) {
	            return true;
	        }else
	        {
	        	return false;
	        }
	 }
	    /***********************************************************************************
	     * Function: Select the search criteria in the search drop down. 
	     * Input : Drop down value 
	     * Action: select 
	     * Output : NA
	     ***********************************************************************************/
	    public void selectSearch(String option) throws Exception {
	        try {
	        	drpDwnBox.waitUntilPresent();        
	        	drpDwnBox.sendKeys(option);
	        } catch (Exception E) {
	            throw E;
	        }
	    }
	 
	    /***********************************************************************************
	     * Function: Enter the search in Search text box 
	     * Input : Drop down value 
	     * Action: Enter 
	     * Output : NA
	     ***********************************************************************************/
	    public void enterSearch(String dunsNo) throws Exception {
	        try {
	        	searchBox.waitUntilEnabled();	
	        	searchBox.clear();
	        	searchBox.sendKeys(dunsNo);
	        } catch (Exception E) {
	            throw E;
	        }
	    }
	    /***********************************************************************************
	     * Function: Click on Search button 
	     * Input : NA 
	     * Action : Click 
	     * Output : NA
	     ***********************************************************************************/
	    public void clickSearchButton() throws Exception {
	        if (btnSearch.isPresent()) {
	        	btnSearch.waitUntilClickable();
	        	btnSearch.click();
	            UIHelper.waitForPageToLoad(getDriver());   
	        }
	    }

	    /***********************************************************************************
	     * Function: Get the total no of rows displayed in search result
	     * Input   : NA 
	     * Action  : Get no of rows 
	     * Output  : return no of rows
	     ***********************************************************************************/
	    public int getNoOfRowsInSearchResultForGuest()
	    {
	    	int noOfRows=0;
	    	if(lstItemsPerPg.isPresent())
	    	{
	    		Select itemsPerPgOption=new Select(lstItemsPerPg);
	    		itemsPerPgOption.selectByVisibleText("50");
	    		searchResultBody.waitUntilPresent();
	    		System.out.println("************no of rows is "+rowsInSearchResult.size());
	    		if(rowsInSearchResult.size()>0)
	 		    {
	    			noOfRows=rowsInSearchResult.size();
	 		    }
	    	}
	    	return noOfRows;
	    }
		/***********************************************************************************
	     * Function: Click on the Reset Password Link under the Manage Accounts section
	     * Input   : NA 
	     * Action  : click
	     * Output  : Reset Password page should be displayed
	     ***********************************************************************************/
	    public void clickHome() throws Exception {
	    	if (home.isPresent())
	    	{
	    		home.click();
	    		UIHelper.waitForPageToLoad(getDriver()); 
	    	}
	    }     
	    
	    /***********************************************************************************
	     * Function: Click on the ManageAccount Link in Home page
	     * Input   : NA 
	     * Action  : click
	     * Output  : Reset Password page should be displayed
	     ***********************************************************************************/
	   public boolean clickOnManageaccLnk() throws Exception
	    {
	    	if(mngAccountLnk.isPresent())
	    	{
	    		mngAccountLnk.click();
	    		UIHelper.waitForPageToLoad(getDriver());
	    		return true;
	    	}else
	    	{
	    		return false;
	    	}
	    } 	      
	    /***********************************************************************************
	     * Function: Click on the Reset Password Link under the Manage Accounts section
	     * Input   : NA 
	     * Action  : click
	     * Output  : Reset Password page should be displayed
	     ***********************************************************************************/
	    public void resetPswdLnk() throws Exception {
	    	if (Element.isPresent())
	    	{
	    		String val=Element.getText();
	    				System.out.println(val);
	    	}
	        if (resetPswdLnk.isPresent()) {
	        	resetPswdLnk.click();
	            UIHelper.waitForPageToLoad(getDriver());  	            
	        }
	    }
	    /***********************************************************************************
	     * Function: Verify the Reset Password page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/
	    public boolean verifyResetPswdPage() throws Exception {  
	    		return resetPswdPage.isPresent();	    		
	    } 
	    /***********************************************************************************
	     * Function: Verify the Email Id field in ResetPassword page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/
	    public boolean verifyEmailId() throws Exception {
	        return emailld.isPresent();	       
	    } 
	    /***********************************************************************************
	     * Function: Verify the LastName field in ResetPassword page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/
	    public boolean verifyLastName() throws Exception {
	    	return lastName.isPresent();	        
	    } 	        
	    /***********************************************************************************
	     * Function: Click on the Edit My Profile Online page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/
	    public void editprofile() throws Exception {	       
	       if (editProfile.isPresent()) {	        	
	        	editProfile.click();	        	        	
	            UIHelper.waitForPageToLoad(getDriver());  	            
	        }
	    } 
	    /***********************************************************************************
	     * Function: Verify the Edit My Profile Online page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/
	        public boolean verifyEditprofilePage() throws Exception {
	        if (editProfilePage.isPresent()) {	        	
	            return true;
	        }else
	        {
	        	return false;
	        }
	    } 	    
	   /***********************************************************************************
		     * Function: Verify the Reset Password page is displayed under My Account section
		     * Input   : NA 
		     * Action  : NA
		     * Output  : NA
		   ***********************************************************************************/
	    public boolean verifyResetPswdPageadmin() throws Exception {     	
	        	resetPswdAdmin.click();	
	        	String val1= resetPswdAdmin.getText();
	        	System.out.println(val1);
	        	if (val1.contains("My Account"))
	    	    {
	    	       System.out.println("Reset Password page is displayed under My Account section");	
	    	       return true;	    	    	            
	            }else
	            {
	        	return false;
	            }
	    } 
	    /***********************************************************************************
	     * Function: Verify the Email id field
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/  
	    public boolean verifyEmailid()
	    {
	    	return emailid.isPresent();	    	
	    }
	    /***********************************************************************************
	     * Function: Verify the Prefix field
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/    
	    public boolean verifyPrefix()
	    {
	    	return prefix.isPresent();	    	
	    }
	    /***********************************************************************************
	     * Function: Verify the First Name field
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/  
	    public boolean verifyFirstName()
	    {
	    	return firstName.isPresent();	    	
	    }
	    /***********************************************************************************
	     * Function: Verify the Country Code field
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/  
	     public boolean verifyCountrycode()
	    {
	    	return countryCode.isPresent();	    	
	    }
	    /***********************************************************************************
	     * Function: Verify the Area code field
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/  
	    public boolean verifyAreacode()
	    {
	    	return areaCode.isPresent();	    	
	    }
	    /***********************************************************************************
	     * Function: Verify the Phone No field in Edit Profile page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/  
	   public boolean verifyPhoneNo()
	    {
	    	return phoneNo.isPresent();	    	
	    }
	    /***********************************************************************************
	     * Function: Verify the Extension field in Edit Profile page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/  
	    public boolean verifyPhoneExtn()
	    {
	    	return phoneExtn.isPresent();	    	
	    }
	    /***********************************************************************************
	     * Function: Verify the Country field in Edit Profile page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/  
	    public boolean verifyCountry()
	    {
	    	return country.isPresent();	    	
	    }
	    /***********************************************************************************
	     * Function: Verify the Country field in Edit Profile page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/  
	    public boolean verifyCompanyUrl()
	    {
	    	return companyUrl.isPresent();
	    }
	    /***********************************************************************************
	     * Function: Verify the Role field in Edit Profile page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/  
	     public boolean verifyRole()
	    {
	    	return role.isPresent();	    	
	    }
	    /***********************************************************************************
	     * Function: Clicking the Create New User link in Home Page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/  
	    public boolean createNewUser()
	    {
	    	if (createNewUser.isPresent())
	    	{
	    		createNewUser.click();
	    		UIHelper.waitForPageToLoad(getDriver());
	    		return true;
	    	}else
	    	{
	    		return false;
	    	}
	    }
	    /***********************************************************************************
	     * Function: Verify User Registration Management details
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/  
	    public boolean verifyUserRegMgmnt()
	    {
	    	return userRegMngmnt.isPresent();
	    }
		/***********************************************************************************
	     * Function: Verify the Downloads and Offers link in Home page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/  
	    public boolean downloadsandoffersLnk()
	    {
	    	return downlaodandoffers.isPresent();	    	
	    }
		/***********************************************************************************
	     * Function: Verify the Manage Downloads link in home page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/  
	    public boolean manageDownloads()
	    {
	    	return manageDownloadsLnk.isPresent();	    	
	    }
		/***********************************************************************************
	     * Function: Clicking the Manage Downloads link in  the Home Page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/  
	    public void mngDownloadsLnk()
	    {
	    	String LnkName2=manageDownloadsLnk.getText();
	    	System.out.println(LnkName2);
	    	manageDownloadsLnk.click();
	    	UIHelper.waitForPageToLoad(getDriver());	    	
	    }
		/***********************************************************************************
	     * Function: Verify the Product Description field in Manage Downloads page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/  
	    public boolean verifyProductDesc()
	    {
	    	return productDesc.isPresent();	  
	    }
		/***********************************************************************************
	     * Function: Verify the ProductOffer Code field in Manage Downloads page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean verifyProductOfferCode()
	    {
	    	return productOfferCode.isPresent();	    	
	    }
	    /***********************************************************************************
	     * Function: Verify the Download Count field in Manage Downloads page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean verifyDownloadCount()
	    {
	    	return downloadCountLimit.isPresent();	    	
	    }
		/***********************************************************************************
	     * Function: Verify the Expiry Date field in Manage Downloads page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean verifyExpiryDate()
	    {
	    	return expiryDate.isPresent();	    	
	    }
		/***********************************************************************************
	     * Function: Verify the Document File field in Manage Downloads page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean verifyDocFile()
	    {
	    	return docfile.isPresent();	    	
	    }
		/***********************************************************************************
	     * Function: Verify the Browse button in Manage Downloads page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean verifyBrowseBtn()
	    {
	    	return browseButton.isPresent();    			
	     }
		 /***********************************************************************************
	     * Function: Verify the Upload button in Manage Downloads page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/    
	    public boolean verifyUploadbtn()
	    {
	    	return uploadBtn.isPresent();	    	
	    }
		/***********************************************************************************
	     * Function: Verify the cancel button in Manage Downloads page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean verifyCancelbtn()
	    {
	    	return cancelBtn.isPresent();	    	
	    }	 
		/***********************************************************************************
	     * Function: Verify Edit MyProfile page is displayed under My Account section
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean verifyMyAcc()
	    {
	    	return myAcc.isPresent();	    	
	    }			
		/***********************************************************************************
	     * Function: Clicking on See my New Request connection link in home page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean requestedConnectionsLnk()
	    {
	    	if(seeMyReqConnec_cmpnyUser.isPresent())
	    	{
	    		seeMyReqConnec_cmpnyUser.click();
	    		UIHelper.waitForPageToLoad(getDriver());
	    		return true;
	    	}else
	    	{
	    		return false;
	    	}
	    }	    
	    /***********************************************************************************
	     * Function: Verify Requested connections page is displayed
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean ConnectionsPage()
	    {
	    	return connectionsPage.isPresent();
	    }	    
		/***********************************************************************************
	     * Function: Verify Requested connections page is displayed under My Account section
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public void requestedConnectionsPage()
	    {
	    	if(Connections_myAcc.isPresent())
	    	{
	    		String headervalue=Connections_myAcc.getText();
	    		System.out.println(headervalue);
	    		if(headervalue.contains("My Account"))
	    		{
	    			System.out.println("Connections details are dispalyed under My Account section");
	    		}else
	    		{
	    			System.out.println("Connections details are dispalyed under My Account section");
	    		}
	    		
	    	}
	    }
		/***********************************************************************************
	     * Function: Verify Connections page is displayed under My Account section
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean verifyInvitesReceived()
	    {
	    	if(ConnectionsHdr_cmpnyUser.isPresent())
	    	{
	    		return true;
	    	}else
	    	{
	    		return false;
	    	}
	    }
		 /***********************************************************************************
	     * Function: Verify Received field in Connections page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public void verifyReceived()
	    {
	    	if(received.isPresent())
	    	{
	    		String HeaderValue=received.getText();
	    		System.out.println(HeaderValue);
	    	}
	    }
		/***********************************************************************************
	     * Function: Verify RequestFor field in Connections page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean verifyRequestFor()
	    {
	    	if(requestFor.isPresent())
	    	{
	    		String HeaderValue=ConnectionsHdr_cmpnyUser.getText();
	    		System.out.println(HeaderValue);
	    		return true;
	    	}else
	    	{
	    		return false;
	    	}
	    }
	    /***********************************************************************************
	     * Function: Verify Received From field in Connections page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean verifyReceivedFrom()
	    {
	    	return ReceivedFrom.isPresent();
	    }	
	    /***********************************************************************************
	     * Function: Verify Status field in Connections page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean verifyStatus()
	    {
	    	return status.isPresent();
	    }
	    /***********************************************************************************
	     * Function: Verify Invites Sent header section in Connections page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean verifyInvitesSent()
	    {
	    	return invitesSent.isPresent();
	    }
	    
		/***********************************************************************************
	     * Function: Verify Terms and Conditions checkbox
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean verifyTermsandConditions()
	    {
	    	return trmsandConditions.isPresent();
	    }
		/***********************************************************************************
	     * Function: Verify the Register Button
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean verifyRegisterButton()
	    {
	    	return registerButton.isPresent();
	    }
		/***********************************************************************************
	     * Function: Verify the Search Button
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean verifySearchButton()
	    {
	    	return searchButton.isPresent();
	    }	      
	    /***********************************************************************************
	     * Function: Clicking the Edit My Profile Online Link
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean clickEditmyProfile()
	    {
	    	if (editMyprofileonline.isPresent())
	    	{
	    		editMyprofileonline.click();	
	    		UIHelper.waitForPageToLoad(getDriver());
	    		return true;
	    	}else
	    	{
	    		return false;
	    	}
	    }	    
	    /***********************************************************************************
	     * Function: Verify the Terms and Conditions checkbox
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
	    public boolean verifyTermsandCondtns()
	    {
	    	return termsandCondtns.isPresent();
	    }
	    /***********************************************************************************
	     * Function: Verify the Save Button
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean verifySaveBtn()
		{
			return saveBtn.isPresent();
		}
		/***********************************************************************************
	     * Function: Clicking the Add New User to my Account Link
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean clickNewUser()
		{
			if (addNewuser.isPresent())
			{
				addNewuser.click();
				UIHelper.waitForPageToLoad(getDriver());				
				return true;
			}else
			{
				return false;
			}
		}
		/***********************************************************************************
	     * Function: Verifying the My Details section
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean verifyMydetails()
		{
			return myDetails.isPresent();
		}
		/***********************************************************************************
	     * Function: Clicking the Add photos Link
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean clickAddPhotos()
		{
			if (addPhotos.isPresent())
			{			
				addPhotos.click();
				UIHelper.waitForPageToLoad(getDriver());
				return  true;
			}else
			{
				return false;
			}					
		}
		/***********************************************************************************
	     * Function: Verify the Company Profile tab
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean verifyCompanyProfile()
		{
			return companyProfile.isPresent();
		}
		/***********************************************************************************
	     * Function: Verify the My Account section
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean verifyMyAccount()
		{
			return myAcc.isPresent();
		}
		/***********************************************************************************
	     * Function: Verify the Company Name field
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean verifycompanyName()
		{
			return companyName.isPresent();
		}
		/***********************************************************************************
	     * Function: Verify the Location field
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean verifyLocation()
		{
			return location.isPresent();
		}
		/***********************************************************************************
	     * Function: Verify the Line Of Business field
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean verifyLineofBusiness()
		{
			return lineofBusiness.isPresent();
		}
		/***********************************************************************************
	     * Function: Verify the Claimed On field
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean verifyClaimedOn()
		{
			return claimedOn.isPresent();
		}
		/***********************************************************************************
	     * Function: Verify the QR Code field
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean verifyQRCode()
		{
			return qrCode.isPresent();
		}
		/***********************************************************************************
	     * Function: Clicking the Click here to use your offer codes link
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean clickOfferCodes()
		{
			if (offerCodeLnk.isPresent())
			{
				offerCodeLnk.click();
				return true;
			}else
			{
				return false;
			}
		}
		/***********************************************************************************
	     * Function: Verify the Submit Button
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean verifySubmitBtn()
		{
			return submitBtn.isPresent();
		}
		/***********************************************************************************
	     * Function: Verify the Profile Users tab
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean verifyProfileUsers()
		{
			return profileUsers.isPresent();
		}
		/***********************************************************************************
	     * Function: Verify the User Type field
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean verifyUserType()
		{
			return 	userType.isPresent();
		}
		/***********************************************************************************
	     * Function: Verify the User Count
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean verifyUserCount()
		{
			return userCount.isPresent();
		}	
		/***********************************************************************************
	     * Function: Selecting the Search option in Home page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean selectsearchdropdown()		
		{			
			if(userOption.isPresent())
				{
				userOption.click();
				 System.out.println("enterd function");
				 userOption.selectByValue("country");				 
				}	
			return true;
		}
		/***********************************************************************************
	     * Function: Entering a value in Search Term textfield 
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public void enterCountry(String country)
		{
			System.out.println(country);
			enterSrchtrm.click();
			System.out.println("Clicked Search term box");
			enterSrchtrm.type(country);
			autosuggestion.click();
		}
		/***********************************************************************************
	     * Function: Clicking the Search button
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public void clickSearch()
		{
			btnSearch.click();
			UIHelper.waitForPageToLoad(getDriver());
		}	
		/***********************************************************************************
	     * Function: Clicking the Narrow Search section
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public void clickNarrowresults()
		{
			narrwoResults.waitUntilClickable();
			narrwoResults.click();
			//selectLocation.waitUntilClickable();			
		}
		/***********************************************************************************
	     * Function: Selecting a value from Country dropdown
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public void selectCountry(String location)		
		{
						String country = null;												
						//country = getDriver().findElement(By.xpath("//select[@id='location']/option[contains(text(),'"+location+"'")])).getText().trim(); 	
						country = getDriver().findElement(By.xpath("//select[@id='location']/option[contains(text(),'" +location+ "')]")).getText().trim();
						System.out.println(country);
						selectLocation.selectByValue(country);				
		}
		/***********************************************************************************
	     * Function: Selecting a value from State dropdown
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public void selectState(String state)
		{
			WebElement elem = null;
			String statevalue = null;				
			statevalue = getDriver().findElement(By.xpath("//select[@name='state']/option[contains(text(),'" +state+ "')]")).getAttribute("value");
			System.out.println(statevalue);
			elem = getDriver().findElement(By.xpath("//select[@name='state']"));
			Select sel = new Select(elem);
			sel.selectByVisibleText(statevalue);
		}

				/*String statevalue = null;												
				statevalue = getDriver().findElement(By.xpath("//select[@name='state']/option[contains(text(),'" +state+ "')]")).getText().trim();
				System.out.println(statevalue);						
				selectState.selectByValue(statevalue);					
		}*/
		/***********************************************************************************
	     * Function: Clicking Apply Filters button
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public void clickApplyFilters()
		{
			applyFilters.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), processicon);			
		}
		/***********************************************************************************
	     * Function: To get the total no of records displayed in the Search results page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public String getTotalRecords()
		{
			pageRange.click();
			String totrecords=pageRange.getTextValue();
			System.out.println(totrecords);
			int val1=totrecords.lastIndexOf("Of");			
			System.out.println(val1);
			recordcnt=totrecords.substring(val1+3);
			System.out.println(recordcnt);
			return recordcnt;			
		}
		/***********************************************************************************
	     * Function: Clicking the remove Filters option
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public void clickRemoveFilters()
		{
			System.out.println("Entered remove filters");
			removeFilters.click();			
			UIHelper.waitForPageToLoad(getDriver());
		}
		/***********************************************************************************
	     * Function: To get the total no of records displayed in a page
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/
		public void getOverallResults()
		{
			pageRange.click();
			String totrecords=pageRange.getTextValue();
			System.out.println(totrecords);
		}
		/***********************************************************************************
	     * Function: Selecting a value from Currency dropdown
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public void selectCurrency(String currency)
		{	
			String currencyvalue = null;
			currencyvalue = getDriver().findElement(By.xpath("//select[@id='currencyCode']/option[contains(text(),'" +currency+ "')]")).getText().trim();
			System.out.println(currencyvalue);			
			currencyCode.selectByValue(currencyvalue);			
		}
		/***********************************************************************************
	     * Function: Selecting a value from #Employee dropdown
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public void selectEmployeeRange(String employee)
		{			
			WebElement elem = null;
			String employeevalue = null;				
			employeevalue = getDriver().findElement(By.xpath("//select[@id='numemployees']/option[contains(@value,'" +employee+ "')]")).getAttribute("value");
			System.out.println(employeevalue);
			elem = getDriver().findElement(By.xpath("//select[@id='numemployees']"));
			Select sel = new Select(elem);
			sel.selectByVisibleText(employeevalue);			
		}
		/***********************************************************************************
	     * Function: Selecting a value from revenue dropdown
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public void selectRevenue(String revenue)
		{
			WebElement elem = null;
			String revenuevalue = null;				
			revenuevalue = getDriver().findElement(By.xpath("//select[@name='revenue']/option[contains(text(),'" +revenue+ "')]")).getAttribute("value");
			System.out.println(revenuevalue);
			elem = getDriver().findElement(By.xpath("//select[@name='revenue']"));
			Select sel = new Select(elem);
			sel.selectByVisibleText(revenuevalue);		
					
		}
		/***********************************************************************************
	     * Function: Verifying the Search Count for country search
	     * Input   : NA 
	     * Action  : NA
	     * Output  : NA
	     ***********************************************************************************/ 
		public boolean verifyCountryResults()
		{
			getTotalRecords();		
			String country=selectLocation.getTextValue().trim();
			System.out.println(country);				
			int val1=country.lastIndexOf("(");
			int val2=country.lastIndexOf(")");
			System.out.println(val1);			
			System.out.println(val2);
			String countryres=country.substring(val1+1, val2);
			System.out.println(countryres);
			System.out.println("the values are"+countryres);
			System.out.println("the values are"+recordcnt);		
			if(countryres.equalsIgnoreCase(recordcnt))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	/***********************************************************************************
     * Function: Verifying the Search Count for currency search
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyCurrencyResults()
	{
		getTotalRecords();			
		String currency=currencyCode.getSelectedValue();			
		System.out.println(currency);
		int val1=currency.lastIndexOf("(");
		int val2=currency.lastIndexOf(")");
		System.out.println(val1);			
		System.out.println(val2);
		String currencyres=currency.substring(val1+1, val2);
		System.out.println(currencyres);	
		System.out.println("the values are"+currencyres);
		System.out.println("the values are"+recordcnt);	
		if(currencyres.equalsIgnoreCase(recordcnt))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: Verifying the Search Count for employee search
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyEmployeeResults()
	{
		getTotalRecords();	
		String employee=noofEmployees.getSelectedValue();
		System.out.println(employee);
		int val1=employee.lastIndexOf("(");
		int val2=employee.lastIndexOf(")");
		System.out.println(val1);			
		System.out.println(val2);
		String employeeres=employee.substring(val1+1, val2);
		System.out.println(employeeres);
		System.out.println("the values are"+employeeres);
		System.out.println("the values are"+recordcnt);	
		if(employeeres.equalsIgnoreCase(recordcnt))
		{
			return true;
		}
		else
		{
			return false;
		}		
	}
	/***********************************************************************************
     * Function: Verifying the Search Count for State search
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	
	public boolean verifyStateResults()
	{
		getTotalRecords();			
		String state=selectState.getSelectedValue();
		int val1=state.lastIndexOf("(");
		int val2=state.lastIndexOf(")");
		System.out.println(val1);			
		System.out.println(val2);
		String stateres=state.substring(val1+1, val2);
		System.out.println(stateres);	
		System.out.println("the values are"+stateres);
		System.out.println("the values are"+recordcnt);	
		if(stateres.equalsIgnoreCase(recordcnt))
		{
			return true;
		}
		else
		{
			return false;
		}		
	}
	/***********************************************************************************
     * Function: Verifying the Search Count for Revenue search
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyRevenueResults()
	{
		getTotalRecords();			
		String revenue=salesRevenue.getSelectedValue();
		System.out.println(revenue);
		int val1=revenue.lastIndexOf("(");
		int val2=revenue.lastIndexOf(")");
		System.out.println(val1);			
		System.out.println(val2);
		String revenueres=revenue.substring(val1+1, val2);
		System.out.println(revenueres);	
		System.out.println("the values are"+revenueres);
		System.out.println("the values are"+recordcnt);	
		if(revenueres.equalsIgnoreCase(recordcnt))
		{
			return true;
		}
		else
		{
			return false;
		}		
	}		
	/***********************************************************************************
     * Function: Clicking on the Company name link in result page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean clickCmpnyName()
	{
		if(result.isPresent())
		{
			result.click();
			UIHelper.waitForPageToLoad(getDriver());
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: Clicking on D&B Verified Information tab
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean clickDnbVerifiedInfoTab()
	{
		if (dnbVerifiedInfoTab.isPresent())
		{
			String tab1=dnbVerifiedInfoTab.getText();
			System.out.println(tab1);
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: Clicking on the Company Provided Information tab
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean clickCompanyProvidedinfoTab()
	{
		if(companyProvidedInfoTab.isPresent())
		{
			String tab2=companyProvidedInfoTab.getText();
			System.out.println(tab2);
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the Overview section displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyOverviewSection()
	{
		if(overviewSection.isPresent())
		{
			String section1=overviewSection.getText();
			System.out.println(section1);
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the Related Tags displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyRelatedTags()
	{
		if(relatedTags.isPresent())
		{
			String tag=relatedTags.getText();
			System.out.println(tag);
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the Corporate Information section displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyCorporateInfosection()
	{
		if(corporateinformation.isPresent())
		{
			String section1=corporateinformation.getText();
			System.out.println(section1);
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the Registration Information section displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyRegistrationInfo()
	{
		if(registrationinformation.isPresent())
		{
			String section2=registrationinformation.getText();
			System.out.println(section2);
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the DUNS Number section displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyDUNSNumberSection()
	{
		if(DunsNumberSection.isPresent())
		{
			String section3=DunsNumberSection.getText();
			System.out.println(section3);
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the Key Employee section displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyKeyEmployeeSection()
	{
		if(keyEmployeeSection.isPresent())
		{
			String section4=keyEmployeeSection.getText();
			System.out.println(section4);
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the Financial information section displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyFinancialInformationsection()
	{
		if(financialInfoSection.isPresent())
		{
			String section5=financialInfoSection.getText();
			System.out.println(section5);
			return true;			
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the Products and Brands section displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyProductsandBrandsSection()
	{
		if(productsandBrands.isPresent())
		{
			String section6=productsandBrands.getText();
			System.out.println(section6);
			return true;
		}else			
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the Company Provided information tab displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean clickCompanyProvidedInfoTab()
	{
		if(companyProvidedInfoTab.isPresent())
		{
			String tab2=companyProvidedInfoTab.getText();
			System.out.println(tab2);
			companyProvidedInfoTab.click();
			return true;
		}else
		{
			return false;
		}		
	}
	/***********************************************************************************
     * Function: To verify the Executives section displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean VerifyExecutives()
	{
		if(executives.isPresent())
		{
			String section7=executives.getText();
			System.out.println(section7);
			return true;
		}
		else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the Name field displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyName()
	{
		if(nameFld.isPresent())
		{
			String field1=nameFld.getText();
			System.out.println(field1);
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the title field displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyTitle()
	{
		if(titleFld.isPresent())
		{
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the Connect button displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyConnectBtn()
	{
		if(connectBtn.isPresent())
		{
			String button1=connectBtn.getTagName();
			System.out.println(button1);
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the DUNS Registered Seal displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyDUNSRegSeal()
	{
		if(DUNSRegSeal.isPresent())
		{
			String sealname=DUNSRegSeal.getTagName();
			System.out.println(sealname);
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the D&B Verified Text displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean DBVerifiedText()
	{
		if(dbVerifiedText.isPresent())
		{
			String text=dbVerifiedText.getText();
			System.out.println(text);
			return true;			
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the About the Company section displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyAboutTheCpmny()
	{
		if(aboutTheCmpny.isPresent())
		{
			String section=aboutTheCmpny.getText();
			System.out.println(section);
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the Line of Business displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyLineofBusDesc()
	{
		if(LOBDesc.isPresent())
		{
			String SICDesc=LOBDesc.getText();
			System.out.println(SICDesc);
			int size=relatedTagsDesc.size();
			for(int i=0;i<size; i++)
			{
				if(relatedTagsDesc.get(i).containsOnlyText(SICDesc))
				{
					System.out.println("Line of Business Description is displayed under Related tags section");
				}
			}
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the Search option displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifySearchOption()
	{
		if(searchOption.isPresent())
		{
			String option1=searchOption.getText();
			System.out.println(option1);
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the Disclaimer section displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifyDisclaimer()
	{
		if(disclaimer.isPresent())
		{					
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the Signed in Link displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifySignedinasLink(String username)
	{
			String link1=signedinasLink.getTextValue();
			System.out.println(link1);
			//String userName = System.getProperty("DrsUserName");				
			System.out.println(username);
			if(link1.contains(username))
			{
				System.out.println("User name is displaying");
				return true;
			}else
			{
				return false;
			}			
	}
	/***********************************************************************************
     * Function: To verify the Sign Out link displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean verifySignOutLink()
	{
		if(signOutLink.isPresent())
		{
			String link2=signOutLink.getText();
			System.out.println(link2);
			return true;
		}else
		{
			return false;
		}
	}
	/***********************************************************************************
     * Function: To verify the Profile Claimed button displayed in Company Profile page
     * Input   : NA 
     * Action  : NA
     * Output  : NA
     ***********************************************************************************/ 
	public boolean VerifyProfileClaimedBtn()
	{
		if(claimBtn.isPresent())
		{
			return true;
		}else
		{
			return false;
		}
	}
	public boolean clickMyDashboard()
	{
		if(myDashboard.isPresent())
		{
			myDashboard.click();
			UIHelper.waitForPageToLoad(getDriver());
			return true;
		}else
		{
			return false;
		}
	}	
}
