package com.dnb.automation.srm.pages;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.core.pages.WebElementState;

/**********************************************************************************************
 * SRMDashboardPage.java - This program contains steps for Dashboard page
 * functionalities
 *
 * @author Duvvuru Naveen
 ***********************************************************************************************/
public class SRMDashboardPage extends PageObject {

	@FindBy(xpath = "//*[@id='wrapper']//div[6]")
	private WebElementFacade srmFrame;

	@FindBy(xpath = "//*[@id='wrapper_header']//*[@class='header-tabs-container clearFix']//ul//*[@id='desktopMenu']/a")
	private WebElementFacade dashBoard;

	@FindBy(xpath = ".//*[@id='wrapper']//*[@class='container']//*[@class='dashboard-container']//*[@class='page-heading']/h1")
	private WebElementFacade dashboardTitleEle;

	@FindBy(xpath = "//*[@class='dashboard-container']//*[@id='search_tab']//div//div//*[@id='dboardSearchType-button']/span[2]")
	private WebElementFacade dunsDropDown;

	@FindBy(xpath = "//*[@class='ui-selectmenu-menu ui-selectmenu-open']//ul/li[2]/a[contains(.,'D-U-N-S Number')]")
	private WebElementFacade dunsValue;

	@FindBy(xpath = ".//*[@id='dunsUniverseTab']//a")
	private WebElementFacade dunsUniverseTab;

	@FindBy(xpath = ".//*[@id='personalFolderTab']//a")
	private WebElementFacade personalFolderTabEle;

	@FindBy(xpath = ".//*[@id='supplyBaseTab']//a")
	private WebElementFacade supplyBaseTabEle;

	@FindBy(xpath = ".//*[@id='certifiedSuppliersTab']//a")
	private WebElementFacade certifiedSuppliersTabEle;

	@FindBy(xpath = "//*[@class='ui-selectmenu-menu ui-selectmenu-open']//ul/li/a")
	private List<WebElement> searchTypeOptions;

	private String dropdownXpathForSearchType = "//*[@class='ui-selectmenu-menu ui-selectmenu-open']//ul/li/a[contains(.,'SERENITY')]";

	@FindBy(xpath = "//*[@class='dashboard-container']//*[@id='search_tab']//*[@id='main_search']")
	private WebElementFacade searchBox;

	@FindBy(xpath = "//*[@id='ui-id-5']")
	private WebElementFacade smartSearchResultsPopup;

	public WebElementFacade getSmartSearchResultsPopup() {
		return smartSearchResultsPopup;
	}

	@FindBy(xpath = ".//*[contains(@id,'ui-id-')]//li[1]/a")
	private WebElementFacade firstSearchItemEleInSmartSearchResults;

	@FindBy(xpath = "//*[@id='example']//*[@id='search-results']/tr[1]/td[1]/h4/a")
	private WebElementFacade searchResultsEle;

	public WebElementFacade getSearchResultsEle() {
		return searchResultsEle;
	}

	@FindBy(xpath = ".//*[@id='wrapper']//*[@class='page-heading_alert']/h1")
	private WebElementFacade alertHeadingEle;

	@FindBy(xpath = ".//*[@id='predictivePosScore']")
	private WebElementFacade predictivePositiveScoreEle;

	@FindBy(xpath = ".//*[@id='predictiveNegScore']")
	private WebElementFacade predictiveNegativeScoreEle;

	@FindBy(xpath = ".//*[@id='govtIndcPosScore']")
	private WebElementFacade govIndicatorsPositiveScoreEle;

	@FindBy(xpath = ".//*[@id='govtIndcNegScore']")
	private WebElementFacade govIndicatorsNegativeScoreEle;

	@FindBy(xpath = ".//*[@id='operationsPosScore']")
	private WebElementFacade operationPositiveScoreEle;

	@FindBy(xpath = ".//*[@id='operationsNegScore']")
	private WebElementFacade operationNegativeScoreEle;

	@FindBy(xpath = ".//*[@id='countryRiskPosScore']]")
	private WebElementFacade countryRisksPositiveScoreEle;

	@FindBy(xpath = ".//*[@id='countryRiskNegScore']")
	private WebElementFacade countryRisksNegativeScoreEle;

	@FindBy(xpath = ".//*[@id='Alerttabs']/ul/li/a/span")
	private List<WebElement> alertTabElements;

	@FindBy(xpath = ".//*[@id='search-results']/tr[1]/td[1]/h4/a")
	private WebElementFacade firstSearchResultEle;

	public WebElementFacade getFirstSearchResultEle() {
		return firstSearchResultEle;
	}

	@FindBy(xpath = ".//*[@id='rec_search1']/span[1]")
	private WebElementFacade advancedSearchEle;

	@FindBy(xpath = ".//*[@id='advancesearchbtn']")
	private WebElementFacade advancedSearchbtnEle;

	@FindBy(xpath = ".//*[@id='recent_search1']//*[@class='advinput']/label")
	private List<WebElement> advancedSearchFieldNamesElements;

	@FindBy(xpath = ".//*[@id='duns']")
	private WebElementFacade dunsFieldEle;

	@FindBy(xpath = ".//*[@id='nationalID-button']/span[1]")
	private WebElementFacade nationalBusinessIdFieldEle;

	@FindBy(xpath = ".//*[@id='nationalIdNum']")
	private WebElementFacade nationalBusinessIdNumberFieldEle;

	@FindBy(xpath = ".//*[@id='address']")
	private WebElementFacade addressFieldEle;

	@FindBy(xpath = ".//*[@id='city']")
	private WebElementFacade cityFieldEle;

	@FindBy(xpath = ".//*[@id='country-button']/span[2]")
	private WebElementFacade countryDropdownEle;

	@FindBy(xpath = ".//*[@id='state-button']/span[2]")
	private WebElementFacade stateDropdownEle;

	@FindBy(xpath = ".//*[@id='zipCd']")
	private WebElementFacade postalCodeFieldEle;

	@FindBy(xpath = ".//*[@id='location-button']/span[2]")
	private WebElementFacade locationTypeDropdownEle;

	@FindBy(xpath = ".//*[@id='saveSearchLabel']")
	private WebElementFacade saveSearchBtnEle;

	@FindBy(xpath = ".//*[@id='rec_search']/span[1]")
	private WebElementFacade savedSearchsLinkEle;

	@FindBy(xpath = ".//*[@id='save_searchblock']/ul/li/a/span")
	private List<WebElement> savedSearchElements;
	
//May 31 Top 10 Risk Script written By Sradha
	@FindBy(xpath = ".//*[@id='save_searchblock']/ul[1]/li/a/span")
	private WebElementFacade WebElement;

	@FindBy(xpath = ".//*[@id='save_searchblock']/ul[1]/li/a/span")
	private WebElementFacade SavedCertified;

	@FindBy(xpath = ".//*[@id='save_searchblock']/ul[1]/li/a/span")
	private WebElementFacade savedDatavalue;

	@FindBy(xpath = ".//*[@id='save_searchblock']/ul[1]/li/a/span")
	private WebElementFacade savedPublicValue;
	
	@FindBy(xpath= ".//*[@id='save_searchblock']/ul[1]/li/a/span")
	private WebElementFacade savedYourShareValue;
	
	@FindBy(xpath = ".//*[@id='risk_comp-button']/span[1]")
	private WebElementFacade mywatchlist;
    
	
	@FindBy(xpath = ".//*[@id='topCompanies']/div/table/tbody/tr/td[2]/a")
	private WebElementFacade companyname ;
    
	
	@FindBy(xpath = ".//*[@id='wrapper']//input[contains(@value,'Confirm')]")
	private WebElementFacade confirmBtnForSavedSearchEle;

	public WebElementFacade getConfirmBtnForSavedSearchEle() {
		return confirmBtnForSavedSearchEle;
	}

	@FindBy(xpath = ".//*[@id='confMsg']/span[contains(.,'Search saved successfully')]")
	private WebElementFacade confirmMsgForSavedSearchEle;

	public WebElementFacade getConfirmMsgForSavedSearchEle() {
		return confirmMsgForSavedSearchEle;
	}

	@FindBy(xpath = ".//*[@id='searchExport']")
	private WebElementFacade exportBtnEle;

	public WebElementFacade getExportBtnEle() {
		return exportBtnEle;
	}

	@FindBy(xpath = ".//*[@id='searchbtn']")
	private WebElementFacade searchBtnEle;

	public WebElementFacade getSearchBtnEle() {
		return searchBtnEle;
	}

	@FindBy(xpath = ".//*[@class='container']//div[6][@class='compliance-export-popup']/ul[contains(@class,'file-type')]//li/a")
	private List<WebElement> exportOptionsElements;

	@FindBy(xpath = ".//*[@id='searchExportCsv']")
	private WebElementFacade csvExportOptEle;
	

	@FindBy(xpath = ".//*[@id='searchExportPdf']")
	private WebElementFacade pdfExportOptEle;

	@FindBy(xpath = ".//*[@id='search-results']/tr[2]")
	private WebElementFacade companyRatingsEleInSearchResults;

	@FindBy(xpath = ".//*[@id='search-results']/tr[2]//*[@class='cmp-profile-score']/a[contains(.,'Go To Company Profile Page')]")
	private WebElementFacade companyProfilePageLinkEle;

	@FindBy(xpath = ".//*[@id='sez-button']/span[2]")
	private WebElementFacade scoreDropdownEle;

	@FindBy(xpath = ".//*[@id='risk_comp-button']/span[2]")
	private WebElementFacade personalFolderDropdownEle;

	@FindBy(xpath = ".//*[@id='scoreHead']")
	private WebElementFacade scoreHeaderEle;

	@FindBy(xpath = ".//*[@id='wrapper']//span[contains(.,'Top 10 Riskiest Companies By score')]")
	private WebElementFacade topRisiestCompHeaderEle;

	@FindBy(xpath = ".//*[@id='sez-button']/span[1]")
	private WebElementFacade scoreEle;

	@FindBy(xpath = ".//*[@id='riskiestCompaniesExport']")
	private WebElementFacade exportBtnEleForTopCompanies;

	public WebElementFacade getExportBtnEleForTopCompanies() {
		return exportBtnEleForTopCompanies;
	}

	@FindBy(xpath = ".//*[@id='wrapper']//*[@class='dashboard-container']//*[@class='GraphContainer']//span[contains(.,'Top 10 Riskiest')]")
	private WebElementFacade topCompaniesHeadingEle;

	public WebElementFacade getTopCompaniesHeadingEle() {
		return topCompaniesHeadingEle;
	}

	@FindBy(xpath = ".//*[@id='csvExport']")
	private WebElementFacade csvExportOptEleForTopCompanies;

	@FindBy(xpath = ".//*[@id='pdfExport']")
	private WebElementFacade pdfExportOptEleForTopCompanies;

	@FindBy(xpath = ".//*[@class='compliance-export-popup']/ul//li/a")
	private List<WebElement> exportOptionsElementsForTopCompanies;

	@FindBy(xpath = ".//*[@id='topCompanies']/div[1]/table/tbody/tr[1]/td[1]/input")
	private WebElementFacade firstCompanyChkBoxEle;

	@FindBy(xpath = ".//*[@id='topCompanies']/div[1]/table/tbody/tr[1]/td[1]/input[contains(@checked,'checked')]")
	private WebElementFacade firstCompanyChkBoxCheckedEle;

	@FindBy(xpath = ".//*[@id='topCompanies']/div[2]/table/tbody/tr[1]/td[1]/input")
	private WebElementFacade secondCompanyChkBoxEle;

	@FindBy(xpath = ".//*[@id='topCompanies']/div[2]/table/tbody/tr[1]/td[1]/input[contains(@checked,'checked')]")
	private WebElementFacade secondCompanyChkBoxCheckedEle;

	@FindBy(xpath = ".//*[@id='topCompanies']/div[3]/table/tbody/tr[1]/td[1]/input")
	private WebElementFacade thirdCompanyChkBoxEle;

	@FindBy(xpath = ".//*[@id='topCompanies']/div[3]/table/tbody/tr[1]/td[1]/input[contains(@checked,'checked')]")
	private WebElementFacade thirdCompanyChkBoxCheckedEle;

	@FindBy(xpath = ".//*[@id='topCompanies']/div[4]/table/tbody/tr[1]/td[1]/input")
	private WebElementFacade fourthCompanyChkBoxEle;

	@FindBy(xpath = ".//*[@id='topCompanies']/div[4]/table/tbody/tr[1]/td[1]/input[contains(@checked,'checked')]")
	private WebElementFacade fourthCompanyChkBoxCheckedEle;

	@FindBy(xpath = ".//*[@id='topCompanies']/div[5]/table/tbody/tr[1]/td[1]/input")
	private WebElementFacade fifthCompanyChkBoxEle;

	@FindBy(xpath = ".//*[@id='topCompanies']/div[5]/table/tbody/tr[1]/td[1]/input[contains(@checked,'checked')]")
	private WebElementFacade fifthCompanyChkBoxCheckedEle;

	@FindBy(xpath = ".//*[@id='recentSuppliers']")
	private WebElementFacade recentlyViewedSuppliersSecEle;

	public WebElementFacade getRecentlyViewedSuppliersSecEle() {
		return recentlyViewedSuppliersSecEle;
	}

	@FindBy(xpath = ".//*[@id='severe_risk-button']/span[2]")
	private WebElementFacade folderSelcDropdownEleForSevereRiskCond;

	@FindBy(xpath = ".//*[@id='PieChart']//*[contains(@id,'highcharts')]//*[contains(@class,'highcharts-data-labels highcharts-tracker')]//*[contains(.,'Bankruptcy')]")
	private WebElementFacade riskCondBankruptcyEle;

	@FindBy(xpath = ".//*[@id='PieChart']//*[contains(@id,'highcharts')]//*[contains(@class,'highcharts-data-labels highcharts-tracker')]//*[contains(.,'Criminal')]")
	private WebElementFacade riskCondCriminalEle;

	@FindBy(xpath = ".//*[@id='PieChart']//*[contains(@id,'highcharts')]//*[contains(@class,'highcharts-data-labels highcharts-tracker')]//*[contains(.,'Proceedings')]")
	private WebElementFacade riskCondProceedinsEle;

	@FindBy(xpath = ".//*[@id='PieChart']//*[contains(@id,'highcharts')]//*[contains(@class,'highcharts-data-labels highcharts-tracker')]//*[contains(.,'Business')]")
	private WebElementFacade riskCondBusinessEle;

	@FindBy(xpath = ".//*[@id='PieChart']//*[contains(@id,'highcharts')]//*[contains(@class,'highcharts-data-labels highcharts-tracker')]//*[contains(.,'Deterioration')]")
	private WebElementFacade riskCondDeteriorationEle;

	@FindBy(xpath = ".//*[@id='PieChart']//*[contains(@id,'highcharts')]//*[contains(@class,'highcharts-data-labels highcharts-tracker')]//*[contains(.,'Debarred')]")
	private WebElementFacade riskCondDebarredEle;

	@FindBy(xpath = ".//*[@id='suppliersCountry']")
	private WebElementFacade riskCondNameEleFromAllSupplier;

	@FindBy(xpath = ".//*[@id='severeRiskSupplierExport']")
	private WebElementFacade exportBtnEleForSevereRiskCond;

	public WebElementFacade getExportBtnEleForSevereRiskCond() {
		return exportBtnEleForSevereRiskCond;
	}
	
	@FindBy(xpath=".//*[@id='severeRiskExport']")
	public WebElementFacade exportSevereRislEle;

	@FindBy(xpath = ".//*[@id='wrapper']//*[@class='page-heading']/h1")
	private WebElementFacade allSuppliersHeaderEle;

	public WebElementFacade getAllSuppliersHeaderEle() {
		return allSuppliersHeaderEle;
	}

	@FindBy(xpath = ".//*[@id='wrapper']//*[@class='dashboard-container']//*[@class='double_GraphContainer']//span[contains(.,'Severe Risk Condition')]")
	private WebElementFacade severeRiskConditionHeaderEle;

	public WebElementFacade getSevereRiskConditionHeaderEle() {
		return severeRiskConditionHeaderEle;
	}

	@FindBy(xpath = ".//*[@id='exportTocsvSevereRiskSuppliers']/a")
	private WebElementFacade csvExportOptEleForSevereRiskCond;
	
	@FindBy(xpath=".//*[@id='severeRiskExportCsv']")
	private WebElementFacade csvExportSevereRisk;

	@FindBy(xpath = ".//*[@id='wrapper']//*[@class='dashboard-queue-title border-top-radius']/span[contains(.,'Portfolio Risk')]")
	private WebElementFacade portfolioRisSecEle;

	@FindBy(xpath = ".//*[@id='portfolio_risk-button']/span[2]")
	private WebElementFacade folderDropdownEleForPortfolioRisk;

	@FindBy(xpath = ".//*[@id='portfolio_sez-button']/span[2]")
	private WebElementFacade scoreDropdownEleForPortfolioRisk;

	@FindBy(xpath = ".//*[contains(@id,'highcharts')]//*[@class='highcharts-legend']//*[@class='highcharts-legend-item']/*[contains(.,'My Watchlist')]")
	private WebElementFacade myWatchListEle;
	
	@FindBy(xpath=".//*[@id='cstmFieldContainer']/span[contains(text(),'Your Share')]/following::span[1]")
	private WebElementFacade yourShareValue;
	
	@FindBy(xpath=".//*[@id='topCompanies']/div[1]/table/tbody/tr/td[1]/input")
	private WebElementFacade selectCheckBoxComapnayName;
	
	@FindBy(xpath=".//*[@id='errMsg']/span")
	private WebElementFacade alertMessage;
	
	@FindBy(xpath = ".//*[@id='risk_comp-button']/span[2]")
	private WebElementFacade myWatchlistDropDown;
	
	/*@FindBy(xpath = ".//*[@id='risk_comp-button']/span[contains(text(),'April2016_2')]/following::span[1]")
	private WebElementFacade myWatchlistDropDown;*/
	
	@FindBy(xpath=".//*[@id='risk_comp-menu']/li")
	private WebElementFacade myWatchListText;

	@FindBy(xpath = ".//*[@id='topCompanies']/div")
	private WebElementFacade companiesList;
	
	/*@FindBy(xpath=".//*[@id='topCompanies']/div[1]/table/tbody/tr/td[1]")
	private WebElementFacade selectCheckBox;*/
	
	@FindBy(xpath=".//*[@id='topCompanies']/div[3]/table/tbody/tr/td[1]")
	private WebElementFacade selectCheckBox;
	
	@FindBy(xpath=".//*[@id='topCompanies']/div/table/tbody/tr/td[2]/a")
	private WebElementFacade SERselectCheckBox;
	
	@FindBy(xpath=".//*[@id='highcharts-2']//*[name()='svg'/*[name()='g'][3]")
	private WebElementFacade graphPanel;
	
	@FindBy(xpath=".//*[@id='highcharts-96']/*[name()='svg']/*[name()='g'][8]/*[name()='text'][1]")
	private WebElementFacade graphValue;
	
	@FindBy(xpath=".//*[@id='highcharts-8']//*[name()='svg']/*[name()='g'][3]")
	private WebElementFacade graphXValue;
	
	@FindBy(xpath=".//*[@id='highcharts-8']/*[name()='svg']/*[name()='g'][7]")
	private WebElementFacade graphYvalue;		
	
	@FindBy(xpath="//*[@id='highcharts-96']/*[name()='svg']/*[name()='g']/*[name()='g'][4]/*[name()='path']")
	private WebElementFacade top10RiskScoreMonths;
	
	@FindBy(xpath=".//*[@id='topCompanies']/div[4]/table/tbody/tr/td[1]")
	private WebElementFacade uncheckSupplier;
	
	@FindBy(xpath=".//*[@id='wrapper']/div[1]/table/div[2]/table")
	private WebElementFacade byDefaultSupplier;
	
	@FindBy(xpath=".//*[@id='highcharts-0']//*[name()='svg']/*[name()='g'][8]/path[2]")
	private WebElementFacade firstGraphPlottedValue;
	 
	@FindBy(xpath=".//*[@id='highcharts-28']//*[name()='svg']/*[name()='g'][8]/text/path[1]")
	private WebElementFacade firstGraphPlottedScoreValue;
	
	//*[@id='highcharts-96']/*[name()='svg']/*[name()='g']/*[name()='g'][4]/*[name()='path'][1]
	
	//.//*[@id='highcharts-96']/*[name()='svg']/*[name()='g'][8]/*[name()='text'][1]
	
//PortoFolio risk New scenario Xpath:Sradha
	
	@FindBy(xpath = ".//*[@id='wrapper']//*[@class='page-heading']/h1")
	private WebElementFacade AllSuppliersData;

	public WebElementFacade getAllSuppliersData() {
		return AllSuppliersData;
	}
	
	
	@FindBy(xpath=".//*[@id='wrapper']/div[6]/div[4]/div[6]/div/div[3]/div[1]/span[1]")
	private WebElementFacade portoFolioRiskvalue;
	
	@FindBy(xpath=".//*[@id='wrapper']/div[6]/div[4]/div[6]/div/div[3]/div[2]/div[1]")
	private WebElementFacade portFolioTwoIcon;
	
	@FindBy(xpath=".//*[@id='portfolio_sez-button']/span[2]'")
	private WebElementFacade  portofolioScoreValue;
	
	@FindBy(xpath=".//*[@id='portfolio_risk-button'")
	private WebElementFacade byDefaultMywatchListValue;
	
	@FindBy(xpath=".//*[@id=portfolioRiskExport")
	private WebElementFacade portfolioExportValue;
	
	@FindBy(xpath = ".//*[@id=portfolioRiskExport")
	private List<WebElement> portfolioExportValueSSI;
	
	@FindBy(xpath=".//*@id='portfolioRiskExportCsv'")
	private WebElementFacade csvExportOptEleForPortFolio;
	
	
	@FindBy(xpath=".//*@id='portfolioRiskExportPdf'")
	private WebElementFacade pdfExportOptEleForPortFolio;
	
	@FindBy(xpath=".//*[@id='HintText']/div[1]")
	private WebElementFacade circleEmptySERValue;
	
	@FindBy(xpath=".//*[@id='HintText']/div[2]")
	private WebElementFacade circleFullSSIValue;
	
	/*@FindBy(xpath=".//*[@id='highcharts-4']//*[name()='svg']//*[name()='g'][2]//*[@class='highcharts-grid']")
	private WebElementFacade barGraphLineGraphvalue;*/
	
	@FindBy(xpath=".//*[@id='wrapper']//*[@class='dashboard-container']//*[@class='dashboard-queue']//*[@id='barChartcontainer']")
	private WebElementFacade barGraphLineGraphvalue;
	
	@FindBy(xpath=".//*[@id='highcharts-20']//*[name()='svg']/*[name()='g'][5]/*[name()='g'][1]/*[name()='rect'][2]")
	private WebElementFacade barGraphvalue;
	
	
	@FindBy(xpath=".//*[@id='highcharts-12']//*[name()='svg']/*[name()='g'][3]")
	private WebElementFacade lineGraphXAxixValue;
	
	@FindBy(xpath=".//*[@id='BarChart']//*[contains(@id,'highcharts')]//*[contains(@class,'highcharts-series highcharts-tracker')] ")
	private WebElementFacade lineGraphSERValue;
	
	@FindBy(xpath=".//*[@id='highcharts-8']//*[name()='svg']/*[name()='g'][5]/*[name()='g'][1]/*[name()='rect'][1]")
	private WebElementFacade lineGraphPerntgSERValue;
	
	@FindBy(xpath=".//*[@id='bubble_block']/div/div[2]")
	private WebElementFacade bubblegraph1axixValue;
	
	@FindBy(xpath=".//*[@id='bubble_block']//*/div/span[contains(text(),'High Risk')]/img")
	private WebElementFacade highRiskSEREle;
	
    @FindBy(xpath="//*/div[@class='qtip-content qtip-content']/div/span[2]")
	private WebElementFacade SERScoreValue;
	
    @FindBy(xpath="//*/div[@class='qtip-content qtip-content']/div/span[1]")
	private WebElementFacade SSIScoreValue;
	
    @FindBy(xpath=".//*[@id='bubble_block']//*/div/span[contains(text(),'Medium Risk')]/img")
	private WebElementFacade mediumRiskEle;
    
    @FindBy(xpath="//*/div[@class='qtip-content qtip-content']/div/span[2]")
	private WebElementFacade highRiskSSEScoreValue;
    
    @FindBy(xpath=".//*[@id='bubble_block']//*/div/span[contains(text(),'Low Risk')]/img")
    private WebElementFacade lowRiskEle;
    
	@FindBy(xpath=".//*[@id='wrapper']/div[6]/div[4]/div[6]/div/div[2]/div[1]/span[3]")
	public  WebElementFacade SevereRiskEle;
    
	@FindBy(xpath=".//*[@id='highcharts-0']/*[name()='svg']/*[name()='g'][1]/*[name()='g'][1]/*[name()='path'][1]")
	public WebElementFacade piaChartCenterValue;
	
	@FindBy(xpath=".//*[@id='severeRiskExportCsv']")
	public WebElementFacade severeRiskCsvExportOptEle;
	
	@FindBy(xpath=".//*[@id='severeRiskExportPdf']")
	public WebElementFacade SevereRiskpdfExportOptEle;
	
   // 
	
	
	@FindBy(xpath = "//*[@id='wrapper']/div[6]/div[4]")
	private WebElementFacade profileFrame;
	
	@FindBy(xpath = ".//*[contains(@id,'highcharts')]//*[@class='highcharts-legend']//*[@class='highcharts-legend-item']/*[contains(.,'All Watchlists')]")
	private WebElementFacade allWatchListsEle;

	@FindBy(xpath = ".//*[@id='wrapper']//*[@id='supplier_viewTable']//*[@id='SupplierBlock']")
	private WebElementFacade listOfSuppliersTableEleForPortfolioRisk;

	public WebElementFacade getListOfSuppliersTableEleForPortfolioRisk() {
		return listOfSuppliersTableEleForPortfolioRisk;
	}

	@FindBy(xpath = ".//*[@id='wrapper']//*[@class='dashboard-queue-title border-top-radius']/h3")
	private WebElementFacade allSuppliersEle;

	@FindBy(xpath = ".//*[@id='BarChart']//*[contains(@id,'highcharts')]//*[contains(@class,'highcharts-series highcharts-tracker')]/*[contains(@y,'192.5')]")
	private WebElementFacade firstBarGraphEleInPortFolioRiskSec;

	@FindBy(xpath = ".//*[@id='BarChart']//*[contains(@id,'highcharts')]//*[contains(@class,'highcharts-tooltip')]/*[contains(@x,'8')]")
	private WebElementFacade tooltipForFirstBarGraphInPortFolioRiskSec;

	public WebElementFacade getTooltipForFirstBarGraphInPortFolioRiskSec() {
		return tooltipForFirstBarGraphInPortFolioRiskSec;
	}

	@FindBy(xpath = ".//*[@id='wrapper']//*[@class='dashboard-container']//*[@class='dashboard-queue']//*[@id='barChartcontainer']")
	private WebElementFacade barchartEle;

	public WebElementFacade getBarchartEle() {
		return barchartEle;
	}

	@FindBy(xpath = ".//*[@id='circlePortfolioRisk']")
	private WebElementFacade bubblesBtnEle;

	@FindBy(xpath = ".//*[@id='HintText']")
	private WebElementFacade hintTextEle;

	@FindBy(xpath = ".//*[@id='bubble_block']//*[@class='vennContainer']//*[contains(@class,'left')]/span")
	private List<WebElement> riskTypesInPortfolioRiskBubbleSec;

	@FindBy(xpath = ".//*[@id='highSsi']")
	private WebElementFacade highSSIEle;

	@FindBy(xpath = ".//*[@id='highSer']")
	private WebElementFacade highSEREle;

	@FindBy(xpath = ".//*[@id='medSsi']")
	private WebElementFacade medSSIEle;

	@FindBy(xpath = ".//*[@id='medSer']")
	private WebElementFacade medSEREle;

	@FindBy(xpath = ".//*[@id='lowSsi']")
	private WebElementFacade lowSSIEle;

	@FindBy(xpath = ".//*[@id='lowSer']")
	private WebElementFacade lowSEREle;

	@FindBy(xpath = ".//*[@id='barPortfolioRisk']")
	private WebElementFacade barChartButtonEle;

	private String ajaxImgLoadingEleInSearchTab = ".//*[@id='wrapper']//*[@class='searchTabLoading']/img";
	private String highRiskEleXpath = ".//*[@id='bubble_block']//*[@class='vennContainer']//*[contains(@class,'left')]/span[contains(.,'High Risk')]";
	private String lowRiskEleXpath = "id('lowCommon')";
	private String imgLoadingInBarChartArea = ".//*[@id='barChartcontainer']/*[@class='bubblechartloading']/img";
	private String firstSearchResultXpath = "//*[@id='example']//*[@id='search-results']/tr[1]/td[1]/h4/a";
	private String scoreMenuXpathForPortfolioRisk = ".//*[@id='portfolio_sez-menu']/li/a[contains(.,'SERENITY')]";
	private String portfolioRiskMenuOptXpath = ".//*[@id='portfolio_risk-menu']/li/a[contains(.,'SERENITY')]";
	private String ajaxImgLoadingXpathInBubblesForPortfolioRisk = ".//*[@id='circleblock']//*[@class='bubblechartloading']/img";
	private String ajaxImgLoadingXpathInSevereRiskSec = ".//*[@id='wrapper']//*[@class='piegraphloading']/img";
	private String allSuppliersResultLoadingXpath = ".//*[@id='wrapper']//*[@class='allSuppliersResultloading']/img";
	private String personalFolderDropdownItemsXpathInSevereRiskSec = ".//*[@id='severe_risk-menu']/li/a[contains(.,'SERENITY')]";
	private String scoresDropdownItemsXpath = ".//*[@id='sez-menu']/li/a[contains(.,'SERENITY')]";
	private String personalFolderDropdownItemsXpath = ".//*[@id='risk_comp-menu']/li/a[contains(.,'SERENITY')]";
	private String ajaxImgLoadingXpathForTopCompaniesSection = ".//*[@id='wrapper']//*[@class='companiesListContent']//*[@class='ajxloading']/img";
	private String ajaxImgLoadingXpath = ".//*[@id='wrapper']//*[@class='searchResultloading']/img";
	private String advCountryMenuOptXpath = ".//*[@id='country-menu']/li/a[contains(.,'SERENITY')]";
	private String advStateMenuOptXpath = ".//*[@id='state-menu']/li/a[contains(.,'SERENITY')]";
	private String advLocationMenuOptXpath = ".//*[@id='location-menu']/li/a[contains(.,'SERENITY')]";
	private String ajaxLoadingImageXpathForSmartSearch = ".//*[@id='search_tab']//*[@id='tabs']//*[@id='tabs-1']//*[@class='autoCompleteLoading']/img";
	private String ajaxLoadingImageXpathForIndicators = ".//*[@id='wrapper']//*[@class='dashboard-container']//*[@class='alertbox-container']//*[@class='alertloading']/img";
	private String ajaxLoadingImageXpathForAlertInbox = ".//*[@id='wrapper']//*[@class='dashboard-container']//*[@class='searchTabLoading']/img";
	private String indicatorsXpath = ".//*[@id='wrapper']//*[@class='dashboard-container']//*[@class='alertbox-container']/ul/li/div/span[contains(.,'SERENITY')]";
	private ArrayList<String> searchOptionValues = new ArrayList<String>();
	private ArrayList<String> alertTabsList = new ArrayList<String>();
	private ArrayList<String> advSearchFieldNames = new ArrayList<String>();
	private ArrayList<String> savedSearchDataList = new ArrayList<String>();
	private ArrayList<String> exportOptionsList = new ArrayList<String>();
	private ArrayList<String> exportOptionsListForTopCompanies = new ArrayList<String>();
	private ArrayList<String> severeRiskCondNamesList = new ArrayList<String>();
	private ArrayList<String> watchListsNameList = new ArrayList<String>();
	private ArrayList<String> riskTypesListForBubbles = new ArrayList<String>();
	
	/***************************************************************************************
	 * Function:Navigate to home page
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void navigateToHomeTab() {
		try {
			dashBoard.click();
			UIHelper.waitForPageToLoad(getDriver());
			dashboardTitleEle.waitUntilPresent();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxImgLoadingEleInSearchTab);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/***************************************************************************************
	 * Function:Get the SRM Application Dashboard Page Title
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/

	
	public String getSRMDashboardPageTitle() {
		dashBoard.waitUntilPresent();
		//dashBoard.click();
		return dashboardTitleEle.getText();
	}
    
	/***************************************************************************************
	 * Function:Goto D&B DUNS Universe Tab
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void navigateToDnBDunsUniverseTab() {
		try {
			dunsUniverseTab.waitUntilPresent();
			UIHelper.mouseOverandclickanElement(getDriver(), dunsUniverseTab);
		} catch (Exception e) {
		}
	}
    
	/***************************************************************************************
	 * Function: Goto My Personal Folder Tab
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void navigateToPersonalFolderTab() {
		try {
			personalFolderTabEle.waitUntilPresent();
			UIHelper.mouseOverandclickanElement(getDriver(), personalFolderTabEle);
		} catch (Exception e) {
		}
	}
    
	/***************************************************************************************
	 * Function: Goto Supply Base Tab
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void navigateToSupplyBaseTab() {
		try {
			supplyBaseTabEle.waitUntilPresent();
			UIHelper.mouseOverandclickanElement(getDriver(), supplyBaseTabEle);
		} catch (Exception e) {
		}
	}
    
	/***************************************************************************************
	 * Function:Goto Certified Suppliers Tab
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void navigateToCertifiedSuppliersTab() {
		try {
			certifiedSuppliersTabEle.waitUntilPresent();
			UIHelper.mouseOverandclickanElement(getDriver(), certifiedSuppliersTabEle);
		} catch (Exception e) {
		}
	}
    
	/***************************************************************************************
	 * Function:Get Search Type Options
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public ArrayList<String> getSearchOptions() {
		try {
			dunsDropDown.waitUntilPresent();
			if (dunsDropDown.isPresent()) {
				UIHelper.highlightElement(getDriver(), dunsDropDown);
				dunsDropDown.click();
			}

			for (WebElement searchTypeOption : searchTypeOptions) {
				searchOptionValues.add(searchTypeOption.getText());
			}

			if (dunsDropDown.isPresent()) {
				dunsDropDown.click();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return searchOptionValues;
	}
     
	/***************************************************************************************
	 * Function:Select Search Type Option
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void selectSearchTypeOption(String searchOption) {
		try {
			if (dunsDropDown.isPresent()) {
				UIHelper.highlightElement(getDriver(), dunsDropDown);
				dunsDropDown.click();
			}

			String tempSearchTypeOptionXpath = dropdownXpathForSearchType.replace("SERENITY", searchOption);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempSearchTypeOptionXpath);
			WebElementFacade searchTypeOptionEle = find(By.xpath(tempSearchTypeOptionXpath));
			searchTypeOptionEle.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
	/***************************************************************************************
	 * Function: Enter Search criteria in search field
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void enterSearchKeyInSearchField(String companyNameOrDuns) {
		try {
			searchBox.waitUntilPresent();
			if (searchBox.isPresent()) {
				UIHelper.highlightElement(getDriver(), searchBox);
				searchBox.type(companyNameOrDuns);
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), ajaxLoadingImageXpathForSmartSearch);
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxLoadingImageXpathForSmartSearch);
				smartSearchResultsPopup.waitUntilPresent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
     
	/***************************************************************************************
	 * Function:   Click on smart search result
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void selectSearchCriteriaFromSmartSearchResults(String companyName) {
		try {
			firstSearchItemEleInSmartSearchResults.waitUntilPresent();
			String searchItemVal = firstSearchItemEleInSmartSearchResults.getText();
			if (searchItemVal.toLowerCase().contains(companyName.toLowerCase())) {
				firstSearchItemEleInSmartSearchResults.click();
			} else {
				firstSearchItemEleInSmartSearchResults.click();
			}
			UIHelper.waitForPageToLoad(getDriver());
		} catch (Exception e) {
		}
	}
	
	/***************************************************************************************
	 * Function:   Get the Company Name from search results data
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/

	
	public String getSearchResultsData() {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), firstSearchResultXpath);
		searchResultsEle.waitUntilPresent();
		return searchResultsEle.getText();
	} 
	 
	/***************************************************************************************
	 * Function:  Click on Indicators
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void clickOnIndicator(String indicatorOption) {
		try {
			dashBoard.click();
			UIHelper.waitForPageToLoad(getDriver());
			dashboardTitleEle.waitUntilPresent();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxLoadingImageXpathForIndicators);
			String tempIndicatorXpath = indicatorsXpath.replace("SERENITY", indicatorOption);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempIndicatorXpath);
			WebElementFacade indicatorEle = find(By.xpath(tempIndicatorXpath));
			indicatorEle.click();
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxLoadingImageXpathForAlertInbox);
			// alertHeadingEle.waitUntilPresent();
		} catch (Exception e) {

		}
	}
    
	/***************************************************************************************
	 * Function: Click On Positive Alerts under Indicators
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void clickOnPositiveAlerts(String indicatorOption) {
		try {
			dashBoard.click();
			UIHelper.waitForPageToLoad(getDriver());
			dashboardTitleEle.waitUntilPresent();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxLoadingImageXpathForIndicators);
			clickOnPositiveScore(indicatorOption);
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxLoadingImageXpathForAlertInbox);
			// alertHeadingEle.waitUntilPresent();
		} catch (Exception e) {
		}
	}

	public void clickOnPositiveScore(String indicatorOption) {
		switch (indicatorOption) {
		case "Predictive Score Changes":
			predictivePositiveScoreEle.waitUntilPresent();
			predictivePositiveScoreEle.click();
			break;
		case "Government Indicators":
			govIndicatorsPositiveScoreEle.waitUntilPresent();
			govIndicatorsPositiveScoreEle.click();
			break;
		case "Operations Indicators":
			operationPositiveScoreEle.waitUntilPresent();
			operationPositiveScoreEle.click();
			break;
		case "Country Risk Score Indicators":
			countryRisksPositiveScoreEle.waitUntilPresent();
			countryRisksPositiveScoreEle.click();
			break;
		default:
		}
	}
	
	/***************************************************************************************
	 * Function: Click On Negative Alerts under Indicators
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/

	public void clickOnNegativeAlerts(String indicatorOption) {
		try {
			dashBoard.click();
			UIHelper.waitForPageToLoad(getDriver());
			dashboardTitleEle.waitUntilPresent();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxLoadingImageXpathForIndicators);
			clickOnNegativeScore(indicatorOption);
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxLoadingImageXpathForAlertInbox);
			// alertHeadingEle.waitUntilPresent();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickOnNegativeScore(String indicatorOption) {
		switch (indicatorOption) {
		case "Predictive Score Changes":
			predictiveNegativeScoreEle.waitUntilPresent();
			predictiveNegativeScoreEle.click();
			break;
		case "Government Indicators":
			govIndicatorsNegativeScoreEle.waitUntilPresent();
			govIndicatorsNegativeScoreEle.click();
			break;
		case "Operations Indicators":
			operationNegativeScoreEle.waitUntilPresent();
			operationNegativeScoreEle.click();
			break;
		case "Country Risk Score Indicators":
			countryRisksNegativeScoreEle.waitUntilPresent();
			countryRisksNegativeScoreEle.click();
			break;
		default:
		}
	}
	
	/***************************************************************************************
	 * Function:  Get Alert Tab Names
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/

	
	public ArrayList<String> getAlertTabs() {
		try {
			for (WebElement alertTabEle : alertTabElements) {
				alertTabsList.add(alertTabEle.getText());
			}
		} catch (Exception e) {

		}
		return alertTabsList;
	}
     
	/***************************************************************************************
	 * Function:  Click on Advanced Search
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void clickOnAdvancedSearch() {
		try {
			advancedSearchEle.waitUntilPresent();
			if (advancedSearchEle.isPresent()) {
				advancedSearchEle.click();
				advancedSearchbtnEle.waitUntilPresent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
	/***************************************************************************************
	 * Function:  Get Advanced Search Field Names
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	 
	public ArrayList<String> getAdvSearchFields() {
		try {
			for (WebElement advSearchFieldNameEle : advancedSearchFieldNamesElements) {
				advSearchFieldNames.add(advSearchFieldNameEle.getText().trim());
				// System.out.println("advField: "+advSearchFieldNames);
			}
		} catch (Exception e) {

		}

		return advSearchFieldNames;
	}
    
	/***************************************************************************************
	 * Function:   Perform Advanced Search with DUNS and Location Type
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	
	public void enterDUNSAndPerformSearch(String dunsNumber, String locationType) {
		enterDUNS(dunsNumber);
		selectLocationType(locationType);
		clickOnSearch();
	}
     
	/***************************************************************************************
	 * Function:   Enter DUNS Number
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void enterDUNS(String dunsNumber) {
		try {
			dunsFieldEle.waitUntilPresent();
			if (dunsFieldEle.isPresent() && dunsNumber != null && !dunsNumber.isEmpty()) {
				dunsFieldEle.type(dunsNumber);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
	/***************************************************************************************
	 * Function:   Select Location Type
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void selectLocationType(String locationType) {
		try {
			if (locationTypeDropdownEle.isPresent()) {
				locationTypeDropdownEle.click();
			}

			String tempAdvLocationMenuOptXpath = advLocationMenuOptXpath.replace("SERENITY", locationType);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempAdvLocationMenuOptXpath);
			WebElementFacade advLocationMenuOptEle = find(By.xpath(tempAdvLocationMenuOptXpath));

			if (advLocationMenuOptEle.isPresent()) {
				advLocationMenuOptEle.click();
			}
		} catch (Exception e) {

		}
	}
    
	/***************************************************************************************
	 * Function:   Click on Advanced Search Button
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void clickOnSearch() {
		try {
			if (advancedSearchbtnEle.isPresent()) {
				advancedSearchbtnEle.click();
				UIHelper.waitForPageToLoad(getDriver());
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxImgLoadingXpath);
				firstSearchResultEle.waitUntilPresent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
	/***************************************************************************************
	 * Function:  perform Advanced Search with National Business Id and Location Type
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/

	public void enterNBIAndPerformSearc(String nationalBusinessId, String locationType) {
		enterNationalBusinessIdAndPerformSearch(nationalBusinessId);
		selectLocationType(locationType);
		clickOnSearch();
	}
  
	/***************************************************************************************
	 * Function:  Enter National Business Id
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void enterNationalBusinessIdAndPerformSearch(String nationalBusinessId) {
		try {
			nationalBusinessIdFieldEle.waitUntilPresent();
			if (nationalBusinessIdFieldEle.isPresent() && nationalBusinessId != null && !nationalBusinessId.isEmpty()) {
				nationalBusinessIdFieldEle.type(nationalBusinessId);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
	/***************************************************************************************
	 * Function:  perform Advanced Search with National Business Id Number and Location
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void enterNationalBusinessIdNumberAndPerformSearch(String nationalBusinessIdNumber, String locationType) {
		enterNationalBusinessIdNumberAndPerformSearch(nationalBusinessIdNumber, locationType);
		selectLocationType(locationType);
		clickOnSearch();
	}

	
	/***************************************************************************************
	 * Function:  Enter National Business Id Number
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void enterNationalbusinessIdNumberAndPerformSearch(String nationalBusinessIdNumber) {
		try {
			nationalBusinessIdNumberFieldEle.waitUntilPresent();
			if (nationalBusinessIdNumberFieldEle.isPresent() && nationalBusinessIdNumber != null
					&& !nationalBusinessIdNumber.isEmpty()) {
				nationalBusinessIdNumberFieldEle.type(nationalBusinessIdNumber);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
	/***************************************************************************************
	 * Function: Perform Advanced Search with Address and Location Type
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void enterAddressAndPerformSearch(String address, String locationType) {
		try {
			enterAddress(address);
			selectLocationType(locationType);
			clickOnSearch();
		} catch (Exception e) {

		}
	}
     
	/***************************************************************************************
	 * Function:Enter Address
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	 
	public void enterAddress(String address) {
		try {
			addressFieldEle.waitUntilPresent();
			if (addressFieldEle.isPresent() && address != null && !address.isEmpty()) {
				addressFieldEle.type(address);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
       
	/***************************************************************************************
	 * Function:Perform Advanced Search with City and Location Type
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	 
	public void enterCityAndPerformSearch(String city, String locationType) {
		try {
			enterCity(city);
			selectLocationType(locationType);
			clickOnSearch();
		} catch (Exception e) {

		}
	}
	
	/***************************************************************************************
	 * Function:Enter City
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void enterCity(String city) {
		try {
			cityFieldEle.waitUntilPresent();
			if (cityFieldEle.isPresent() && city != null && !city.isEmpty()) {
				cityFieldEle.type(city);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
     
	/***************************************************************************************
	 * Function:Perform Advanced Search with Country, State and Location Type
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	 
	public void selectCountryWithStateAndPerformSearch(String country, String state, String locationType) {
		try {
			selectCountryAndState(country, state);
			selectLocationType(locationType);
			clickOnSearch();
		} catch (Exception e) {

		}
	}
	
	/***************************************************************************************
	 * Function:Select Country and State
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void selectCountryAndState(String country, String state) {
		try {
			countryDropdownEle.waitUntilPresent();
			if (countryDropdownEle.isPresent() && country != null && !country.isEmpty()) {
				countryDropdownEle.click();
				String tempAdvCountryMenuOptXpath = advCountryMenuOptXpath.replace("SERENITY", country);
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempAdvCountryMenuOptXpath);
				WebElementFacade advCountryMenuOptEle = find(By.xpath(tempAdvCountryMenuOptXpath));

				if (advCountryMenuOptEle.isPresent()) {
					advCountryMenuOptEle.click();
				}
			}

			stateDropdownEle.waitUntilPresent();
			if (stateDropdownEle.isPresent() && state != null && !state.isEmpty()) {
				stateDropdownEle.click();
				String tempAdvStateMenuOptXpath = advStateMenuOptXpath.replace("SERENITY", state);
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempAdvStateMenuOptXpath);
				WebElementFacade advStateMenuOptEle = find(By.xpath(tempAdvStateMenuOptXpath));

				if (advStateMenuOptEle.isPresent()) {
					advStateMenuOptEle.click();
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/***************************************************************************************
	 * Function:Perform Advanced Search with Postal Code and Location Type
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void enterPostalCodeAndPerformSearch(String postalCode, String locationType) {
		try {
			enterPostalCode(postalCode);
			selectLocationType(locationType);
			clickOnSearch();
		} catch (Exception e) {

		}
	}
	
	/***************************************************************************************
	 * Function:Enter Postal Code
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void enterPostalCode(String postalCode) {
		try {
			postalCodeFieldEle.waitUntilPresent();
			if (postalCodeFieldEle.isPresent() && postalCode != null && !postalCode.isEmpty()) {
				postalCodeFieldEle.type(postalCode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
	/***************************************************************************************
	 * Function:Perform Advanced Search with Location Type
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void selectLocationTypeAndPerformSearch(String locationType) {
		selectLocationType(locationType);
	}
    
	/***************************************************************************************
	 * Function:Perform Advanced Search with all fields
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void performAdvancedSearchWithAllFields(String dunsNumber, String nationalBusinessId,
			String nationalBusinessIdNumber, String address, String city, String country, String state,
			String postalCode, String locationType) {

		try {
			enterDUNS(dunsNumber);
			enterNationalBusinessIdAndPerformSearch(nationalBusinessId);
			enterNationalbusinessIdNumberAndPerformSearch(nationalBusinessIdNumber);
			enterAddress(address);
			enterCity(city);
			selectCountryAndState(country, state);
			enterPostalCode(postalCode);
			selectLocationType(locationType);
			clickOnSearch();
		} catch (Exception e) {

		}
	}  
	
	/***************************************************************************************
	 * Function:Click on 'Save this Search' button
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/


	public void clickOnSaveThisSearch() {
		try {
			if (saveSearchBtnEle.isPresent()) {
				saveSearchBtnEle.click();
				confirmBtnForSavedSearchEle.waitUntilPresent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
     
	/***************************************************************************************
	 * Function: Click on 'Confirm' button in popup window
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/

	public void clickOnConfirmInPopupWindow() {
		try {
			if (confirmBtnForSavedSearchEle.isPresent()) {
				confirmBtnForSavedSearchEle.click();
				confirmMsgForSavedSearchEle.waitUntilPresent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
     
	/***************************************************************************************
	 * Function: Click on 'Saved Searches' link
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void clickOnSavedSearches() {
		try {
			savedSearchsLinkEle.waitUntilPresent();
			if (savedSearchsLinkEle.isPresent()) {
				savedSearchsLinkEle.click();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
     
	/***************************************************************************************
	 * Function: Get the saved search results data
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	 
	public ArrayList<String> getSavedSearchResults() {
		try {
			for (WebElement saveSearchEle : savedSearchElements) {
				savedSearchDataList.add(saveSearchEle.getText().trim());
			}
		} catch (Exception e) {

		}
		return savedSearchDataList;
	}
     
	/***************************************************************************************
	 * Function:  Verify Amount Details Value In Saved searches
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public String verifyAmountDetailValue() throws Exception {
		String amtDetVal = null;
		try {
			WebElement.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), WebElement);
			amtDetVal = WebElement.getText().toString().trim();
			System.out.println("WebElement: " + amtDetVal);
		} catch (Exception e) {

		}
		return amtDetVal;
	}

	
	/***************************************************************************************
	 * Function: verify the Are you certified value in Saved searches
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/

	 
	public String verifyAreyouCertifiedValue() throws Exception {
		String certifiedval = null;
		try {

			SavedCertified.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), SavedCertified);
			certifiedval = SavedCertified.getText().toString().trim();
			System.out.println("SavedCertified: " + certifiedval);
		} catch (Exception e) {

		}
		return certifiedval;
	}
	
	/***************************************************************************************
	 * Function: verify Date started value in Saved searches

	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	
	public String verifyDateValue() throws Exception {
		String dateVal = null;
		try {
			savedDatavalue.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), savedDatavalue);
			dateVal = savedDatavalue.getText().toString().trim();
			System.out.println("savedDatavalue: " + dateVal);
		} catch (Exception e) {

		}
		return dateVal;

	}  
	
	/***************************************************************************************
	 * Function: verify public value in Saved searches
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	


	public String verifyPublicShareValue() throws Exception {
		String publicval = null;
		try {
			savedPublicValue.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), savedPublicValue);
			publicval = savedPublicValue.getText().toString().trim();
			System.out.println("savedPublicValue: " + publicval);
		} catch (Exception e) {

		}
		return publicval;
	}
	
	/***************************************************************************************
	 * Function: verify Your Share value in Saved searches
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public String verifyYourShareValue() throws Exception {
		
		String yourShareVal= null;
		try {
			savedYourShareValue.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), savedYourShareValue);
			yourShareVal = savedYourShareValue.getText().toString().trim();
			System.out.println("savedYourShareValue: " + yourShareVal);
		} catch (Exception e) {

		}
		return yourShareVal;
	}
		
		
	
	
	
	/***************************************************************************************
	 * Function:  Click on Export Button
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	

	public void clickOnExport() {
		try {
			exportBtnEle.waitUntilPresent();
			if (exportBtnEle.isPresent()) {
				UIHelper.mouseOverandclickanElement(getDriver(), exportBtnEle);
				waitFor(3000).milliseconds();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
	/***************************************************************************************
	 * Function: Get the Export options
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public ArrayList<String> getExportOptions() {
		try {
			for (WebElement exportOptEle : exportOptionsElements) {
				exportOptionsList.add(exportOptEle.getText().trim());
			}
		} catch (Exception e) {
		}
		return exportOptionsList;
	}
	
	/***************************************************************************************
	 * Function:Click on Export Option
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	
	public void clickOnExportOption(String exportOption) {
		try {
			if (exportOption.equalsIgnoreCase("CSV")) {
				UIHelper.mouseOverandclickanElement(getDriver(), csvExportOptEle);
			} else if (exportOption.equalsIgnoreCase("PDF")) {
				UIHelper.mouseOverandclickanElement(getDriver(), pdfExportOptEle);
			}

			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForPageToLoad(getDriver());
			waitFor(7000).milliseconds();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/***************************************************************************************
	 * Function:Get the expanded section data
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public String getExpanedSectionInfoForSearchResult() {
		companyRatingsEleInSearchResults.waitUntilPresent();
		return companyRatingsEleInSearchResults.getText();
	}
    
	/***************************************************************************************
	 * Function:Click on 'Go To Company Profile Page to Update/Add to Watchlist Folder'
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	

	public void clickOnCompanyProfile() {
		try {
			if (companyProfilePageLinkEle.isPresent()) {
				companyProfilePageLinkEle.click();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
	/***************************************************************************************
	 * Function:Select Score and view the Top 10 companies
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void viewTheTopCompaniesByScore(String scoreOption) {
		try {
			if (scoreDropdownEle.isPresent()) {
				scoreDropdownEle.click();
			}
			String tempScoresDropdownItemsXpath = scoresDropdownItemsXpath.replace("SERENITY", scoreOption);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempScoresDropdownItemsXpath);
			WebElementFacade scoresDropdownItemsEle = find(By.xpath(tempScoresDropdownItemsXpath));
			if (scoresDropdownItemsEle.isPresent()) {
				scoresDropdownItemsEle.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxImgLoadingXpathForTopCompaniesSection);
			}
		} catch (Exception e) {
		}
	}

	// Get Score Name from Top 10 Companies
	public String getScoreFromTopCompanies() {
		try {
			scoreEle.waitUntilPresent();
			UIHelper.mouseOveranElement(getDriver(), scoreEle);
			/*
			 * scoreHeaderEle.waitUntilPresent();
			 * UIHelper.mouseOveranElement(getDriver(), scoreHeaderEle);
			 * System.out.println("ScoreHead :"
			 * +scoreHeaderEle.getText().trim());
			 */
		} catch (Exception e) {
			e.printStackTrace();
		}
		/* return scoreHeaderEle.getText().trim(); */
		return scoreEle.getText();
	}
     
	/***************************************************************************************
	 * Function:Select 5 companies from Top 10 companies
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void selectFiveCompanies() {
		try {

			if (!firstCompanyChkBoxCheckedEle.isPresent()) {
				UIHelper.mouseOverandclickanElement(getDriver(), firstCompanyChkBoxEle);
			}

			if (!secondCompanyChkBoxCheckedEle.isPresent()) {
				UIHelper.mouseOverandclickanElement(getDriver(), secondCompanyChkBoxEle);
			}

			if (!thirdCompanyChkBoxCheckedEle.isPresent()) {
				UIHelper.mouseOverandclickanElement(getDriver(), thirdCompanyChkBoxEle);
			}

			if (!fourthCompanyChkBoxCheckedEle.isPresent()) {
				UIHelper.mouseOverandclickanElement(getDriver(), fourthCompanyChkBoxEle);
			}

			if (!fifthCompanyChkBoxCheckedEle.isPresent()) {
				UIHelper.mouseOverandclickanElement(getDriver(), fifthCompanyChkBoxEle);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
       
	/***************************************************************************************
	 * Function:Select personal folder and score for top 10 companies
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void selectPersonalFolderAndScore(String personalFolder, String scoreOption) {
		try {
			if (personalFolderDropdownEle.isPresent()) {
				personalFolderDropdownEle.click();
			}
			String tempPersonalFolderDropdownItemsXpath = personalFolderDropdownItemsXpath.replace("SERENITY",
					personalFolder);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempPersonalFolderDropdownItemsXpath);
			WebElementFacade personalFolderDropdownItemsEle = find(By.xpath(tempPersonalFolderDropdownItemsXpath));
			if (personalFolderDropdownItemsEle.isPresent()) {
				personalFolderDropdownItemsEle.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxImgLoadingXpathForTopCompaniesSection);
			}

			viewTheTopCompaniesByScore(scoreOption);
		} catch (Exception e) {
		}
	}

	
	/***************************************************************************************
	 * Function:Click on Export Button for top companies
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void clickExportForTopCompanies() {
		try {
			exportBtnEleForTopCompanies.waitUntilPresent();
			if (exportBtnEleForTopCompanies.isPresent()) {
				UIHelper.mouseOverandElementdoubleClick(getDriver(), exportBtnEleForTopCompanies);
				waitFor(3000).milliseconds();
				// csvExportOptEleForTopCompanies.waitUntilPresent();
				// pdfExportOptEleForTopCompanies.waitUntilPresent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	/***************************************************************************************
	 * Function: Get the Export options for top companies
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public ArrayList<String> getExportOptionsForTopCompanies() {
		try {
			for (WebElement exportOptEle : exportOptionsElementsForTopCompanies) {
				exportOptionsListForTopCompanies.add(exportOptEle.getText().trim());
			}
		} catch (Exception e) {
		}
		return exportOptionsListForTopCompanies;
	}
    
	/***************************************************************************************
	 * Function: Click on Export Option for top companies
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void clickExportOptionForTopCompanies(String exportOption) {
		try {
			if (exportOption.equalsIgnoreCase("CSV")) {
				UIHelper.mouseOverandclickanElement(getDriver(), csvExportOptEleForTopCompanies);
			} else if (exportOption.equalsIgnoreCase("PDF")) {
				UIHelper.mouseOverandclickanElement(getDriver(), pdfExportOptEleForTopCompanies);
			}
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForPageToLoad(getDriver());
			waitFor(5000).milliseconds();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/***************************************************************************************
	 * Function: Goto Recently Viewed Supplier Section
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void gotoRecentlyViewedSupplierSection() {
		recentlyViewedSuppliersSecEle.waitUntilPresent();
		UIHelper.highlightElement(getDriver(), recentlyViewedSuppliersSecEle);
	}

	/***************************************************************************************
	 * Function: Select folder name and view the severe risk condition pie chart
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	
	public void selectFolderAndViewTheSevereRiskConditionChart(String personalFolder) {
		try {
			if (folderSelcDropdownEleForSevereRiskCond.isPresent()) {
				folderSelcDropdownEleForSevereRiskCond.click();
			}
			String tempPersonalFolderDropdownItemsXpathInSevereRiskSec = personalFolderDropdownItemsXpathInSevereRiskSec
					.replace("SERENITY", personalFolder);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempPersonalFolderDropdownItemsXpathInSevereRiskSec);
			WebElementFacade personalFolderDropdownItemsEleInSevereRiskSec = find(
					By.xpath(tempPersonalFolderDropdownItemsXpathInSevereRiskSec));
			if (personalFolderDropdownItemsEleInSevereRiskSec.isPresent()) {
				personalFolderDropdownItemsEleInSevereRiskSec.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxImgLoadingXpathInSevereRiskSec);
				waitFor(5000).milliseconds();
			}

		} catch (Exception e) {
		}
	}
    
	/***************************************************************************************
	 * Function: Check the risk conditions on pie chart
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public ArrayList<String> getRiskConditionsFromSuppliersForRiskCond() {
		try {
			if (!riskCondCriminalEle.getText().isEmpty() && riskCondCriminalEle.getText().trim() != null) {
				severeRiskCondNamesList.add(riskCondCriminalEle.getText().trim());
			}
			if (!riskCondProceedinsEle.getText().isEmpty() && riskCondProceedinsEle.getText().trim() != null) {
				severeRiskCondNamesList.add(riskCondProceedinsEle.getText().trim());
			}
			if (!riskCondBusinessEle.getText().isEmpty() && riskCondBusinessEle.getText().trim() != null) {
				severeRiskCondNamesList.add(riskCondBusinessEle.getText().trim());
			}
			if (!riskCondDeteriorationEle.getText().isEmpty() && riskCondDeteriorationEle.getText().trim() != null) {
				severeRiskCondNamesList.add(riskCondDeteriorationEle.getText());
			}
			if (!riskCondDebarredEle.getText().isEmpty() && riskCondDebarredEle.getText().trim() != null) {
				severeRiskCondNamesList.add(riskCondDebarredEle.getText().trim());
			}
			if (!riskCondBankruptcyEle.getText().isEmpty() && riskCondBankruptcyEle.getText().trim() != null) {
				severeRiskCondNamesList.add(riskCondBankruptcyEle.getText().trim());
			}

			UIHelper.removeDuplicatesFromArrayList(severeRiskCondNamesList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return severeRiskCondNamesList;
	}
     
	
	/***************************************************************************************
	 * Function: Click the risk condition on pie chart
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void clickTheRiskConditionInSevereRiskCondChart(String riskCondition) {
		try {
			switch (riskCondition) {
			case "Criminal Proceedings":
				// UIHelper.mouseOveranElement(getDriver(),
				// riskCondCriminalEle);
				UIHelper.mouseOverandclickanElement(getDriver(), riskCondCriminalEle);
				waitForSupplierToSevereRisk();
				break;
			case "Business Deterioration":
				UIHelper.mouseOverandclickanElement(getDriver(), riskCondBusinessEle);
				waitForSupplierToSevereRisk();
				break;
			case "Debarred":
				UIHelper.mouseOverandclickanElement(getDriver(), riskCondDebarredEle);
				waitForSupplierToSevereRisk();
				break;
			case "Bankruptcy":
				UIHelper.mouseOverandclickanElement(getDriver(), riskCondBankruptcyEle);
				waitForSupplierToSevereRisk();
				break;
			default:
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void waitForSupplierToSevereRisk() {
		UIHelper.waitForPageToLoad(getDriver());
		riskCondNameEleFromAllSupplier.waitUntilPresent();
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), allSuppliersResultLoadingXpath);
	}

	/***************************************************************************************
	 * Function: Check the suppliers for severe risk condition
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public String getAllSuppliersForSevereRiskCond() {
		return riskCondNameEleFromAllSupplier.getText().trim();
	}

	
	/***************************************************************************************
	 * Function: Click on Export Button for suppliers Severe Risk Condition
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void clickExportForSevereRiskCond() {
		try {
			UIHelper.mouseOverandclickanElement(getDriver(), exportBtnEleForSevereRiskCond);
			waitFor(3000).milliseconds();
			// csvExportOptEleForSevereRiskCond.waitUntilPresent();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
     
	/***************************************************************************************
	 * Function: Get the export option for suppliers Severe Risk Condition
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public String getExportOptionForSevereRiskCond() {
		return csvExportOptEleForSevereRiskCond.getText();
	}

	
	/***************************************************************************************
	 * Function: Click on Export Option for suppliers Severe Risk Condition
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void clickExportOptionForSevereRiskCond(String exportOption) {
		try {
			if (exportOption.equalsIgnoreCase("CSV")) {
				UIHelper.mouseOverandclickanElement(getDriver(), csvExportOptEleForSevereRiskCond);
				UIHelper.waitForPageToLoad(getDriver());
				waitFor(5000).milliseconds();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
   
	/***************************************************************************************
	 * Function: Verify Portfolio Risk Section by Personal folder and score values
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void viewPortfolioRiskByPersonalFolderAndScore(String personalFolder, String scoreOption) {
		try {
			portfolioRisSecEle.waitUntilPresent();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgLoadingInBarChartArea);
			if (portfolioRisSecEle.isPresent()) {
				UIHelper.mouseOveranElement(getDriver(), portfolioRisSecEle);
			}

			folderDropdownEleForPortfolioRisk.waitUntilPresent();
			if (folderDropdownEleForPortfolioRisk.isPresent()) {
				UIHelper.mouseOveranElement(getDriver(), folderDropdownEleForPortfolioRisk);
				UIHelper.mouseOverandclickanElement(getDriver(), folderDropdownEleForPortfolioRisk);
			}

			String tempPortfolioRiskMenuOptXpath = portfolioRiskMenuOptXpath.replace("SERENITY", personalFolder);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempPortfolioRiskMenuOptXpath);
			WebElementFacade portfolioRiskMenuOptEle = find(By.xpath(tempPortfolioRiskMenuOptXpath));
			if (portfolioRiskMenuOptEle.isPresent()) {
				portfolioRiskMenuOptEle.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxImgLoadingXpathInBubblesForPortfolioRisk);
			}

			if (scoreDropdownEleForPortfolioRisk.isPresent()) {
				UIHelper.highlightElement(getDriver(), scoreDropdownEleForPortfolioRisk);
				scoreDropdownEleForPortfolioRisk.click();
			}
			String tempScoreMenuXpathForPortfolioRisk = scoreMenuXpathForPortfolioRisk.replace("SERENITY", scoreOption);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempScoreMenuXpathForPortfolioRisk);
			WebElementFacade scoreMenuEleForPortfolioRisk = find(By.xpath(tempScoreMenuXpathForPortfolioRisk));
			if (scoreMenuEleForPortfolioRisk.isPresent()) {
				scoreMenuEleForPortfolioRisk.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxImgLoadingXpathInBubblesForPortfolioRisk);
			}

			barChartButtonEle.waitUntilPresent();
			if (barChartButtonEle.isPresent()) {
				barChartButtonEle.click();
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgLoadingInBarChartArea);
				waitFor(3000).milliseconds();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	/***************************************************************************************
	 * Function:  Get WatchLists from charts
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public ArrayList<String> getWatchlists() {
		try {
			if (myWatchListEle.isPresent() && allWatchListsEle.isPresent()) {
				if (!myWatchListEle.getText().trim().isEmpty() && myWatchListEle.getText().trim() != null) {
					watchListsNameList.add(myWatchListEle.getText().trim());
				}

				if (!allWatchListsEle.getText().trim().isEmpty() && allWatchListsEle.getText().trim() != null) {
					watchListsNameList.add(allWatchListsEle.getText().trim());
				}

				UIHelper.removeDuplicatesFromArrayList(watchListsNameList);
			} else {
				watchListsNameList.add("My Watchlist");
				watchListsNameList.add("All Watchlists");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return watchListsNameList;
	}

	
	/***************************************************************************************
	 * Function:  Place Mouse cursor on charts
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void placeCursorOnCharts() {
		try {
			UIHelper.mouseOveranElement(getDriver(), firstBarGraphEleInPortFolioRiskSec);
			waitFor(3000).milliseconds();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getPercentageDetails() {
		tooltipForFirstBarGraphInPortFolioRiskSec.waitUntilPresent();
		return tooltipForFirstBarGraphInPortFolioRiskSec.getText();
	}
    
	/***************************************************************************************
	 * Function:  Click Bubbles
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void clickBubbles() {
		if (bubblesBtnEle.isPresent()) {
			bubblesBtnEle.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxImgLoadingXpathInBubblesForPortfolioRisk);
			hintTextEle.waitUntilPresent();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), highRiskEleXpath);
		} else if (bubblesBtnEle.isPresent()) {
			bubblesBtnEle.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), ajaxImgLoadingXpathInBubblesForPortfolioRisk);
			hintTextEle.waitUntilPresent();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), lowRiskEleXpath);
		}
	}
	
	/***************************************************************************************
	 * Function: Verify Get Risk types from Bubbles section
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	// Get Risk types from Bubbles section
	public ArrayList<String> getRiskCatsInBubbleSec() {
		try {
			for (WebElement ele : riskTypesInPortfolioRiskBubbleSec) {
				riskTypesListForBubbles.add(ele.getText().trim());
			}
		} catch (Exception e) {
		}
		return riskTypesListForBubbles;
	}
	
	/***************************************************************************************
	 * Function:  Click on specific risk type in Bubble section
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	
	public void clickOnRiskTypeInBubble(String riskTypeInBubbleSec, String scoreOption) {
		try {
			if (riskTypeInBubbleSec.equalsIgnoreCase("High Risk") && scoreOption.equalsIgnoreCase("SSI")) {
				highSSIEle.click();
				waitForAllBubblesSuppliers();
			} else if (riskTypeInBubbleSec.equalsIgnoreCase("High Risk") && scoreOption.equalsIgnoreCase("SER")) {
				highSEREle.click();
				waitForAllBubblesSuppliers();
			} else if (riskTypeInBubbleSec.equalsIgnoreCase("Medium Risk") && scoreOption.equalsIgnoreCase("SSI")) {
				medSSIEle.click();
				waitForAllBubblesSuppliers();
			} else if (riskTypeInBubbleSec.equalsIgnoreCase("Medium Risk") && scoreOption.equalsIgnoreCase("SER")) {
				medSEREle.click();
				waitForAllBubblesSuppliers();
			} else if (riskTypeInBubbleSec.equalsIgnoreCase("Low Risk") && scoreOption.equalsIgnoreCase("SSI")) {
				lowSSIEle.click();
				waitForAllBubblesSuppliers();
			} else if (riskTypeInBubbleSec.equalsIgnoreCase("Low Risk") && scoreOption.equalsIgnoreCase("SER")) {
				lowSEREle.click();
				waitForAllBubblesSuppliers();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void waitForAllBubblesSuppliers() {
		try {
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForPageToLoad(getDriver());
			allSuppliersEle.waitUntilPresent();
			listOfSuppliersTableEleForPortfolioRisk.waitUntilPresent();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void getselectMywatchListFolder(String mywatchlist) {

		try {
			if (myWatchlistDropDown.isPresent()) {
				UIHelper.highlightElement(getDriver(), myWatchlistDropDown);
				myWatchlistDropDown.click();
			}

			String tempSearchTypeOptionXpath = dropdownXpathForSearchType.replace("SERENITY", mywatchlist);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tempSearchTypeOptionXpath);
			WebElementFacade searchTypeOptionEle = find(By.xpath(tempSearchTypeOptionXpath));
			searchTypeOptionEle.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public void verifyAllTheCompaniesList() {

		try {			
			companiesList.isPresent();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
    
	/***************************************************************************************
	 * Function:  click SSI Supplier checkbox
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	public void clickSSISuplierCheckbox() {
		UIHelper.highlightElement(getDriver(), selectCheckBox);
		selectCheckBox.click();
		

	}
	
	/***************************************************************************************
	 * Function: GraphPage  according to list of SSI suppliers selected
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	public void verifyGraphPageIsDispalyed() {
		graphPanel.waitUntilVisible();
		UIHelper.highlightElement(getDriver(), graphPanel);
		graphPanel.isCurrentlyVisible();
		

	}

	/***************************************************************************************
	 * Function: Graph X-axis ranges from present date to last 18 months
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	public void verifyXAxixPageBarIsDispalyed() {
		graphXValue.waitUntilVisible();
		UIHelper.highlightElement(getDriver(),graphXValue);
		graphXValue.isCurrentlyVisible();
		
	}
	
		/*try{
			graphXValue.isPresent();
			String str=graphXValue
					.getText().toString().trim();
		
		
		Calendar now = Calendar.getInstance();
	    now.add(Calendar.MONTH, -18);
	 
	    System.out.println("date before 18 months : " + (now.get(Calendar.MONTH) + 1)
	                        + "-"
	                        + now.get(Calendar.DATE)
	                        + "-"
	                        + now.get(Calendar.YEAR));
		}
		
			catch (Exception e) {
				e.printStackTrace();
			
		}
	}*/
	/***************************************************************************************
	 * Function: Graph Y-axis ranges from 0 to 10
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/
	public void verifyYAxixPageBarIsDisplayed() {
		graphYvalue.waitUntilVisible();
		UIHelper.highlightElement(getDriver(),graphYvalue);
		graphYvalue.isCurrentlyVisible();
		
	}

	public void clickSERSuplierCheckbox() {
		SERselectCheckBox.waitUntilVisible();
		UIHelper.highlightElement(getDriver(),SERselectCheckBox);
		SERselectCheckBox.click();
		
		
	}
	public void verifySERGraphPageIsDispalyed() {
		graphPanel.waitUntilVisible();
		UIHelper.highlightElement(getDriver(), graphPanel);
		graphPanel.isCurrentlyVisible();
		
	}

	/*public String verifyCompanyNameValue() throws Exception{
		String companyVal=null;
		try {
			selectCheckBoxComapnayName.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), selectCheckBoxComapnayName);
			companyVal = selectCheckBoxComapnayName.getText().toString().trim();
			System.out.println("selectCheckBoxComapnayName: " + companyVal);
		} catch (Exception e) {

		}
		return companyVal;
	}*/

	/*public String verifyCompanyNameCheckBoxChecked() {
		selectCheckBoxComapnayName.waitUntilVisible();
		UIHelper.highlightElement(getDriver(),selectCheckBoxComapnayName);
		selectCheckBoxComapnayName.click();
		alertMessage.waitUntilEnabled();
		String alertMsg=alertMessage.getText().toString().trim();
		return alertMsg;
		
	}*/
	
	/***************************************************************************************
	 * Function:click the mouse on the plotted points in the graph
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/

	public void verifyPlottedGraphValueIsDispalyed() {
		
		
		try {
			UIHelper.mouseOveranElement(getDriver(),firstGraphPlottedValue );
			waitFor(3000).milliseconds();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public void verifyPlottedGraphValueIsDisplayed() {
		try {
			UIHelper.mouseOveranElement(getDriver(),firstGraphPlottedScoreValue );
			waitFor(3000).milliseconds();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	/***************************************************************************************
	 * Function:Verify the user is also not allowed to uncheck the last supplier
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/

	public void verifyUncheckedSupplierValueIsDisplayed() {
		uncheckSupplier.waitUntilVisible();
		UIHelper.highlightElement(getDriver(), uncheckSupplier);
		uncheckSupplier.isCurrentlyVisible();
		
	}

	public int VerifyMonthlyTimeScaleInScoreValue()throws Exception {
		int noOfMonthsInmyWatchListUI = 0;
		try {
			top10RiskScoreMonths.isPresent();

			List<WebElement> numberOfMonths = getDriver()
					.findElements(
							By.xpath(".//*[@id='highcharts-28']//*[name()='svg']/*[name()='g'][6]"));

			noOfMonthsInmyWatchListUI= numberOfMonths.size();
			System.out.println("SizeOfMonths: " + noOfMonthsInmyWatchListUI);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return noOfMonthsInmyWatchListUI;
	} {
		
		
	}


	public void verifyBydefaultcompaniesValuesIsDisplayed() {
		byDefaultSupplier.waitUntilVisible();
		UIHelper.highlightElement(getDriver(), byDefaultSupplier);
		byDefaultSupplier.isCurrentlyVisible();
		
		
		
		
	}

	public void verifyGraphSelectedSupplierDateValueIsDisplayed() {
		
	}

	public String verifyAlertMsgSupplierValue(String message) {
		selectCheckBoxComapnayName.waitUntilVisible();
		UIHelper.highlightElement(getDriver(),selectCheckBoxComapnayName);
		selectCheckBoxComapnayName.click();
		alertMessage.waitUntilEnabled();
		String alertMsg=alertMessage.getText().toString().trim();
		return alertMsg;
	}
	
	/***************************************************************************************
	 * Function:Verify the pie chart is displayed in the Severe Risk conditions section
	 * Detailed : Action : Output : value
	 *
	 ****************************************************************************************/

	public void verifyPieChartSevereRiskValueValueIsDisplayed() {
		
		try {
			UIHelper.mouseOveranElement(getDriver(), firstBarGraphEleInPortFolioRiskSec);
			waitFor(3000).milliseconds();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//PortFolio Risk new Scenario:Sradha
	
	public void showPortFolioRiskValueIsDisplayed() {
		portoFolioRiskvalue.waitUntilVisible();
		UIHelper.highlightElement(getDriver(), portoFolioRiskvalue);
		portoFolioRiskvalue.isCurrentlyVisible();
		
	}

	public void IsDisplayedTwoIconValueRightSide() {
		try {
			UIHelper.mouseOveranElement(getDriver(), portFolioTwoIcon);
			waitFor(3000).milliseconds();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public void verifyBubbleAndBarIconValueIsDisplayed() {
		
		try {
			UIHelper.mouseOveranElement(getDriver(), portFolioTwoIcon);
			waitFor(3000).milliseconds();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyScoreDropDownValueIsDisplayed() {
		portofolioScoreValue.waitUntilVisible();
		UIHelper.highlightElement(getDriver(), portofolioScoreValue);
		portofolioScoreValue.isCurrentlyVisible();
		
		
	}

	public void verifySERCircleEmpty() {
		portofolioScoreValue.waitUntilVisible();
		UIHelper.highlightElement(getDriver(),portofolioScoreValue);
		portofolioScoreValue.click();
		
		
	}

	public void verifyBydefaultMywatchListFolderIsDisplayed() {
		
		byDefaultMywatchListValue.waitUntilVisible();
		UIHelper.highlightElement(getDriver(), byDefaultMywatchListValue);
		byDefaultMywatchListValue.isCurrentlyVisible();
		
	}

	public void veryExportButtonValueIsDisplayed() {
		portfolioExportValue.waitUntilVisible();
		UIHelper.highlightElement(getDriver(), portfolioExportValue);
		portfolioExportValue.isCurrentlyVisible();
		
	}

	public void clickExportForPortFolioValueIsDisplayed() {
		try {
			portfolioExportValue.waitUntilPresent();
			if (portfolioExportValue.isPresent()) {
				UIHelper.mouseOverandElementdoubleClick(getDriver(),portfolioExportValue);
				waitFor(3000).milliseconds();
				// csvExportOptEleForTopCompanies.waitUntilPresent();
				// pdfExportOptEleForTopCompanies.waitUntilPresent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ArrayList<String> getExportOptionsForPortFolio() {
		try {
			for (WebElement exportOptEle : portfolioExportValueSSI) {
				exportOptionsList.add(exportOptEle.getText().trim());
			}
		} catch (Exception e) {
		}
		return exportOptionsList;
		
	}

	public void clickExportOptionForPortFolioIsDisplayed(String exportOption) {
		try {
			if (exportOption.equalsIgnoreCase("CSV")) {
				UIHelper.mouseOverandclickanElement(getDriver(), csvExportOptEleForPortFolio);
			} else if (exportOption.equalsIgnoreCase("PDF")) {
				UIHelper.mouseOverandclickanElement(getDriver(), pdfExportOptEleForPortFolio);
			}
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForPageToLoad(getDriver());
			waitFor(5000).milliseconds();
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}

	public void isDisplayedExportOptionsForPortFolioValue(String exportOption) {
		try {
			portfolioExportValue.waitUntilPresent();
			if (portfolioExportValue.isPresent()) {
				UIHelper.mouseOverandElementdoubleClick(getDriver(),portfolioExportValue);
				waitFor(3000).milliseconds();
				// csvExportOptEleForTopCompanies.waitUntilPresent();
				// pdfExportOptEleForTopCompanies.waitUntilPresent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//PDF Download
	
	
	public String clickOnExportPdfIconPage() {
		String str = "Not Clicked on Export Icon";
		if(pdfExportOptEleForPortFolio.isPresent())
		{
			UIHelper.highlightElement(getDriver(), pdfExportOptEleForPortFolio);
			pdfExportOptEleForPortFolio.click();
			//exportAsPdfOption.waitUntilVisible();
			str = "Clicked on Export Icon";
		}
		return str;
	}
	//To verify Export as pdf option availability
		public String verifyExportPdfOptionPage(String exportAsPdf) {
			
			String str = "";
			
				if(pdfExportOptEleForPortFolio.isPresent())
				{		
					 List<WebElement> options = getDriver().findElements(By.xpath(".//*@id='portfolioRiskExportPdf'"));
				        // Loop through the options and select the one that matches
				        for (WebElement opt : options) {
				        	 if (opt.getText().equals(exportAsPdf)) {
				        		 str = opt.getText(); 
				        	 }
				        }		
				}
			
			return str;
		}

		//To select export pdf option
		public boolean selectExportAsPdfOption(String exportAsPdf) {
			
		      boolean result = false;
		        // Get all of the options
		        try {
					List<WebElement> options = getDriver().findElements(By.xpath("//*[@id='portfolioRiskExportPdf']"));
					// Loop through the options and select the one that matches
					for (WebElement opt : options) {
					    if (opt.getText().equals(exportAsPdf)) {
					        opt.click();
					        result= true;
					    }
					}
					
					//UIHelper.highlightElement(getDriver();
				} catch (Exception e) {
					//throw new NoSuchElementException("Can't find " + exportAsPdf + " in dropdown");
				}
		        return result;
		       
		}

	public String verifyExportedPdfPage() {
			String str = "Not Downloaded as PDF";
			if(pdfExportOptEleForPortFolio.isPresent())
			{
				str = "Downloaded as PDF";
			}
			return str;
		}
		
		public boolean isElementPresent(By by) {
		    try {
		    	getDriver().findElement(by);
		        return true;
		    } catch (Exception e) {
		        return false;
		    }
		}

		
		
		public void verifyScoreSERSSIValueIsDisplayed() {
			
			try {
				scoreDropdownEleForPortfolioRisk.waitUntilPresent();
				if (scoreDropdownEleForPortfolioRisk.isPresent()) {
					UIHelper.highlightElement(getDriver(),scoreDropdownEleForPortfolioRisk);
					scoreDropdownEleForPortfolioRisk.click();
					
					
				}
			} catch (Exception e){
				e.printStackTrace();
			}
		}

		public void verifySSICircleFullIsDispalyed() {
			
			try {
				circleFullSSIValue.waitUntilPresent();
				if (circleFullSSIValue.isPresent()) {
					UIHelper.mouseOverandElementdoubleClick(getDriver(),circleFullSSIValue);
					waitFor(3000).milliseconds();
					// csvExportOptEleForTopCompanies.waitUntilPresent();
					// pdfExportOptEleForTopCompanies.waitUntilPresent();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void verifyBarGraphLineGraphValueIsDispalyed() {
			barGraphLineGraphvalue.waitUntilVisible();
			UIHelper.highlightElement(getDriver(), barGraphLineGraphvalue);
			barGraphLineGraphvalue.isCurrentlyVisible();
			
		}

		public void verifyLineGraphPercntgValueIsDisplayed() {
			try {
				barGraphvalue.waitUntilPresent();
				if (barGraphvalue.isPresent()) {
					UIHelper.mouseOverandElementdoubleClick(getDriver(),barGraphvalue);
					waitFor(3000).milliseconds();
					// csvExportOptEleForTopCompanies.waitUntilPresent();
					// pdfExportOptEleForTopCompanies.waitUntilPresent();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}

		public void verifyLineGraphXAxixValueIsDispalyed() {
			try {
				lineGraphXAxixValue.waitUntilPresent();
				if (lineGraphXAxixValue.isPresent()) {
					UIHelper.mouseOverandElementdoubleClick(getDriver(),lineGraphXAxixValue);
					waitFor(3000).milliseconds();
					// csvExportOptEleForTopCompanies.waitUntilPresent();
					// pdfExportOptEleForTopCompanies.waitUntilPresent();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void verifyLineGraphPerntgSERValueIsDisplayed() {
			 lineGraphPerntgSERValue.waitUntilVisible();
			UIHelper.highlightElement(getDriver(),  lineGraphPerntgSERValue);
			 lineGraphPerntgSERValue.isCurrentlyVisible();
			
		}

		public void VerifyBubbleGraph1AxixValueIsDisplayed() {
			
			
			
			bubblegraph1axixValue.waitUntilVisible();
				UIHelper.highlightElement(getDriver(),  bubblegraph1axixValue);
				bubblegraph1axixValue.isCurrentlyVisible();
				
		}
		
		
		/***************************************************************************************
		 * Function:Verify the high risk is defined for SER as 7 - 9 in the bubble graph
		 * Detailed : Action : Output : value
		 *
		 ****************************************************************************************/
		
		public void isDisplayedHighRiskSERScoreValue() {
			
			try {
				highRiskSEREle.waitUntilPresent();
				if (highRiskSEREle.isPresent()) {
					UIHelper.mouseOveranElement(getDriver(),highRiskSEREle);
					UIHelper.highlightElement(getDriver(), SERScoreValue);
					SERScoreValue.isCurrentlyVisible();					
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}

		/***************************************************************************************
		 * Function:Verify the high risk is defined for SSI as 7 - 10 in the bubble graph
		 * Detailed : Action : Output : value
		 *
		 ****************************************************************************************/

		public void verifyHighRiskSSIValueIsDisplayed() {
			try {
				highRiskSEREle.waitUntilPresent();
				if (highRiskSEREle.isPresent()) {
					UIHelper.mouseOveranElement(getDriver(),highRiskSEREle);
					UIHelper.highlightElement(getDriver(), SSIScoreValue);
					SSIScoreValue.isCurrentlyVisible();					
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		/***************************************************************************************
		 * Function:Verify the medium risk is defined for SER as 4 - 6 in the bubble graph
		 * Detailed : Action : Output : value
		 *
		 ****************************************************************************************/
		public void verifyMediumRiskBubbleGraphValueIsDisplayed() {
			try {
				mediumRiskEle.waitUntilPresent();
				if (mediumRiskEle.isPresent()) {
					UIHelper.mouseOveranElement(getDriver(),mediumRiskEle);
					UIHelper.highlightElement(getDriver(), SERScoreValue);
					SERScoreValue.isCurrentlyVisible();					
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void verifyMediumRiskSSIBubbleGraphValueIsDisplayed() {
			try {
				mediumRiskEle.waitUntilPresent();
				if (mediumRiskEle.isPresent()) {
					UIHelper.mouseOveranElement(getDriver(),mediumRiskEle);
					UIHelper.highlightElement(getDriver(), SSIScoreValue);
					SSIScoreValue.isCurrentlyVisible();					
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}


			
		/***************************************************************************************
		 * Function:Verify the Low risk is defined for SER as 4 - 6 in the bubble graph
		 * Detailed : Action : Output : value
		 *
		 ****************************************************************************************/
		
                   public void verifyLowRiskSSIBubbleGraphValueIsDisplayed() {
                	   
                	   try {
                		   lowRiskEle.waitUntilPresent();
           				if (lowRiskEle.isPresent()) {
           					UIHelper.mouseOveranElement(getDriver(),lowRiskEle);
           					UIHelper.highlightElement(getDriver(), SERScoreValue);
           					SERScoreValue.isCurrentlyVisible();					
           				}
           			} catch (Exception e) {
           				e.printStackTrace();
           			}
                          }

		public void verifyLowRiskBubbleGraphValueIsDisplayed() {
			
			 try {
      		   lowRiskEle.waitUntilPresent();
 				if (lowRiskEle.isPresent()) {
 					UIHelper.mouseOveranElement(getDriver(),lowRiskEle);
 					UIHelper.highlightElement(getDriver(),SSIScoreValue);
 					SSIScoreValue.isCurrentlyVisible();					
 				}
 			} catch (Exception e) {
 				e.printStackTrace();
 			}
		}

		public void verifyBubbleIsDipalyed() {
		
			try {
				hintTextEle.waitUntilPresent();
	 				if (hintTextEle.isPresent()) {
	 					UIHelper.mouseOveranElement(getDriver(),hintTextEle);
	 					UIHelper.highlightElement(getDriver(),circleEmptySERValue);
	 					circleEmptySERValue.isCurrentlyVisible();
	 					UIHelper.highlightElement(getDriver(),circleFullSSIValue);
	 					circleFullSSIValue.isCurrentlyVisible();
	 				}
	 			} catch (Exception e) {
	 				e.printStackTrace();
	 			}
		}

		public void verifyTotalBubbleValueIsDisplayed() {
			try {
				hintTextEle.waitUntilPresent();
	 				if (hintTextEle.isPresent()) {
	 					UIHelper.mouseOveranElement(getDriver(),hintTextEle);
	 					UIHelper.highlightElement(getDriver(),circleEmptySERValue);
	 					circleEmptySERValue.isCurrentlyVisible();
	 					UIHelper.highlightElement(getDriver(),circleFullSSIValue);
	 					circleFullSSIValue.isCurrentlyVisible();
	 					UIHelper.mouseOveranElement(getDriver(),bubblesBtnEle);
	 					UIHelper.mouseOveranElement(getDriver(),highSSIEle);
	 					UIHelper.mouseOveranElement(getDriver(), medSSIEle);
	 					UIHelper.mouseOveranElement(getDriver(), lowSSIEle);
	 				}
	 			} catch (Exception e) {
	 				e.printStackTrace();
	 			}
		}

		public void verifyGraphValueGreaterThenZeroValueIsDisplayed() {
			try {
				highRiskSEREle.waitUntilPresent();
				if (highRiskSEREle.isPresent()) {
					UIHelper.mouseOveranElement(getDriver(),highRiskSEREle);
					UIHelper.highlightElement(getDriver(), SERScoreValue);
					SERScoreValue.isCurrentlyVisible();					
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void verifySERCircleEmptyValueIsDisplayed() {
		
			try {
				portFolioTwoIcon.waitUntilPresent();
				if (portFolioTwoIcon.isPresent()) {
					UIHelper.mouseOveranElement(getDriver(),portFolioTwoIcon);
					UIHelper.highlightElement(getDriver(), circleEmptySERValue);
					circleEmptySERValue.isCurrentlyVisible();					
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void navigateSevereRiskValueIsDisplayed() {
			SevereRiskEle.waitUntilVisible();
				UIHelper.highlightElement(getDriver(),  SevereRiskEle);
				SevereRiskEle.isCurrentlyVisible();
				
			
		}

		public void veryExportButtonSevereValueIsDisplayed() {
			try {
				exportSevereRislEle.waitUntilPresent();
				if (exportSevereRislEle.isPresent()) {
					UIHelper.mouseOveranElement(getDriver(),exportSevereRislEle);
					waitFor(3000).milliseconds();
					// csvExportOptEleForTopCompanies.waitUntilPresent();
					// pdfExportOptEleForTopCompanies.waitUntilPresent();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
// Display Severe Risk pia chart center z empty
		public void verifyCenterOfPiaChartBlankValueIsDiplayed() {
			piaChartCenterValue.waitUntilVisible();
			UIHelper.highlightElement(getDriver(), piaChartCenterValue);
			piaChartCenterValue.isCurrentlyVisible();
			
		}

		public void verifyPiaChartValueRingBasedIsDisplayed() {
			try {
				piaChartCenterValue.waitUntilPresent();
				if (piaChartCenterValue.isPresent()) {
					UIHelper.mouseOveranElement(getDriver(),piaChartCenterValue);
					waitFor(3000).milliseconds();
					// csvExportOptEleForTopCompanies.waitUntilPresent();
					// pdfExportOptEleForTopCompanies.waitUntilPresent();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}

		public void clickRingAreaValueIsDisplayed() {
			try {
				csvExportSevereRisk.waitUntilPresent();
				if (csvExportSevereRisk.isPresent()) {
					UIHelper.mouseOverandElementdoubleClick(getDriver(),csvExportSevereRisk);
					waitFor(3000).milliseconds();
					// csvExportOptEleForTopCompanies.waitUntilPresent();
					// pdfExportOptEleForTopCompanies.waitUntilPresent();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}

		public void isDisplayedExportOptionsForSevereRiskValue() {
			// TODO Auto-generated method stub
			
		}

		public void clickExportCsvValueIsDisPlayed(String exportOption) {
			try {
				exportSevereRislEle.waitUntilPresent();
				if (exportSevereRislEle.isPresent()) {
					UIHelper.mouseOveranElement(getDriver(),exportSevereRislEle);
					waitFor(3000).milliseconds();
					// csvExportOptEleForTopCompanies.waitUntilPresent();
					// pdfExportOptEleForTopCompanies.waitUntilPresent();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}

		public void isDisplayedEXportButtonOptionsValue(String exportOptions) {
			try {
				exportSevereRislEle.waitUntilPresent();
				if (exportSevereRislEle.isPresent()) {
					UIHelper.mouseOverandElementdoubleClick(getDriver(),exportSevereRislEle);
					waitFor(3000).milliseconds();
					
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		

                   
		/***************************************************************************************
		 * Function:User clicks on {CSV} format(Severe Risk condition)
		 * Detailed : Action : Output : value
		 *
		 ****************************************************************************************/               
               

public void clickOnExportOptionSevereRisk(String exportOption) {
	try {
		if (exportOption.equalsIgnoreCase("CSV")) {
			UIHelper.mouseOverandclickanElement(getDriver(), severeRiskCsvExportOptEle);
		} /*else if (exportOption.equalsIgnoreCase("PDF")) {
			UIHelper.mouseOverandclickanElement(getDriver(), SevereRiskpdfExportOptEle);
		}*/

		//UIHelper.waitForPageToLoad(getDriver());
		UIHelper.waitForPageToLoad(getDriver());
		waitFor(7000).milliseconds();
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}

		public void clickCsvValue(String exportOption) {
			try {
				csvExportOptEle.waitUntilPresent();
				if (csvExportOptEle.isPresent()) {
					UIHelper.mouseOveranElement(getDriver(),csvExportOptEle);
					waitFor(3000).milliseconds();
					// csvExportOptEleForTopCompanies.waitUntilPresent();
					// pdfExportOptEleForTopCompanies.waitUntilPresent();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
}
