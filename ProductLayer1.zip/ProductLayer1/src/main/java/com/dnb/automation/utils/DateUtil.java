package com.dnb.automation.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**********************************************************************************************
 * DateUtil.java - This program gets current Date & time and converts to EST
 * format.
 * 
 * @author Duvvuru Naveen
 * @version 1.0
 ***********************************************************************************************/
public class DateUtil {
    // Get EST Time Zone
    private Date shiftTimeZone(Date date, TimeZone sourceTimeZone,
            TimeZone targetTimeZone) {
        Calendar sourceCalendar = Calendar.getInstance();
        sourceCalendar.setTime(date);
        sourceCalendar.setTimeZone(sourceTimeZone);

        Calendar targetCalendar = Calendar.getInstance();
        for (int field : new int[] { Calendar.YEAR, Calendar.MONTH,
                Calendar.DAY_OF_MONTH, Calendar.HOUR, Calendar.MINUTE,
                Calendar.SECOND, Calendar.MILLISECOND }) {
            targetCalendar.set(field, sourceCalendar.get(field));
        }
        targetCalendar.setTimeZone(targetTimeZone);
        return targetCalendar.getTime();
    }

    // Get EST Details
    public String getESTDetails(String zone) {
        Date date = new Date();
        SimpleDateFormat sf = new SimpleDateFormat("dd-MM-yyyy;HH:mm:ss");
        sf.format(date);
        TimeZone tz = sf.getTimeZone();
        TimeZone tz1 = TimeZone.getTimeZone(zone);
        Date c = shiftTimeZone(date, tz, tz1);

        return sf.format(c);
    }

    // Or Get EST Date and Time
    public String getESTDateAndTime(String timeZoneFor) {
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone(timeZoneFor));

        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy;h:mm:ss");
        df.setTimeZone(cal.getTimeZone());
        return df.format(cal.getTime());
    }
    
    public String getCurrentDateAndTime()
    {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        //get current date time with Date()
        Date date = new Date();
        
        return dateFormat.format(date);
    }
}
