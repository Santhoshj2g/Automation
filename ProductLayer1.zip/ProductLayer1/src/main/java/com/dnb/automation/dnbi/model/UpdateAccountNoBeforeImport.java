package com.dnb.automation.dnbi.model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**********************************************************************************************
 * UpdateAccountNoBeforeImport.java - This class update the account number in
 * ImportAccountData.csv file
 * 
 * @author Duvvuru Naveen,Sivakrishna Manigam
 * @version 1.0
 ***********************************************************************************************/
public class UpdateAccountNoBeforeImport {

    private String[] mapName;

    public String[] getMapName() {
        return mapName;
    }

    String textFileData[];

    public String[] getTextFileData() {
        return textFileData;
    }

    /***********************************************************************************************
     * Function: accNoUpdate Input : Action : update account number in
     * ImportAccountData.csv file Output :
     * 
     * @throws Exception
     ***********************************************************************************************/

    public void accNoUpdate(String uploadFileCol) throws Exception {

        try {
//        	ClassLoader classLoader = getClass().getClassLoader();
//        	File file = new File(classLoader.getResource("src/test/resources/ARImport_Copy3.csv").getFile());
//          FileInputStream fstream = new FileInputStream(uploadFileCol);
        	String filePath = System.getProperty("user.dir")+uploadFileCol;
        	System.out.println("----myfile path-----------------"+filePath);
        	File file= new File(filePath);
        	FileInputStream fstream = new FileInputStream(file);
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    fstream));
            String strLine;
            StringBuilder fileContent = new StringBuilder();
            int lineNbr = 0;
           
            while ((strLine = br.readLine()) != null) {

                lineNbr = lineNbr + 1;
                if (1 == lineNbr) {
                    String tokens[] = strLine.split(",");
                   
                    String newLine ="";
                    for(String s:tokens){
//                    	System.out.println("STRING SPLIT VALUES------"+s);
                    	  newLine=newLine+s+",";
                    }
                
                   
                  /*  String newLine = tokens[0] + "," + tokens[1] + ","
                            + tokens[2] + "," + tokens[3] + "," + tokens[4]
                            + "," + tokens[5] + "," + tokens[6] + ","
                            + tokens[7] + "," + tokens[8] + "," + tokens[9]
                            + "," + tokens[10] + "," + tokens[11];*/
                    System.out.println("total new line----"+newLine);
                    fileContent.append(newLine);
                    fileContent.append("\n");
                    continue;
                }

                DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssms");
                Date date = new Date();
                String AccountValue = "AC_" + dateFormat.format(date) + "_"
                        + lineNbr;

                String tokens[] = strLine.split(",");
                tokens[0] = AccountValue;
                /*String newLine = tokens[0] + "," + tokens[1] + "," + tokens[2]
                        + "," + tokens[3] + "," + tokens[4] + "," + tokens[5]
                        + "," + tokens[6] + "," + tokens[7] + "," + tokens[8]
                        + "," + tokens[9] + "," + tokens[10] + "," + tokens[11];*/
                String newLine1 ="";
                for(String s:tokens){
//                	System.out.println("STRING SPLIT VALUES------"+s);
                	  newLine1=newLine1+s+",";
                }
                fileContent.append(newLine1);
                fileContent.append("\n");
            }
           //-----------changed by siva-----------------
//            FileWriter fstreamWrite = new FileWriter(uploadFileCol);
            System.out.println("fstreamWritefilepath-----------"+filePath);
            FileWriter fstreamWrite = new FileWriter(filePath);
            BufferedWriter out = new BufferedWriter(fstreamWrite);
            out.write(fileContent.toString());
            out.close();

            fstream.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
