package com.dnb.automation.bd.pages;

import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.dnb.automation.utils.UIHelper;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/******************************************************************************************************
 * Description : LoginPage class contains locators and methods for login page
 * 
 *******************************************************************************************************/
public class LoginPage extends PageObject {

	
	@FindBy(xpath = "//*[@id='headerlinks']//a[@class='login']")
    private WebElementFacade btnLogIn;

	@FindBy(xpath = "//*[@id='userid']")
    private WebElementFacade txtUserName;

    @FindBy(xpath = "//*[@id='password']")
    private WebElementFacade txtPassword;

    @FindBy(xpath = "//*[@id='signinbutton']/span")
    private WebElementFacade btnSubmit;
    
    @FindBy(xpath = "//*[@id='qck-unspsc']")
    private WebElementFacade selBox;
    
    @FindBy(xpath = "//*/a[@class='activetab' and contains(text(),'HOME')]")
    private WebElementFacade tabHome;
    
  
       
    /***********************************************************************************
     * Function: Click on login button 
     * Input : NA
     * Action : NA 
     * Output : NA
     ***********************************************************************************/
    public boolean login()
    {
    	UIHelper.waitForPageToLoad(getDriver());
    	btnLogIn.waitUntilClickable();
    	btnLogIn.click();
    	UIHelper.waitForPageToLoad(getDriver());
    	if(txtUserName.isPresent())
    	{
    		return true;    		
    	}else
    	{
    		return false;
    	}
    	
    }
    
    /***********************************************************************************
     * Function: Get application URL and launch application 
     * Input : URL 
     * Action : Launch 
     * Output : Login screen should be displayed
     ***********************************************************************************/
    public boolean getURLAndLaunchApplication(String appURL) throws Exception {
        getDriver().manage().deleteAllCookies();
        getDriver().manage().window().maximize();
        getDriver().manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
        getDriver().manage().timeouts().pageLoadTimeout(4, TimeUnit.MINUTES);
        getURLtoTest(appURL);
        UIHelper.waitForPageToLoad(getDriver());
        if(txtUserName.isPresent())
        {
        	return true;
        }else
        {
        	return false;
        }
    }

    /***********************************************************************************
     * Function: Login into GD application 
     * Input : User name and password
     * Action : Type and click 
     * Output : Welcome message with user name should be displayed
     ***********************************************************************************/
    public void login(String userName, String password) throws Exception {
        enterLogin(userName);
        enterPassword(password);
        clickLoginButton();
    }

    /***********************************************************************************
     * Function: Enter URL of application in address bar of browser 
     * Input : NA
     * Action : enter URL 
     * Output : NA
     ***********************************************************************************/
    public void getURLtoTest(String appURL) throws Exception {
        UIHelper.waitForPageToLoad(getDriver());
        getDriver().get(appURL);
    }

    /***********************************************************************************
     * Function: Enter user name in user name text box 
     * Input : User name 
     * Action: Enter 
     * Output : NA
     ***********************************************************************************/
    public void enterLogin(String login) throws Exception {
        
        	txtUserName.waitUntilEnabled();        
            txtUserName.type(login);       
    }

    /***********************************************************************************
     * Function: Enter password in user name text box Input : Password Action :
     * Enter Output : NA
     ***********************************************************************************/
    public void enterPassword(String password) throws Exception {        
            txtPassword.waitUntilEnabled();
            txtPassword.type(password);
    }

    /***********************************************************************************
     * Function: Click on login button 
     * Input : NA 
     * Action : Click 
     * Output : NA
     ***********************************************************************************/
    public void clickLoginButton() throws Exception {
        if (btnSubmit.isPresent()) {
            btnSubmit.click();
            UIHelper.waitForPageToLoad(getDriver());   
//            WebDriverWait wait = new WebDriverWait(getDriver(),20);            
//            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@id='qck-unspsc']")));
            selBox.waitUntilPresent();
        }
    }

    /***********************************************************************************
     * Function: Homepage verification 
     * Input : NA 
     * Action : NA 
     * Output : NA
     ***********************************************************************************/
    public boolean userInHomePage() throws Exception {
        if (selBox.isPresent()) {
            return true;
        } else {
            return false;
        }
    } 
    
    /***********************************************************************************
     * Function: Click on home tab
     * Input   : NA 
     * Action  : Click
     * Output  : Home page of the application should be displayed
     ***********************************************************************************/
    public void clickOnHomeTab()
    {
    	if(tabHome.isPresent())
    	{
    		tabHome.click();
    		UIHelper.waitForPageToLoad(getDriver());
    	}
    }  
    
   
}