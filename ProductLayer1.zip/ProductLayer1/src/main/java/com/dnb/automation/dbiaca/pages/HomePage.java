package com.dnb.automation.dbiaca.pages;


import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

/**********************************************************************************************
 * HomePage.java - This program contains steps for 
 * 1. User checks home page navigation
 *
 * @author   Sendhilkumar.R
***********************************************************************************************/

public class HomePage extends PageObject{


	@FindBy(xpath="//*[@id='searchForm']")
	private WebElementFacade searchForm;
	
	@FindBy(xpath="//*[@href='welcome.asp?lang=ENG&SearchBy=DUNS']")
	private WebElementFacade dunsLink;
	
	@FindBy(xpath="//*[@id='searchForm']//input[@name='SearchString']")
	private WebElementFacade dunsNumber;
	
	@FindBy(xpath="//*[@id='searchForm']//select[@name='country']")	
	private WebElementFacade country;
	
	@FindBy(xpath="//*[@id='Submit1']")
	private WebElementFacade searchBtn;
	
	@FindBy(xpath="//*[contains(text(),'Company Search')]")
	private WebElementFacade companysearchLnk;
	
	//Navigate to home page
	
	
	
	public void navigateToDunsSearch()
	{
		dunsLink.click();
		dunsNumber.waitUntilVisible();
	}
	

	public boolean verifyDBIAhomePage()
	{
		try{
		if(searchForm.isPresent())
		{
			return true;
		}
		else
		{
			return false;
		}
		}catch(Exception e){
			throw e;
		}
		
		
	}
	
	public boolean verifyVisibilityOfDunsOptions(){
		try{
		if(dunsNumber.isPresent())
		{
			return true;
		}
		else
		{
			return false;
		}
		}catch(Exception e){
			throw e;
		}
	}
	
	public void doDunsSearch(String dunsNumber,String countryName){
		selectCountry(countryName);
		enterDuns(dunsNumber);
		clickSearchButton();
		
	}
	
	public void selectCountry(String countryName){
		try{
		UIHelper.highlightElement(getDriver(), country);
		if(countryName.equalsIgnoreCase("Slovakia(Slovak Republic)")){
		country.selectByValue("703");
		}else{
			country.selectByVisibleText(countryName);
		}
		}catch(Exception e){
			throw e;
		}
	}
			
	public void enterDuns(String duns){
		dunsNumber.type(duns);
	}
	
	public void clickSearchButton(){
		searchBtn.click();
		UIHelper.waitForPageToLoad(getDriver());
							
	}
	public void clickCompanySearch(){
		companysearchLnk.click();
		UIHelper.waitForPageToLoad(getDriver());
	}
	
	
	
}




