package com.dnb.automation.bd.pages;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dnb.automation.utils.UIHelper;
import com.thoughtworks.selenium.Wait;

public class SuperAdminMyAccountPage extends PageObject{	
	
	LoginPage objLoginPage;
	
	//Xpaths
	@FindBy(xpath = "//*/div[@id='navigation']/ul/li/a[@id='accessAdminAccount']")
	private WebElementFacade tabMyAccount;
	
	@FindBy(xpath = "//*/div[@class='pageHead']/h2")
	private WebElementFacade headingMyAccPg;
	
	@FindBy(xpath = "//*/div[@id='flat-tabs']/ul/li/a[contains(text(),'Details')]")
	private WebElementFacade tabMyDetails;
	
	String imgLoading= "//div[@class='loadmask-msg']";
	
	@FindBy(xpath = "//*/div[@id='interactive']//*/h3")
	private WebElementFacade headingManageAdv;
	
	@FindBy(xpath = "//*/div[@id='support']//*/a[contains(text(),'Manage Ads')]")
	private WebElementFacade lnkManageAds;
	
	@FindBy(xpath = "//*/div[@id='interactive']/div//*/h3")
	private WebElementFacade titleManageAdv;
	
//	@FindBy(xpath = "//*/div[@id='adv-inputs']//*/input[@id='adverFile' and @type='file']")
//	@FindBy(xpath = "//div[@id='adv-inputs']//a[@class='button']/span[contains(text(),'Browse')]")
	@FindBy(xpath = "//div[@id='adv-inputs']//a[@class='button' and @tabindex='1']")
	private WebElementFacade btnBrowse;
	
	@FindBy(xpath = "//*/input[@id='advtDesc']")
	private WebElementFacade txtAdDescription;
	
	@FindBy(xpath = "//*/div[@class='upload-container']/a[@id='addAdver']")
	private WebElementFacade btnUpload;
	
	@FindBy(xpath = "//*/div/label[@id='description-mandatory']")
	private WebElementFacade mandatoryMsg;
	
	@FindBy(xpath = "//*/div[@id='adv-inputs']//*/label[@class='filename']")
	private WebElementFacade imgWarningMsg;
	
	@FindBy(xpath = "//*/label[@id='uploadSuccessMessage']")
	private WebElementFacade msgSuccessfulImgUpload;	
	
	String filePath="D:\\Automation\\BD\\CustPromotionLogo.jpg";
	
	@FindBy(xpath = "//*/form[@id='genericForm']//*/h2")
	private WebElementFacade titleResetPwd;
	
	@FindBy(xpath = "//*/form[@id='genericForm']//*/input[@id='resetPasswordEmail']")
	private WebElementFacade txtSearchEmail;
	
	@FindBy(xpath = "//*/form[@id='genericForm']//*/input[@id='searchFirstName']")
	private WebElementFacade txtSearchFirstName;
	
	@FindBy(xpath = "//*/form[@id='genericForm']//*/input[@id='searchLastName']")
	private WebElementFacade txtSearchLastName;
	
	@FindBy(xpath = "//*/form[@id='genericForm']//*/select[@id='registerCountryTemp']")
	private WebElementFacade selCountry;
	
	@FindBy(xpath = "//*/a[@id='search-user']")
	private WebElementFacade btnSearch;
			
	@FindBy(xpath = "//*/table[@id='resetinguserDetails']/tbody/tr")
	private WebElementFacade tblRowUserDetails;
	
	@FindBy(xpath = "//*/table[@id='resetinguserDetails']/tbody/tr/td/input")
	private List<WebElementFacade> tblOptionBtn;
	
	@FindBy(xpath = "//*/table[@id='resetinguserDetails']/tbody/tr/td[@id='resetingUserId']")
	private List<WebElementFacade> tblUserID;
	
	@FindBy(xpath = "//*/table[@id='resetinguserDetails']/tbody/tr/td[@id='resetingUserFName']")
	private List<WebElementFacade> tblUserFName;
	
	@FindBy(xpath = "//*/table[@id='resetinguserDetails']/tbody/tr/td[@id='resetingUserLName']")
	private List<WebElementFacade> tblUserLName;
	
	@FindBy(xpath = "//*/a[@id='resetButtonView']")
	private WebElementFacade btnResetPwd;
	
	@FindBy(xpath = "//*/p[@id='resetUserIdStatus']")
	private WebElementFacade msgResetPwdLinkSent;
	
	@FindBy(xpath = "//*/input[@id='Email']")
	private WebElementFacade txtEmailID;
	
	@FindBy(xpath = "//*/input[@id='next']")
	private WebElementFacade btnNext;
	
	@FindBy(xpath = "//*/input[@id='Passwd']")
	private WebElementFacade txtPwd;
	
	@FindBy(xpath = "//*/input[@id='signIn']")
	private WebElementFacade btnSignIn;
	
	@FindBy(xpath = "//*/input[@id='PersistentCookie']")
	private WebElementFacade chkboxStaySignedIn;  //checked="checked"
	
	@FindBy(xpath = "//*/a[@id='userManagementResetPassword']")
	private WebElementFacade lnkResetPwd;
	
	@FindBy(xpath = "//a[contains(@title,'Google Account:')]")
	private WebElementFacade userNameInGmailHomePg;
	
//	@FindBy(xpath = "//table[@id=':3d']/tbody/tr/td/div[contains(text(),'unread')]/following-sibling::div[1]/span[contains(text(),'DNBCustomerNotifications')]/ancestor::td[1]/following-sibling::td[2]//*[contains(text(),'Reset your D&B')]")
//	.//div[@class='UI']//b[contains(text(),'Reset your D&B')]
	@FindBy(xpath = "//table[@id=':3d']/tbody/tr/td/div[contains(text(),'unread')]/following-sibling::div[1]/span[contains(text(),'DNBCustomerNotifications')]/ancestor::td[1]/following-sibling::td[2]//*[contains(text(),'Reset your D&B')]")
	private WebElementFacade inboxMail;
	
	@FindBy(xpath = "//*/div[@class='Bk']")
	private WebElementFacade mailBody;
		
	@FindBy(xpath = "//*/div[@class='nH']//a[contains(@href,'https://directory-web-q.dnb.com/globaldirectory')]")
	private WebElementFacade linkToResetPwd;
	
	@FindBy(xpath = "//*/div[@class='formpageHead float-left']/h2")
	private WebElementFacade titleActivateAcc;
	
	@FindBy(xpath = "//*/p[@id='tip-gray']/input[@id='registerEmailId']")
	private WebElementFacade greyUserID;  //title="User Id"
	
	@FindBy(xpath = "//*/input[@id='newPassword']")
	private WebElementFacade txtNewPwd;
	
	@FindBy(xpath = "//*/input[@id='confirmpassword']")
	private WebElementFacade txtConfirmPwd;
	
	@FindBy(xpath = "//*/a[@class='buttonBlue right register']")
	private WebElementFacade btnSubmitResetPwd;
	
	@FindBy(xpath = "//*/a[@class='gotoLoginPage']")
	private WebElementFacade lnkGoToLoginPg;
	
	@FindBy(xpath = "//*/p[@id='activeSuccess']")
	private WebElementFacade msgActivation; //User activation completed successfully
	
	@FindBy(xpath = "//*/ul[@id='headerlinks']/li/span")
	private WebElementFacade msgLoggedInAs;
	
	@FindBy(xpath = "//*/a[@href='logout']")
	private WebElementFacade lnkLogout;
	
	@FindBy(xpath = "//div[@id='adv-inputs']//input[@id='advtDuns']")
	private WebElementFacade txtDuns;
	
	@FindBy(xpath = "//div[@id='adv-inputs']//input[@id='advtDesc']")
	private WebElementFacade txtDesc;

	@FindBy(xpath = "//div[@id='adv-inputs']//label[@class='filename']")
	private WebElementFacade VisibleFile;

	@FindBy(xpath = "//a[@id='addAdver']")
	private WebElementFacade btnUploadAdd;

	@FindBy(xpath = "//label[@id='uploadSuccessMessage']")
	private WebElementFacade labelAdvConfirmation;

	@FindBy(xpath = "//div[@id='delete-confirm-dialog']")
	private WebElementFacade msgAddDelete;

	@FindBy(xpath = "//div[@id='delete-confirm-dialog']//a[@class='buttonBlue']/span[contains(text(),'OK')]")
	private WebElementFacade btnAddDeleteOk;

	@FindBy(xpath = "//div[@id='adv-inputs']//select[@id='ownAdd']")
	private WebElementFacade selAddCat;
	
	
	
	
		
	/***********************************************************************************
	*	Function: Click on My Account tab
	*	Input 	: NA
	*	Action	: Click
	*   Output  : My Account page should be displayed	
	***********************************************************************************/
	public void clickMyAccountTab()
	{		
		if(tabMyAccount.isPresent())
		{			
			tabMyAccount.click();
			UIHelper.waitForPageToLoad(getDriver());
		}
	}
	
	/***********************************************************************************
	*	Function: Get page title
	*	Input 	: NA
	*	Action	: Get title
	*   Output  : Return the title of My Account page
	*   @return 
	***********************************************************************************/
	public String getMyAccountPgTitle()
	{
		if(headingMyAccPg.isPresent())
		{
			return headingMyAccPg.getText();
		}
		else
		{
			return null;
		}		
	}
	
	/***********************************************************************************
	*	Function: Click on My Details tab
	*	Input 	: NA
	*	Action	: Click
	*   Output  : My Details page should be displayed	
	***********************************************************************************/
	public void clickMyDetailsTab()
	{
		if(tabMyDetails.isPresent())
		{
			tabMyDetails.click();
			waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgLoading);
		}
	}
	
	/***********************************************************************************
	*	Function: Check manage ads link is available
	*	Input 	: NA
	*	Action	: get availability of link
	*   Output  : return true if available 
	*   @return 
	***********************************************************************************/
	public boolean isPresentManageAds()
	{
		return lnkManageAds.isVisible();
	}
	
	/***********************************************************************************
	*	Function: Click on manage ads link
	*	Input 	: NA
	*	Action	: Click
	*   Output  : Manage advertisement page should be displayed	
	***********************************************************************************/
	public void clickManageAdsLink()
	{
//			UIHelper.highlightElement(getDriver(), lnkManageAds);
			lnkManageAds.click();
			waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgLoading);
	}
	
	/***********************************************************************************
	*	Function: Get title of the manage advertisement page
	*	Input 	: NA
	*	Action	: Get title value
	*   Output  : Return the title of manage advertisement page
	*   @return 
	***********************************************************************************/
	public String getManageAdvTitle()
	{
		if(headingManageAdv.isPresent())
		{
			return headingManageAdv.getText();
		}
		else
		{
			return null;
		}
	}	
	
	/***********************************************************************************
	*	Function: Upload ads
	*	Input 	: Path of the image
	*	Action	: upload image
	*   Output  : Image should be uploaded
	*   @return 
	***********************************************************************************/
	public void uploadAds() throws Exception
	{
		if(titleManageAdv.isPresent() && btnBrowse.isPresent())
		{
			UIHelper.highlightElement(getDriver(), btnBrowse);				
		
			upload("src/test/resources/BDLogo/CustPromotionLogo.jpg").to(btnBrowse);	
			
		/*	File file=new File("C:/Automation/BD/CustPromotionLogo.jpg");
			URL url=file.toURI().toURL();
			btnBrowse..sendKeys(url.toString());
		*/
					
			
	//		btnBrowse.click();
		
			System.out.println("**********filename in browse button:"+btnBrowse.getText());
			Select selectAdCategories = new Select(getDriver().findElement(By.id("ownAdd")));
			selectAdCategories.selectByVisibleText("Customer Promotion");
			Thread.sleep(2000);
			txtAdDescription.sendKeys("Sample Customer Promotion Ad");	
			btnUpload.click();	
			Thread.sleep(2000);
			
	//		JavascriptExecutor js = (JavascriptExecutor) getDriver();
	//		js.executeScript("document.getElementByXpath('//*/div[@id='adv-inputs']//*/a[@class='button' and @tabindex='1']').setAttribute('href', 'D:\\Automation\\BD\\CustPromotionLogo.jpg')");
					
	/*		js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", 
			btnBrowse, "href", "C:\\Automation\\BD\\CustPromotionLogo.jpg");
	*/
			
	//		upload("src/test/resources/BDLogo/CustPromotionLogo.jpg").to(btnBrowse);	
			
	//		upload(filePath).to(btnBrowse);
			
	//		btnBrowse.sendKeys(filePath);
			
			
	//		WebElement dropdownlists = getDriver().findElement(By.xpath("//*/div[@id='adv-inputs']//*/a[@class='button' and @tabindex='1']"));
	/*		dropdownlists.sendKeys("D:\\Automation\\BD\\CustPromotionLogo.jpg");
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
	*/	
			
	/*		File logoPath=new File("D:\\Automation\\BD\\CustPromotionLogo.jpg");
			btnBrowse.sendKeys(logoPath.getAbsolutePath());
	*/		
		}
	}
	
	/***********************************************************************************
	*	Function: Get upload status
	*	Input 	: Path of the image
	*	Action	: get status of upload
	*   Output  : returns the upload status
	*   @return 
	***********************************************************************************/
	public boolean imgUploadStatus() throws IOException
	{
		BufferedImage bimg = ImageIO.read(new File(filePath));
		int width          = bimg.getWidth();
		int height         = bimg.getHeight();
		System.out.println("**********width:"+width);
		System.out.println("*********height:"+height);
		if(width==728 && height==90)
		{
			return msgSuccessfulImgUpload.getText().contains("successfully");			
		}
		else
		{
			return false;
		}		
	}
	
	/***********************************************************************************
	*	Function: click on reset password link
	*	Input 	: NA
	*	Action	: Click
	*   Output  : Reset password page should be displayed
	***********************************************************************************/
	public void clickOnResetPassword()
	{
		if(lnkResetPwd.isPresent())
		{
			lnkResetPwd.click();
			waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgLoading);
		}
	}
	
	/***********************************************************************************
	*	Function: Get title of the reset password page
	*	Input 	: NA
	*	Action	: Get title value
	*   Output  : Return the title of reset password page
	***********************************************************************************/
	public String getResetPwdPgTitle(String resetPwdTitle)
	{
		if(titleResetPwd.isPresent())
		{
			return titleResetPwd.getText();
		}
		else
		{
			return null;
		}
	}
	
	/***********************************************************************************
	*	Function: Enter email,first name,last name and select country
	*	Input 	: Email,first name,last name and country
	*	Action	: Sendkeys and click
	*   Output  : user's registration details should be displayed	
	***********************************************************************************/
	public void fillResetFieldsAndSearch(String email,String firstName,String lastName,String country)
	{
		if(txtSearchEmail.isPresent() && txtSearchFirstName.isPresent() && txtSearchLastName.isPresent() && selCountry.isPresent())
		{
			txtSearchEmail.sendKeys(email);
			txtSearchFirstName.sendKeys(firstName);
			txtSearchLastName.sendKeys(lastName);
			Select selCountryVal=new Select(getDriver().findElement(By.xpath("//*/form[@id='genericForm']//*/select[@id='registerCountryTemp']")));
			selCountryVal.selectByVisibleText(country);
			btnSearch.click();
			waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgLoading);
		}
	}
	
	/***********************************************************************************
	*	Function: Select user's registration detail if present
	*	Input 	: UserID
	*	Action	: Select
	*   Output  : NA	
	***********************************************************************************/
	public void isUserDetailsDisplayed(String userID)
	{
		if(tblOptionBtn.get(0).isPresent())
		{
			int noOfOptionsBtn=tblOptionBtn.size();
			if(noOfOptionsBtn>0)
			{
				for(int index=0;index<tblUserID.size();index++)
				{
					if(tblUserID.get(index).getText().contains(userID))
					{
						tblOptionBtn.get(index).click();
					}
				}
			}
			else if(tblUserID.get(0).getText().contains(userID))
			{
				tblOptionBtn.get(0).click();
			}
		}
	}
	
	/***********************************************************************************
	*	Function: click on reset button
	*	Input 	: NA
	*	Action	: Click
	*   Output  : A message of triggering a mail to reset password should be displayed	
	***********************************************************************************/
	public void clickOnResetBtn()
	{
		if(btnResetPwd.isPresent())
		{
			btnResetPwd.click();
			waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgLoading);				
		}		
	}
	
	/***********************************************************************************
	*	Function: Get message of triggering mail
	*	Input 	: NA
	*	Action	: get message of triggering mail
	*   Output  : return the message
	*   @return 
	***********************************************************************************/
	public String getResetMsg()
	{
		System.out.println("*****************driver"+getDriver());
		if(msgResetPwdLinkSent.isPresent())
		{
//			Reset password link has been successfully sent to the user	
			return msgResetPwdLinkSent.getText();
		}
		else
		{
			return null;
		}
	}
	
	/***********************************************************************************
	*	Function: Launch gmail application
	*	Input 	: NA
	*	Action	: Launch
	*   Output  : Login page of gmail should be displayed	
	***********************************************************************************/
	public void launchGmail() throws Exception
	{
		getDriver().manage().deleteAllCookies();
        getDriver().manage().window().maximize();
        getDriver().manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
        getDriver().manage().timeouts().pageLoadTimeout(4, TimeUnit.MINUTES);
        objLoginPage.getURLtoTest("www.gmail.com");
        UIHelper.waitForPageToLoad(getDriver());
	}		
	
	/***********************************************************************************
	*	Function: Get the availability of user id text box 
	*	Input 	: NA
	*	Action	: Get availability
	*   Output  : Return true if user id text box is displayed
	*   @return 
	***********************************************************************************/
	public boolean isGmailLoginPgDisplayed()
	{
		if(txtEmailID.isPresent())
		{
			return true;
		}
		else
		{
			return false;
		}
	}	
	
	/***********************************************************************************
	*	Function: Enter email id and password and click on sign in
	*	Input 	: Email id and password
	*	Action	: Sendkeys and click
	*   Output  : Home page of user should be displayed	
	***********************************************************************************/
	public void loginWithUserRegMailID(String EmailID,String Pwd) throws Exception 
	{
		System.out.println("*****************driver"+getDriver());
		txtEmailID.sendKeys(EmailID);
		btnNext.click();
		txtPwd.sendKeys(Pwd);
		btnSignIn.click();	
		UIHelper.waitForPageToLoad(getDriver());
//		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*/table[@id=':3d']/tbody/tr")));
		Thread.sleep(20000);
	}
	
	/***********************************************************************************
	*	Function: Get user name in home page of gmail
	*	Input 	: NA
	*	Action	: Get user name
	*   Output  : Return user name
	*   @return 
	***********************************************************************************/
	public String getUserNameFrmHomePg()
	{
		if(userNameInGmailHomePg.isPresent())
		{
			return userNameInGmailHomePg.getText();
		}
		else
		{
			return null;
		}
	}
	
	/***********************************************************************************
	*	Function: Click on email received to reset the password
	*	Input 	: NA
	*	Action	: Click on mail
	*   Output  : Mail body should be displayed	
	***********************************************************************************/
	public void clickOnEmailMsg()
	{
		if(inboxMail.isPresent())
		{
			inboxMail.click();	
			mailBody.waitUntilPresent();
		}
	}
	
	/***********************************************************************************
	*	Function: Get the availability of reset link in mail body 
	*	Input 	: NA
	*	Action	: Get availability
	*   Output  : Return the availability of reset link in mail body
	*   @return 
	***********************************************************************************/
	public boolean isDisplayedMailBodyWithResetPwdLink()
	{
		return linkToResetPwd.isPresent();		
	}
	
	/***********************************************************************************
	*	Function: Click on reset password link
	*	Input 	: NA
	*	Action	: Click on the reset link
	*   Output  : Activate account page should be displayed	
	***********************************************************************************/
	public void clickLinkToResetPwd()
	{
		if(mailBody.isPresent() && linkToResetPwd.isPresent())
		{
			linkToResetPwd.click();
			UIHelper.waitForPageToLoad(getDriver());
		}
	}
	
	/***********************************************************************************
	*	Function: Get title of the Activate account page
	*	Input 	: NA
	*	Action	: Get title value
	*   Output  : Return the title of Activate account page
	***********************************************************************************/
	public String getActivateAccPgTitle()
	{	
		Set noOfWindows;
		Iterator iterate;
		UIHelper.waitForPageToLoad(getDriver());
		String parentWindowId = getDriver().getWindowHandle();
		noOfWindows=getDriver().getWindowHandles();
		iterate=noOfWindows.iterator();
		while(iterate.hasNext())
		{
			String popupHandle=iterate.next().toString();
			if(!popupHandle.contains(parentWindowId))
			{				
				getDriver().switchTo().window(popupHandle);				
				titleActivateAcc.waitUntilPresent();				
			}
		}		
		if(titleActivateAcc.isPresent())
		{
			return titleActivateAcc.getText();
		}
		else
		{
			return null;
		}	
		
	//	getDriver().close();
	//	getDriver().switchTo().window(parentWindowId);	
		
	}
		
	/***********************************************************************************
	*	Function: Enter new password and confirm password and click on submit button
	*	Input 	: New password and confirm password
	*	Action	: Sendkeys and click
	*   Output  : Password successfully reset message should be displayed	
	***********************************************************************************/
	public void enterNewAndConfirmPwd(String newPwd,String confirmPwd)
	{		
		if(greyUserID.isPresent())
		{	
			greyUserID.waitUntilDisabled();
//			waitForCondition().until(greyUserID.getAttribute("title").contains("User Id"));
			if(greyUserID.getAttribute("title").contains("User Id") && txtNewPwd.isPresent() && txtConfirmPwd.isPresent())
			{
				txtNewPwd.sendKeys(newPwd);
				txtConfirmPwd.sendKeys(confirmPwd);
				btnSubmitResetPwd.click();
				UIHelper.waitForPageToLoad(getDriver());
			}
		}
	}
	
	/***********************************************************************************
	*	Function: Get activation message 
	*	Input 	: NA
	*	Action	: Get message value
	*   Output  : Successfully reset password message should be displayed
	*   @return 
	***********************************************************************************/
	public String getActivationMsg()
	{
		if(msgActivation.isPresent())
		{
			return msgActivation.getText();
		}
		else
		{
			return null;
		}
	}
	
	/***********************************************************************************
	*	Function: Click on got to login page link
	*	Input 	: NA
	*	Action	: Click
	*   Output  : Page should be redirected to login page 	
	***********************************************************************************/
	public void clickGoToLoginPgAftrChangePwd()
	{
		if(lnkGoToLoginPg.isPresent())
		{
			lnkGoToLoginPg.click();			
		}
	}
		
	
	/***********************************************************************************
	*	Function: Click on logout link
	*	Input 	: NA
	*	Action	: Click
	*   Output  : User should be logged out of application
	***********************************************************************************/
	public void clickLogoutLink()
	{
		if(lnkLogout.isPresent())
		{
			lnkLogout.click();
		}
	}

	/***********************************************************************************
	*	Function: select the ad category from the Ad Categories dropdown
	*	Input 	: NA
	*	Action	: Select
	*   Output  : NA
	***********************************************************************************/
	public void selectAdCategories(String adCategories) {
		

		Select selectAdCategories = new Select(selAddCat);
		selectAdCategories.selectByVisibleText(adCategories);		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		selAddCat.selectByVisibleText(adCategories);
		selAddCat.click();
		
	}

	/***********************************************************************************
	*	Function: Enter Duns number for Advertisement
	*	Input 	: NA
	*	Action	: Sendkeys
	*   Output  : NA
	***********************************************************************************/	
	public void enterDuns(String duns) {
		if(! duns.isEmpty())
		{
			txtDuns.waitUntilEnabled();
			txtDuns.sendKeys(duns);		
		}
		
	}

	/***********************************************************************************
	*	Function: Enter description for Advertisement
	*	Input 	: NA
	*	Action	: Sendkeys
	*   Output  : NA
	***********************************************************************************/	
	public void enterAdDesc(String adsDesc) {
		txtDesc.waitUntilEnabled();
		txtDesc.sendKeys(adsDesc);		
	}

	/***********************************************************************************
	*	Function: Click on file browser button
	*	Input 	: NA
	*	Action	: Click
	*   Output  : NA
	***********************************************************************************/		
	public void clickBrowseButton() {
        getDriver().findElement(By.cssSelector("input#adverFile")).click();
        getDriver().switchTo().activeElement();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/***********************************************************************************
	*	Function: Select the Customer Promotion Image
	*	Input 	: NA
	*	Action	: select
	*   Output  : NA
	***********************************************************************************/			
	public void uploadAdvertisementImage(String ImageName) {
		
     String AutoItPath = System.getProperty("user.dir")+"\\src\\test\\resources\\AppTestData\\BusinessDirectory\\AutoIt_UploadFile.exe";
     String UploadImagePath = System.getProperty("user.dir")+"\\src\\test\\resources\\AppTestData\\BusinessDirectory\\UploadImages\\"+ImageName;
     System.out.println("Testing1..AutoItPath..."+AutoItPath);
     System.out.println("Testing2..UploadImagePath..."+UploadImagePath);
/*     try {
		Runtime.getRuntime().exec("C:\\BD_AutoIT\\AutoIt_UploadFile.exe "+ImageName+"");		
//		Runtime.getRuntime().exec(AutoItPath+" "+UploadImagePath+"");
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
*/    
//     UIHelper.highlightElement(getDriver(), btnBrowse);     
     getDriver().findElement(By.id("adverFile")).sendKeys(UploadImagePath);
     
     VisibleFile.waitUntilPresent();

	}

	/***********************************************************************************
	*	Function: verify the selected file is displayed
	*	Input 	: NA
	*	Action	: NA
	*   Output  : boolean
	***********************************************************************************/			
	public boolean isSelectedFileDisplayed() {		
		return VisibleFile.isCurrentlyVisible();
	}

	/***********************************************************************************
	*	Function: Click on the Upload button
	*	Input 	: NA
	*	Action	: NA
	*   Output  : boolean
	***********************************************************************************/			
	public void clickAdvUpload() {
		btnUploadAdd.click();	
		waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgLoading);
	}

	/***********************************************************************************
	*	Function: get the Advertisement confirmation message
	*	Input 	: NA
	*	Action	: NA
	*   Output  : Confirmation message
	***********************************************************************************/			
	
	public String getAdvConfrimationMsg() {
		return labelAdvConfirmation.getText();
		
	}

	/***********************************************************************************
	*	Function: Verify the uploaed adver is available in the uploaded adds
	*	Input 	: NA
	*	Action	: NA
	*   Output  : boolean
	***********************************************************************************/			
	public boolean isUploadedAddAvail(String AdsDesc) {
		int row = getAddRowNum(AdsDesc);
		if(row >0)
			return true;			
		else
			return false;				
	}
	
	
	/***********************************************************************************
	*	Function: Verify the uploaed adver is available in the uploaded adds
	*	Input 	: NA
	*	Action	: NA
	*   Output  : NA
	***********************************************************************************/			
	public int getAddRowNum(String AdsDesc)
	{
		int advRowNo = 0;
		WebElement table = getDriver().findElement(By.xpath("//table[@id='advertiementTable']/tbody"));
		int numOfRows = table.findElements(By.tagName("tr")).size();
		String first_part = "//table[@id='advertiementTable']/tbody/tr[";
		String second_part = "]/td[2]";		
		
		for (int i=1; i<=numOfRows; i++)
		{

		    //Prepared final xpath of specific cell as per values of i and j.
		       String final_xpath = first_part+i+second_part;
		       String test_name = getDriver().findElement(By.xpath(final_xpath)).getText();

		       if(test_name.equalsIgnoreCase(AdsDesc))
		       {		
		    	   advRowNo = i;	
		    	   break;
		       }
		}
		return advRowNo;
	}

	/***********************************************************************************
	*	Function: click on Ok delete button of the Adds
	*	Input 	: Add description
	*	Action	: Click
	*   Output  : NA
	***********************************************************************************/			
	public void clickAddDeleteButton(String adsDesc) {
		getDriver().findElement(By.xpath("//*[text()='"+adsDesc+"']/following-sibling::td/a")).click();		
	}
	
	/***********************************************************************************
	*	Function: Verify the Add delete confirmation message is displayed.
	*	Input 	: NA
	*	Action	: NA
	*   Output  : Confirmation message
	***********************************************************************************/			

	public boolean isAddDeleteConfirmationDisp() {
		return msgAddDelete.isCurrentlyVisible();		
	}

	/***********************************************************************************
	*	Function: click on Ok button of the Adds delete confirmation
	*	Input 	: NA
	*	Action	: Click
	*   Output  : NA
	***********************************************************************************/			
	
	public void clickOkAddsDelete() {
		btnAddDeleteOk.click();
		waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgLoading);
	}

	/***********************************************************************************
	*	Function: Wait until for loading image is disappeared 
	*	Input 	: NA
	*	Action	: NA
	*   Output  : NA
	***********************************************************************************/			

    public void waitForInvisibilityOfAjaxImgByXpath(
            final WebDriver driver, final String ajaxElementxpath) {

        try {
            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By
                    .xpath(ajaxElementxpath)));
        } catch (Exception e) {

        }
    }
	
}
