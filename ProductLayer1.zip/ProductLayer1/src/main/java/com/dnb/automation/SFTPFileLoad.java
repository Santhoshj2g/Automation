package com.dnb.automation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;


import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;


public class SFTPFileLoad {
	
	private static String userName;
	private static String password;
	private static String hostId;
	private static final int READTIME=1024;
	private static final int SLEEPTIME=1000;
	private static final int READINCTHREAD=2750;
	
	
	
	public static String getHostId(){
		return hostId;
	}
	
	public static void setHostId(String hostId){
		SFTPFileLoad.hostId = hostId;
	}
	
	public static String getUserName(){
		return userName;
	}
	
	public static void setUserName(String userName){
		SFTPFileLoad.userName = userName;
	}
	
	public static String getPassWord(){
		return password;
	}
	
	public static void setPassword(String password){
		SFTPFileLoad.password = password;
	}
	
	public void putFileToSFTP(String hostId, String userName, String password,
			String locPath, String remotePath) throws Exception{
		Session session = createConnection(hostId, userName, password);
		Channel channel = null;
		ChannelSftp channelSftp = null;
		try {
			channel = session.openChannel("sftp");
			channel.connect();
			channelSftp = (ChannelSftp)channel;
			
			File files = new File(locPath);
			File[] filelist = files.listFiles();
			for(File file : filelist){
			String fileName = file.getName();
			String absolutefileName  = file.getAbsolutePath();
			InputStream input = new FileInputStream(absolutefileName);
			channelSftp.cd(remotePath);
			channelSftp.put(input, fileName);
			}
			
			
			/*channelSftp.cd(remotePath);
			File f = new File(locPath);
			channelSftp.put(new FileInputStream(f), f.getName());*/

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			channelSftp.exit();
			channel.disconnect();
			session.disconnect();
			}
	}

	public Session createConnection(String sftpHost, String sftpUser,
			String sftpPass) throws Exception{
		JSch jsch = new JSch();
		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		
		Session session = jsch.getSession(sftpUser, sftpHost);
		session.setPassword(sftpPass);
		session.setConfig(config);
		session.connect();
		System.out.println("Connected");
		return session;
	}

	public void executeShellScript(String hostId, String userName, String password, 
			String script, String filepath) throws Exception
	{
		Session session = createConnection(hostId, userName, password);
		ChannelExec channelExec = null;	
		Channel channel = session.openChannel("exec");
		try{
			channelExec =((ChannelExec) channel);
			channelExec.setCommand(filepath + script);
			System.out.print(filepath + script);
			channel.connect();
			channel.run();		
			InputStream in = channel.getInputStream();
			readInStream(channel, in);
		
		
		//readInStream(channel, in);

		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if(channel.isClosed()){
				System.out.println("exit-status:" + channel.getExitStatus());
			}else {
				channel.disconnect();
				session.disconnect();
				System.out.println("exit-status:" + channel.getExitStatus());
			}
		}
		
	}

	private void readInStream(Channel channel, InputStream in) {
		int countofthread = 0;
		try {
		byte[] tmp = new byte[READTIME];
		while (true) {
		while (in.available() > 0) {
		int i = in.read(tmp, 0, READTIME);
		if (i < 0) {
		break;
		 }
		System.out.println(new String(tmp, 0, i));
		}
		if (channel.isClosed()) {
		
		break;
		}
		try {
		Thread.sleep(SLEEPTIME);
		countofthread++;
		if (countofthread == READINCTHREAD) {
		break;
		 }
		} catch (Exception e) {
		
		}
		}
		} catch (Exception e) {
		e.printStackTrace();
		} 
		
	}
	
	public static void main(String []args) throws Exception{
		SFTPFileLoad obj = new SFTPFileLoad();
		obj.executeShellScript("158.151.156.216", "hameedy", "sbfeqa2@2016", 
				"sbfe-invoke-file-validation.sh", "/dnbusr1/dnbweb/SBFEBatch/scripts/");
	}
	
}
