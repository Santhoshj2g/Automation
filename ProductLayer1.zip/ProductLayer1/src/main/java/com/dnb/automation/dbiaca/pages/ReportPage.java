package com.dnb.automation.dbiaca.pages;

import com.dnb.automation.utils.UIHelper;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

/********************************************************************************************************************************
 * ReportPage.java - Program consists of the following actions
 * 1. Verifying D&B Risk Indicator in the Identification & Summary section of the report with Expected D&B Risk Indicator
 * 2. Verifying D&B Failure Score in the Identification & Summary section of the report with Expected D&B Failure Score
 * 3. Verifying D&B Credit Limit in the Identification & Summary section of the report with Expected D&B Credit Limit
 * 4. Verifying D&B Rating in the D&B Risk Assessment section of the report with Expected D&B Rating
 * 5. Verifying D&B Financial Strength in the D&B Risk Assessment section of the report with Expected D&B Financial Strength
 * 6. Verifying D&B Risk Indicator (1-4) in the D&B Risk Assessment section of the report with Expected D&B Risk Indicator (1-4)
 * 7. Verifying D&B Credit Limit in the D&B Risk Assessment section of the report with Expected D&B Credit Limit
 * 8. Verifying D&B Failure Score in the D&B Risk Assessment section of the report with Expected D&B Failure Score
 *
 * @author   Sendhilkumar.R
********************************************************************************************************************************/

public class ReportPage extends PageObject {
	
	@FindBy(xpath = "html/body/table[1]/tbody/tr[3]/td/table/tbody/tr[3]/td")
	private WebElementFacade Report;
	
	@FindBy(xpath = "//h3/i/font")
	private WebElementFacade reportNameTxt;
		
	@FindBy(xpath = "//*[contains(text(),'Company Search')]")
	private WebElementFacade companySearchLink;
	String result;
	
	@FindBy(xpath="html/body/table[1]/tbody/tr[3]/td/table/tbody/tr[3]/td")
	private WebElementFacade reportTbl;
	
	
	// To check report availability
	
	public boolean hasReport()
	{
		if(Report.isPresent())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
		
		// To check report has section Identification & Summary and D&B Risk Assessment
		
		public boolean hasIdentificationSummary()
		{
			try {
				getIdentificationSummary();
				return true;
			} catch (Exception e) {
				return false;
			}
		}
		
		public boolean hasRiskAssesment()
		{
			try {
				getRiskAssesment();
				return true;
			} catch (Exception e) {
				return false;
			}
		}
		
		public boolean hasCreditOpinion()
		{
			try {
				getCreditOpinion();
				return true;
			} catch (Exception e) {
				return false;
			}
		}
		
		// To Verify the that actual value is equal to the expected value for each element
		
		public boolean verifyIdSummary_RiskIndicator(String IdSummary_RiskIndicator)
		{
			if (hasIdentificationSummary())
			{
				String Actual = getIdentificationSummary();
				if (Actual.toLowerCase().replaceAll("\\s", "").contains(("D&B Risk Indicator        "+IdSummary_RiskIndicator).toLowerCase().replaceAll("\\s", "")))
				{
					return true;
				}else if(IdSummary_RiskIndicator=="-"){
					return true;
				}
				else{
					return false;
				}
				
			}else{
				return false;
			}
		}
		
			
		public boolean verifyIdSummary_FailureScore(String IdSummary_FailureScore)
		{
			if (hasIdentificationSummary())
			{
				String Actual = getIdentificationSummary();
								
				if (Actual.toLowerCase().replaceAll("\\s", "").contains(("D&B Failure Score         "+IdSummary_FailureScore).toLowerCase().replaceAll("\\s", "")))
				{
					return true;
				}else if(IdSummary_FailureScore.equalsIgnoreCase("") && extractBetween("D&B Risk Indicator        -", "Score Override", Actual).replaceAll("\\s", "").equalsIgnoreCase("")){
					
						return true;
					
				}else{
						return false;
				}
			}else{
					return false;
			}
		}
		
		public boolean verifyIdSummary_CreditLimit(String IdSummary_CreditLimit)
		{
			if (hasIdentificationSummary())
			{
				String idCreditLimit;
				String creditLimit[] = new String[2];
				idCreditLimit = formatCreditLimit(IdSummary_CreditLimit);
				creditLimit = idCreditLimit.split("\\.");
				String idSummaryCreditLimit = "EUR"+creditLimit[0];
				String Actual = getIdentificationSummary();
				
								
				if (Actual.replaceAll("\\s", "").contains(("D&B Credit Limit         "+idSummaryCreditLimit).replaceAll("\\s", "")))
				{
					return true;										  
				}else if((IdSummary_CreditLimit.equalsIgnoreCase("0")||IdSummary_CreditLimit.equalsIgnoreCase("")) && !extractBetween("D&B Risk Indicator", "Score Override", Actual).contains("D&B Credit Limit")){
					
						return true;
					
				}else{
						return false;
				}
			}else{
					return false;
			}
		}
		
		//To get the exact credit value -IdSummary
		public String  getSlovakiaCreditLimit()
			{
			   if(getCreditLimit().contains("D&B Credit Limit"))
				return extractBetween("EUR", "Score Override", getReport());
			   else{
				   return "zero";
			   }
			}
		
		public boolean verifyRiskAssesment_Rating(String RiskAssesment_Rating)
		{
			if (hasRiskAssesment())
			{
				String Actual = getRiskAssesment();
				if (Actual.toLowerCase().replaceAll("\\s", "").contains(("D&B Rating                     "+RiskAssesment_Rating).toLowerCase().replaceAll("\\s", "")))
				{
					return true;
				}else{
					return false;
				}
			}else{
				return false;
			}
		}
		
		public boolean verifyRiskAssessment_FinancialStrength(String RiskAssesment_FinancialStrength)
		{
			if (hasRiskAssesment())
			{
				String Actual = getRiskAssesment();
				if (Actual.toLowerCase().replaceAll("\\s", "").contains(("D&B Financial Strength         "+RiskAssesment_FinancialStrength).toLowerCase().replaceAll("\\s", "")))
				{
					return true;
				}else{
					return false;
				}
			}else{
				return false;
			}
		}
		
		public boolean verifyRiskAssessment_RiskIndicator(String RiskAssesment_RiskIndicator)
		{
			if (hasRiskAssesment())
			{
				String Actual = getRiskAssesment();
				if (Actual.toLowerCase().replaceAll("\\s", "").contains(("D&B Risk Indicator (1-4)       "+RiskAssesment_RiskIndicator).toLowerCase().replaceAll("\\s", "")))
				{
					return true;
				}else{
					return false;
				}
			}else{
				return false;
			}
		}
		
		public boolean verifyRiskAssessment_CreditLimit(String RiskAssesment_CreditLimit)
		{
			if (hasRiskAssesment())
			{
				
				String riskAssessmentCreditLimit = formatCreditLimit(RiskAssesment_CreditLimit)+"EUR";
				String Actual = getRiskAssesment();
				if (Actual.toLowerCase().replaceAll("\\s", "").contains(("D&B Credit Limit               "+riskAssessmentCreditLimit).toLowerCase().replaceAll("\\s", "")))
				{
					return true;
				}else if(RiskAssesment_CreditLimit.equalsIgnoreCase("") && Actual.contains("Not determined.")){
					return true;
				
			}else{
					return false;
				}
			}else{
				return false;
			}
		}
		
				
		public boolean verifyRiskAssessment_FailureScore(String RiskAssesment_FailureScore)
		{
			if (hasRiskAssesment())
			{
				String Actual = getRiskAssesment();
				if (Actual.toLowerCase().replaceAll("\\s", "").contains(("D&B Failure Score              "+RiskAssesment_FailureScore).toLowerCase().replaceAll("\\s", "")))
				{
					return true;
				}else if(RiskAssesment_FailureScore.equalsIgnoreCase("") && Actual.contains("Not determined.")){
					
					return true;
				
			}else{
					return false;
				}
			}else{
				return false;
			}
		}
		
				
		// To obtain value of each element by extracting from the report
		
		private String getIdentificationSummary()
		{
			return extractBetween("Identification & Summary", "D&B Risk Assessment", getReport());
		}
		
		private String getRiskAssesment()
		{
			return extractBetween("D&B Risk Assessment", "D&B Rating & Score", getReport());
		}
		
		private String getCreditLimit(){
			return extractBetween("D&B Failure Score", "Score Override", getReport());
		}
				
		private String getCreditOpinion(){
			String extractCreditOpinionSec;
			String strStart = "OTHERWISE STATED ***";
			extractCreditOpinionSec = getReport().substring(getReport().indexOf(strStart)+strStart.length(), getReport().indexOf(strStart)+500);
			return extractCreditOpinionSec;
			//return extractBetween("OTHERWISE STATED ***","of",getReport());
		}
		
		// To Obtain the report as string
		
		private String getReport()
		{
			String textReport;
			textReport = Report.getText().toString().trim();
			return textReport;
		}
		
		// To extract Max high credit in case of "0"
		private String extractMaxCredit(){
			String extractedMaxCredit;
			String strStart = "MAXIMUM HIGH CREDIT:";
			extractedMaxCredit = getCreditOpinion().substring(getCreditOpinion().indexOf(strStart)+strStart.length(), getCreditOpinion().indexOf(strStart)+40);
			return extractedMaxCredit;
			}
		
		
		// To Extract a String between two strings
		
		private String extractBetween(String str1, String str2, String mainString)
		{
			String ExtractedValue;
			ExtractedValue = mainString.substring(mainString.indexOf(str1) + str1.length(), mainString.lastIndexOf(str2));
			return ExtractedValue;
		}
		
		//To check the Report name
		
		public boolean isReportName(String reportName){
			boolean flag = false;
			if(reportNameTxt.isPresent() && reportNameTxt.getText().toString().trim().contains(reportName)){
				flag = true;
					}
				
			return flag;
		}
		
		public boolean isReportTableAvailable(){
			while(!reportTbl.isPresent()){
				return false;
			}
			return true;
		}
		
		//To 
		
		public void clickCompanySearch(){
			companySearchLink.click();
			UIHelper.waitForPageToLoad(getDriver());
		}
		
		public void clickOnBackButton() {
			getDriver().navigate().back();
			UIHelper.waitForPageToLoad(getDriver());
			
		}
		// To Verify the Rating in the Credit Opinion Section
		public boolean verifyRating(String CreditOpinion_Rating)
		{
			if (hasCreditOpinion())
			{
				String Actual = getCreditOpinion();
				if (Actual.toLowerCase().replaceAll("\\s", "").contains(("D&B RATING:              "+CreditOpinion_Rating).toLowerCase().replaceAll("\\s", "")))
				{
					return true;
				}else{
					return false;
				}
			}else{
				return false;
			}
		}
		// To Verify the FailureScore in the Credit Opinion Section
		public boolean verifyFailureScore(String FailureScore)
		{
			if (hasCreditOpinion())
			{
				String Actual = getCreditOpinion();
				if (Actual.toLowerCase().replaceAll("\\s", "").contains(("D&B SCORE:               "+FailureScore).toLowerCase().replaceAll("\\s", "")))
				{
					return true;
				}else if((FailureScore.equalsIgnoreCase("0") || FailureScore.equalsIgnoreCase("") ) && !(extractBetween("D&B RATING:", "HIGH CREDIT:", Actual).contains("D&B SCORE"))){
					
					return true;
				
			}else{
					return false;
				}
			}else{
				return false;
			}
		}
		
		// To Verify the High Credit Limit in the Credit Opinion Section
				public boolean verifyHighCreditLimit(String creditLimit)
				{
					if (hasCreditOpinion())
					{
						String Actual = getHighCredit();
						String creditOpinion = getCreditOpinion();
						Actual = Actual.replaceAll("\\s", "").replaceAll("-","").replace(".","").replace(",","");
						if(Actual.contains(creditLimit))
						{
							return true;
						}else if(creditLimit.equalsIgnoreCase("0") && extractBetween("HIGH CREDIT:", "MAXIMUM HIGH CREDIT:", creditOpinion).contains("Non reported")){
							return true;
						}else{
							return false;
						}
					}else{
						return false;
					}
				}
				// To Verify the Maximum High Credit Limit in the Credit Opinion Section
				public boolean verifyMaxCreditLimit(String maxCreditLimit)
				{
					if (hasCreditOpinion())
					{
						if(!maxCreditLimit.equalsIgnoreCase("0") && extractMaxCredit().trim().equalsIgnoreCase("Non reported")){
							return false;
						}
						String Actual = getMaxCreditLimit(maxCreditLimit);
						if(!Actual.equalsIgnoreCase("Non")){
							Actual = Actual.replaceAll("\\s", "").replaceAll("-","").replace(".","").replace(",","");
						}
						if(Actual.contains(maxCreditLimit))
						{
							return true;
						}
						else if(maxCreditLimit.equalsIgnoreCase("0") && extractMaxCredit().trim().equalsIgnoreCase("Non reported")){
							return true;
						}
							else{
								return false;
							}
						
					}else{
						return false;
					}
				}
				
				public String getHighCredit(){
					String highCredit = getCreditOpinion();
					String highCreditValue = extractBetween("HIGH CREDIT:","MAXIMUM HIGH CREDIT:",highCredit);
					return highCreditValue;
				}
				
				public String getMaxCreditLimit(String maxCredit){
					String maxCreditLimit = getCreditOpinion();
					String maxCreditValue;
					if(maxCredit.equalsIgnoreCase("0")){
						 maxCreditValue = extractBetween("MAXIMUM HIGH CREDIT:","reported",maxCreditLimit);
					}else{
						 maxCreditValue = extractBetween("MAXIMUM HIGH CREDIT:",",",maxCreditLimit);
					}
					System.out.println(maxCreditValue.replaceAll("\\s","")+"Apple");
					return maxCreditValue.replaceAll("\\s","");
				}
				
				//Function to format credit limit
				
				public static String formatCreditLimit(String creditlimit){
					String strLast,strFirst,temp;
					temp="";
					strFirst="";
					strLast ="";
					if(creditlimit.length()<=3){
						creditlimit = creditlimit+".00";
						return creditlimit;
								}else{
									int value = creditlimit.length();
									for(int count=1;count<=value;count++){
										if (creditlimit.length()>=3){
											strLast = creditlimit.substring(creditlimit.length()-3);
											strFirst = creditlimit.substring(0,creditlimit.length()-3);
										}
										if(strFirst.length()>3){
											if(count==1){
												temp = ","+strLast+temp;
												creditlimit = strFirst;
												}
											else{
												temp = ","+strLast+temp;
												creditlimit = strFirst;
												}
										}else if(strFirst.length()<=3){
											if(count==1){
												strFirst = strFirst+","+strLast;
												creditlimit = strFirst;
											}else{
												strFirst = strFirst+","+strLast+temp;
												creditlimit = strFirst;
												}
											return strFirst+".00";
											}
										}
									}
					
					return strFirst;
					
								}
		
}
