/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.dnb.automation.dnbi.pages;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;

import com.dnb.automation.utils.UIHelper;
import com.google.common.base.Predicate;

/**********************************************************************************************
 * CompaniesPage.java - This class contains method for 1. Create Folder in
 * Companies Tab 2. Delete Folder in Companies Tab 3. Clear Folder Contents in
 * Companies Tab 4. Check Folder is available or not in Companies Tab
 * 
 * @author Duvvuru Naveen
 * @version 1.0
 ***********************************************************************************************/

public class CompaniesPage extends PageObject {
	
	ECFPage ecfPage;
	private WebElement Foldername;
	@FindBy(xpath = "//*[@id='header_mainApp']//*[contains(text(),'Companies')]")
    private WebElementFacade compHref;

	@FindBy(xpath = "//div[@class='table_folder']/input[@value='Copy To Folder']")
    private WebElementFacade btnCopyToFolder;

	
	
	@FindBy(xpath = "//form[@id='folderOperations']//div[@class='table_folder']//input[@value='Delete']")
    private WebElementFacade deleteBttn;
	
	@FindBy(xpath = "//form[@id='confirmDeleteForm']//div[@class='modal_buttons']//input[@value='Delete']")
    private WebElementFacade btnDeletCreditFile;

	@FindBy(xpath = "//body[@class='iframe_modal']/form[@id='addToFolderForm']//label[contains(text(),'Available Folders')]")
    private WebElementFacade labelAvailableFolders;
	
	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
    private WebElementFacade iFrame;
	
	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
	public WebElementFacade iFrameEle;

	@FindBy(xpath = "//div[@id='seld_cus']//select[@class='CompCustomize_Select' and @name='selectedFields']")
    private WebElementFacade selSelectFieldsToDisplay;
	
	@FindBy(xpath = "//div[@id='sel_cus']/a[starts-with(@href,'javascript:removeSelectedOptions')]/img")
    private WebElementFacade btnRemoveSelectedFieldsToDisplay;

	@FindBy(xpath = "//div[@id='sel_cus']/a[starts-with(@href,'javascript:copySelectedOptions')]/img")
    private WebElementFacade btnAddSelectedFieldsToDisplay;

	@FindBy(xpath = "//div[@id='main']//div[@class='floatLeft viewMargin']//select[@id='ALL_COMPANIES_FILTER']")
    private WebElementFacade selAllCompViewFilter;
	
	@FindBy(xpath = "//table[@id='allCompaniesMainTable']/tbody/tr/td/b[contains(text(),'No Companies were found')]")
    private WebElementFacade NoCompInAllCompFold;
	
	@FindBy(xpath = "//div[@id='main']//div[@class='floatLeft viewMargin']//input[@value='Filter']")
    private WebElementFacade btnFilter;	
	
	@FindBy(xpath = "//select[@id='entityFilter']")
    private WebElementFacade selCreditFilesView;		
	
	@FindBy(xpath = "//select[@id='subFilter']")
    private WebElementFacade selCreditFilesViewSubFilt;		
	
	@FindBy(xpath = "//input[@id='MODIFICATION_DATE']")
    private WebElementFacade creditFilesViewDate;		
	
	@FindBy(xpath = "//input[@type='button' and @value='Apply']")
    private WebElementFacade btnApplyAllCreditFilesFilter;		
	
	@FindBy(xpath = "//form[@name='additionalForm']/ul/li/strong[2]")
    private WebElementFacade totCntRecordDisp;		

	@FindBy(xpath = "//form[@name='additionalForm']/ul/li/strong[1]")
    private WebElementFacade totRecordDisp;		

	@FindBy(xpath = "//form[@name='additionalForm']/ul/li/a[contains(text(),'Next')]")
    private WebElementFacade linkNext;		
	
	@FindBy(xpath = "//form[@name='additionalForm']/ul/li/a[contains(text(),'Previous')]")
    private WebElementFacade linkPrevious;		

	@FindBy(xpath = "//form[@name='additionalForm']/ul/li/a[contains(text(),'Last')]")
    private WebElementFacade linkLast;		
	
	@FindBy(xpath = "//form[@name='additionalForm']/ul/li/a[contains(text(),'First')]")
    private WebElementFacade linkFirst;		

	@FindBy(xpath = "//div[@class='modal_buttons']/input[@value='Update List']")
    private WebElementFacade btnUpdateList;

	@FindBy(xpath = "//div[@id='vars_cus']/select[@id='pool']")
    private WebElementFacade selAvailableFields;
	
	@FindBy(xpath = "//table[@id='allCompaniesMainTable']/thead//tr//th/a")
    private List<WebElement> allCompaniesMainTableHeader;
	
	@FindBy(xpath = "//tbody[@id='dataFieldAndTable']/tr")
    private List<WebElement> tblDataFieldAndTableRows;

	@FindBy(xpath = "//tbody[@id='dataFieldORTable']/tr")
    private List<WebElement> tblDataFieldORTableRows;

	@FindBy(xpath = "//tbody[@id='dataFieldNotTable']/tr")
    private List<WebElement> tblDataFieldNotTableRows;

	@FindBy(xpath = "//table[@class='results full_company']/thead/tr[1]/th")
    private List<WebElement> companyResultsTableHeader;

	@FindBy(xpath = "//table[@class='results full_company']/tbody/tr")
    private List<WebElement> companyResultsTableRows;

	@FindBy(xpath = "//div[@class='modal_content']/iframe[@name='__modal_iframe_target']")
    private WebElementFacade selectFolderiFrame;

	@FindBy(xpath = "//div[@class='modal_content']/iframe[@name='__modal_iframe_target']")
    private WebElementFacade deletCompaniesConfirmFrame;

	@FindBy(xpath = "//body[@class='iframe_modal']/form[@id='addToFolderForm']//select[@id='to_folder_id']")
    private WebElementFacade selectAvailableFolders;
	
	@FindBy(xpath = "//body[@class='iframe_modal']/form[@id='addToFolderForm']//a[normalize-space(text())='Create a new folder']")
    private WebElementFacade lnkCreateNewFolder;
	
	@FindBy(xpath = "//div[@id='createFolder']//input[@id='NewFolderName']")
    private WebElementFacade lblFolderName;
	
	@FindBy(xpath = "//*[contains(@class,'iframe')]//*[@id='createFolder']//*[contains(@id,'NewFolderName') or contains(@name,'NewFolderName')]")
	private WebElementFacade newFolderName;
	
	@FindBy(xpath = "//*[contains(@class,'iframe')]//*[@id='createFolder']//*[contains(@id,'user_profile') or contains(@name,'user_profile')]")
	private WebElementFacade newFolderNameAlertProfile;
	
	@FindBy(xpath = "//*[@class='iframe_modal']//*[@class='modal_buttons']/input[@type='button' and @value='Submit']")
	private WebElementFacade searchResultsnapShotAddFolderSubmit;
	
	@FindBy(xpath = "//body[@class='iframe_modal']//div[@class='modal_buttons']//input[@id='submit_ecf']")
    private WebElementFacade btnSubmitSelectFolder;

	@FindBy(xpath = "//div[@class='modal_buttons']/input[3]")
    private WebElementFacade btnRemoveCreditFiles;

	@FindBy(xpath = "//div[@id='confirmOperation']/div/h3")
    private WebElementFacade labelCopyConfirmationMsg;
	
	@FindBy(xpath = "//*[@id='confirmOperationDynamic']/div/h3")
    private WebElementFacade labeldeleteConfirmationMsg;
	
	@FindBy(xpath = "//div[@id='confirmOperationDynamic']//h3")
	private WebElementFacade labelMoveConfirmationMsg;
	
	@FindBy(xpath = "//div[@id='confirmOperationDynamic']/div/h3")
    private WebElementFacade labelRemoveConfirmationMsg;
	
	@FindBy(xpath = "//div[@id='confirmOperation']/div[@class='alert_box']/h3")
	 private WebElementFacade labeladdConfirmationMsg;
	
	@FindBy(xpath = "//div[@class='CompAllCredit_Infoborder']//h3[contains(.,'The selected Companies are succesfully deleted')]")
	private WebElementFacade labelDeleteConfirmationMsg;
	
	@FindBy(xpath = "//div[@id='confirmOperation']/div/h3")
	private WebElementFacade labelSharedFolderConfirmationMsg;
	@FindBy(xpath = "//div[@id='confirmOperation']/div/h3")
    private WebElementFacade labelFolderShareConfirmationMsg;

	//@FindBy(xpath = "//div[@id='pageHead']//a[contains(text(),'Customize')]")
	@FindBy(xpath = "//div[@id='pageHead']//ul[@id='pp_side_icon']//li//a//span[contains(.,'Customize')]")
    private WebElementFacade linkCustomizeInCompaniesFolder;
	
	@FindBy(xpath = "//div[@id='pageHead']//span[text()='Customize']/..")
    private WebElementFacade linkCustomize;
	
//	@FindBy(xpath = "//div[@id='showdiv']/a")
//    private WebElementFacade showSharingOptions;

	@FindBy(xpath = "//table[@id='Role_alerts']")
    private WebElementFacade RoleAndUsertable;
		
	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[@id='tabs1']//*[contains(text(),'Folders')]")
    private WebElementFacade companiespagefolderTab;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@type='button' and contains(@value,'New Folder')]")
    private WebElementFacade companiespageCreateFolder;
    
    @FindBy(xpath="//*[@id='tab1']/div/form/table/tbody/tr/td[2]/a")
    private List<WebElementFacade> folderList;

    @FindBy(xpath = "//form[@action='showAllFolderSummary']/table/tbody//tr//td/a[contains(text(),'All Companies')]")
    private WebElementFacade AllCompaniesFolder;

    @FindBy(xpath = "//form[@action='showAllFolderSummary']/table/tbody//tr//td/a[contains(text(),'All Credit Files')]")
    private WebElementFacade AllCreditFilesFolder;

    @FindBy(xpath = "//form[@action='showAllFolderSummary']/table/tbody//tr//td/a[contains(text(),'My Companies')]")
    private WebElementFacade MyCompaniesFolder;

    @FindBy(xpath = "//form[@action='showAllFolderSummary']/table/tbody//tr//td/a[contains(text(),'Accounts')]")
    private WebElementFacade AccountsFolder;

    @FindBy(xpath = "//form[@action='showAllFolderSummary']/table/tbody//tr//td/a[contains(text(),'Applications')]")
    private WebElementFacade ApplicationsFolder;

    @FindBy(xpath = "//form[@action='showAllFolderSummary']/table/tbody//tr//td/a[contains(text(),'Snapshots')]")
    private WebElementFacade SnapshotsFolder;

    @FindBy(xpath = "//form[@action='showAllFolderSummary']/table/tbody//tr//td/a[contains(text(),'Investigations')]")
    private WebElementFacade InvestigationsFolder;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='folderOptionsForm']//*[@id='alertprofile']//*[@class='TxtboxNormal']")
    private WebElementFacade companiesCreateFolderTextbox;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='folderOptionsForm']//*[@id='smart_folder_submit' and @value='Submit']")
    private WebElementFacade companiesCreateFolderandSubmit;

    @FindBy(xpath = "//div[@class='modal_buttons']/input[@name='Submit']")
    private WebElementFacade btnSubmitCreateNewFolder;
  
    @FindBy(xpath = "//input[@value='Delete Selected']")
    private WebElementFacade btnDeleteSelected;
  
    @FindBy(xpath = "//div[@id='pageHead']//a/span[text()='Export']")
    private WebElementFacade linkExcelExport;
  
    @FindBy(xpath = "//div[@id='confirmOperation']//h3")
    private WebElementFacade companiesCreateFolderSuccMsg;

    @FindBy(xpath = "//table[@id='allCompaniesMainTable']/tbody/tr")
    private WebElementFacade creditFilesInAllCompaniesFolder;
  
    @FindBy(xpath = "//table[@class='results full_company']/tbody/tr[1]/td[1]/input")
    private WebElementFacade creditFilesInAllCreditFilesFolder;

    @FindBy(xpath = "//th[@class='lastChild']/input[@name='checkAll']")
    private WebElementFacade checkAllCreditFilesCheckbox;

    @FindBy(xpath = "//table[@class='results full_company']")
    private WebElementFacade creditFilesInMyCompaniesFolder;

    @FindBy(xpath = "//table[@class='results full_company']")
    private WebElementFacade creditFileInAccountsFolder;

    @FindBy(xpath = "//table[@class='results full_company']/tbody/tr")
    private List<WebElement> creditFilesInAccountsFolder;
    
    @FindBy(xpath="//form[@action='showAllFolderSummary']//table[@class='results full']//tbody//tr//td[contains(.,'Investigation')]/a")
    private WebElementFacade investigationFolder;
    
    @FindBy(xpath="//*[@id='additionalHeaderForm']/table/tbody/tr")
    private List<WebElementFacade> investigationFolderList;
    
    @FindBy(xpath = "//table[@class='results full_company']/tbody/tr/td[3]")
    private List<WebElement> creditFilesCompNameInAccountsFolder;    

    @FindBy(xpath = "//table[@class='results full_company']")
    private WebElementFacade creditFilesInApplicationFolder;

    @FindBy(xpath = "//table[@class='results full_company']")
    private WebElementFacade creditFilesInSnapshotsFolder;
    
    @FindBy(xpath = "//*[@id='loading']/span")
    private WebElementFacade loadingImageEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='viewItems']")
    private WebElementFacade viewItemsEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//a")
    private WebElementFacade folderTabTableEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//a")
    private List<WebElement> folderTabTableListEle;
    
    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//a")
    private List<WebElement> folderToClick;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//thead//*[@type='checkbox']")
    private WebElementFacade deleteChkBoxEle;

    @FindBy(xpath = "//*[@id='folderOperations']//*[@value='Delete']")
    private WebElementFacade deleteBTNEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]")
    private WebElementFacade folderTabTableWithoutHREFEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//tbody//tr[1]")
    private WebElementFacade accountResultsFirstRowEle;

    @FindBy(xpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//tbody//tr[1]//td[3]//b")
    private WebElementFacade getDatainTDForKeysEle;

    private String xpathDelete = "//*[@class='outerDiv']//*[@class='floatLeft']/form/table//a[contains(text(),'Auto')]//ancestor::tr//a[contains(text(),'Delete')]";

    @FindBy(xpath = "//div[@id='main']//div[@id='alertprofile']/div[@class='comp_alertprofile_margin']/input[@name='folderName']")
    private WebElementFacade folderNameEle;

    @FindBy(xpath = "//form[@id='folderOptionsForm']//input[@id='smart_folder_submit']")
    private WebElementFacade folderSubmitEle;

    @FindBy(xpath = "//div[@id='main']//form[@id='alertsListForm']//select[@id='FILTER_ALERT']")
    private WebElementFacade filterAlertEle;

    @FindBy(xpath = "//div[@id='page_title']/h2[contains(text(),'Edit Folder')]")
    private WebElementFacade lblEditFolder;
  
    @FindBy(xpath = "//select[@id='user_profile_id']")
    private WebElementFacade selAlertProfile;
  
    @FindBy(xpath = "//div[@id='alertprofile']/div//input[@name='folderName']")
    private WebElementFacade txtFolderName;
   
    @FindBy(xpath = "//div[@id='showdiv']/a[contains(text(),'Show Sharing Options')]")
    private WebElementFacade showSharingOptions;
    @FindBy(xpath = "//*[@id='main']//*[@id='entity_category']")
	private WebElementFacade selectFilterCategoryEle;
    private String loadingImageEleXpath = "//*[@id='loading']/span";

    private String folderTabTableXpath = "//*[@class='outerDiv']//*[contains(@class,'results')]//a";
    private String folderTabTableXpathWithoutHREF = "//*[@class='outerDiv']//*[contains(@class,'results')]";

    public String getFolderTabTableXpathWithoutHREF() {
        return folderTabTableXpathWithoutHREF;
    }

    ArrayList<String> viewItemsList = new ArrayList<String>();

    @FindBy(xpath = "//div[@id='main']//div[@class='compHome_newFolder']/input[@value='Create New Folder' and @type='button']")
    private WebElementFacade createNewFolderButton;

    @FindBy(xpath = "//div[@id='header_mainApp']//ul[@id='primaryNav']//a[@href='/dnbi/dunsright/showNewsAndAlerts']")
    private WebElementFacade monitoringTab;

    @FindBy(xpath = "//div[@id='main']//div[@class='floatLeft']//select[@id='viewItems']")
    private WebElementFacade viewItems;

    // *Creating a template for an application and for an account
    @FindBy(xpath = "//*[@id='primaryNav']//li//a[contains(.,'Companies')]")
    private WebElementFacade companiesTab;

    @FindBy(xpath = "//a[contains(text(),'Dashboard')]")
    private WebElementFacade dashboardTab;

    @FindBy(xpath = "//*[@id='page_title_links']/h2")
    private WebElementFacade dashboardPageTitleEle;

    @FindBy(xpath = ".//*[@class='results full']//tr[2]//a[contains(.,'All Credit Files')]")
    private WebElementFacade allCreditFiles;

    @FindBy(xpath = ".//*[@class='disInline']//*[@id='entityFilter']")
    private WebElementFacade viewDropDown;

    @FindBy(xpath = ".//*[@class='alert_box include_filterBG']//*[@value='Apply']")
    private WebElementFacade applyButton;

    @FindBy(xpath = ".//*[@class='results full_company']//tbody//tr[1]//*[@type='checkbox']")
    private WebElementFacade firstEleCheckbox;

    @FindBy(xpath = ".//*[@id='main']//*[@value='Delete']")
    private WebElementFacade deleteBtn;

    @FindBy(xpath = ".//*[@class='CompAllCredit_Infoborder']//*[@class='info']")
    private WebElementFacade deleteSuccessfulMsg;

    @FindBy(xpath = ".//*[@id='main']/div[6]/table/tbody")
    private WebElementFacade creditFilesTable;

    @FindBy(xpath = ".//*[@id='page_title_links']/h2")
    private WebElementFacade creditFilesPageTitleEle;

    @FindBy(xpath = "//select[@id='viewItems']")
    private WebElementFacade selViewItems;
  
    @FindBy(xpath = "//div[@id='main']/div[@id='tabs1']/a[contains(text(),'Filters')]")
    private WebElementFacade tabFilters;
  
    @FindBy(xpath = "//div[@id='main']/div[@id='tabs1']/a[normalize-space(text())='Filter Exports']")
    private WebElementFacade tabFiltersExports;
  
    @FindBy(xpath = "//div[@id='main']//div[@id='tab2']//input[@value='Create New Filter']")
    private WebElementFacade btnCreateNewFilter;
  
    @FindBy(xpath = "//div[@id='tab3']//form[@name='additionalHeaderForm']/table[@class='results full']/tbody")
    private WebElementFacade tblExcelExportJobs;
  
    @FindBy(xpath = "//div[@id='tab3']//form[@name='additionalHeaderForm']/table[@class='results full']/tbody/tr[1]/td[1]/a")
    private WebElementFacade linkExcelExportJobStatus;

    @FindBy(xpath = "//div[@id='tab3']//form[@name='additionalHeaderForm']/table[@class='results full']/tbody/tr[1]/td[5]/a")
    private WebElementFacade linkDownloadExcelExportJob;

    @FindBy(xpath = "//body[@class='iframe_modal']/div[@id='CallcreditSearch']//input[contains(@value,'Submit')]")
    private WebElementFacade btnCreateNewFilterSubmit;
  
    @FindBy(xpath = "//form[@id='saveFilterForm']//div[@id='page_title']//h2[text()='Create Filter']")
    private WebElementFacade labelCreateFilter;
  
    @FindBy(xpath = "//div[@class='clear filt_bottomPad mar_left5px']//select[@id='entity_category']")
    private WebElementFacade selFilterEntityType;
  
    @FindBy(xpath = "//select[@id='data_category']")
    private WebElementFacade selFilterDataCategory;
  
    @FindBy(xpath = "//select[@id='data_fields']")
    private WebElementFacade selDataFields;
  
    @FindBy(xpath = "//img[@id='addDataFieldsAnd']")
    private WebElementFacade btnAddDataFieldToAndCondition;
    
    @FindBy(xpath = "//img[@id='removeDataFieldsAnd']")
    private WebElementFacade btnRemoveDataFieldFromAndCondition;

    @FindBy(xpath = "//img[@id='addDataFieldsOR']")
    private WebElementFacade btnAddDataFieldToORCondition;
    
    @FindBy(xpath = "//img[@id='removeDataFieldsOR']")
    private WebElementFacade btnRemoveDataFieldFromORCondition;

    @FindBy(xpath = "//img[@id='addDataFieldsNOT']")
    private WebElementFacade btnAddDataFieldToNotCondition;
    
    @FindBy(xpath = "//img[@id='removeDataFieldsNOT']")
    private WebElementFacade btnRemoveDataFieldFromNotCondition;
 
    @FindBy(xpath = "//input[@id='filter_name']")
    private WebElementFacade txtFilterName;
  
    @FindBy(xpath = "//input[@id='exp_builder_filterName']")
    private WebElementFacade txtAdvFilterName;

    @FindBy(xpath = "//input[@id='form_submit']")
    private WebElementFacade btnFilterSave;
  
    @FindBy(xpath = "//input[@class='btn btnPrimary' and @value='Save']")
    private WebElementFacade btnAdvFilterSave;
  
    @FindBy(xpath = "//div[@id='page_title']/h2")
    private WebElementFacade labelPageTitle;
  
    @FindBy(xpath = "//select[@id='pool']")
    private WebElementFacade selVariable;
  
    @FindBy(xpath = "//div[@class='var_container']//a[text()='Add Variable']")
    private WebElementFacade linkAddVariable;
  
    @FindBy(xpath = "//div[@class='opera_container']//a[contains(text(),'Add Operator')]")
    private WebElementFacade linkAddOperator;

    @FindBy(xpath = "//div[@class='modal_buttons']/input[@id='modal_filt_variableBtn' and @value='Yes']")
    private WebElementFacade btnSaveAdvFilter;

    @FindBy(xpath = "//div[@id='page_title']/h2[text()='Edit Filter Expression']")
    private WebElementFacade pageAdvEditFilter;
  
    @FindBy(xpath = "//div[@id='page_title_links']/h2[text()='Edit Filter']")
    private WebElementFacade pageEditFilter;

    @FindBy(xpath = "//div[@class='modal_title']/h3[text()='Delete Filter']")
    private WebElementFacade deleteFilterWindow;
  
    @FindBy(xpath = "//textarea[@id='expressionBox']")
    private WebElementFacade filterExpressionBox;
    
    @FindBy(xpath = "//select[@id='varOperatorValue']")
    private WebElementFacade selVarOperatorValue;

    @FindBy(xpath = "//div[@class='modal_title']/h3[text()='Save Advanced Filter']")
    private WebElementFacade saveAdvFilterPopUp;

    @FindBy(xpath = "//div[@class='modal_title']/h3[text()='Save Filter']")
    private WebElementFacade saveFilterPopUp;

    @FindBy(xpath = "//input[@value='Advanced Filter Builder']")
    private WebElementFacade btnAdvancedFilterBuilder;
    
    @FindBy(xpath = "//*[contains(@class,'clear filt_bottomPad mar_left5px')]//input[@value='Pre-Count Filter Results']")
    private WebElementFacade btnPreCountFilterResults;

    @FindBy(xpath = "//input[@id='preCountResultBtn']")
    private WebElementFacade btnOkOfPreCountFilterResults;
  
    @FindBy(xpath = "//div[@class='floatRight filt_btnWrapperTopPadding']//input[@value='Cancel']")
    private WebElementFacade btnCancelEditFilter;
    
    @FindBy(xpath = "//div[@class='Amodal_buttons']/input[@value='Yes']")
    private WebElementFacade btnYesDeleteFilter;  
  
    @FindBy(xpath = "//div[@id='widget_container1']")
    private WebElementFacade lblPreCountFilterResults;
  
    @FindBy(xpath = "//div[@class='modal_title']/h3[text()='Pre-Count Filter Results']")
    private WebElementFacade windPreCountFilterResults;
  
    @FindBy(xpath = "//form[@name='additionalHeaderForm']")
    private WebElementFacade formFilterList;
    
    @FindBy(xpath = "//form[@id='folderOperations']//input[@value='Move To Folder']")
    private WebElementFacade moveToFolder;
    
   // -----
    @FindBy(xpath = "//div[@id='main']//input[@value='Add to Folder']")
    private WebElementFacade searchResultAddToFolder;
    
    @FindBy(xpath = "//div[@id='main']//table[@class='results full']//tr/td[1]/input[@type='checkbox']")
    private WebElementFacade searchResultcheckbox;
    
    
    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='search_box']//*[@id='quickSearchFld']")
    private WebElementFacade searchCompBox;

    @FindBy(xpath = "//form[@id='ruleForm']//textarea[@id='expressionBox']")
    private WebElementFacade textareaexp;
    private String creditFilesTableXpath = ".//*[@id='main']/div[6]/table/tbody";
    
    private String deletemsg="//div[@class='CompAllCredit_Infoborder']//h3[contains(.,'The selected Companies are succesfully deleted')]";
    private String sharedFolder= "//div[@id='confirmOperation']/div/h3";
    
    @FindBy(xpath = "//*[@id='page_title']/h2[contains(text(),'International Request')]")
    private WebElementFacade internationalRequest;
    
    @FindBy(xpath ="//div[@class='clear filt_bottomPad mar_left5px']//input[@id='preCountBtn']")
    private WebElementFacade preCountFilterBtn;
    
    @FindBy(xpath ="//*[@id='filterExpressionForm']//input[@value='Pre-Count Filter Results']")
    private WebElementFacade advPreCountFilterResults;
    
    
    @FindBy(xpath ="//form[@action='showAllFolderSummary']//table[@class='results full']//tbody//tr//td[contains(.,'My Companies')]/a")
    private WebElementFacade myCompaniesLink;
    
    @FindBy(xpath ="//form[@action='showAllFolderSummary']//table[@class='results full']//tbody//tr//td[contains(.,'All Credit Files')]/a")
    private WebElementFacade allCreditFilesLink;
    
  
    @FindBy(xpath ="//*[@id='filterAtoZ']/a[4]")
    private WebElementFacade clickDlink;
    
    @FindBy(xpath ="//*[@id='filterAtoZ']/a[27]")
    private WebElementFacade clickHashlink;
    
    @FindBy(xpath ="//*[@id='filterAtoZ']/a[28]")
    private WebElementFacade clickAlllink;
    
    private static int prefiltercount;
    private static int advprefiltercount;
    private String addedProductName;

    private String tableResultsTxt;
    
    private String ExpectedExpression;
    private static int primeUserCount;
    private static int sharedUserCount;
    private int intTotCntRecordDisp;    
    private int intrecordsInFilter;
//    private int intRecordDisp;
    private int intRecordDispTemp;
    private int intCurrentRecordDisp;
    private boolean NextAvail = false;
    private boolean LastAvail = false;
    private boolean PreviousAvail = false;
    private boolean FirstAvail = false;
    private boolean NextValidation = false;
    private boolean rec20DropDown = false;
    private boolean rec50DropDown = false;
    private String title="//*[@id='page_title_links']/h2";
    
    


    // Delete Folder
    public void recursiveDelete(String xpath) throws Exception {

        try {

            List<WebElement> valuestobedeletedinTable = getDriver()
                    .findElements(By.xpath(xpath));

            Iterator<WebElement> clickDeleteforAll = valuestobedeletedinTable
                    .iterator();

            main: while (clickDeleteforAll.hasNext()) {

                WebElementFacade givenFolderNameEle = find(By.xpath(xpath));

                if (givenFolderNameEle.isPresent()) {

                    try {
                        try {
                            if (viewItemsEle.isPresent()) {

                                viewItemsEle.selectByValue("500");
                            }

                        } catch (Exception e) {

                        }

                        folderTabTableEle.waitUntilPresent();

                        try {
                            if (deleteChkBoxEle.isPresent()) {

                                deleteChkBoxEle.click();
                            }

                        } catch (Exception e) {

                        }

                        try {
                            if (deleteBTNEle.isPresent()) {
                                deleteBTNEle.click();
                                UIHelper.processalert(getDriver());
                            }

                        } catch (Exception e) {

                        }

                        folderTabTableWithoutHREFEle.waitUntilPresent();

                    } catch (StaleElementReferenceException e) {

                    } catch (NoSuchElementException E) {

                    }

                } else {
                    break main;
                }

            }

        } catch (Exception e) {
            // throw e;
        }

    }
    
    public void clickCompaniesFolder(){
    	UIHelper.waitForPageToLoad(getDriver());
    	UIHelper.highlightElement(getDriver(), myCompaniesLink);
    	myCompaniesLink.click();
    }

    // Delete Records in Folder
    public void deleteRecordsInFolder(String folderName) throws Exception {

        try {
        	compHref.waitUntilClickable();
            compHref.click();

            folderTabTableWithoutHREFEle.waitUntilPresent();

            if (folderTabTableEle.isPresent()) {

                if (folderTabTableListEle.size() > 0) {

                    for (WebElement getKys : folderTabTableListEle) {
                        if (StringUtils.containsIgnoreCase(getKys.getText(),
                                folderName)) {

                            getKys.click();

                            break;

                        }
                    }
                }

            }

            folderTabTableWithoutHREFEle.waitUntilPresent();

            // Delete Files

            try {

                recursiveDelete(folderTabTableXpath);

            } catch (Exception e) {

                throw e;

            }

        } catch (Exception e) {

            throw e;
        }

    }

    // Verify Companies Folder is updated or not
    public String getAddedProductFromCompaniesFolder(String keysToTest,
            String folderName){
        try {
        	compHref.waitUntilClickable();
            compHref.click();
            companiespagefolderTab.waitUntilPresent();
            UIHelper.waitForPageToLoad(getDriver());
            companiespagefolderTab.click();
            waitFor(5000).milliseconds();
            try
            {
            if (folderToClick != null) {

                for (WebElement getKys : folderToClick) {
                   if (StringUtils.containsIgnoreCase(getKys.getText(),
                            folderName)) {
                    	waitFor(5000).milliseconds();
                        getKys.click();
                        break;

                    }
                }

            }
            }catch(StaleElementReferenceException e)
            {
            	e.printStackTrace();
            }

            // Wait for PageLoad
            accountResultsFirstRowEle.waitUntilPresent();
            getDatainTDForKeysEle.waitUntilPresent();
            /* if (getDatainTDForKeysEle.isPresent()) {

                addedProductName = getDatainTDForKeysEle.getText();

            }*/

        } catch (Exception e) {
        	e.printStackTrace();
        }
        waitFor(5000).milliseconds();
        return addedProductName;

    }

    // Delete Existing Folder
    public void companiesDeleteExistingFolder(String getFolderName)
            throws InterruptedException {

        try {
        	compHref.waitUntilClickable();
            compHref.click();
            UIHelper.waitForPageToLoad(getDriver());
            companiespagefolderTab.waitUntilPresent();
            companiespagefolderTab.click();
            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                    loadingImageEleXpath);
            waitFor(3000).milliseconds();
            int attempt = 0;
            main: while (attempt < 100) {

                try {

                    List<WebElement> companiespageTable = getDriver()
                            .findElements(By.xpath(xpathDelete));

                    if (companiespageTable.size() == 0) {
                        break main;
                    }

                    Iterator<WebElement> clickDelete = companiespageTable
                            .iterator();

                    if (companiespageTable.size() > 0) {

                        while (clickDelete.hasNext()) {

                            clickDelete.next().click();

                            UIHelper.processalert(getDriver());
                            UIHelper.waitForPageToLoad(getDriver());
                            UIHelper.waitForInvisibilityOfAjaxImgByXpath(
                                    getDriver(), loadingImageEleXpath);
                            waitFor(2000).milliseconds();
                        }

                    }

                    else {

                        break;
                    }

                }

                catch (StaleElementReferenceException E) {

                    attempt++;

                }

                catch (NoSuchElementException E) {

                }

            }

            attempt = attempt + 100;
        } catch (Exception E) {
            // throw E;
        }
    }

    // Create Folder in Companies Tab
    public void companiesCreateFolder(String folderName) throws Exception {

        try {
            UIHelper.waitForPageToLoad(getDriver());
            folderTabTableWithoutHREFEle.waitUntilPresent();

            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                    loadingImageEleXpath);

            if (companiespageCreateFolder.isPresent()) {

                companiespageCreateFolder.click();
                UIHelper.waitForPageToLoad(getDriver());
            }

            companiesCreateFolderTextbox.waitUntilPresent();

            companiesCreateFolderTextbox.click();

            companiesCreateFolderTextbox.type(folderName);

            companiesCreateFolderandSubmit.click();

            folderTabTableWithoutHREFEle.waitUntilPresent();

            UIHelper.waitForPageToLoad(getDriver());

            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                    loadingImageEleXpath);

        } catch (Exception E) {

            throw E;
        }

    }

    // Delete Existing Folder
    public int deleteExistingFolder(String foldertobeDelete) {
        int count = 0;

        try {

            viewItems.waitUntilPresent();
            viewItems.selectByValue("500");

            createNewFolderButton.waitUntilPresent();

            String part1 = "//*[@id='main']//*[@class='floatLeft']/form/table[@class='results full']/tbody/tr[";
            String part2 = "]/td[2]/a";
            int i = 1;

            WebElementFacade tableResultsFullEle = find(By.xpath(part1 + i
                    + part2));

            while (tableResultsFullEle.isPresent()) {

                String folderName = tableResultsFullEle.getText();

                if (folderName.equalsIgnoreCase(foldertobeDelete)) {

                    String xpath_Delete_col = part1 + i
                            + part2.replace("td[2]/a", "td[6]/a[2]");

                    WebElementFacade tableResultsFullTD6Ele = find(By
                            .xpath(xpath_Delete_col));

                    if (tableResultsFullTD6Ele.isPresent()) {
                        tableResultsFullTD6Ele.click();
                        UIHelper.processalert(getDriver());
                        i--;
                        count++;
                    }

                    viewItems.waitUntilPresent();
                    viewItems.selectByValue("500");
                    viewItems.waitUntilPresent();

                    WebElementFacade tableResultsFullEle2 = find(By.xpath(part1
                            + i + part2));

                    tableResultsFullEle2.waitUntilPresent();

                }

                i++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;

    }

    // Create New Folder
    public void clickCreateNewFolder() {

        createNewFolderButton.waitUntilPresent();
        createNewFolderButton.click();
        folderNameEle.waitUntilPresent();
        folderSubmitEle.waitUntilPresent();

    }

    // Edit Existing Folder
    public void editExistingFolder(String foldertobeEdited) {

        try {
            viewItems.waitUntilPresent();
            viewItems.selectByValue("500");

            String part1 = "//*[@id='main']//*[@class='floatLeft']/form/table[@class='results full']/tbody/tr[";
            String part2 = "]/td[2]/a";
            int i = 1;

            WebElementFacade tableResultsFullEle = find(By.xpath(part1 + i
                    + part2));

            while (tableResultsFullEle.isPresent()) {

                String folderName = tableResultsFullEle.getText();

                if (folderName.equalsIgnoreCase(foldertobeEdited)) {
                    String xpath_Edit_col = part1 + i
                            + part2.replace("td[2]/a", "td[6]/a[1]");

                    WebElementFacade tableResultsFullTD6Ele = find(By
                            .xpath(xpath_Edit_col));

                    if (tableResultsFullTD6Ele.isPresent()) {
                        tableResultsFullTD6Ele.click();
                        folderNameEle.waitUntilPresent();
                        break;
                    }

                }

                i++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void gotoMonitoringPage() {
    	monitoringTab.waitUntilClickable();
        monitoringTab.click();
        filterAlertEle.waitUntilPresent();
    }

    public void navigateToAllCreditFiles() throws Exception {
        try {
        	companiesTab.waitUntilClickable();
            companiesTab.click();
            UIHelper.waitForPageToLoad(getDriver());
            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                    loadingImageEleXpath);

            allCreditFiles.waitUntilPresent();
            allCreditFiles.click();

            viewDropDown.waitUntilPresent();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getCreditFilesPageTitle() {
    	creditFilesPageTitleEle.waitUntilPresent();
        return creditFilesPageTitleEle.getText();
    }

    public void deleteCreditFiles(String viewBy) {
        try {
        	viewDropDown.waitUntilPresent();
        	viewDropDown.selectByVisibleText(viewBy);

            UIHelper.waitForPageToLoad(getDriver());
            applyButton.waitUntilPresent();
            applyButton.click();
            UIHelper.waitForPageToLoad(getDriver());

            firstEleCheckbox.waitUntilPresent();

            do {
                firstEleCheckbox.click();
                deleteBtn.click();
                UIHelper.processalert(getDriver());
                UIHelper.waitForPageToLoad(getDriver());
                UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
                        creditFilesTableXpath);

            } while (firstEleCheckbox.isPresent());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String checkDeletedCreditFiles(String viewBy) {
    	viewDropDown.waitUntilPresent();
    	viewDropDown.selectByVisibleText(viewBy);
        UIHelper.waitForPageToLoad(getDriver());
        applyButton.waitUntilPresent();
        applyButton.click();
        UIHelper.waitForPageToLoad(getDriver());
        UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[@class='results full_company']//tbody//tr[1]//*[@type='checkbox']");
        if (!firstEleCheckbox.isPresent()) {
            tableResultsTxt = "Deleted";
        } else {
            tableResultsTxt = "Not Deleted";
        }

        return tableResultsTxt;
    }

//Navigate to Companies Tab    
	public void selectCompaniesTab() {
		
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//*[@id='primaryNav']//li//a[contains(.,'Companies')]");
		System.out.println("*****************&&&&&&&&&&&&&&&&&&&&&&***********");
		((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", companiesTab);

        companiesTab.click();
        UIHelper.waitForPageToLoad(getDriver());
        UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                loadingImageEleXpath);		
	}


	public void selectDashboardTab() {
		dashboardTab.waitUntilClickable();
		dashboardTab.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), title);
        /*dashboardPageTitleEle.waitUntilPresent();
        UIHelper.waitForPageToLoad(getDriver());
        UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImageEleXpath);*/		
		}

	
//Get the status of Create New Folder button availability in companies page	
	public boolean isCreateNewFolderBtnDisplayed() {
		UIHelper.waitForPageToLoad(getDriver());
		String s ="//*[@class='outerDiv']//*[@type='button' and contains(@value,'New Folder')]";
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), s);
		return companiespageCreateFolder.isVisible();
		
	}
	
	public void deleteFolder(String folderName){
		UIHelper.waitForPageToLoad(getDriver());
		 if (viewItemsEle.isPresent()) {

             viewItemsEle.selectByValue("500");
		 }
		for(int i=1;i<folderList.size();i++){
			String getFolderNames=folderList.get(i).getText();
			if(getFolderNames.equalsIgnoreCase(folderName)){
				WebElement deleteFolderEle=getDriver().findElement(By.xpath("//*[@id='tab1']/div/form/table/tbody/tr[contains(.,'"+folderName+"')]/td[6]/a[2]"));
				UIHelper.highlightElement(getDriver(), deleteFolderEle);
				deleteFolderEle.click();
				UIHelper.processalert(getDriver());
				
			}
			
		}
	}

//Get the status of Create New Folder button availability in companies page	
	public void isFolderNotDisplayed(String FolderName) {
		waitFor(5000).milliseconds();
		System.out.println("++++++++++++++++++++++++++++++++");
		int size=getDriver().findElements(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr")).size();
		int count=1;
		for(int i=1;i<=size;i++){
			WebElement element=getDriver().findElement(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr["+i+"]//td[2]"));
			System.out.println("------------element---------element.isDisplayed()-----1------"+element);
		if(element.getText().contains(FolderName)){
			System.out.println("------------isFolderNameDisplayed()---------element.isDisplayed()-----1------");
//			return getDriver().findElement(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr//td/a[contains(text(),'"+FolderName+"')]")).isDisplayed();
			if(count<=3){
			clickOnFolderDeleteBtn(FolderName);
			UIHelper.processalert(getDriver());
			size--;
			count++;
			if(count==5){
				break;
			}
			}
			waitFor(5000).milliseconds();
			System.out.println("------------isFolderNameDisplayed()---------element.isDisplayed()---2--------");
//			return true;
		}
		else{
			
//		return true;
		}
		}
	}

//Click on folder delete button	
	public boolean clickOnFolderDeleteBtn(String FolderName) {
		waitFor(5000).milliseconds();
		if(true){
			System.out.println("trueeeeeeeeeeeeeeeeeeeeeeeeeeeee");
		 getDriver().findElement(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr//td/a[contains(text(),'"+FolderName+"')]/../following-sibling::td//a[contains(text(),'Delete')]")).click();
		 System.out.println("trueeeeeeeeeeeeeeeeeeeeeeeeeeeee22222222222222");
		 waitFor(5000).milliseconds();
		return true;
		}
		return false;
		
	}

//get the alter type for the folder
	public String getAlertTypeForFolder(String FolderName) {
		return getDriver().findElement(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr//td/a[contains(text(),'"+FolderName+"')]/../following-sibling::td[3]")).getText().trim();		
	}
		
//Click on folder Edit button	
	public boolean clickOnFolderEditBtn(String FolderName) {
		waitFor(5000).milliseconds();
		getDriver().findElement(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr//td/a[contains(text(),'"+FolderName+"')]/../following-sibling::td//a[contains(text(),'Edit')]")).click();
		UIHelper.waitForPageToLoad(getDriver());
		return lblEditFolder.isDisplayed();		
	}

//Return the text displayed on edit folder section
	public String isEditFolderSecDisplayed(String FolderName) {
		waitFor(2000).milliseconds();
		if(lblEditFolder.isDisplayed())
		{			
			return txtFolderName.getAttribute("value").trim();
		}
		return null;
	}

//select the profile alert type
	public void updateAlertProfileType(String AlertProfile) {
		selAlertProfile.waitUntilPresent();
		selAlertProfile.selectByVisibleText(AlertProfile);		
	}
			
//Click on Ok button of the delete confirmation
	public boolean clickOkOnDeleteConfirmaiton() {
		UIHelper.processalert(getDriver());
		UIHelper.waitForPageToLoad(getDriver());
		return true;
	}
	
//Get the status of All Companies Folder button availability in companies page	
	public boolean isAllCompaniesFolderAvailable() {
		return AllCompaniesFolder.isPresent();		
	}

//Get the status of All Credit Files Folder button availability in companies page	
	public boolean isAllCreditFilesFolderAvailable() {
		return AllCreditFilesFolder.isPresent();		
	}

//Get the status of My Companies Folder button availability in companies page	
	public boolean isMyCompaniesFolderAvailable() {
		return MyCompaniesFolder.isPresent();		
	}

//Get the status of Accounts Folder button availability in companies page	
	public boolean isAccountsFolderAvailable() {
		return AccountsFolder.isPresent();		
	}

//Get the status of Applications Folder button availability in companies page	
	public boolean isApplicationsFolderAvailable() {
		return ApplicationsFolder.isPresent();		
	}

//Get the status of Snapshots Folder button availability in companies page	
	public boolean isSnapshotsFolderAvailable() {
		return SnapshotsFolder.isPresent();		
	}

//Get the status of Snapshots Folder button availability in companies page	
	public boolean isInvestigationsFolderAvailable() {
		return InvestigationsFolder.isPresent();		
	}

	
//Click on Create New Folder Buttokn	
	public void clickCreatNewFolderBtn() {
        if (companiespageCreateFolder.isPresent()) {

            companiespageCreateFolder.click();
            UIHelper.waitForPageToLoad(getDriver());
            waitFor(5000).milliseconds();
        }
        companiesCreateFolderTextbox.waitUntilPresent();		
	}

//Get the status of Create Folder section in companies page	
	public boolean isCreateFolderSecDisp() {
		return companiesCreateFolderTextbox.isPresent();
		
	}

//Enter the folder name in create folder section	
	public void provideFolderName(String folderName) {
        companiesCreateFolderTextbox.click();
        companiesCreateFolderTextbox.type(folderName);	
	}

//Click on Submit of the Create New Folder	
	public void clickSubmitBtnOfCreateNewFolder() {
        companiesCreateFolderandSubmit.click();
        folderTabTableWithoutHREFEle.waitUntilPresent();

        UIHelper.waitForPageToLoad(getDriver());

        UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),
                loadingImageEleXpath);		
	}

//Click on Submit of the edit folder	
	public void submitEditFolder() {
        companiesCreateFolderandSubmit.click();
        folderTabTableWithoutHREFEle.waitUntilPresent();
        UIHelper.waitForPageToLoad(getDriver());
        UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(),loadingImageEleXpath);		
		}

		
//Get the folder create sucess message	
	public String isFolderCreateSucessMsgDisp() {
		if(companiesCreateFolderSuccMsg.isPresent())
		{
			return companiesCreateFolderSuccMsg.getText().trim();
		}
		return null;
	}

//Click on folder
	public void clickOnFolder(String folderName) {
		System.out.println("Folder.."+folderName);
		getDriver().findElement(By.xpath("//div[@id='main']//div[@id='tabs1']//a[contains(.,'Folders')]")).click();
		getDriver().findElement(By.xpath("//form[@action='showAllFolderSummary']//tbody/tr/td[contains(.,'"+folderName+"')]/a")).click();
		UIHelper.waitForPageToLoad(getDriver());
	}

//Get the status of availability of credit files in All Companies folder	
	public boolean isCreditFilesAvailableInAllCompanies() {
		return creditFilesInAllCompaniesFolder.isDisplayed();
	}
	
	public void allCreditFiles(){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), allCreditFilesLink);
		allCreditFilesLink.click();
	}
	
//Get the status of availability of credit files in All Credit Files folder	
	public boolean isCreditFilesAvailableInAllCreditFiles() {
		if(companyResultsTableRows.size() > 0)
		{
			return creditFilesInAllCreditFilesFolder.isDisplayed();			
		}
		return true;
	}

//Get the status of availability of credit files in All Credit Files folder	
	public boolean isCreditFilesAvailableInFolder(String FolderName) {		
		return creditFilesInAllCreditFilesFolder.isDisplayed();
	}
		
//Get the status of availability of credit files in MyCompanies folder	
	public boolean isCreditFilesAvailableInMyCompanies() {		
		return creditFilesInMyCompaniesFolder.isDisplayed();
	}

//Get the status of availability of credit files in Accounts folder	
	public boolean isCreditFilesAvailableInAccounts() {		
		return creditFileInAccountsFolder.isDisplayed();
	}
	
//Get the status of availability of credit files in Applications folder	
	public boolean isCreditFilesAvailableInApplications() {
		if(creditFilesInAccountsFolder.size() > 0)
		{
			return true;
		}
		else
			return false;
//		return creditFilesInApplicationFolder.isDisplayed();
	}
	

	
	public boolean validateInvestigationFolderPage(){
		if(investigationFolderList.size()>0)
			return true;
		else 
			return false;
	}

//Get the status of availability of credit files in Snapshots folder	
	public boolean isCreditFilesAvailableInSnapshots() {
		if(creditFilesInAccountsFolder.size() > 0)
		{
			return true;
		}
		else
			return false;
//		return creditFilesInSnapshotsFolder.isDisplayed();
	}

//Select the credit file from All credit files folder	
	public void selectCreditFileFromAllCreditFilesFolder(String sourceFolder) {
		String sourecFolderEle1="//h2[contains(.,'"+sourceFolder+"')]//following::tr//td[1]";
		List<WebElement> sourecFolderEle=getDriver().findElements(By.xpath(sourecFolderEle1));
		for(WebElement sf : sourecFolderEle){
			sf.click();
		}
		UIHelper.waitForPageToLoad(getDriver());
		
	}

	public void selectCreditFileFromFilter() {
		intTotCntRecordDisp = Integer.parseInt(totCntRecordDisp.getText());
		creditFilesInAllCreditFilesFolder.click();
	}
	
//Select the credit file from folder	
	public void selectCreditFileFromFolder(String folderName) {
		clickOnFolder(folderName);
		checkAllCreditFilesCheckbox.click();
	}
/**
 * selectCreditFileFromFolder only for ecf
 * 
 */
	public void selectCreditFileFromFolderForEcf(String folderName) {
		clickOnFolder(folderName);
//		checkAllCreditFilesCheckbox.click();
	}
	
	public void DeleteCreditFileFromFolder(String folderName) {
		clickOnFolder(folderName);
//		checkAllCreditFilesCheckbox.click();
	}
	
//click on Copy to Folder button	
	public void clickCopyToFolderBtn() {
		btnCopyToFolder.click();
		UIHelper.waitForPageToLoad(getDriver());
	}
	public boolean verifyelements() {
		if(btnCopyToFolder.isDisplayed()){
			return true;		}
		return false;
	}

	//click on Copy to Folder button	
	public void clickDeleteCreditFilesBtn() {
		deleteBttn.click();
		getDriver().switchTo().frame("__modal_iframe_target");
		btnDeletCreditFile.click();
		//getDriver().switchTo().defaultContent();
		getDriver().switchTo().alert().accept();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}
	
//get the status of Select Folder frame avaialbility	
	public boolean isSelectFolderFrameDisplayed() {			
		return selectFolderiFrame.isDisplayed();
		
	}

//get the status of Create Folder frame avaialbility	
	public boolean isCreateFolderFrameDisp() {			
		if(iFrame.isDisplayed())
		{
			getDriver().switchTo().frame("__modal_iframe_target");
			return true;
		}
		return false;				
	}
	
//get the status of Select frame avaialbility	
//	public boolean isSelectFrameDisplayed() {	
		public void isSelectFrameDisplayed() {	
		UIHelper.waitForPageToLoad(getDriver());
//		System.out.println("I am int he window---------------");
//		getDriver().switchTo().frame("__modal_iframe_target");
//		if(iFrameEle.isDisplayed())
//		{
			System.out.println("-----------------I am inside the Iframe----------:isSelectFrameDisplayed()--------------");
			getDriver().switchTo().frame("__modal_iframe_target");
//			return true;
//		}
//		return false;		
	}
	
//get the status of Select Folder frame avaialbility	
	public boolean isDeleteCompaniesFrameDisplayed() {			
		return deletCompaniesConfirmFrame.isDisplayed();
	}

	
//Select the Folder from Available folders drop down	
	public void selectFolderFromAvailableFolderDropDown(String folderName) {
		System.out.println("))))))))111111111111111))))))))");
		getDriver().switchTo().frame("__modal_iframe_target");
		System.out.println(")))))))))22222222222222222222)))))))");
		Select mySelect= new Select(getDriver().findElement(By.xpath("//body[@class='iframe_modal']/form[@id='addToFolderForm']//select[@id='to_folder_id']")));
		mySelect.selectByVisibleText(folderName);
		btnSubmitSelectFolder.click();
//		selectAvailableFolders.selectByVisibleText(folderName);	
		System.out.println(")))))))33333333333333333333333)))))))))");
		getDriver().switchTo().defaultContent();
	}

//click on submit button from the Select folder frame	
	public void clickSubmitOnSelectFolderFrame() {
		//getDriver().switchTo().frame("__modal_iframe_target");
		//btnSubmitSelectFolder.click();
		UIHelper.waitForPageToLoad(getDriver());
	}
		
//click on Remove button on Delete Companies frame	
	public void clickRemoveBtnOnDeleteCompaniesFrame() {
		getDriver().switchTo().frame("__modal_iframe_target");
		btnRemoveCreditFiles.click();
		UIHelper.waitForPageToLoad(getDriver());
	}
		
//Get the Credit file copy confirmation message.	
	public boolean isCopyToFolderConfirmationDisplayed(){	
		getDriver().switchTo().defaultContent();
		String getMessage= labelCopyConfirmationMsg.getText();	
		if(getMessage.contains("The selected companies have been copied"))
			return true;
		else 
			return false;
	}
	
	
	public boolean deleteToFolderConfirmationDisplayed(){	
		getDriver().switchTo().defaultContent();
		UIHelper.highlightElement(getDriver(), labeldeleteConfirmationMsg);
		String getMessage= labeldeleteConfirmationMsg.getText();	
		if(getMessage.contains("The selected companies have been removed"))
			return true;
		else 
			return false;
	}

//Get the Credit file Remove confirmation message.	
	public String isCompaniesRemovedConfirmationDisplayed(String folderName) {		
		return labelRemoveConfirmationMsg.getText();		
	}
	//Get the Credit file added confirmation message.	
	public boolean isCompaniesAddedConfirmationDisplayed(String folderName) {
		System.out.println("11111111111111111111111111");
		waitFor(300).milliseconds();
	String expFolder=getDriver().findElement(By.xpath("//div[@id='confirmOperation']//h3//*[@id='m_folderName']")).getText().trim();
//		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//form[@id='SearchResultsForm']//div[@id='confirmOperation']//h3//*[@id='m_folderName']");
		System.out.println("22222222222222222222222222222");
//		labeladdConfirmationMsg.waitUntilVisible();
		System.out.println("33333333333333333333333");
		if(folderName.equalsIgnoreCase(expFolder)){
		return true;
		}
		return false;
	}
	
//Get the status of Shwo Sharing option	
	public boolean isShowSharingOptionDisplayed() {
		return showSharingOptions.isDisplayed();
	}

//Click on Show Sharing Options	
	public void clickOnShowSharingOption() {
		showSharingOptions.click();
	}

//Get the status of Role and User Details table	
	public boolean isRoleAndUserDetailsDisplayed() {
		return RoleAndUsertable.isDisplayed();
	}

//Select all the  checkboxes of Roles and Users	
	public void checkCheckboxesOfRolesAndUsers() {
		int intRows = getDriver().findElements(By.xpath("//table[@id='Role_alerts']//tr")).size();	
		if(intRows>0)
		{
			for(int i=1;i<=intRows;i++)
			{
				int intTdCnt = getDriver().findElements(By.xpath("//table[@id='Role_alerts']//tr["+i+"]/td/input[@type='checkbox']")).size();	
//				System.out.println("Row.."+i+"..TD cont.."+intTdCnt);
				if(intTdCnt>0)
				{
					List<WebElement> checkboxs = getDriver().findElements(By.xpath("//table[@id='Role_alerts']//tr["+i+"]/td/input[@type='checkbox']"));
					for(WebElement element:checkboxs)
					{
						if(isAttribtuePresent(element,"checked"))
						{
//								System.out.println("Test.."+i+".."+element.getText()+"..."+element.getAttribute("checked"));
								element.click();
						}
					}	
				}
									
			}			
		}	
	}
	
//Get the status of availability of attribute	
	private boolean isAttribtuePresent(WebElement element, String attribute) {
	    Boolean result = false;
	    try {
	        String value = element.getAttribute(attribute);	        
	        if (value == null){
	            result = true;
	        }
	    } catch (Exception e) {}

	    return result;
	}

//Get the confirmation message of the folder sharing	
	public String isFolderShareConfirmationMsgMatched() {
		return labelFolderShareConfirmationMsg.getText();		
	}

//Click on Customize link in Companies page	
	public void clickOnCustomize() {
		try{
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//ul[@id='pp_side_icon']//li//a//span[contains(.,'Customize')]");
			linkCustomizeInCompaniesFolder.click();	
			System.out.println("link calling::linkCustomizeInCompaniesFolder.click()");
			waitFor(5000).milliseconds();
		}catch(Exception e)
		{
//			e.printStackTrace();
		}

		/*try{
			linkCustomize.click();	
			System.out.println("link calling::linkCustomize.click()");
			waitFor(500).milliseconds();
		}catch(Exception e)
		{
//			e.printStackTrace();
		}*/
		
		
/*		if(linkCustomizeInCompaniesFolder.isDisplayed())
		{
			linkCustomizeInCompaniesFolder.click();
		}
		else
		{
			linkCustomize.click();			
		}
*/
//		iFrame.waitUntilVisible();
	}
	
	public void  clickOnCustomizedLink(){
		
		getDriver().findElement(By.xpath("//div[@id='pageHead']//a[contains(.,'Customize')]")).click();
		waitFor(300).milliseconds();
//		iFrame.waitUntilVisible();
	}
	
	
	
	
	
	

//select all the fileds from select Fields to display frame	
	public void selectAllFieldsFromSelectFieldsToDisplayFrameAndRemove() {
//		getDriver().switchTo().frame("__modal_iframe_target");
	System.out.println("-------i am inside the selectAllFieldsFromSelectFieldsToDisplayFrameAndRemove-----------------");
	Select selectBox = new Select(getDriver().findElement(By.xpath("//div[@id='seld_cus']//select[@class='CompCustomize_Select' and @name='selectedFields']")));
		int totOptions = selectBox.getOptions().size();
		for(int i=0;i<totOptions;i++)
		{
			System.out.println("---------methodcalling----------------");
			selSelectFieldsToDisplay.selectByIndex(i);
		}
//		UIHelper.highlightElement(getDriver(), btnRemoveSelectedFieldsToDisplay);
		btnRemoveSelectedFieldsToDisplay.click();
		waitFor(5000).milliseconds();
	}

//Verify that , company name can not removed alert box	
	public boolean isCompanyNameCantRemovedAlertDisplayed() {
		    try 
		    { 
		    	Alert alert = getDriver().switchTo().alert(); 
		    	alert.accept();
		        return true; 
		    } 
		    catch (NoAlertPresentException Ex) 
		    { 
		        return false; 
		    }  
		}
//Click on Update List button
	public void clickOnUpdateList() {
		waitFor(5000).milliseconds();
		btnUpdateList.click();
		UIHelper.waitForPageToLoad(getDriver());
		waitFor(5000).milliseconds();
	}

//Verify that , only company name header is displayed	
	public boolean isOnlyCompanyNameHeaderDisplayed() {
		if(allCompaniesMainTableHeader.size() == 1)
		{
			return isCompanyHeaderDisp("Company Name");
		}
		return false;
		
	}
	
	public boolean isOnlyCompanyNameAndTypeHeaderDisplayed() {
		if(companyResultsTableHeader.size() == 3)
		{
			return isCompanyHeaderDispForUserCreatedFold("Company Name & Address");
		}
		return false;
		
	}
	
	private boolean isCompanyHeaderDisp(String headerName)
	{ 	
		waitFor(3000).milliseconds();
		return getDriver().findElement(By.xpath("//table[@id='allCompaniesMainTable']/thead//tr//th/a[contains(text(),'"+headerName+"')]")).isDisplayed();
	}

	private boolean isCompanyHeaderDispForUserCreatedFold(String headerName)
	{		
		btnCopyToFolder.waitUntilEnabled();
		try
		{
			if(getDriver().findElement(By.xpath("//table[@class='results full_company']/thead//tr//th/a[contains(text(),'"+headerName+"')]")).isDisplayed())
			{
				return true;
			}
		}
		catch(Exception e)
		{
			
		}
		try
		{
			if(getDriver().findElement(By.xpath("//table[@class='results full_company']/thead//tr//th[contains(text(),'"+headerName+"')]")).isDisplayed())
			{
				return true;
			}
		}
		catch(Exception e)
		{
			
		}
		return false;
		//		return getDriver().findElement(By.xpath("//table[@class='results full_company']/thead//tr//th[contains(text(),'"+headerName+"')]")).isDisplayed();
	}

	public void addAddressField(String AvailableField) {
		System.out.println("MY AVILABLE FIELD IS---------------->"+AvailableField);
		UIHelper.waitForPageToLoad(getDriver());
		Select select = new Select(getDriver().findElement(By.xpath("//div[@class='CompCutomize_Mar_Bottom']//div[@id='vars_cus']//select[@id='pool']")));
		select.selectByVisibleText(AvailableField);
		//selAvailableFields.selectByVisibleText(AvailableField);
		btnAddSelectedFieldsToDisplay.click();
		waitFor(300).milliseconds();
	}

	public boolean isAllCompaniesColumnHeaderDisplayed(String availableField) {
		return isCompanyHeaderDisp(availableField);		
	}
	
	public boolean isUserCreatedFolderColumnHeaderDisplayed(String availableField) {
		return isCompanyHeaderDispForUserCreatedFold(availableField);		
	}

	public void selCompaniesWithOutDunsFromViewFilter() {	
		System.out.println("a00000000000000000000000000000a");
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//*[@id='ALL_COMPANIES_FILTER']");
		System.out.println("b00000000000000000000000000000b");
		//div[@id='main']//div[@class='floatLeft viewMargin']
		Select select = new Select(getDriver().findElement(By.xpath("//select[@id='ALL_COMPANIES_FILTER']")));
		System.out.println("---------------------");
	     select.selectByIndex(1);
//		select.selectByVisibleText("Companies without D-U-N-S� Numbers");
		UIHelper.waitForPageToLoad(getDriver());
		System.out.println("c00000000000000000000000000000c");
	}

	public void clickFilterInAllCompFold() {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='main']//div[@class='floatLeft viewMargin']//input[@value='Filter']");
		((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", btnFilter);
		btnFilter.click();
		UIHelper.waitForPageToLoad(getDriver());
	}

	public boolean isListOfCompWithOutDunsDispInAllCompFolder() {
		System.out.println("00000000000000000000000000000");
		int rowCnt = getDriver().findElements(By.xpath("//table[@id='allCompaniesMainTable']/tbody/tr")).size();
		if(rowCnt>1)
		{
			for(int i=1;i<=rowCnt;i++)
			{				
				if(!getDriver().findElement(By.xpath("//table[@id='allCompaniesMainTable']/tbody/tr["+i+"]/td[1]")).getText().split("D-U-N-S")[1].split(" ")[11].trim().equalsIgnoreCase("NA"))
				{
//					return false;
					return true;
				}
			}
			
		}
		System.out.println("11111111111111111");
			return true;		
	}

	public void setCreditFilesFilterInAllCreditFilesFolder(String subFilter, String date) {
		UIHelper.highlightElement(getDriver(), selCreditFilesView);
		selCreditFilesView.selectByVisibleText("D&B Live Reports");
		selCreditFilesViewSubFilt.selectByVisibleText(subFilter);
		creditFilesViewDate.sendKeys(date);
		UIHelper.waitForPageToLoad(getDriver());
		
	}

	public void setCreditFilesFilterInApplicationFolder(String subFilter, String date) {
		selCreditFilesViewSubFilt.selectByVisibleText(subFilter);
		creditFilesViewDate.sendKeys(date);
		
	}

	
	public void clickApplyOfAllCreditFilesFilter() {		
		btnApplyAllCreditFilesFilter.click();
		UIHelper.waitForPageToLoad(getDriver());
		waitFor(1000).milliseconds();
	}

	
	public boolean isCreditFilesDispAsPerFilterDate(String date) {
		boolean sucessflag = false;
		int rowCnt = getDriver().findElements(By.xpath("//table[@class='results full_company']/tbody/tr")).size();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

			Date expDate = null;
			Date actDate = null;
			try {
				expDate = sdf.parse(date);
				System.out.println("expDate---------------"+expDate);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			System.out.println("Row Cnt.."+rowCnt);
			int headIndex = getHeaderIndex("Date Created");
			if(rowCnt>1)
			{
				for(int i=1;i<=rowCnt;i++)
				{									
					try {
						actDate = sdf.parse(getDriver().findElement(By.xpath("//table[@class='results full_company']/tbody/tr["+i+"]/td["+headIndex+"]")).getText());
					} catch (ParseException e) {
						e.printStackTrace();
					}
					System.out.println("actDate----------"+actDate+"expDate-----------"+expDate);
					if(expDate.before(actDate) || expDate.equals(actDate))
					{
						sucessflag = true;
						System.out.println("test1..."+date+"...."+getDriver().findElement(By.xpath("//table[@class='results full_company']/tbody/tr["+i+"]/td["+headIndex+"]")).getText());				
					}
					else
					{
						sucessflag = false;
					}
				}
				
			}
			else
				sucessflag = true;
		return sucessflag;
		
	}
	public int getHeaderIndex(String headerName)
	{
		System.out.println("Header index..."+getDriver().findElements(By.xpath("//table[@class='results full_company']/thead/tr/th/a[text()='"+headerName+"']/../preceding-sibling::th")).size());
		int headerIndex = getDriver().findElements(By.xpath("//table[@class='results full_company']/thead/tr/th/a[text()='"+headerName+"']/../preceding-sibling::th")).size();
		headerIndex = headerIndex + 1;
		System.out.println("Header index2...-------"+headerIndex);
		return headerIndex;
	}

	public void getTheTotalDispItemCount() {		
		intTotCntRecordDisp = Integer.parseInt(totCntRecordDisp.getText());
		intCurrentRecordDisp = Integer.parseInt(totRecordDisp.getText().split("-")[1].trim());
		if(intCurrentRecordDisp > 20)
		{
			rec20DropDown = true;
		}
		if(intCurrentRecordDisp > 50)
		{
			rec50DropDown = true;
		}

	}

	public void clickOnNextpageNavi() {
		if(linkNext.isVisible())
		{
			linkNext.click();
			NextAvail = true;
		}
		else
		{
			NextAvail = false;
		}
		UIHelper.waitForPageToLoad(getDriver());		
	}
	
	public void clickOnPreviouspageNavi() {
		if(linkPrevious.isVisible())
		{
			linkPrevious.click();
			PreviousAvail = true;
		}
		else
			PreviousAvail = false;
		UIHelper.waitForPageToLoad(getDriver());		
	}
	
	public void clickOnLastpageNavi() {
		if(linkLast.isVisible())
		{
			linkLast.click();
			LastAvail = true;
		}
		else
			LastAvail = false;
		UIHelper.waitForPageToLoad(getDriver());		
	}
	
	public void clickOnFirstpageNavi() {
		if(linkFirst.isVisible())
		{
			linkFirst.click();
			FirstAvail = true;
		}
		else
			FirstAvail = false;
		UIHelper.waitForPageToLoad(getDriver());		
	}
	
	public boolean isLastRecordsDispCntUpdated() {
		if(LastAvail)
		{
			intRecordDispTemp = Integer.parseInt(totRecordDisp.getText().split("-")[1].trim());
			System.out.println("Test1.."+intRecordDispTemp);
			if(intTotCntRecordDisp == intRecordDispTemp)
			{
				intCurrentRecordDisp = intRecordDispTemp;
				return true;
			}
			else{
				intCurrentRecordDisp = intRecordDispTemp;
				return false;			
			}						
		}
		else
			return true;
	}
	
	public boolean isFirstRecordsDispCntUpdated() {
		if(FirstAvail)
		{			
			intRecordDispTemp = Integer.parseInt(totRecordDisp.getText().split("-")[1].trim());
			if(intRecordDispTemp == 10)
			{
				intCurrentRecordDisp = intRecordDispTemp;
				return true;
			}
			else{
				intCurrentRecordDisp = intRecordDispTemp;
				return false;			
			}			
		}
		else
			return true;
	}
		
	public boolean isNextRecordsDispCntUpdated() {
		if(NextAvail)
		{
			intRecordDispTemp = Integer.parseInt(totRecordDisp.getText().split("-")[1].trim());
//			if(intCurrentRecordDisp + 10 == intRecordDispTemp)
			if(intRecordDispTemp >= intCurrentRecordDisp + 1 || intRecordDispTemp <= intCurrentRecordDisp + 10   )
			{
				intCurrentRecordDisp = intRecordDispTemp;
				return true;
			}
			else{
				intCurrentRecordDisp = intRecordDispTemp;
				return false;			
			}						
		}
		else
			return true;
	}
	
	public boolean isPreviousRecordsDispCntUpdated() {
		if(PreviousAvail)
		{			
			intRecordDispTemp = Integer.parseInt(totRecordDisp.getText().split("-")[1].trim());
			if(intCurrentRecordDisp%10 == 0)
			{			
				if(intCurrentRecordDisp - 10 == intRecordDispTemp)
				{
					intCurrentRecordDisp = intRecordDispTemp;
					return true;
				}
				else{
					intCurrentRecordDisp = intRecordDispTemp;
					return false;			
				}			
			}
			else
			{
				if(intCurrentRecordDisp/10 * 10 == intRecordDispTemp)
				{
					intCurrentRecordDisp = intRecordDispTemp;
					return true;
				}
				else{
					intCurrentRecordDisp = intRecordDispTemp;
					return false;			
				}			
				
			}
		}
		else
			return true;
	}

	public boolean isViewItemsCntDisp() {	
		return selViewItems.isDisplayed();
	}

	public void setRecordsViewSize(String viewRecordsCnt) {
		selViewItems.selectByVisibleText(viewRecordsCnt);	
		UIHelper.waitForPageToLoad(getDriver());
	}

	public int isDispRecCntMatchWithViewRecCnt(int viewRecordsCnt) {
		if(intCurrentRecordDisp >= viewRecordsCnt)
		{
			return creditFilesInAccountsFolder.size();		
		}else
			return viewRecordsCnt;
	}

	public void clickLetterForSort(String letter) {
		if(getDriver().findElement(By.xpath("//div[@id='filterAtoZ']/a[text()='"+letter+"']")).isDisplayed())
		{		
			getDriver().findElement(By.xpath("//div[@id='filterAtoZ']/a[text()='"+letter+"']")).click();
			UIHelper.waitForPageToLoad(getDriver());
			NextValidation = true;
		}
	}
	
	public void clickDletterPage(){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), clickDlink);
		clickDlink.click();
	}
	
	public void clickHashletterPage(){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), clickHashlink);
		clickHashlink.click();
	}
	
	public void clickAllletterPage(){
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.highlightElement(getDriver(), clickAlllink);
		clickAlllink.click();
	}

	public boolean isCrediFilesNamesStartedWithLetter(String letter) {
		if(NextValidation){			
			int rowCnt = creditFilesCompNameInAccountsFolder.size();			
			for(int i=0;i<rowCnt;i++)
			{
				System.out.println("Test1.."+creditFilesCompNameInAccountsFolder.get(i).getText());
				if(!creditFilesCompNameInAccountsFolder.get(i).getText().substring(0, 1).equalsIgnoreCase(letter))
				{
					return true;
				}
			}
			return true;
		}
		return true;
		
	}

	public boolean isFiltersTabAvailable() {		
		return tabFilters.isVisible();
	}

	public void selectFiltersTab() {
		tabFilters.click();
		btnCreateNewFilter.waitUntilVisible();
		
	}

	public void selectFilterExportTab() {
		tabFiltersExports.click();
		tblExcelExportJobs.waitUntilVisible();		
	}
	
	public void clickCreateNewFilter() {
		btnCreateNewFilter.waitUntilEnabled();
		btnCreateNewFilter.click();
		iFrame.waitUntilVisible();		
	}

	public void clickCreateFilterSubmit() {
		btnCreateNewFilterSubmit.click();
		UIHelper.waitForPageToLoad(getDriver());
		labelCreateFilter.waitUntilVisible();		
	}

	public boolean isCreateFilterPageDisplayed() {
		return labelCreateFilter.isVisible();
	}

	public void selectFilterType(String filterType) {
		System.out.println("filtertype----------------"+filterType);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@id='main']//div[@class='clear filt_bottomPad mar_left5px']/table//td[contains(.,'Type')]");
		selectFilterCategoryEle.selectByVisibleText(filterType);
//		selFilterEntityType.selectByVisibleText(filterType);		
	}

	public void selFilterDataCategory(String filterDataCategory) {
		selFilterDataCategory.selectByVisibleText(filterDataCategory);		
	}

	public boolean isAvailableVariableDisp() {
		return selDataFields.isVisible();
	}

	public void addCondition(String variable, String condition) {
		selDataFields.selectByVisibleText(variable);
		if(condition.equalsIgnoreCase("AND"))
		{
			btnAddDataFieldToAndCondition.click();
		}else if(condition.equalsIgnoreCase("OR"))
		{
			btnAddDataFieldToORCondition.click();
		}else
		{
			btnAddDataFieldToNotCondition.click();
		}
		
	}

	public void selectOperator(String operator, String variable) {
		Select selOper = new Select(getDriver().findElement(By.xpath("//span[contains(text(),'"+variable+"')]/../following-sibling::td/select")));
		selOper.selectByVisibleText(operator);				
	}

	public void setFilterName(String filterName) {
		System.out.println("----------------------00000000000000-----------");
		txtFilterName.clear();
		txtFilterName.sendKeys(filterName);
		WebElement element = getDriver().findElement(By.xpath("//input[@id='form_submit']"));
		((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
//		((JavascriptExecutor)getDriver()).executeScript("arguments[0].click();", element);
		btnFilterSave.click();
//		formFilterList.waitUntilVisible();
	}

	public void setAdvFilterName(String AdvFilterName) {
		System.out.println("----------------------111111111111111111----------");
		txtAdvFilterName.clear();
		txtAdvFilterName.sendKeys(AdvFilterName);
		btnAdvFilterSave.click();
		saveAdvFilterPopUp.waitUntilVisible();
	}
	
	public boolean isFilterAvailable(String filterName) {	
		System.out.println("----------------------2111111222222222-----------");
		System.out.println("----------------------2222222222-----------"+filterName);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//form[@action='showFilterSummaryList']//table//thead");
		System.out.println("----------------------3333333-----------");
		if(getDriver().findElement(By.xpath("//form[@name='additionalHeaderForm']//tr/td/a[normalize-space(text())='"+filterName+"']")).isDisplayed()){
			System.out.println("----------------------444444-----------");
			return true ;
		}
		else {
			return false;	
		}
	}

	public void clickOnAdvancedFilterBuilderButton() {	
		if(btnAdvancedFilterBuilder.isDisplayed())
		{
			System.out.println("Element is displayed");
		}
		btnAdvancedFilterBuilder.click();
		btnPreCountFilterResults.waitUntilVisible();
	}

	public String getDNBiPageTitle() {		
		return labelPageTitle.getText();
	}

	public void selectTheVariable(String variable) {
		selVariable.selectByVisibleText(variable);
		linkAddVariable.click();
		ExpectedExpression = "("+variable+")";
	}

	public void selectOperator(String operator) {
		selVarOperatorValue.selectByVisibleText(operator);
		linkAddOperator.click();
		ExpectedExpression = ExpectedExpression+" "+operator;
	}

	public void isSelectedExpressionMatched() {
		
		
	}

	public boolean isSaveAdvanceFilterPopupDisp() {
		waitFor(5000).milliseconds();
		return saveAdvFilterPopUp.isDisplayed();		
	}

	public boolean isSaveFilterPopupDisp() {
		saveFilterPopUp.waitUntilVisible();
		return saveFilterPopUp.isDisplayed();		
	}
	
	public void saveAdvFilter() {
		btnSaveAdvFilter.click();
		formFilterList.waitUntilVisible();		
	}

	public void clickOnEditForFilter(String filterName) {
		getDriver().findElement(By.xpath("//form[@name='additionalHeaderForm']//tr/td/a[normalize-space(text())='"+filterName+"']/../following-sibling::td/a[contains(text(),'Edit')]")).click();		
	}

	public boolean isEditFilterPageDisp() {	
		pageEditFilter.waitUntilPresent();
		return pageEditFilter.isVisible();
	}

	public boolean isAdvanceFilterPageDisp() {	
		pageAdvEditFilter.waitUntilVisible();
		return pageAdvEditFilter.isVisible();
	}
	
	public void clearTheFilterConditions() {		
		filterExpressionBox.clear();
	}

	public String isExpressionBoxEmpty() {
		System.out.println("Expresskion box text.."+filterExpressionBox.getText());
		return filterExpressionBox.getText();
		
	}

	public void RemoveFilterExistingConditions() {
		int AndTableRows = tblDataFieldAndTableRows.size();
		int OrTableRows = tblDataFieldORTableRows.size();
		int NotTableRows = tblDataFieldNotTableRows.size();
		if(AndTableRows > 0 )
		{
			for(int i=1;i<=AndTableRows;i++)
			{
				tblDataFieldAndTableRows.get(0).findElements(By.tagName("td")).get(0).click();
				btnRemoveDataFieldFromAndCondition.click();		
			}
		}

		if(OrTableRows > 0 )
		{
			for(int i=1;i<=OrTableRows;i++)
			{
				tblDataFieldORTableRows.get(0).findElements(By.tagName("td")).get(0).click();
				btnRemoveDataFieldFromORCondition.click();
			}
		}

		if(NotTableRows > 0 )
		{
			for(int i=1;i<=NotTableRows;i++)
			{
				tblDataFieldNotTableRows.get(0).findElements(By.tagName("td")).get(0).click();
				btnRemoveDataFieldFromNotCondition.click();				
			}
		}

	}

	public void clickPreCountFilterResults() {		
//		btnPreCountFilterResults.click();
		((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", btnPreCountFilterResults);
		((JavascriptExecutor)getDriver()).executeScript("arguments[0].click();", btnPreCountFilterResults);
		windPreCountFilterResults.waitUntilVisible();
	}

	public boolean isPreCountFilterResultsDisp() {
		

			System.out.println("========getting value...........................");
			getDriver().switchTo().frame("__modal_iframe_target");			
			System.out.println("getting value...........................");
			//UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[@class='modal']");
			UIHelper.waitForPageToLoad(getDriver());
			waitFor(7000).milliseconds();
		String value=getDriver().findElement(By.xpath("//div[@id='widget_container1']")).getText();
			intrecordsInFilter = Integer.parseInt(value.toString().trim());
			System.out.println("no of records in the filter-----------"+value);
			System.out.println("no of records in the filter-----------"+value.length());
			
			if(intrecordsInFilter >=0){
//				System.out.println("The filter result------------->"+lblPreCountFilterResults.getValue());
				System.out.println("inside if loop ok1 btn has clicked");
				WebElement element=getDriver().findElement(By.xpath("//body[@class='iframe_modal']//*[@class='modal_buttons clear']//input[contains(@value,'OK')]"));
				((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
				System.out.println("ok button has identified----------------------------------");
//				((JavascriptExecutor)getDriver()).executeScript("arguments[0].click();", element);
				System.out.println("inside if loop ok2 btn has clicked");
				element.click();
				getDriver().switchTo().defaultContent();
				getDriver().switchTo().activeElement();
			return true;
		}	
			System.out.println("outside if loop ok btn has clicked");
			getDriver().switchTo().defaultContent();
			getDriver().switchTo().activeElement();
		return false;
	}


public void clickOkOnFilterResults() {
//		getDriver().switchTo().frame("__modal_iframe_target");	
		btnOkOfPreCountFilterResults.click();
		getDriver().switchTo().defaultContent();
		
	}

	public void clickCancelOfEditFilter(){
		System.out.println("cancel button has clicked");
		((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", btnCancelEditFilter);
		((JavascriptExecutor)getDriver()).executeScript("arguments[0].click();", btnCancelEditFilter);
//		btnCancelEditFilter.waitUntilEnabled();
//		btnCancelEditFilter.click();
		formFilterList.waitUntilVisible();
	}

	public boolean isNavigatedToFilterPage() {
		return formFilterList.isVisible();
	}

	public void clickDeleteFilter(String filterName) {
		WebElement deleteFilter=getDriver().findElement(By.xpath("//form[@name='additionalHeaderForm']//tr/td/a[normalize-space(text())='"+filterName+"']"));
		
		if(deleteFilter.isDisplayed()){
			WebElement deleteFilter1=getDriver().findElement(By.xpath("//form[@name='additionalHeaderForm']//tr/td/a[normalize-space(text())='"+filterName+"']/../following-sibling::td/a[contains(text(),'Delete')]"));
			
			((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);", deleteFilter1);
			((JavascriptExecutor)getDriver()).executeScript("arguments[0].click();", deleteFilter1);
			deleteFilterWindow.waitUntilVisible();
		}
		else{
			
		}
	}

	public boolean isDeleteFilterPopUpDisp() {	
		UIHelper.waitForPageToLoad(getDriver());
		return deleteFilterWindow.isDisplayed();
	}

	public void selectYesOfDeleteFiltConfirmation() {
		UIHelper.waitForPageToLoad(getDriver());
		btnYesDeleteFilter.click();	
		UIHelper.waitForPageToLoad(getDriver());		
	}

	public void clickOnFilterName(String filterName) {
		getDriver().findElement(By.xpath("//form[@name='additionalHeaderForm']//tr/td/a[normalize-space(text())='"+filterName+"']")).click();
		labelPageTitle.waitUntilVisible();
	}

	public boolean isFilterResultMatchedWithPreCount() {
		intTotCntRecordDisp = Integer.parseInt(totCntRecordDisp.getText());
		System.out.println("Test1..."+intTotCntRecordDisp);
		System.out.println("Test1..."+intrecordsInFilter);
		if(intTotCntRecordDisp == intrecordsInFilter)
		{
			return true;
		}else		
		return false;
	}

	public void AddHeaderIfNotAvail(String headerName) {
		try{
			System.out.println("adding date field-------------------");
			waitFor(5000).milliseconds(); 
			//div[@id='vars_cus']//select[@id='pool']
			Select mySelect= new Select(getDriver().findElement(By.xpath("//div[@id='vars_cus']//select[@id='pool']")));
			mySelect.selectByVisibleText(headerName);
			btnAddSelectedFieldsToDisplay.click();		
		}
		catch(Exception e)
		{
//			e.printStackTrace();
		}
		
	}

	public void clickCreateNewFolderOnSelectFoldFrame(String FolderName,String Profile) {
		waitFor(3000).milliseconds();
		System.out.println("************1111111111111111111111");
		
		getDriver().switchTo().frame(iFrameEle);
		System.out.println("*************4444444444444444444444");
		lnkCreateNewFolder.click();
		System.out.println("*************555555555555555");
		getDriver().switchTo().defaultContent();
		// iFrameEle.waitUntilPresent();
		System.out
				.println("waited for iframe-----------------------");
		getDriver().switchTo().frame(iFrameEle);
		System.out
				.println("folder popup has displayed---------------------");
		if (newFolderName.isPresent()) {
			System.out.println("*************6666666666666666666666666");
			newFolderName.type(FolderName);
			newFolderNameAlertProfile
					.selectByVisibleText(Profile);
			searchResultsnapShotAddFolderSubmit.click();
			getDriver().switchTo().defaultContent();
		}
	}

	public void enterFoldNameAndSelectProfileType(String folderName,
			String profile) {
		//waitFor(5000).milliseconds();
		System.out.println("*************4444444444444444444444");
		getDriver().switchTo().activeElement();
		System.out.println("*****55555555555555********4444444444444444444444");
		getDriver().switchTo().frame(getDriver().findElement(By.xpath("//div[@class='modal_content']//iframe[1]")));
		System.out.println("*******************6666666666666666666666666666**********");
		lblFolderName.sendKeys(folderName);
		System.out.println("********************77777777777777777777777777777");
		selAlertProfile.selectByVisibleText(profile);	
		System.out.println("*************888888888888888888888888888888");
		getDriver().switchTo().defaultContent();
	}

	public void clickSubmitOfCreateFolder() {
		btnSubmitCreateNewFolder.click();
		UIHelper.waitForPageToLoad(getDriver());
		getDriver().switchTo().defaultContent();		
	}

	public void objCompaniesTest() {
		btnDeleteSelected.click();
		
	}
	public boolean isCreditFileDeleteFromFilterAlertDisplayed() {
	    try 
	    { 
	    	Alert alert = getDriver().switchTo().alert(); 
	    	alert.accept();
	    	UIHelper.waitForPageToLoad(getDriver());
	        return true; 
	    } 
	    catch (NoAlertPresentException Ex) 
	    { 
	        return false; 
	    }  
	}

	public boolean isConfirmationAlertDisp() {
	    try 
	    { 
	    	Alert alert = getDriver().switchTo().alert(); 
	    	alert.accept();
	    	UIHelper.waitForPageToLoad(getDriver());
	        return true; 
	    } 
	    catch (NoAlertPresentException Ex) 
	    { 
	        return false; 
	    }  
	}
	
	public boolean isCreditFileDeletedFromFilter() {
		int intTotCntRecordDisptemp = Integer.parseInt(totCntRecordDisp.getText());
		if(intTotCntRecordDisptemp + 1 == intTotCntRecordDisp)
		{
			return true;
		}
		else
		return false;
	}

	public void clickOnExcelExportLink() {
		linkExcelExport.click();
		
	}

	public String isExcelExportStatusCompleted() {
		waitFor(3000).seconds();
		return linkExcelExportJobStatus.getText().trim();		
	}

	public void clickDownloadFilterExport() {
		linkDownloadExcelExportJob.click();		
	}

	public boolean isFilterDeleted(String filterName) {
		
		System.out.println("----------------------5555555555555555555----------"+filterName);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//form[@action='showFilterSummaryList']//table//thead");
	int rowcnt=	getDriver().findElements(By.xpath("//form[@action='showFilterSummaryList']//table[@ class='results full']/tbody/tr")).size();
System.out.println("****************************************rowcount*******************"+rowcnt);
	for (int i = 1; i <=rowcnt; i++) {
		System.out.println("****************************************for loop*******************");
		if(getDriver().findElement(By.xpath("//form[@action='showFilterSummaryList']//table[@ class='results full']/tbody/tr["+i+"]/td[1]")).getText().equalsIgnoreCase(filterName)){	
	
			return false ;
		}
		
	}
	return true;
	}

	public void isFilterAvailableThenDelete(String filterName) {
		// TODO Auto-generated method stub
		System.out.println("----------------------2111111222222222-----------");
		System.out.println("----------------------2222222222-----------"+filterName);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//form[@action='showFilterSummaryList']//table//thead");
		System.out.println("----------------------3333333-----------");
		if(getDriver().findElement(By.xpath("//form[@name='additionalHeaderForm']//tr/td/a[normalize-space(text())='"+filterName+"']")).isDisplayed()){
			System.out.println("----------------------444444-----------");
			
			clickDeleteFilter(filterName);
			isDeleteFilterPopUpDisp();
			selectYesOfDeleteFiltConfirmation();
			isFilterDeleted(filterName);
			isNavigatedToFilterPage();
			
		}
		else {
			
		}
	}

	public boolean isFolderNameDisplayed(String FolderName) {
		waitFor(5000).milliseconds();
		//--------
		int size=getDriver().findElements(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr")).size();
	
		for(int i=1;i<=size;i++){
			WebElement element=getDriver().findElement(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr["+i+"]//td[2]"));
			System.out.println("------------element---------element.isDisplayed()-----1------"+element);
			waitFor(5000).milliseconds();
		if(!element.getText().contains(FolderName)){
		
			return true;
		
		//------------------
//		boolean value= getDriver().findElement(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr//td/a[contains(text(),'"+FolderName+"')]")).isDisplayed();
//		return value;
		
	        }
//		 return false;
		}
		return false;

	}
	
	
	//--------------added--------------
	
	public void isFolderRemoved(String FolderName) {
		waitFor(5000).milliseconds();
		System.out.println("++++++++++++++++++++++++++++++++");
		int size=getDriver().findElements(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr")).size();
		int count=1;
		for(int i=1;i<=size;i++){
			WebElement element=getDriver().findElement(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr["+i+"]//td[2]"));
			System.out.println("------------element---------element.isDisplayed()-----1------"+element);
		if(element.getText().contains(FolderName)){
			System.out.println("------------isFolderNameDisplayed()---------element.isDisplayed()-----1------");
//			return getDriver().findElement(By.xpath("//form[@action='showAllFolderSummary']/table/tbody//tr//td/a[contains(text(),'"+FolderName+"')]")).isDisplayed();
			if(count<=2){
			clickOnFolderDeleteBtn(FolderName);
			UIHelper.processalert(getDriver());
			count++;
			if(count==2){
				break;
			}
			}
			waitFor(5000).milliseconds();
			System.out.println("------------isFolderNameDisplayed()---------element.isDisplayed()---2--------");
//			return true;
		}
		else{
			
//		return true;
		}
		}
	}
//	----------------------------

	public void clickCheckAll() {
		// TODO Auto-generated method stub
		getDriver().findElement(By.xpath("//div[@id='main']//table[@class='results full_company']//th[1]/input[@name='checkAll']")).click();	
	}

	public void clickOnMoveToFolderButton() {
		// TODO Auto-generated method stub
		moveToFolder.click();
	}

	public String isMoveToFolderConfirmationDisplayed(String folderName) {
		// TODO Auto-generated method stub
		return labelMoveConfirmationMsg.getText();
	}

	public boolean isCreditFilesAvailableInCustomFolder(String folderName) {
		// TODO Auto-generated method stub
		if(creditFilesInAccountsFolder.size() > 0)
		{
			return true;
		}
		else
			return false;
	}

	public void enterDunsNumberandEnter(String dunsNumber) {
		// TODO Auto-generated method stub
		searchCompBox.waitUntilPresent();
//        searchCompBox.click();
//        searchCompBox.sendKeys(dunsNumber.trim());
		WebElement el=getDriver().findElement(By.xpath("//*[@class='outerDiv']//*[@id='search_box']//*[@id='quickSearchFld']"));
		el.sendKeys(dunsNumber);
		el.sendKeys(Keys.ENTER);
	}

	public void clickFirstRecordandDelete() {
		// TODO Auto-generated method stub
		getDriver().findElement(By.xpath("//div[@id='main']//table//tr[1]/td[1]")).click();
		waitFor(300).milliseconds();
		getDriver().findElement(By.xpath("//form[@id='folderOperations']//input[@value='Delete']")).click();
		waitFor(300).milliseconds();
	}

	public boolean countNumberOfDunsDisplayed() {
		// TODO Auto-generated method stub
		int size=getDriver().findElements(By.xpath("//div[@id='main']/div/table[@class='results full']/tbody/tr")).size();
		if(size>0){
			return true;
		}
		return false;
	}

	public void clickcolumnForSort(String columnName) {
		// TODO Auto-generated method stub
		//table[@id='allCompaniesMainTable']//tr/th/a[contains(text(),'Company Name')]
		if(getDriver().findElement(By.xpath("//table//tr/th/a[contains(text(),'"+columnName+"')]")).isDisplayed())
		{		
			getDriver().findElement(By.xpath("//table//tr/th/a[contains(text(),'"+columnName+"')]")).click();
			UIHelper.waitForPageToLoad(getDriver());
			NextValidation = true;
		}
	}

	public boolean isCrediFilesNamesStartedWithColumnName() {
		// TODO Auto-generated method stub
		if(NextValidation){			
			int rowCnt = getDriver().findElements(By.xpath("//table/tbody/tr")).size();
			String temp;
			String text=getDriver().findElement(By.xpath("//*[@id='main']/table/tbody/tr[1]/td[3]/b")).getText().trim();
			for(int i=2;i<rowCnt;i++)
			{
				
				String text2=getDriver().findElement(By.xpath("//*[@id='main']/table/tbody/tr['"+i+"']/td[3]/b")).getText().trim();
				System.out.println("Test1.."+text);
				if(text2.charAt(0)>=text.charAt(0)){
					System.out.println("equal");
				}
				/*if(text2.equals(text))
				{
					return false;
				}*/
				temp=text;
				text=text2;
			}
			return true;
		}
		return true;
		
	}

	public void clickshowsharedFolder() {
		// TODO Auto-generated method stub
		showSharingOptions.click();	
	}

	public void clickDeleteBtnOnDeleteCompaniesFrame() {
		// TODO Auto-generated method stub
//		getDriver().switchTo().frame("__modal_iframe_target");
//		btnRemoveCreditFiles.click();
		System.out.println("I am in the clickDeleteBtnOnDeleteCompaniesFrame------------------");
		UIHelper.processalert(getDriver());
		System.out.println("I am in the clickDeleteBtnOnDeleteCompaniesFrame----------222--------");
		UIHelper.waitForPageToLoad(getDriver());
	}

	public String isCompaniesDeletedConfirmationDisplayed() {
		System.out.println("I am getting --------------------");
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), deletemsg);
			System.out.println("I am getting --------------------"+labelDeleteConfirmationMsg.getText().trim());
			return labelDeleteConfirmationMsg.getText();		
		}

	public void selectFirstCreditFileFromFolder() {
		// TODO Auto-generated method stub
		getDriver().findElement(By.xpath("//div[@id='main']/table/tbody/tr[1]/td[1]/input[@type='checkbox']")).click();
	}

	public void clickUserandSavetoShare(String userName) {
		// TODO Auto-generated method stub
		getDriver().findElement(By.xpath("//table[@id='Role_alerts']/tbody//tr/td[contains(.,'"+userName+"')]/input")).click();
		waitFor(500).milliseconds();
		getDriver().findElement(By.xpath("//input[@id='smart_folder_submit']")).click();
	}

	public String isConfirmationMessageforSharedFolderDisplayed(String folderName) {
		// TODO Auto-generated method stub
		String sharedFolder1= "//div[@id='confirmOperation']//div//h3[contains(.,'"+folderName+" folder sharing options have been successfully saved')]";
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), sharedFolder1);
		return  getDriver().findElement(By.xpath(sharedFolder1)).getText().trim();
	}

	public void validateExpression(String expression) {
		// TODO Auto-generated method stub
		textareaexp.clear();
		textareaexp.sendKeys(expression);
	}

	public void clickFirstRecordandCallAddToFolderMethod(String folderName) {

//		boolean isViewIntPageDisplayed=false;
		UIHelper.waitForPageToLoad(getDriver());
		System.out.println("--------------1----------------------");
		getDriver().findElement(By.xpath("//*[@id='main']//table[@class='results full']/tbody/tr[1]/td[2]//a")).click();
//		System.out.println("internationalRequest.isPresent()-----------"+internationalRequest.isPresent());
//		if(internationalRequest.isPresent()){
		UIHelper.waitForPageToLoad(getDriver());
//		waitFor(2000).millisecond();
//		getDriver().findElement(By.xpath("//*[@id='options']//input[@value='View Report']")).click();
		System.out.println("--------------2----------------------");
		getDriver().findElement(By.xpath("//*[@id='entity_header']//*[@id='pp_side_icon']//li//a//span[contains(.,'Add to Folder')]")).click();
//		ecfPage.ecfAddtoFolder(folderName);
		getDriver().switchTo().frame(iFrameEle);
		System.out.println("--------------3----------------------");
	
		new Select(getDriver().findElement(By.xpath("//div[@class='ecfaddfo']//select[@id='to_folder_id']"))).selectByVisibleText(folderName);
		getDriver().findElement(By.xpath("//form[@id='addToFolderForm']//div[@class='modal_buttons']//input[@id='submit_ecf']")).click();
//		clickToAddFolderButton(folderName);
		getDriver().switchTo().defaultContent();
		System.out.println("--------------4----------------------");
		
//		}
		/*else{
			System.out.println("I am in the else block");
			UIHelper.waitForPageToLoad(getDriver());
			waitFor(5000).millisecond();
			System.out.println("--------------2----------------------");
			getDriver().findElement(By.xpath("//*[@id='entity_header']//*[@id='pp_side_icon']//li//a//span[contains(.,'Add to Folder')]")).click();
//			ecfPage.ecfAddtoFolder(folderName);
			System.out.println("--------------3----------------------");
			clickToAddFolderButton(folderName);
			System.out.println("--------------4----------------------");
			System.out.println("ecfPage.ecfAddtoFolder(folderName)is called "+folderName);
		}*/
	}

	public boolean verifyHasAddedToFolder(String dunsNumber, String foldername) {
		// TODO Auto-generated method stub
		System.out.println("inside verifyHasAddedToFolder method------------------------------------");
		compHref.click();
		
		WebElement folderStored=getDriver().findElement(By.xpath("//form[@action='showAllFolderSummary']//table[@class='results full']//tbody//tr//td/a[contains(.,'"+foldername+"')]"));
		folderStored.click();
		UIHelper.waitForPageToLoad(getDriver());
		
		WebElement liveReportValidate=getDriver().findElement(By.xpath("//table[@class='results full_company']//tbody//tr//td/span/a[contains(.,'"+dunsNumber+"')]"));
		if(liveReportValidate.isDisplayed())
			return true;
		else 
			return false;
		
		
		
//		lnkCreateNewFolder.waitUntilPresent();
////      snapshotlink.waitUntilPresent();
//System.out.println("inside folder click method------------------------------");
//Foldername = (getDriver().findElement(By.xpath("//div[@id='tab1']//table[@class='results full']//tr//td//a[contains(text(),'"+foldername+"')]")));
//// *[@action='showAllFolderSummary']//tbody//*[contains(@class,'RowGray')]//td[contains(@class,'leftAlign')]//a[contains(.,'Snapshots')]
//if (Foldername.isDisplayed()) {
//	System.out.println("folder has displayed-----------------------");
//	UIHelper.highlightElement(getDriver(), Foldername);
//	Foldername.click();
//	
//
//}

	}

	public void clickOnAddFolderButton(String folderName) {
		// TODO Auto-generated method stub
		getDriver().findElement(By.xpath("//div[@id='main']//input[@value='Add to Folder']")).click();		
		System.out.println("222222222222222222222222");
		waitFor(3000).milliseconds();		
		getDriver().switchTo().frame(iFrameEle);
		System.out.println("33333333333333333333333");
		Select mySelect= new Select(getDriver().findElement(By.xpath("//body[@class='iframe_modal']//form[@id='addToFolderForm']//select[@id='to_folder_id']")));
		mySelect.selectByVisibleText(folderName);
		System.out.println("444444444444444444444");
		getDriver().findElement(By.xpath("//body[@class='iframe_modal']//form[@id='addToFolderForm']//input[@id='submit_ecf']")).click();	
		System.out.println("5555555555555555555555555");
		waitFor(300).milliseconds();	
		getDriver().switchTo().defaultContent();
	}

	public void clickToAddFolderButton(String folderName) {
		// TODO Auto-generated method stub
//		getDriver().findElement(By.xpath("//div[@id='main']//input[@value='Add to Folder']")).click();		
		System.out.println("222222222222222222222222");
		waitFor(3000).milliseconds();		
		getDriver().switchTo().frame(iFrameEle);
		System.out.println("33333333333333333333333");
		Select mySelect= new Select(getDriver().findElement(By.xpath("//body[@class='iframe_modal']//form[@id='addToFolderForm']//select[@id='to_folder_id']")));
		mySelect.selectByVisibleText(folderName);
		System.out.println("444444444444444444444");
		getDriver().findElement(By.xpath("//body[@class='iframe_modal']//form[@id='addToFolderForm']//input[@id='submit_ecf']")).click();	
		System.out.println("5555555555555555555555555");
		waitFor(300).milliseconds();	
		getDriver().switchTo().defaultContent();
	}

	public void clickPrecountFilter() {
		
		preCountFilterBtn.click();
		waitFor(300).milliseconds();
		UIHelper.waitForPageToLoad(getDriver());
		getDriver().switchTo().frame("__modal_iframe_target");
		waitFor(3000).milliseconds();
		UIHelper.waitForPageToLoad(getDriver());
		String value=getDriver().findElement(By.xpath("//div[@id='filt_modalContent1']//div[@id='widget_container1']")).getText().trim();
		prefiltercount=Integer.parseInt(value);
		getDriver().findElement(By.xpath("//input[@id='preCountResultBtn']")).click();
		getDriver().switchTo().defaultContent();
	}

	public boolean clickFilterandverifycount(String filterName) {
		// TODO Auto-generated method stub
		int size=getDriver().findElements(By.xpath("//div[@id='tab2']//table[@class='results full']/tbody//tr")).size();
		System.out.println("table sixze======="+size);
		for (int i = 1; i < size; i++) {
			String text=getDriver().findElement(By.xpath("//div[@id='tab2']//table[@class='results full']/tbody/tr["+i+"]/td[1]/a")).getText().trim();
			System.out.println("000000000000000000000000000"+text+")))))))))))))))))))))))))))))"+filterName);
			if(filterName.equalsIgnoreCase(text)){
				getDriver().findElement(By.xpath("//div[@id='tab2']//table[@class='results full']/tbody/tr["+i+"]/td[1]/a")).click();
				break;
			}
		}
		//after the for loop validate the count
		String val=getDriver().findElement(By.xpath(" //*[@id='main']//form[@name='additionalForm']//li//strong[2]")).getText().trim();
		int count=Integer.parseInt(val);
		System.out.println("from filter count value--------"+count+"Precount filter value------"+prefiltercount);
		if(count==prefiltercount){
			return true;
		}
		return false;
	}

	public void clickAdvancecdPrecountFilter() {
		// TODO Auto-generated method stub
		advPreCountFilterResults.click();
		waitFor(3000).milliseconds();
		getDriver().switchTo().frame("__modal_iframe_target");
		waitFor(3000).milliseconds();
		String value=getDriver().findElement(By.xpath("//div[@id='widget_container1']/strong")).getText().trim();
		advprefiltercount=Integer.parseInt(value);
		getDriver().findElement(By.xpath("//div[@id='filter_precount_result']//input[@id='preCountResultBtn']")).click();
		getDriver().switchTo().defaultContent();
	}

	public void clickonTheavilableUser(String user) {
		// TODO Auto-generated method stub
		waitFor(3000).milliseconds();
		getDriver().findElement(By.xpath("//*[@id='Role_alerts']/tbody//tr//td[contains(.,'"+user+"')]/input[@type='checkbox']")).click();
	}

	public boolean verifyUserisVisible(String user) {
		
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),"//div[@id='tab_contents']//table[@id='srcRecordList']//tr");
				int size = getDriver().findElements(By.xpath("//div[@id='tab_contents']//table[@id='srcRecordList']//tr")).size();
//				System.out.println("table size--------" + size);
				for (int i = 2; i <= size; i++) {
					String value = getDriver().findElement(By.xpath("//div[@id='tab_contents']//table[@id='srcRecordList']//tr["+ i +"]/td[1]/a")).getText().trim();
					System.out.println("table VALUES DISPLAYED--------" + value+"paramerevalue----------"+user);
					if (value.equalsIgnoreCase(user)) {
						return true;
					}
				}
				return false;
			}

	public void clickOnFolderNameandgetCountOfRecored(String folderName) {
		// TODO Auto-generated method stub
		
		getDriver().findElement(By.xpath("//div[@id='tab1']//form[@name='additionalHeaderForm']//table[@class='results full']/tbody//tr/td[2]/a[contains(.,'"+folderName+"')]")).click();
		UIHelper.waitForPageToLoad(getDriver());
		primeUserCount=getDriver().findElements(By.xpath("//*[@id='main']//table[@class='results full_company']/tbody/tr")).size();
		
		
	
	}

	public boolean clickOnSharedFolderNameandgetCountOfRecored(String folderName) {
		// TODO Auto-generated method stub
		getDriver().findElement(By.xpath("//div[@id='tab1']//form[@name='additionalHeaderForm']//table[@class='results full']/tbody//tr/td[2]/a[contains(.,'"+folderName+"')]")).click();
		UIHelper.waitForPageToLoad(getDriver());
		sharedUserCount=getDriver().findElements(By.xpath("//*[@id='main']//table[@class='results full_company']/tbody/tr")).size();
		if(sharedUserCount==primeUserCount){
			System.out.println("shareFolderEcf-----"+sharedUserCount+"primeUserCount-----------"+primeUserCount);
		return true;
		}
		return false;
	}
	

	
}
