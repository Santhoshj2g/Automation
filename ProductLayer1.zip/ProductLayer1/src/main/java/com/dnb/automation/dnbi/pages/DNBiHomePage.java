package com.dnb.automation.dnbi.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * HomePage.java - This class contains method for navigate to home page
 * 
 * @author Duvvuru Naveen
 * @version 1.0
 ***********************************************************************************************/
public class DNBiHomePage extends PageObject {

    @FindBy(xpath = "//*[@id='primaryNav']//a[contains(text(),'Dashboard')]")
    private WebElementFacade dashboardTabEle;

    @FindBy(xpath = "//a[contains(text(),'Companies')]")
    private WebElementFacade CompaniesTabEle;

    @FindBy(xpath = "//div[@id='header_mainApp']/div[@class='primaryNav_div']/ul/li[@id='activeTab']/a")
    private WebElementFacade activeTabEle;

    @FindBy(xpath = "//*[@id='page_title_links']/h2")
    private WebElementFacade dashboardPageTitleEle;

    @FindBy(xpath = ".//*[@id='header_mainApp']//*[@id='primaryNav']//*[contains(text(),'Admin')]")
    private WebElementFacade tabAdmin;
    
    @FindBy(xpath = "//*[@class='outerDiv']//*[@id='quicksearch_more_options' and contains(text(),'Fewer')] | //*[@class='outerDiv']//*[@id='search_box']//*[@class='moreOpt']//*[@id='quicksearch_more_options' and contains(text(),'More')]")
    private WebElementFacade fewerORMoreOptionsEle;
    @FindBy(xpath = "//iframe[@name='__modal_iframe_target']")
   	private WebElementFacade iFrameEle;
    @FindBy(xpath = "//div[@class='modal_inner_content']")
   	private WebElementFacade modelEle;
  
    @FindBy(xpath = "//*[@id='header_toolbar']//li//a[contains(.,'My Profile')][1]")
    private WebElementFacade myProfileLink;
    @FindBy(xpath="//div[@class='modal_content']//*[@id='modal_buttons']/input[contains(@onclick,'DontSave')]")
    private WebElementFacade DontsaveASnapshotEle;
    String imgLoading = "//span[contains(text(),'Loading')]";
    private String title="//*[@id='page_title_links']/h2";
    private String dashboard="//*[@id='primaryNav']//a[contains(text(),'Dashboard')]";
    private String myProfilexpath="//*[@id='header_toolbar']//li//a[contains(.,'My Profile')]";
    private String myprofiletable = "//*[@id='main']//*[@class='widget_form']//table";
    public void navigateToHomeTab() {
    	UIHelper.waitForPageToLoad(getDriver());
    	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), myProfilexpath);
    	UIHelper.highlightElement(getDriver(), myProfileLink);
    	
    	myProfileLink.waitUntilClickable();
    	myProfileLink.click();
    	try{
          	 ((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", DontsaveASnapshotEle);
          	 
       	}catch(Exception T){
        	  
          }
    	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), dashboard);
    	((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", dashboardTabEle);
    	UIHelper.waitForPageToLoad(getDriver());
    	UIHelper.highlightElement(getDriver(), dashboardTabEle);
        dashboardTabEle.click();
        	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), title);
           /* UIHelper.waitForPageToLoad(getDriver());
            UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgLoading);*/
//            tabAdmin.waitUntilPresent();
//            dashboardPageTitleEle.waitUntilPresent();
//            UIHelper.highlightElement(getDriver(), dashboardPageTitleEle);
//            fewerORMoreOptionsEle.waitUntilPresent();
//            UIHelper.highlightElement(getDriver(), fewerORMoreOptionsEle);
//            System.out.println("inside navigate home tab method");
        	
    }
    public void myprofile() {
    	UIHelper.waitForPageToLoad(getDriver());
    	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), myProfilexpath);
    	UIHelper.highlightElement(getDriver(), myProfileLink);
    	myProfileLink.waitUntilClickable();
    	myProfileLink.click();
    	UIHelper.waitForPageToLoad(getDriver());
    }
    public void gotoCompaniesTab() {        
           myProfileLink.click();
              try{
         		
               	 ((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", DontsaveASnapshotEle);
               	
            	}catch(Exception s){
             	  
               }
        	   CompaniesTabEle.click();
        	   UIHelper.waitForPageToLoad(getDriver());
        	   UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgLoading);
    }
    
    public void gotoDashboardTab() {        
        UIHelper.highlightElement(getDriver(), dashboardTabEle);
        dashboardTabEle.click();
     	UIHelper.waitForPageToLoad(getDriver());
     	UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), imgLoading);
//     	waitFor(5000).milliseconds();
    }
    

    public String getHomePageTitle() {
//    	dashboardTabEle.click();
//        UIHelper.waitForPageToLoad(getDriver());
//        tabAdmin.waitUntilPresent();
//    	dashboardPageTitleEle.waitUntilVisible();
        return dashboardPageTitleEle.getText();
    }

	
	}