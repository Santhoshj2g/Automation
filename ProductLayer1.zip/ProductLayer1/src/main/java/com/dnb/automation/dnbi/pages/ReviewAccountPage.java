package com.dnb.automation.dnbi.pages;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.dnb.automation.utils.UIHelper;

/**********************************************************************************************
 * ReviewAccountPage.java - This class contains method for Review Account Page
 * 
 * @author Duvvuru Naveen
 * @version 1.0
 ***********************************************************************************************/
public class ReviewAccountPage extends PageObject {
	private final Logger log = Logger.getLogger(this.getClass().getPackage()
			.getName());

	@FindBy(xpath = "//*[@id='loginForm']//p//label")
	private WebElementFacade rememberDnbID;

	@FindBy(xpath = "//*[@id='primaryNav']//a[contains(.,'Admin')]")
	private WebElementFacade adminTabNav;

	@FindBy(xpath = "//*[@id='main']//a[contains(.,'Account Manager Admin')]")
	private WebElementFacade accManagerAdmin;

	@FindBy(xpath = "//*[@id='main']//a[contains(.,'Data Management')]")
	private WebElementFacade dataManagement;

	@FindBy(xpath = ".//*[@id='page_title']/h2")
	private WebElementFacade PgTitleEle;

	@FindBy(xpath = "//*[@class='widget ad_widget_portfolio']//*[@id='main']//a[contains(.,'Account Manager')]")
	private WebElementFacade reviewAccFrame;

	@FindBy(xpath = "//*[@id='main']//a[contains(.,'Review Accounts')]")
	private WebElementFacade accReviewLink;

	@FindBy(xpath = "//*[@id='main']//*[@class='widget ad_widget_portfolio']//a[contains(.,'Clear Account Statuses')]")
	private WebElementFacade accClearAccStatusLink;

	@FindBy(xpath = "//*[@id='main']//a/strong[contains(.,'Delete Credit Files')]")
	private WebElementFacade deleteCreditFilesLink;

	@FindBy(xpath = "//*[@id='page_title'][contains(.,'Review Accounts')]")
	private WebElementFacade accountReviewPage;

	@FindBy(xpath = "//*[@class='review_accounts']//*[@value='Review Accounts']")
	private WebElementFacade reviewAccBtn;

	@FindBy(xpath = "//*[@class='clear']//*[@id='clearButtonId']")
	private WebElementFacade clearSelectedBtn;

	@FindBy(xpath = "//*[@id='adminLayout']//table//td[@class='comcopy']//input//ancestor::td[contains(.,'(')]")
	private List<WebElementFacade> clearcheckboxes;

	@FindBy(xpath = "//*[@id='main']//*[@value='Submit']")
	private WebElementFacade submitBtn;

	@FindBy(xpath = "//*[@id='reviewAccountForm']//*[@value='Run Automated Account Review']")
	private WebElementFacade runAutoAccountReviewBtn;

	@FindBy(xpath = "//*[@id='page_title'][contains(.,'Run Automated Account Review')]")
	private WebElementFacade runAutoAccountReviewPage;

	@FindBy(xpath = "//*[@id='main']/table/tbody/tr/td[1]")
	private WebElementFacade reviewStatus;

	@FindBy(xpath = "//*[@id='reviewAccountForm']//*[@class='alert_box'][contains(.,'The system has not detected a recent A/R or D&B batch file import')]")
	private WebElementFacade warningForm;

	@FindBy(xpath = "//*[@id='main']/div[contains(.,'An automated account review is currently running. You will not be able to start another review until it is complete.')]")
	private WebElementFacade activeAlertMsgEle;

	@FindBy(xpath = "//*[@id='reviewAccountForm']/p//*[@value='OK']")
	private WebElementFacade warningOkBtn;

	@FindBy(xpath = "//*[@class='results ']//*[@align='left'][contains(.,'Scheduled')]")
	private WebElementFacade acctReviewStat;

	@FindBy(xpath = "//*[@id='backMiddle']//*[@value='Home']")
	private WebElementFacade warningPageHomebtn;

	@FindBy(xpath = "//*[@id='main']//*[@class='review_accounts']//table[@class='results full']//tbody//tr[1]//td[1]//a")
	private WebElementFacade reviewedAcntStatusEle;

	@FindBy(xpath = "//*[@id='main']//*[@class='review_accounts']//table[@class='results full']//tbody//tr[1]//td[1]//a")
	private WebElementFacade mainStatusEle;

	@FindBy(xpath = "//*[@id='primaryNav']//a[contains(.,'Dashboard')]")
	private WebElementFacade dashboardTab;

	@FindBy(xpath = "//*[@class='frmView'][contains(.,'Completed')]")
	private WebElementFacade homeWindowStatus;

	@FindBy(xpath = "//*[@class='frmTitle'][contains(.,'Total Number of Accounts in system')]//following-sibling::td")
	private WebElementFacade homeWindowAccCount;

	@FindBy(xpath = "//*[@id='primaryNav']//a[contains(.,'Account Manager')]")
	private WebElementFacade accTabNavigation;

	@FindBy(xpath = "//*[@id='primaryNav']//a[contains(.,'Admin')]")
	private WebElementFacade adminTabNavi;

	@FindBy(xpath = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[contains(.,'No Action Recommended')]//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']")
	private WebElementFacade accInboxAllAccCount;

	@FindBy(xpath = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[contains(.,'All Accounts')]//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']")
	private WebElementFacade allAccCountcount;

	@FindBy(xpath = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[contains(.,'Credit Hold Advised')]//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']")
	private WebElementFacade creditHoldcount;

	@FindBy(xpath = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[contains(.,'Credit Review Required')]//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']")
	private WebElementFacade creditReviewcount;

	@FindBy(xpath = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[contains(.,'Collections Required')]//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']")
	private WebElementFacade collectionRequiredcount;

	@FindBy(xpath = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[contains(.,'Credit Increase Recommended')]//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']")
	private WebElementFacade creditIncreasecount;

	@FindBy(xpath = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[contains(.,'Credit Hold Advised')]")
	private WebElementFacade creditHoldAdvisedLink;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[contains(@class,'results full')]//thead")
	private WebElementFacade accountsTableHeader;

	@FindBy(xpath = "//*[@class='outerDiv']//*[@id='main']//*[contains(@class,'results full')]//tr[1]//td[1]//a")
	private WebElementFacade accountNumber;

	@FindBy(xpath = "//*[@id='compTitle']//*[contains(.,'Company Summary')]")
	private WebElementFacade companySummarySection;
	private String companySmrSection = "//*[@id='compTitle']//*[contains(.,'Company Summary')]";

	@FindBy(xpath = "//*[@id='widget_container']//*[contains(@class,'review_box')]//*[@class='review_buttons']//input[@value='Send to Credit Manager']")
	private WebElementFacade sendToCreditManagerBtn;

	@FindBy(xpath = "//*[contains(@class,'review_box')]//*[@class='review_buttons']//input[@value='Place on Credit Hold']")
	private WebElementFacade placeOnCreditHoldBtn;

	/*
	 * @FindBy(xpath
	 * ="//*[@class='iframe_modal']//*[@class='modal_inner_content']") private
	 * WebElementFacade Iframepopup;
	 */
	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
	private WebElementFacade Iframepopup;

	@FindBy(xpath = "//*[@class='modal_inner_content']//*[@class='ecfanalystReasons']//*[@class='comcopyarea']//b[contains(.,'Next')]")
	private WebElementFacade nextBtnIframe;

	@FindBy(xpath = "//*[@class='iframe_modal']//*[@class='modal_buttons']//*[@value='Continue']")
	private WebElementFacade continueBtn1;

	@FindBy(xpath = "//*[@id='deleteForm']//input[@value='ACCOUNT']")
	private WebElementFacade accountcheckbox;

	@FindBy(xpath = "//*[@id='main']//*[@class='customize_block']//a[contains(.,'Customize')]")
	private WebElementFacade customizeLink;

	@FindBy(xpath = "//*[@class='customize_popup']//p//span//select[@class='customize_sel']")
	private WebElementFacade sortTheTableByList;

	@FindBy(xpath = "//*[@class='customize_popup']//p//span//select[@class='select_order']")
	private WebElementFacade sortOrderList;

	@FindBy(xpath = "//*[@class='customize_popup']//input[@value='Submit'][@type='Button']")
	private WebElementFacade cSubmitBtn;

	@FindBy(xpath = "//*[@id='dd_inboxR']//table//tbody//tr[1]//td[3]")
	private WebElementFacade dateCreatedText;

	@FindBy(xpath = "//*[@id='main']//*[@class='viewMoreBtn']//*[@value='View Details' or 'View More'][@type='button']")
	private WebElementFacade viewMoreBtn;

	@FindBy(xpath = "//*[@id='page_title_links']//h2")
	private WebElementFacade allAccPageHeader;

	@FindBy(xpath = "//*[@id='header_mainApp']//li//a[contains(.,'Companies')]")
	private WebElementFacade CompaniesTabEle;

	@FindBy(xpath = "//*[@id='main']//*[@id='filter_tab']")
	private WebElementFacade filterTab;

	@FindBy(xpath = "//*[@id='tab2']//*[@id='button_createFilterID']")
	private WebElementFacade createNewFilterBtn;

	@FindBy(xpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']")
	private WebElementFacade iFrameElement;

	@FindBy(xpath = "//*[@id='CallcreditSearch']//*[@class='modal_buttons']//input[contains(@value,'Submit')]")
	private WebElementFacade modelSumbmitButton;

	@FindBy(xpath = "//*[@id='main']//*[@id='entity_category']")
	private WebElementFacade selectFilterType;

	@FindBy(xpath = "//*[@id='main']//*[@id='filter_name']")
	private WebElementFacade FilternameEle;

	@FindBy(xpath = "//*[@id='main']//*[@id='data_category']")
	private WebElementFacade selectFilterCategory;

	@FindBy(xpath = "//*[@id='main']//*[@id='addDataFieldsAnd']")
	private WebElementFacade fieldsAddBtn;

	@FindBy(xpath = "//*[@class='modal_content']//*[@id='filt_fieldName']")
	private WebElementFacade valueTextField;

	@FindBy(xpath = "//*[@class='modal_content']//span//a//strong[.='Add']")
	private WebElementFacade valueAddBtn;

	@FindBy(xpath = "//*[@class='modal_content']//*[@class='modal_buttons']//*[@id='modal_filt_variableBtn']")
	private WebElementFacade valueSubmitBtn;

	@FindBy(xpath = "//*[@id='main']//*[@id='form_submit']")
	private WebElementFacade filterSaveBtn;

	@FindBy(xpath = "//*[@class='modal_content']//*[@id='filt_fieldValueList']")
	private WebElementFacade fieldValueTextbox;

	@FindBy(xpath = "//*[@class='modal_content']//*[@class='Amodal_buttons']//*[@id='modal_filtSysMsgBtn']")
	private WebElementFacade deleteYesButton;

	@FindBy(xpath = "//*[@class='modal_content']//*[@id='addCntry']//img")
	private WebElementFacade countryAddBtn;

	@FindBy(xpath = "//*[@class='modal_content']//*[@ class='modal_buttons']//*[@id='countrySeleBtn']")
	private WebElementFacade countrySubmitBtn;

	@FindBy(xpath = "//*[@class='modal_content']//*[@class='filter_cntrySelTable']")
	private WebElementFacade countrySelectedList;

	@FindBy(xpath = "//*[@id='main']//input[@value='Show Filter Options'][@type='button']")
	private WebElementFacade showFilterOptionsBtn;

	@FindBy(xpath = "//*[@id='filter_cover']//*[@value='Select Filter']")
	private WebElementFacade selectFilterElement;

	@FindBy(xpath = "//*[@id='filter_cover']//input[@value='Apply Filter']")
	private WebElementFacade applyFilterBtn;

	@FindBy(xpath = "//*[@id='dd_inboxR']//table//tbody//tr//td[2]")
	private List<WebElementFacade> accountResutlsList;

	@FindBy(xpath = "//*[@id='main']//table//tbody//tr//td[3]")
	private List<WebElementFacade> accountViewMoreResutlsList;

	@FindBy(xpath = "//*[@id='main']//input[@value='Reset List'][@type='button']")
	private WebElementFacade resetListBtn;

	@FindBy(xpath = "//*[@id='main']//*[@id='folder_tab']")
	private WebElementFacade foldersTab;

	@FindBy(xpath = "//*[@id='viewItems']")
	private WebElementFacade viewItemsList;

	@FindBy(xpath = "//*[@id='main']//*[@id='tab1']//*[@class='floatLeft']//*[@action='showAllFolderSummary']//tbody//td[2]//a")
	private List<WebElementFacade> foldersNameList;

	@FindBy(xpath = "//*[@id='main']//*[@value='Create New Folder']")
	private WebElementFacade createNewFolderBtn;

	@FindBy(xpath = "//*[@id='alertprofile']//*[@name='folderName'][@type='text']")
	private WebElementFacade FolderNameText;

	@FindBy(xpath = "//*[@id='alertprofile']//*[@id='user_profile_id']")
	private WebElementFacade alertProfileName;

	@FindBy(xpath = "//*[@id='folderOptionsForm']//*[@id='smart_folder_submit']")
	private WebElementFacade folderSubmitButton;

	@FindBy(xpath = "//*[@id='main']//table//tbody//tr[1]//td[1]//input[@type='checkbox']")
	private WebElementFacade firstRowAccNoRecord;

	@FindBy(xpath = "//*[@id='main']//*[@value='Add to Folder']")
	private WebElementFacade addToFolderBtn;

	@FindBy(xpath = "//*[@id='ecfaddfolder']//*[@id='to_folder_id']")
	private WebElementFacade selectFolder;

	@FindBy(xpath = "//*[@id='addToFolderForm']//*[@id='submit_ecf']")
	private WebElementFacade cFSubmitButton;

	@FindBy(xpath = "//*[@id='main']//table//tbody//tr[1]//td[2]//a")
	private WebElementFacade firstRowAccNo;
	@FindBy(xpath = "//*[@id='main']//table//tbody//tr[1]//td[2]//a")
	private List<WebElementFacade> accountListinFolder;

	@FindBy(xpath = "//*[@id='main']//*[@value='Delete']")
	private WebElementFacade deleteBtn;

	@FindBy(xpath = "//*[@id='dd_inboxR']//table//thead")
	private WebElementFacade resultList;

	@FindBy(xpath = "//*[@id='main']//form//ul//li//strong[2]")
	private WebElementFacade viewPageCount;

	@FindBy(xpath = "//*[@id='main']//form//ul//li//a[contains(.,'Next')]")
	private WebElementFacade viewPageNextBtn;

	@FindBy(xpath = "//*[@class='modal_buttons']//*[@value='Delete']")
	private WebElementFacade modelDeleteBtn;

	@FindBy(xpath = "//*[@id='main']//table//thead")
	private WebElementFacade accTablethead;

	@FindBy(xpath = "//*[@id='main']//*[@id='preCountBtn']")
	private WebElementFacade precountFilterResultsBtn;

	@FindBy(xpath = "//*[@id='filter_precount_result']//*[@id='widget_container1']")
	private WebElementFacade totalNumberOfRecrods;

	@FindBy(xpath = "//*[@id='filter_precount_result']//input[@id='preCountResultBtn']")
	private WebElementFacade precountResultsOkBtn;

	@FindBy(xpath = "//*[@id='dd_inboxR']//*[@class='results full_company']//tbody//tr[contains(.,'United States Of America')][1]//preceding-sibling::td/a")
	private WebElementFacade clickfirstusaccount;
	@FindBy(xpath = "//*[@id='main']//*[@class='tools'][1]//ul/li/strong[2]")
	private WebElementFacade filterResultCount;

	@FindBy(xpath = "//*[@id='main']//*[@class='tools'][1]//ul/li/strong")
	private WebElementFacade filterResultCount1;
	@FindBy(xpath = "//*[@id='main']//*[@id='schedule_export']")
	private WebElementFacade scheduleFilterTab;
	@FindBy(xpath = "//*[@id='main']//*[@id='schedule_export']")
	private WebElementFacade ScheduleFilterTabEle;
	@FindBy(xpath = "//*[@class='iframe_modal']//form[@id='createFolderForm']//*[@id='NewFolderName']")
	private WebElementFacade folderNameTxt;
	@FindBy(xpath = "//form[@id='DataForm1']//tbody//select[@id='selectFolder']")
	private WebElementFacade folderNameSelect;
	@FindBy(xpath = "//*[@id='DataForm1']/table/tbody/tr[3]/td[2]/a")
	private WebElementFacade createNewFolderEle;
	@FindBy(xpath = "//*[@id='main']//table//thead")
	private WebElementFacade accTableXpathelement;
	@FindBy(xpath = "//*[@id='viewItems']")
	private WebElementFacade viewItems;
	String filtercategory = "//*[@id='main']//*[@id='data_category']";
	private String rStatus;
	private WebElement checkboxclear;
	private WebElement checkboxclear1;
	private String clear1;
	private String clear4;
	String clearAccountBTN = "//*[@class='clear']//*[@id='clearButtonId']";
	String clearAccountStatus = "//*[@id='main']//*[@class='widget ad_widget_portfolio']//a[contains(.,'Clear Account Statuses')]";
	String accountResultsTableXpath = "//*[@id='dd_inboxR']//table//thead";
	String accountViewMoreResultsTableXpath = "//*[@id='main']//table//tbody//tr//td[3]";
	String sortTheTableByListXpath = "//*[@class='customize_popup']//p//span//select[@class='customize_sel']";
	String allAccPageHeaderXpath = "//*[@id='page_title_links']//h2";
	String cnfBtnxpath = "//*[@id='main']//*[@class='compHome_newFolder']//input[@value='Create New Folder']";
	String filtersTableHeaderXpath = "//*[@id='main']//*[@id='tab2']//form//table//thead";
	String framexpath = "//*[@class='modal']//*[@class='modal_content']//iframe[@name='__modal_iframe_target']";
	String valueTextFieldXpath = "//*[@class='modal_content']//*[@id='filt_fieldName']";
	String countryFieldXpath = "//*[@class='modal_content']//*[@class='filter_cntrySelTable']";
	String conditionTableExpath = "//*[@id='main']//table[@class='data_table']//tr[1]";
	String deleteYesButtonXpath = "//*[@class='modal_content']//*[@class='Amodal_buttons']//*[@id='modal_filtSysMsgBtn']";
	String selectFilterXpath = "//*[@id='filter_cover']//*[@value='Select Filter']";
	String foldersTableHeaderXpath = "//*[@id='main']//*[@id='tab1']//form//table//thead";
	String foldersTableXpath = "//*[@id='main']//*[@id='tab1']//form//table//tbody";
	String FolderNameTextXpath = "//*[@id='alertprofile']//*[@name='folderName'][@type='text']";
	String accTableXpath = "//*[@id='main']//table//thead";
	String tablerowsXpath = "//*[@id='main']//table/tbody/tr";
	String filterSettingXpath = "//*[@id='DataForm1']/h3";
	boolean processScheduled;

	private static int AllAccountsCount;

	public static int getAllAccountsCount() {
		return AllAccountsCount;
	}

	private static int precountAccountResutls;

	public static int getPrecountAccountResutls() {
		return precountAccountResutls;
	}

	private static int precountApplicatonResutls;

	public static int getPrecountApplicatonResutls() {
		return precountApplicatonResutls;
	}

	private static int precountLivereportResutls;

	public static int getPrecountLivereportResutls() {
		return precountLivereportResutls;
	}

	private static int precountSnapshotResutls;

	public static int getPrecountSnapshotResutls() {
		return precountSnapshotResutls;
	}

	private static String numberText;

	
	public boolean getProcessScheduled() {
		return processScheduled;
	}

	boolean processCompleted;

	public boolean getProcessCompleted() {
		return processCompleted;
	}

	String windowAccCount;

	public String getWindowAccCount() {
		return windowAccCount;
	}

	String accMgrInboxCount;

	public String getAccMgrInboxCount() {
		return accMgrInboxCount;
	}

	public String parentWindow;

	public static long allnoAcRecommendedCount;

	public static long getAllnoAcRecommendedCount() {
		return allnoAcRecommendedCount;
	}

	public static long allAllAccountsCount;

	public static long getAllAllAccountsCount() {
		return allAllAccountsCount;
	}

	public static long myNoAcRecommendedCount;

	public static long getMyNoAcRecommendedCount() {
		return myNoAcRecommendedCount;
	}

	public static long myallAccountsCount;

	public static long getMyallAccountsCount() {
		return myallAccountsCount;
	}

	public static long allnoAcRecommendedCountAfter;

	public static long getAllnoAcRecommendedCountAfter() {
		return allnoAcRecommendedCountAfter;
	}

	public static long allAllAccountsCountAfter;

	public static long getAllAllAccountsCountAfter() {
		return allAllAccountsCountAfter;
	}

	public static long myNoAcRecommendedCountAfter;

	public static long getMyNoAcRecommendedCountAfter() {
		return myNoAcRecommendedCountAfter;
	}

	public static long myallAccountsCountAfter;

	public static long getMyallAccountsCountAfter() {
		return myallAccountsCountAfter;
	}

	private static long app_count;

	public static long getApp_count() {
		return app_count;
	}

	public void gotoReviewAccountPage() {
		adminTabNav.waitUntilPresent();
		if (adminTabNav.isVisible()) {
			adminTabNav.click();
			accManagerAdmin.waitUntilPresent();
			UIHelper.waitForPageToLoad(getDriver());
			accManagerAdmin.click();

			accReviewLink.waitUntilPresent();
			UIHelper.waitForPageToLoad(getDriver());
			if (accReviewLink.isVisible()) {
				accReviewLink.click();
				reviewAccBtn.waitUntilPresent();
				UIHelper.waitForPageToLoad(getDriver());
			}
		}
	}

	public void gotoDeleteCreditFilesPage() {
		adminTabNav.waitUntilPresent();
		if (adminTabNav.isVisible()) {
			adminTabNav.click();
			dataManagement.waitUntilPresent();
			dataManagement.click();
			deleteCreditFilesLink.waitUntilPresent();
			if (deleteCreditFilesLink.isVisible()) {
				deleteCreditFilesLink.click();
				submitBtn.waitUntilPresent();
				UIHelper.highlightElement(getDriver(), submitBtn);
			}
		}
	}

	public String getPageTitle() {
		return PgTitleEle.getText();
	}

	public void deleteAccounts() {
		if (accountcheckbox.isVisible()) {
			accountcheckbox.click();
			submitBtn.click();
			UIHelper.processalert(getDriver());
		}
	}

	public void validateAccountReviewStatus() {
		try {
			if (reviewAccBtn.isVisible()) {
				reviewAccBtn.waitUntilClickable();
				reviewAccBtn.click();
				runAutoAccountReviewPage.waitUntilPresent();

				UIHelper.waitForPageToLoad(getDriver());

				/*
				 * if (!((activeAlertMsgEle.getText())
				 * .contains("currently running"))) {
				 */
				if (runAutoAccountReviewBtn.isVisible()) {
					runAutoAccountReviewBtn.click();
					UIHelper.waitForPageToLoad(getDriver());
					if (warningForm.isVisible()) {
						// warningOkBtn.waitUntilPresent();
						warningOkBtn.click();
						warningPageHomebtn.waitUntilClickable();
						acctReviewStat.waitUntilPresent();
					}
				}
				// }

				if (acctReviewStat.getText().contains("Scheduled")) {
					processScheduled = true;
				} else {
					processScheduled = false;
				}
				System.out.println("review status-------------------"
						+ processScheduled);
				warningPageHomebtn.click();
				UIHelper.waitForPageToLoad(getDriver());
				accReviewLink.waitUntilPresent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public String waitforTheCompletedStatusOfReviewAccount()
			throws InterruptedException {
		try {
			if (accReviewLink.isVisible()) {
				accReviewLink.click();
				UIHelper.waitForPageToLoad(getDriver());
				reviewAccBtn.waitUntilPresent();
				reviewedAcntStatusEle.waitUntilPresent();
			}

			long start = System.currentTimeMillis();
			String storeStatusVal = null;
			long diffInMinutes;

			do {
				if (reviewedAcntStatusEle.isVisible()) {
					String CurrentStatus = reviewedAcntStatusEle.getText()
							.toString().trim();
					if (!CurrentStatus.equalsIgnoreCase("Completed")) {
						storeStatusVal = CurrentStatus;
					} else {
						storeStatusVal = CurrentStatus;
					}

				}

				if (!storeStatusVal.equalsIgnoreCase("Completed")) {
					getDriver().navigate().refresh();
					mainStatusEle.waitUntilPresent();
					UIHelper.waitForPageToLoad(getDriver());
				}

				long end = System.currentTimeMillis();
				long diff = end - start;
				diffInMinutes = TimeUnit.MILLISECONDS.toMinutes(diff);
				waitFor(3).minutes();
				getDriver().navigate().refresh();

			} while (!(storeStatusVal.equalsIgnoreCase("Completed"))
					&& (diffInMinutes < 15));

			rStatus = reviewedAcntStatusEle.getText().toString();
			System.out.println("Review Triggered Status-------" + rStatus);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return rStatus;
	}

	public String getReviewAcntStatus() {
		return reviewedAcntStatusEle.getText();
	}

	public void checkTotalAccountsInAcntMgrTab() {
		mainStatusEle.waitUntilPresent();
		if (reviewedAcntStatusEle.getText().contains("Completed")) {
			processCompleted = true;
		} else {
			processCompleted = false;
		}

		if (processCompleted) {
			dashboardTab.click();
			adminTabNav.waitUntilPresent();
			UIHelper.waitForPageToLoad(getDriver());

			adminTabNav.click();
			accManagerAdmin.waitUntilPresent();
			UIHelper.waitForPageToLoad(getDriver());

			accManagerAdmin.click();
			UIHelper.waitForPageToLoad(getDriver());
			accReviewLink.waitUntilPresent();

			accReviewLink.click();
			reviewAccBtn.waitUntilPresent();
			UIHelper.waitForPageToLoad(getDriver());

			parentWindow = getDriver().getWindowHandle();
			reviewedAcntStatusEle.click();
			for (String childWindow : getDriver().getWindowHandles()) {
				if (!childWindow.equals(parentWindow)) {
					getDriver().switchTo().window(childWindow);
					homeWindowAccCount.waitUntilPresent();
					windowAccCount = homeWindowAccCount.getText().toString();
					getDriver().close();
				}
			}
			getDriver().switchTo().window(parentWindow);
			accTabNavigation.waitUntilPresent();
			accTabNavigation.click();
			accInboxAllAccCount.waitUntilPresent();
			UIHelper.waitForPageToLoad(getDriver());
			accMgrInboxCount = accInboxAllAccCount.getText().toString();
		}
	}

	public boolean verifyAccountsCount() {
		accTabNavigation.waitUntilClickable();
		accTabNavigation.click();
		accInboxAllAccCount.waitUntilPresent();
		System.out.println("No Action Recommended  count--------------------"
				+ accInboxAllAccCount.getText());

		System.out.println("All Accounts  count--------------------"
				+ allAccCountcount.getText());
		if (accInboxAllAccCount.getText().toString().equals("0")
				&& allAccCountcount.getText().toString().equals("0")) {
			return true;
		} else {
			return false;
		}

	}

	public boolean verifyCreditHoldCountafterTriggered(String CreditHoldAdvised) {
		accTabNavigation.waitUntilClickable();
		accTabNavigation.click();
		accInboxAllAccCount.waitUntilPresent();
		System.out.println("Credit Hold Advised count----------------"
				+ creditHoldcount.getText());
		if (creditHoldcount.getText().toString().equals(CreditHoldAdvised)) {
			return true;
		} else {
			return false;
		}

	}

	public boolean verifyCreditReviewdCountafterTriggered(
			String CreditReviewRequired) {

		System.out.println("Credit review  count----------------"
				+ creditReviewcount.getText());
		if (creditReviewcount.getText().toString().equals(CreditReviewRequired)) {
			return true;
		} else {
			return false;
		}

	}

	public boolean verifyCollectionsRequiredCountafterTriggered(
			String CollectionsRequired) {

		System.out.println("Collections Required count----------------"
				+ collectionRequiredcount.getText());
		if (collectionRequiredcount.getText().toString()
				.equals(CollectionsRequired)) {
			return true;
		} else {
			return false;
		}

	}

	public boolean verifyCreditIncreaseCountafterTriggered(
			String CreditIncreaseRecommended) {

		System.out.println("Credit Increase Recommended count----------------"
				+ creditIncreasecount.getText());
		if (creditIncreasecount.getText().toString()
				.equals(CreditIncreaseRecommended)) {
			return true;
		} else {
			return false;
		}

	}

	public void sendToCreditManager() {
		if (creditHoldAdvisedLink.isVisible()) {
			creditHoldAdvisedLink.click();
			accountsTableHeader.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), accountNumber);
			accountNumber.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					companySmrSection);
			UIHelper.highlightElement(getDriver(), companySummarySection);
			sendToCreditManagerBtn.click();

			getDriver().switchTo().frame(Iframepopup);

			if (continueBtn1.isDisplayed()) {
				continueBtn1.click();
			}
			getDriver().switchTo().defaultContent();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					companySmrSection);
		}
	}

	public void placeOnCreditHold() {
		accTabNavigation.waitUntilClickable();
		accTabNavigation.click();
		accInboxAllAccCount.waitUntilPresent();
		if (creditHoldAdvisedLink.isVisible()) {
			creditHoldAdvisedLink.click();
			accountsTableHeader.waitUntilPresent();
			UIHelper.highlightElement(getDriver(), accountNumber);
			accountNumber.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					companySmrSection);
			UIHelper.highlightElement(getDriver(), companySummarySection);
			placeOnCreditHoldBtn.click();
			getDriver().switchTo().frame(Iframepopup);
			nextBtnIframe.click();
			if (continueBtn1.isDisplayed()) {
				continueBtn1.click();
			}
			getDriver().switchTo().defaultContent();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					companySmrSection);
		}
	}

	public void gotoClearAccountStatusesPage() {
		adminTabNav.waitUntilPresent();
		if (adminTabNav.isVisible()) {
			adminTabNav.click();
			accManagerAdmin.waitUntilPresent();
			UIHelper.waitForPageToLoad(getDriver());
			accManagerAdmin.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					clearAccountStatus);

			((JavascriptExecutor) getDriver())
					.executeScript("arguments[0].scrollIntoView(true);",
							accClearAccStatusLink);
			UIHelper.highlightElement(getDriver(), accClearAccStatusLink);
			((JavascriptExecutor) getDriver()).executeScript(
					"arguments[0].click();", accClearAccStatusLink);
			// accClearAccStatusLink.click();

			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), clearAccountBTN);

		}
	}

	public boolean verifyclearAccountsCount() {
		accTabNavigation.waitUntilPresent();
		accTabNavigation.click();
		accInboxAllAccCount.waitUntilPresent();
		System.out.println("No Action Recommended  count--------------------"
				+ accInboxAllAccCount.getText());

		System.out.println("All Accounts  count--------------------"
				+ allAccCountcount.getText());
		if (allAccCountcount.getText().toString()
				.equals(accInboxAllAccCount.getText().toString())) {
			return true;
		} else {
			return false;
		}

	}

	public void selectAllCheckBoxesClrAcStatus(String CHA) {
		clear1 = "//*[@id='adminLayout']//table//td[contains(.,'" + CHA + "')]";
		clear4 = "//*[@id='adminLayout']//table//td[contains(.,'" + CHA
				+ "')]//input";
		checkboxclear = getDriver().findElement(By.xpath(clear1));
		checkboxclear1 = getDriver().findElement(By.xpath(clear4));
		String clear2 = checkboxclear.getText();

		if (clear2.contains("0")) {

		} else {
			checkboxclear1.click();
		}
	}

	public String selectAllCheckBoxesStatus(String CHA) {
		clear1 = "//*[@id='adminLayout']//table//td[contains(.,'" + CHA + "')]";
		checkboxclear = getDriver().findElement(By.xpath(clear1));
		String clear2 = checkboxclear.getText();
		return clear2;
	}

	public void clickClearbtn() {
		clearSelectedBtn.waitUntilClickable();
		clearSelectedBtn.click();
		UIHelper.processalert(getDriver());
		long start = System.currentTimeMillis();
		String storeStatusVal1 = null;
		long diffInMinutes;

		do {
			long end = System.currentTimeMillis();
			long diff = end - start;
			diffInMinutes = TimeUnit.MILLISECONDS.toMinutes(diff);
			if ((selectAllCheckBoxesStatus("Credit Hold Advised").contains("0"))
					&& (selectAllCheckBoxesStatus("Credit Review Required")
							.contains("0"))
					&& (selectAllCheckBoxesStatus("Collections Required")
							.contains("0"))
					&& (selectAllCheckBoxesStatus("Credit Increase Recommended")
							.contains("0"))
					&& (selectAllCheckBoxesStatus("On Credit Hold")
							.contains("0"))
					&& (selectAllCheckBoxesStatus("Manager Review Required")
							.contains("0"))
					&& (selectAllCheckBoxesStatus("Errored Accounts")
							.contains("0"))
					&& (selectAllCheckBoxesStatus("Deleted Accounts")
							.contains("0"))) {
				storeStatusVal1 = "1";
			} else {
				storeStatusVal1 = "2";
			}

			gotoClearAccountStatusesPage();
			// getDriver().navigate().refresh();
			UIHelper.waitForPageToLoad(getDriver());

		} while ((!storeStatusVal1.equals("1")) && (diffInMinutes < 1));
		System.out.println("waited time =================" + diffInMinutes);

		System.out.println("Credit Hold Advised----------"
				+ selectAllCheckBoxesStatus("Credit Hold Advised"));
		System.out.println("Credit Review Required----------"
				+ selectAllCheckBoxesStatus("Credit Review Required"));
		System.out.println("Collections Required--------"
				+ selectAllCheckBoxesStatus("Collections Required"));
		System.out.println("Credit Increase Recommended-------"
				+ selectAllCheckBoxesStatus("Credit Increase Recommended"));
		System.out.println("On Credit Hold--------"
				+ selectAllCheckBoxesStatus("On Credit Hold"));
		System.out.println("Manager Review Required------"
				+ selectAllCheckBoxesStatus("Manager Review Required"));
		System.out.println("Errored Accounts------------"
				+ selectAllCheckBoxesStatus("Errored Accounts"));
		System.out.println("Deleted Accounts----------"
				+ selectAllCheckBoxesStatus("Deleted Accounts"));
	}

	public boolean clearedStatus() {
		if ((selectAllCheckBoxesStatus("Credit Hold Advised").contains("0"))
				&& (selectAllCheckBoxesStatus("Credit Review Required")
						.contains("0"))
				&& (selectAllCheckBoxesStatus("Collections Required")
						.contains("0"))
				&& (selectAllCheckBoxesStatus("Credit Increase Recommended")
						.contains("0"))
				&& (selectAllCheckBoxesStatus("On Credit Hold").contains("0"))
				&& (selectAllCheckBoxesStatus("Manager Review Required")
						.contains("0"))
				&& (selectAllCheckBoxesStatus("Errored Accounts").contains("0"))
				&& (selectAllCheckBoxesStatus("Deleted Accounts").contains("0"))) {
			return true;
		} else {
			return false;
		}

	}

	public void click_Accounts_Tabs(String AccountTab) {

		String accTabXpth = "//*[contains(@id,'inbox_preference')][contains(.,'"
				+ AccountTab + "')]";
		WebElementFacade accNameElement = find(By.xpath(accTabXpth));
		UIHelper.highlightElement(getDriver(), accNameElement);
		accNameElement.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				accountResultsTableXpath);

	}

	public boolean verify_Accounts_Section(String AccountTab) {
		try {
			String accTabXpth = "//*[contains(@id,'inbox_preference')][contains(.,'"
					+ AccountTab + "')]";
			WebElementFacade accNameElement = find(By.xpath(accTabXpth));
			UIHelper.highlightElement(getDriver(), accNameElement);
			accNameElement.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					accountResultsTableXpath);
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	public void getAllAccountCountBefore(String accountName) {
		String accNameXpth = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[contains(.,'"
				+ accountName
				+ "')]//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']";
		WebElementFacade accNameElement = find(By.xpath(accNameXpth));

		if (accountName.equals("No Action Recommended")) {
			allnoAcRecommendedCount = Long.parseLong(accNameElement.getText()
					.trim());
			System.out
					.println("All Acounts - No Action Recommended count------"
							+ allnoAcRecommendedCount);

		} else if (accountName.equals("All Accounts")) {
			allAllAccountsCount = Long.parseLong(accNameElement.getText()
					.trim());
			System.out.println("All Acounts - All Accounts count------"
					+ allAllAccountsCount);

		}

	}

	public void getMyAccountCountBefore(String accountName) {
		String accNameXpth = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[contains(.,'"
				+ accountName
				+ "')]//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']";
		WebElementFacade accNameElement = find(By.xpath(accNameXpth));

		if (accountName.equals("No Action Recommended")) {
			myNoAcRecommendedCount = Long.parseLong(accNameElement.getText()
					.trim());
			System.out
					.println("My Accounts -  No Action Recommended count------"
							+ myNoAcRecommendedCount);

		} else if (accountName.equals("All Accounts")) {
			myallAccountsCount = Long
					.parseLong(accNameElement.getText().trim());
			System.out.println("My Accounts - All Accounts count------"
					+ myallAccountsCount);

		}

	}

	public void getAllAccountCountAfter(String accountName) {
		String accNameXpth = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[contains(.,'"
				+ accountName
				+ "')]//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']";
		WebElementFacade accNameElement = find(By.xpath(accNameXpth));

		if (accountName.equals("No Action Recommended")) {
			allnoAcRecommendedCountAfter = Long.parseLong(accNameElement
					.getText().trim());
			System.out
					.println("All Acounts - No Action Recommended count------"
							+ allnoAcRecommendedCountAfter);

		} else if (accountName.equals("All Accounts")) {
			allAllAccountsCountAfter = Long.parseLong(accNameElement.getText()
					.trim());
			System.out.println("All Acounts - All Accounts count------"
					+ allAllAccountsCountAfter);

		}

	}

	public void getMyAccountCountAfter(String accountName) {
		String accNameXpth = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[contains(.,'"
				+ accountName
				+ "')]//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']";
		WebElementFacade accNameElement = find(By.xpath(accNameXpth));

		if (accountName.equals("No Action Recommended")) {
			myNoAcRecommendedCountAfter = Long.parseLong(accNameElement
					.getText().trim());
			System.out
					.println("My Accounts -  No Action Recommended count------"
							+ myNoAcRecommendedCountAfter);

		} else if (accountName.equals("All Accounts")) {
			myallAccountsCountAfter = Long.parseLong(accNameElement.getText()
					.trim());
			System.out.println("My Accounts - All Accounts count------"
					+ myallAccountsCountAfter);

		}

	}

	

	

	
	

	public boolean verify_Acc_Page_Has_Dispalyed() {
		try {
			allAccPageHeader.isVisible();
			UIHelper.highlightElement(getDriver(), allAccPageHeader);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public String verify_Acc_Page_Has_Dispalyed2() {

		allAccPageHeader.isVisible();
		String Pagetitle = allAccPageHeader.getText();
		UIHelper.highlightElement(getDriver(), allAccPageHeader);
		return Pagetitle;
	}

	public void choose_filternameas(String ScheduleFilter) {
		String chooseFilternameXpath = "//form[@id='DataForm1']//tbody//select[@id='selectFilter']//option[contains(., '"
				+ ScheduleFilter + "')]";
		WebElementFacade schedulefiltereEle = find(By
				.xpath(chooseFilternameXpath));
		UIHelper.highlightElement(getDriver(), schedulefiltereEle);
	}
	public void create_Folderlink() {
		createNewFolderEle.isVisible();
		createNewFolderEle.click();
		folderNameTxt.isVisible();
	}
	public void enter_Folder_Name_Sbmt(String FolderNames) {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), FolderNames);
		UIHelper.highlightElement(getDriver(), folderNameTxt);
		folderNameTxt.selectByVisibleText(FolderNames);
	}
	public void choose_Folder_Name_list(String FolderNames) {
		folderNameSelect.isVisible();
		folderNameSelect.selectByVisibleText(FolderNames);
		folderNameSelect.sendKeys(FolderNames);
	}
	/* public void choose_Scheduler_Start_Date() {
	}
	public void choose_Scheduler_Frequency() {
	}
	public void click_Subt_Btn() {
	}
	public void schedule_Filter_Status() {
	}
	public void status_Completed() {
	}
	public void delete_Filter_Name(String ScheduleFilter) {
	}
	public void ok_Btn() {
	}
	public void check_Filter_Name_Exists(String ScheduleFilter) {
	} */
	
	public void click_Create_New_Filter_Button() {
		try {
			createNewFilterBtn.isVisible();
			createNewFilterBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
			getDriver().switchTo().frame(iFrameElement);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void select_Filter_type(String FilterType) {
		try {
			getDriver().switchTo().frame(iFrameElement);
			String filterTypeXpath = "//*[@id='filt_modalContent']//strong[contains(.,'"
					+ FilterType
					+ "')]//preceding-sibling::input[@type='radio']";
			WebElementFacade filterTypeElement = find(By.xpath(filterTypeXpath));
			filterTypeElement.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void select_FilterName(String ExistFilterName) {
		try {
			String ExistFilterNameXpath = "//*[@id='existingFiltersTable']//tr/td[contains(.,'"
					+ ExistFilterName + "')]";
			WebElementFacade filterNameElement = find(By
					.xpath(ExistFilterNameXpath));
			filterNameElement.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_Cf_Sumit_Btn() {
		modelSumbmitButton.isVisible();
		modelSumbmitButton.click();
		getDriver().switchTo().defaultContent();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				allAccPageHeaderXpath);

	}

	public boolean verify_Create_Filter_Page_Has_Dispalyed() {
		try {
			allAccPageHeader.isVisible();
			UIHelper.highlightElement(getDriver(), allAccPageHeader);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public void select_Filter_Type_And_Name(String FilterType, String FilterName) {
		try {
			selectFilterType.isVisible();
			selectFilterType.selectByVisibleText(FilterType);
			FilternameEle.sendKeys(FilterName);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void select_Category_Add_Fields(String Category, String Fields) {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), filtercategory);
		selectFilterCategory.selectByVisibleText(Category);
		if (Fields.contains(":")) {
			String[] fieldsList = Fields.split(":");
			for (String fieldname : fieldsList) {
				String fieldnameXpath = "//*[@id='main']//*[@id='data_fields']//option[.='"
						+ fieldname + "']";
				WebElementFacade fieldnameEle = find(By.xpath(fieldnameXpath));
				fieldnameEle.click();
				waitFor(1000).milliseconds();
				fieldsAddBtn.click();
			}
		} else {
			List<WebElement> optionlist = getDriver().findElements(
					By.xpath("//*[@id='main']//*[@id='data_fields']//option"));
			for (WebElement getoption : optionlist) {
				if (getoption.getText().equals(Fields)) {
					/*
					 * String fieldnameXpath =
					 * "//*[@id='main']//*[@id='data_fields']//option[.='" +
					 * Fields + "']"; WebElementFacade fieldnameEle =
					 * find(By.xpath(fieldnameXpath));
					 */
					getoption.click();
					waitFor(1000).milliseconds();
					fieldsAddBtn.click();
				}
			}
		}
	}

	public void input_Values_to_Fields(String FieldName, String Operator,
			String Value, String RangeValue) {

		String operatorXpath = "//*[@id='main']//table[@class='data_table']//tr//td[.='"
				+ FieldName + "']//following-sibling::td[1]//select";
		WebElementFacade operatorEle = find(By.xpath(operatorXpath));
		operatorEle.selectByVisibleText(Operator);
		waitFor(1000).milliseconds();
		if (Operator.equals("Is Equal To")
				|| Operator.equals("Is Not Equal To")) {
			String valueXpath = ".//*[@id='main']//table[@class='data_table']//tr//td[.='"
					+ FieldName + "']//following-sibling::td[2]//span//a";
			WebElementFacade valueEle = find(By.xpath(valueXpath));
			valueEle.click();
			if (FieldName.equals("Country")) {
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						countryFieldXpath);
				if (Value.contains(",")) {
					String[] valuelist = Value.split(",");
					for (String valuename : valuelist) {
						String countryXpath = "//*[@class='modal_content']//*[@id='filt_cntryList']//option[.='"
								+ valuename + "']";
						WebElementFacade countryEle = find(By
								.xpath(countryXpath));
						countryEle.click();
						countryAddBtn.click();
					}
				} else {
					String countryXpath = "//*[@class='modal_content']//*[@id='filt_cntryList']//option[.='"
							+ Value + "']";
					WebElementFacade countryEle = find(By.xpath(countryXpath));
					countryEle.click();
					countryAddBtn.click();
				}
				UIHelper.highlightElement(getDriver(), countrySelectedList);
				countrySubmitBtn.click();
			} else {

				if (Value.contains(",")) {
					String[] valuelist = Value.split(",");
					for (String valuename : valuelist) {
						valueTextField.sendKeys(valuename);
						valueAddBtn.click();
					}
				} else {
					valueTextField.sendKeys(Value);
					valueAddBtn.click();
				}
				UIHelper.highlightElement(getDriver(), fieldValueTextbox);
				valueSubmitBtn.click();
			}

			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					conditionTableExpath);

		} else if (Operator.equals("Is Blank")
				|| Operator.equals("Is Not Blank")) {
			operatorEle.selectByVisibleText(Operator);
		} else if (Operator.equals("Is Within Range")) {
			String valueXpath1 = "//*[@id='main']//table[@class='data_table']//tr//td[.='"
					+ FieldName
					+ "']//following-sibling::td[2]//span//span[1]//input";
			String valueXpath2 = "//*[@id='main']//table[@class='data_table']//tr//td[.='"
					+ FieldName
					+ "']//following-sibling::td[2]//span//span[2]//input";
			WebElementFacade valueEleOne = find(By.xpath(valueXpath1));
			WebElementFacade valueEleTwo = find(By.xpath(valueXpath2));
			valueEleOne.sendKeys(Value);
			valueEleTwo.sendKeys(RangeValue);

		} else {
			String valueXpath = "//*[@id='main']//table[@class='data_table']//tr//td[.='"
					+ FieldName + "']//following-sibling::td[2]//input";
			WebElementFacade valueEle = find(By.xpath(valueXpath));
			valueEle.sendKeys(Value);

		}

	}

	public void click_Filter_Save_btn() {
		try {
			filterSaveBtn.isVisible();
			filterSaveBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					filtersTableHeaderXpath);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void delete_Existing_Filter(String FilterName) {
		try {
			String filternamexpath = "//*[@id='main']//*[@id='tab2']//form//table//tbody//td[contains(.,'"
					+ FilterName + "')]";
			String filterNameDeleteExpath = "//*[@id='main']//*[@id='tab2']//form//table//tbody//td[contains(.,'"
					+ FilterName
					+ "')]//following-sibling::td//a[contains(.,'Delete')]";
			WebElementFacade filterNameEle = find(By.xpath(filternamexpath));
			UIHelper.highlightElement(getDriver(), filterNameEle);
			WebElementFacade filterNameDeleteEle = find(By
					.xpath(filterNameDeleteExpath));
			filterNameDeleteEle.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					deleteYesButtonXpath);
			deleteYesButton.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					filtersTableHeaderXpath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void delete_Existing_Folder(String FolderName) {
		try {
			String folderNameExpath = "//*[@id='main']//*[@id='tab1']//form//table//tbody//td[contains(.,'"
					+ FolderName + "')]";
			String folderNameDeleteExpath = "//*[@id='main']//*[@id='tab1']//form//table//tbody//td[contains(.,'"
					+ FolderName
					+ "')]//following-sibling::td//a[contains(.,'Delete')]";
			WebElementFacade folderNameEle = find(By.xpath(folderNameExpath));
			UIHelper.highlightElement(getDriver(), folderNameEle);
			WebElementFacade folderNameDeleteEle = find(By
					.xpath(folderNameDeleteExpath));
			folderNameDeleteEle.click();
			UIHelper.processalert(getDriver());
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					foldersTableHeaderXpath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean verify_Filter_has_Created(String FilterName) {
		try {
			filterTab.isVisible();
			filterTab.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					filtersTableHeaderXpath);
			waitFor(8000).milliseconds();
			String filterNameExpath = "//*[@id='main']//*[@id='tab2']//form//table//tbody//td[contains(.,'"
					+ FilterName + "')]";
			WebElementFacade filterNameEle = find(By.xpath(filterNameExpath));
			UIHelper.highlightElement(getDriver(), filterNameEle);
			return true;

		} catch (Exception e) {
			return false;

		}
	}

	

	

	public boolean verify_View_More_Results_Has_Filtered(String BusinessName,
			String Country, String State) {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				accountViewMoreResultsTableXpath);
		int resultsFlag = 0;
		for (WebElementFacade list : accountViewMoreResutlsList) {
			UIHelper.highlightElement(getDriver(), list);
			if (list.getText().contains(BusinessName)
					&& list.getText().contains(Country)
					&& list.getText().contains(State)) {
				resultsFlag = 1;
				break;
			} else {
				resultsFlag = 2;
			}
		}
		if (resultsFlag == 1) {
			return true;

		} else {
			return false;
		}
	}

	public void click_Reset_Filter_Btn() {
		try {
			resetListBtn.isEnabled();
			resetListBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					accountResultsTableXpath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	

	public void create_New_Folder(String FolderName, String AlertProfileName) {

		try {
			String foldersDeleteBtnXpath = "//*[@id='main']//*[@id='tab1']//form//table//tbody//tr//td[2][contains(.,'"
					+ FolderName
					+ "')]//following-sibling::td[4]//a[contains(.,'Delete')]";
			for (WebElementFacade folderName : foldersNameList) {
				System.out
						.println("folder name------- " + folderName.getText());
				UIHelper.mouseOveranElement(getDriver(), folderName);
				waitFor(500).milliseconds();
				if (folderName.getText().contains(FolderName)) {
					WebElementFacade foldersDeleteBtn = find(By
							.xpath(foldersDeleteBtnXpath));
					UIHelper.highlightElement(getDriver(), foldersDeleteBtn);
					foldersDeleteBtn.click();
					waitFor(2000).milliseconds();
					UIHelper.processalert(getDriver());
					waitFor(5000).milliseconds();
					UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
							foldersTableXpath);
					break;
				}
			}
			createNewFolderBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					FolderNameTextXpath);
			FolderNameText.sendKeys(FolderName);
			alertProfileName.selectByVisibleText(AlertProfileName);
			folderSubmitButton.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					foldersTableXpath);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public boolean verify_Folder_has_Created(String FolderName) {
		int folderFlag = 0;
		for (WebElementFacade folderName : foldersNameList) {
			if (folderName.getText().contains(FolderName)) {

				folderFlag = 1;
				break;

			} else {
				folderFlag = 2;
			}
		}
		if (folderFlag == 1) {
			return true;

		} else {
			return false;
		}

	}

	

	

	
	
	

	

	

	public boolean verify_Accounts_Section_Heading(String AccountSectionHeading) {
		try {
			String accTabXpth = "//*[@id='main']//span[contains(.,'"
					+ AccountSectionHeading + "')]";
			WebElementFacade accNameElement = find(By.xpath(accTabXpth));
			UIHelper.highlightElement(getDriver(), accNameElement);
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	public boolean viewAllTheSections(String SectionName) {
		try {
			String accTabXpth = "//*[@id='TimeFilter']//span[contains(.,'"
					+ SectionName + "')]";
			WebElementFacade accNameElement = find(By.xpath(accTabXpth));
			UIHelper.highlightElement(getDriver(), accNameElement);
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	public void get_DM_Link_Count(String accountName) {
		String accNameLinkXpth = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[normalize-space(text())='"
				+ accountName + "']";
		String accNameXpth = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[normalize-space(text())='"
				+ accountName
				+ "']//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']";
		WebElementFacade accNameLinkElement = find(By.xpath(accNameLinkXpth));
		WebElementFacade accNameElement = find(By.xpath(accNameXpth));
		app_count = Long.parseLong(accNameElement.getText().trim());
		if (app_count < 1) {
			UIHelper.highlightElement(getDriver(), accNameLinkElement);
		}
		System.out.println("My Accounts -  " + accountName + " count------"
				+ app_count);

	}

	public void click_DM_Link(String accountName) {
		String accNameLinkXpth = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[normalize-space(text())='"
				+ accountName + "']";
		WebElementFacade accNameLinkElement = find(By.xpath(accNameLinkXpth));
		accNameLinkElement.click();
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				accountResultsTableXpath);
	}

	public void acc_uslink() {
		clickfirstusaccount.waitUntilClickable();
		UIHelper.highlightElement(getDriver(), clickfirstusaccount);
		clickfirstusaccount.click();
	}

	public void acc_tablink(String tab) {
		String tablink = "//*[@id='ecf_toc_main']//*[@id='ecf_toc1']//li[contains(a,'"
				+ tab + "')]";
		WebElementFacade tablinkelement = find(By.xpath(tablink));
		UIHelper.highlightElement(getDriver(), tablinkelement);
		tablinkelement.click();
	}

	public boolean verify_Application_Results() {
		try {
			resultList.isVisible();
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	public void verify_Pagenation() {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				accountViewMoreResultsTableXpath);
		int pagecount = Integer.parseInt(viewPageCount.getText().trim());
		if (pagecount > 10) {
			DecimalFormat df = new DecimalFormat("0"); // defining the decimal
														// points foramt
			int pagecount1 = Integer.parseInt(df.format(pagecount / 10));
			log.log(Level.INFO, "page count--------------------- " + pagecount1);
			for (int i = 1; i < pagecount1; i++) {
				log.log(Level.INFO, "page no in loop -------------------- " + i);
				viewPageNextBtn.click();
				UIHelper.waitForPageToLoad(getDriver());
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						accountViewMoreResultsTableXpath);
				if (i > 5) {
					break;
				}
			}
		}
	}

	public boolean verify_Results_is_Filtered() {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				accountResultsTableXpath);
		if (resultList.isVisible()) {
			return true;

		} else {
			return false;
		}
	}

	public void store_Precount_Filter_Results(String Name) {

		try {
			int pcount = 0;
			precountFilterResultsBtn.isVisible();
			precountFilterResultsBtn.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), framexpath);
			getDriver().switchTo().frame(iFrameElement);
			waitFor(2000).milliseconds();
			if (Name.equals("Account")) {
				precountAccountResutls = Integer.parseInt(totalNumberOfRecrods
						.getText().trim());
				pcount = precountAccountResutls;
			} else if (Name.equals("Application")) {
				precountApplicatonResutls = Integer
						.parseInt(totalNumberOfRecrods.getText().trim());
				pcount = precountApplicatonResutls;
			} else if (Name.equals("Live Report")) {
				precountLivereportResutls = Integer
						.parseInt(totalNumberOfRecrods.getText().trim());
				pcount = precountLivereportResutls;
			} else if (Name.equals("Snapshot")) {
				precountSnapshotResutls = Integer.parseInt(totalNumberOfRecrods
						.getText().trim());
				pcount = precountSnapshotResutls;
			}

			System.out.println("count of records-----------------" + pcount);
			precountResultsOkBtn.click();
			getDriver().switchTo().defaultContent();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					allAccPageHeaderXpath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int get_All_Account_Count() {
		String accNameLinkXpth = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[contains(.,'All Accounts')]";
		String accNameXpth = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[contains(.,'All Accounts')]//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']";
		WebElementFacade accNameLinkElement = find(By.xpath(accNameLinkXpth));
		WebElementFacade accNameElement = find(By.xpath(accNameXpth));
		UIHelper.mouseOveranElement(getDriver(), accNameLinkElement);
		int accCount = Integer.parseInt(accNameElement.getText().trim());
		System.out.println("All Accounts count------" + accCount);
		return accCount;
	}

	public void Click_On_Existing_Filter_Name(String FilterName) {
		try {
			String filterNameExpath = "//*[@id='main']//*[@id='tab2']//form//table//tbody//td[contains(.,'"
					+ FilterName + "')]/a";
			WebElementFacade filterNameEle = find(By.xpath(filterNameExpath));
			UIHelper.highlightElement(getDriver(), filterNameEle);
			filterNameEle.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), accTableXpath);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int get_Filter_Record_Account_Count() {
		int accCount = 0;
		UIHelper.highlightElement(getDriver(), accTableXpathelement);
		if (filterResultCount.isVisible()) {
			UIHelper.mouseOveranElement(getDriver(), filterResultCount);
			accCount = Integer.parseInt(filterResultCount.getText().trim());
		} else {
			UIHelper.mouseOveranElement(getDriver(), filterResultCount1);
			accCount = Integer.parseInt(filterResultCount1.getText().trim());
		}

		System.out
				.println("Filter results All Accounts count------" + accCount);
		return accCount;
	}

	public boolean verify_CountryName_In_Results(String CountryName) {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), accTableXpath);
		int resultsFlag = 0;
		System.out.println("Filter results list size======================="
				+ accountViewMoreResutlsList.size());
		if (accountViewMoreResutlsList.size() > 0) {
			for (WebElementFacade list : accountViewMoreResutlsList) {
				UIHelper.mouseOveranElement(getDriver(), list);
				if (list.getText().contains(CountryName)) {
					resultsFlag = 1;
					break;
				} else {
					resultsFlag = 2;
				}
			}

		} else {
			resultsFlag = 1;
		}

		if (resultsFlag == 1) {
			return true;

		} else {
			return false;
		}
	}

	public boolean verify_CountryName_in_Acc_Resutls(String CountryName) {
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				accountResultsTableXpath);
		int resultsFlag = 0;
		System.out.println("Filter results list size======================="
				+ accountResutlsList.size());
		if (accountResutlsList.size() > 0) {
			for (WebElementFacade list : accountResutlsList) {
				UIHelper.mouseOveranElement(getDriver(), list);
				if (list.getText().contains(CountryName)) {
					resultsFlag = 1;
					break;
				} else {
					resultsFlag = 2;
				}
			}
		} else {
			resultsFlag = 1;
		}

		if (resultsFlag == 1) {
			return true;

		} else {
			return false;
		}

	}

	public int get_DM_Inbox_Required_Applications_Count(String ApplicationName) {
		String appNameLinkXpth = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[contains(.,'"
				+ ApplicationName + "')]";
		String appNameXpth = "//*[@id='main']//*[contains(@class,'drill_down_inbox')]//span[contains(.,'"
				+ ApplicationName
				+ "')]//ancestor::li//*[@class='node_image']//*[@class='circle_bg_middle']";
		WebElementFacade appNameLinkElement = find(By.xpath(appNameLinkXpth));
		WebElementFacade appNameElement = find(By.xpath(appNameXpth));
		UIHelper.mouseOveranElement(getDriver(), appNameLinkElement);
		int appcount = Integer.parseInt(appNameElement.getText().trim());
		System.out.println("My Applicatons -  " + ApplicationName
				+ " count------" + app_count);
		return appcount;
	}

	public int getDM_ApplicationCount() {
		int DmAppCount1 = get_DM_Inbox_Required_Applications_Count("Submitted Applications");
		int DmAppCount2 = get_DM_Inbox_Required_Applications_Count("Saved Applications");
		int DmAppCount3 = DmAppCount1 + DmAppCount2;
		return DmAppCount3;
	}

	public void select_ViewItems_Count(String ItemsCount) {
		try {
			viewItemsList.isVisible();
			viewItemsList.selectByVisibleText(ItemsCount);
			waitFor(5000).milliseconds();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), tablerowsXpath);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		public void click_Schedule_Filter_Tab() {
			scheduleFilterTab.isVisible();
			scheduleFilterTab.click();
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),filtersTableHeaderXpath);
			
		}
}