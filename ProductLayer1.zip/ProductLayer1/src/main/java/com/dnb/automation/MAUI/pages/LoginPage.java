package com.dnb.automation.MAUI.pages;

import com.dnb.automation.utils.UIHelper;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class LoginPage extends PageObject
{

	@FindBy(xpath=".//td[2]/input[@name='user']")
	private WebElementFacade userName;
	
	@FindBy(xpath=".//td[2]/input[@name='pass']")
	private WebElementFacade passWord;
	
	@FindBy(xpath=".//td[2]/input[@type='submit']")
	private WebElementFacade loginbtn;
	
	@FindBy(xpath=".//td[3]/input[@value='Sign Up Later']")
	private WebElementFacade signuplaterbtn;
	
	public void Login(String username, String password) 
	{
	enteruserName(username);
	enterPassword(password);
	clicklogin();	
	}

	private void clicklogin() 
	{
		try{
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.highlightElement(getDriver(), loginbtn);
			loginbtn.click();
		}catch(Exception e){
		}
		
	}

	private void enterPassword(String password) {
		try{
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.highlightElement(getDriver(), passWord);
			passWord.type(password);
		}catch(Exception e){
		}
	}

	private void enteruserName(String username) {
		
		try{
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.highlightElement(getDriver(), userName);
			userName.type(username);
		}catch(Exception e){
		}
	}

	public void clickSignuplaterbtn() 
	{
		try{
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.highlightElement(getDriver(), signuplaterbtn);
			signuplaterbtn.click();
		}catch(Exception e){
		}
		
	}

}
