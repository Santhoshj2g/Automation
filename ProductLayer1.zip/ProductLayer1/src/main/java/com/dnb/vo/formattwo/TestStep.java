
package com.dnb.vo.formattwo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "number",
    "description",
    "duration",
    "startTime",
    "children"
})
public class TestStep {

    @JsonProperty("number")
    private long number;
    @JsonProperty("description")
    private String description;
    @JsonProperty("duration")
    private long duration;
    @JsonProperty("startTime")
    private long startTime;
    @JsonProperty("children")
    private List<Child> children = new ArrayList<Child>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public TestStep() {
    }

    /**
     * 
     * @param startTime
     * @param duration
     * @param description
     * @param children
     * @param number
     */
    public TestStep(long number, String description, long duration, long startTime, List<Child> children) {
        this.number = number;
        this.description = description;
        this.duration = duration;
        this.startTime = startTime;
        this.children = children;
    }

    /**
     * 
     * @return
     *     The number
     */
    @JsonProperty("number")
    public long getNumber() {
        return number;
    }

    /**
     * 
     * @param number
     *     The number
     */
    @JsonProperty("number")
    public void setNumber(long number) {
        this.number = number;
    }

    public TestStep withNumber(long number) {
        this.number = number;
        return this;
    }

    /**
     * 
     * @return
     *     The description
     */
    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    /**
     * 
     * @param description
     *     The description
     */
    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    public TestStep withDescription(String description) {
        this.description = description;
        return this;
    }

    /**
     * 
     * @return
     *     The duration
     */
    @JsonProperty("duration")
    public long getDuration() {
        return duration;
    }

    /**
     * 
     * @param duration
     *     The duration
     */
    @JsonProperty("duration")
    public void setDuration(long duration) {
        this.duration = duration;
    }

    public TestStep withDuration(long duration) {
        this.duration = duration;
        return this;
    }

    /**
     * 
     * @return
     *     The startTime
     */
    @JsonProperty("startTime")
    public long getStartTime() {
        return startTime;
    }

    /**
     * 
     * @param startTime
     *     The startTime
     */
    @JsonProperty("startTime")
    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public TestStep withStartTime(long startTime) {
        this.startTime = startTime;
        return this;
    }

    /**
     * 
     * @return
     *     The children
     */
    @JsonProperty("children")
    public List<Child> getChildren() {
        return children;
    }

    /**
     * 
     * @param children
     *     The children
     */
    @JsonProperty("children")
    public void setChildren(List<Child> children) {
        this.children = children;
    }

    public TestStep withChildren(List<Child> children) {
        this.children = children;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public TestStep withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(number).append(description).append(duration).append(startTime).append(children).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof TestStep) == false) {
            return false;
        }
        TestStep rhs = ((TestStep) other);
        return new EqualsBuilder().append(number, rhs.number).append(description, rhs.description).append(duration, rhs.duration).append(startTime, rhs.startTime).append(children, rhs.children).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
