
package com.dnb.vo.formattwo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "errorType",
    "message",
    "stackTrace",
    "COLLAPSE_NEW_LINE_HINTS"
})
public class Exception_ {

    @JsonProperty("errorType")
    private String errorType;
    @JsonProperty("message")
    private String message;
    @JsonProperty("stackTrace")
    private List<StackTrace_> stackTrace = new ArrayList<StackTrace_>();
    @JsonProperty("COLLAPSE_NEW_LINE_HINTS")
    private List<String> cOLLAPSENEWLINEHINTS = new ArrayList<String>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public Exception_() {
    }

    /**
     * 
     * @param message
     * @param cOLLAPSENEWLINEHINTS
     * @param errorType
     * @param stackTrace
     */
    public Exception_(String errorType, String message, List<StackTrace_> stackTrace, List<String> cOLLAPSENEWLINEHINTS) {
        this.errorType = errorType;
        this.message = message;
        this.stackTrace = stackTrace;
        this.cOLLAPSENEWLINEHINTS = cOLLAPSENEWLINEHINTS;
    }

    /**
     * 
     * @return
     *     The errorType
     */
    @JsonProperty("errorType")
    public String getErrorType() {
        return errorType;
    }

    /**
     * 
     * @param errorType
     *     The errorType
     */
    @JsonProperty("errorType")
    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    public Exception_ withErrorType(String errorType) {
        this.errorType = errorType;
        return this;
    }

    /**
     * 
     * @return
     *     The message
     */
    @JsonProperty("message")
    public String getMessage() {
        return message;
    }

    /**
     * 
     * @param message
     *     The message
     */
    @JsonProperty("message")
    public void setMessage(String message) {
        this.message = message;
    }

    public Exception_ withMessage(String message) {
        this.message = message;
        return this;
    }

    /**
     * 
     * @return
     *     The stackTrace
     */
    @JsonProperty("stackTrace")
    public List<StackTrace_> getStackTrace() {
        return stackTrace;
    }

    /**
     * 
     * @param stackTrace
     *     The stackTrace
     */
    @JsonProperty("stackTrace")
    public void setStackTrace(List<StackTrace_> stackTrace) {
        this.stackTrace = stackTrace;
    }

    public Exception_ withStackTrace(List<StackTrace_> stackTrace) {
        this.stackTrace = stackTrace;
        return this;
    }

    /**
     * 
     * @return
     *     The cOLLAPSENEWLINEHINTS
     */
    @JsonProperty("COLLAPSE_NEW_LINE_HINTS")
    public List<String> getCOLLAPSENEWLINEHINTS() {
        return cOLLAPSENEWLINEHINTS;
    }

    /**
     * 
     * @param cOLLAPSENEWLINEHINTS
     *     The COLLAPSE_NEW_LINE_HINTS
     */
    @JsonProperty("COLLAPSE_NEW_LINE_HINTS")
    public void setCOLLAPSENEWLINEHINTS(List<String> cOLLAPSENEWLINEHINTS) {
        this.cOLLAPSENEWLINEHINTS = cOLLAPSENEWLINEHINTS;
    }

    public Exception_ withCOLLAPSENEWLINEHINTS(List<String> cOLLAPSENEWLINEHINTS) {
        this.cOLLAPSENEWLINEHINTS = cOLLAPSENEWLINEHINTS;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Exception_ withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(errorType).append(message).append(stackTrace).append(cOLLAPSENEWLINEHINTS).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Exception_) == false) {
            return false;
        }
        Exception_ rhs = ((Exception_) other);
        return new EqualsBuilder().append(errorType, rhs.errorType).append(message, rhs.message).append(stackTrace, rhs.stackTrace).append(cOLLAPSENEWLINEHINTS, rhs.cOLLAPSENEWLINEHINTS).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
