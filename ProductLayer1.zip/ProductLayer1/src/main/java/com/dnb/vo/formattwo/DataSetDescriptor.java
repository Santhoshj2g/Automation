
package com.dnb.vo.formattwo;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "startRow",
    "rowCount"
})
public class DataSetDescriptor {

    @JsonProperty("startRow")
    private long startRow;
    @JsonProperty("rowCount")
    private long rowCount;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public DataSetDescriptor() {
    }

    /**
     * 
     * @param startRow
     * @param rowCount
     */
    public DataSetDescriptor(long startRow, long rowCount) {
        this.startRow = startRow;
        this.rowCount = rowCount;
    }

    /**
     * 
     * @return
     *     The startRow
     */
    @JsonProperty("startRow")
    public long getStartRow() {
        return startRow;
    }

    /**
     * 
     * @param startRow
     *     The startRow
     */
    @JsonProperty("startRow")
    public void setStartRow(long startRow) {
        this.startRow = startRow;
    }

    public DataSetDescriptor withStartRow(long startRow) {
        this.startRow = startRow;
        return this;
    }

    /**
     * 
     * @return
     *     The rowCount
     */
    @JsonProperty("rowCount")
    public long getRowCount() {
        return rowCount;
    }

    /**
     * 
     * @param rowCount
     *     The rowCount
     */
    @JsonProperty("rowCount")
    public void setRowCount(long rowCount) {
        this.rowCount = rowCount;
    }

    public DataSetDescriptor withRowCount(long rowCount) {
        this.rowCount = rowCount;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DataSetDescriptor withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(startRow).append(rowCount).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DataSetDescriptor) == false) {
            return false;
        }
        DataSetDescriptor rhs = ((DataSetDescriptor) other);
        return new EqualsBuilder().append(startRow, rhs.startRow).append(rowCount, rhs.rowCount).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
