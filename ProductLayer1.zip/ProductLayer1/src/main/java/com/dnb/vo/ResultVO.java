/**
 * 
 */
package com.dnb.vo;

/**
 * @author Lalitha
 *
 */
public class ResultVO {
	private String story;
	private String scenario;
	private String step;
	private String testClassMethodName;
	private String errorType;
	private String message;
	private String htmlSource;
	/**
	 * @return the htmlSource
	 */
	public String getHtmlSource() {
		return htmlSource;
	}
	/**
	 * @param htmlSource the htmlSource to set
	 */
	public void setHtmlSource(String htmlSource) {
		this.htmlSource = htmlSource;
	}
	public String getStory() {
		return story;
	}
	
	public void setStory(String story) {
		this.story = story;
	}
	
	public String getScenario() {
		return scenario;
	}
	
	public void setScenario(String scenario) {
		this.scenario = scenario;
	}
	
	public String getStep() {
		return step;
	}
	
	public void setStep(String step) {
		this.step = step;
	}
	
	public String getTestClassMethodName() {
		return testClassMethodName;
	}
	
	public void setTestClassMethodName(String testClassMethodName) {
		this.testClassMethodName = testClassMethodName;
	}
	
	public String getErrorType() {
		return errorType;
	}
	
	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}
	
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
	
	
	

}
