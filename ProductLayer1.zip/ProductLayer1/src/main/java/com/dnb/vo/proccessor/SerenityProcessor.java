/**
 * 
 */
package com.dnb.vo.proccessor;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.dnb.vo.ResultVO;
import com.dnb.vo.formatone.Child;
import com.dnb.vo.formatone.JsonFormatOne;
import com.dnb.vo.formatone.Screenshot;
import com.dnb.vo.formatone.TestStep;
import com.dnb.vo.formattwo.Child_;
import com.dnb.vo.formattwo.JsonFormatTwo;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author Lalitha
 *
 */
public class SerenityProcessor {

	// CSV file header
	private static final String FILE_HEADER = "Story,Scenario,Step,Message,Screen Shot";
	// Delimiter used in CSV file

	private static final String COMMA_DELIMITER = ",";

	private static final String NEW_LINE_SEPARATOR = "\n";

	private static  String HYPHER_LINK_LOCATION = "";

	private static String AUDIT_FILE = "";
	
	private static StringBuffer auditLogMessages = new StringBuffer();

	public static void main(String[] args) throws Exception {

		SerenityProcessor serenityProcessor = new SerenityProcessor();
//		serenityProcessor.createCSVByComaringTodayWithYesterdayResult("C:/Jenkins/jobs/Cirrus UI/jobs/Cirrus_STAG/builds/359/htmlreports/Serenity_Report/" , "C:/Jenkins/jobs/Cirrus UI/jobs/Cirrus_STAG/builds/358/htmlreports/Serenity_Report/");
		serenityProcessor.createCSVByComaringTodayWithYesterdayResult(args[0] , args[1]);

	}

	private static void writeAudit(String message) {
		FileWriter fileWriter = null;

		try {
			fileWriter = new FileWriter(AUDIT_FILE + "AuditLog.txt", true);
			fileWriter.append(new Date() + " : " + message);
			fileWriter.append(NEW_LINE_SEPARATOR);
		} catch (IOException e) {
			writeAudit("ERROR : " + e.getMessage());
		} finally {

			try {

				fileWriter.flush();
				fileWriter.close();

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void createCSVByComaringTodayWithYesterdayResult(String todayFolderName, String yesterdayFolderName)
			throws Exception {
		
		HYPHER_LINK_LOCATION = "=HYPERLINK(\""+todayFolderName;
		auditLogMessages.append("I am inside createCSVByComaringTodayWithYesterdayResult" +"\n");
		
		AUDIT_FILE = todayFolderName;
		auditLogMessages.append("Input Folder Name for TODAY's JSON :" + todayFolderName+"\n");
		auditLogMessages.append("Input Folder Name for YESTERDAY's JSON :" + yesterdayFolderName+"\n\n");
		

		Map<String, ResultVO> resultTodayMap = serenityResultProcessor(todayFolderName);

		Map<String, ResultVO> resultYesterdayMap = serenityResultProcessor(yesterdayFolderName);

		FileWriter fileWriter = null;
		FileWriter fileWriterPassed = null;
		try {

			fileWriter = new FileWriter(todayFolderName + "New_Failures" + ".csv");
			fileWriterPassed = new FileWriter(todayFolderName + "YesterdayFailures_TodayPassed" + ".csv");

			// Write the CSV file header
			fileWriter.append(FILE_HEADER.toString());
			fileWriter.append(NEW_LINE_SEPARATOR.toString());

			fileWriterPassed.append(FILE_HEADER);
			fileWriterPassed.append(NEW_LINE_SEPARATOR);

			auditLogMessages.append("Writing the final result into : " + todayFolderName + "New_Failures" + ".csv"+"\n");
			for (Map.Entry<String, ResultVO> entry : resultTodayMap.entrySet()) {
				String todayFailureKey = entry.getKey();
				if (!resultYesterdayMap.containsKey(todayFailureKey)) {
					ResultVO resultVO = entry.getValue();
					fileWriter.append(resultVO.getStory());
					fileWriter.append(COMMA_DELIMITER);
					fileWriter.append(resultVO.getScenario());
					fileWriter.append(COMMA_DELIMITER);
					fileWriter.append(resultVO.getStep());
					fileWriter.append(COMMA_DELIMITER);
//					fileWriter.append(resultVO.getTestClassMethodName());
//					fileWriter.append(COMMA_DELIMITER);
//					fileWriter.append(resultVO.getErrorType());
//					fileWriter.append(COMMA_DELIMITER);
					fileWriter.append(resultVO.getMessage());
					fileWriter.append(COMMA_DELIMITER);
					fileWriter.append(resultVO.getHtmlSource());
					fileWriter.append(NEW_LINE_SEPARATOR);
				}
			}

			auditLogMessages.append(todayFolderName + "New_Failures.csv Created Successfully"+"\n");
			
			
			for (Map.Entry<String, ResultVO> entry : resultYesterdayMap.entrySet()) {
				String yesterdayFailureKey = entry.getKey();
				if (!resultTodayMap.containsKey(yesterdayFailureKey)) {
					ResultVO resultVO = entry.getValue();
					fileWriterPassed.append(resultVO.getStory());
					fileWriterPassed.append(COMMA_DELIMITER);
					fileWriterPassed.append(resultVO.getScenario());
					fileWriterPassed.append(COMMA_DELIMITER);
					fileWriterPassed.append(resultVO.getStep());
					fileWriterPassed.append(COMMA_DELIMITER);
//					fileWriterPassed.append(resultVO.getTestClassMethodName());
//					fileWriterPassed.append(COMMA_DELIMITER);
//					fileWriterPassed.append(resultVO.getErrorType());
//					fileWriterPassed.append(COMMA_DELIMITER);
					fileWriterPassed.append(resultVO.getMessage());
					fileWriterPassed.append(COMMA_DELIMITER);
					fileWriterPassed.append(resultVO.getHtmlSource());
					fileWriterPassed.append(NEW_LINE_SEPARATOR);
				}
			}
		//	System.out.println("SUCCESSFULLY PROCESSED createCSVByComaringTodayWithYesterdayResult "+"\n");
		} catch (Exception e) {
			e.printStackTrace();
			auditLogMessages.append(e.getMessage());
		} finally {

			try {

				fileWriter.flush();
				fileWriter.close();
				fileWriterPassed.flush();
				fileWriterPassed.close();
				writeAudit(auditLogMessages.toString());				
				auditLogMessages = new StringBuffer();

			} catch (IOException e) {
				e.printStackTrace();
			}

		}

	}

	private Map<String, ResultVO> serenityResultProcessor(String folderName) throws Exception {
		auditLogMessages.append("Inside serenityResultProcessor for processing " + folderName+"\n");
		final Map<String, ResultVO> resultToday = new HashMap<String, ResultVO>();
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		// JSON from file to Object

		File folder = new File(folderName);
		File[] listOfFiles = folder.listFiles();
		

		for (int i = 0; i < listOfFiles.length; i++) {

			File file = listOfFiles[i];
			String fileName = folderName + file.getName();

			if (file.isFile() && fileName.endsWith(".json")) {

				try {
					JsonFormatOne jsonFormatOne = mapper.readValue(new File(fileName), JsonFormatOne.class);
					String result = jsonFormatOne.getResult();
					// System.out.println("Executing JSON Format 1");
					formatOneProcessor(result, jsonFormatOne, resultToday, fileName);
				} catch (Exception e) { // we have two formats of JSON
										// identified as of now
					// System.out.println("Executing JSON Format 2");
					JsonFormatTwo jsonFormatTwo = mapper.readValue(new File(fileName), JsonFormatTwo.class);
					String result = jsonFormatTwo.getResult();

					formatTwoProcessor(result, jsonFormatTwo, resultToday, fileName);
				}

			}
		}
		auditLogMessages.append("Successfully processed : " + folderName+"\n\n\n");
		return resultToday;
	}

	private static void formatOneProcessor(String result, JsonFormatOne obj, Map<String, ResultVO> resultMap,
			String fileName) throws Exception {

		// Checking the overall result is failure or error
		if (result.equalsIgnoreCase("FAILURE") || result.equalsIgnoreCase("ERROR")) {
			String titleMappedToScenario = obj.getTitle().replaceAll("\n", ". ").replaceAll(",", "; "); // taking
																										// name
			String storyNameMappedToStory = obj.getUserStory().getStoryName().replaceAll("\n", ". ").replaceAll(",",
					"; ");

			List<TestStep> testStepList = obj.getTestSteps();

			// Checking each testSteps to find which is failed
			for (TestStep testStep : testStepList) {

				if ("FAILURE".equalsIgnoreCase(testStep.getResult())
						|| "ERROR".equalsIgnoreCase(testStep.getResult())) {

					String mainDescMappedToStep = testStep.getDescription().replaceAll("\n", ". ").replaceAll(",","; ");
					String errorType = testStep.getException().getErrorType().replaceAll("\n", ". ").replaceAll(",",
							"; ");
					String message = testStep.getException().getMessage().replaceAll("\n", ". ").replaceAll(",", "; ");
					String htmlSource = "";
					String childDescMappedToTestClassMethodName = "";

					List<Child> childrenList = testStep.getChildren();

					// Checking if the children is present for the testStep
					// which has failure
					if (childrenList != null) {
						for (Child child : childrenList) {
							if (child.getResult().equalsIgnoreCase("FAILURE")
									|| child.getResult().equalsIgnoreCase("ERROR")) {
								/*childDescMappedToTestClassMethodName = child.getDescription(); // taking
								// description
								errorType = child.getException().getErrorType().replaceAll("\n", ". ").replaceAll(",",
										"; "); // taking
								// errorTpe
*/								if(child.getException() != null){ // check exception is available
									if(child.getException().getMessage() != null){
								message = child.getException().getMessage().replaceAll("\u003c", "\"")
										.replaceAll("\n", ". ") // taking
										// message
										.replaceAll("\u003e", "\"").replaceAll(",", "; ");
									}
								}
								List<Screenshot> screenShotList = child.getScreenshots();
								for (Screenshot screenShot : screenShotList) {

									htmlSource = screenShot.getScreenshot().replaceAll("\n", ". ").replaceAll(",",
											"; "); // taking
									// htmlSource
									// break;
								}
								// break;
							}
						}
					}
					ResultVO resultVO = new ResultVO();
					resultVO.setStory(storyNameMappedToStory);
					resultVO.setScenario(titleMappedToScenario);
					resultVO.setStep(mainDescMappedToStep);
//					resultVO.setTestClassMethodName(childDescMappedToTestClassMethodName);
//					resultVO.setErrorType(errorType);
					resultVO.setMessage(message);

					resultVO.setHtmlSource(HYPHER_LINK_LOCATION + htmlSource.replaceAll(".txt", "") + "\")");
					String key = titleMappedToScenario + "#" + mainDescMappedToStep;

					// comment the below if condition block for better
					// performance
					if (resultMap.containsKey(key)) {
						auditLogMessages.append("Duplicate Scenario: " + titleMappedToScenario + " ### File Name: "
								+ fileName + "\n ");
					}
					resultMap.put(key, resultVO);

					
				}
			}
		}

	}

	private void formatTwoProcessor(String result, JsonFormatTwo obj, Map<String, ResultVO> resultMap, String fileName)
			throws Exception {

		// Checking the overall result is failure or error
		if (result.equalsIgnoreCase("FAILURE") || result.equalsIgnoreCase("ERROR")) {
			String titleMappedToScenario = obj.getTitle().replaceAll("\n", ". ").replaceAll(",", "; "); // taking
																										// name
			String storyNameMappedToStory = obj.getUserStory().getStoryName().replaceAll("\n", ". ").replaceAll(",",
					"; ");

			List<com.dnb.vo.formattwo.TestStep> testStepList = obj.getTestSteps();

			String mainDescMappedToStep = "";
			String childDescMappedToTestClassMethodName = "";
			String errorType = "";
			String message = "";
			String htmlSource = "";
			// Checking each testSteps to find which is failed
			for (com.dnb.vo.formattwo.TestStep testStep : testStepList) {

				List<com.dnb.vo.formattwo.Child> childrenList = testStep.getChildren();

				// Checking if the children is present for the testStep
				// which has failure
				if (childrenList != null) {
					for (com.dnb.vo.formattwo.Child child : childrenList) {
						if (child.getResult().equalsIgnoreCase("FAILURE")
								|| child.getResult().equalsIgnoreCase("ERROR")) {

							mainDescMappedToStep = child.getDescription().replaceAll("\n", ". ").replaceAll(",", "; "); // main
							// description

							List<Child_> childList = child.getChildren();
							for (Child_ child_ : childList) {
//								childDescMappedToTestClassMethodName = child_.getDescription().replaceAll("\n", ". ")
//										.replaceAll(",", "; "); // taking
//								// description
//								//System.out.println("child_ : "+child_);
								if(child_.getException() != null){ // check exception is available
									if(child_.getException().getMessage() != null){
								message = child_.getException().getMessage().replaceAll("\u003c", "\"")
										.replaceAll("\u003e", "\"").replaceAll("\n", ". ").replaceAll(",", "; ");								
									}
								}
								/*if(child_.getException() != null){ // check exception is available
									if(child_.getException().getMessage() != null){
									errorType = child_.getException().getErrorType().replaceAll("\n", ". ").replaceAll(",",
										"; "); // taking
								// errorTpe
									}
								}*/
								List<com.dnb.vo.formattwo.Screenshot> screenshots = child_.getScreenshots();
								for (com.dnb.vo.formattwo.Screenshot screenshot : screenshots) {
									htmlSource = screenshot.getHtmlSource().replaceAll("\n", ". ").replaceAll(",",
											"; "); // taking
									// htmlSource

								}

							}

							ResultVO resultVO = new ResultVO();
							resultVO.setStory(storyNameMappedToStory);
							resultVO.setScenario(titleMappedToScenario);
							resultVO.setStep(mainDescMappedToStep);
//							resultVO.setTestClassMethodName(childDescMappedToTestClassMethodName);
//							resultVO.setErrorType(errorType);
							resultVO.setMessage(message);
							resultVO.setHtmlSource(HYPHER_LINK_LOCATION + htmlSource.replaceAll(".txt", "") + "\")");
							String key = titleMappedToScenario + "#" + mainDescMappedToStep;

							// comment the below if condition block for better
							// performance
							if (resultMap.containsKey(key)) {
								auditLogMessages.append("Duplicate Scenario: " + titleMappedToScenario + " ### File Name: "
										+ fileName + "\n");

							}
							resultMap.put(key, resultVO);

						}
						else
						{
							mainDescMappedToStep = child.getDescription().replaceAll("\n", ". ").replaceAll(",", "; "); // main
							// description

							List<Child_> childList = child.getChildren();
							for (Child_ child_ : childList) {
								/*childDescMappedToTestClassMethodName = child_.getDescription().replaceAll("\n", ". ")
										.replaceAll(",", "; "); // taking
								// description
								//System.out.println("child_ : "+child_);*/
								if(child_.getException() != null){ // check exception is available
									if(child_.getException().getMessage() != null){
								message = child_.getException().getMessage().replaceAll("\u003c", "\"")
										.replaceAll("\u003e", "\"").replaceAll("\n", ". ").replaceAll(",", "; ");								
									}
								}
								/*if(child_.getException() != null){ // check exception is available
									if(child_.getException().getErrorType() != null){
									errorType = child_.getException().getErrorType().replaceAll("\n", ". ").replaceAll(",",
										"; "); // taking
								// errorTpe
									}
								}
*/
								List<com.dnb.vo.formattwo.Screenshot> screenshots = child_.getScreenshots();
								for (com.dnb.vo.formattwo.Screenshot screenshot : screenshots) {
									htmlSource = screenshot.getHtmlSource().replaceAll("\n", ". ").replaceAll(",",
											"; "); // taking
									// htmlSource

								}

							}

							ResultVO resultVO = new ResultVO();
							resultVO.setStory(storyNameMappedToStory);
							resultVO.setScenario(titleMappedToScenario);
							resultVO.setStep(mainDescMappedToStep);
//							resultVO.setTestClassMethodName(childDescMappedToTestClassMethodName);
//							resultVO.setErrorType(errorType);
							resultVO.setMessage(message);
							resultVO.setHtmlSource(HYPHER_LINK_LOCATION + htmlSource.replaceAll(".txt", "") + "\")");
							String key = titleMappedToScenario + "#" + mainDescMappedToStep;

							// comment the below if condition block for better
							// performance
							if (resultMap.containsKey(key)) {
								auditLogMessages.append("Duplicate Scenario: " + titleMappedToScenario + " ### File Name: "
										+ fileName + "\n");

							}
							resultMap.put(key, resultVO);

						}

					}
				}
			}
		}

	}

}
