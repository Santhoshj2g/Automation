
package com.dnb.vo.formattwo;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "declaringClass",
    "methodName",
    "fileName",
    "lineNumber"
})
public class StackTrace {

    @JsonProperty("declaringClass")
    private String declaringClass;
    @JsonProperty("methodName")
    private String methodName;
    @JsonProperty("fileName")
    private String fileName;
    @JsonProperty("lineNumber")
    private long lineNumber;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public StackTrace() {
    }

    /**
     * 
     * @param declaringClass
     * @param fileName
     * @param lineNumber
     * @param methodName
     */
    public StackTrace(String declaringClass, String methodName, String fileName, long lineNumber) {
        this.declaringClass = declaringClass;
        this.methodName = methodName;
        this.fileName = fileName;
        this.lineNumber = lineNumber;
    }

    /**
     * 
     * @return
     *     The declaringClass
     */
    @JsonProperty("declaringClass")
    public String getDeclaringClass() {
        return declaringClass;
    }

    /**
     * 
     * @param declaringClass
     *     The declaringClass
     */
    @JsonProperty("declaringClass")
    public void setDeclaringClass(String declaringClass) {
        this.declaringClass = declaringClass;
    }

    public StackTrace withDeclaringClass(String declaringClass) {
        this.declaringClass = declaringClass;
        return this;
    }

    /**
     * 
     * @return
     *     The methodName
     */
    @JsonProperty("methodName")
    public String getMethodName() {
        return methodName;
    }

    /**
     * 
     * @param methodName
     *     The methodName
     */
    @JsonProperty("methodName")
    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public StackTrace withMethodName(String methodName) {
        this.methodName = methodName;
        return this;
    }

    /**
     * 
     * @return
     *     The fileName
     */
    @JsonProperty("fileName")
    public String getFileName() {
        return fileName;
    }

    /**
     * 
     * @param fileName
     *     The fileName
     */
    @JsonProperty("fileName")
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public StackTrace withFileName(String fileName) {
        this.fileName = fileName;
        return this;
    }

    /**
     * 
     * @return
     *     The lineNumber
     */
    @JsonProperty("lineNumber")
    public long getLineNumber() {
        return lineNumber;
    }

    /**
     * 
     * @param lineNumber
     *     The lineNumber
     */
    @JsonProperty("lineNumber")
    public void setLineNumber(long lineNumber) {
        this.lineNumber = lineNumber;
    }

    public StackTrace withLineNumber(long lineNumber) {
        this.lineNumber = lineNumber;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public StackTrace withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(declaringClass).append(methodName).append(fileName).append(lineNumber).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof StackTrace) == false) {
            return false;
        }
        StackTrace rhs = ((StackTrace) other);
        return new EqualsBuilder().append(declaringClass, rhs.declaringClass).append(methodName, rhs.methodName).append(fileName, rhs.fileName).append(lineNumber, rhs.lineNumber).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
