
package com.dnb.vo.formattwo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "name",
    "testSteps",
    "userStory",
    "title",
    "tags",
    "startTime",
    "duration",
    "testFailureCause",
    "testFailureClassname",
    "testFailureMessage",
    "annotatedResult",
    "sessionId",
    "driver",
    "dataTable",
    "manual",
    "result"
})
public class JsonFormatTwo {

    @JsonProperty("name")
    private String name;
    @JsonProperty("testSteps")
    private List<TestStep> testSteps = new ArrayList<TestStep>();
    @JsonProperty("userStory")
    private UserStory userStory;
    @JsonProperty("title")
    private String title;
    @JsonProperty("tags")
    private List<Tag> tags = new ArrayList<Tag>();
    @JsonProperty("startTime")
    private long startTime;
    @JsonProperty("duration")
    private long duration;
    @JsonProperty("testFailureCause")
    private TestFailureCause testFailureCause;
    @JsonProperty("testFailureClassname")
    private String testFailureClassname;
    @JsonProperty("testFailureMessage")
    private String testFailureMessage;
    @JsonProperty("annotatedResult")
    private String annotatedResult;
    @JsonProperty("sessionId")
    private String sessionId;
    @JsonProperty("driver")
    private String driver;
    @JsonProperty("dataTable")
    private DataTable dataTable;
    @JsonProperty("manual")
    private boolean manual;
    @JsonProperty("result")
    private String result;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public JsonFormatTwo() {
    }

    /**
     * 
     * @param tags
     * @param result
     * @param userStory
     * @param testSteps
     * @param testFailureMessage
     * @param testFailureClassname
     * @param manual
     * @param startTime
     * @param annotatedResult
     * @param title
     * @param duration
     * @param sessionId
     * @param name
     * @param driver
     * @param testFailureCause
     * @param dataTable
     */
    public JsonFormatTwo(String name, List<TestStep> testSteps, UserStory userStory, String title, List<Tag> tags, long startTime, long duration, TestFailureCause testFailureCause, String testFailureClassname, String testFailureMessage, String annotatedResult, String sessionId, String driver, DataTable dataTable, boolean manual, String result) {
        this.name = name;
        this.testSteps = testSteps;
        this.userStory = userStory;
        this.title = title;
        this.tags = tags;
        this.startTime = startTime;
        this.duration = duration;
        this.testFailureCause = testFailureCause;
        this.testFailureClassname = testFailureClassname;
        this.testFailureMessage = testFailureMessage;
        this.annotatedResult = annotatedResult;
        this.sessionId = sessionId;
        this.driver = driver;
        this.dataTable = dataTable;
        this.manual = manual;
        this.result = result;
    }

    /**
     * 
     * @return
     *     The name
     */
    @JsonProperty("name")
    public String getName() {
        return name;
    }

    /**
     * 
     * @param name
     *     The name
     */
    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    public JsonFormatTwo withName(String name) {
        this.name = name;
        return this;
    }

    /**
     * 
     * @return
     *     The testSteps
     */
    @JsonProperty("testSteps")
    public List<TestStep> getTestSteps() {
        return testSteps;
    }

    /**
     * 
     * @param testSteps
     *     The testSteps
     */
    @JsonProperty("testSteps")
    public void setTestSteps(List<TestStep> testSteps) {
        this.testSteps = testSteps;
    }

    public JsonFormatTwo withTestSteps(List<TestStep> testSteps) {
        this.testSteps = testSteps;
        return this;
    }

    /**
     * 
     * @return
     *     The userStory
     */
    @JsonProperty("userStory")
    public UserStory getUserStory() {
        return userStory;
    }

    /**
     * 
     * @param userStory
     *     The userStory
     */
    @JsonProperty("userStory")
    public void setUserStory(UserStory userStory) {
        this.userStory = userStory;
    }

    public JsonFormatTwo withUserStory(UserStory userStory) {
        this.userStory = userStory;
        return this;
    }

    /**
     * 
     * @return
     *     The title
     */
    @JsonProperty("title")
    public String getTitle() {
        return title;
    }

    /**
     * 
     * @param title
     *     The title
     */
    @JsonProperty("title")
    public void setTitle(String title) {
        this.title = title;
    }

    public JsonFormatTwo withTitle(String title) {
        this.title = title;
        return this;
    }

    /**
     * 
     * @return
     *     The tags
     */
    @JsonProperty("tags")
    public List<Tag> getTags() {
        return tags;
    }

    /**
     * 
     * @param tags
     *     The tags
     */
    @JsonProperty("tags")
    public void setTags(List<Tag> tags) {
        this.tags = tags;
    }

    public JsonFormatTwo withTags(List<Tag> tags) {
        this.tags = tags;
        return this;
    }

    /**
     * 
     * @return
     *     The startTime
     */
    @JsonProperty("startTime")
    public long getStartTime() {
        return startTime;
    }

    /**
     * 
     * @param startTime
     *     The startTime
     */
    @JsonProperty("startTime")
    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public JsonFormatTwo withStartTime(long startTime) {
        this.startTime = startTime;
        return this;
    }

    /**
     * 
     * @return
     *     The duration
     */
    @JsonProperty("duration")
    public long getDuration() {
        return duration;
    }

    /**
     * 
     * @param duration
     *     The duration
     */
    @JsonProperty("duration")
    public void setDuration(long duration) {
        this.duration = duration;
    }

    public JsonFormatTwo withDuration(long duration) {
        this.duration = duration;
        return this;
    }

    /**
     * 
     * @return
     *     The testFailureCause
     */
    @JsonProperty("testFailureCause")
    public TestFailureCause getTestFailureCause() {
        return testFailureCause;
    }

    /**
     * 
     * @param testFailureCause
     *     The testFailureCause
     */
    @JsonProperty("testFailureCause")
    public void setTestFailureCause(TestFailureCause testFailureCause) {
        this.testFailureCause = testFailureCause;
    }

    public JsonFormatTwo withTestFailureCause(TestFailureCause testFailureCause) {
        this.testFailureCause = testFailureCause;
        return this;
    }

    /**
     * 
     * @return
     *     The testFailureClassname
     */
    @JsonProperty("testFailureClassname")
    public String getTestFailureClassname() {
        return testFailureClassname;
    }

    /**
     * 
     * @param testFailureClassname
     *     The testFailureClassname
     */
    @JsonProperty("testFailureClassname")
    public void setTestFailureClassname(String testFailureClassname) {
        this.testFailureClassname = testFailureClassname;
    }

    public JsonFormatTwo withTestFailureClassname(String testFailureClassname) {
        this.testFailureClassname = testFailureClassname;
        return this;
    }

    /**
     * 
     * @return
     *     The testFailureMessage
     */
    @JsonProperty("testFailureMessage")
    public String getTestFailureMessage() {
        return testFailureMessage;
    }

    /**
     * 
     * @param testFailureMessage
     *     The testFailureMessage
     */
    @JsonProperty("testFailureMessage")
    public void setTestFailureMessage(String testFailureMessage) {
        this.testFailureMessage = testFailureMessage;
    }

    public JsonFormatTwo withTestFailureMessage(String testFailureMessage) {
        this.testFailureMessage = testFailureMessage;
        return this;
    }

    /**
     * 
     * @return
     *     The annotatedResult
     */
    @JsonProperty("annotatedResult")
    public String getAnnotatedResult() {
        return annotatedResult;
    }

    /**
     * 
     * @param annotatedResult
     *     The annotatedResult
     */
    @JsonProperty("annotatedResult")
    public void setAnnotatedResult(String annotatedResult) {
        this.annotatedResult = annotatedResult;
    }

    public JsonFormatTwo withAnnotatedResult(String annotatedResult) {
        this.annotatedResult = annotatedResult;
        return this;
    }

    /**
     * 
     * @return
     *     The sessionId
     */
    @JsonProperty("sessionId")
    public String getSessionId() {
        return sessionId;
    }

    /**
     * 
     * @param sessionId
     *     The sessionId
     */
    @JsonProperty("sessionId")
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public JsonFormatTwo withSessionId(String sessionId) {
        this.sessionId = sessionId;
        return this;
    }

    /**
     * 
     * @return
     *     The driver
     */
    @JsonProperty("driver")
    public String getDriver() {
        return driver;
    }

    /**
     * 
     * @param driver
     *     The driver
     */
    @JsonProperty("driver")
    public void setDriver(String driver) {
        this.driver = driver;
    }

    public JsonFormatTwo withDriver(String driver) {
        this.driver = driver;
        return this;
    }

    /**
     * 
     * @return
     *     The dataTable
     */
    @JsonProperty("dataTable")
    public DataTable getDataTable() {
        return dataTable;
    }

    /**
     * 
     * @param dataTable
     *     The dataTable
     */
    @JsonProperty("dataTable")
    public void setDataTable(DataTable dataTable) {
        this.dataTable = dataTable;
    }

    public JsonFormatTwo withDataTable(DataTable dataTable) {
        this.dataTable = dataTable;
        return this;
    }

    /**
     * 
     * @return
     *     The manual
     */
    @JsonProperty("manual")
    public boolean isManual() {
        return manual;
    }

    /**
     * 
     * @param manual
     *     The manual
     */
    @JsonProperty("manual")
    public void setManual(boolean manual) {
        this.manual = manual;
    }

    public JsonFormatTwo withManual(boolean manual) {
        this.manual = manual;
        return this;
    }

    /**
     * 
     * @return
     *     The result
     */
    @JsonProperty("result")
    public String getResult() {
        return result;
    }

    /**
     * 
     * @param result
     *     The result
     */
    @JsonProperty("result")
    public void setResult(String result) {
        this.result = result;
    }

    public JsonFormatTwo withResult(String result) {
        this.result = result;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public JsonFormatTwo withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(name).append(testSteps).append(userStory).append(title).append(tags).append(startTime).append(duration).append(testFailureCause).append(testFailureClassname).append(testFailureMessage).append(annotatedResult).append(sessionId).append(driver).append(dataTable).append(manual).append(result).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof JsonFormatTwo) == false) {
            return false;
        }
        JsonFormatTwo rhs = ((JsonFormatTwo) other);
        return new EqualsBuilder().append(name, rhs.name).append(testSteps, rhs.testSteps).append(userStory, rhs.userStory).append(title, rhs.title).append(tags, rhs.tags).append(startTime, rhs.startTime).append(duration, rhs.duration).append(testFailureCause, rhs.testFailureCause).append(testFailureClassname, rhs.testFailureClassname).append(testFailureMessage, rhs.testFailureMessage).append(annotatedResult, rhs.annotatedResult).append(sessionId, rhs.sessionId).append(driver, rhs.driver).append(dataTable, rhs.dataTable).append(manual, rhs.manual).append(result, rhs.result).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
