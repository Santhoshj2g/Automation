
package com.dnb.vo.formatone;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "number",
    "description",
    "duration",
    "startTime",
    "screenshots",
    "exception",
    "result"
})
public class Child {

    @JsonProperty("number")
    private long number;
    @JsonProperty("description")
    private String description;
    @JsonProperty("duration")
    private long duration;
    @JsonProperty("startTime")
    private long startTime;
    @JsonProperty("screenshots")
    private List<Screenshot> screenshots = new ArrayList<Screenshot>();
    @JsonProperty("exception")
    private Exception_ exception;
    @JsonProperty("result")
    private String result;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public Child() {
    }

    /**
     * 
     * @param startTime
     * @param result
     * @param duration
     * @param screenshots
     * @param description
     * @param exception
     * @param number
     */
    public Child(long number, String description, long duration, long startTime, List<Screenshot> screenshots, Exception_ exception, String result) {
        this.number = number;
        this.description = description;
        this.duration = duration;
        this.startTime = startTime;
        this.screenshots = screenshots;
        this.exception = exception;
        this.result = result;
    }

    /**
     * 
     * @return
     *     The number
     */
    @JsonProperty("number")
    public long getNumber() {
        return number;
    }

    /**
     * 
     * @param number
     *     The number
     */
    @JsonProperty("number")
    public void setNumber(long number) {
        this.number = number;
    }

    public Child withNumber(long number) {
        this.number = number;
        return this;
    }

    /**
     * 
     * @return
     *     The description
     */
    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    /**
     * 
     * @param description
     *     The description
     */
    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    public Child withDescription(String description) {
        this.description = description;
        return this;
    }

    /**
     * 
     * @return
     *     The duration
     */
    @JsonProperty("duration")
    public long getDuration() {
        return duration;
    }

    /**
     * 
     * @param duration
     *     The duration
     */
    @JsonProperty("duration")
    public void setDuration(long duration) {
        this.duration = duration;
    }

    public Child withDuration(long duration) {
        this.duration = duration;
        return this;
    }

    /**
     * 
     * @return
     *     The startTime
     */
    @JsonProperty("startTime")
    public long getStartTime() {
        return startTime;
    }

    /**
     * 
     * @param startTime
     *     The startTime
     */
    @JsonProperty("startTime")
    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public Child withStartTime(long startTime) {
        this.startTime = startTime;
        return this;
    }

    /**
     * 
     * @return
     *     The screenshots
     */
    @JsonProperty("screenshots")
    public List<Screenshot> getScreenshots() {
        return screenshots;
    }

    /**
     * 
     * @param screenshots
     *     The screenshots
     */
    @JsonProperty("screenshots")
    public void setScreenshots(List<Screenshot> screenshots) {
        this.screenshots = screenshots;
    }

    public Child withScreenshots(List<Screenshot> screenshots) {
        this.screenshots = screenshots;
        return this;
    }

    /**
     * 
     * @return
     *     The exception
     */
    @JsonProperty("exception")
    public Exception_ getException() {
        return exception;
    }

    /**
     * 
     * @param exception
     *     The exception
     */
    @JsonProperty("exception")
    public void setException(Exception_ exception) {
        this.exception = exception;
    }

    public Child withException(Exception_ exception) {
        this.exception = exception;
        return this;
    }

    /**
     * 
     * @return
     *     The result
     */
    @JsonProperty("result")
    public String getResult() {
        return result;
    }

    /**
     * 
     * @param result
     *     The result
     */
    @JsonProperty("result")
    public void setResult(String result) {
        this.result = result;
    }

    public Child withResult(String result) {
        this.result = result;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Child withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(number).append(description).append(duration).append(startTime).append(screenshots).append(exception).append(result).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Child) == false) {
            return false;
        }
        Child rhs = ((Child) other);
        return new EqualsBuilder().append(number, rhs.number).append(description, rhs.description).append(duration, rhs.duration).append(startTime, rhs.startTime).append(screenshots, rhs.screenshots).append(exception, rhs.exception).append(result, rhs.result).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
