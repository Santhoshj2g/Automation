
package com.dnb.vo.formattwo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "headers",
    "rows",
    "predefinedRows",
    "currentRow",
    "dataSetDescriptors"
})
public class DataTable {

    @JsonProperty("headers")
    private List<String> headers = new ArrayList<String>();
    @JsonProperty("rows")
    private List<Row> rows = new ArrayList<Row>();
    @JsonProperty("predefinedRows")
    private boolean predefinedRows;
    @JsonProperty("currentRow")
    private CurrentRow currentRow;
    @JsonProperty("dataSetDescriptors")
    private List<DataSetDescriptor> dataSetDescriptors = new ArrayList<DataSetDescriptor>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public DataTable() {
    }

    /**
     * 
     * @param headers
     * @param predefinedRows
     * @param dataSetDescriptors
     * @param currentRow
     * @param rows
     */
    public DataTable(List<String> headers, List<Row> rows, boolean predefinedRows, CurrentRow currentRow, List<DataSetDescriptor> dataSetDescriptors) {
        this.headers = headers;
        this.rows = rows;
        this.predefinedRows = predefinedRows;
        this.currentRow = currentRow;
        this.dataSetDescriptors = dataSetDescriptors;
    }

    /**
     * 
     * @return
     *     The headers
     */
    @JsonProperty("headers")
    public List<String> getHeaders() {
        return headers;
    }

    /**
     * 
     * @param headers
     *     The headers
     */
    @JsonProperty("headers")
    public void setHeaders(List<String> headers) {
        this.headers = headers;
    }

    public DataTable withHeaders(List<String> headers) {
        this.headers = headers;
        return this;
    }

    /**
     * 
     * @return
     *     The rows
     */
    @JsonProperty("rows")
    public List<Row> getRows() {
        return rows;
    }

    /**
     * 
     * @param rows
     *     The rows
     */
    @JsonProperty("rows")
    public void setRows(List<Row> rows) {
        this.rows = rows;
    }

    public DataTable withRows(List<Row> rows) {
        this.rows = rows;
        return this;
    }

    /**
     * 
     * @return
     *     The predefinedRows
     */
    @JsonProperty("predefinedRows")
    public boolean isPredefinedRows() {
        return predefinedRows;
    }

    /**
     * 
     * @param predefinedRows
     *     The predefinedRows
     */
    @JsonProperty("predefinedRows")
    public void setPredefinedRows(boolean predefinedRows) {
        this.predefinedRows = predefinedRows;
    }

    public DataTable withPredefinedRows(boolean predefinedRows) {
        this.predefinedRows = predefinedRows;
        return this;
    }

    /**
     * 
     * @return
     *     The currentRow
     */
    @JsonProperty("currentRow")
    public CurrentRow getCurrentRow() {
        return currentRow;
    }

    /**
     * 
     * @param currentRow
     *     The currentRow
     */
    @JsonProperty("currentRow")
    public void setCurrentRow(CurrentRow currentRow) {
        this.currentRow = currentRow;
    }

    public DataTable withCurrentRow(CurrentRow currentRow) {
        this.currentRow = currentRow;
        return this;
    }

    /**
     * 
     * @return
     *     The dataSetDescriptors
     */
    @JsonProperty("dataSetDescriptors")
    public List<DataSetDescriptor> getDataSetDescriptors() {
        return dataSetDescriptors;
    }

    /**
     * 
     * @param dataSetDescriptors
     *     The dataSetDescriptors
     */
    @JsonProperty("dataSetDescriptors")
    public void setDataSetDescriptors(List<DataSetDescriptor> dataSetDescriptors) {
        this.dataSetDescriptors = dataSetDescriptors;
    }

    public DataTable withDataSetDescriptors(List<DataSetDescriptor> dataSetDescriptors) {
        this.dataSetDescriptors = dataSetDescriptors;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DataTable withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(headers).append(rows).append(predefinedRows).append(currentRow).append(dataSetDescriptors).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DataTable) == false) {
            return false;
        }
        DataTable rhs = ((DataTable) other);
        return new EqualsBuilder().append(headers, rhs.headers).append(rows, rhs.rows).append(predefinedRows, rhs.predefinedRows).append(currentRow, rhs.currentRow).append(dataSetDescriptors, rhs.dataSetDescriptors).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
