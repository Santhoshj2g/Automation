
package com.dnb.vo.formattwo;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "id",
    "storyName",
    "path",
    "narrative",
    "type"
})
public class UserStory {

    @JsonProperty("id")
    private String id;
    @JsonProperty("storyName")
    private String storyName;
    @JsonProperty("path")
    private String path;
    @JsonProperty("narrative")
    private String narrative;
    @JsonProperty("type")
    private String type;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public UserStory() {
    }

    /**
     * 
     * @param id
     * @param narrative
     * @param storyName
     * @param path
     * @param type
     */
    public UserStory(String id, String storyName, String path, String narrative, String type) {
        this.id = id;
        this.storyName = storyName;
        this.path = path;
        this.narrative = narrative;
        this.type = type;
    }

    /**
     * 
     * @return
     *     The id
     */
    @JsonProperty("id")
    public String getId() {
        return id;
    }

    /**
     * 
     * @param id
     *     The id
     */
    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public UserStory withId(String id) {
        this.id = id;
        return this;
    }

    /**
     * 
     * @return
     *     The storyName
     */
    @JsonProperty("storyName")
    public String getStoryName() {
        return storyName;
    }

    /**
     * 
     * @param storyName
     *     The storyName
     */
    @JsonProperty("storyName")
    public void setStoryName(String storyName) {
        this.storyName = storyName;
    }

    public UserStory withStoryName(String storyName) {
        this.storyName = storyName;
        return this;
    }

    /**
     * 
     * @return
     *     The path
     */
    @JsonProperty("path")
    public String getPath() {
        return path;
    }

    /**
     * 
     * @param path
     *     The path
     */
    @JsonProperty("path")
    public void setPath(String path) {
        this.path = path;
    }

    public UserStory withPath(String path) {
        this.path = path;
        return this;
    }

    /**
     * 
     * @return
     *     The narrative
     */
    @JsonProperty("narrative")
    public String getNarrative() {
        return narrative;
    }

    /**
     * 
     * @param narrative
     *     The narrative
     */
    @JsonProperty("narrative")
    public void setNarrative(String narrative) {
        this.narrative = narrative;
    }

    public UserStory withNarrative(String narrative) {
        this.narrative = narrative;
        return this;
    }

    /**
     * 
     * @return
     *     The type
     */
    @JsonProperty("type")
    public String getType() {
        return type;
    }

    /**
     * 
     * @param type
     *     The type
     */
    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    public UserStory withType(String type) {
        this.type = type;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public UserStory withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(id).append(storyName).append(path).append(narrative).append(type).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof UserStory) == false) {
            return false;
        }
        UserStory rhs = ((UserStory) other);
        return new EqualsBuilder().append(id, rhs.id).append(storyName, rhs.storyName).append(path, rhs.path).append(narrative, rhs.narrative).append(type, rhs.type).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
