package sabic.monshaat.sme.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import sabic.monshaat.exception.MyException;

public class HealthAndSafetyManagementSystemTab extends TechnicalTab {

	public HealthAndSafetyManagementSystemTab(WebDriver driver) {
		super(driver);
	}

	@FindBy(how = How.XPATH, using = "//input[contains(@value,'Does your organisation')]/parent::td/following-sibling::td/input[@id='txtAnswer']")
	public WebElement question1;

	@FindBy(how = How.XPATH, using = "//input[contains(@value,'Does this health')]/parent::td/following-sibling::td/descendant::input")
	public WebElement question2;

	@FindBy(how = How.XPATH, using = "//input[contains(@value,'Heath & Safety Management')]/parent::td/following-sibling::td/input[@value='Yes']")
	public WebElement question3Yes;

	@FindBy(how = How.XPATH, using = "//input[contains(@value,'Heath & Safety Management')]/parent::td/following-sibling::td/input[@value='No']")
	public WebElement question3No;

	@FindBy(how = How.XPATH, using = "//input[contains(@value,'Name of Health')]/parent::td/following-sibling::td/input[@value='Yes']")
	public WebElement question4Yes;

	@FindBy(how = How.XPATH, using = "//input[contains(@value,'Name of Health')]/parent::td/following-sibling::td/input[@value='No']")
	public WebElement question4No;

	@FindBy(how = How.ID, using = "btnSubmit")
	public WebElement submitOption;

	@FindBy(how = How.ID, using = "btnNext")
	public WebElement saveAndNext;

	public void fillHealthAndSafetyManagementSystemQuestioners() throws MyException {
		waitTillElementIsClickable(question1);
		type("Testing", question1);
		uploadFile(question2);
		clickOn(question3No);
		clickOn(question4No);
	}

	public TechnicalTab saveAndGoToTechnicalTab() throws InterruptedException {
		if (submitOption.isDisplayed()) {
			clickOn(submitOption);
			Thread.sleep(50000);
			waitTillElementIsClickable(popUpYes);
			clickOn(popUpYes);
		} else {
			clickOn(saveAndNext);
		}
		return new TechnicalTab(pageBrowser);
	}
}