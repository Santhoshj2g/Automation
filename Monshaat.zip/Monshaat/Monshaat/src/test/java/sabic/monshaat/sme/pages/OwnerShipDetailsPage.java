package sabic.monshaat.sme.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class OwnerShipDetailsPage extends CommercialTab {

	//private ExtentTest ownerShipDetailsTest;

	public OwnerShipDetailsPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(how = How.ID, using = "txtOwnership_Name")
	public WebElement ownerShipName;

	@FindBy(how = How.ID, using = "txtOwnership_Nationality")
	public WebElement ownerShipNationality;

	@FindBy(how = How.ID, using = "txtOwnership_Phone")
	public WebElement ownerShipPhone;

	@FindBy(how = How.ID, using = "txtOwnership_Mobile")
	public WebElement ownerShipMobile;

	@FindBy(how = How.ID, using = "txtOwnership_OwnerID")
	public WebElement ownerID;

	@FindBy(how = How.ID, using = "txtOwnership_Email")
	public WebElement ownerEmailID;

	@FindBy(how = How.ID, using = "txtOwnership_CRRelation")
	public WebElement crRelation;

	@FindBy(how = How.ID, using = "chkManagementDetails")
	public WebElement managementDetails;

	@FindBy(how = How.ID, using = "btn_OwneshipDetails_Save")
	private WebElement saveOwnerShipDetails;
	
	@FindBy(how = How.ID, using = "btn_AddOwnershipDetails")
	public WebElement addOwnerShipDetails;
	
	@FindBy(how = How.ID, using = "txtOwnershipDetailsPosition")
	public WebElement addOwnerShipPosition;
	
	@FindBy(how = How.ID, using = "txtOwnershipDetailsName")
	public WebElement addOwnerShipName;
	
	@FindBy(how = How.ID, using = "txtOwnershipDetailsEmail")
	public WebElement addOwnerShipEmailID;
	
	@FindBy(how = How.ID, using = "txtOwnershipDetailsPhone")
	public WebElement addOwnerShipPhone;
	
	@FindBy(how = How.XPATH, using = "(//button[text()='Cancel'])[1]")
	public WebElement cancelOption;

	@FindBy(how = How.ID, using = "btnAddOwnershipDetails")
	public WebElement addOption;

	public void fillOwnerShipDetails(String condition) {

		//ownerShipDetailsTest = parentTestCase.createNode("Fill OwnerShip Details",
				//"Filling the necessary OwnerShip Details");
		
		scrollToElement(ownerShipName);
		type("Owner", ownerShipName);
		type("India", ownerShipNationality);
		type("908389", ownerShipPhone);
		type("982983", ownerShipMobile);
		type("2877853", ownerID);
		type("ream@gamil.com", ownerEmailID);
		type("Manager", crRelation);
		
		if(condition.equalsIgnoreCase("Yes")) {
			clickOn(managementDetails);
			clickOn(addOwnerShipDetails);
			type("Owner", addOwnerShipPosition);
			type("India", addOwnerShipName);
			type("ream@gamil.com", addOwnerShipEmailID);
			type("982983", addOwnerShipPhone);
			clickOn(addOption);
		}

		//ownerShipDetailsTest.log(Status.INFO, "Successfully filled in all the OwnerShip Details");
	}

	public CompanyHierarchyPage saveAndGoToCompanyHierarchyPage() throws InterruptedException {
		scrollToElement(crRelation);
		Thread.sleep(2000);
		clickOn(saveOwnerShipDetails);
		//ownerShipDetailsTest.log(Status.INFO, "OwnerShip Details saved successfully");
		return new CompanyHierarchyPage(pageBrowser);
	}
}