package sabic.monshaat.sme.pages;

import java.awt.AWTException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.Assert;

import sabic.monshaat.exception.MyException;

public class CompanyDetailsPage extends CommercialTab {

	//private ExtentTest companyDetailsTest;

	public CompanyDetailsPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(how = How.ID, using = "txtCompanyName")
	public WebElement companyName;

	@FindBy(how = How.XPATH, using = "//span[@aria-owns='txtPreferredLanguage_listbox']")
	//@FindBy(how = How.CSS, using = "input#txtPreferredLanguage")
	public WebElement preferredContactLang;

	@FindBy(how = How.CSS, using = "input#txtBrandName")
	private WebElement brandName;

	@FindBy(how = How.ID, using = "txtBrandNameAr")
	private WebElement brandNameArabic;
	
	@FindBy(how = How.CSS, using = "button#btn_CompanyDetails_GeneralInformation_Save")
	private WebElement btnSaveAndNext;
	
	@FindBy(how = How.CSS, using = "input#btn_Address_Save")
	private WebElement btnAddressTabSaveAndNext;

	@FindBy(how = How.CSS, using = "input#btn_CommercialInformation_Save")
	private WebElement btnCommericalTabSaveAndNext;

	@FindBy(how = How.CSS, using = "input#btn_SAGIA_Save")
	private WebElement btnSagiaTabSaveAndNext;
	

	@FindBy(how = How.ID, using = "txtVAT")
	private WebElement vatNumber;

	@FindBy(how = How.ID, using = "txtBuildingNumber")
	private WebElement buildingNumber;

	@FindBy(how = How.ID, using = "txtDistrict")
	private WebElement district;

	@FindBy(how = How.ID, using = "FileTaxationCertificate")
	private WebElement copyOfVatCert;

	@FindBy(how = How.ID, using = "txtPostalCode")
	private WebElement postalCode;

	@FindBy(how = How.ID, using = "txtAdditionalCode")
	private WebElement additionalCode;

	@FindBy(how = How.ID, using = "VATCertificateExpirationDate")
	private WebElement vatCertExpDate;

	@FindBy(how = How.XPATH, using = "//span[@aria-controls='VATCertificateExpirationDate_dateview']/span")
	private WebElement vatCertExpCalendar;

	@FindBy(how = How.XPATH, using = "//div[@id='VATCertificateExpirationDate_dateview']//table/tbody//td[contains(@aria-label,'Current focused date is')]/following-sibling::td[1]")
	private WebElement vatCertExpCalendarFutureDate;

	@FindBy(how = How.ID, using = "txtCommercialRegistrationNumber")
	private WebElement commercialRegNumber;

	@FindBy(how = How.ID, using = "txtStreetAddress")
	private WebElement streetAddress;

	@FindBy(how = How.ID, using = "txtStreetAddressAr")
	private WebElement streetAddressArabic;

	@FindBy(how = How.ID, using = "txtCity")
	private WebElement city;

	@FindBy(how = How.ID, using = "txtCityAr")
	private WebElement cityArabic;

	@FindBy(how = How.ID, using = "txtCountry")
	private WebElement country;

	@FindBy(how = How.ID, using = "txtCountryAr")
	private WebElement countryArabic;

	@FindBy(how = How.ID, using = "CompanyRegistrationDate")
	private WebElement companyRegDate;

	@FindBy(how = How.XPATH, using = "//span[@aria-controls='CompanyRegistrationDate_dateview']/span")
	private WebElement companyRegCalendar;

	@FindBy(how = How.ID, using = "CompanyExpiryDate")
	private WebElement companyExpDate;

	@FindBy(how = How.XPATH, using = "//span[@aria-controls='CompanyExpiryDate_dateview']/span")
	private WebElement companyExpCalendar;

	@FindBy(how = How.CSS, using = "input#txtGeoLocation")
	private WebElement geoLocation;

	@FindBy(how = How.ID, using = "rdIsCRNMainYes")
	private WebElement commercialRegYES;

	@FindBy(how = How.ID, using = "rdIsCRNMainNo")
	private WebElement commercialRegNO;

	@FindBy(how = How.CSS, using = "input#FileCopyOfCRN")
	private WebElement copyOfCommercialReg;

	@FindBy(how = How.ID, using = "txtCRBusinessType")
	private WebElement commercialRegBusinessType;

	@FindBy(how = How.ID, using = "txtCRActivities")
	private WebElement commercialRegActivities;

	@FindBy(how = How.ID, using = "txtCRStatus")
	private WebElement commercialRegStatus;

	@FindBy(how = How.ID, using = "rdIsForeignInvestorComapnyYes")
	private WebElement foreignInvestorsYES;	
	
	@FindBy(how = How.XPATH, using = "//div[@id='CompanyDetails_Header4Div']/div[1]/div/div[1]/label")
	private WebElement labelForeignInvestorsNO;
	
	@FindBy(how = How.CSS, using = "div.container-fluid div#CompanyDetails_Header4Div label.padding10-radio:nth-child(4)")
	//@FindBy(how = How.XPATH, using = "//div[@id='CompanyDetails_Header4Div']/div[1]/div/div[2]/label[2]")
	private WebElement foreignInvestorsNO;

	@FindBy(how = How.ID, using = "txtSAGIACertificateNumber")
	private WebElement sagiaCertNumber;

	@FindBy(how = How.ID, using = "btnVerfiySAGIACertificateNumber")
	private WebElement verifySagiaCert;

	@FindBy(how = How.ID, using = "txtSAGIACertificateStatus")
	private WebElement sagiaCertStatus;

	@FindBy(how = How.ID, using = "SAGIACertificateExpiryDate")
	private WebElement sagiaCertExpDate;

	@FindBy(how = How.ID, using = "FileSAGIACertificateCopy")
	private WebElement copyOfSagiaCert;

	@FindBy(how = How.ID, using = "txtZAKATCertificateNumber")
	private WebElement zakatCertNumber;

	@FindBy(how = How.ID, using = "ZAKATCertificateExpiryDate")
	private WebElement zakatCertExpDate;

	@FindBy(how = How.XPATH, using = "//span[@aria-controls='ZAKATCertificateExpiryDate_dateview']/span")
	private WebElement zakatCertExpCalendar;

	@FindBy(how = How.CSS, using = "input#FileTaxationCertificate")
	private WebElement copyOfVATCert;
	
	@FindBy(how = How.CSS, using = "input#FileZAKATCertificateCopy")
	private WebElement copyOfZaktaCert;

	@FindBy(how = How.CSS, using = "input#btn_ZAKAT_Save")
	private WebElement btnZakatSaveAndNext;
	
	@FindBy(how = How.CSS, using = "input#FileGOSICertificateCopy")
	private WebElement copyOfGosiCert;
	
	
	@FindBy(how = How.XPATH, using = "//input[@id='txtWebsite']")
	private WebElement txtCompanyWebSite;
	
	@FindBy(how = How.XPATH, using = "//input[@id='txtCompanyMainEmailAddress']")
	private WebElement txtCompanyEmailAddress;
	
	@FindBy(how = How.XPATH, using = "//button[@id='btn_AddContactInformation']")
	private WebElement btnAddContactInformation;
	
	@FindBy(how = How.XPATH, using = "//input[@id='txtContactInformationName']")
	private WebElement txtNameEnglish;
	
	@FindBy(how = How.XPATH, using = "//input[@id='txtContactInformationNameAr']")
	private WebElement txtNameArabic;
	
	@FindBy(how = How.XPATH, using = "//input[@id='txtContactInformationJobTitle']")
	private WebElement txtJobTitleEnglish;
	
	@FindBy(how = How.XPATH, using = "//input[@id='txtContactInformationJobTitleAr']")
	private WebElement txtJobTitleArabic;
	
	//@FindBy(how = How.XPATH, using = "//div[@class='col-sm-12 col-xs-12 col-md-6 col-lg-6 pad-rt-15']//span[contains(text(), '--Select Contact Type--')]")
	@FindBy(how = How.XPATH, using = "//form[@id='AddContactInformationForm']/div[1]/div[5]/div[1]/span")
	private WebElement dropdownContactType;
	
	@FindBy(how = How.XPATH, using = "//input[@id='txtContactInformationEmail']")
	private WebElement txtEmail;
	
	//@FindBy(how = How.XPATH, using = "(//div[@class='col-sm-12 col-xs-12 col-md-6 col-lg-6 pad-rt-15']//span[1]/span[2])[2]")
	@FindBy(how = How.XPATH, using = "//form[@id='AddContactInformationForm']/div[1]/div[7]/div[1]/span[1]")
	private WebElement dropdownCountryCode1;
	
	@FindBy(how = How.XPATH, using = "//input[@id='txtContactInformationTelephone']")
	private WebElement txtTelephone;
	
	@FindBy(how = How.XPATH, using = "//form[@id='AddContactInformationForm']/div[1]/div[8]/div[1]/span[1]")
	private WebElement dropdownCountryCode2;
	
	@FindBy(how = How.XPATH, using = "//input[@id='txtContactInformationMobile']")
	private WebElement txtMobile;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='col-sm-12 col-xs-12 col-md-6 col-lg-6 pad-rt-15']//span[1]/span[2])[3]")
	private WebElement dropdownCountryCode3;
	
	@FindBy(how = How.CSS, using = "input#txtContactInformationFax")
	private WebElement txtFax;
	
	@FindBy(how = How.XPATH, using = "//button[@id='btnAddContactInformation1']")
	private WebElement btnAdd;
	
	
	@FindBy(how = How.XPATH, using = "//input[@id='btn_ContactInfo_Save']")
	private WebElement btnAddContactInfoSaveNext;
	
	//ends add contact information
	
	//Managment Details Start
	@FindBy(how = How.XPATH, using = "//input[@id='chkManagementDetails']")
	private WebElement MangtDetCheckbox;
	
	@FindBy(how = How.XPATH, using = "//input[@id='txtOwnershipDetailsName']")
	private WebElement txtMantName;
	
	@FindBy(how = How.XPATH, using = "//input[@id='txtOwnershipDetailsPosition']")
	private WebElement txtPosition;
	
	@FindBy(how = How.XPATH, using = "//input[@id='txtOwnershipDetailsEmail']")
	private WebElement txtMntEmail;
	
	@FindBy(how = How.XPATH, using = "//div[@id='OwnershipDetailsDiv']/div/div[2]/div[2]/div/div[1]/span[1]")
	private WebElement MangtDetaildropdown;
	
	@FindBy(how = How.XPATH, using = "//input[@id='txtOwnershipDetailsPhone']")
	private WebElement txtPhone;
	
	@FindBy(how = How.XPATH, using = "//input[@id='btn_OwneshipDetails_Save']")
	private WebElement btnMangtDetSaveNext;
	
	//Ownership edit details
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='OwnershipGrid']/div[2]/table/tbody/tr/td[13]/i")
	private WebElement editOwnershipdetails;
	
	@FindBy(how = How.XPATH, using = "//input[@id='txtOwnership_Email']")
	private WebElement txtownerEmail;
	@FindBy(how = How.XPATH, using = "//form[@id='EditOwnershipDetailsForm']/div[1]/div[4]/div[1]/span[1]")
	private WebElement ownerCountryCodeone;
	@FindBy(how = How.XPATH, using = "//input[@id='txtOwnership_Phone']")
	private WebElement ownerPhone;
	@FindBy(how = How.XPATH, using = "//form[@id='EditOwnershipDetailsForm']/div[1]/div[5]/div[1]/span[1]")
	private WebElement ownerCountryCodeTwo;
	@FindBy(how = How.XPATH, using = "//input[@id='txtOwnership_Mobile']")
	private WebElement txtownerMobile;
	@FindBy(how = How.CSS, using = "button#btnUpdateOwnershipDetails")
	private WebElement btnOwnerUpdate;
	
	
	//Company Hierarchy Page
	
	@FindBy(how = How.XPATH, using = "//div[@id='CompanyHierarchyDiv']/div/div[2]/div/div/span[2]")
	private WebElement dropdownCompanyPresence;
		
	@FindBy(how = How.XPATH, using = "//div[@id='CompanyHierarchyDiv']/div/div[3]/div[2]/label[2]")
	private WebElement rdBtnParentCompany;
	
	@FindBy(how = How.CSS, using = "input#btn_CompanyHierarchy_Save")
	private WebElement companyHierarchySaveNext;

	
	//Classification Page
	@FindBy(how = How.XPATH, using = "//div[@id='dvClassification']/div[2]/div[2]/div/div")
	private WebElement txtCompanyClassification;
	@FindBy(how = How.XPATH, using = "//div[@id='grdSMEClassificationAgentActivity']//div[2]//tbody/tr/td[contains(text(),'101041')]/..//label")
	private WebElement ActivityCode1;
	@FindBy(how = How.XPATH, using = "//div[@id='grdSMEClassificationAgentActivity']//div[2]//tbody/tr/td[contains(text(),'101042')]/..//label")
	private WebElement ActivityCode2;
	@FindBy(how = How.CSS, using = "input#btnClassificationSave")
	private WebElement CompanyClassificationSaveNext;
	@FindBy(how = How.XPATH, using = "//ul[@id='ddlSMEClassifications_listbox']/li[2]")
	private WebElement txtAgentOption;
	//@FindBy(how = How.XPATH, using = "//ul[@id='ddlSMEClassifications_listbox']/li[3]")
	//private WebElement activityCodeTwo;
	
	
	//Attachment Page(need datepicker)
	
	//@FindBy(how = How.XPATH, using = "//td[@id='AttachmentDetailsgrid_active_cell']/div[1]/span/span/span")
	@FindBy(how = How.XPATH, using = "(//div[@id='AttachmentDetailsgrid']//div[2]//tbody/tr//td[5]//div//span//span[@class='k-picker-wrap k-state-default']//span[@class='k-select'])[1]//span")
	private WebElement clickDatePickerBtn;
	
	
	@FindBy(how = How.XPATH, using = "(//td[contains(@class,'k-today')]/following-sibling::td[1]/a)[1]")
	private WebElement currDate;
	
	
	@FindBy(how = How.CSS, using = "input#btn_Atatchment_Save")
	private WebElement btnAttachedSaveAndNext;
	
	//@FindBy(how = How.XPATH, using = "//td[@id='AttachmentDetailsgrid_active_cell']/div[1]/div/div/input")
	
	//@FindBy(how = How.CSS, using = "body#MainBody td#AttachmentDetailsgrid_active_cell input.fdUpload")
	
	@FindBy(how = How.XPATH, using = "//td[@id='AttachmentDetailsgrid_active_cell']/../td[6]/div/div[1]")     
	private WebElement uploadAgencyCertificate;
	
	
	@FindBy(how = How.XPATH, using = "(//div[@id='AttachmentDetailsgrid']//div[2]//tbody/tr//td[5]//div//span//span[@class='k-picker-wrap k-state-default']//span[@class='k-select'])[1]//span")
	private WebElement AgencyCertificateAttachmentExpiryDate;
	@FindBy(how = How.XPATH, using = "(//div[@id='AttachmentDetailsgrid']//div[2]//tbody/tr//td[6]//div//div//div)[1]")
	private WebElement AgencyCertificateAction;
	@FindBy(how = How.CSS, using = "input#btn_Atatchment_Save")
	private WebElement AttachmentSaveNext;
	
	
	//Finance page
	
	@FindBy(how = How.CSS, using = "input#tech_Rdbtn_No")
	private WebElement btnDoesYourOrganizationIssueAnnualFinancialStatement ;
	
	//@FindBy(how = How.XPATH, using = "//div[@id='divFinancialjustification']/div[2]/span/span")
	@FindBy(how = How.XPATH, using = "//div[@id='divFinancialjustification']/div[2]/span[1]")
	private WebElement FinanceJustification;
	
	@FindBy(how = How.CSS, using = "input#btnSend_Finance")
	private WebElement FinancesaveNext;
	
	//Insurance Page
	
	@FindBy(how = How.CSS, using = "input#Insurance_Rdbtn_No")
	private WebElement RdbtnDoesYourOrganizationHaveInsurance ;
	@FindBy(how = How.XPATH, using = "//div[@id='divInsurancejustification']/div[2]/span")
	private WebElement InsuranceJustification	;
	@FindBy(how = How.XPATH, using = "//div/textarea[@id='txtddlInsOtherJustification']")
	private WebElement txtOthersTextArea;
	@FindBy(how = How.CSS, using = "input#btnSubmit_Insurance")
	private WebElement btnInsuranceSaveNext;
	
	
	//Corporate Social Responsibility Page
	

	@FindBy(how = How.CSS, using = "input#ItemID-82-No")
	private WebElement rdbtnQuestion1 ;

	@FindBy(how = How.CSS, using = "input#ItemID-83-No")
	private WebElement rdbtnQuestion2 ;

	@FindBy(how = How.CSS, using = "input#ItemID-84-No")
	private WebElement rdbtnQuestion3 ;

	@FindBy(how = How.CSS, using = "input#ItemID-85-No")
	private WebElement rdbtnQuestion4 ;

	@FindBy(how = How.CSS, using = "input#ItemID-86-No")
	private WebElement rdbtnQuestion5 ;

	@FindBy(how = How.CSS, using = "input#ItemID-98-No")
	private WebElement rdbtnQuestion6 ;

	@FindBy(how = How.CSS, using = "input#ItemID-99-No")
	private WebElement rdbtnQuestion7 ;

	@FindBy(how = How.CSS, using = "input#ItemID-100-No")
	private WebElement rdbtnQuestion8 ;

	@FindBy(how = How.CSS, using = "input#ItemID-101-No")
	private WebElement rdbtnQuestion9 ;

	@FindBy(how = How.CSS, using = "input#ItemID-102-No")
	private WebElement rdbtnQuestion10 ;

	@FindBy(how = How.CSS, using = "input#ItemID-103-No")
	private WebElement rdbtnQuestion11 ;

	@FindBy(how = How.CSS, using = "input#ItemID-198-No")
	private WebElement rdbtnQuestion12 ;

	@FindBy(how = How.CSS, using = "input#ItemID-104-No")
	private WebElement rdbtnQuestion13 ;

	@FindBy(how = How.CSS, using = "input#ItemID-105-No")
	private WebElement rdbtnQuestion14 ;

	@FindBy(how = How.CSS, using = "input#ItemID-106-No")
	private WebElement rdbtnQuestion15 ;

	@FindBy(how = How.CSS, using = "input#ItemID-107-No")
	private WebElement rdbtnQuestion16 ;
	
	@FindBy(how = How.CSS, using = "button#btnNext")
	private WebElement btnCSResponsibilitySaveandNext ;
	
	
	//Health and Safety Page
	
	@FindBy(how = How.CSS, using = "input#ItemID-137-No")
	private WebElement rdhsbtnQuestion1;

	@FindBy(how = How.CSS, using = "input#ItemID-128-No")
	private WebElement rdhsbtnQuestion2;

	@FindBy(how = How.CSS, using = "input#ItemID-140-No")
	private WebElement rdhsbtnQuestion3;
	
	@FindBy(how = How.CSS, using = "button#btnNext")
	private WebElement btnhsSaveandNext ;
	
	//Quality Management Page
	
	@FindBy(how = How.CSS, using = "input#ItemID-148-No")
	private WebElement rdqmbtnQuestion1;

	@FindBy(how = How.CSS, using = "input#ItemID-150-No")
	private WebElement rdqmbtnQuestion2;
	
	@FindBy(how = How.CSS, using = "button#btnNext")
	private WebElement rdqmSaveNext;
	
	// Environmental Management
		
		@FindBy(how = How.CSS, using = "input#ItemID-158-No")
		private WebElement rdembtnQuestion1;
	
		@FindBy(how = How.CSS, using = "input#ItemID-161-No")
		private WebElement rdembtnQuestion2;
		@FindBy(how = How.CSS, using = "input#chkDisclaimer")
		private WebElement checkboxDisclaimer;
	
		@FindBy(how = How.XPATH, using = "//button[@id='btnSubmit']")
		private WebElement btnemSubmit;
		
		@FindBy(how = How.CSS, using = "div.ui-dialog-buttonset button.ui-button:nth-child(2)")
		private WebElement btnemConfirmPopup;
		
	//End Home Page Validation
	
	@FindBy(how = How.ID, using = "txtAddress")
	private WebElement address;

	@FindBy(how = How.ID, using = "txtCommercialRegistrationGovernmentLicense")
	private WebElement commercialGovtLisence;
	
	@FindBy(how = How.CSS, using = "input#btn_CompanySize_Save")
	private WebElement btnCompanySizeSaveAndNext;
	

	@FindBy(how = How.ID, using = "txtNETGATStatus")
	private WebElement netgatStatus;

	@FindBy(how = How.ID, using = "txtTotalNoOfSaudiEmployees")
	private WebElement noOfSaudiEmployees;

	@FindBy(how = How.ID, using = "txtTotalNoOfEmployees")
	private WebElement noOfEmployees;



	@FindBy(how = How.ID, using = "GOSIExpirationDate")
	private WebElement gosiCertExpDate;

	@FindBy(how = How.XPATH, using = "//span[@aria-controls='GOSIExpirationDate_dateview']/span")
	private WebElement gosiCertExpCalendar;

	@FindBy(how = How.XPATH, using = "//div[@id='GOSIExpirationDate_dateview']//table/tbody//td[contains(@aria-label,'Current focused date is')]/following-sibling::td[1]")
	private WebElement gosiCertExpCalendarFutureDate;

	@FindBy(how = How.ID, using = "rdIsOrganizationHaveContentscoreYes")
	private WebElement localContentScoreYES;

	@FindBy(how = How.ID, using = "rdIsOrganizationHaveContentscoreNo")
	private WebElement localContentScoreNO;

	@FindBy(how = How.ID, using = "txtLocalContentScore")
	private WebElement localContentScore;

	@FindBy(how = How.ID, using = "btn_CompanyDetails_Save")
	private WebElement saveCompanyDetails;
	
	@FindBy(how = How.XPATH, using = "//button[text()='Save as Draft']")
	private WebElement saveAsDraft;
	
	@FindBy(how = How.ID, using = "//li[@id=\"bdcParentMenu\"]")
	private WebElement homePageSubmissionValidation;
	
	
	
	public void fillCompanyDetails() throws MyException, InterruptedException, AWTException {

		//companyDetailsTest = parentTestCase.createNode("Fill Company Details", "Filling the necessary Company Details");

		type("sabicindia", companyName);
		
		type("Sabic", brandName);
		type("سابك", brandNameArabic);
		Thread.sleep(2000);
		action.moveToElement(preferredContactLang).build().perform();
		setListBox(preferredContactLang, "English");
	
		clickOn(btnSaveAndNext);
		
		type("www.google.com", geoLocation);
		Thread.sleep(2000);
		clickOn(btnAddressTabSaveAndNext);
		
		Thread.sleep(2000);
		uploadFile(copyOfCommercialReg);
		Thread.sleep(2000);
		clickOn(btnCommericalTabSaveAndNext);
		
		Thread.sleep(4000);
		scrollToElement(labelForeignInvestorsNO);
		System.out.println(foreignInvestorsNO.isDisplayed());
		System.out.println(foreignInvestorsNO.isEnabled());
		
		System.out.println(foreignInvestorsNO.getText());
		Thread.sleep(4000);
			
		clickOnUsingJs(foreignInvestorsNO);

		
		Thread.sleep(4000);
		System.out.println("btnSagiaTabSaveAndNext click start");
		clickOn(btnSagiaTabSaveAndNext);
		System.out.println("btnSagiaTabSaveAndNext click end");
		
		Thread.sleep(2000);
		uploadFile(copyOfVATCert);
		Thread.sleep(2000);
		uploadFile(copyOfZaktaCert);
		clickOn(btnZakatSaveAndNext);
		
		Thread.sleep(2000);
		uploadFile(copyOfGosiCert);
		
		scrollToElement(btnCompanySizeSaveAndNext);
				
		System.out.println(btnCompanySizeSaveAndNext.getText());
		
		Thread.sleep(3000);
		clickOnUsingJs(btnCompanySizeSaveAndNext);
		
		Thread.sleep(3000);
		type("www.google.com", txtCompanyWebSite);
		type("abc@gmail.com", txtCompanyEmailAddress);
		
		clickOn(btnAddContactInformation);
		
		
		type("www.google.com", txtCompanyWebSite);
		
		//Add Contact Information
		
		
		type("English",txtNameEnglish);
		type("مرحبا",txtNameArabic);
		type("Job",txtJobTitleEnglish);
		type("مرحبا",txtJobTitleArabic);
		action.moveToElement(dropdownContactType).build().perform();
		setListBox(dropdownContactType,"Main Contact");
		type("sabic@sabic.com",txtEmail);
		
		
		action.moveToElement(dropdownCountryCode2).build().perform();
		setListBox(dropdownCountryCode2,"INDIA (+91)");
		Thread.sleep(2000);
		type("8056796289",txtMobile);
		
		Thread.sleep(2000);
		clickOn(btnAdd);
		
		clickOn(btnAddContactInfoSaveNext);
		Thread.sleep(3000);
		
		//Edit ownership details starts here
		
		clickOn(editOwnershipdetails);
		Thread.sleep(2000);
		type("sab@sab.com",txtownerEmail);
		type("8056796256",ownerPhone);
		type("8056796256",txtownerMobile);
		Thread.sleep(2000);
		action.moveToElement(ownerCountryCodeone).build().perform();
		setListBox(ownerCountryCodeone,"INDIA (+91)");
		Thread.sleep(2000);
		action.moveToElement(ownerCountryCodeTwo).build().perform();
		setListBox(ownerCountryCodeTwo,"INDIA (+91)");
		
		
		Thread.sleep(2000);
		
		clickOn(btnOwnerUpdate);	
		
		// Management Details Starts here
		clickOn(MangtDetCheckbox);
		type("Company",txtMantName);
		type("TestPosition",txtPosition);
		type("testmntde@mail.com",txtMntEmail);
		action.moveToElement(MangtDetaildropdown).build().perform();
		setListBox(MangtDetaildropdown,"INDIA (+91)");
		type("8056796289",txtPhone);
		Thread.sleep(3000);
		clickOn(btnMangtDetSaveNext);
		Thread.sleep(3000);
		
		
		//Company Hierarchy starts here 	
		action.moveToElement(dropdownCompanyPresence).build().perform();
		setListBox(dropdownCompanyPresence,"International");
		Thread.sleep(2000);
		clickOnUsingJs(rdBtnParentCompany);
		clickOn(companyHierarchySaveNext);
		Thread.sleep(3000);
		
		//Classification Starts here
		clickOn(txtCompanyClassification);
		Thread.sleep(4000);
		clickOn(txtAgentOption);
		
		Thread.sleep(3000);
		
		clickOnUsingJs(ActivityCode1);
		clickOnUsingJs(ActivityCode2);
		clickOn(CompanyClassificationSaveNext);
		
		
		//Attachment Page (need datepicker)
		Thread.sleep(3000);
		clickOn(clickDatePickerBtn);
		
		Thread.sleep(3000);
		clickOn(currDate);
	
		Thread.sleep(3000);
			
		//Action to upload
		String str = getProjectPath() + userProperties.fetch(""
				+ "DocPath") + userProperties.fetch("uploadDocName");
        uploadFile(uploadAgencyCertificate,str);

		
		Thread.sleep(3000);

		clickOn(btnAttachedSaveAndNext);
		
		//Finance Page starts here
		Thread.sleep(3000);
		clickOnUsingJs(btnDoesYourOrganizationIssueAnnualFinancialStatement);
		
		action.moveToElement(FinanceJustification).build().perform();
		setListBox(FinanceJustification,"The company does not have financial statement due to the lack of capabilities");
	 
		clickOn(FinancesaveNext);
		
		
		//Insurance Page starts here
		
		Thread.sleep(3000);
		clickOnUsingJs(RdbtnDoesYourOrganizationHaveInsurance);
		action.moveToElement(InsuranceJustification).build().perform();
		setListBox(InsuranceJustification,"Others");
		type("Message",txtOthersTextArea);
		
		Thread.sleep(2000);
		clickOn(btnInsuranceSaveNext);
		
		
		//Corporate Social Responsibility Starts here	
		clickOnUsingJs(rdbtnQuestion1);
		clickOnUsingJs(rdbtnQuestion2);
		clickOnUsingJs(rdbtnQuestion3);
		clickOnUsingJs(rdbtnQuestion4);
		clickOnUsingJs(rdbtnQuestion5);
		clickOnUsingJs(rdbtnQuestion6);
		clickOnUsingJs(rdbtnQuestion7);
		clickOnUsingJs(rdbtnQuestion8);
		clickOnUsingJs(rdbtnQuestion9);
		clickOnUsingJs(rdbtnQuestion10);
		clickOnUsingJs(rdbtnQuestion11);
		clickOnUsingJs(rdbtnQuestion12);
		clickOnUsingJs(rdbtnQuestion13);
		clickOnUsingJs(rdbtnQuestion14);
		clickOnUsingJs(rdbtnQuestion15);
		clickOnUsingJs(rdbtnQuestion16);
		Thread.sleep(3000);
		clickOn(btnCSResponsibilitySaveandNext);
	
		
		
		//Health and Safety Page
		
		clickOnUsingJs(rdhsbtnQuestion1);
		clickOnUsingJs(rdhsbtnQuestion2);
		clickOnUsingJs(rdhsbtnQuestion3);
		clickOn(btnhsSaveandNext);
		Thread.sleep(2000);
		
		
		//Quality Management Page
		
		clickOnUsingJs(rdqmbtnQuestion1);
		clickOnUsingJs(rdqmbtnQuestion2);
		
		clickOn(rdqmSaveNext);
		Thread.sleep(2000);
		
		//Environmental Management Page
		
		
		clickOnUsingJs(rdembtnQuestion1);
		clickOnUsingJs(rdembtnQuestion2);
		clickOnUsingJs(checkboxDisclaimer);	
		Thread.sleep(3000);
		clickOn(btnemSubmit);
		Thread.sleep(3000);
		clickOnUsingJs(btnemConfirmPopup);
		
		
		System.out.println("profile registered successfully");
		
	
		//companyDetailsTest.log(Status.INFO, "Successfully filled in all the Company Details");
	}

	public ContactsInfoPage saveAndGoToContactsInfoPage() {
		scrollToElement(copyOfGosiCert);
		clickOn(saveCompanyDetails);
		//waitTillElementIsClickable(saveAsDraft);
		//clickOn(saveAsDraft);
		//companyDetailsTest.log(Status.INFO, "Company Details saved successfully");
		return new ContactsInfoPage(pageBrowser);
	}
	//After Submission Validation
	public void EndPageValidation() {
		String actual=fetchTextFrom(homePageSubmissionValidation);
		String expected="Home";
		Assert.assertEquals(actual, expected);
	}
	
	
}