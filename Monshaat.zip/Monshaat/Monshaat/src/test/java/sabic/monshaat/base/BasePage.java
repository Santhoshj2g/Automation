package sabic.monshaat.base;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import sabic.monshaat.exception.MyException;
import sabic.monshaat.sme.pages.LoginPage;

public class BasePage extends TestSetUp {

	protected WebDriver pageBrowser;
	protected WebDriverWait wait;
	protected Actions action;
	protected JavascriptExecutor js;

	public BasePage(WebDriver driver) {
		this.pageBrowser = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(pageBrowser, ELEMENT_WAIT_TIME);
		action = new Actions(pageBrowser);
		js = (JavascriptExecutor) pageBrowser;
	}

	public LoginPage openApplication(String appURL) {
		pageBrowser.get(appURL);
		return new LoginPage(pageBrowser);
	}

	public void scrollToElement(WebElement element) {
		String test = element.getText();
		System.out.println("test data : "+test);
		js.executeScript("arguments[0].scrollIntoView(true);", element);
		
	}

	public void waitTillElementIsClickable(WebElement element) {
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}

	public void clickOn(WebElement element) {

		//((JavascriptExecutor) pageBrowser).executeScript("arguments[0].scrollIntoView(true);", element);
		element.click();
	
	}
	public void clickOnUsingJs(WebElement element) {
	JavascriptExecutor executor = (JavascriptExecutor)pageBrowser;
	executor.executeScript("arguments[0].click();", element);
	}
	public void type(String text, WebElement element) {
		
		((JavascriptExecutor) pageBrowser).executeScript("arguments[0].scrollIntoView(true);", element);
		element.clear();
		element.sendKeys(text);
	}

	public void type(Keys keys, WebElement element) {
		element.sendKeys(keys);
	}

	public String fetchTextFrom(WebElement element) {
		return element.getText();
	}

	public void setListBox(WebElement element, String text) throws InterruptedException {
		clickOn(element);
		Thread.sleep(3000);
		System.out.println(text);
		element.sendKeys(text);
		Thread.sleep(2000);
		element.sendKeys(Keys.RETURN);
		//element.sendKeys(Keys.ENTER);
	}
	
	public void setListBoxOne(WebElement element, String text) throws InterruptedException {
		clickOn(element);
		Thread.sleep(3000);
		System.out.println(text);
		element.sendKeys(text);
		Thread.sleep(2000);
		
		element.sendKeys(Keys.ENTER);
	}

	public void uploadFile(WebElement element) throws MyException {
		element.sendKeys(getProjectPath() + userProperties.fetch("uploadDocPath"),
				userProperties.fetch("uploadDocName"));
	}
	
	public void uploadFile(WebElement element, String filePath) throws MyException, AWTException, InterruptedException {
		element.click();
		Thread.sleep(3000);
	    //put path to your image in a clipboard
	    StringSelection ss = new StringSelection(filePath);
	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
	    Thread.sleep(2000);
	    //imitate mouse events like ENTER, CTRL+C, CTRL+V
	    Robot robot = new Robot();
	    robot.keyPress(KeyEvent.VK_ENTER);
	    robot.keyRelease(KeyEvent.VK_ENTER);
	    robot.keyPress(KeyEvent.VK_CONTROL);
	    robot.keyPress(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_CONTROL);
	    robot.keyPress(KeyEvent.VK_ENTER);
	    robot.keyRelease(KeyEvent.VK_ENTER);
	}
	
	public void currentDatePicker() throws MyException{
		
		String today;
		  //Get Today's number
        today = getCurrentDay();
        System.out.println("Today's number: " + today + "\n");
		
		//This is from date picker table
        WebElement dateWidgetFrom = pageBrowser.findElement(By.cssSelector("table.k-content tbody"));
 
        //This are the rows of the from date picker table
        //List<WebElement> rows = dateWidgetFrom.findElements(By.tagName("tr"));
 
        //This are the columns of the from date picker table
        List<WebElement> columns = dateWidgetFrom.findElements(By.tagName("td"));
 
        //DatePicker is a table. Thus we can navigate to each cell
        //and if a cell matches with the current date then we will click it.
        for (WebElement cell: columns) {
            /*
            //If you want to click 18th Date
            if (cell.getText().equals("18")) {
            */
            //Select Today's Date
            if (cell.getText().equals(today)) {
                cell.click();
                break;
            }
            
        }    
        
	}
        
        //Get The Current Day
        private String getCurrentDay (){
            //Create a Calendar Object
            Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
     
            //Get Current Day as a number
            int todayInt = calendar.get(Calendar.DAY_OF_MONTH);
            System.out.println("Today Int: " + todayInt +"\n");
     
            //Integer to String Conversion
            String todayStr = Integer.toString(todayInt);
            System.out.println("Today Str: " + todayStr + "\n");
     
            return todayStr;
        }
        /*
        public void takeScreenShot() {
        	
        	 File scrFile = ((TakesScreenshot)pageBrowser).getScreenshotAs(OutputType.FILE);
        	 FileUtils.copyFile(scrFile, new File(filePath+methodName+".png"));
        	 //  D:\TestingCoe\Monshaat\Monshaat\src\main\resources\failedscreen
        }
        */
	
}