package sabic.monshaat.sme.pages;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import sabic.monshaat.exception.MyException;

public class ClassificationTab extends RegisterProfilePage {

	public ClassificationTab(WebDriver driver) {
		super(driver);
	}

	@FindBy(how = How.ID, using = "MonshaatClassification")
	public WebElement monshaatClassification;

	@FindBy(how = How.XPATH, using = "//input[@aria-owns='ddlSMEClassifications_taglist ddlSMEClassifications_listbox']")
	public WebElement smeClassification;

	@FindBy(how = How.ID, using = "btnClassificationSave")
	public WebElement saveAndProceed;

	@FindBy(how = How.XPATH, using = "//input[@id='hdnSelectedManufacturerActivityIDs']/parent::div//descendant::table[2]/tbody")
	public WebElement manufacturerActivityTable;

	@FindBy(how = How.XPATH, using = "//input[@id='hdnSelectedAgentActivityIDs']/parent::div//descendant::table[2]/tbody")
	public WebElement agentActivityTable;

	@FindBy(how = How.XPATH, using = "//input[@id='hdnSelectedDistributorActivityIDs']/parent::div//descendant::table[2]/tbody")
	public WebElement distributorActivityTable;

	@FindBy(how = How.XPATH, using = "//input[@id='hdnSelectedTraderActivityIDs']/parent::div//descendant::table[2]/tbody")
	public WebElement traderActivityTable;

	@FindBy(how = How.XPATH, using = "//input[@id='hdnSelectedServiceProviderActivityIDs']/parent::div//descendant::table[2]/tbody")
	public WebElement serviceProviderActivityTable;

	@FindBy(how = How.XPATH, using = "(//div[@id='AttachmentDetailsgrid']//table)[2]//tbody//div[@aria-label='Select files...']")
	public WebElement selectFiles;

	@FindBy(how = How.ID, using = "AttachmentFile")
	public WebElement addAttachment;

	@FindBy(how = How.ID, using = "btnUploadFile_popup")
	public WebElement saveAttachment;

	@FindBy(how = How.XPATH, using = "//button[text()='Close']")
	public WebElement closeAttachment;

	@FindBy(how = How.ID, using = "btn_Classification_Save")
	private WebElement saveClassification;

	@FindBy(how = How.XPATH, using = "(//a[text()='Activity Code'])[4]/preceding-sibling::a[@href='javascript:void(0)']")
	private WebElement activityCodeFilterIcon;

	@FindBy(how = How.XPATH, using = "//input[@title='Value']")
	private WebElement activityCodeFilterValueTextBox;

	@FindBy(how = How.XPATH, using = "//button[text()='Filter']")
	private WebElement activityCodeFilterButton;

	@FindBy(how = How.XPATH, using = "(//div[@id='AttachmentDetailsgrid']//table)[2]//tbody")
	private WebElement attachmentTable;
	
	@FindBy(how = How.XPATH, using = "//button[text()='Delete']")
	private WebElement deleteOption;
	

	public void fillClassificationDetails(String condition, String activityCode)
			throws MyException, InterruptedException, AWTException {
		waitTillElementIsClickable(smeClassification);
		if (condition.equals("Manufacturer")) {
			setListBox(smeClassification, condition);
		} else if (condition.equals("Agent")) {
			setListBox(smeClassification, condition);
		} else if (condition.equals("Distributor")) {
			setListBox(smeClassification, condition);
		} else if (condition.equals("Trader")) {
			setListBox(smeClassification, condition);
		} else if (condition.equals("Service Provider")) {
			setListBox(smeClassification, condition);
		}
		Thread.sleep(3000);
		js.executeScript("arguments[0].click();", activityCodeFilterIcon);
		Thread.sleep(1000);
		type(activityCode, activityCodeFilterValueTextBox);
		Thread.sleep(1000);
		clickOn(activityCodeFilterButton);
		Thread.sleep(3000);
		clickOn(pageBrowser.findElement(By.xpath("//td[text()='"+activityCode+"']/preceding-sibling::td[2]")));
		clickOn(saveAndProceed);
		scrollToElement(saveAndProceed);
		boolean status = attachmentTable.isDisplayed();
		if (status == true) {
			Thread.sleep(5000);
			uploadFile(selectFiles,getProjectPath() + "\\src\\main\\resources\\doc\\sample.pdf");
			//waitTillElementIsClickable(deleteOption);
		}
	}

	public FinancePage saveAndGoToFinancePage() throws InterruptedException {
		Thread.sleep(3000);
		//scrollToElement(deleteOption);
		//Thread.sleep(2000);
		clickOn(saveClassification);
		return new FinancePage(pageBrowser);
	}
}