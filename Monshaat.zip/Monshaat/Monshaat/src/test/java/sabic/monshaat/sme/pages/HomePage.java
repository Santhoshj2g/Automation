package sabic.monshaat.sme.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import sabic.monshaat.base.BasePage;

public class HomePage extends BasePage {

	public HomePage(WebDriver driver) {
		super(driver);
	}

	@FindBy(how = How.XPATH, using = "((//div[@class='category-content no-padding'])[1]/child::ul[4]//span)[1]")
	public WebElement manageLink;
	
	@FindBy(how = How.XPATH, using = "//li[@class=\"brd-overwrite\"]/a/i")
	public WebElement expandLink;
	
	//@FindBy(how = How.XPATH, using = "((//div[@class='category-content no-padding'])[1]/child::ul[4]//ul//span)[1]")
	@FindBy(how = How.CSS, using = "div#divContainerPageMar div.sidebar-content a[data-cssclass='registerprofile_icon_breadcrumb']")
	public WebElement registerProfileLink;
	
	@FindBy(how = How.XPATH, using = "((//div[@class='category-content no-padding'])[1]/child::ul[3]//span)[1]")
	public WebElement myBasketLink;
	
	@FindBy(how = How.XPATH, using = "((//div[@class='category-content no-padding'])[1]/child::ul[3]//ul//span)[1]")
	public WebElement myrequestLink;
	
	@FindBy(how = How.XPATH, using = "//button[@class='dropbtn userProfile']//i[@class='caret']")
	public WebElement userProfileButton;

	@FindBy(how = How.XPATH, using = "//span[text()='Logout']")
	public WebElement logOutOption;

	@FindBy(how = How.XPATH, using = "//a[text()=' Back to Login']")
	public WebElement backToLogin;
	
	public RegisterProfilePage goToRegisterProfile() {
		clickOn(expandLink);
		//action.moveToElement(manageLink).build().perform();
		clickOn(registerProfileLink);
		return new RegisterProfilePage(pageBrowser);
	}
	
	public MyRequestPage goToMyRequest() {
		action.moveToElement(myBasketLink).build().perform();
		clickOn(myrequestLink);
		return new MyRequestPage(pageBrowser);
	}

	public LoginPage logOutApplication() {
		clickOn(userProfileButton);
		clickOn(logOutOption);
		waitTillElementIsClickable(backToLogin);
		return new LoginPage(pageBrowser);
	}
}