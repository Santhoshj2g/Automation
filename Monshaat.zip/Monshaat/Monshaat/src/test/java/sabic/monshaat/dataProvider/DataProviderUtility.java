package sabic.monshaat.dataProvider;

import java.lang.reflect.Method;

import org.testng.annotations.DataProvider;

import sabic.monshaat.exception.MyException;
import sabic.monshaat.helper.ExcelReader;

public class DataProviderUtility /* extends TestSetUp */ {
	
	ExcelReader excelReader;
	
	@DataProvider(name = "SME_Registration_Trader")
	public Object[][] dataProviderMethod(Method method) throws MyException {

		Object[][] testDataArray = null;
		try {
			if (method.getName().equals("dataProvider")) {
				excelReader = new ExcelReader(
						"C:\\Automation\\projects\\Monshaat\\src\\main\\resources\\excel\\", "TestData.xlsx");
				testDataArray = excelReader.readExcelSheet("Sheet1");
			}
		} catch (Exception exp) {
			MyException.fire(
					"Unable to read the excelSheet:Sheet1" + "in the form of a DataProvider" + exp.getMessage() + "\n");
		}
		return testDataArray;
	}
}