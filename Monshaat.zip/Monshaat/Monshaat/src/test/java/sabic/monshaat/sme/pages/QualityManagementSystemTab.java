package sabic.monshaat.sme.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class QualityManagementSystemTab extends TechnicalTab {

	public QualityManagementSystemTab(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(how = How.XPATH, using = "//td[@id='tdControls']/span[@aria-live='polite']")
	public WebElement question1;
	
	@FindBy(how = How.XPATH, using = "//input[contains(@value,'(QMS)?')]/parent::td/following-sibling::td/input[@value='Yes']")
	public WebElement question2Yes;
	
	@FindBy(how = How.XPATH, using = "//input[contains(@value,'(QMS)?')]/parent::td/following-sibling::td/input[@value='No']")
	public WebElement question2No;
	
	@FindBy(how = How.ID, using = "btnNext")
	public WebElement saveAndNext;
	
	public void fillQualityManagementSystemQuestioners() {
		
	}
	
	public TechnicalTab saveAndGoToTechnicalTab() {
		clickOn(saveAndNext);
		return new TechnicalTab(pageBrowser);
	}
}