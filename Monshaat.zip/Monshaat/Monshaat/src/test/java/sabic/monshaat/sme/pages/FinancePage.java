package sabic.monshaat.sme.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import sabic.monshaat.exception.MyException;

public class FinancePage extends TechnicalTab {

	public FinancePage(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(how = How.ID, using = "tech_Rdbtn_Yes")
	public WebElement issueAnnualStatementYES;
	
	@FindBy(how = How.ID, using = "tech_Rdbtn_No")
	public WebElement issueAnnualStatementNO;
	
	@FindBy(how = How.ID, using = "txtFinancialJustification")
	public WebElement justificationTextBox;
	
	@FindBy(how = How.ID, using = "btn_AddFinanceDetails")
	public WebElement addFinancialDetails;
	
	@FindBy(how = How.XPATH, using = "//span[@aria-owns='txtStrtYrDt_listbox']")
	public WebElement financialStatementYear;
	
	@FindBy(how = How.XPATH, using = "//span[@aria-owns='Currency_listbox']")
	public WebElement currencyListBox;
	
	@FindBy(how = How.ID, using = "txtInventory")
	public WebElement inventory;
	
	@FindBy(how = How.ID, using = "txtRecievables")
	public WebElement receivables;
	
	@FindBy(how = How.ID, using = "txtCrntAsset")
	public WebElement currentAssets;
	
	@FindBy(how = How.ID, using = "txtNonCrntAssets")
	public WebElement nonCurrentAssets;
	
	@FindBy(how = How.ID, using = "txtShortDate")
	public WebElement shortTermDebt;
	
	@FindBy(how = How.ID, using = "txtCrntMaturityAssetDebt")
	public WebElement maturityofLongTermDebt;
	
	@FindBy(how = How.ID, using = "txtCrntLiabilities")
	public WebElement currentLiabilities;
	
	@FindBy(how = How.ID, using = "txtLongTermDebt")
	public WebElement longTermDebt;
	
	@FindBy(how = How.ID, using = "txtNonCrntLiabilities")
	public WebElement nonCurrentLiabilities;
	
	@FindBy(how = How.ID, using = "txtEquity")
	public WebElement equity;
	
	@FindBy(how = How.ID, using = "txtRevenues")
	public WebElement revenues;
	
	@FindBy(how = How.ID, using = "txtGrossProfit")
	public WebElement grossProfit;
	
	@FindBy(how = How.ID, using = "txtNetincome")
	public WebElement netIncome;
	
	@FindBy(how = How.ID, using = "financialAttachments")
	public WebElement netIncomeAttachment;
	
	@FindBy(how = How.ID, using = "btnTechnicalClose_Popup")
	public WebElement close;
	
	@FindBy(how = How.ID, using = "btnTechnicalSave_Popup")
	public WebElement save;
	
	@FindBy(how = How.ID, using = "btnSend_Finance")
	private WebElement saveFinancialDetails;
	
	@FindBy(how = How.XPATH, using = "//i[@onclick='DeleteFinanceDetailsRecord(this);']")
	private WebElement deleteFinanceRecordDetails;
	
	public void fillFinanceDetails(String condition) throws MyException, InterruptedException {
		if(condition.equalsIgnoreCase("Yes")) {
			waitTillElementIsClickable(issueAnnualStatementYES);
			clickOn(issueAnnualStatementYES);
			Thread.sleep(5000);
			clickOn(addFinancialDetails);
			Thread.sleep(2000);
			setListBox(financialStatementYear, "2019");
			setListBox(currencyListBox, "USD");
			
			type("111", inventory);
			type("111", receivables);
			type("111", currentAssets);
			type("111", nonCurrentAssets);
			type("111", shortTermDebt);
			type("111", maturityofLongTermDebt);
			type("111", currentLiabilities);
			type("111", longTermDebt);
			type("111", nonCurrentLiabilities);
			type("111", equity);
			type("111", revenues);
			type("111", grossProfit);
			type("111", netIncome);
			Thread.sleep(1000);
			uploadFile(netIncomeAttachment);
			Thread.sleep(1000);
			clickOn(save);
		} else if(condition.equalsIgnoreCase("No")) {
			clickOn(issueAnnualStatementNO);
			type("Testing", justificationTextBox);
		}
	}
	
	public InsurancePage saveAndGoToInsurancePage() throws InterruptedException {
		Thread.sleep(2000);
		scrollToElement(deleteFinanceRecordDetails);
		Thread.sleep(2000);
		clickOn(saveFinancialDetails);
		return new InsurancePage(pageBrowser);
	}
}