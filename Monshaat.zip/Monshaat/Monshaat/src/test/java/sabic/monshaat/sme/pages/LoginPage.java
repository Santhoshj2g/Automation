package sabic.monshaat.sme.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import sabic.monshaat.auditor.pages.AuditorHomePage;
import sabic.monshaat.base.BasePage;

public class LoginPage extends BasePage {

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(how = How.ID, using = "UserName")
	private WebElement userNameTextBox;

	@FindBy(how = How.ID, using = "Password")
	private WebElement passWordTextBox;

	@FindBy(how = How.ID, using = "PageContentContainer_SubmitBut")
	private WebElement loginButton;

	@FindBy(how = How.XPATH, using = "//a[@class='login-link']")
	private WebElement forgotPasswordLink;

	@FindBy(how = How.XPATH, using = "(//div[@id='myModalCR']//table)[2]/tbody")
	private WebElement crListTable;

	public void loginUsingCredentials(String userName, String passWord) {
		type(userName, userNameTextBox);
		type(passWord, passWordTextBox);
		clickOn(loginButton);
	}
	
	public AuditorHomePage gotToAuditorHomePage() {
		return new AuditorHomePage(pageBrowser);
	}

	public HomePage selectCRNumber(String crNumber) {
		waitTillElementIsClickable(crListTable);
		List<WebElement> rows = crListTable.findElements(By.tagName("tr"));
		int rowCount = rows.size();
		System.out.println("row count is:" + rowCount);
		for (int i = 1; i <= rowCount; i++) {
			String value = fetchTextFrom(
					pageBrowser.findElement(By.xpath("(//div[@id='myModalCR']//table)[2]/tbody/tr[" + i + "]/td[1]")));
			System.out.println("Expected Value:"+value);
			if (value.equals(crNumber)) {
				System.out.println("Actual Value:"+crNumber);
				clickOn(pageBrowser.findElement(By.xpath("(//div[@id='myModalCR']//table)[2]/tbody//td[text()='"
						+ crNumber + "']/parent::tr/td[7]/div")));
				break;
			}
		}
		return new HomePage(pageBrowser);
	}
}