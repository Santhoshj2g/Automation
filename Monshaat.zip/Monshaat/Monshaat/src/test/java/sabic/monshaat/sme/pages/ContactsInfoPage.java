package sabic.monshaat.sme.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class ContactsInfoPage extends CommercialTab {

	// private ExtentTest contactsInfoTest;

	public ContactsInfoPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(how = How.ID, using = "txtWebsite")
	public WebElement companyWebSite;

	@FindBy(how = How.ID, using = "txtCompanyMainEmailAddress")
	public WebElement companyMailID;

	@FindBy(how = How.ID, using = "btn_AddContactInformation")
	public WebElement addContactInfo;

	@FindBy(how = How.XPATH, using = "//span[@aria-owns='ContactType_listbox']")
	public WebElement contactType;

	@FindBy(how = How.ID, using = "txtContactInformationName")
	public WebElement contactInfoName;

	@FindBy(how = How.ID, using = "txtContactInformationNameAr")
	public WebElement contactInfoNameArabic;

	@FindBy(how = How.ID, using = "txtContactInformationJobTitle")
	public WebElement contactInfoJobTitle;

	@FindBy(how = How.ID, using = "txtContactInformationJobTitleAr")
	public WebElement contactInfoJobTitleArabic;

	@FindBy(how = How.ID, using = "txtContactInformationEmail")
	public WebElement contactInfoEmail;

	@FindBy(how = How.ID, using = "txtContactInformationTelephone")
	public WebElement contactInfoTelNo;

	@FindBy(how = How.ID, using = "txtContactInformationMobile")
	public WebElement contactInfoMobNo;

	@FindBy(how = How.ID, using = "txtContactInformationFax")
	public WebElement contactInfoFax;

	@FindBy(how = How.XPATH, using = "(//button[text()='Cancel'])[1]")
	public WebElement cancelOption;

	@FindBy(how = How.XPATH, using = "//button[text()='Add']")
	public WebElement addOption;

	@FindBy(how = How.ID, using = "btn_ContactInfo_Save")
	private WebElement saveContactsInfo;

	@FindBy(how = How.XPATH, using = "//button[text()='Save as Draft']")
	private WebElement saveAsDraft;

	public void fillContactsInformation() throws InterruptedException {

		// contactsInfoTest = parentTestCase.createNode("Fill Contacts Information",
		// "Filling the necessary Contacts Information");

		waitTillElementIsClickable(companyWebSite);
		type("Company Website", companyWebSite);
		type("mailid@gmail.com", companyMailID);
		clickOn(addContactInfo);

		waitTillElementIsClickable(contactType);
		setListBox(contactType, "Admin");
		type("Contact Name", contactInfoName);
		type("Job Title", contactInfoJobTitle);
		type("mailid@gmail.com", contactInfoEmail);
		type("012345678", contactInfoTelNo);
		type("012345678", contactInfoMobNo);
		type("012345678", contactInfoFax);
		clickOn(addOption);

		// contactsInfoTest.log(Status.INFO, "Successfully filled in all the Contacts
		// Information");
	}

	public OwnerShipDetailsPage saveAndGoToOwnerShipDetailsPage() throws InterruptedException {
		Thread.sleep(3000);
		scrollToElement(addContactInfo);
		clickOn(saveContactsInfo);
		//waitTillElementIsClickable(saveAsDraft);
		//clickOn(saveAsDraft);
		// contactsInfoTest.log(Status.INFO, "Contacts Information saved successfully");
		return new OwnerShipDetailsPage(pageBrowser);
	}
}