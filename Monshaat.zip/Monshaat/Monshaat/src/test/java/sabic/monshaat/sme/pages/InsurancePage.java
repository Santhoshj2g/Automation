package sabic.monshaat.sme.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import sabic.monshaat.exception.MyException;

public class InsurancePage extends TechnicalTab {

	public InsurancePage(WebDriver driver) {
		super(driver);
	}

	@FindBy(how = How.ID, using = "Insurance_Rdbtn_Yes")
	public WebElement insuranceYES;

	@FindBy(how = How.ID, using = "Insurance_Rdbtn_No")
	public WebElement insuranceNO;

	@FindBy(how = How.ID, using = "txtInsuranceJustification")
	public WebElement justificationTextBox;

	@FindBy(how = How.ID, using = "btn_AddInsuranceDetails")
	public WebElement addInsuranceDetails;

	@FindBy(how = How.XPATH, using = "//span[@aria-owns='InsuranceTypes_listbox']")
	public WebElement insuranceType;

	@FindBy(how = How.ID, using = "txtInsuranceCompany")
	public WebElement insuranceCompany;

	@FindBy(how = How.XPATH, using = "//span[@aria-controls='txtStrtYrDt_dateview']")
	public WebElement startDateCalendar;

	@FindBy(how = How.XPATH, using = "//span[@aria-controls='txtExpDate_dateview']")
	public WebElement endDateCalendar;

	@FindBy(how = How.XPATH, using = "//div[@id='txtExpDate_dateview']//table/tbody//td[contains(@aria-label,'Current focused date is')]/following-sibling::td[1]")
	public WebElement endDateCalendarFutureDate;

	@FindBy(how = How.XPATH, using = "//span[@aria-owns='txtCurrency_listbox']")
	public WebElement currencyType;

	@FindBy(how = How.ID, using = "txtValueofCover")
	public WebElement valueofCover;

	@FindBy(how = How.ID, using = "InsuranceAttachments")
	public WebElement copyofInsuranceCertificate;

	@FindBy(how = How.ID, using = "btnInsuranceClose_Popup")
	public WebElement close;

	@FindBy(how = How.ID, using = "btnInsuranceSave_Popup")
	public WebElement addInsurance;

	@FindBy(how = How.ID, using = "btnSubmit_Insurance")
	private WebElement saveInsuranceDetails;
	
	@FindBy(how = How.XPATH, using = "//i[@onclick='DeleteInsuranceDetailsRecord(this);']")
	private WebElement deleteInsuranceRecordDetails;

	public void fillInsuranceDetails(String condition) throws MyException, InterruptedException {
		if (condition.equalsIgnoreCase("Yes")) {
			waitTillElementIsClickable(insuranceYES);
			clickOn(insuranceYES);
			Thread.sleep(3000);
			clickOn(addInsuranceDetails);
			Thread.sleep(1000);
			setListBox(insuranceType, "Healthcare Secure");
			type("Testing", insuranceCompany);
			Thread.sleep(1000);
			action.moveToElement(startDateCalendar).click(startDateCalendar).sendKeys(Keys.RETURN).build().perform();
			Thread.sleep(1000);
			action.moveToElement(endDateCalendar).click(endDateCalendar).build().perform();
			Thread.sleep(1000);
			action.click(endDateCalendarFutureDate).sendKeys(Keys.RETURN).build().perform();
			Thread.sleep(1000);
			setListBox(currencyType, "USD");
			Thread.sleep(1000);
			type("111", valueofCover);
			Thread.sleep(1000);
			uploadFile(copyofInsuranceCertificate);
			Thread.sleep(1000);
			clickOn(addInsurance);
		} else if (condition.equalsIgnoreCase("No")) {
			clickOn(insuranceNO);
			type("Testing", justificationTextBox);
		}
	}

	public CorporateSocialResponsibiltyTab saveAndGoToTechnicalTab() throws InterruptedException {
		Thread.sleep(2000);
		scrollToElement(deleteInsuranceRecordDetails);
		Thread.sleep(2000);
		clickOn(saveInsuranceDetails);
		return new CorporateSocialResponsibiltyTab(pageBrowser);
	}
}