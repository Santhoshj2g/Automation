package sabic.monshaat.testcases;

import java.awt.AWTException;

import org.testng.annotations.Test;

import sabic.monshaat.base.TestBase;
import sabic.monshaat.exception.MyException;

public class SMERegistrationTrader extends TestBase {
	
	String workFlowID;

	@Test
	public void smeRegistrationTrader() throws MyException, InterruptedException, AWTException {

		//parentTestCase = extentReport.createTest("SME_Registration_Trader");

		loginToTheApplication(userProperties.fetch("smeUserName"), userProperties.fetch("smePassWord"));
		chooseCRNumber();
	
		commercialTab = registerProfielPage.goToCommercialTab();
		companyDetailsPage = commercialTab.goToCompanyDetailsPage();
		companyDetailsPage.fillCompanyDetails();
		/*
		contactsInfoPage = companyDetailsPage.saveAndGoToContactsInfoPage();
		contactsInfoPage.fillContactsInformation();

		ownerShipDetailsPage = contactsInfoPage.saveAndGoToOwnerShipDetailsPage();
		ownerShipDetailsPage.fillOwnerShipDetails("Yes");

		companyHierarchyPage = ownerShipDetailsPage.saveAndGoToCompanyHierarchyPage();
		companyHierarchyPage.fillCompanyHierarchyDetails("Yes");

		classificationTab = companyHierarchyPage.saveAndGoToClassificationTab();
		classificationTab.fillClassificationDetails("Trader", "101021");

		financePage = classificationTab.saveAndGoToFinancePage();
		financePage.fillFinanceDetails("Yes");

		insurancePage = financePage.saveAndGoToInsurancePage();
		insurancePage.fillInsuranceDetails("Yes");

		technicalTab = insurancePage.saveAndGoToTechnicalTab();
		corporateSocialResponsibilityTab = technicalTab.goToCorporateSocialResponsibiltyTab();
		corporateSocialResponsibilityTab.fillCorporateSocialResponsibiltyQuestioners();

		technicalTab = corporateSocialResponsibilityTab.saveAndGoToTechnicalTab();
		healthAndSafetyManagementSystemTab = technicalTab.goToHealthAndSafetyManagementSystemTab();
		healthAndSafetyManagementSystemTab.fillHealthAndSafetyManagementSystemQuestioners();

		technicalTab = healthAndSafetyManagementSystemTab.saveAndGoToTechnicalTab();
		homePage = technicalTab.gotToHomePage();
		Thread.sleep(50000);
		myRequestPage = homePage.goToMyRequest();
		/*workFlowID = myRequestPage.getWorkFlowID();
		System.out.println(workFlowID);*/
	}

	//@Test
	public void approvalByAuditor() throws MyException, InterruptedException {
		loginToTheApplication(userProperties.fetch("auditorUserName"), userProperties.fetch("auditorPassWord"));
		auditorHomePage = loginPage.gotToAuditorHomePage();

		newRegistrationPendingPage = auditorHomePage.goToNewRegistrationPendingPage();
		auditorHomePage = newRegistrationPendingPage.takeActionOnPendingRegistration("1000043");
		
		newRequestPage = auditorHomePage.goToNewRequestPage();
		newRequestPage.takeActionOnPendingRegistration("1000043");
		
		newRequestPage.reviewAttachments();
		newRequestPage.approvalProcess("Approval");
	}
}