package sabic.monshaat.auditor.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class NewRequestPage extends AuditorHomePage {

	public NewRequestPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(how = How.XPATH, using = "//a[text()='Review Attachments']")
	public WebElement reviewAttachmentsOption;

	@FindBy(how = How.XPATH, using = "//button[text()='View Profile']")
	public WebElement viewProfileOption;

	@FindBy(how = How.XPATH, using = "//div[@id='attachmentGrid']//table/tbody")
	public WebElement reviewAttachmentsTable;

	@FindBy(how = How.XPATH, using = "(//div[@id='grdWorkHistoryDetails']//table)[2]")
	public WebElement workFlowHistoryTable;

	@FindBy(how = How.XPATH, using = "//span[@aria-owns='ddlAction_listbox']")
	public WebElement actionListBox;

	@FindBy(how = How.ID, using = "PreQualificationAuditorComment")
	public WebElement comments;

	@FindBy(how = How.XPATH, using = "//button[text()=' Submit']")
	public WebElement submitOption;

	@FindBy(how = How.XPATH, using = "//button[text()=' Cancel']")
	public WebElement cancelOption;

	public void takeActionOnPendingRegistration(String workFlowID) throws InterruptedException {
		Thread.sleep(50000);
		waitTillElementIsClickable(
				pageBrowser.findElement(By.xpath("//div[@id='QuestionDiv']/descendant::table[2]/tbody")));
		List<WebElement> rows = pageBrowser
				.findElements(By.xpath("//div[@id='QuestionDiv']/descendant::table[2]/tbody/tr"));
		int rowCount = rows.size();
		for (int i = 1; i <= rowCount; i++) {
			String id = pageBrowser
					.findElement(By.xpath("//div[@id='QuestionDiv']/descendant::table[2]/tbody/tr[" + i + "]/td[2]"))
					.getText();
			if (workFlowID.equals(id)) {
				pageBrowser.findElement(By.xpath("//div[@id='QuestionDiv']/descendant::table[2]/tbody/tr[" + i
						+ "]/td[13]/a[text()='Take Action']")).click();
				break;
			}
		}
		Thread.sleep(10000);
	}

	public void reviewAttachments() throws InterruptedException {
		Thread.sleep(10000);
		scrollToElement(reviewAttachmentsOption);
		waitTillElementIsClickable(reviewAttachmentsTable);
		List<WebElement> rows = reviewAttachmentsTable.findElements(By.tagName("tr"));
		int rowCount = rows.size();
		for (int i = 1; i <= rowCount; i++) {
			Thread.sleep(3000);
			pageBrowser.findElement(By.xpath("//div[@id='attachmentGrid']/descendant::table/tbody/tr[" + i
					+ "]/td[4]/span[text()='-- Select --']")).click();
			Thread.sleep(1000);
			clickOn(pageBrowser.findElement(By.xpath("//span[@aria-owns='Action_listbox']//span[@class='k-input']")));
			Thread.sleep(1000);
			clickOn(pageBrowser.findElement(By.xpath("//li[text()='Accept']")));
		}
		Thread.sleep(3000);
	}

	public void approvalProcess(String status) throws InterruptedException {
		scrollToElement(actionListBox);
		Thread.sleep(1000);
		setListBox(actionListBox, status);
		type("Testing", comments);
		clickOn(submitOption);
	}
}