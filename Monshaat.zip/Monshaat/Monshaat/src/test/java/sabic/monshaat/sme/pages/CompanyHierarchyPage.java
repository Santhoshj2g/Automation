package sabic.monshaat.sme.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CompanyHierarchyPage extends CommercialTab {

	public CompanyHierarchyPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(how = How.ID, using = "rdTech_Orgz_ParentCompanyYes")
	public WebElement parentCompanyYES;

	@FindBy(how = How.XPATH, using = "//span[@aria-owns='ddlCompanyPresence_listbox']")
	public WebElement companyPresence;

	@FindBy(how = How.ID, using = "txtCompanyHierarchy_ParentCompanyName")
	public WebElement parentCompanyName;

	@FindBy(how = How.XPATH, using = "//span[@aria-owns='txtCompanyHierarchy_InCorporationCountry_listbox']")
	public WebElement incorporationCountry;

	@FindBy(how = How.ID, using = "txtCompanyHierarchy_City")
	public WebElement parentCompanyCity;

	@FindBy(how = How.ID, using = "txtCompanyHierarchy_PostalCode")
	public WebElement parentCompanyPostalCode;

	@FindBy(how = How.ID, using = "txtCompanyHierarchy_Address")
	public WebElement parentCompanyAddress;

	@FindBy(how = How.ID, using = "txtCompanyHierarchy_CommericalRegistration")
	public WebElement parentCompanyLisence;

	@FindBy(how = How.ID, using = "rdTech_Orgz_ParentCompanyNo")
	public WebElement parentCompanyNO;

	@FindBy(how = How.ID, using = "btn_CompanyHierarchy_Save")
	private WebElement saveCompanyHierarchy;

	public void fillCompanyHierarchyDetails(String condition) throws InterruptedException {
		waitTillElementIsClickable(companyPresence);
		Thread.sleep(3000);
		setListBox(companyPresence, "International");
		if (condition.equalsIgnoreCase("Yes")) {
			Thread.sleep(2000);
			clickOn(parentCompanyYES);
			type("Testing", parentCompanyName);
			setListBox(incorporationCountry, "India");
			type("Riyadh", parentCompanyCity);
			scrollToElement(parentCompanyPostalCode);
			type("123456", parentCompanyPostalCode);
			type("Testing", parentCompanyAddress);
			type("Testing", parentCompanyLisence);
		} else if (condition.equalsIgnoreCase("No")) {
			clickOn(parentCompanyNO);
		}
	}

	public ClassificationTab saveAndGoToClassificationTab() throws InterruptedException {
		Thread.sleep(2000);
		clickOn(saveCompanyHierarchy);
		return new ClassificationTab(pageBrowser);
	}
}