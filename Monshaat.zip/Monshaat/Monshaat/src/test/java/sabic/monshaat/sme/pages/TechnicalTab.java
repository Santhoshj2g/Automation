package sabic.monshaat.sme.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class TechnicalTab extends RegisterProfilePage {

	public TechnicalTab(WebDriver driver) {
		super(driver);
	}

	@FindBy(how = How.XPATH, using = "//a[text()='Corporate Social Responsibilty']")
	public WebElement corporateSocialResponsibiltyTab;

	@FindBy(how = How.XPATH, using = "//a[text()='Health & Safety Management System']")
	public WebElement healthAndSafetyManagementSystemTab;

	@FindBy(how = How.XPATH, using = "//a[text()='//a[text()='Quality Management System']']")
	public WebElement qualityManagementSystemTab;

	@FindBy(how = How.XPATH, using = "//a[text()='Supply Chain Management']")
	public WebElement supplyChainManagementTab;
	
	@FindBy(how = How.XPATH, using = "//a[text()='Corporate Social Responsibilty']/ancestor::ul[@id='myTabMD']/following-sibling::p//table[@id='QuestionnaireTbl']")
	public WebElement corporateSocialResponsibiltyQuestionerTable;

	@FindBy(how = How.XPATH, using = "//a[text()='Health & Safety Management System']/ancestor::ul[@id='myTabMD']/following-sibling::p//table[@id='QuestionnaireTbl']")
	public WebElement healthAndSafetyManagementQuestionerTable;
	
	@FindBy(how = How.XPATH, using = "//a[text()='Quality Management System']/ancestor::ul[@id='myTabMD']/following-sibling::p//table[@id='QuestionnaireTbl']")
	public WebElement qualityManagementSystemQuestionerTable;
	
	@FindBy(how = How.XPATH, using = "//a[text()='Supply Chain Management']/ancestor::ul[@id='myTabMD']/following-sibling::p//table[@id='QuestionnaireTbl']")
	public WebElement supplyChainManagementQuestionerTable;

	@FindBy(how = How.ID, using = "btnSubmit")
	public WebElement submitOption;

	@FindBy(how = How.XPATH, using = "//button[text()='Yes']")
	public WebElement popUpYes;

	@FindBy(how = How.ID, using = "//button[text()='No']")
	public WebElement popUpNo;

	public CorporateSocialResponsibiltyTab goToCorporateSocialResponsibiltyTab() {
		waitTillElementIsClickable(corporateSocialResponsibiltyQuestionerTable);
		clickOn(corporateSocialResponsibiltyQuestionerTable);
		return new CorporateSocialResponsibiltyTab(pageBrowser);
	}

	public HealthAndSafetyManagementSystemTab goToHealthAndSafetyManagementSystemTab() throws InterruptedException {
		Thread.sleep(50000);
		clickOn(healthAndSafetyManagementQuestionerTable);
		return new HealthAndSafetyManagementSystemTab(pageBrowser);
	}

	public QualityManagementSystemTab goToQualityManagementSystemTab() {
		waitTillElementIsClickable(qualityManagementSystemQuestionerTable);
		clickOn(qualityManagementSystemQuestionerTable);
		return new QualityManagementSystemTab(pageBrowser);
	}

	public SupplyChainManagementTab goToSupplyChainManagementTab() {
		waitTillElementIsClickable(supplyChainManagementQuestionerTable);
		clickOn(supplyChainManagementQuestionerTable);
		return new SupplyChainManagementTab(pageBrowser);
	}

	public HomePage gotToHomePage() {
		return new HomePage(pageBrowser);
	}
}