package sabic.monshaat.testcases;

import java.util.Map;

import org.testng.annotations.Test;

import sabic.monshaat.dataProvider.DataProviderUtility;

public class TestDataProvider {
	
	@Test(dataProvider = "SME_Registration_Trader", dataProviderClass = DataProviderUtility.class)
	public void dataProvider(Map<String,String> testData) {
		System.out.println(testData.get("UserName"));
		System.out.println(testData.get("PassWord"));
		System.out.println(testData.get("UserName1"));
		System.out.println(testData.get("PassWord1"));
	}
}