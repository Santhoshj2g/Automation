package sabic.monshaat.base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import sabic.monshaat.auditor.pages.AuditorHomePage;
import sabic.monshaat.auditor.pages.NewRegistrationPendingPage;
import sabic.monshaat.auditor.pages.NewRequestPage;
import sabic.monshaat.exception.MyException;
import sabic.monshaat.helper.BrowserFactory;
import sabic.monshaat.helper.ConfigReader;
import sabic.monshaat.helper.ExcelReader;
import sabic.monshaat.helper.SnapShot;
import sabic.monshaat.sme.pages.ClassificationTab;
import sabic.monshaat.sme.pages.CommercialTab;
import sabic.monshaat.sme.pages.CompanyDetailsPage;
import sabic.monshaat.sme.pages.CompanyHierarchyPage;
import sabic.monshaat.sme.pages.ContactsInfoPage;
import sabic.monshaat.sme.pages.CorporateSocialResponsibiltyTab;
import sabic.monshaat.sme.pages.FinancePage;
import sabic.monshaat.sme.pages.HealthAndSafetyManagementSystemTab;
import sabic.monshaat.sme.pages.HomePage;
import sabic.monshaat.sme.pages.InsurancePage;
import sabic.monshaat.sme.pages.LoginPage;
import sabic.monshaat.sme.pages.MyRequestPage;
import sabic.monshaat.sme.pages.OwnerShipDetailsPage;
import sabic.monshaat.sme.pages.RegisterProfilePage;
import sabic.monshaat.sme.pages.TechnicalTab;

public class TestSetUp {

	protected static WebDriver myBrowser;

	protected static ConfigReader userProperties;
	BrowserFactory browserFactory;
	protected SnapShot snap;
	protected ExcelReader excelReader;

	protected BasePage basePage;
	protected LoginPage loginPage;
	protected HomePage homePage;
	protected RegisterProfilePage registerProfielPage;
	protected CommercialTab commercialTab;
	protected CompanyDetailsPage companyDetailsPage;
	protected ContactsInfoPage contactsInfoPage;
	protected OwnerShipDetailsPage ownerShipDetailsPage;
	protected CompanyHierarchyPage companyHierarchyPage;
	protected ClassificationTab classificationTab;
	protected FinancePage financePage;
	protected InsurancePage insurancePage;
	protected TechnicalTab technicalTab;
	protected CorporateSocialResponsibiltyTab corporateSocialResponsibilityTab;
	protected HealthAndSafetyManagementSystemTab healthAndSafetyManagementSystemTab;
	protected MyRequestPage myRequestPage;
	
	protected AuditorHomePage auditorHomePage;
	protected NewRegistrationPendingPage newRegistrationPendingPage;
	protected NewRequestPage newRequestPage;

	/*protected ExtentHtmlReporter htmlReporter;
	protected ExtentReports extentReport;
	protected static ExtentTest parentTestCase;*/

	protected String testRunTimeStamp;

	public static final String CONFIG_FILE_PATH = "\\src\\main\\resources\\config\\";
	public static final String CONFIG_FILE_NAME = "config.properties";
	public static final int PAGE_WAIT_TIME = 150;
	public static final int ELEMENT_WAIT_TIME = 25;
	public static final TimeUnit TIME_UNIT = TimeUnit.SECONDS;

	public String getProjectPath() {
		return System.getProperty("user.dir");
	}

	public String getConfigFilePath() {
		return getProjectPath() + CONFIG_FILE_PATH;
	}

	public String getConfigFileName() {
		return CONFIG_FILE_NAME;
	}

	public void getTimeStamp() {
		java.util.Date today = new java.util.Date();
		testRunTimeStamp = new java.sql.Timestamp(today.getTime()).toString();
		testRunTimeStamp = testRunTimeStamp.replace(" ", "_").replace(":", "_").replace(".", "_");
	}

	/*public void initializeTestReport() throws MyException {
		htmlReporter = new ExtentHtmlReporter(getProjectPath() + userProperties.fetch("reportPath")
				+ userProperties.fetch("reportName") + "_" + testRunTimeStamp + ".html");
		htmlReporter.setAppendExisting(false);
		htmlReporter.config().setReportName(userProperties.fetch("reportDocumentName"));
		htmlReporter.config().setTheme(Theme.DARK);
		extentReport = new ExtentReports();
		extentReport.attachReporter(htmlReporter);
	}*/

	public void loadUserProperties(String propertyFileName) throws MyException {
		userProperties = new ConfigReader(getConfigFilePath(), propertyFileName);
	}

	public void initiateExcelFile() throws MyException {
		excelReader = new ExcelReader(getProjectPath() + userProperties.fetch("excelFilePath"),
				userProperties.fetch("excelFileName"));
	}

	public void initiateBrowserInstance() throws MyException {
		browserFactory = new BrowserFactory(getProjectPath() + userProperties.fetch("driverFilesPath"));
	}

	public void openTheBrowser() throws MyException {
		myBrowser = browserFactory.launch(userProperties.fetch("browserName"));
		myBrowser.manage().timeouts().pageLoadTimeout(PAGE_WAIT_TIME, TIME_UNIT);
		myBrowser.manage().timeouts().implicitlyWait(PAGE_WAIT_TIME, TIME_UNIT);
	}

	public void initializeSnapShot() throws MyException {
		snap = new SnapShot(getProjectPath() + userProperties.fetch("snapShotPath"), myBrowser);
	}

	public void loginToTheApplication(String userName, String passWord) throws MyException {
		loginPage = basePage.openApplication(userProperties.fetch("appURL"));
		loginPage.loginUsingCredentials(userName, passWord);
	}

	public void chooseCRNumber() throws MyException {
		homePage = loginPage.selectCRNumber(userProperties.fetch("crNumber"));
		registerProfielPage = homePage.goToRegisterProfile();
	}
}