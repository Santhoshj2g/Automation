package sabic.monshaat.auditor.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import sabic.monshaat.base.BasePage;

public class AuditorHomePage extends BasePage {

	public AuditorHomePage(WebDriver driver) {
		super(driver);
	}

	@FindBy(how = How.XPATH, using = "((//div[@class='category-content no-padding'])[1]/child::ul[3]//span)[1]")
	public WebElement myBasket;

	@FindBy(how = How.XPATH, using = "((//div[@class='category-content no-padding'])[1]/child::ul[3]//ul//span)[1]")
	public WebElement newRegistrationPendingItems;

	@FindBy(how = How.XPATH, using = "((//div[@class='category-content no-padding'])[1]/child::ul[3]//ul//span)[2]")
	public WebElement newRequest;

	public NewRegistrationPendingPage goToNewRegistrationPendingPage() throws InterruptedException {
		action.moveToElement(myBasket).build().perform();
		Thread.sleep(1000);
		clickOn(newRegistrationPendingItems);
		return new NewRegistrationPendingPage(pageBrowser);
	}

	public NewRequestPage goToNewRequestPage() throws InterruptedException {
		action.moveToElement(myBasket).build().perform();
		Thread.sleep(1000);
		clickOn(newRequest);
		return new NewRequestPage(pageBrowser);
	}
}