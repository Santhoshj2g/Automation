package sabic.monshaat.sme.pages;

import org.openqa.selenium.WebDriver;

public class CommercialTab extends RegisterProfilePage {

	public CommercialTab(WebDriver driver) {
		super(driver);
	}

	public CompanyDetailsPage goToCompanyDetailsPage() {
		return new CompanyDetailsPage(pageBrowser);
	}
}