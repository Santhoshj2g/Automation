package sabic.monshaat.sme.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CorporateSocialResponsibiltyTab extends TechnicalTab {

	public CorporateSocialResponsibiltyTab(WebDriver driver) {
		super(driver);
	}

	@FindBy(how = How.XPATH, using = "//td[@id='tdControls']/span[@aria-live='polite']")
	public WebElement isrtListBox;

	@FindBy(how = How.XPATH, using = "//input[@name='childitem.Answer']")
	public WebElement isrtTestTextBox;
	
	@FindBy(how = How.XPATH, using = "//input[contains(@value,'Does your organisation')]/parent::td/following-sibling::td/input[@id='txtAnswer']")
	public WebElement question1;

	@FindBy(how = How.XPATH, using = "//input[contains(@value,'Have any directors')]/parent::td/following-sibling::td/input[@value='Yes']")
	public WebElement question2Yes;

	@FindBy(how = How.XPATH, using = "//input[contains(@value,'Have any directors')]/parent::td/following-sibling::td/input[@value='No']")
	public WebElement question2No;

	@FindBy(how = How.XPATH, using = "//input[@name='item.Answer']")
	public WebElement question2;

	@FindBy(how = How.ID, using = "btnNext")
	public WebElement saveAndNext;

	public void fillCorporateSocialResponsibiltyQuestioners() throws InterruptedException {
		waitTillElementIsClickable(isrtListBox);
		setListBox(isrtListBox, "International Council of Chemicals Associations");
		type("Testing", isrtTestTextBox);
		scrollToElement(isrtTestTextBox);
		type("Testing", question1);
		clickOn(question2No);
	}

	public TechnicalTab saveAndGoToTechnicalTab() throws InterruptedException {
		Thread.sleep(2000);
		clickOn(saveAndNext);
		return new TechnicalTab(pageBrowser);
	}
}