package sabic.monshaat.sme.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MyRequestPage extends HomePage {

	public MyRequestPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(how = How.XPATH, using = "(//div[@id='SMEBasketGridHd']//table)[2]/tbody")
	public WebElement requestTable;

	public String getWorkFlowID() {
		String workFlowID = "";
		List<WebElement> rows = requestTable.findElements(By.tagName("tr"));
		int rowCount = rows.size();
		for (int i = 1; i <= rowCount; i++) {
			WebElement row = pageBrowser.findElement(By.xpath("(//div[@id='SMEBasketGridHd']//table)[2]/tbody/tr["+i+"]"));
			String status = row.findElement(By.tagName("td[5]")).getText();
			if(status.equals("UnAssigned")) {
				workFlowID = row.findElement(By.tagName("td[2]")).getText();
				break;
			}
		}
		return workFlowID;
	}
}