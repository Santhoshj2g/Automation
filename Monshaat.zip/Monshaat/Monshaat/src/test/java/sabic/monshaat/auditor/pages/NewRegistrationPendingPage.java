package sabic.monshaat.auditor.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class NewRegistrationPendingPage extends AuditorHomePage {

	public NewRegistrationPendingPage(WebDriver driver) {
		super(driver);
	}

	public AuditorHomePage takeActionOnPendingRegistration(String workFlowID) throws InterruptedException {
		waitTillElementIsClickable(
				pageBrowser.findElement(By.xpath("//div[@id='QuestionDiv']/descendant::table[2]/tbody")));
		List<WebElement> rows = pageBrowser
				.findElements(By.xpath("//div[@id='QuestionDiv']/descendant::table[2]/tbody/tr"));
		int rowCount = rows.size();
		for (int i = 1; i <= rowCount; i++) {
			String id = pageBrowser
					.findElement(By.xpath("//div[@id='QuestionDiv']/descendant::table[2]/tbody/tr[" + i + "]/td[2]"))
					.getText();
			if (workFlowID.equals(id)) {
				pageBrowser.findElement(By.xpath("//div[@id='QuestionDiv']/descendant::table[2]/tbody/tr[" + i
						+ "]/td[13]/a[text()='Assign to Me']")).click();
				break;
			}
		}
		Thread.sleep(15000);
		return new AuditorHomePage(pageBrowser);
	}
}