package sabic.monshaat.sme.pages;

import org.openqa.selenium.WebDriver;

import sabic.monshaat.base.BasePage;

public class RegisterProfilePage extends BasePage {

	public RegisterProfilePage(WebDriver driver) {
		super(driver);
	}

	public CommercialTab goToCommercialTab() {
		return new CommercialTab(pageBrowser);
	}
}