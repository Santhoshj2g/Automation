package sabic.monshaat.base;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import sabic.monshaat.exception.MyException;

public class TestBase extends TestSetUp {

	@BeforeSuite
	public void beforeEntireTestSuite() throws MyException {
		getTimeStamp();
		loadUserProperties(getConfigFileName());
		//initializeTestReport();
	}

	@BeforeClass
	public void beforeEachTestClasses() throws MyException {
		initiateExcelFile();
		initiateBrowserInstance();
	}

	@BeforeMethod
	public void beforeEachTestCase() throws MyException {
		openTheBrowser();
		basePage = new BasePage(myBrowser);
		initializeSnapShot();
	}

	@AfterMethod(alwaysRun = true)
	public void afterEachTestCase(Method method, ITestResult status) throws MyException {
		//loginPage = homePage.logOutApplication();
		if (ITestResult.SUCCESS == status.getStatus()) {
			//parentTestCase.log(Status.PASS, "Successfully completed registering SME for trader");
		} else if (ITestResult.FAILURE == status.getStatus()) {
			snap.saveAs("1.png");
		} else if (ITestResult.SKIP == status.getStatus()) {

		}
		//myBrowser.quit();
	}

	@AfterSuite
	public void afterEntireTestSuite() {
		//extentReport.flush();
	}
}