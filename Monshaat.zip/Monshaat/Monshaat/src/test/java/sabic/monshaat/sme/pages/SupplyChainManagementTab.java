package sabic.monshaat.sme.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class SupplyChainManagementTab extends TechnicalTab {

	public SupplyChainManagementTab(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(how = How.XPATH, using = "//input[contains(@value,'approved register of suppliers?')]/parent::td/following-sibling::td/input[@value='Yes']")
	public WebElement question2Yes;
	
	@FindBy(how = How.XPATH, using = "//input[contains(@value,'approved register of suppliers?')]/parent::td/following-sibling::td/input[@value='No']")
	public WebElement question2No;
	
	@FindBy(how = How.NAME, using = "btnNext")
	public WebElement saveAndNext;

	public void fillSupplyChainManagementQuestioners() {
		
	}

	public TechnicalTab saveAndGoToTechnicalTab() {
		clickOn(saveAndNext);
		return new TechnicalTab(pageBrowser);
	}
}