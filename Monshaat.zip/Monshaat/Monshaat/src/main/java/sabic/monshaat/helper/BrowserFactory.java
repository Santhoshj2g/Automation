package sabic.monshaat.helper;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import sabic.monshaat.exception.MyException;

public class BrowserFactory {

	private WebDriver lDriver;
	private String lDriverFilesPath;

	private static final String CHROME_PROPERTY = "webdriver.chrome.driver";
	private static final String FIREFOX_PROPERTY = "webdriver.gecko.driver";

	private static final String CHROME_DRIVER_FILE_NAME = "chromedriver.exe";
	private static final String FIREFOX_DRIVER_FILE_NAME = "geckodriver.exe";

	public BrowserFactory(String driverFilesPath) {
		setlDriverFilesPath(driverFilesPath);
	}

	public WebDriver launch(String browserName) throws MyException {
		try {
			if (browserName.equalsIgnoreCase("Chrome")) {
				System.setProperty(CHROME_PROPERTY, getlDriverFilesPath() + CHROME_DRIVER_FILE_NAME);
				setlDriver(new ChromeDriver());
			} else if (browserName.equalsIgnoreCase("Firefox")) {
				System.setProperty(FIREFOX_PROPERTY, getlDriverFilesPath() + FIREFOX_DRIVER_FILE_NAME);
				setlDriver(new FirefoxDriver());
			} else {
				MyException.fire("Incorrect Browser type:" + browserName);
			}
			getlDriver().manage().window().maximize();
		} catch (Exception e) {
			MyException.fire("Unable to launch:" + browserName + "\n" + e.getMessage());
		}
		return getlDriver();
	}

	public WebDriver getlDriver() {
		return lDriver;
	}

	public void setlDriver(WebDriver lDriver) {
		this.lDriver = lDriver;
	}

	public String getlDriverFilesPath() {
		return lDriverFilesPath;
	}

	public void setlDriverFilesPath(String lDriverFilesPath) {
		this.lDriverFilesPath = lDriverFilesPath;
	}
}