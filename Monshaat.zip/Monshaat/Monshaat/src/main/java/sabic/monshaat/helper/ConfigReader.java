package sabic.monshaat.helper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import sabic.monshaat.exception.MyException;

public class ConfigReader {

	private File propertyFile;
	private FileInputStream propertyFis;
	private Properties properties;

	public ConfigReader(String propertyFilePath, String propertyFileName) throws MyException {
		setPropertyFile(new File(propertyFilePath + propertyFileName));
		try {
			setPropertyFis(new FileInputStream(propertyFile));
		} catch (FileNotFoundException e) {
			MyException.fire("Unable to read property file:" + propertyFileName);
		}
		setProperties(new Properties());
	}

	public String fetch(String key) throws MyException {
		try {
			getProperties().load(propertyFis);
		} catch (IOException e) {
			MyException.fire("Unable to fetch the value for key:" + key + " " + "from the property file");
		}
		return getProperties().get(key).toString();
	}

	public void setPropertyFile(File propertyFile) {
		this.propertyFile = propertyFile;
	}

	public void setPropertyFis(FileInputStream propertyFis) {
		this.propertyFis = propertyFis;
	}

	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}
}