package sabic.monshaat.helper;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

import sabic.monshaat.exception.MyException;

public class SnapShot {

	private WebDriver lBrowser;
	private String lSnapShotPath;
	private File sourceImage;
	private File finalImage;

	public SnapShot(String snapShotPath, WebDriver driver) {
		setlBrowser(driver);
		setlSnapShotPath(snapShotPath);
	}

	public String saveAs(String snapShotName) throws MyException {
		setSourceImage(((TakesScreenshot) lBrowser).getScreenshotAs(OutputType.FILE));
		setFinalImage(new File(lSnapShotPath + snapShotName));
		try {
			FileHandler.copy(getSourceImage(), getFinalImage());
		} catch (IOException e) {
			MyException.fire("Unable to save snapshot as:" + " " + snapShotName);
		}
		return getFinalImage().getAbsolutePath();
	}

	public WebDriver getlBrowser() {
		return lBrowser;
	}

	public void setlBrowser(WebDriver lBrowser) {
		this.lBrowser = lBrowser;
	}

	public String getlSnapShotPath() {
		return lSnapShotPath;
	}

	public void setlSnapShotPath(String lSnapShotPath) {
		this.lSnapShotPath = lSnapShotPath;
	}

	public File getSourceImage() {
		return sourceImage;
	}

	public void setSourceImage(File sourceImage) {
		this.sourceImage = sourceImage;
	}

	public File getFinalImage() {
		return finalImage;
	}

	public void setFinalImage(File finalImage) {
		this.finalImage = finalImage;
	}
}