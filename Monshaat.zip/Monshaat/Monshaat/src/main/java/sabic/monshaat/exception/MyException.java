package sabic.monshaat.exception;

@SuppressWarnings("serial")
public class MyException extends Exception {

	public MyException(String message) {
		super(message);
	}

	public static void fire(String message) throws MyException {
		throw new MyException(message);
	}
}