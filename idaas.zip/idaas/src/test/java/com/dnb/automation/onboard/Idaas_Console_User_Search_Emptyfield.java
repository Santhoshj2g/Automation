package com.dnb.automation.onboard;
import org.openqa.selenium.WebDriver;

import net.serenitybdd.jbehave.SerenityStory;
import net.thucydides.core.annotations.Managed;
public class Idaas_Console_User_Search_Emptyfield extends SerenityStory {
	@Managed(uniqueSession = true, driver="chrome")
    public WebDriver webdriver;
	
	public Idaas_Console_User_Search_Emptyfield() {
		runSerenity().inASingleSession();
	}
}
