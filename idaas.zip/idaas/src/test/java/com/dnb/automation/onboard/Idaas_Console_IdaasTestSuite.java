package com.dnb.automation.onboard;
import java.io.IOException;

import org.junit.After;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.openqa.selenium.WebDriver;

import com.dnb.automation.onboard.pages.CommonXpath;

import net.serenitybdd.jbehave.SerenityStories;
import net.thucydides.core.annotations.Managed;

@RunWith(Suite.class)
@Suite.SuiteClasses({Idaas_Console_Group_Search_Download.class,
	Idaas_Console_Group_Update.class,
	Idaas_Console_Notification.class,
	Idaas_Console_Security.class,
	Idaas_Console_Subscriber_Search.class,
	Idaas_Console_Subscriber_Search_Emptyfield.class,
	Idaas_Console_Subscriber_Search_Negativescenario.class,
	Idaas_Console_User_Creation_Emptyfield.class,
	Idaas_Console_User_Creation_User_Update.class,
	Idaas_Console_User_Creation.class,
	Idaas_Console_User_Search_Download.class,
	Idaas_Console_User_Search_Emptyfield.class,
	Idaas_Console_User_Search.class,
	Idaas_Console_User_Update.class})
public class Idaas_Console_IdaasTestSuite extends SerenityStories {
	@Managed(uniqueSession = true, driver="chrome")
    public WebDriver webdriver;
	
	public Idaas_Console_IdaasTestSuite() {
		runSerenity().inASingleSession();
	}
	@After
	public void cleanUp() throws IOException {
		CommonXpath objOnboardCommonXpath=new CommonXpath();
		objOnboardCommonXpath.exception();
}
}