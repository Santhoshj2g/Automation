package com.dnb.automation.onboard.tests;

import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

import static org.hamcrest.MatcherAssert.assertThat;


import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.hamcrest.Matchers;
import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.dnb.automation.onboard.pages.CommonXpath;

import Utils.UnZip;
import Utils.excelFileValidation;


public class IdassXpathTest extends ScenarioSteps{
	@Steps
	CommonXpath cXpath;
	UnZip zipObj = new UnZip();
	

    // User logs into the application
    @Given("User launches Idaas Console")
    public void launchApplication() throws Exception {
    	String appplicationURL = System.getProperty("appURL");
    	cXpath.launchOnboardApplication(appplicationURL);
    }

    // User verifies the user-name and password
    @Given("User enters $User_Name and $user_password")
    
    public void appLogin(String User_Name,String user_password) throws Exception {
    	String username = System.getProperty("appUserName");
        String pwd = System.getProperty("appPassword");
        if (!username.isEmpty() && !pwd.isEmpty()){
        cXpath.Entervalue(User_Name.replace("{", "").replace("}", ""), username.replace("{", "").replace("}", ""));
        cXpath.Entervalue(user_password.replace("{", "").replace("}", ""), pwd.replace("{", "").replace("}", ""));
    }
    }
    @When("User enters $value1 for $password1 and $value2 for $confpassword")
    public void checkpassword(String password1,String confpassword,String value1,String value2){
    	
       	 cXpath.Entervalue(password1.replace("{", "").replace("}", ""), value1.replace("{", "").replace("}", ""));
       	 cXpath.Entervalue(confpassword.replace("{", "").replace("}", ""), value2.replace("{", "").replace("}", ""));
       
    }
    @When("User select the list value for the fields as <ListFieldName> for <ListValue> under $ListTabValue")
    public void selectListValue(String ListTabName, String ListFieldName, String ListValue)
    {
      cXpath.enterListInputs(ListTabName.replace("{", "").replace("}", ""), ListFieldName, ListValue);
    }

    @When("User enter the value <TextFieldName> with <TextValue> under $TextTabValue")
    public void enterTxtInputs(String TextTabName, String TextFieldName, String TextValue){
      cXpath.enterTxtInputs(TextTabName.replace("{", "").replace("}", ""),TextFieldName,TextValue);
    }

    @When("User click on $linkName Link under $tabName")
    public void clickLink(String tabName, String linkName){
      System.out.println("linkname is------"+linkName+"under tabname is------"+tabName);
      cXpath.clickLink(tabName.replace("{", "").replace("}", ""),linkName.replace("{", "").replace("}", ""));
    }

    @Then ("User click the $name button")
    public void status(String name)
    {
    	cXpath.clickstatus(name.replace("{", "").replace("}", ""));
    }
    
    @When ("User clicking on Save Button")
    public void addupdatesave()
    {
    	cXpath.addupdatesave();
    }
   
    @When("I click on Manage Notification icon")
    public void clickManageNotification()
    {
        cXpath.clickManageNotification();	
    }
    
    @Then ("user clears start date")
    public void clear()
    {
    	cXpath.clear_sdate();
    }
    @Then ("user clears end date")
    public void cleare()
    {
    	cXpath.clear_edate();
    }
    @When ("user click on $start_date")
    public void clickCalendar(String start_date)
    {
        cXpath.clickCalendar(start_date);	
    }
    @When("I click on Delete icon for <title_name>")
    public void clickDelete(String title_name)
    {
        cXpath.clickDelete(title_name.replace("{", "").replace("}", ""));	
    }
    
    @Then ("user clears")
    public void clearfile() 
    {
    	String path="C:\\Users\\663847\\Downloads\\";
    	zipObj.clear(path);
    }
    
    @Then("User click on Downloaded zip file")
    public void downloadZip() throws IOException
    {    
    	String path1="D:\\outputzip";
    zipObj.clear(path1);
    	File f = new File("C:\\Users\\663847\\Downloads\\");
    	
        File[] downloadedFiles = f.listFiles();
        for (int i = 0; i < downloadedFiles.length; i++) 
        {
        	 String fileName = downloadedFiles[i].getName();
        String Filename = downloadedFiles[i].toString();
        //System.out.println(downloadedFiles);
        //Desktop.getDesktop().open(new File(Filename));
       // System.out.println(Filename);
        if (fileName.startsWith("UserSearchResults-"))
        zipObj.unZipIt(Filename, "D:\\outputzip");
        
        } 
   
        File file1= new File("D:\\outputzip");
        File[] files = file1.listFiles();
  	File lastModifiedFile = files[0];
       for (int i = 0; i < files.length; i++) {
    	   
           String fileName = files[i].getName();
           if (fileName.startsWith("UserSearchResults-"))
        	  lastModifiedFile=files[i];  
       }
       String nfName=lastModifiedFile.getName();
       System.out.println(nfName);
       cXpath.firstrow(nfName);
       
  
    }
    
    @When("I click on Edit icon for <title_name>")
    public void clickEdit(String title_name)
    {
        cXpath.clickEdit(title_name.replace("{", "").replace("}", ""));	
    }
    
    @Then ("click on download file")
    public void downloadZip1() throws IOException
    {    
    	String path1="D:\\outputzip";
        zipObj.clear(path1);
    	File f = new File("C:\\Users\\663847\\Downloads\\");
    	
        File[] downloadedFiles = f.listFiles();
        for (int i = 0; i < downloadedFiles.length; i++) 
        {
        	String fileName = downloadedFiles[i].getName();
        String Filename = downloadedFiles[i].toString();
        //System.out.println(downloadedFiles);
        //Desktop.getDesktop().open(new File(Filename));
       // System.out.println(Filename);
        if (fileName.startsWith("SubscriberSearchResults-"))
        zipObj.unZipIt(Filename, "D:\\outputzip");
        
        } 
   
        File file1= new File("D:\\outputzip");
        File[] files = file1.listFiles();
  	File lastModifiedFile = files[0];
       for (int i = 0; i < files.length; i++) {
    	   
           String fileName = files[i].getName();
           if (fileName.startsWith("SubscriberSearchResults-"))
        	  lastModifiedFile=files[i];  
       }
       String nfName=lastModifiedFile.getName();
       System.out.println(nfName);
       cXpath.firstrow(nfName);
       
  
    }
    @Then("User clicks on $user_submit")
    public void clickButton(String user_submit)
    {
    	cXpath.clickButtonwithID(user_submit.replace("{", "").replace("}", ""));
    }
    @Then("User view $console")
    public void viewText(String console)
    {
    	cXpath.viewText(console.replace("{", "").replace("}", ""));
    	/*String eleValue=console.replace("{", "").replace("}", "").trim();
   	 Assert.assertTrue(cXpath.viewText(console.replace("{", "").replace("}", "").trim()).contains(eleValue));*/ 
    }
   
    @Then("User view <enterValueq> or <enterValues>")
    public void viewText1(String console)
    {
    	cXpath.viewText(console.replace("{", "").replace("}", ""));
    }
    @When("User click on $linkName Link")
    public void clickLink(String linkName){
    	System.out.println("linkname is------"+linkName);
    	cXpath.clickLink(linkName.replace("{", "").replace("}", ""));
    }
    @Then("User Selects $dropdownOption")
    public void selectValue(String dropdownOption){
    cXpath.clickLink(dropdownOption.replace("{", "").replace("}", ""));
}
    
    @When("User clicks Search Button")
    public void clickbutton()
    {
    	cXpath.clickButton();
    	
    }
    @When("User click on Cancel Button")
    public void click_cancelBtn()
    {
    	cXpath.click_cancelBtn();
    	
    }
    @When("User click on Save Button")
    public void click_SaveBtn()
    {
    	cXpath.click_SaveBtn();
    	
    }
    @When("User click on Download icon")
    public void click_downloadicon()
    {
    	cXpath.click_downloadicon();
    	
    }
    @Then("click on Save link")
    public void savelink(){
    	cXpath.savebutton();
    }
    @Then("wait for sometime to database update")
    public void waitforPage() throws InterruptedException{
    	cXpath.waitforPage();
    }
    @Then("User verify results table")
    public void viewTable(){
    	cXpath.viewTable();
    }
    @Then("User enters $textBoxValue value for $textBoxName")
    public void enterTextBox(String textBoxValue, String textBoxName){
    	cXpath.enterTextBox(textBoxValue.replace("{", "").replace("}", ""),textBoxName.replace("{", "").replace("}", ""));
    }
    @When("User enter the values for the fields as <TextFieldName> with <TextValue>")
    public void enterTxtInputs(String TextFieldName, String TextValue){
    	cXpath.enterTxtInputs(TextFieldName,TextValue);
    }
    @When("User select the list value for the fields as <ListFieldName> for <ListValue>")
    public void selectListValue(String ListFieldName, String ListValue)
    {
    	cXpath.enterListInputs(ListFieldName, ListValue);
    }
    @Then("User selects date as <sdate>")
    public void selectdate1(String sdate)
    {
    	cXpath.selectdate(sdate);
    }
    @Then("User selects date as <edate>")
    public void selectdate2(String edate)
    {
    	cXpath.selectdate(edate);
    }
    @When("User Select Checkbox as $option")
    public void selectCheckbox(String option)
    {
    	cXpath.selectCheckbox(option.replace("{", "").replace("}", ""));
    }
    @When("User Selected product is $option")
    public void selectCheckbox1(String option)
    {
    	cXpath.selectCheckbox1(option.replace("{", "").replace("}", ""));
    }
    //Security
    @Then ("User clicks $username link")
	public void clickUser(String username)
	{
	cXpath.clickLink(username.replace("{", "").replace("}", ""));
}
@Then ("User presses the $Security and $SendLink buttons respectively")
public void clickSecurity(String Security,String SendLink )
{
	cXpath.clickLink(Security.replace("{", "").replace("}", ""));
	cXpath.clickLink(SendLink.replace("{", "").replace("}", ""));
}
//space for send link pop up

@When("User clicks $changeBut button")
public void clickChange(String changeBut)
{
	cXpath.clickLink(changeBut.replace("{", "").replace("}", ""));
}
@Then("User clicks $OK button") 
public void clickOk(String OK)
{
	cXpath.clickLink(OK.replace("{", "").replace("}", ""));
}
@Then("User clicks $Save and $OK")
public void clickPop(String Save,String OK)
{
	cXpath.clickLink(Save.replace("{", "").replace("}", ""));
	cXpath.clickLink(OK.replace("{", "").replace("}", ""));
}
@Then ("User clicks the change log $changeLog")
public void clickChangelog( String changeLog  )
{
	cXpath.clickLink(changeLog.replace("{", "").replace("}", ""));
}


@Then ("User clicks login error $OK")
public void clickLogin(String OK)
{
	cXpath.clickLink(OK.replace("{", "").replace("}", ""));
}
@Then ("User clicks API email address error $OK")

public void clickMail(String OK)
{
	cXpath.clickLink(OK.replace("{", "").replace("}", ""));
}

@Then ("User clicks company name error $OK}")
public void clickCompany(String OK)
{
	cXpath.clickLink(OK.replace("{", "").replace("}", ""));
}
@Then ("User clicks user ID error $OK}")
public void clickUserid(String OK)
{
	cXpath.clickLink(OK.replace("{", "").replace("}", ""));
}
@Then ("User clicks email address error $OK")
public void clickEmail(String OK)
{
	cXpath.clickLink(OK.replace("{", "").replace("}", ""));
}
@Then ("User clicks subscriber error $OK")
public void clickSubscriber(String OK)
{
	cXpath.clickLink(OK.replace("{", "").replace("}", ""));
}
@Then ("User clicks UUID error $OK")
public void clickUuid(String OK)
{
	cXpath.clickLink(OK.replace("{", "").replace("}", ""));
}
@Then ("User clicks the pop up $OK") 
public void clickPop(String OK)
{
   cXpath.clickLink(OK.replace("{", "").replace("}", ""));
}
@Then ("User clicks group name error message $OK")
public void clickGroup(String OK)
{
   cXpath.clickLink(OK.replace("{", "").replace("}", ""));
}
@Then ("User clicks contract ID error message $OK")
public void clickContact(String OK)
{
	cXpath.clickLink(OK.replace("{", "").replace("}", ""));
}
@When ("User clicks the $Security")
public void clickSecurity(String Security)
{
	cXpath.clickLink(Security.replace("{", "").replace("}", ""));
}

//env
@Then ("User enter <enterValueq> or <enterValues> value for $Login")
public void decideTextbox(String enterValueq, String enterValues,String Login)

{

    String env = System.getProperty("env");
    if(env.contains("stg"))
    {
    	cXpath.enterTextBox(enterValues.replace("{", "").replace("}", ""),Login.replace("{", "").replace("}", ""));
    }
    else if(env.contains("qa"))
    {
    	cXpath.enterTextBox(enterValueq.replace("{", "").replace("}", ""),Login.replace("{", "").replace("}", ""));
    }
}
@Then ("User click <enterValueq> or <enterValues> link")
public void decideClick(String enterValueq,String enterValues)

{String env = System.getProperty("env");
if(env.contains("stg"))
{
	cXpath.clickLink(enterValues.replace("{", "").replace("}", ""));
}

else if(env.contains("qa"))
{
	cXpath.clickLink(enterValueq.replace("{", "").replace("}", ""));
}

}
@Then("User views <enterValueq> or <enterValues>")
public void decideView(String enterValueq,String enterValues)

{String env = System.getProperty("env");
if(env.contains("stg"))
{
	cXpath.viewText(enterValues.replace("{", "").replace("}", ""));
}

else if(env.contains("qa"))
{
	cXpath.viewText(enterValueq.replace("{", "").replace("}", ""));
}

}
@Then("User views <enterValueQa> or <enterValueStg>")
public void decideViews(String enterValueQa,String enterValueStg)

{String env = System.getProperty("env");
if(env.contains("stg"))
{
	cXpath.viewText(enterValueStg.replace("{", "").replace("}", ""));
}

else if(env.contains("qa"))
{
	cXpath.viewText(enterValueQa.replace("{", "").replace("}", ""));
}

}
@Then ("User enter <enterValueq> or <enterValues> values for <fieldValueq> or <fieldValues>")

public void decideTextBox(String enterValueq, String enterValues, String fieldValueq,String fieldValues ){
	
	
		String env = System.getProperty("env");
			if(env.contains("stg"))		
	{
	cXpath.enterTextBox(enterValues.replace("{", "").replace("}", ""),fieldValues.replace("{", "").replace("}", ""));
}
			else
			{
				cXpath.enterTextBox(enterValueq.replace("{", "").replace("}", ""),fieldValueq.replace("{", "").replace("}", ""));
			}
}
@Then ("User clicks <enterValueQa> or <enterValueStg>")
public void decideClick1(String enterValueQa, String enterValueStg)
{String env = System.getProperty("env");
if(env.contains("stg"))
{
	cXpath.clickLink(enterValueStg.replace("{", "").replace("}", ""));
}

else
{
	cXpath.clickLink(enterValueQa.replace("{", "").replace("}", ""));
}

}
@When ("User selects the list value for the field as <ListFieldName> for <ListValueSub> or <ListValueGrp>")
public void decideList(String ListFieldName,String ListValueSub,String ListValueGrp )
{
	String env = System.getProperty("env");
	if(env.contains("stg"))
	{
		cXpath.enterListInputs(ListFieldName, ListValueSub);
	}

	else if(env.contains("qa"))
	{
		cXpath.enterListInputs(ListFieldName, ListValueGrp);
	}

}
}