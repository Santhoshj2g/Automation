package com.dnb.automation.onboard;
import java.io.IOException;

import org.junit.After;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.openqa.selenium.WebDriver;

import com.dnb.automation.onboard.pages.CommonXpath;

import net.serenitybdd.jbehave.SerenityStories;
import net.thucydides.core.annotations.Managed;


@RunWith(Suite.class)
@Suite.SuiteClasses({SmokeTest_Idaas_Console_Group_Search_Download.class,
	SmokeTest_Idaas_Console_Group_Update.class,
	SmokeTest_Idaas_Console_Notification.class,
	SmokeTest_Idaas_Console_Security.class,
	SmokeTest_Idaas_Console_Subscriber_Search.class,
	SmokeTest_Idaas_Console_User_Creation_Emptyfield.class,
	SmokeTest_Idaas_Console_User_Creation_User_Update.class,
	SmokeTest_Idaas_Console_User_Search_Download.class,
	SmokeTest_Idaas_Console_User_Search_Emptyfield.class,
	SmokeTest_Idaas_Console_User_Search.class,
	SmokeTest_Idaas_Console_User_Update.class})
public class SmokeTest_Idaas_Console extends SerenityStories {
	@Managed(uniqueSession = true, driver="chrome")
    public WebDriver webdriver;
	
	public SmokeTest_Idaas_Console() {
		runSerenity().inASingleSession();
	}
	@After
	public void cleanUp() throws IOException {
		CommonXpath objOnboardCommonXpath=new CommonXpath();
		objOnboardCommonXpath.exception();
}
}