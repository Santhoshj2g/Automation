package com.dnb.automation.onboard;
import org.openqa.selenium.WebDriver;

import net.serenitybdd.jbehave.SerenityStory;
import net.thucydides.core.annotations.Managed;
public class SmokeTest_Idaas_Console_User_Creation_Emptyfield extends SerenityStory {
	@Managed(uniqueSession = true, driver="chrome")
    public WebDriver webdriver;
	
	public SmokeTest_Idaas_Console_User_Creation_Emptyfield() {
		runSerenity().inASingleSession();
	}
}
