package com.dnb.automation.onboard;
import org.openqa.selenium.WebDriver;

import net.serenitybdd.jbehave.SerenityStory;
import net.thucydides.core.annotations.Managed;
public class SmokeTest_Idaas_Console_Group_Search_Download extends SerenityStory {
	@Managed(uniqueSession = true, driver="chrome")
    public WebDriver webdriver;
	
	public SmokeTest_Idaas_Console_Group_Search_Download() {
		runSerenity().inASingleSession();
	}
}
