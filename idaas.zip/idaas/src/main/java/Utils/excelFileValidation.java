package Utils;


import java.awt.Desktop;
import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jbehave.core.steps.Row;

import com.ibm.icu.text.SimpleDateFormat;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;



public class excelFileValidation {
	
		public void FileValidation(String content,String text) throws IOException  {
			String filepath="D:\\outputzip";
			String sheetname="UserSearchResults";
			String tab_cont=content;
			String res = null;
			// System.out.print(content);
File file = new File(filepath+"\\"+text);
			 FileInputStream inputStream = new FileInputStream(file);
			 HSSFWorkbook smpl = null;
			 
			 String fileExtensionName = text.substring(text.indexOf("."));
			 
			 if(fileExtensionName.equals(".xls"))
				smpl = new HSSFWorkbook(inputStream);

			
			 HSSFSheet Sheet1 = smpl.getSheet(sheetname);
			 //int rowCount =Sheet1.getLastRowNum()-Sheet1.getFirstRowNum();
			// int rowcount=++rowCount;
			HSSFRow row = Sheet1.getRow(1);
			 System.out.println("\nFirst Row of Results Table");
			 System.out.println(tab_cont);
			 System.out.println("First Row of extracted Excel File");
			 for (int j = 0; j < row.getLastCellNum(); j++) 
			 {	
			 res= row.getCell(j).getStringCellValue();
			 System.out.print(res);
			 }
			 //System.out.println("\nNumber of rows in Excel file are : "+rowcount);
			 if(tab_cont.contains(res))
				 System.out.println("\nMatching Results Found");
			 else
				 System.out.println("\nMatching Results not Found");
		}	 
			 
			 public void FileValidations(String content,String text) throws IOException  {
					String filepath="D:\\outputzip";
					String sheetname="SubscriberSearchResults";
					String tab_cont=content;
					String res = null;
					Date date;
					String strDate;
					 //Date date1 = new Date();  
					    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
					     
					// System.out.print(content);
		File file = new File(filepath+"\\"+text);
					 FileInputStream inputStream = new FileInputStream(file);
					 HSSFWorkbook smpl = null;
					 
					 String fileExtensionName = text.substring(text.indexOf("."));
					 
					 if(fileExtensionName.equals(".xls"))
						smpl = new HSSFWorkbook(inputStream);

					
					 HSSFSheet Sheet1 = smpl.getSheet(sheetname);
					 //int rowCount =Sheet1.getLastRowNum()-Sheet1.getFirstRowNum();
					// int rowcount=++rowCount;
					HSSFRow row = Sheet1.getRow(1);
					 System.out.println("\nFirst Row of Results Table");
					 System.out.println(tab_cont);
					 System.out.println("First Row of extracted Excel File");
					 for (int j = 0; j < row.getLastCellNum(); j++) 
					 {	
						 if(j==6)
					 {
							 
						date= row.getCell(j).getDateCellValue();
						
						/*if(date.equals(""))
						{
							 strDate="";
							 System.out.print(strDate);
						}
						else
						{*/
						  strDate= formatter.format(date);
					 System.out.print(strDate);
					 }
					 else
					 {
					 res= row.getCell(j).getStringCellValue();
					 System.out.print(res);
					 }}
					 //System.out.println("\nNumber of rows in Excel file are : "+rowcount);
					 if(tab_cont.contains(res))
						 System.out.println("\nMatching Results Found");
					 else
						 System.out.println("\nMatching Results not Found");
			
		   
} 
}