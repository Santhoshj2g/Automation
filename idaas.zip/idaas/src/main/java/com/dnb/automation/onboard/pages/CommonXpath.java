package com.dnb.automation.onboard.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import java.text.SimpleDateFormat;  
import java.util.Date; 
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import com.dnb.automation.utils.UIHelper;
import Utils.excelFileValidation;
import junit.framework.Assert;

public class CommonXpath extends PageObject {

	private String option1;
	private String loginid;
	private String password;
	String img = "//img[@class='ajax-loader']";

	String popup = "//*[@id='apiTimer']/span[2]";
	WebElementFacade pop1 = find(By.xpath(popup));
	@FindBy(xpath = "//*[@id='headerContainer']/div/div[3]/form/a")
	private WebElementFacade searchIcon;

	@FindBy(xpath = "//a[normalize-space(text())='Subscriber']")
	private WebElementFacade subscriberLink;

	@FindBy(xpath = "//span[normalize-space(text())='Create Subscriber']")
	private WebElementFacade createSubLink;

	@FindBy(xpath = "//div[@class='container-title']/following-sibling::form//label[normalize-space(text())='Subscriber Number']/following-sibling::div[1]/input")
	private WebElementFacade subNumberVal;
	private String createsubpage = "//div[@class='container-title']/following-sibling::form//label[normalize-space(text())='Subscriber Number']/following-sibling::div[1]/input";

	@FindBy(xpath = "//button[normalize-space(text())='Save']")
	private WebElementFacade saveBtn;

	@FindBy(xpath = "//button[normalize-space(text())='OK']")
	private WebElementFacade okBtn;

	@FindBy(xpath = "//*[normalize-space(text())='Cancel']")
	private WebElementFacade cancelBtn;
	excelFileValidation val = new excelFileValidation();
	
	
   
	public void clickstatus(String name)
	{
		UIHelper.waitForPageToLoad(getDriver());
		WebElementFacade feild = find(By.xpath("//span[@class='" + name + "']"));
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView();", feild);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//span[@class='" + name + "']");
		UIHelper.highlightElement(getDriver(), feild);
		feild.click();
	}
	public void firstrow(String nfname) throws IOException {
		String name=nfname;
		WebElement feild = getDriver().findElement(By.xpath("//tr[@ng-repeat='item in tableData'][1]"));
		String contents = feild.getText();
		String conts = contents.replace(" ","");
		//WebElement table = getDriver().findElement(By.xpath("//table[@class='user-result dataTable table-hover']"));
		//List<WebElement> row = table.findElements(By.tagName("tr"));
		//List<WebElement> rows = getDriver().findElements(By.xpath("//table[@class='user-result dataTable table-hover']"));
		//int count = row.size();
		//System.out.println("Number of rows in Result Table are: "+count);
		if(name.startsWith("UserSearchResults-"))
		val.FileValidation(conts, name);
		else
			val.FileValidations(conts, name);	

	}

	public void enterListInputs(String TabName, String FieldName, String Value) {
		String FieldXpath = "//*[normalize-space(text())='" + TabName
				+ "']//following::*//label[normalize-space(text())='" + FieldName + "']//following::select";
		WebElementFacade fieldelement = find(By.xpath(FieldXpath));
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView();", fieldelement);
		fieldelement.selectByVisibleText(Value);
	}

	public void enterTxtInputs(String textTabName, String textFieldName, String textValue) {
		UIHelper.waitForPageToLoad(getDriver());

		WebElement field = find(By.xpath(
				"//*[normalize-space(text())='" + textTabName + "']//following::*//label[normalize-space(text())='"
						+ textFieldName + "']/following-sibling::div[1]/input"));
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView();", field);
		UIHelper.highlightElement(getDriver(), field);
		field.clear();
		field.sendKeys(textValue);

	}

	public void clickLink(String tabName, String linkName) {
		WebElement feild = getDriver().findElement(By.xpath("//*[normalize-space(text())='" + tabName
				+ "']//following::button[contains(text(),'" + linkName + "')]"));
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[normalize-space(text())='" + tabName
				+ "']//following::button[contains(text(),'" + linkName + "')]");
		UIHelper.highlightElement(getDriver(), feild);
		feild.click();
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), img);
	}

	public void addupdatesave() {
		UIHelper.waitForPageToLoad(getDriver());
		WebElementFacade feild = find(By.xpath("//button[@ng-click='addUpdate()']"));
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView();", feild);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//button[@ng-click='addUpdate()']");
		UIHelper.highlightElement(getDriver(), feild);
		feild.click();
	}

	public void clickCalendar(String value) {
		UIHelper.waitForPageToLoad(getDriver());
		if (value.equals("Start Date") || value.equals("End Date")) {
			WebElement field = getDriver().findElement(By.xpath("//label[contains(text(),'" + value
					+ "')]//following::button[@class='calender-icon_p icon-btn'][1]"));
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView();", field);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					"//label[contains(text(),'Start Date')]//following::button[@class='calender-icon_p icon-btn'][1]");
			UIHelper.highlightElement(getDriver(), field);
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", field);
		}
	}
public void clear_sdate()
{
	UIHelper.waitForPageToLoad(getDriver());
	WebElementFacade feild = find(By.xpath("//label[contains(text(),'Start Date')]//following::button[@class='cancel-icon_p icon-btn'][1]"));
	((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView();", feild);
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//label[contains(text(),'Start Date')]//following::button[@class='cancel-icon_p icon-btn'][1]");
	UIHelper.highlightElement(getDriver(), feild);
	feild.click();
}
public void clear_edate()
{
	UIHelper.waitForPageToLoad(getDriver());
	WebElementFacade feild = find(By.xpath("//label[contains(text(),'Start Date')]//following::button[@class='cancel-icon_p icon-btn'][2]"));
	((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView();", feild);
	UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//label[contains(text(),'Start Date')]//following::button[@class='cancel-icon_p icon-btn'][2]");
	UIHelper.highlightElement(getDriver(), feild);
	feild.click();
}
	public void clickManageNotification() {

		UIHelper.waitForPageToLoad(getDriver());
		WebElementFacade feild = find(By.xpath("//span[@ng-click='addEditNotification()']"));
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView();", feild);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//span[@ng-click='addEditNotification()']");
		UIHelper.highlightElement(getDriver(), feild);
		feild.click();
	}

	public void clickDelete(String title_name) {

		UIHelper.waitForPageToLoad(getDriver());
		WebElementFacade feild = find(By.xpath("//label[contains(text(),'" + title_name + "')]//following::span[@title='Delete Notification']"));
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView();", feild);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//label[contains(text(),'" + title_name + "')]//following::span[@title='Delete Notification']");
		UIHelper.highlightElement(getDriver(), feild);
		feild.click();
	}

	public void clickEdit(String title_name) {
           
		UIHelper.waitForPageToLoad(getDriver());
		WebElementFacade feild = find(By.xpath("//label[contains(text(),'" + title_name + "')]//following::span[@title='Edit Notification']"));
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView();", feild);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//label[contains(text(),'" + title_name + "')]//following::span[@title='Edit Notification']");
		WebDriver driver = getDriver();
		Actions act = new Actions(driver);
		UIHelper.highlightElement(getDriver(), feild);
		act.moveToElement(feild);
		waitFor(300);
		act.click();
		act.build().perform();
	}
	
	public void click_downloadicon() {

		UIHelper.waitForPageToLoad(getDriver());
		WebElementFacade feild = find(By.xpath("//span[@class='glyphicon glyphicon-download-alt']"));
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView();", feild);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//span[@class='glyphicon glyphicon-download-alt']");
		UIHelper.highlightElement(getDriver(), feild);
		feild.click();
	}

	public void Entervalue(String idvalue, String value) {
		System.out.println("Id is------" + idvalue);
		if (value.equals("ns789Throw@#") || value.equals("ns789Throw@#1")) {
			if (value.equals("ns789Throw@#")) {
				Random r = new Random();
				int n = 10 + r.nextInt(90);
				password = value + n;
			}

			UIHelper.waitForPageToLoad(getDriver());
			WebElement feild = getDriver().findElement(By.xpath("//input[@id='" + idvalue + "']"));
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//input[@id='" + idvalue + "']");
			UIHelper.highlightElement(getDriver(), feild);
			feild.clear();
			feild.sendKeys(password);
			UIHelper.waitForPageToLoad(getDriver());
		} else {
			UIHelper.waitForPageToLoad(getDriver());
			WebElement feild = getDriver().findElement(By.xpath("//input[@id='" + idvalue + "']"));
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//input[@id='" + idvalue + "']");
			UIHelper.highlightElement(getDriver(), feild);
			feild.clear();
			feild.sendKeys(value);
			UIHelper.waitForPageToLoad(getDriver());
		}
	}

	public void viewText(String text) {
		String value = null;
		
			if (text.equals("User Password Changed")) {
				System.out.println("text Name is------" + text);
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), img);
				UIHelper.waitForPageToLoad(getDriver());
				WebElement feild = getDriver().findElement(By.xpath("//span[contains(.,'" + text + "')]"));
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//span[contains(.,'" + text + "')]");
				UIHelper.highlightElement(getDriver(), feild);
				UIHelper.waitForPageToLoad(getDriver());

			} else if (text.equals("date")) {
				Calendar cal = Calendar.getInstance();
				SimpleDateFormat sf = new SimpleDateFormat("MMM d, YYYY");
				Date date = new Date();
				String date1 = sf.format(date);
				System.out.println(date1);
				UIHelper.waitForPageToLoad(getDriver());
				WebElement feild = getDriver()
						.findElement(By.xpath("//td[contains(.,'" + date1 + "')]/following::td/ul"));
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						"//td[contains(.,'" + date1 + "')]/following::td/ul");
				UIHelper.highlightElement(getDriver(), feild);
				UIHelper.waitForPageToLoad(getDriver());
			} else if (text.equals("MyDNB.com") || text.equals("Toolkit") || text.equals("DnB Direct Onboard")
					|| text.equals("DnB Direct API") || text.equals("OLUS") || text.equals("ERCR")
					|| text.equals("eRecheck") || text.equals("FATCA") || text.equals("Reference Data")
					|| text.equals("Registration Portal") || text.equals("TIS") || text.equals("Trade Keystone")
					|| text.equals("CLM") || text.equals("Onboard") || text.equals("Compliance/DaaS")
					|| text.equals("IVS")) {
				System.out.println("text Name is------" + text);
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), img);
				UIHelper.waitForPageToLoad(getDriver());
				WebElement feild = getDriver()
						.findElement(By.xpath("//div[@class='tab-content']//label[contains(.,'" + text + "')]"));
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						"//div[@class='tab-content']//label[contains(.,'" + text + "')]");

				UIHelper.highlightElement(getDriver(), feild);
				UIHelper.waitForPageToLoad(getDriver());
			} else if (text.equals("Manage Notification	- Notification List")
					|| text.equals("Manage Notification	- Add New Notification") || text.equals("Confirm")
					|| text.equals("Manage Notification	- Edit Notification")) {
				System.out.println("text Name is------" + text);
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), img);
				UIHelper.waitForPageToLoad(getDriver());
				WebElement feild = getDriver().findElement(By.xpath("//div[contains(text(),'" + text + "')]"));
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//div[contains(text(),'" + text + "')]");

				UIHelper.highlightElement(getDriver(), feild);
				UIHelper.waitForPageToLoad(getDriver());
			} else {

				System.out.println("text Name is------" + text);
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), img);
				UIHelper.waitForPageToLoad(getDriver());
				WebElement feild=getDriver().findElement(By.xpath("//*[normalize-space(text())='" + text + "']"));
				/*List<String> feild = getAllElements(text);
				System.out.println(feild.iterator());
				Assert.assertTrue(feild.size()!= 0);
				*/
				if(feild.isDisplayed()){
						UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
								"//*[normalize-space(text())='" + text + "']");
						//System.out.println("field---->" + feild);
						//UIHelper.highlightElement(getDriver(), (WebElement) feild);
						UIHelper.highlightElement(getDriver(), feild);
						UIHelper.waitForPageToLoad(getDriver());
					
			}
				else
					Assert.assertEquals("Expected:"+text,"Actual:"+ feild.getText());
			}
		

	}
	public List<String> getAllElements(String xpTextValue2) {
		UIHelper.waitForPageToLoad(getDriver());
		waitFor(5000);
		List<WebElementFacade> matchingEle = findAll(xpTextValue2);
		List<String> stringList = new ArrayList<String>();
		for (WebElementFacade webElement : matchingEle) {
			stringList.add(webElement.getTextValue());
		}
		
		return stringList;
	} 
	public void clickButtonwithID(String value) {
		System.out.println("Button id is------" + value);
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), img);
		UIHelper.waitForPageToLoad(getDriver());
		WebElement feild = getDriver().findElement(By.xpath("//input[@id='" + value + "']"));
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//input[@id='" + value + "']");
		UIHelper.highlightElement(getDriver(), feild);
		feild.click();
		UIHelper.waitForPageToLoad(getDriver());

	}

	public void launchOnboardApplication(String appplicationURL) {
		// getDriver().get(appplicationURL);
		getDriver().manage().deleteAllCookies();
		getDriver().get(appplicationURL);
		getDriver().manage().window().maximize();
		System.out.println("APP LAUNCHED");

	}

	public void clickLink(String linkName) {
		try {
			System.out.println("linkname is------" + linkName);
			UIHelper.waitForPageToLoad(getDriver());

			if (!linkName.equals("Subscriber")) {

				if (linkName.equals("subscriber")) {
					linkName = "Subscriber";
				}
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), img);
				WebElementFacade feild = find(By.xpath("//*[normalize-space(text())='" + linkName + "']"));
				//WebElement feild = getDriver().findElement(By.xpath("//*[normalize-space(text())='" + linkName + "']"));
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[normalize-space(text())='" + linkName + "']");
				((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView();", feild);
				
				UIHelper.highlightElement(getDriver(), feild);
				//feild.waitUntilClickable();
				feild.click();
				//((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", feild);
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), img);
			}
		

						else {
				WebElement feild = getDriver()
						.findElement(By.xpath("//*[normalize-space(text())='" + linkName + "']//following::button"));
				UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
						"//*[normalize-space(text())='" + linkName + "']//following::button");
				((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView();", feild);
				UIHelper.highlightElement(getDriver(), feild);
				((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", feild);
				UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), img);
			}
		} catch (Exception e) {
			exception();
			e.printStackTrace();
		}
	}

	public void clickButton() {
		try {
			UIHelper.waitForPageToLoad(getDriver());
			WebElement searchIcon1 = getDriver().findElement(By.xpath("//a[@class='searchIcon']"));
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//a[@class='searchIcon']");
			UIHelper.highlightElement(getDriver(), searchIcon1);
			searchIcon1.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), img);
		} catch (Exception e) {
			exception();
			e.printStackTrace();
		}
	}

	public void viewTable() {
		UIHelper.waitForPageToLoad(getDriver());
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), img);
		WebElement table = getDriver().findElement(By.xpath("//table[contains(@id,'searchTable')]"));
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//table[contains(@id,'searchTable')]");
		UIHelper.highlightElement(getDriver(), table);

	}

	public void enterTextBox(String textBoxValue, String textBoxName) {
		UIHelper.waitForPageToLoad(getDriver());
		if (textBoxName.equals("Business Information Report") || textBoxName.equals("Business Background Report")
				|| textBoxName.equals("Algeria")) {

			WebElement listfield = getDriver()
					.findElement(By.xpath("//div[@class='tab-pane active']//*[normalize-space(text())='" + textBoxName
							+ "']//following::label[contains(.,'" + textBoxValue + "')]"));

			listfield.click();
			System.out.println("if part");
		} else {
			System.out.println("else part");
			UIHelper.waitForPageToLoad(getDriver());
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), img);
			WebElement fieldName = find(By.xpath("//option[contains(text(),'" + textBoxName + "')]/following::input[1]"));
			  ((JavascriptExecutor) getDriver()).executeScript(
			  "arguments[0].scrollIntoView();", fieldName);
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
					"//option[contains(text(),'" + textBoxName + "')]/following::input[1]");
			UIHelper.highlightElement(getDriver(), fieldName);
			fieldName.clear();
			fieldName.sendKeys(textBoxValue);
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), img);
		}
	}

	public void selectdate(String value) {
		 SimpleDateFormat formatter = new SimpleDateFormat("dd");  
		    Date date = new Date();  
		    String date1=(formatter.format(date));
		    int result = Integer.parseInt(date1);
		    if(value.equals("0"))
		    {
		    	result=result+2;
		    }
		    else if(value.equals("1"))
		    {
		    	result=result+3;
		    }
		    else if(value.equals("-1"))
		    {
		    	result=result-2;
		    }
		WebElement field = find(
				By.xpath("//*[@class='uib-datepicker']//following::span[normalize-space(text())='" + result + "']"));
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", field);
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(),
				"//*[@class='uib-datepicker']//following::span[normalize-space(text())='" + result + "']");
		UIHelper.highlightElement(getDriver(), field);
		field.click();
		// field.sendKeys(value);

	}

	public void enterTxtInputs(String textFieldName, String textValue) {
		UIHelper.waitForPageToLoad(getDriver());

		if (textFieldName.equals("Login ID") || textFieldName.equals("Email Address")
				|| textFieldName.equals("API Email ID")) {

			if (textFieldName.equals("Login ID")|| textFieldName.equals("API Email ID")) {
				Random r = new Random();
				int n = 100000 + r.nextInt(900000);
				loginid = option1.replaceAll("\\s+", "") + n + "@test.com";
			}
			WebElement field = find(
					By.xpath("//div[@class='container-title']/following::form//label[normalize-space(text())='"
							+ textFieldName + "']/following-sibling::div[1]/input"));
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", field);

			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", field);
			UIHelper.highlightElement(getDriver(), field);
			field.clear();
			field.sendKeys(loginid);
		} else if (textFieldName.equals("Notification Title")) {
			WebElement field = find(By.xpath("//*[normalize-space(text())='" + textFieldName + "']//following::input"));
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", field);
			UIHelper.highlightElement(getDriver(), field);
			field.clear();
			field.sendKeys(textValue);
		}

		else if (textFieldName.equals("Notification Text")) {
			getDriver().switchTo().frame(0);
			// WebElementFacade field = find(By.cssSelector("#tinymce > p"));
			WebElement field = find(By.xpath("//*[@id='tinymce']/p"));
			// ((JavascriptExecutor)
			// getDriver()).executeScript("arguments[0].scrollIntoView();",
			// field);
			WebDriver driver = getDriver();
			
			field.click();
			
			Actions act = new Actions(driver);
			UIHelper.highlightElement(getDriver(), field);
			act.moveToElement(field);
			waitFor(300);
			
			act.sendKeys(" "+textValue);
			act.build().perform();
			getDriver().switchTo().defaultContent();
		}

		else if (!textFieldName.equals("Search Subscriber")) {
			WebElement field = find(
					By.xpath("//div[@class='container-title']/following::form//label[normalize-space(text())='"
							+ textFieldName + "']/following-sibling::div[1]/input"));
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", field);
			UIHelper.highlightElement(getDriver(), field);
			field.sendKeys(textValue);
		} else {
			WebElement field = find(By.xpath("//*[normalize-space(text())='" + textFieldName + "']//following::input"));
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", field);
			UIHelper.highlightElement(getDriver(), field);
			field.clear();
			field.sendKeys(textValue);
		}

	}

	public void enterListInputs(String FieldName, String Value) {
		if (FieldName.equals("Search Subscriber")) {
			String FieldXpath = "//*[normalize-space(text())='" + FieldName + "']//following::select";
			WebElementFacade fieldelement = find(By.xpath(FieldXpath));
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", fieldelement);
			fieldelement.selectByVisibleText(Value);
		} else if (FieldName.equals("Title") || FieldName.equals("Archive Opt Out")) {
			String field = "//div[@class='container-title']/following::div[@class='tab-pane active']//label[normalize-space(text())='"
					+ FieldName + "']/following-sibling::div[1]/select";
			WebElementFacade listfield = find(By.xpath(field));
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", listfield);
			listfield.selectByVisibleText(Value);
		} else {
			String FieldXpath = "//div[@class='container-title']/following::*//label[normalize-space(text())='"
					+ FieldName + "']/following-sibling::div[1]/select";
			WebElementFacade fieldelement = find(By.xpath(FieldXpath));
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", fieldelement);
			// ((JavascriptExecutor)
			// getDriver()).executeScript("option[val="+Value+"].selected=true");

			fieldelement.selectByVisibleText(Value);
		}
	}

	public void click_SaveBtn() {
		try {
			UIHelper.highlightElement(getDriver(), saveBtn);
			saveBtn.click();
		} catch (Exception e) {
			exception();
			e.printStackTrace();
		}
	}

	public void click_OKBtn() {
		try {
			UIHelper.highlightElement(getDriver(), okBtn);
			okBtn.click();
		} catch (Exception e) {
			exception();
			e.printStackTrace();
		}
	}

	public void click_cancelBtn() {
		try {
			UIHelper.highlightElement(getDriver(), cancelBtn);
			cancelBtn.click();
		} catch (Exception e) {
			exception();
			e.printStackTrace();
		}
	}

	public void selectCheckbox(String option) {
		if ((option.equals("NA")) || (option.equals("A"))) {
			String FieldXpath = "//div[@id='mCSB_36']//li[@class='entitleDiv'][2]//label[contains(.,'" + option + "')]";
			WebElementFacade fieldelement = find(By.xpath(FieldXpath));
			if (!fieldelement.isSelected())
				fieldelement.click();
		} else if (option.equals("Onboard")) {
			String option1 = "OLUS";
			String FieldXpath = "//ul//li//label[contains(.,'" + option1
					+ "')]//preceding-sibling::span//following::span";
			/*
			 * List<WebElementFacade> fieldelement = find(By.xpath(FieldXpath));
			 * if (!fieldelement.get(1).isSelected())
			 * fieldelement.get(1).click();
			 */
			WebElementFacade fieldelement = find(By.xpath(FieldXpath));
			if (!fieldelement.isSelected())
				fieldelement.click();
		} else {
			String FieldXpath = "//ul//li//label[contains(.,'" + option + "')]//preceding-sibling::span";
			WebElementFacade fieldelement = find(By.xpath(FieldXpath));
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView();", fieldelement);
			if (!fieldelement.isSelected())
				fieldelement.click();

		}

	}

	public String selectCheckbox1(String option) {
		this.option1 = option;
		return this.option1;
	}

	public void waitforPage() throws InterruptedException {
		Thread.sleep(30000);

	}

	public void savebutton() {
		WebElement save = getDriver().findElement(By.xpath("//*[@id='groupDetails']/div[2]/div[2]/div/button"));
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[@id='groupDetails']/div[2]/div[2]/div/button");
		UIHelper.highlightElement(getDriver(), save);
		save.click();

	}

	public void exception() {
		WebElement feild = getDriver().findElement(By.xpath("//*[normalize-space(text())='OK']"));
		UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[normalize-space(text())='OK']");
		UIHelper.highlightElement(getDriver(), feild);
		UIHelper.waitForPageToLoad(getDriver());
		feild.click();
		UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), img);
		WebElement feild1 = getDriver().findElement(By.xpath("//*[normalize-space(text())='Cancel']"));
		if (feild1.isDisplayed()) {
			UIHelper.waitForVisibilityOfEleByXpath(getDriver(), "//*[normalize-space(text())='Cancel']");
			UIHelper.highlightElement(getDriver(), feild1);
			feild1.click();
			UIHelper.waitForInvisibilityOfAjaxImgByXpath(getDriver(), img);
		}
	}

}
